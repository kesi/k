package com.ipas.hf.dbutilities;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.ipas.hf.reporting.StepLogging;



public class SqlQueries {

	private static StepLogging log = StepLogging.getLoggingObject();

	public static String getTest(String StatusId){
		String facilityName=null;
		try{
			String sQuery="Select * from VIMLink where PatientVisitID='"+StatusId+"'";

			List<String> actAssetId = MsSqlDBRead.getSqlData("iPASServiceTracker",sQuery);
			{
				facilityName = actAssetId.get(0).trim();
			}
		}catch(Exception e){
			//logger.error(e);
		}
		return facilityName;
	}

	public static String getInvitationReference(String visitId){
		String InvitationReference=null;
		try{
			String sQuery="Select InvitationReference from VIMLink where PatientVisitID='"+visitId+"'";

			List<String> actAssetId = MsSqlDBRead.getSqlData("iPASServiceTracker",sQuery);
			{
				InvitationReference = actAssetId.get(0).trim();
			}
		}catch(Exception e){
		}
		return InvitationReference;
	}


	public static String getVerificationCode(String visitId){
		String VerificationCode=null;
		try{
			String sQuery="Select VerificationCode from VIMLinkVerificationCode where VIMLinkID="
					+ "(Select VIMLinkID from VIMLink where PatientVisitID='"+visitId+"')";

			List<String> actAssetId = MsSqlDBRead.getSqlData("iPASServiceTracker",sQuery);
			{
				VerificationCode = actAssetId.get(0).trim();
			}
		}catch(Exception e){
		}
		return VerificationCode;
	}



	public static String getInsuranceStatus(String visitId,int sequenceNumber){
		String InvitationReference=null;
		try{
			String sQuery="select StatusId from InsuranceStatus where PatientVisitId='"+visitId+"'"
					+ "and SequenceNumber='"+sequenceNumber+"' and ExpirationDate is NULL";

			List<String> actAssetId = MsSqlDBRead.getSqlData("iPASEligibility",sQuery);
			{
				InvitationReference = actAssetId.get(0).trim();
			}
		}catch(Exception e){
		}
		return InvitationReference;
	}
	public static String getFacilityPayerMasterId(String facilityId,String insurancePlanId){
		String facilityPayerMasterId=null;
		try{

			String sQuery="Select FacilityPayerMasterID from FacilityPayerMaster where FacilityID='"+facilityId+"' and PlanCode='"+insurancePlanId+"'";

			List<String> actAssetId = MsSqlDBRead.getSqlData("iPASEligibility",sQuery);		
			{
				facilityPayerMasterId = actAssetId.get(0).trim();
			}
		}catch(Exception e){
		}
		return facilityPayerMasterId;
	}

	public static ArrayList<String> getFacilityDetails(String code,String tenantID){
		ArrayList<String> facility=new ArrayList<>();
		try {

			String sQuery="Select FacilityId,Name from Facility where FacilityCode='"+code+"' and TenantID='"+tenantID+"'";			
			facility= MsSqlDBRead.getFacility("iPASTenant",sQuery);		

		} catch (Exception e) {			
		}		
		return facility ;

	}
	public static String getPointOfCareId(String code,String facilityID){
		String pointOfCare=null;
		try{

			String sQuery="select PointOfCareID from Pointofcare where PointOfCareCode='"+code+"' and FacilityID='"+facilityID+"'";		
			List<String> actAssetId = MsSqlDBRead.getSqlData("iPASServiceTracker",sQuery);
			{
				pointOfCare = actAssetId.get(0).trim().toLowerCase();
			}
		}catch(Exception e){
		}
		return pointOfCare;
	}
	public static ArrayList<String> getIdentifierTypes(String code,String tenantID){
		ArrayList<String> identifiers=new ArrayList<>();
		try {
			String sQuery="Select PA.UniqueIdentifier as Account,PU.UniqueIdentifier as Patient,PV.UniqueIdentifier as Visit from Facility f "
					+ " join PatientAccountUniqueIdentifierRef PA ON f.PatientAccountUniqueIdentifierRefId=PA.PatientAccountUniqueIdentifierRefID "
					+ " join PatientUniqueIdentifierRef PU ON f.PatientUniqueIdentifierRefID=PU.PatientUniqueIdentifierRefID "
					+ " join PatientVisitUniqueIdentifierRef PV ON f.PatientVisitUniqueIdentifierRefID=PV.PatientVisitUniqueIdentifierRefID "
					+ " where FacilityCode='"+code+"' and TenantID='"+tenantID+"' ";

			identifiers= MsSqlDBRead.getVisitIdentifierTypes("iPASTenant",sQuery);			

		} catch (Exception e) {		
		}
		return identifiers ;

	}

	public static ArrayList<String> getiPASEmployeeDetails(String code,String tenantID){
		ArrayList<String> employee=new ArrayList<>();
		try {
			String sQuery="select EmployeeId,FirstName,LastName from Employee where OperatorID='"+code+"' and TenantID='"+tenantID+"' ";			
			employee= MsSqlDBRead.getEmployeeDetails("iPASTenant",sQuery);			

		} catch (Exception e) {			
		}
		return employee ;

	}
}
