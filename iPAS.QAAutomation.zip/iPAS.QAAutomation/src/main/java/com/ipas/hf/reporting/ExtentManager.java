package com.ipas.hf.reporting;



import java.util.HashMap;
import java.util.Map;

import com.aventstack.extentreports.AnalysisStrategy;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManager {

	private static Map<Long, ExtentReports> extentMap = new HashMap<Long, ExtentReports>();

	public static ExtentHtmlReporter getReporter(String fullName, String scenarioName) {
		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(fullName);

		htmlReporter.setAppendExisting(true);
		htmlReporter.config().setDocumentTitle(scenarioName);
		htmlReporter.config().setTheme(Theme.DARK);
		return htmlReporter;
	}

	public static void setupInstance(String scenarioName) {
		String fullPath = System.getProperty("extent.Report.Directory") + "\\" + scenarioName + ".html";
		ExtentReports extent = new ExtentReports();
		extent.attachReporter(getReporter(fullPath, scenarioName));
		extent.setSystemInfo("Run Platform", "Winodws");
		extent.setSystemInfo("Environment", "QA");
		extent.setAnalysisStrategy(AnalysisStrategy.TEST);
		extentMap.put(Thread.currentThread().getId(), extent);
	}

	public static ExtentReports getInstance() {
		return extentMap.get(Thread.currentThread().getId());
	}

	public static void flushInstance() {
		getInstance().flush();
	}

}
