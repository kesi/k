package com.ipas.hf.dbutilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.utilities.ConfigProperties;



public class MsSqlConnectionUtil extends ConnectionUtil {

	
	private StepLogging log = StepLogging.getLoggingObject();
	

	private static String MSSQLDRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	
	

	private Connection connection = null;

	@Override
	protected Connection getConnection(String dataBase) throws SQLException, ClassNotFoundException {
		try {
			Class.forName(MsSqlConnectionUtil.MSSQLDRIVER);
			this.connection = DriverManager.getConnection("jdbc:sqlserver://" +
					TestBase.prop.dbServer() + ";" +
		            "databaseName=" + dataBase + ";" +
		            "user=" + TestBase.prop.dbUserName() + ";" +
		            "password=" + TestBase.prop.dbPassword() + ";");
			//this.connection = DriverManager.getConnection(this.URL, this.USERNAME, this.PASSWORD);
			System.out.println(connection.isClosed());
		} catch (Exception e) {
			e.printStackTrace();
			log.info("MsSqlConnectionUtil : Exception occured while establishing the MS SQL connection. " + e);
		}
		return connection;
	}

	@Override
	protected Connection getConnection(String host, String portNumber, String SID, String userID, String Password) throws ClassNotFoundException, SQLException {
		return null;
	}

	@Override
	protected void closeDefaultConnection() throws SQLException {
		this.connection.close();
	}

	@Override
	protected void closeCustomizedConnection(String url, String userID, String Password) throws SQLException {
	}

}
