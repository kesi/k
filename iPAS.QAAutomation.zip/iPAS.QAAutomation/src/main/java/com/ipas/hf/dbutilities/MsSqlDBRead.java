package com.ipas.hf.dbutilities;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ipas.hf.reporting.StepLogging;



public class MsSqlDBRead {
	private static StepLogging log = StepLogging.getLoggingObject();

	public static List<String> getSqlData(String dataBase,String sql) throws SQLException{
		Connection con = null;
		Statement statement = null;
		ResultSet resultSet = null;
		List<String> results = new ArrayList<String>();
		try{
			con = MsSqlConnect.getConnection(dataBase);
			statement = con.createStatement();
			resultSet = statement.executeQuery(sql);
			ResultSetMetaData metaData = resultSet.getMetaData();
			while(resultSet.next()){	
				String columnType = metaData.getColumnTypeName(1).trim().toUpperCase();
				switch(columnType){
				case "INT":
					results.add(String.valueOf(resultSet.getLong(1)));
					break;
				case "SMALLINT":
					results.add(String.valueOf(resultSet.getLong(1)));
					break;						
				case "VARCHAR": case "NVARCHAR": case "DATETIMEOFFSET": case "UNIQUEIDENTIFIER":
					results.add(resultSet.getString(1));
					break;
				case "BIT":
					results.add(String.valueOf(resultSet.getInt(1)));
				}						
			}
			return results;
		}catch(Throwable t){
			log.info("MsSqlConnectionUtil : Exception occured while establishing the MS SQL connection. " + t);	
			return results;
		}finally{
			con.close();
			statement.close();
			resultSet.close();		
		}

	}

	public static ArrayList<String> getFacility(String dataBase,String sql) throws SQLException{
		Connection con = null;			
		ResultSet rs = null;
		ArrayList<String> facility=new ArrayList<>();
		try{
			con = MsSqlConnect.getConnection(dataBase);
			PreparedStatement ps=con.prepareStatement(sql);
			rs=ps.executeQuery();		

			if(rs.next()){					
				facility.add(rs.getString("FacilityId").toLowerCase());
				facility.add(rs.getString("Name"));
			}

		}catch(Throwable t){
			log.info("MsSqlConnectionUtil : Exception occured while establishing the MS SQL connection. " + t);	

		}finally{
			con.close();				
		}
		return facility;		

	}
	public static ArrayList<String> getVisitIdentifierTypes(String dataBase,String sql) throws SQLException{
		Connection con = null;			
		ResultSet rs = null;
		ArrayList<String> types=new ArrayList<>();
		try{
			con = MsSqlConnect.getConnection(dataBase);
			PreparedStatement ps=con.prepareStatement(sql);
			rs=ps.executeQuery();		

			if(rs.next()){
				types.add(rs.getString("Account"));
				types.add(rs.getString("Patient"));
				types.add(rs.getString("Visit"));
			}

		}catch(Throwable t){
			log.info("MsSqlConnectionUtil : Exception occured while establishing the MS SQL connection. " + t);	

		}finally{
			con.close();				
		}
		return types;		

	}

	public static ArrayList<String> getEmployeeDetails(String dataBase,String sql) throws SQLException{
		Connection con = null;			
		ResultSet rs = null;
		ArrayList<String> details=new ArrayList<>();
		try{
			con = MsSqlConnect.getConnection(dataBase);
			PreparedStatement ps=con.prepareStatement(sql);
			rs=ps.executeQuery();		

			if(rs.next()){
				details.add(rs.getString("EmployeeId").toLowerCase());
				details.add(rs.getString("FirstName"));
				details.add(rs.getString("LastName"));
			}

		}catch(Throwable t){
			log.info("MsSqlConnectionUtil : Exception occured while establishing the MS SQL connection. " + t);	

		}finally{
			con.close();				
		}
		return details;		

	}
}
