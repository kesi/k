package com.ipas.hf.azureutilities;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.microsoft.azure.cosmosdb.ConnectionPolicy;
import com.microsoft.azure.cosmosdb.ConsistencyLevel;
import com.microsoft.azure.cosmosdb.DataType;
import com.microsoft.azure.cosmosdb.Database;
import com.microsoft.azure.cosmosdb.Document;
import com.microsoft.azure.cosmosdb.DocumentClientException;
import com.microsoft.azure.cosmosdb.DocumentCollection;
import com.microsoft.azure.cosmosdb.FeedOptions;
import com.microsoft.azure.cosmosdb.FeedResponse;
import com.microsoft.azure.cosmosdb.IncludedPath;
import com.microsoft.azure.cosmosdb.Index;
import com.microsoft.azure.cosmosdb.IndexingPolicy;
import com.microsoft.azure.cosmosdb.PartitionKeyDefinition;
import com.microsoft.azure.cosmosdb.RequestOptions;
import com.microsoft.azure.cosmosdb.ResourceResponse;
import com.microsoft.azure.cosmosdb.internal.HttpConstants;
import com.microsoft.azure.cosmosdb.rx.AsyncDocumentClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.json.Json;

import rx.Observable;
import rx.Scheduler;
import rx.schedulers.Schedulers;
import com.azure.cosmos.CosmosClient;
import com.azure.cosmos.CosmosContainer;
import com.azure.cosmos.CosmosDatabase;
import com.azure.cosmos.CosmosException;
import com.azure.cosmos.implementation.Utils;
import com.azure.cosmos.models.CosmosContainerProperties;
import com.azure.cosmos.models.CosmosContainerResponse;
import com.azure.cosmos.models.CosmosDatabaseResponse;
import com.azure.cosmos.models.CosmosItemRequestOptions;
import com.azure.cosmos.models.CosmosQueryRequestOptions;
import com.azure.cosmos.models.PartitionKey;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.gson.Gson;
import com.ipas.hf.azureutilities.TodoItem;
import com.microsoft.azure.cosmosdb.Document;
import com.microsoft.azure.cosmosdb.FeedOptions;
import com.microsoft.azure.cosmosdb.rx.AsyncDocumentClient;

import rx.Observable;
import rx.Scheduler;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;

import org.json.JSONObject;

public class DocDbDao implements TodoDao {
	
	public DocDbDao() {
		executorService = Executors.newFixedThreadPool(100);
		scheduler = Schedulers.from(executorService);
		setClient(new AsyncDocumentClient.Builder()
				.withServiceEndpoint("https://ipasqa-patient-cosmos-db.documents.azure.com:443/")
				.withMasterKeyOrResourceToken(
						"anAbRiNBDRQBpCOhbioVFajlCWFdyxyiWk4p3tTIJsKLVOs1finuCROWmSjO8BlMQZl2Wv3HdgxKma2zoKSnVA==")
				.withConnectionPolicy(ConnectionPolicy.GetDefault()).withConsistencyLevel(ConsistencyLevel.Eventual)
				.build());

	}

	private final ExecutorService executorService;
	private final Scheduler scheduler;
	// The name of our database.
	private static final String DATABASE_ID = "TestDB";

	// The name of our collection.
	private static final String CONTAINER_ID = "TestCollection";

	// We'll use Gson for POJO <=> JSON serialization for this example.
	private static Gson gson = new Gson();

	// The Cosmos DB Client
	private static CosmosClient cosmosClient = CosmosClientFactory.getCosmosClient();

	// The Cosmos DB database
	private static CosmosDatabase cosmosDatabase = null;

	// The Cosmos DB container
	private static CosmosContainer cosmosContainer = null;

	// For POJO/JsonNode interconversion
	private static final ObjectMapper OBJECT_MAPPER = Utils.getSimpleObjectMapper();
	
	//For private client
	private AsyncDocumentClient client;

	@Override
	public TodoItem createTodoItem(TodoItem todoItem) {
		// Serialize the TodoItem as a JSON Document.

		JsonNode todoItemJson = OBJECT_MAPPER.valueToTree(todoItem);

		((ObjectNode) todoItemJson).put("entityType", "todoItem");

		try {
			// Persist the document using the DocumentClient.
			todoItemJson = getContainerCreateResourcesIfNotExist().createItem(todoItemJson).getItem();
		} catch (CosmosException e) {
			System.out.println("Error creating TODO item.\n");
			e.printStackTrace();
			return null;
		}

		try {

			return OBJECT_MAPPER.treeToValue(todoItemJson, TodoItem.class);
			// return todoItem;
		} catch (Exception e) {
			System.out.println("Error deserializing created TODO item.\n");
			e.printStackTrace();

			return null;
		}

	}

	@Override
	public TodoItem readTodoItem(String id) {
		// Retrieve the document by id using our helper method.
		JsonNode todoItemJson = getDocumentById(id);

		if (todoItemJson != null) {
			// De-serialize the document in to a TodoItem.
			try {
				return OBJECT_MAPPER.treeToValue(todoItemJson, TodoItem.class);
			} catch (JsonProcessingException e) {
				System.out.println("Error deserializing read TODO item.\n");
				e.printStackTrace();

				return null;
			}
		} else {
			return null;
		}
	}

	@Override
	public List<TodoItem> readTodoItems() {
		return null;

		
	}

	@Override
	public TodoItem updateTodoItem(String id, boolean isComplete) {
		// Retrieve the document from the database
		JsonNode todoItemJson = getDocumentById(id);

		// You can update the document as a JSON document directly.
		// For more complex operations - you could de-serialize the document in
		// to a POJO, update the POJO, and then re-serialize the POJO back in to
		// a document.
		((ObjectNode) todoItemJson).put("complete", isComplete);

		try {
			// Persist/replace the updated document.
			todoItemJson = getContainerCreateResourcesIfNotExist()
					.replaceItem(todoItemJson, id, new PartitionKey(id), new CosmosItemRequestOptions()).getItem();
		} catch (CosmosException e) {
			System.out.println("Error updating TODO item.\n");
			e.printStackTrace();
			return null;
		}

		// De-serialize the document in to a TodoItem.
		try {
			return OBJECT_MAPPER.treeToValue(todoItemJson, TodoItem.class);
		} catch (JsonProcessingException e) {
			System.out.println("Error deserializing updated item.\n");
			e.printStackTrace();

			return null;
		}
	}

	@Override
	public boolean deleteTodoItem(String id) {
		// CosmosDB refers to documents by self link rather than id.

		// Query for the document to retrieve the self link.
		JsonNode todoItemJson = getDocumentById(id);

		try {
			// Delete the document by self link.
			getContainerCreateResourcesIfNotExist().deleteItem(id, new PartitionKey(id),
					new CosmosItemRequestOptions());
		} catch (CosmosException e) {
			System.out.println("Error deleting TODO item.\n");
			e.printStackTrace();
			return false;
		}

		return true;
	}

	/*
	 * 
	 * private CosmosDatabase getTodoDatabase() { if (databaseCache == null) {
	 * // Get the database if it exists List<CosmosDatabase> databaseList =
	 * cosmosClient .queryDatabases( "SELECT * FROM root r WHERE r.id='" +
	 * DATABASE_ID + "'", null).getQueryIterable().toList();
	 * 
	 * if (databaseList.size() > 0) { // Cache the database object so we won't
	 * have to query for it // later to retrieve the selfLink. databaseCache =
	 * databaseList.get(0); } else { // Create the database if it doesn't exist.
	 * try { CosmosDatabase databaseDefinition = new CosmosDatabase();
	 * databaseDefinition.setId(DATABASE_ID);
	 * 
	 * databaseCache = cosmosClient.createDatabase( databaseDefinition,
	 * null).getResource(); } catch (CosmosException e) { // TODO: Something has
	 * gone terribly wrong - the app wasn't // able to query or create the
	 * collection. // Verify your connection, endpoint, and key.
	 * e.printStackTrace(); } } }
	 * 
	 * return databaseCache; }
	 * 
	 */

	private CosmosContainer getContainerCreateResourcesIfNotExist() {

		try {

			if (cosmosDatabase == null) {
				CosmosDatabaseResponse cosmosDatabaseResponse = cosmosClient.createDatabaseIfNotExists(DATABASE_ID);
				cosmosDatabase = cosmosClient.getDatabase(cosmosDatabaseResponse.getProperties().getId());
			}

		} catch (CosmosException e) {
			// TODO: Something has gone terribly wrong - the app wasn't
			// able to query or create the collection.
			// Verify your connection, endpoint, and key.
			System.out
					.println("Something has gone terribly wrong - " + "the app wasn't able to create the Database.\n");
			e.printStackTrace();
		}

		try {

			if (cosmosContainer == null) {
				CosmosContainerProperties properties = new CosmosContainerProperties(CONTAINER_ID, "/id");
				CosmosContainerResponse cosmosContainerResponse = cosmosDatabase.createContainerIfNotExists(properties);
				cosmosContainer = cosmosDatabase.getContainer(cosmosContainerResponse.getProperties().getId());
			}

		} catch (CosmosException e) {
			// TODO: Something has gone terribly wrong - the app wasn't
			// able to query or create the collection.
			// Verify your connection, endpoint, and key.
			System.out
					.println("Something has gone terribly wrong - " + "the app wasn't able to create the Container.\n");
			e.printStackTrace();
		}

		return cosmosContainer;
	}

	private JsonNode getDocumentById(String id) {
		return null;

		
	}

	

	
	@Override
	public JSONObject getDocByVisitId(String dataBase, String containerId, String id) {
		JSONObject obj = null;
		try {
			FeedOptions options = new FeedOptions();
			// as this is a multi collection enable cross partition query
			options.setEnableCrossPartitionQuery(true);
			// note that setMaxItemCount sets the number of items to return in a
			// single page result
			options.setMaxItemCount(1);
			String continuationToken = "";
			options.setRequestContinuation(continuationToken);
			String sql = "SELECT * FROM c WHERE c.id='" + id + "'";
			
			Observable<com.microsoft.azure.cosmosdb.FeedResponse<Document>> documentQueryObservable = getClient()
					.queryDocuments("dbs/" + dataBase + "/colls/" + containerId, sql, options);
			// observable to an iterator
			Iterator<com.microsoft.azure.cosmosdb.FeedResponse<Document>> it = documentQueryObservable.toBlocking()
					.getIterator();

			int pageCount = 0;
			do {
				com.microsoft.azure.cosmosdb.FeedResponse<Document> page = it.next();
				Document results = page.getResults().get(0);
                obj = new JSONObject(results.toJson());
				continuationToken = page.getResponseContinuation();
			} while (continuationToken != null);

		} catch (Exception e) {

		}
		return obj;
	}

	public AsyncDocumentClient getClient() {
		return client;
	}

	public void setClient(AsyncDocumentClient client) {
		this.client = client;
	}

}