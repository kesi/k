package com.ipas.hf.dbutilities;

import java.sql.Connection;
import java.sql.SQLException;

public abstract class ConnectionUtil {

	protected abstract Connection getConnection(String dataBase) throws SQLException, ClassNotFoundException;

	protected abstract Connection getConnection(String host, String portNumber, String SID, String userID, String Password) throws ClassNotFoundException, SQLException;

	protected abstract void closeDefaultConnection() throws SQLException;

	protected abstract void closeCustomizedConnection(String url, String userID, String Password) throws SQLException;
}