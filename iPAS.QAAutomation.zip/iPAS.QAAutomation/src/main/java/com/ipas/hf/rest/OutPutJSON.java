package com.ipas.hf.rest;

import java.io.FileWriter;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.MultiPartSpecification;
import io.restassured.specification.QueryableRequestSpecification;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.SpecificationQuerier;

public class OutPutJSON {
	private static OutPutJSON outPutJSON = null;
	private static String testName = null;

	private OutPutJSON() {

	}

	public void setTestName(String testName) {
		OutPutJSON.testName = testName;

	}

	public static OutPutJSON getinstance() {
		if (outPutJSON == null) {
			outPutJSON = new OutPutJSON();
		}
		return outPutJSON;
	}

	public void flushOPData() {
		String jsonString = generateJSONTestDataString();
		try {
			String opfilePath = System.getProperty("api.output.file");

			try (FileWriter writer = new FileWriter(opfilePath, true)) {
				writer.append(jsonString);
				writer.append(",");
				writer.flush();
			}

		} catch (Exception e) {
			System.out.print("Exception Occured While Writing to API output Test Data File");
			e.printStackTrace();
		}
	}

	private String generateJSONTestDataString() {
		try {
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			Response response = RestActions.getResponseReceived();
			RequestSpecification request = RestActions.getCreatedRequest();
			QueryableRequestSpecification queryable = SpecificationQuerier.query(request);
			JSONArray dataArray = new JSONArray();

			JSONObject parent = new JSONObject();

			parent.put(testName, "");

			if (queryable.getMethod() != null) {

				String method = queryable.getMethod().toUpperCase();

				JSONObject obj = new JSONObject();
				obj.put("request_method", method);
				dataArray.add(obj);

			}
			if (queryable.getAuthenticationScheme() != null) {
				JSONObject object = new JSONObject();
				object.put("authentication_scheme", queryable.getAuthenticationScheme());
				dataArray.add(object);
			}
			if (queryable.getBaseUri() != null) {
				String baseURI = queryable.getBaseUri();

				JSONObject obj = new JSONObject();
				obj.put("baseURI", baseURI);
				dataArray.add(obj);
			}

			if (queryable.getBasePath() != null) {
				String basePath = queryable.getBasePath();

				JSONObject obj = new JSONObject();
				obj.put("basepath", basePath);
				dataArray.add(obj);
			}

			if (queryable.getURI() != null) {

				JSONObject headerObj = new JSONObject();
				headerObj.put("endpoint_URL", queryable.getURI());
				dataArray.add(headerObj);
			}

			if (queryable.getHeaders() != null) {
				List<Header> headers = queryable.getHeaders().asList();
				JSONObject object = new JSONObject();
				for (Header header : headers) {
					object.put(header.getName(), header.getValue());
				}
				JSONObject headerObj = new JSONObject();
				headerObj.put("request_Headers", object);
				dataArray.add(headerObj);
			}

			if (queryable.getFormParams() != null) {
				Map<String, String> formParamsMap = queryable.getFormParams();
				JSONObject object = new JSONObject();
				Set<String> keys = formParamsMap.keySet();
				for (String key : keys) {
					object.put(key, formParamsMap.get(key));
				}
				JSONObject fparmas = new JSONObject();
				fparmas.put("form_params", object);
				dataArray.add(fparmas);
			}
			if (queryable.getMultiPartParams() != null) {

				List<MultiPartSpecification> multiPartParams = queryable.getMultiPartParams();
				JSONArray arr = new JSONArray();
				for (MultiPartSpecification mps : multiPartParams) {
					arr.add(mps);

				}
				JSONObject multiPartParamsObj = new JSONObject();
				multiPartParamsObj.put("multipartparams", arr);
				dataArray.add(multiPartParamsObj);

			}
			if (queryable.getNamedPathParams() != null) {
				Map<String, String> namedParamsMap = queryable.getNamedPathParams();
				JSONObject object = new JSONObject();
				Set<String> keys = namedParamsMap.keySet();
				for (String key : keys) {
					object.put(key, namedParamsMap.get(key));
				}
				JSONObject namedParams = new JSONObject();
				namedParams.put("named_path_params", object);
				dataArray.add(namedParams);
			}
			if (queryable.getPathParamPlaceholders() != null) {

				List<String> pathParamHolders = queryable.getPathParamPlaceholders();
				JSONArray arr = new JSONArray();
				for (String pph : pathParamHolders) {
					arr.add(pph);

				}
				JSONObject obj = new JSONObject();
				obj.put("path_param_placeholders", arr);
				dataArray.add(obj);

			}
			if (queryable.getPathParams() != null) {
				Map<String, String> pathParams = queryable.getPathParams();
				JSONObject object = new JSONObject();
				Set<String> keys = pathParams.keySet();
				for (String key : keys) {
					object.put(key, pathParams.get(key));
				}
				JSONObject namedParams = new JSONObject();
				namedParams.put("path_params", object);
				dataArray.add(namedParams);
			}
			if (queryable.getQueryParams() != null) {
				Map<String, String> queryParams = queryable.getQueryParams();
				JSONObject object = new JSONObject();
				Set<String> keys = queryParams.keySet();
				for (String key : keys) {
					object.put(key, queryParams.get(key));
				}
				JSONObject queryParamsObject = new JSONObject();
				queryParamsObject.put("query_params", object);
				dataArray.add(queryParamsObject);
			}
			if (queryable.getRequestParams() != null) {
				Map<String, String> requestParams = queryable.getRequestParams();
				JSONObject object = new JSONObject();
				Set<String> keys = requestParams.keySet();
				for (String key : keys) {
					object.put(key, requestParams.get(key));
				}
				JSONObject requestParamsObject = new JSONObject();
				requestParamsObject.put("request_params", object);
				dataArray.add(requestParamsObject);

			}

			if (queryable.getBody() != null) {

				String body = queryable.getBody().toString();

				JSONObject obj = new JSONObject();
				obj.put("request_body", body);
				dataArray.add(obj);

			}
			if (response.getHeaders() != null) {
				List<Header> headers = response.getHeaders().asList();
				JSONObject object = new JSONObject();
				for (Header header : headers) {
					object.put(header.getName(), header.getValue());
				}
				JSONObject headerObj = new JSONObject();
				headerObj.put("response_Headers", object);
				dataArray.add(headerObj);
			}
			if (response.getBody() != null) {
				JSONObject object = new JSONObject();

				object.put("response_body", response.body().asString());
				dataArray.add(object);
			}

			if (response.getTime() != -1) {
				JSONObject object = new JSONObject();
				long respsoneMS = response.getTimeIn(TimeUnit.MILLISECONDS);
				int sec = (int) response.getTimeIn(TimeUnit.SECONDS);
				long ms = (sec * 1000 - respsoneMS);
				object.put("response_time", (sec + "s" + ":" + ms + "m").replace("-", ""));
				dataArray.add(object);
			}
			if (response.getStatusCode() != -1 && response.getStatusLine() != null) {
				JSONObject object = new JSONObject();
				object.put("response_status_code_line", response.getStatusCode() + " " + response.getStatusLine());
				dataArray.add(object);
			}

			parent.put(testName, dataArray);

			String jsonString = gson.toJson(parent);

			return jsonString;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";

	}
}

