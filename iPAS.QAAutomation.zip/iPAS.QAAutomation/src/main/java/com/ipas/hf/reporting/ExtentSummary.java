package com.ipas.hf.reporting;

import java.util.HashMap;
import java.util.Map;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentSummary {

	private static ExtentReports reports;

	private static Map<Long, ExtentTest> summaryTestMap = new HashMap<Long, ExtentTest>();

	public static void createSummaryInstance() {
		String reportDirectory = System.getProperty("extent.Report.Directory");
		ExtentHtmlReporter reporter = new ExtentHtmlReporter(reportDirectory + "\\Summary.html");
		reporter.config().setReportName("Execution Summary Report");
		reporter.config().setTheme(Theme.DARK);
		reporter.config().setDocumentTitle("Automation Execution Summary Report");
		reporter.setAppendExisting(true);
		reports = new ExtentReports();
		reports.attachReporter(reporter);
	}

	public static ExtentReports getSummaryInstance() {
		return reports;
	}

	public static void createTest(String reportFileName, String category) {
		String testCaseName = reportFileName.replace(".html", "");
		ExtentTest test = reports.createTest(testCaseName).assignCategory(category);
		summaryTestMap.put(Thread.currentThread().getId(), test);
	}

	public static ExtentTest getTest() {
		return summaryTestMap.get(Thread.currentThread().getId());
	}

	public static void logFailTest(String name) {
		ExtentTest test = getTest();
		String testCaseName = name;
		String reportFileName = name + ".html";
		test.log(Status.FAIL, "<a href='" + reportFileName
				+ "' target=\"_blank\" style=\"text - decoration: underline; \" class=\"label white-text red\" >"
				+ testCaseName + "</a>");
	}

	public static void logPassTest(String name) {
		ExtentTest test = getTest();
		String testCaseName = name;
		String reportFileName = name + ".html";
		test.log(Status.PASS, "<a href='" + reportFileName
				+ "' target=\"_blank\" style=\"text - decoration: underline; \" class=\"label white-text green\" >"
				+ testCaseName + "</a>");
	}

	public static void flushSummaryReport() {
		if (reports != null) {
			reports.flush();
			summaryTestMap.remove(Thread.currentThread().getId());
		}
	}


}
