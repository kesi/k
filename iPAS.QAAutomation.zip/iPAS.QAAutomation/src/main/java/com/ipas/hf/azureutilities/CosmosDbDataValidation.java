package com.ipas.hf.azureutilities;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.util.ArrayList;
import java.util.Random;

import org.json.JSONObject;
import org.json.simple.JSONArray;

import com.ipas.hf.dbutilities.SqlQueries;
import com.ipas.hf.reporting.ReportLibrary;
import com.ipas.hf.rest.RestActions;

public class CosmosDbDataValidation {
	private ReportLibrary report = new ReportLibrary();
	RestActions rest=new RestActions();


	//List to Notepad Write
	public static void notepadWrite(String filename,ArrayList<String> appoint) 
	{
		try
		{				
			String filepath=System.getProperty("user.dir")+"\\ExternalTestData\\"+filename+".txt";
			File file = new File(filepath);
			file.createNewFile();
			FileWriter fw = new FileWriter(file);
			BufferedWriter writer = new BufferedWriter(fw);
			for(String str: appoint) {
				writer.write(str + System.lineSeparator());
			}

			writer.flush();
			writer.close();				
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}

	}
	//Notepad Read to List

	public static ArrayList<String> notepadReadToList(String notepadname) throws IOException
	{
		ArrayList<String> listOfLines = new ArrayList<>();
		String filename=System.getProperty("user.dir")+"\\ExternalTestData\\"+notepadname+".txt";
		BufferedReader bufReader = new BufferedReader(new FileReader(filename));
		try {

			String line = bufReader.readLine();
			while (line != null) 
			{
				listOfLines.add(line.trim());
				line = bufReader.readLine(); 
			} 	 

		} finally {
			bufReader.close();
		}
		return listOfLines;
	}

	public String replaceAll(String input){
		return input.replaceAll("[\\[\\]\"]", "");
	}
	/**
	 * To compare two array list elements 
	 * @param actData
	 * @param expData
	 * @return the unmatched elements
	 * @throws Exception
	 */
	public ArrayList<String> getUmatchedInArrayComparision(ArrayList<String> actData, ArrayList<String> expData) throws Exception
	{
		ArrayList<String> UnmatchedArray = new ArrayList<String>();
		if(actData!=null && expData!=null &&actData.size()>0&&expData.size()>0 && actData.size()==expData.size()){
			for(int data=0;data<actData.size();data++)
			{
				if(!((actData.get(data)).contains(expData.get(data))))
					UnmatchedArray.add(actData.get(data));	
			}
		}
		else{
			throw new Exception("Arrya Sizes are not matched");
		}
		return UnmatchedArray;			
	}
	public static String getRandomString(int length){
		String alphabet = "abcdefghijklmnopqrstuvwxyz";
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		for(int i = 0; i < length; i++) {
			int index = random.nextInt(alphabet.length());
			char randomChar = alphabet.charAt(index);
			sb.append(randomChar);
		}
		String randomString = sb.toString();
		return randomString;
	}
	//Notepad Read

	public static String notepadRead(String notepadname) throws IOException
	{
		String filename=System.getProperty("user.dir")+"\\ExternalTestData\\"+notepadname+".txt";
		BufferedReader br = new BufferedReader(new FileReader(filename));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append("\n");
				line = br.readLine();
			}
			return sb.toString();
		} finally {
			br.close();
		}
	}

	//Notepad Write

	public static void notepadWrite(String filename,String subjectmessage) 
	{
		try
		{
			String verify, putData;
			String filepath=System.getProperty("user.dir")+"\\ExternalTestData\\"+filename+".txt";
			File file = new File(filepath);
			file.createNewFile();
			FileWriter fw = new FileWriter(file);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(subjectmessage);
			bw.flush();
			bw.close();
			FileReader fr         = new FileReader(file);
			BufferedReader br     = new BufferedReader(fr);
			while( br.readLine() != null )
			{
				verify = br.readLine();
				if(verify != null)
				{
					putData = verify.replaceAll("here", "there");
					bw.write(putData);
				}
			}
			br.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}

	}
	public void getAppointmentIdFromCosmosDB(String dataBase,String containerId,String id){
		try {
			ArrayList<String> appoint=new ArrayList<>();
			org.json.JSONObject appointment = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Appointment");				
			String appointmentID = (String) appointment.get("AppointmentId");
			String AppointmentReason = (String) appointment.get("AppointmentReason");
			appoint.add(appointmentID);
			appoint.add(AppointmentReason);
			notepadWrite("hello",appoint);
			//Thread.sleep(2000);
			//ArrayList<String> appo=notepadReadToList("hello");					
			report.reportInfo("SIU appointment objects: "+appoint);

		} catch (Exception e) {					
			report.reportFail(e.getMessage());
		}
	}

	public void verifyAppointmentduration(String dataBase,String containerId,String id){
		try {					
			org.json.JSONObject appointment = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Appointment");
			String cosmosAppointmentDuration = (String) appointment.get("AppointmentDuration");
			report.reportInfo("Cosmos"+ cosmosAppointmentDuration);
			String expAppointmentDuration=notepadRead("hello").trim();
			report.reportInfo("Expected"+ expAppointmentDuration);

			org.json.JSONArray transaction =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("Transaction");
			int arraySize=transaction.length();
			report.reportInfo("Transaction array size "+ arraySize);	

			if(cosmosAppointmentDuration.trim().contentEquals(expAppointmentDuration) && arraySize>1){						
				report.reportPass("Appointment duration is updated and doc version is increased",false);
			}
			else{						
				report.reportFail("Fail to update the Appointment duration and actual displayed duration is : " +cosmosAppointmentDuration,false);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}				
	}

	public String getPatientVisitIdFromResponse(){
		String patientVisitId="";
		try {
			patientVisitId = rest.getStringValueFromResponse("$..patientVisitId");		
			patientVisitId=replaceAll(patientVisitId);		
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return patientVisitId;
	}
	public String getFacilityIdFromResponse(){
		String facilityId="";
		try {
			facilityId = rest.getStringValueFromResponse("$..facilityId");		
			facilityId=replaceAll(facilityId);		
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return facilityId;
	}
	public String getFacilityCodeFromResponse(){
		String facilityCode="";
		try {
			facilityCode = rest.getStringValueFromResponse("$..facilityCode");		
			facilityCode=replaceAll(facilityCode);		
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return facilityCode;
	}
	public String getTenantIDFromResponse(){
		String tenantID="";
		try {
			tenantID = rest.getStringValueFromResponse("$..tenantId");		
			tenantID=replaceAll(tenantID);		
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return tenantID;
	}
	public String getOperatorIDFromResponse(){
		String employeeId="";
		try {
			employeeId = rest.getStringValueFromResponse("$..employeeId");		
			employeeId=replaceAll(employeeId);		
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return employeeId;
	}
	public String getPointOfCareCodeFromResponse(){
		String pcc="";
		try {
			pcc = rest.getStringValueFromResponse("$..pointofCareCode");		
			pcc=replaceAll(pcc);		
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return pcc;
	}
	public String getPrimaryInsurancePlanIdFromResponse(){
		String insuranceId="";
		try {
			insuranceId = rest.getStringValueFromResponse("$..insurancePlanId");		
			insuranceId=replaceAll(insuranceId);		
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return insuranceId;
	}
	public String getVisitDischargeDateFromResponse(){
		String dsichargeDate="";
		try {
			dsichargeDate = rest.getStringValueFromResponse("$..visitDischargeDate");		
			dsichargeDate=replaceAll(dsichargeDate);
			report.reportInfo("discharge date from response: "+dsichargeDate);
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return dsichargeDate;
	}
	public   ArrayList<String> readPatientInfoFromCosmos(String dataBase,String containerId,String id){
		ArrayList<String> patientInfo=new ArrayList<>();
		try {

			org.json.JSONObject patient = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Patient");				
			String firstName = (String) patient.get("PatientFirstName");
			String lastName = (String) patient.get("PatientLastName");
			/*String dob = (String) patient.get("PatientDateOfBirth");
				String patientDob[]=dob.split("T");
				String patientDateOfBirth=patientDob[0];
				org.json.JSONObject gender=(JSONObject) patient.get("PatientGender");
				String genderCode=(String) gender.get("GenderCode");*/
			String email=(String) patient.get("PatientEmailAddress");
			org.json.JSONArray address = (org.json.JSONArray)	patient.get("PatientAddress");
			org.json.JSONObject patientAddress =(JSONObject) address.get(0);
			String city=(String) patientAddress.get("City");

			org.json.JSONObject appointment = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Appointment");				
			String	appointmentID = (String) appointment.get("AppointmentId");

			patientInfo.add(firstName);
			patientInfo.add(lastName);				
			patientInfo.add(email);
			patientInfo.add(city);
			patientInfo.add(appointmentID);

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return patientInfo;
	}

	public int getTransactionArraySize(String dataBase,String containerName,String id){
		int arraySize=0;
		try {
			org.json.JSONArray transaction =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).getJSONArray("Transaction");
			arraySize=transaction.length();
			report.reportInfo("Transaction array size "+ arraySize);
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return arraySize ;
	}
	public void verifyPatientInformation(String dataBase,String containerName,String id){
		try {
			ArrayList<String> patientInfo=readPatientInfoFromCosmos(dataBase, containerName, id);				
			ArrayList<String> expPatientInfo=notepadReadToList("hello");
			report.reportInfo("Patient information from current document: "+ patientInfo);
			report.reportInfo("Patient information from input document: "+ expPatientInfo);
			ArrayList<String>unmatchedPatientInfo=getUmatchedInArrayComparision(patientInfo, expPatientInfo);
			int arraySize=getTransactionArraySize(dataBase, containerName, id);

			if(unmatchedPatientInfo.size()==0 && arraySize>1){
				report.reportPass("Verified patient information successfully",false);
			}
			else{
				throw new Exception("Fail to verify patient information and unmatched fields are: "+unmatchedPatientInfo);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public   String readPatientContactInfoFromCosmos(String dataBase,String containerId,String id){
		String contactFirstName="";
		try {				
			org.json.JSONArray patientContact =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("PatientContact");		
			org.json.JSONObject contact=(JSONObject) patientContact.get(1);
			contactFirstName=(String) contact.get("ContactFirstName");			

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return contactFirstName;
	}
	public void verifyPatientContactInformation(String dataBase,String containerName,String id){
		try {
			String patientContactInfo=readPatientContactInfoFromCosmos(dataBase, containerName, id);
			String expPatientContactInfo=notepadRead("hello");
			report.reportInfo("Patient information from current document: "+ patientContactInfo);
			report.reportInfo("Patient information from input document: "+ expPatientContactInfo);

			if(patientContactInfo.trim().contentEquals(expPatientContactInfo.trim())){
				report.reportPass("Verified patient contact information successfully",false);
			}
			else{
				throw new Exception("Fail to verify patient contact information and unmatched fields are: "+patientContactInfo);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public   String readAdmittingVisitProviderInfoFromCosmos(String dataBase,String containerId,String id){
		String providerLastName="";
		try {				
			org.json.JSONObject visit = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Visit");	
			org.json.JSONArray visitProvider=(org.json.JSONArray) visit.get("VisitProvider");
			org.json.JSONObject admittingProvider=(JSONObject) visitProvider.get(3);
			providerLastName=(String) admittingProvider.get("ProviderLastName");

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return providerLastName;
	}
	public void verifyAdmittingVisitProviderInformation(String dataBase,String containerName,String id){
		try {
			String admittingVisitProviderLastName=readAdmittingVisitProviderInfoFromCosmos(dataBase, containerName, id);
			String expadmittingVisitProviderLastName=notepadRead("hello");
			report.reportInfo("Visit Provider information from current document: "+ admittingVisitProviderLastName);
			report.reportInfo("Visit Provider information from input document: "+ expadmittingVisitProviderLastName);

			if(admittingVisitProviderLastName.trim().contentEquals(expadmittingVisitProviderLastName.trim())){
				report.reportPass("Verified visit provider information successfully",false);
			}
			else{
				throw new Exception("Fail to verify visit provider information and unmatched fields are: "+admittingVisitProviderLastName);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public String getInsuranceIdFromResponse(){
		String insuranceId="";
		try {
			insuranceId = rest.getStringValueFromResponse("$..insuranceId");		
			insuranceId=replaceAll(insuranceId);		
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return insuranceId;
	}
	public String getGuarantorIdFromResponse(){
		String guarantorId="";
		try {
			guarantorId = rest.getStringValueFromResponse("$..guarantorId");		
			guarantorId=replaceAll(guarantorId);		
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return guarantorId;
	}
	public  ArrayList<String> readInsuranceGuarantorIdsFromCosmos(String dataBase,String containerId,String id){
		ArrayList<String> Ids=new ArrayList<>();
		try {
			org.json.JSONArray insuranceArr =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("Insurance");		
			org.json.JSONObject insuarnce=(JSONObject) insuranceArr.get(0);
			String insuranceId=(String) insuarnce.get("InsuranceId");
			org.json.JSONArray guarantorArr =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("Guarantor");		
			org.json.JSONObject guarantor=(JSONObject) guarantorArr.get(0);
			String guarantorId=(String) guarantor.get("GuarantorId");
			Ids.add(insuranceId.trim());
			Ids.add(guarantorId.trim());

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return Ids;
	}
	public void verifyInsuranceGuarantorIds(String dataBase,String containerName,String id){
		try {
			ArrayList<String> cosmosInsuranceGuarantorIds=readInsuranceGuarantorIdsFromCosmos(dataBase, containerName, id);
			ArrayList<String> responseInsuranceGuarantorIds=notepadReadToList("hello");
			report.reportInfo("Insurance and Guarantor Ids from current document: "+ cosmosInsuranceGuarantorIds);
			report.reportInfo("Insurance and Guarantor Ids from response: "+ responseInsuranceGuarantorIds);
			ArrayList<String>unmatchedInfo=getUmatchedInArrayComparision(cosmosInsuranceGuarantorIds, responseInsuranceGuarantorIds);
			if(unmatchedInfo.size()==0){
				report.reportPass("Verified insurance and guarantorIds successfully",false);
			}
			else{
				throw new Exception("Fail to verify insurance and guarantorIds and unmatched fields are: "+unmatchedInfo);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public   String readInsuredAddressInfoFromCosmos(String dataBase,String containerId,String id){
		String insuredAddress="";
		try {				
			org.json.JSONArray insurance = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("Insurance");	
			org.json.JSONObject insu=(JSONObject) insurance.get(0);
			org.json.JSONObject insured=	(JSONObject) insu.get("Insured");
			org.json.JSONObject insuredAdd=	(JSONObject) insured.get("InsuredAddress");
			insuredAddress=(String) insuredAdd.get("City");
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return insuredAddress;
	}
	public   String readGuarantorInfoFromCosmos(String dataBase,String containerId,String id){
		String guarantorSpouseName="";
		try {				
			org.json.JSONArray guarantor = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("Guarantor");	
			org.json.JSONObject guaran=(JSONObject) guarantor.get(0);
			guarantorSpouseName=(String) guaran.get("GuarantorSpouseFirstName");				
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return guarantorSpouseName;
	}
	public String readClaimOccuranceCodeFromCosmos(String dataBase,String containerId,String id){
		String OccuranceCode="";
		try {				
			org.json.JSONArray claim = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("ClaimOccurance");	
			org.json.JSONObject occurance=(JSONObject) claim.get(0);
			OccuranceCode=(String) occurance.get("OccuranceCode");				
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return OccuranceCode;
	}
	public   String readAccidentCodeFromCosmos(String dataBase,String containerId,String id){
		String accidentCode="";
		try {				
			org.json.JSONObject acci = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Accident");					
			accidentCode=(String) acci.get("AccidentCode");				
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return accidentCode;
	}
	public  String readObservationTypeFromCosmos(String dataBase,String containerId,String id){
		String type="";
		try {				
			org.json.JSONArray observation = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("Observation");
			org.json.JSONObject obser=(JSONObject) observation.get(0);
			type=(String) obser.get("ObservationType");				
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return type;
	}
	public  String readProcedureTypeFromCosmos(String dataBase,String containerId,String id){
		String proceduretype="";
		try {				
			org.json.JSONArray proced = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("Procedure");
			org.json.JSONObject proc=(JSONObject) proced.get(0);
			proceduretype=(String) proc.get("ProcedureType");				
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return proceduretype;
	}
	public  String readDRGFromCosmos(String dataBase,String containerId,String id){
		String drgg="";
		try {				
			org.json.JSONArray drg = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("DRG");
			org.json.JSONObject dr=(JSONObject) drg.get(0);
			drgg=(String) dr.get("DRG");				
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return drgg;
	}
	public  String readVisitProviderFromCosmos(String dataBase,String containerId,String id){
		String providerLastName="";
		try {				
			org.json.JSONObject visit = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Visit");
			org.json.JSONArray visitProvider =(org.json.JSONArray) visit.get("VisitProvider");
			org.json.JSONObject provider =(JSONObject) visitProvider.get(3);
			providerLastName=(String) provider.get("ProviderLastName");
			
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return providerLastName;
	}
	public  String readDiagnosisNameFromCosmos(String dataBase,String containerId,String id){
		String diagName="";
		try {				
			org.json.JSONArray diagnosis = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("Diagnosis");
			org.json.JSONObject diag=(JSONObject) diagnosis.get(0);
			org.json.JSONObject diagDescription=(JSONObject) diag.get("DiagnosisDescription");
			diagName=(String) diagDescription.get("DiagnosisName");
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return diagName;
	}
	public   ArrayList<String> readPatientIdentifiersFromCosmos(String dataBase,String containerId,String id){
		ArrayList<String> visitMatch=new ArrayList<>();
		try 
		{	

			org.json.JSONObject patient =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Patient");		
			org.json.JSONArray identifiers=(org.json.JSONArray) patient.get("TenantPatientIdentifier");
			org.json.JSONObject mr=(JSONObject) identifiers.get(0);
			String mrID=(String) mr.get("TenantPatientId");				
			org.json.JSONObject epi=(JSONObject) identifiers.get(3);
			String epiID=(String) epi.get("TenantPatientId");

			org.json.JSONObject appointment = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Appointment");				
			String appointmentID =(String) appointment.get("AppointmentId");					

			org.json.JSONObject visit = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Visit");
			String accountNumber = (String) visit.get("AccountNumber");
			String visitNumber = (String) visit.get("VisitNumber");
			String date = (String) visit.get("VisitDate");				
			//String visitDate=date.substring(0,19);
			String firstName = (String) patient.get("PatientFirstName");
			String lastName = (String) patient.get("PatientLastName");				
			String email=(String) patient.get("PatientEmailAddress");
			org.json.JSONArray address = (org.json.JSONArray)	patient.get("PatientAddress");
			org.json.JSONObject patientAddress =(JSONObject) address.get(0);
			String city=(String) patientAddress.get("City");

			visitMatch.add(mrID);				
			visitMatch.add(epiID);
			visitMatch.add(appointmentID);
			visitMatch.add(accountNumber);
			visitMatch.add(visitNumber);
			visitMatch.add(date);
			visitMatch.add(firstName);
			visitMatch.add(lastName);
			visitMatch.add(email);
			visitMatch.add(city);			

			notepadWrite("hello", visitMatch);
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return visitMatch;
	}
	public void verifyInsuranceInformation(String dataBase,String containerName,String id){
		try {
			String insuredAddress=readInsuredAddressInfoFromCosmos(dataBase, containerName, id);
			String expinsuredAddress=notepadRead("hello");
			report.reportInfo("Insured address from current document: "+ insuredAddress);
			report.reportInfo("Insured address from input document: "+ expinsuredAddress);

			if(insuredAddress.trim().contentEquals(expinsuredAddress.trim())){
				report.reportPass("Verified insured address information successfully",false);
			}
			else{
				throw new Exception("Fail to verify insured information and unmatched fields are: "+insuredAddress);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}

	public void verifyFacilityPayerMasterId(String dataBase,String containerName,String id){
		try {
			String insurancePlanId=getPrimaryInsurancePlanIdFromResponse();
			String facilityId=getFacilityIdFromResponse();
			String payerMasterId=SqlQueries.getFacilityPayerMasterId(facilityId, insurancePlanId);
			org.json.JSONArray insurance = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).getJSONArray("Insurance");	
			org.json.JSONObject insu=(JSONObject) insurance.get(0);
			String cosmosPayerMasterId=(String) insu.get("FacilityPayerMasterId");
			report.reportInfo("FacilityPayerMasterId from SQL: " +payerMasterId );
			report.reportInfo("FacilityPayerMasterId from CurrentDocument: " +cosmosPayerMasterId );
			if(payerMasterId.trim().equalsIgnoreCase(cosmosPayerMasterId.trim())){
				report.reportPass("Verified facility payermasterId successfully",false);
			}
			else{
				throw new Exception("Fail to verify facility payermasterId and unmatched fields are: "+cosmosPayerMasterId);
			}

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}

	public void verifyGuarantorInformation(String dataBase,String containerName,String id){
		try {
			String guarantorSpouseName=readGuarantorInfoFromCosmos(dataBase, containerName, id);
			String expguarantorSpouseName=notepadRead("hello");
			report.reportInfo("Guarantor Spouse first Name from current document: "+ guarantorSpouseName);
			report.reportInfo("Guarantor Spouse first Name from input document: "+ expguarantorSpouseName);

			if(guarantorSpouseName.trim().contentEquals(expguarantorSpouseName.trim())){
				report.reportPass("Verified Guarantor Spouse first Name successfully",false);
			}
			else{
				throw new Exception("Fail to verify Guarantor Spouse first Name and unmatched fields are: "+guarantorSpouseName);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}

	public void verifyClaimOccuranceInformation(String dataBase,String containerName,String id){
		try {
			String OccuranceCode=readClaimOccuranceCodeFromCosmos(dataBase, containerName, id);
			String expOccuranceCode=notepadRead("hello");
			report.reportInfo("Claim Occurance Code from current document: "+ OccuranceCode);
			report.reportInfo("Claim Occurance Code from input document: "+ expOccuranceCode);

			if(OccuranceCode.trim().contentEquals(expOccuranceCode.trim())){
				report.reportPass("Verified Claim Occurance Code successfully",false);
			}
			else{
				throw new Exception("Fail to verify Claim Occurance Code and unmatched fields are: "+OccuranceCode);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public void verifyAccidentInformation(String dataBase,String containerName,String id){
		try {
			String accidentCode=readAccidentCodeFromCosmos(dataBase, containerName, id);
			String expAccidentCode=notepadRead("hello");
			report.reportInfo("AccidentCode from current document: "+ accidentCode);
			report.reportInfo("AccidentCode from input document: "+ expAccidentCode);

			if(accidentCode.trim().contentEquals(expAccidentCode.trim())){
				report.reportPass("Verified AccidentCode successfully",false);
			}
			else{
				throw new Exception("Fail to verify AccidentCode and unmatched fields are: "+accidentCode);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public void verifyObservationInformation(String dataBase,String containerName,String id){
		try {
			String ObservationType=readObservationTypeFromCosmos(dataBase, containerName, id);
			String expType=notepadRead("hello");
			report.reportInfo("ObservationType from current document: "+ ObservationType);
			report.reportInfo("ObservationType from input document: "+ expType);

			if(ObservationType.trim().contentEquals(expType.trim())){
				report.reportPass("Verified observationType successfully",false);
			}
			else{
				throw new Exception("Fail to verify observationType and unmatched fields are: "+ObservationType);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public void verifyDRGInformation(String dataBase,String containerName,String id){
		try {
			String drg=readDRGFromCosmos(dataBase, containerName, id);
			String expdrg=notepadRead("hello");
			report.reportInfo("DRG from current document: "+ drg);
			report.reportInfo("DRG from input document: "+ expdrg);

			if(drg.trim().contentEquals(expdrg.trim())){
				report.reportPass("Verified DRG successfully",false);
			}
			else{
				throw new Exception("Fail to verify DRG and unmatched fields are: "+drg);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public void verifyDiagnosisInformation(String dataBase,String containerName,String id){
		try {
			String diagnosisName=readDiagnosisNameFromCosmos(dataBase, containerName, id);
			String expName=notepadRead("hello");
			report.reportInfo("Diagnosis name from current document: "+ diagnosisName);
			report.reportInfo("Diagnosis Name from input document: "+ expName);

			if(diagnosisName.trim().contentEquals(expName.trim())){
				report.reportPass("Verified diagnosisName successfully",false);
			}
			else{
				throw new Exception("Fail to verify diagnosisName and unmatched fields are: "+diagnosisName);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}

	public ArrayList<String> readAllObjectsInformation(String dataBase,String containerName,String id){

		ArrayList<String> otherInfo=new ArrayList<>();
		ArrayList<String> patientInfo=new ArrayList<>();

		try {
			patientInfo=readPatientInfoFromCosmos(dataBase, containerName, id);
			otherInfo.add(readDiagnosisNameFromCosmos(dataBase, containerName, id));
			otherInfo.add(readDRGFromCosmos(dataBase, containerName, id));
			otherInfo.add(readObservationTypeFromCosmos(dataBase, containerName, id));
			otherInfo.add(readProcedureTypeFromCosmos(dataBase, containerName, id));
			otherInfo.add(readAccidentCodeFromCosmos(dataBase, containerName, id));
			otherInfo.add(readClaimOccuranceCodeFromCosmos(dataBase, containerName, id));
			otherInfo.add(readGuarantorInfoFromCosmos(dataBase, containerName, id));
			otherInfo.add(readInsuredAddressInfoFromCosmos(dataBase, containerName, id));
			otherInfo.add(readVisitProviderFromCosmos(dataBase, containerName, id));
			otherInfo.add(readPatientContactInfoFromCosmos(dataBase, containerName, id));
			//otherInfo.add(readAdmittingVisitProviderInfoFromCosmos(dataBase, containerName, id));
		
			patientInfo.addAll(otherInfo);

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return patientInfo;
	}

	public void verifyAllObjectsInformation(String dataBase,String containerName,String id){
		try {
			ArrayList<String> allInfo=readAllObjectsInformation(dataBase, containerName, id);
			ArrayList<String> expInfo=notepadReadToList("hello");
			report.reportInfo("All objects information from current document: "+ allInfo);
			report.reportInfo("All objects information from previous document: "+ expInfo);
			ArrayList<String>unmatchedPatientInfo=getUmatchedInArrayComparision(allInfo, expInfo);
			int arraySize=getTransactionArraySize(dataBase, containerName, id);

			if(unmatchedPatientInfo.size()==0 && arraySize>1){
				report.reportPass("Verified all objects information successfully",false);
			}
			else{
				throw new Exception("Fail to verify objects information and unmatched fields are: "+unmatchedPatientInfo);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}

	public void verifyVisitStatusAndDischargeDate(String dataBase,String containerName,String id){
		try {
			ArrayList<String> actualInfo=new ArrayList<>();
			ArrayList<String> expInfo=new ArrayList<>();
			String status=(String) TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).get("CurrentVisitStatusDescription");
			String statusChange=(String) TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).get("StatusChange");
			org.json.JSONObject visit=TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).getJSONObject("Visit");
			String date=(String) visit.get("VisitDischargeDate");
			//String visitDischargeDtae=(String) date.substring(0, 19);		
			report.reportInfo("VisitDischarge Date : "+ date);
			actualInfo.add(status);
			actualInfo.add(statusChange);
			actualInfo.add(date);
			//org.json.JSONArray transaction =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).getJSONArray("Transaction");
			//org.json.JSONObject event=(JSONObject) transaction.get(1);
			//String eventDate=(String) visit.get("VisitDischargeDate");			
			//String eventDateTime=(String) eventDate.substring(0, 19);
			//report.reportInfo("Visit DischargeDateTime : "+ eventDateTime);
			expInfo.add("Discharged");
			expInfo.add("Yes");			
			expInfo.add(getVisitDischargeDateFromResponse());

			org.json.JSONArray visitStatus =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).getJSONArray("VisitStatus");
			int arraySize=visitStatus.length();
			report.reportInfo("Visit Status array size "+ arraySize);

			ArrayList<String>unmatchedInfo=getUmatchedInArrayComparision(actualInfo, expInfo);			

			if(unmatchedInfo.size()==0 && arraySize>1){
				report.reportPass("Verified visit status and visit discharge date successfully",false);
			}
			else{
				throw new Exception("Fail to verify visit status and visit discharge date and unmatched data are: "+unmatchedInfo);
			}

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}

	public void verifyJSONfields(String dataBase,String containerName,String id){
		try {
			String facilityCode=getFacilityCodeFromResponse();				
			String tenantID=getTenantIDFromResponse();				
			String operatorID=getOperatorIDFromResponse();
			String ponitOfCare=getPointOfCareCodeFromResponse();
			String facilityId=getFacilityIdFromResponse();

			ArrayList<String> facility=SqlQueries.getFacilityDetails(facilityCode,tenantID);				
			String pcc=SqlQueries.getPointOfCareId(ponitOfCare, facilityId);
			facility.add(pcc);		
			ArrayList<String> types=SqlQueries.getIdentifierTypes(facilityCode, tenantID);				
			ArrayList<String> employee=SqlQueries.getiPASEmployeeDetails(operatorID, tenantID);				
			types.addAll(employee);				
			facility.addAll(types);

			ArrayList<String> expJsonFields=new ArrayList<>();		

			expJsonFields.add((String) TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).get("FacilityId"));
			expJsonFields.add((String) TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).get("FacilityName"));
			expJsonFields.add((String) TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).get("PointOfCareId"));
			expJsonFields.add((String) TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).get("PatientAccountIdentifierType"));
			expJsonFields.add((String) TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).get("PatientIdentifierType"));
			expJsonFields.add((String) TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).get("PatientVisitIdentifierType"));
			expJsonFields.add((String) TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).get("iPASEmployeeId"));
			expJsonFields.add((String) TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).get("iPASEmployeeFirstName"));
			expJsonFields.add((String) TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).get("iPASEmployeeLastName"));					

			report.reportInfo("JSON fileds from SQL: " + facility);
			report.reportInfo("JSON fileds from CurrentDocument: " + expJsonFields);
			ArrayList<String>unmatchedInfo=getUmatchedInArrayComparision(facility, expJsonFields);			

			if(unmatchedInfo.size()==0){
				report.reportPass("Verified json populated fields successfully",false);
			}
			else{
				throw new Exception("Fail to verify json populated fields and unmatched data are: "+unmatchedInfo);
			}

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public  ArrayList<String> getVisitStatusFromCurrentDocument(String dataBase,String containerName,String id){
		ArrayList<String> actualInfo=new ArrayList<>();
		try {

			String status=(String) TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).get("CurrentVisitStatusDescription");
			String statusChange=(String) TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).get("StatusChange");
			actualInfo.add(status);
			actualInfo.add(statusChange);
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return actualInfo;
	}

	public int getVisitSatusArraySize(String dataBase,String containerName,String id){
		int arraySize=0;
		try {
			org.json.JSONArray visitStatus =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).getJSONArray("VisitStatus");
			arraySize=visitStatus.length();
			report.reportInfo("Visit Status array size "+ arraySize);

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return arraySize;
	}
	public void verifyVisitStatus(String dataBase,String containerName,String id,String status,String statusChange){
		try {
			ArrayList<String> expInfo=new ArrayList<>();				
			ArrayList<String> actualInfo=getVisitStatusFromCurrentDocument(dataBase, containerName, id);
			expInfo.add(status);
			expInfo.add(statusChange);

			ArrayList<String>unmatchedInfo=getUmatchedInArrayComparision(actualInfo, expInfo);
			int arraySize=getVisitSatusArraySize(dataBase,containerName,id);
			if(statusChange.contentEquals("No")){
				if(unmatchedInfo.size()==0 && arraySize==1){
					report.reportPass("Verified visit status and visitStatus array successfully",false);
				}
			}else if(statusChange.contentEquals("Yes")){
				if(unmatchedInfo.size()==0 && arraySize>1){
					report.reportPass("Verified visit status and visitStatus array successfully",false);
				}
			}			
			else{
				throw new Exception("Fail to verify visit status and visitStatus array and unmatched data are: "+unmatchedInfo);
			}

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public void verifyVisitStatusExpiry(String dataBase,String containerName,String id){
		try {
			org.json.JSONArray visitStatus =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).getJSONArray("VisitStatus");
			org.json.JSONObject prevStatus=(JSONObject) visitStatus.get(0);
			String expiry=(String) prevStatus.get("ExpirationDate");
			String previousExpiryDate=expiry.substring(0, 19);
			org.json.JSONObject currentStatus=(JSONObject) visitStatus.get(1);
			String currentEffective=(String) currentStatus.get("EffectiveDate");
			String currentEffectiveDate=currentEffective.substring(0, 19);
			report.reportInfo("Previous status expiration date:"+previousExpiryDate);
			report.reportInfo("Current status effective date:"+currentEffectiveDate);
			int arraySize=getVisitSatusArraySize(dataBase, containerName, id);
			String statusChange =(String) TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).get("StatusChange");
			if(previousExpiryDate.contentEquals(currentEffectiveDate) && arraySize>1 && statusChange.contentEquals("Yes")){
				report.reportPass("Verified visit status expiry successfully",false);

			}else{
				throw new Exception("Fail to verify visit status expiryand unmatched data are: "+currentEffectiveDate);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public   ArrayList<String> readADTPatientInfoFromCosmos(String dataBase,String containerId,String id){
		ArrayList<String> patientInfo=new ArrayList<>();
		try {

			org.json.JSONObject patient = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Patient");				
			String firstName = (String) patient.get("PatientFirstName");
			String lastName = (String) patient.get("PatientLastName");		
			String email=(String) patient.get("PatientEmailAddress");
			org.json.JSONArray address = (org.json.JSONArray)	patient.get("PatientAddress");
			org.json.JSONObject patientAddress =(JSONObject) address.get(0);
			String city=(String) patientAddress.get("City");
			patientInfo.add(firstName);
			patientInfo.add(lastName);				
			patientInfo.add(email);
			patientInfo.add(city);		

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return patientInfo;
	}

	public ArrayList<String> readAllObjectsADTInformation(String dataBase,String containerName,String id){

		ArrayList<String> otherInfo=new ArrayList<>();
		ArrayList<String> patientInfo=new ArrayList<>();

		try {
			patientInfo=readADTPatientInfoFromCosmos(dataBase, containerName, id);
			otherInfo.add(readPatientContactInfoFromCosmos(dataBase, containerName, id));
			otherInfo.add(readAdmittingVisitProviderInfoFromCosmos(dataBase, containerName, id));
			otherInfo.add(readInsuredAddressInfoFromCosmos(dataBase, containerName, id));
			otherInfo.add(readGuarantorInfoFromCosmos(dataBase, containerName, id));
			otherInfo.add(readClaimOccuranceCodeFromCosmos(dataBase, containerName, id));
			otherInfo.add(readAccidentCodeFromCosmos(dataBase, containerName, id));
			otherInfo.add(readObservationTypeFromCosmos(dataBase, containerName, id));
			otherInfo.add(readDRGFromCosmos(dataBase, containerName, id));
			otherInfo.add(readDiagnosisNameFromCosmos(dataBase, containerName, id));			

			patientInfo.addAll(otherInfo);

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return patientInfo;
	}
	public void verifyAllADTObjectsInformation(String dataBase,String containerName,String id){
		try {
			ArrayList<String> allInfo=readAllObjectsADTInformation(dataBase, containerName, id);
			ArrayList<String> expInfo=notepadReadToList("hello");
			report.reportInfo("All objects information from current document: "+ allInfo);
			report.reportInfo("All objects information from previous document: "+ expInfo);
			ArrayList<String>unmatchedPatientInfo=getUmatchedInArrayComparision(allInfo, expInfo);
			int arraySize=getTransactionArraySize(dataBase, containerName, id);

			if(unmatchedPatientInfo.size()==0 && arraySize>1){
				report.reportPass("Verified all objects information successfully",false);
			}
			else{
				throw new Exception("Fail to verify objects information and unmatched fields are: "+unmatchedPatientInfo);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public void verifyADTVisitStatus(String dataBase,String containerName,String id){
		try {
			ArrayList<String> expInfo=new ArrayList<>();				
			ArrayList<String> actualInfo=getVisitStatusFromCurrentDocument(dataBase, containerName, id);
			expInfo.add("Scheduled");
			expInfo.add("No");

			ArrayList<String>unmatchedInfo=getUmatchedInArrayComparision(actualInfo, expInfo);
			int arraySize=getVisitSatusArraySize(dataBase,containerName,id);

			if(unmatchedInfo.size()==0 && arraySize==1){
				report.reportPass("Verified visit status and visitStatus array successfully",false);
			}
			else{
				throw new Exception("Fail to verify visit status and visitStatus array and unmatched data are: "+unmatchedInfo);
			}

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public   ArrayList<String> readADTPatientIdentifiersFromCosmos(String dataBase,String containerId,String id){
		ArrayList<String> visitMatch=new ArrayList<>();
		try 
		{	

			org.json.JSONObject patient =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Patient");		
			org.json.JSONArray identifiers=(org.json.JSONArray) patient.get("TenantPatientIdentifier");
			org.json.JSONObject mr=(JSONObject) identifiers.get(0);
			String mrID=(String) mr.get("TenantPatientId");				
			org.json.JSONObject epi=(JSONObject) identifiers.get(3);
			String epiID=(String) epi.get("TenantPatientId");							

			org.json.JSONObject visit = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Visit");
			String accountNumber = (String) visit.get("AccountNumber");
			String visitNumber = (String) visit.get("VisitNumber");
			String date = (String) visit.get("VisitDate");			
			//String visitDate=date.substring(0,19);
			String firstName = (String) patient.get("PatientFirstName");
			String lastName = (String) patient.get("PatientLastName");				
			String email=(String) patient.get("PatientEmailAddress");
			org.json.JSONArray address = (org.json.JSONArray)	patient.get("PatientAddress");
			org.json.JSONObject patientAddress =(JSONObject) address.get(0);
			String city=(String) patientAddress.get("City");

			visitMatch.add(mrID);				
			visitMatch.add(epiID);			
			visitMatch.add(accountNumber);
			visitMatch.add(visitNumber);
			visitMatch.add(date);
			visitMatch.add(firstName);
			visitMatch.add(lastName);
			visitMatch.add(email);
			visitMatch.add(city);			

			notepadWrite("hello", visitMatch);
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return visitMatch;
	}
	public void verifyTransactionArray(String dataBase,String containerName,String id){
		try {
			ArrayList<String> expInfo=new ArrayList<>();				
			ArrayList<String> actualInfo=new ArrayList<>();
			expInfo.add("SYSTEM");
			expInfo.add("iPAS");
			expInfo.add("Add Patient");
			org.json.JSONArray transaction =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).getJSONArray("Transaction");
			org.json.JSONObject tranObject=(JSONObject) transaction.get(0);
			String messageType=(String) tranObject.get("MessageType");
			org.json.JSONObject eventType=(JSONObject) tranObject.get("EventType");
			String code=(String)eventType.get("EventTypeCode");
			String description=(String)eventType.get("EventTypeDescription");
			actualInfo.add(messageType);
			actualInfo.add(code);
			actualInfo.add(description);
			int arraySize=getTransactionArraySize(dataBase,containerName,id);
			ArrayList<String>unmatchedInfo=getUmatchedInArrayComparision(actualInfo, expInfo);
			if(unmatchedInfo.size()==0 && arraySize==2){
				report.reportPass("Verified transaction array successfully",false);
			}
			else{
				throw new Exception("Fail to verify transaction and unmatched data are: "+unmatchedInfo);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public String getProcedureIdFromResponse(){
		String procedureId="";
		try {
			procedureId = rest.getStringValueFromResponse("$..procedureId");		
			procedureId=replaceAll(procedureId);		
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return procedureId;
	}
	public void verifyProcedureId(String dataBase,String containerName,String id){
		try {
			String cosmosDBProcedureID=readProcedureIdFromCosmos(dataBase, containerName, id);
			String procedureID=getProcedureIdFromResponse();
			report.reportInfo("Procedure Id from current document: "+ cosmosDBProcedureID);
			report.reportInfo("Procedure Id from response: "+ procedureID);
			
			if(cosmosDBProcedureID.contentEquals(procedureID)){
				report.reportPass("Verified procedureID successfully",false);
			}
			else{
				throw new Exception("Fail to verify procedureid and unmatched fields are: "+procedureID);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	
	public String readProcedureIdFromCosmos(String dataBase,String containerId,String id){
		String procedureId="";
		try {
			org.json.JSONArray procedureArr =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("Procedure");		
			org.json.JSONObject procedure=(JSONObject) procedureArr.get(0);
			 procedureId=(String) procedure.get("ProcedureId");				

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return procedureId;
	}
	
	public void verifyProcedurePopulatedFields(String dataBase,String containerId,String id){
		try {
			ArrayList<String> procedureResponse=new ArrayList<>();
			org.json.JSONArray procedureArr =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("Procedure");
			org.json.JSONObject procedure=(JSONObject) procedureArr.get(0);
			 String createdBy=(String) procedure.get("CreatedBy");
			 String updatedBy=(String) procedure.get("LastUpdateBy");
			 String createdByType=(String) procedure.get("CreatedByType");
			 String updatedByType=(String) procedure.get("LastUpdateByType");
			 String createdDateUTC=(String) procedure.get("CreatedDateUTC");
			 String utcTime[]= createdDateUTC.split(".");
			 String utcDateTime=utcTime[0];
			 String updatedDateUTC=(String) procedure.get("LastUpdateDateUTC");
			 String updatedUtcTime[]= updatedDateUTC.split(".");
			 String updatedUtcDateTime=utcTime[0];
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public   ArrayList<String> readICDANDCPTCodesFromCosmos(String dataBase,String containerId,String id){
		ArrayList<String> codes=new ArrayList<>();
		try 
		{	
			
		org.json.JSONArray diagnosis = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("Diagnosis");
		org.json.JSONObject diag=(JSONObject) diagnosis.get(0);
		org.json.JSONObject diagDescription=(JSONObject) diag.get("DiagnosisDescription");
		String diagCode=(String) diagDescription.get("DiagnosisCode");
		
		org.json.JSONArray proced = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("Procedure");
		org.json.JSONObject proc=(JSONObject) proced.get(0);
		org.json.JSONObject proName=(JSONObject)  proc.get("ProcedureName");
		String proCode1=(String)proName.get("ProcedureCode");		
		
		org.json.JSONObject proce=(JSONObject) proced.get(1);
		org.json.JSONObject proceName=(JSONObject)  proce.get("ProcedureName");
		String proCode2=(String)proceName.get("ProcedureCode");
				
		codes.add(diagCode);
		codes.add(proCode1);
		codes.add(proCode2);					

		notepadWrite("hello", codes);
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return codes;
	}	
	public   String readVisitProviderInfoFromCosmos(String dataBase,String containerId,String id){
		String providerName="";
		try {				
			org.json.JSONObject visit = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Visit");	
			org.json.JSONArray visitProvider=(org.json.JSONArray) visit.get("VisitProvider");
			org.json.JSONObject admittingProvider=(JSONObject) visitProvider.get(3);
			String providerLastName=(String) admittingProvider.get("ProviderLastName");
			String providerFirstName=(String) admittingProvider.get("ProviderFirstName");
			String providerNPI=(String) admittingProvider.get("ProviderNPI");
			providerName=providerFirstName+" "+providerLastName+" "+"("+providerNPI+")";

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return providerName;
	}
	public   String readInsurancePlanNameFromCosmos(String dataBase,String containerId,String id){
		String insuranceName="";
		try {				
			org.json.JSONArray insuranceArr =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("Insurance");		
			org.json.JSONObject insuarnce=(JSONObject) insuranceArr.get(0);
			insuranceName=(String) insuarnce.get("InsurancePlanName");

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return insuranceName;
	}
	public  ArrayList<String> readProcedureInfoFromCosmos(String dataBase,String containerId,String id){
		ArrayList<String> procedureInfo=new ArrayList<>();
		try {				
			org.json.JSONArray proced = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONArray("Procedure");
			org.json.JSONObject proc=(JSONObject) proced.get(0);
			org.json.JSONObject procName= (JSONObject) proc.get("ProcedureName");
			String procCode=(String) procName.get("ProcedureCode");
			String procDescription=(String) procName.get("ProcedureDescription");
			procedureInfo.add(procCode);
			procedureInfo.add(procDescription);
			procedureInfo.add("A5 - Dressing for five wounds");
			procedureInfo.add("1");		
			
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return procedureInfo;
	}
	public void verifyAppointmentDuration(String dataBase,String containerName,String id){
		try {			
			ArrayList<String> patientInfo=readPatientAppointmentInfoFromCosmos(dataBase, containerName, id);				
			ArrayList<String> expPatientInfo=notepadReadToList("hello");
			report.reportInfo("Patient information from current document: "+ patientInfo);
			report.reportInfo("Patient information from input document: "+ expPatientInfo);
			ArrayList<String>unmatchedPatientInfo=getUmatchedInArrayComparision(patientInfo, expPatientInfo);
			int arraySize=getTransactionArraySize(dataBase, containerName, id);

			if(unmatchedPatientInfo.size()==0 && arraySize>1){
				report.reportPass("Verified patient information successfully",false);
			}
			else{
				throw new Exception("Fail to verify patient information and unmatched fields are: "+unmatchedPatientInfo);
			}
		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
	}
	public   ArrayList<String> readPatientAppointmentInfoFromCosmos(String dataBase,String containerId,String id){
		ArrayList<String> patientInfo=new ArrayList<>();
		try {
			org.json.JSONObject patient = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Patient");			
			org.json.JSONObject appointment = TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerId,id).getJSONObject("Appointment");				
			String	appointmentTime = (String) appointment.get("AppointmentDuration");			
			patientInfo.add(appointmentTime);

		} catch (Exception e) {
			report.reportFail(""+e,false);
		}
		return patientInfo;
	}

}
