package com.ipas.hf.actions;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import org.joda.time.DateTime;

public class Testing {
	
	public void spilitString() throws Exception{
		try {
			/*String txt="03/31/2022 01:11:01 PM";
			//DateFormat dateFormat2 = new SimpleDateFormat("dd/MM/yyyy hh.mm aa");
			 //SimpleDateFormat dateFormat2=new SimpleDateFormat("dd/MM/yyyy");  
			
			 // Date date1=dateFormat2.parse(txt);  
	    	//System.out.println("Current date and time in AM/PM: "+date1);
			String txt1=txt.substring(0, 16);
			String txt2=txt.substring(20, 22);
			txt=txt1+" "+txt2;
			System.out.println("1: "+txt1);
			System.out.println("2: "+txt2);

			txt=txt1+" "+txt2;*/
			
			//03/29/2022, 04:51 PM
			/*String s="$75.60";
			System.out.println(""+s.length());
			s=s.substring(0, s.length()- 8).trim();
			System.out.println(""+s);*/
			
			/*String liveprice = "$123,456.70";
			liveprice = liveprice.replace("$", "").replace(",","");
			System.out.println(liveprice);*/
			/*String str="Plan Code V4607 already exists for Parkside Regional Medical Hospital.";
			String str2="V4607";
			if(str.contains(str2)){
				System.out.println("Test Pass");
			}else{
				System.out.println("Test Fail");
			}*/
			
			String as="60.00 0 claims";
			String[] splited = as.split("\\s+");
			as=splited[0];
			System.out.println("Test Data: "+as);
			
		} catch (Exception e) {
			throw e;
		}
	}
	
	public void compareString(){
		/*String a="boldtext ng-star-inserted 1isDisablead1aas";
		String b="isDisabled";
		if(a.contains(b)){
			System.out.println("Pass");
		}else{
			System.out.println("Fail");
		}*/
		//int a = ThreadLocalRandom.current().nextInt();   
		int b = ThreadLocalRandom.current().nextInt(11);   
		//System.out.println(a);
		System.out.println(b);
		
	}

	public static void main(String[] args) throws Exception {
		Testing t=new Testing();
		t.spilitString();

	}

}
