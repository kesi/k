package com.ipas.hf.engine;

import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerOptions;

import com.google.gson.Gson;
import com.ipas.hf.testbase.TestBase;

public class BrowserCapabilities {

	public String downloadFilepath="";
	public Capabilities getCapabilities(String browserName) throws IOException, ParseException {
		JSONParser parser = new JSONParser();
		Map<String, String> map = new HashMap<>();
		try (FileReader reader = new FileReader(
				System.getProperty("user.dir") + "\\src\\main\\resources\\capabilities.json")) {
			Object obj = parser.parse(reader);
			JSONObject parentObject = (JSONObject) obj;
			JSONObject browser = (JSONObject) parentObject.get(browserName);
			JSONObject arguments = (JSONObject) browser.get("arguments");
			JSONObject capabilities = (JSONObject) browser.get("capabilities");
			if (browserName.equalsIgnoreCase("chrome")) {
				 downloadFilepath = System.getProperty("user.dir")+"\\Downloads\\";
				map = new Gson().fromJson(arguments.toString(), Map.class);
				ChromeOptions options = new ChromeOptions();
				Set<String> keys = map.keySet();
				for (String key : keys) {
					options.addArguments(map.get(key));
				}
				options.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
				options.setExperimentalOption("useAutomationExtension", false);
				Map<String, Object> prefs = new HashMap<>();
				prefs.put("credentials_enable_service", false);
				prefs.put("password_manager_enabled", false);
				prefs.put("profile.default_content_settings.popups", 0);
				prefs.put("download.default_directory", downloadFilepath);
				prefs.put("download.prompt_for_download", "false");
				prefs.put("profile.managed_default_content_settings.geolocation", 2);
				options.setExperimentalOption("prefs", prefs);
				options.addArguments("--disable-notifications");
				map.clear();
				map = new Gson().fromJson(capabilities.toString(), Map.class);
				keys = map.keySet();
				for (String key : keys) {
					options.setCapability(key, map.get(key));
				}
				return options;
			}
			if (browserName.equalsIgnoreCase("firefox")) {
				map = new Gson().fromJson(arguments.toString(), Map.class);
				FirefoxOptions options = new FirefoxOptions();
				if (TestBase.prop.runType().equals("local")) {
					options.setBinary(TestBase.prop.firefoxBinaryPath());
				}
				Set<String> keys = map.keySet();
				for (String key : keys) {
					options.addArguments(map.get(key));
				}
				map.clear();
				map = new Gson().fromJson(capabilities.toString(), Map.class);
				keys = map.keySet();
				for (String key : keys) {
					options.setCapability(key, map.get(key));
				}
				return options;
			}
			if (browserName.equalsIgnoreCase("ie")) {
				InternetExplorerOptions options = new InternetExplorerOptions();
				map = new Gson().fromJson(capabilities.toString(), Map.class);
				Set<String> keys = map.keySet();
				for (String key : keys) {
					options.setCapability(key, map.get(key));
				}
				return options;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
