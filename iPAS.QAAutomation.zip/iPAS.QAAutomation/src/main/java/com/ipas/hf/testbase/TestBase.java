package com.ipas.hf.testbase;



import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Properties;

import org.aeonbits.owner.ConfigFactory;
import org.joda.time.DateTime;
import org.openqa.selenium.Capabilities;
import org.testng.IExecutionListener;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;


import com.ipas.hf.reporting.ExtentManager;
import com.ipas.hf.reporting.ExtentSummary;
import com.ipas.hf.reporting.ExtentTestManager;
import com.ipas.hf.reporting.JSONReportBuilder;
import com.ipas.hf.rest.OutPutJSON;
import com.ipas.hf.utilities.ConfigProperties;
import com.ipas.hf.utilities.EmailReporter;
import com.ipas.hf.cucumber.PickleEventWrapper;
import com.ipas.hf.cucumber.TestNGCucumberRunner;
import com.ipas.hf.engine.BrowserCapabilities;
import com.ipas.hf.engine.ConcurrentEngine;
import com.ipas.hf.engine.GridSetup;

import cucumber.api.testng.CucumberFeatureWrapper;


@Listeners(TestBase.class)
public class TestBase implements IExecutionListener {

	public static Properties apiProp;
	public static ConfigProperties prop;
	private String apiPropertiesFile = "api.properties";

	private boolean remoteExecution;

	private static String extentReport;

	private static String reportPath;

	private String browser;

	private static String reportDirectoryName;

	private static final String DATETIMEFORMAT = "E dd MMM yyyy HH-mm-ss";

	private TestNGCucumberRunner testNGCukesRunner;

	private JSONReportBuilder executionSummaryReport = JSONReportBuilder.getInstance();

	private BrowserCapabilities cap = new BrowserCapabilities();
	private OutPutJSON outputJSON = OutPutJSON.getinstance();
	

	@Override
	public void onExecutionStart() {
		try {
			defaultOnExecutionStart();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void defaultOnExecutionStart() throws Exception {
		loadProperties();
		setUpExtent();
		setupExtentSummary();
		if (prop.runType().equals("api")) {
			loadAPIProperties();
			setUpOutputTestDataDirectory();
		}else if((prop.runType().equals("apiui")) || (prop.runType().equals("grid"))){
			loadAPIProperties();
			setUpOutputTestDataDirectory();
			//engineSetUp(context);
		}
	}
	
	
	
	public void loadProperties() {
		prop = ConfigFactory.create(ConfigProperties.class);

	}

	public void loadAPIProperties() {
		try (InputStreamReader input = new InputStreamReader(
				getClass().getClassLoader().getResourceAsStream(apiPropertiesFile))) {
			apiProp = new Properties();

			apiProp.load(input);

		} catch (Exception e) {
			System.out.println("loadProperties There was a problem loading API properties file.");
			e.printStackTrace();
		}
	}

	public void setUpExtent() {

		if (prop.extentReport().equals("true")) {
			reportDirectoryName = prop.extentWindowsDirectory();
			reportPath = new File(System.getProperty("user.dir")) + reportDirectoryName + "Test Execution Reports "
					+ DateTime.now().toString(DATETIMEFORMAT);
			String fullPath = reportPath;
			File screenshotDirectory = new File(fullPath);
			screenshotDirectory.mkdirs();

			System.setProperty("extent.Report.Directory", fullPath);
		}

	}

	public void setUpOutputTestDataDirectory() {

		String outputDir = new File(System.getProperty("user.dir")) + "\\outputdata";
		File directory = new File(outputDir);
		directory.mkdirs();
		File file = new File(outputDir + "\\TestData" + DateTime.now().toString(" MMDDyyyyhhmmss") + ".txt");
		try {
			file.createNewFile();
		} catch (IOException e) {

			e.printStackTrace();
		}

		System.setProperty("api.output.file", file.getPath());
		System.setProperty("api.test.data.Directory", outputDir);
	}

	public void setupExtentSummary() {
		ExtentSummary.createSummaryInstance();
	}

	@BeforeClass
	public void beforeClass(ITestContext context) throws Exception {
		if (!prop.runType().equalsIgnoreCase("api")) {
			setRemoteExecution();
		}
		testNGCukesRunner = new TestNGCucumberRunner(context, this.getClass());

	}

	public void setRemoteExecution() throws UnknownHostException {
		if (prop.runType().equalsIgnoreCase("grid")) {
			remoteExecution = true;
		}
		if (remoteExecution == true) {
			GridSetup initializeGrid = new GridSetup();
			System.setProperty("grid.url", initializeGrid.startGrid(prop.gridPortNumber()));
		}
	}

	@BeforeMethod
	public void beforeMethod(ITestContext context, Method method) throws Exception {
		if (!prop.runType().equals("api")  || prop.runType().equals("apiui")) {

			try {
				engineSetUp(context);
			} catch (Exception e) {
				throw e;
			}
		}
	}
	
	
	


	protected void engineSetUp(ITestContext context) throws Exception {

		if (!prop.runType().equalsIgnoreCase("api")|| prop.runType().equals("apiui")) {
			setTestParameters(context);
			Capabilities caps = cap.getCapabilities(browser);
			ConcurrentEngine.createEngine(caps, browser, remoteExecution);
		}
	}

	@Test(groups = "cucumber", description = "Runs Cucumber Scenarios", dataProvider = "scenarios")
	public void runScenario(PickleEventWrapper pickleWrapper, CucumberFeatureWrapper featurewrapper) throws Throwable {
		try {

			String featureFileTopTag = pickleWrapper.getPickleEvent().pickle.getTags().get(0).getName();
			String currentTestCaseID = pickleWrapper.getPickleEvent().pickle.getTags().get(1).getName().replaceAll("\\@","");
			String currentScenarioName = pickleWrapper.getPickleEvent().pickle.getName();
			reportSetup(currentScenarioName, featureFileTopTag,currentTestCaseID);
			assignReportTag(featureFileTopTag);
			outputJSON.setTestName(currentScenarioName);
			testNGCukesRunner.runScenario(pickleWrapper.getPickleEvent());
		} catch (Exception e) {
			ExtentTestManager.getTest().fail(e);
			e.printStackTrace();
			throw e;
		}
	}

	@AfterMethod(alwaysRun = true)
	public void afterMethod(ITestResult result) throws Throwable {
		driverTearDown();
		flushExtentManager();
		ExtentSummary.flushSummaryReport();
		if (prop.runType().equalsIgnoreCase("api")) {
			outputJSON.flushOPData();
		}
	}

	public void driverTearDown() {
		ConcurrentEngine.destroyEngine();
	}

	@AfterClass(alwaysRun = true)
	public void afterClass() {
		testNGCukesRunner.finish();
	}

	@AfterSuite
	public final void afterSuite() throws Exception {
		
	}

	@DataProvider(parallel = true)
	public Object[][] scenarios() {
		return testNGCukesRunner.provideScenarios();
	}

	@Override
	public void onExecutionFinish() {
		executionSummaryReport.generateMasterThoughtsSummary();
		executionSummaryReport.generateReportBuilderSummary();

		System.out.println("Finished at " + new SimpleDateFormat("yyy_MM-dd HH:mm:ss").format(new Date()));
		System.out.println(prop.emailReport());
		if(prop.emailReport().equals("yes")){
			EmailReporter.mailTestNGReport();
		}

	}

	private void setTestParameters(ITestContext context) {
		browser = System.getProperty("browser");
		Map<String, String> allParameters = context.getCurrentXmlTest().getAllParameters();
		for (Map.Entry<String, String> entry : allParameters.entrySet()) {
			if (entry.getKey().equals("browser")) {
				browser = entry.getValue();
			}
		}
	}

	public void flushExtentManager() {
		if (extentReport.equalsIgnoreCase("true")) {
			if (ExtentManager.getInstance() != null) {
				ExtentManager.flushInstance();
				ExtentTestManager.removeTest();
			}
		}
	}
	
	public void reportSetup(String currentScenarioName, String category,String currentTestCaseID) {
		extentReport = prop.extentReport();
		if (extentReport.equalsIgnoreCase("true")) {
			ExtentManager.setupInstance(currentScenarioName);
			if (prop.runType().equals("api")) {
				ExtentTestManager.createTest(currentTestCaseID+": " + currentScenarioName);
				ExtentSummary.createTest(currentTestCaseID+": " + currentScenarioName, category);
			} else {
				ExtentTestManager.createTest(currentTestCaseID+": " + currentScenarioName);
				ExtentSummary.createTest(currentTestCaseID+": " + currentScenarioName, category);
			}
		}
	}
	
	//This is old method after review we can remove this method
	/*public void reportSetup(String currentScenarioName, String category) {
		extentReport = prop.extentReport();
		if (extentReport.equalsIgnoreCase("true")) {
			ExtentManager.setupInstance(currentScenarioName);
			if (prop.runType().equals("api")) {
				ExtentTestManager.createTest("Scenario: " + currentScenarioName);
				ExtentSummary.createTest("Scenario: " + currentScenarioName, category);
			} else {
				ExtentTestManager.createTest("Scenario: " + currentScenarioName + " " + browser);
				ExtentSummary.createTest("Scenario: " + currentScenarioName + " " + browser, category);
			}
		}
	}*/

	public void assignReportTag(String featureFileTopTag) {
		ExtentTestManager.assignCategory(featureFileTopTag);
	}

}
