package com.ipas.hf.utilities;

import org.aeonbits.owner.Config;
import org.aeonbits.owner.Config.Sources;

@Sources({ "file:src/main/resources/Config.properties" })
public interface ConfigProperties extends Config {
	@DefaultValue("true")
	@Key("extent.report")
	public String extentReport();

	@Key("report.directory.windows")
	public String extentWindowsDirectory();

	@Key("reports.dir")
	public String extentReportDirectory();

	@DefaultValue("local")
	@Key("run.type")
	public String runType();

	@DefaultValue("false")
	@Key("Selenium.Event.log")
	public String seleniumEventLog();

	@Key("chrome.binary.version")
	public String chromeBinaryVersion();

	@Key("chrome.binary.version")
	public String firefoxBinaryVersion();

	@Key("ie.binary.version")
	public String internetExplorerBinaryVersion();

	@DefaultValue("2426")
	@Key("grid.port.number")
	public String gridPortNumber();

	@DefaultValue("true")
	@Key("screenshot.passed.step")
	public String screenshotPassedStep();

	@DefaultValue("true")
	@Key("screenshot.failed.step")
	public String screenshotFailedStep();


	@Key("grid.url")
	public String gridURL();

	@DefaultValue("60")
	@Key("explicit.wait.timeout")
	public String explicitWaitPeriod();

	@Key("firefox.binary.path")
	public String firefoxBinaryPath();

	@DefaultValue("60")
	@Key("page.load.wait")
	public String pageLoadTimeout();

	@Key("ipas.int.url")
	public String ipasURL();

	@Key("gmail.int.url")
	public String gmailURL();

	@Key("environment.env")
	public String Environment();

	@DefaultValue("true")
	@Key("isEmailReport")
	public String emailReport();

	@Key("sql.dbserver")
	public String dbServer();


	@Key("sqldbusername")
	public String dbUserName();


	@Key("sqldbpassword")
	public String dbPassword();

	@Key("userName")
	public String tenantUserName();

	@Key("password")
	public String tenatPassword();
	
	@Key("eligibility.int.url")
	public String eligibilityURL();
	
	@Key("applicationUserName")
	public String applicationLoginUserName();

	@Key("applicationPassword")
	public String applicationLoginPassword();
	
	@Key("washington.int.url")
	public String washingtonURL();

	@Key("vim.url")
    public String VIMURL();






}

