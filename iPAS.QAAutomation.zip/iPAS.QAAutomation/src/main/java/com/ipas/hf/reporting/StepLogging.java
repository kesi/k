package com.ipas.hf.reporting;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class StepLogging {

	private Logger log = Logger.getLogger(StepLogging.class);

	private static StepLogging stepLogging;

	private StepLogging() {
		// Singleton
	}

	public static StepLogging getLoggingObject() {
		if (stepLogging == null) {
			stepLogging = new StepLogging();
		}
		return stepLogging;
	}

	public void setLogginLevel(String loggingLevel) {
		log.setLevel(Level.toLevel(loggingLevel));

	}

	public void info(String details, String elementName)

	{
		log.info("Thread: " + Thread.currentThread().getName() + details + elementName);
	}

	public void info(String details)

	{
		log.info("Thread: " + Thread.currentThread().getName() + details);
	}

	public void warn(String details, String elementName) {

		log.warn("Thread: " + Thread.currentThread().getName() + details + elementName);

	}

	public void warn(String message) {

		log.warn("Thread: " + Thread.currentThread().getName() + "message");

	}

	public void error(String details, String elementName, Throwable e) {

		log.error("Thread: " + Thread.currentThread().getName() + details + elementName, e);

	}

	public void error(String message, Throwable e) {

		log.error("Thread: " + Thread.currentThread().getName() + message, e);

	}

	public void fatal(String details, String elementName, Throwable e) {

		log.fatal("Thread: " + Thread.currentThread().getName() + details + elementName, e);

	}

}