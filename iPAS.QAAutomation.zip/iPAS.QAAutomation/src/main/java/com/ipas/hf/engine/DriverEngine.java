package com.ipas.hf.engine;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ThreadGuard;
import org.openqa.selenium.support.events.EventFiringWebDriver;


import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.ReportLibrary;
import com.ipas.hf.testbase.TestBase;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverEngine {

	private EventFiringWebDriver webDriver;

	private WebActions webActions;

	private ReportLibrary reportLibrary;

	private String browser;

	private String browserVersion;

	private WebDriverEvents webDriverEvents = WebDriverEvents.getInstance();

	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public String getBrowserVersion() {
		return browserVersion;
	}

	public void setBrowserVersion(String browserVersion) {
		this.browserVersion = browserVersion;
	}

	public DriverEngine() {
		initialize();
	}

	public void initialize() {
		initalizeWebActions();
		initalizeReportLibrary();
		
	}

	private void initalizeWebActions() {
		webActions = new WebActions(this);
	}

	private void initalizeReportLibrary() {
		reportLibrary = new ReportLibrary(this);
	}

	

	public WebActions getWebActions() {
		return webActions;
	}

	public ReportLibrary getReportLibrary() {
		return reportLibrary;
	}

	public EventFiringWebDriver getWebDriver() {
		return webDriver;
	}

	
	public void setWebDriver(EventFiringWebDriver webDriver) {
		this.webDriver = webDriver;
	}

	public void setUpWebDriver(String browserType, Capabilities caps, boolean remoteExecution) throws Exception {
		selectDriverType(browserType, caps, remoteExecution);
	}

	private final void selectDriverType(String browserType, Capabilities caps, boolean remoteExecution)
			throws Exception {
		if (remoteExecution)
			setUpRemoteWebDriver(browserType, caps);
		else
			setUpLocalWebDriver(browserType, caps);
	}

	private void setUpRemoteWebDriver(String browser, Capabilities caps) throws Exception {
		try {
			webDriver = new EventFiringWebDriver(ThreadGuard.protect(createRemoteDriver(caps)));
			webDriver.manage().window().maximize();
			if (Boolean.parseBoolean(TestBase.prop.seleniumEventLog())) {
				webDriver.register(webDriverEvents);
			}
		} catch (MalformedURLException e) {
			System.out.println("setUpRemoteWebDriver, The url provided was malformed.");
			throw e;
		} catch (SessionNotCreatedException e) {
			System.out.println("setUpRemoteWebDriver, The session could not be created.");
			throw e;
		} catch (WebDriverException e) {
			System.out.println(
					"setUpRemoteWebDriver, The webdriver created on one thread was accessed by another thread or the session could not be created");
			throw e;
		}
	}

	private RemoteWebDriver createRemoteDriver(Capabilities caps) throws MalformedURLException {
		RemoteWebDriver remoteWebDriver;
		String hubURL = System.getProperty("grid.url");
		switch ("grid") {
		case "grid":
			remoteWebDriver = new RemoteWebDriver(new URL(hubURL), caps);
			break;
		default:
			System.out.println("an attempt to create a remote web driver for grid is failed");
			remoteWebDriver = new RemoteWebDriver(new URL(hubURL), caps);
		}
		return remoteWebDriver;
	}

	private void setUpLocalWebDriver(String browserType, Capabilities caps) throws Exception {
		EventFiringWebDriver eventDriver;
		switch (browserType.toUpperCase()) {
		case "CHROME":
			eventDriver = setUpLocalChromeDriver(caps);
			break;
		case "FIREFOX":
			eventDriver = setUpLocalFirefoxDriver(caps);
			break;
		case "IE":
			eventDriver = setUpLocalIeDriver(caps);
			break;
		default:
			throw new IllegalArgumentException(browserType + " is not supported. Please choose another browser.");
		}
		webDriver = eventDriver;
		// #############
		if (Boolean.parseBoolean(TestBase.prop.seleniumEventLog())) {
			webDriver.register(webDriverEvents);
		}
		webDriver.manage().window().maximize();
		setBrowser(caps.getBrowserName());
		setBrowserVersion(caps.getVersion());
	}

	private EventFiringWebDriver setUpLocalChromeDriver(Capabilities caps) {
		EventFiringWebDriver driver;
		ChromeOptions options = (ChromeOptions) caps;
		WebDriverManager.chromedriver().version(TestBase.prop.chromeBinaryVersion()).setup();
		if (caps == null) {
			driver = new EventFiringWebDriver(ThreadGuard.protect(new ChromeDriver()));
		} else {
			driver = new EventFiringWebDriver(ThreadGuard.protect(new ChromeDriver(options)));
		}
		return driver;
	}

	private EventFiringWebDriver setUpLocalFirefoxDriver(Capabilities caps) {
		EventFiringWebDriver driver;
		FirefoxOptions options = (FirefoxOptions) caps;
		WebDriverManager.firefoxdriver().version(TestBase.prop.firefoxBinaryVersion()).setup();
		if (caps == null) {
			driver = new EventFiringWebDriver(ThreadGuard.protect(new FirefoxDriver()));
		} else {
			driver = new EventFiringWebDriver(ThreadGuard.protect(new FirefoxDriver(options)));
		}
		return driver;
	}

	private EventFiringWebDriver setUpLocalIeDriver(Capabilities caps) {
		EventFiringWebDriver driver;
		InternetExplorerOptions options = (InternetExplorerOptions) caps;
		WebDriverManager.iedriver().version(TestBase.prop.internetExplorerBinaryVersion()).arch32().setup();
		if (caps == null) {
			driver = new EventFiringWebDriver(ThreadGuard.protect(new InternetExplorerDriver()));
		} else {
			driver = new EventFiringWebDriver(ThreadGuard.protect(new InternetExplorerDriver(options)));
		}
		return driver;
	}

}

