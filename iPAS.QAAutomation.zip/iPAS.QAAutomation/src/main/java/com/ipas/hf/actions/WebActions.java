
package com.ipas.hf.actions;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.time.DateUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ipas.hf.engine.ConcurrentEngine;
import com.ipas.hf.engine.DriverEngine;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.testbase.TestBase;

import io.cucumber.datatable.DataTable;

public class WebActions {

	private DriverEngine driverEngine;

	private StepLogging log = StepLogging.getLoggingObject();

	long explicitPeriod = Long.parseLong(TestBase.prop.explicitWaitPeriod());

	public DriverEngine getDriverEngine() {
		return driverEngine;
	}

	public WebActions(DriverEngine driverEngine) {
		this.driverEngine = driverEngine;
	}

	public void loadURL(String URL) {
		driverEngine.getWebDriver().get(URL);
	}

	public void refreshPage() {
		driverEngine.getWebDriver().navigate().refresh();
	}

	private void selectDropDownOption(WebElement element, String value, String elementName) throws Exception {
		//Need to be implement
	}
	/**
	 * Click WebElement
	 *
	 * @param element
	 * @param elementName
	 * @throws Exception
	 */
	public void click(WebElement element, String elementName) {
		try {
			element.click();
			log.info("Click on: ", elementName);
		} catch (Exception e) {
			log.error("Click on: ", elementName, e);
			throw e;
		}
	}

	/**
	 * wait Until WebElement Displayed Property is True and then Click
	 *
	 * @param element
	 * @param elementName
	 * @throws Exception
	 */
	public void waitAndClick(WebElement element, String elementName) {
		waitForClickAbility(element, elementName);
		click(element, elementName);
	}

	/**
	 * wait Until WebElement Enabled Property is True and then Click
	 *
	 * @param element
	 * @param elementName
	 * @throws Exception
	 */
	public void waitUntilEnabledAndClick(WebElement element, String elementName) throws Exception {
		waitUntilEnabled(element, elementName);
		click(element, elementName);
	}

	/**
	 * get Element Attribute Value
	 *
	 * @param element
	 * @param elementName
	 * @return
	 */
	public String getValue(WebElement element, String elementName) {
		String value = null;
		try {
			value = element.getAttribute("value");
			log.info("Get Attribute Value for ", elementName + ": " + value);
		} catch (Exception e) {
			log.error("Get Attribute Value Failed for ", e);
		}
		return value;
	}



	public void sendKeys(WebElement element,String value,String elementName ){
		try{
			element.sendKeys(value);
			log.info("Emtered Value as ", value);
		}catch(Exception e){
			log.error("Failed to enter value in to ", elementName, e);
			throw e;
		}

	}

	public void clearValue(WebElement element,String elementName ){
		try{
			element.clear();
			log.info("Value cleared");
		}catch(Exception e){
			log.error("Failed to clear the value", e);
			throw e;
		}

	}

	public void waitUntilPresentAndDisplayed(WebElement element, String elementName){
		try {
			element.isDisplayed();
			log.info("Displayed element: ", elementName);
		} catch (Exception e) {
			log.error("Failed to display the element: ", elementName, e);
			throw e;
		}
	}



	public String getText(WebElement element, String elementName) {
		String text = null;
		try {
			text = element.getText();
			log.info("Get Attribute Value for ", elementName + ": " + text);
		} catch (Exception e) {
			log.error("Get Attribute Value Failed for ", e);
		}
		return text;
	}

	/**
	 * wait Until WebElement is Visible using WebDriverWait
	 *
	 * @param element
	 * @param elementName
	 * @throws Exception
	 */
	public void waitForVisibility(WebElement element, String elementName) {
		try {
			WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), explicitPeriod);
			wait.ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.visibilityOf(element));
			log.info("Wait for Element to be visible: ", elementName);
		} catch (Exception e) {
			log.error("Wait for Element to be visible: ", e);
			throw e;
		}
	}


	public String waitAndGetText(WebElement element, String elementName) {
		String text = null;
		try {
			WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), explicitPeriod);
			wait.ignoring(NoSuchElementException.class);
			text=wait.until(ExpectedConditions.visibilityOf(element)).getText();
			log.info("Get Text Value for ", elementName + ": " + text);
		} catch (Exception e) {
			log.error("Get Text Value Failed for ", e);
		}
		return text;
	}

	/**
	 * wait Until Visibility Of All Elements using WebDriverWait
	 *
	 * @param element
	 * @param elementName
	 * @throws Exception
	 */
	public void waitForVisibilityOfAllElements(WebElement element,String elementName ){
		try {
			WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), explicitPeriod);
			wait.until(ExpectedConditions.visibilityOfAllElements(element));
			log.info("Wait for Visibility Of All Elements: ", elementName);
		} catch (Exception e) {
			log.error("Wait for Element to be visible: ", e);
			throw e;
		}
	}

	/**
	 * wait Until Visibility Of All Elements using WebDriverWait
	 *
	 * @param element
	 * @param elementName
	 * @throws Exception
	 */
	public void waitForVisibilityOfAllElements(List<WebElement> elements,String elementName){
		try {
			WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), explicitPeriod);
			wait.until(ExpectedConditions.visibilityOfAllElements(elements));
			log.info("Wait for Visibility Of All Elements: ", elementName);
		} catch (Exception e) {
			log.error("Wait for Element to be visible: ", e);
			throw e;
		}
	}

	public void check(WebElement element, String elementName){
		try{
			if(!element.isSelected())
			{
				element.click();
				log.info("Should check the option :" +elementName);
			}
			else
			{
				log.info("CheckBox already checked");
			}
		}catch(Exception e){
			log.error("Failed to check the option :" +elementName, e);
		}

	}

	public void uncheck(WebElement element, String elementName){
		try{
			if(element.isSelected())
			{
				element.click();
				log.info("Should uncheck the option :" +elementName);
			}
			else
			{
				log.info("CheckBox already unchecked");
			}
		}catch(Exception e){
			log.error("Failed to check the option :" +elementName, e);
		}

	}


	public void waitForPageLoaded() throws Exception  {
		ExpectedCondition<Boolean> expectation = new
				ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
			}
		};
		try {
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), explicitPeriod);
			wait.until(expectation);
		} catch (Exception e) {
			log.error("Timeout waiting for Page Load: ", e);
			throw e;
		}
	}

	public void waitForLoad() {
		try {
			ExpectedCondition<Boolean> pageLoadCondition = new
					ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver driverEngine) {
					return ((JavascriptExecutor)driverEngine).executeScript("return document.readyState").equals("complete");
				}
			};
			WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), explicitPeriod);
			wait.until(pageLoadCondition);
		} catch (Exception e) {
			log.error("Wait For PageLoad: ", e);
			throw e;
		}
	}


	/**
	 * wait Until WebElement is Visible using WebDriverWait and Defined Wait
	 * Period
	 *
	 * @param element
	 * @param elementName
	 * @throws Exception
	 */
	public WebElement waitForVisibility(WebElement element, String elementName, long period) {
		try {
			WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), period);
			wait.ignoring(NoSuchElementException.class).pollingEvery(Duration.ofMillis(500));
			wait.until(ExpectedConditions.visibilityOf(element));
			log.info("Wait for Element to be visible: ", elementName);
		} catch (Exception e) {
			log.error("Wait for Element to be visible: ", e);
			throw e;
		}
		return element;
	}

	public boolean isPresent(WebElement element, String elementName) {
		try {
			element.getSize();
			log.info("Element is Present: ", elementName);
			return true;

		} catch (NoSuchElementException e) {
			log.info("Element not Present : ", elementName);
			return false;

		}

	}

	/**
	 * Wait Until Element is Clickable
	 *
	 * @param element
	 * @param elementName
	 */
	public void waitForClickAbility(WebElement element, String elementName) {
		try {
			WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), explicitPeriod);
			wait.ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.elementToBeClickable(element));
			log.info("Wait for Element to be Clickable: ", elementName);
		} catch (Exception e) {
			log.error("Wait for Element to be Clickable: ", e);
			throw e;
		}
	}

	/**
	 * Wait Until Element is Clickable and Perform JS Click
	 *
	 * @param element
	 * @param elementName
	 */
	public void waitForClickAbilityAndClick(WebElement element, String elementName) {
		try {
			WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), explicitPeriod);
			wait.ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.elementToBeClickable(element));
			clickBYJS(element, elementName);
			log.info("Wait for Element to be Clickable: ", elementName);
		} catch (Exception e) {
			log.error("Wait for Element to be Clickable: ", e);
			throw e;
		}
	}

	/**
	 * Wait for Text to Be Present in Textbox
	 *
	 * @param element
	 * @param elementName
	 */
	public void waitForTextToBePresentInValue(WebElement element, String value, String elementName) {
		long timeOut = explicitPeriod;
		try {
			WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), timeOut);
			wait.ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.textToBePresentInElementValue(element, value));
			log.info("Wait for Text to Present in Value: ", elementName);
		} catch (Exception e) {
			log.error("Wait for Text to Present in Value: ", e);
			throw e;
		}
	}

	/**
	 * Wait for Text to Be Present in Textbox
	 *
	 * @param element
	 * @param elementName
	 */
	public void waitForTextToBePresentInValue(WebElement element, String value, String elementName, long timeout) {
		try {
			WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), timeout);
			wait.ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.textToBePresentInElementValue(element, value));
			log.info("Wait for Text to Present in Value: ", elementName);
		} catch (Exception e) {
			log.error("Wait for Text to Present in Value: ", e);
			throw e;
		}
	}

	/**
	 * Wait Until Element is not present in DOM anymore
	 *
	 * @param element
	 * @param elementName
	 * @throws Exception
	 */
	public void waitForElementToBeNotPresent(WebElement element, String elementName) throws Exception {
		long timeout = explicitPeriod;
		do {
			try {
				if (element.isDisplayed()) {
					Thread.sleep(1000);
				}
				timeout--;
			} catch (NoSuchElementException | StaleElementReferenceException e) {
				log.info("Element is Not Present in DOM ", elementName);
				break;
			} catch (Exception e) {
				log.info("Wait for Element Not Present in DOM failed: ", elementName);
				throw e;
			}
		} while (timeout > 0);
	}

	/**
	 * Wait Until Element is Disabled
	 *
	 * @param element
	 * @param elementName
	 */
	public void waitForElementToBeDisabled(WebElement element, String elementName) {
		try {
			WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), explicitPeriod);
			wait.ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.not(ExpectedConditions.elementToBeClickable(element)));
			log.info("Element is Disabled ", elementName);
		} catch (Exception e) {
			log.info("Element is Disabled: ", elementName);
			throw e;
		}
	}

	/**
	 * Wait For CUBA Loading Bar to Appear
	 *
	 * @throws Exception
	 */
	public void waitForLoadingBarToAppear() throws Exception {
		try {
			long timeout = explicitPeriod;
			WebElement element = driverEngine.getWebDriver()
					.findElement(By.xpath("//div[contains(@class,'v-loading-indicator')]"));
			WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), timeout);
			wait.until(new ExpectedCondition<Boolean>() {

				@Override
				public Boolean apply(WebDriver driver) {
					boolean enabled = element.isDisplayed();
					if (enabled) {
						return true;
					}
					return false;
				}

			});
			log.info("Wait For loading Bar to Finish", "Loading Bar");
		} catch (NoSuchElementException e) {
			log.info("Wait For loading Bar to Finish", "Loading Bar");
		} catch (Exception e) {
			log.error("Wait For loading Bar to Finish", "Loading Bar", e);
			throw e;
		}
	}

	/**
	 * Click WebElement by JS click
	 *
	 * @param element
	 * @param elementName
	 * @throws Exception
	 */
	public void clickBYJS(WebElement element, String elementName) {
		try {
			((JavascriptExecutor) driverEngine.getWebDriver()).executeScript("arguments[0].click();", element);
			log.info("Click by JS on: ", elementName);
		} catch (Exception e) {
			log.error("Click by JS on: ", elementName, e);
			throw e;
		}
	}

	public boolean isDisplayed(WebElement element, String elementName) {
		boolean displayed = false;
		try {
			displayed = element.isDisplayed();
			log.info("Is Element Displayed", elementName);
		} catch (Exception e) {
			log.error("Is element Displayed Check Fail", e);
			throw e;
		}
		return displayed;
	}

	/**
	 * Get Page Source
	 *
	 * @return
	 */
	public String getPageSource() {
		String source = "";
		try {
			source = driverEngine.getWebDriver().getPageSource();
			log.info("Get Page Source ", "");
		} catch (Exception e) {
			log.error("Get Page Source", e);
		}
		return source;
	}

	/**
	 * Click the Specified webElement using Actions class
	 *
	 * @param element
	 * @param elementName
	 */
	public void clickAction(WebElement element, String elementName) {
		try {
			Actions action = new Actions(driverEngine.getWebDriver());
			action.click(element).build().perform();
			log.info("Click By Action ", elementName);
		} catch (Exception e) {
			log.error("Click By Action : ", e);
			throw e;
		}
	}

	/**
	 * Click the Specified webElement using Actions class
	 *
	 * @param element
	 * @param elementName
	 */
	public void rightClickAction(WebElement element, String elementName) {
		try {
			Actions action = new Actions(driverEngine.getWebDriver());
			action.contextClick(element).build().perform();
			log.info("Click By Action ", elementName);
		} catch (Exception e) {
			log.error("Click By Action : ", e);
			throw e;
		}
	}

	/**
	 * Double the Specified webElement using Actions class
	 *
	 * @param element
	 * @param elementName
	 */
	public void doubleClick(WebElement element, String elementName) {
		try {
			Actions action = new Actions(driverEngine.getWebDriver());
			action.doubleClick(element).build().perform();
			log.info("Scroll to WebElement ", elementName);
		} catch (Exception e) {
			log.error("Wait for Element to be Displayed failed: ", e);
			throw e;
		}
	}

	/**
	 * Double the Specified webElement using Actions class
	 *
	 * @param element
	 * @param elementName
	 */
	public void authenticationLogin(String userName, String password) {
		try {
			Alert alert = driverEngine.getWebDriver().switchTo().alert();
			alert.sendKeys(userName + Keys.TAB + password);
			alert.accept();
			log.info("Send Keys to Alert ", "Authentication Alert");
		} catch (Exception e) {
			log.error("Send Keys to Alert ", e);
		}
	}

	/**
	 * Wait Until the WebElement Enabled Property return true while Ignoring
	 * NoSuchElementException
	 *
	 * @param element
	 * @param elementName
	 * @throws Exception
	 */
	public WebElement waitUntilEnabled(WebElement element, String elementName) throws Exception {
		long timeout = explicitPeriod;
		do {
			try {
				TimeUnit.MILLISECONDS.sleep(500);
				if (element.isEnabled()) {
					log.info("Element is Enabled: ", elementName);
					break;
				}
				Thread.sleep(1000);
				timeout--;
			} catch (NoSuchElementException e) {
				Thread.sleep(1000);
				timeout--;
			} catch (Exception e) {
				log.info("Wait for Element to be Enabled failed: ", elementName);
				throw e;
			}
		} while (timeout > 0);
		if (timeout == 0) {
			throw new Exception("Wait for Element to be Enabled: " + elementName);
		}
		return element;
	}

	public void assertDisplayed(WebElement element, String elementName) throws Exception {
		try {
			if (element.isDisplayed() == true) {
				log.info("Element is Displayed: ", elementName);
			} else {
				throw new Exception("Element not Displayed: "+elementName);
			}
		} catch (Exception e) {
			log.info("Assert Displayed Exception Occured: ", elementName);
			throw e;
		}
	}

	public boolean waitForJSandJQueryToLoad() {
		WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), explicitPeriod);
		// wait for jQuery to load
		ExpectedCondition<Boolean> jQueryLoad = new ExpectedCondition<Boolean>() {

			@Override
			public Boolean apply(WebDriver driver) {
				try {
					return ((Long) ((JavascriptExecutor) driverEngine.getWebDriver())
							.executeScript("return jQuery.active") == 0);
				} catch (Exception e) {
					// no jQuery present
					return true;
				}
			}

		};
		// wait for Javascript to load
		ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {

			@Override
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driverEngine.getWebDriver()).executeScript("return document.readyState")
						.toString().equals("complete");
			}

		};
		return wait.until(jQueryLoad) && wait.until(jsLoad);
	}

	/**
	 * Wait Until Element is not DIsplayed
	 *
	 * @param element
	 * @param elementName
	 * @return
	 * @throws Exception
	 */
	public WebElement waitUntilNotDisplayed(WebElement element, String elementName) throws Exception {
		long timeout = explicitPeriod;
		do {
			try {
				if (!element.isDisplayed()) {
					log.info("Element is Not Displayed: ", elementName);
					break;
				}
				Thread.sleep(1000);
				timeout--;
			} catch (Exception e) {
				log.info("Wait for Element to be Not Displayed failed: ", elementName);
				throw e;
			}
		} while (timeout > 0);
		return element;
	}

	/**
	 * Wait Until Element is not DIsplayed
	 *
	 * @param element
	 * @param elementName
	 * @return
	 * @throws Exception
	 */
	public void waitUntilisDisplayed(WebElement element, String elementName) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), explicitPeriod);
			wait.ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.visibilityOf(element));
			log.info("Wait for Element to be displayed ", elementName);
		} catch (Exception e) {
			log.error("Wait for Element to be displayed ", e);
			throw e;
		}
	}

	public void waitUntilListisDisplayed(List<WebElement> elements, String elementName) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), explicitPeriod);
			wait.ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.visibilityOfAllElements(elements));
			log.info("Wait for Element to be displayed ", elementName);
		} catch (Exception e) {
			log.error("Wait for Element to be displayed ", e);
			throw e;
		}
	}
	/**
	 * Wait Until Value of Textbxo is not empty
	 *
	 * @param element
	 * @param elementName
	 * @return
	 * @throws Exception
	 */
	public WebElement waitUntilValueisNotEmpty(WebElement element, String elementName) throws Exception {
		long timeout = explicitPeriod;
		do {
			try {
				if (!element.getAttribute("value").isEmpty()) {
					log.info("Wait for Element Value is not Empty: ", elementName);
					break;
				}
				Thread.sleep(1000);
				timeout--;
			} catch (Exception e) {
				log.info("Wait for Element Value is not Empty: ", elementName);
				throw e;
			}
		} while (timeout > 0);
		return element;
	}

	public void clickByJSAndWaitUntilNotPresent(WebElement element, String elementName) throws Exception {
		clickBYJS(element, elementName);
		waitUntilNotPresent(element, elementName);
	}

	/**
	 * Wait Until Element is not present in DOM
	 *
	 * @param element
	 * @param elementName
	 * @return
	 * @throws Exception
	 */
	public void waitUntilNotPresent(WebElement element, String elementName) throws Exception {
		long timeout = explicitPeriod;
		do {
			try {
				if (element.isDisplayed()) {
					log.info("Element is Not Present in DOM Anymore: ", elementName);
					Thread.sleep(1000);
					timeout--;
				}
			} catch (NoSuchElementException | StaleElementReferenceException e) {
				break;
			} catch (Exception e) {
				log.info("Element is Not Present in DOM Anymore: ", elementName);
				throw e;
			}
		} while (timeout > 0);
		if (timeout == 0) {
			throw new Exception("Timeout while waiting for Element to be not present in DOM");
		}
	}

	/**
	 * Wait Until the Inner text of the WebElement changes
	 *
	 * @param element
	 * @param elementName
	 * @throws Exception
	 */
	public void waitforTextToChange(WebElement element, String elementName, String originaltext) throws Exception {
		long timeout = explicitPeriod;
		do {
			try {
				if (!element.getText().equals(originaltext)) {
					log.info("Element Text Changed ", elementName);
					break;
				}
				Thread.sleep(1000);
			} catch (Exception e) {
				log.info("Wait for Element Text Changed Failed", elementName);
				throw e;
			}
		} while (timeout > 0);
		if (timeout == 0) {
			throw new Exception("Timeout while waiting for Element Text to Change");
		}
	}

	/**
	 * Switch to Other window than current Note: works Properly only when two
	 * windows are open
	 */
	public void switchToOtherOpenedWindow() {
		try {
			Thread.sleep(5000);
			WebDriver driver = driverEngine.getWebDriver();
			String curentHandle = driver.getWindowHandle();
			Set<String> handles = driver.getWindowHandles();
			for (String string : handles) {
				if (!string.equals(curentHandle)) {
					driver.switchTo().window(string);
					break;
				}
			}
			log.info("Switch to newly opened window ", "");
		} catch (Exception e) {
			log.error("Switch to newly opened window ", e);
		}
	}

	/**
	 * Return the Webelement Attribue value as a String
	 *
	 * @param element
	 * @param attribute
	 * @param elementName
	 * @return
	 */
	public String getAttributeValue(WebElement element, String attribute, String elementName) {
		String value = null;
		try {
			value = element.getAttribute(attribute);
			log.info("Get Attribute Value for ", elementName + ": " + value);
		} catch (Exception e) {
			log.error("Get Attribute Value Failed for ", e);
		}
		return value;
	}

	public String getBrowsername() {
		Capabilities cap = ((RemoteWebDriver) driverEngine.getWebDriver().getWrappedDriver()).getCapabilities();
		return cap.getBrowserName().toLowerCase();
	}

	public String getUniqueNumber(){
		String uniqueNumber = "";
		try{
			Date dNow = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("ssMs");
			String s = ft.format(dNow);
			uniqueNumber = s.substring(0, Math.min(s.length(), 4));
			log.info("unique number generated "+uniqueNumber);
		}catch(Exception e){
			log.error("Failed to generate unique number", e);
		}
		return uniqueNumber;
	}

	public void keyBoardEnter(WebElement element, String elementName){
		try{
			element.sendKeys(Keys.ENTER);
			log.info("Pressed keys enter");
		}catch(Exception e){
			log.error("Failed to click on keyboard enter", e);
		}

	}

	public ArrayList<String> getVistDates(List<WebElement> elements, String elementName){
		ArrayList<String> data= new ArrayList<String>();
		List<WebElement> allElement = elements;
		for (WebElement we: allElement) { 
			String txt=we.getText();
			String[] splited = txt.split("\\s+");
			txt=splited[0];
			if(!txt.isEmpty()){
				data.add(txt);
			}
		}
		return data;
	}

	public ArrayList<String> getGenders(List<WebElement> elements){
		ArrayList<String> data= new ArrayList<String>();
		List<WebElement> allElement = elements;
		for (WebElement we: allElement) { 
			String txt=we.getText();
			String[] splited = txt.split("\\n+");
			txt=splited[2];
			String[] splited1 = txt.split("\\s+");
			txt = splited1[0].replaceAll("\\p{P}","");
			data.add(txt);
		}
		return data;
	}

	public ArrayList<String> getDatafromWebTable(List<WebElement> elements){
		ArrayList<String> data= new ArrayList<String>();
		List<WebElement> allElement = elements;
		for (WebElement we: allElement) { 
			String txt=we.getText();
			data.add(txt);
		}
		return data;
	}

	public void selectByVisibleText(WebElement element, String visibleText,String elementName){
		Select dropdown = new Select(element);  
		dropdown.selectByVisibleText(visibleText);  
	}

	public void selectByValue(WebElement element, String value,String elementName){
		Select dropdown = new Select(element);  
		dropdown.selectByValue(value);  
	}

	public void selectByIndex(WebElement element, int index,String elementName){
		Select dropdown = new Select(element);  
		dropdown.selectByIndex(index); 
	}

	/**Get The title of the current page
	 * @return The title of the current page
	 */
	public String getPageTitle(){
		String pageTitle=null;
		try {
			pageTitle=driverEngine.getWebDriver().getTitle();
			log.info("The title of the current page: ", pageTitle);
		} catch (Exception e) {
			log.error("Failed to get the title of the current page ", e);
		}
		return pageTitle;
	}


	public void sendKeysByJS(WebElement element,String data,String elementName){
		try {
			JavascriptExecutor js = (JavascriptExecutor)driverEngine.getWebDriver();
			js.executeScript("arguments[0].value='"+data+"';",element);
			log.info("Entered Value as: ", data);
		} catch (Exception e) {
			log.error("Failed to enter value in to ", elementName, e);
			throw e;
		}
	}

	/**
	 * to select the check box with the given value from multiple check boxes
	 * @param element
	 * @param valueToSelect
	 */
	public void selectCheckBoxfromList(List<WebElement> element, String valueToSelect,String elementName) {
		try {
			List<WebElement> allOptions = element;
			for (WebElement option : allOptions) {
				String optionvalue=option.getText();
				if (valueToSelect.contentEquals(optionvalue)) {
					option.click();
					log.info("Check box is selected: ", elementName);
					break;
				}
			}
		} catch (Exception e) {
			log.error("Failed to select check box: ", elementName, e);
			throw e;
		}
	}

	/**
	 * To compare two array list elements 
	 * @param actData
	 * @param expData
	 * @return the unmatched elements
	 * @throws Exception
	 */
	public ArrayList<String> getUmatchedInArrayComparision(ArrayList<String> actData, ArrayList<String> expData) throws Exception
	{
		ArrayList<String> UnmatchedArray = new ArrayList<String>();
		if(actData!=null && expData!=null &&actData.size()>0&&expData.size()>0 && actData.size()==expData.size()){
			for(int data=0;data<actData.size();data++)
			{
				if(!((actData.get(data)).contains(expData.get(data))))
					UnmatchedArray.add(actData.get(data));	
			}
		}
		else{
			throw new Exception("Arrya Sizes are not matched");
		}
		return UnmatchedArray;			
	}

	public ArrayList<String> isFullArrayMatchWithData(ArrayList<String> actArrayData,String expData) throws Exception
	{
		ArrayList<String> unmatchdata = new ArrayList<String>();
		try {
			if (actArrayData.size()!=0) {
				for (int data = 0; data < actArrayData.size(); data++) {
					if (!actArrayData.get(data).contains(expData)) {
						unmatchdata.add("unmatched data in row no: " + data + " and data: " + actArrayData.get(data));
						log.info(" unmatched data in row no: " + data + " and actual data is : " + actArrayData.get(data)
						+ " is not matched with expected data: " + expData);
					}
				} 
			}else{
				throw new Exception("Actual data is zero");
			}
		} catch (Exception e) {
			throw new Exception(e);
		}
		return unmatchdata;
	}

	/**to convert date from string
	 * @param dateText
	 * @return
	 * @throws ParseException
	 */
	public Date getDate(String dateText) throws ParseException
	{
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		Date date = formatter.parse(dateText);
		return date;
	}

	/**to get System Current Date
	 * @return date
	 */
	public  String getSystemCurrentDate(){
		String sysDate=new SimpleDateFormat("MM/dd/yyyy").format(Calendar.getInstance().getTime());
		return sysDate;	
	}

	/** to get Previous Date
	 * @param days
	 * @return date
	 */
	public String getPreviousDate(int days) throws Exception{	
		SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy");
		Calendar calendar=Calendar.getInstance();
		calendar.add(Calendar.DATE,-days);
		return sdf.format(calendar.getTime());
	}

	/** to get Next Date
	 * @param days
	 * @return date
	 */
	public String getNextDate(int days) throws Exception{	
		SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy");
		Calendar calendar=Calendar.getInstance();
		calendar.add(Calendar.DATE,days);
		return sdf.format(calendar.getTime());
	}


	/**to compare 2 ArrayList elements
	 * @param actData
	 * @param expData
	 * @return
	 * @throws Exception
	 */
	public ArrayList<String> getUmatchedInArrayComparision(List<String> actData, List<String> expData) throws Exception
	{
		ArrayList<String> UnmatchedArray = new ArrayList<String>();
		if(actData!=null && expData!=null &&actData.size()>0&&expData.size()>0 && actData.size()==expData.size()){
			for(int data=0;data<actData.size();data++)
			{
				if(!((actData.get(data)).contentEquals(expData.get(data))))
					UnmatchedArray.add(actData.get(data));	
			}
		}
		else{
			throw new Exception("Arrya Sizes are not matched");
		}
		return UnmatchedArray;			
	}

	/**
	 * Check a Date is between two dates 
	 * @param DateFrom
	 * @param DateTo
	 * @param ListofDates
	 * @return
	 */
	public ArrayList<String> getUnmatchedDatesFromResult(String DateFrom , String DateTo , ArrayList<String> ListofDates) throws ParseException
	{
		ArrayList<String> unmatched = new ArrayList<String>();
		Date DateF = getDate(DateFrom);
		Date DateT = getDate(DateTo);
		for(int date=0;date<ListofDates.size();date++)
		{
			Date arrayDate = getDate(ListofDates.get(date));
			if((arrayDate.before(DateT) && arrayDate.after(DateF)) || (arrayDate.equals(DateT) || arrayDate.equals(DateF)))
			{
			}
			else
			{
				unmatched.add(ListofDates.get(date));
			}
		}
		return unmatched;
	}


	public ArrayList<String> getGridData(WebElement grid_Header,WebElement grid_Results,String columnName,String fieldName) throws Exception 
	{
		ArrayList<String>data=new ArrayList<String>();
		try {
			waitForPageLoaded();
			Integer columnIndex = null;
			List<WebElement> rows_table = grid_Header.findElements(By.tagName("tr"));
			List<WebElement> columns=rows_table.get(0).findElements(By.tagName("th"));
			for(int cnum=0;cnum<columns.size();cnum++)
			{
				String actColumnName = (columns.get(cnum).getText());
				if(actColumnName.toUpperCase().contains(columnName.toUpperCase())){
					columnIndex = cnum;
					break;
				}
			}
			//to get tag name
			String tagName="";
			if("Status".contentEquals(columnName)){
				tagName="span";
			}
			else {
				tagName="div";
			}
			List<WebElement> results_rows_table = grid_Results.findElements(By.tagName("tr"));
			int rowsCount = results_rows_table.size();

			for(int rnum=0;rnum<rowsCount;rnum++){
				List<WebElement> resultsColumns= results_rows_table.get(rnum).findElements(By.tagName("td"));
				List<WebElement> resultsData = (resultsColumns.get(columnIndex).findElements(By.tagName(tagName)));
				for(int i = 0;i<resultsData.size();i++){
					if ("Patient".contentEquals(columnName)) {
						data.addAll(getPatientColumnData(fieldName, i, resultsData));
					}
					else if("Visit".contentEquals(columnName)){
						data.addAll(getVisitColumnData(fieldName, i, resultsData));
					}
					else if("Insurance".contentEquals(columnName)){
						data.addAll(getInsuranceColumnData(fieldName, i, resultsData));
					}
					else if("Last Event".contentEquals(columnName)){
						data.addAll(getLastEventColumnData(fieldName, i, resultsData));
					}
					else{
						scrollBarHandle(resultsData.get(i), columnName);
						String text = resultsData.get(i).getText();
						data.add(text);
						break;
					}
				}
			}
		}catch (Exception e){
			log.error("Failed to get data from ", columnName, e);
			throw new Exception(e);
		}
		return data;
	}

	public ArrayList<String> getPatientColumnData(String fieldName,int rown,List<WebElement> resultsData){
		String text="";
		ArrayList<String>data=new ArrayList<String>();
		if("Patient Name".contentEquals(fieldName)){
			if(rown==1){
				text = resultsData.get(rown).getText();
				data.add(text);
			}
		}
		else if("Account Number".contentEquals(fieldName)){
			if(rown==0){
				text = resultsData.get(rown).getText();
				String[] splited = text.split("\\n+");
				text=splited[1];
				data.add(text);	
			}
		}
		else if("Appointment Number".contentEquals(fieldName)){ 
			if(rown==0){
				text = resultsData.get(rown).getText();
				String[] splited;
				splited = text.split("\\n+");
				text=splited[1];
				splited = text.split("\\s+");
				text=splited[1];
				text = text.replaceAll("\\p{P}","");
				data.add(text);
			}
		}
		else if("Gender".contentEquals(fieldName)){
			if(rown==0){
				String[] splited;
				text = resultsData.get(rown).getText();
				splited = text.split("\\n+");
				text = resultsData.get(2).getText();
				splited = text.split("\\s+");
				text = splited[0].replaceAll("\\p{P}","");
				data.add(text);	
			}
		}
		else if("Date of Birth".contentEquals(fieldName)){
			if(rown==0){
				String[] splited;
				text = resultsData.get(0).getText();
				splited = text.split("\\n+");
				text=splited[2];
				splited = text.split("\\s+");
				text = splited[1];
				data.add(text);
			}
		}
		else if(("SSN".contentEquals(fieldName))|| ("Email".contentEquals(fieldName))){
			if(rown==0){
				try {
					text = resultsData.get(rown).getText();
					String[] splited = text.split("\\n+");
					text=splited[3];
					data.add(text);
				} catch (Exception e) {
				}
			}
		}
		else if("Phone Number".contentEquals(fieldName)){
			if(rown==0){						
				String[] splited;
				text = resultsData.get(rown).getText();
				splited = text.split("\\n+");
				text=splited[3];
				String [] splitM = text.split(":");
				String mobile="";
				String home="";
				try {
					mobile=splitM[1].trim().replaceAll("[-()]","");
				} catch (Exception e) {
				}
				text=splited[4];
				String [] splitH = text.split(":");
				try {
					home=splitH[1].trim().replaceAll("[-()]","");;
				} catch (Exception e) {			
				}							
				data.add(mobile+" "+home);						
			}
		}
		else if("MRN".contentEquals(fieldName)){
			if(rown==0){
				text = resultsData.get(rown).getText();				
				String[] splited = text.split("\\n+");
				text=splited[1];				
				data.add(text);
			}
		}
		return data;
	}

	public ArrayList<String> getVisitColumnData(String fieldName,int row,List<WebElement> resultsData){
		String text="";
		ArrayList<String>data=new ArrayList<String>();
		if("Date of Service".contentEquals(fieldName)){
			if(row==0){
				text = resultsData.get(row).getText();
				String[] splited = text.split("\\s+");
				text=splited[0];
				data.add(text);
			}					
		}
		else if("Facility".contentEquals(fieldName)){
			if (row==2) {
				text = resultsData.get(row).getText();
				data.add(text.replaceAll("\\s(?=[A-Z])|(?<=\\s)\\s+", ""));
			} 
		}
		else if("Location".contentEquals(fieldName)){
			if (row==3) {
				text = resultsData.get(row).getText();
				data.add(text);
			}
		}
		else if(("Patient Type".contentEquals(fieldName))){
			if(row==4){
				text = resultsData.get(row).getText();
				data.add(text);
			}
		}	
		return data;
	}

	public ArrayList<String> getInsuranceColumnData(String fieldName,int row,List<WebElement> resultsData){
		String text="";
		ArrayList<String>data=new ArrayList<String>();
		if(("Primary Insurance".contentEquals(fieldName))){
			if(row==1){
				try {
					text = resultsData.get(row).getText();
					String [] split = text.split(":");
					text=split[1].trim();
					data.add(text);
				} catch (Exception e) {
				}
			}
		}
		else if("Secondary Insurance".contentEquals(fieldName)){
			if(row==2){
				text = resultsData.get(row).getText();
				String [] split = text.split(":");
				text=split[1].trim();
				data.add(text);
			}
		}
		else if("Tertiary Insurance".contentEquals(fieldName)){
			if(row==3){
				text = resultsData.get(row).getText();
				String [] split = text.split(":");
				text=split[1].trim();
				data.add(text);
			}
		}
		return data;
	}

	public ArrayList<String> getLastEventColumnData(String fieldName,int row,List<WebElement> resultsData){
		String text="";
		ArrayList<String>data=new ArrayList<String>();
		if("Event Type".contentEquals(fieldName)){
			if(row==0){
				text = resultsData.get(row).getText();
				String [] split = text.split("\\s+");
				data.add(split[0]);
			}
		}
		else if("Employee".contentEquals(fieldName)){
			if(row==1){
				try {
					text = resultsData.get(row).getText();
					String [] split = text.split(" ");
					text=split[0];
					data.add(text+" "+split[1]);
				} catch (Exception e) {
				}
			}
		}
		return data;
	}

	/** to Enter Values from KeyBoard
	 * @param element
	 * @param value
	 * @param elementName
	 */
	public void enterValuesfromKeyBoard(WebElement element, String value,String elementName){
		try{
			element.sendKeys(Keys.chord(value));
			log.info("value entered");
		}catch(Exception e){
			log.error("Failed to click on keyboard enter", e);
		}

	}

	public void scrollBarHandle(WebElement element, String elementName){
		try{
			((JavascriptExecutor) driverEngine.getWebDriver()).executeScript("arguments[0].scrollIntoView(true);", element);
			log.info("Click by JS on: ", elementName);
		}catch(Exception e){
			log.error("Failed to scroll upto element", e);
		}
	}

	public void scrollUpPage(){
		JavascriptExecutor js = (JavascriptExecutor) driverEngine.getWebDriver();
		// js.executeScript("window.scrollBy(0,-250)", "");
		js.executeScript("scroll(0, -250);");
	}
	public void scrollDownPage(){
		JavascriptExecutor js = (JavascriptExecutor) driverEngine.getWebDriver();
		// js.executeScript("window.scrollBy(0,250)", "");
		js.executeScript("scroll(0, 250);"); 

	}


	/** To get multiple attribute values from web page
	 * @param elements
	 * @param attributeName
	 */
	public ArrayList<String> getListofAttributeValuesfromWebPage(List<WebElement> elements,String attributeName){
		ArrayList<String> data= new ArrayList<String>();
		List<WebElement> allElement = elements;
		for (WebElement we: allElement) { 
			String txt=we.getAttribute(attributeName);
			data.add(txt);
		}
		return data;
	}

	public void pressTab(){
		try{
			Actions act = new Actions(driverEngine.getWebDriver());
			act.sendKeys(Keys.TAB).build().perform();
			log.info("Pressed keys Tab");
		}catch(Exception e){
			log.error("Failed to click on Tab", e);
		}
	}

	public void pressEnter(){
		try{
			Actions act = new Actions(driverEngine.getWebDriver());
			act.sendKeys(Keys.ENTER).build().perform();
			log.info("Pressed keys Enter");
		}catch(Exception e){
			log.error("Failed to click on Enter", e);
		}
	}

	public String getVisitandDischargeDate(String actDate,int hours,int minutes) throws Exception{
		SimpleDateFormat inputDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		SimpleDateFormat outputDate = new SimpleDateFormat("MM/dd/yyy hh:mm a");
		Date date = inputDate.parse(actDate);
		Date newDate = DateUtils.addHours(date, hours);
		newDate = DateUtils.addMinutes(newDate, minutes);
		String expDate = outputDate.format(newDate);
		return expDate;
	}

	public String getEventDateandTimeStamp(String actDate,int hours,int minutes) throws Exception{
		SimpleDateFormat inputDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		SimpleDateFormat outputDate = new SimpleDateFormat("MM/dd/yyy hh:mm:ss:SSS a");
		Date date = inputDate.parse(actDate);
		Date newDate = DateUtils.addHours(date, hours);
		newDate = DateUtils.addMinutes(newDate, minutes);
		String expDate = outputDate.format(newDate);
		return expDate;
	}

	public String getRandomString(int length){
		String alphabet = "abcdefghijklmnopqrstuvwxyz";
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		for(int i = 0; i < length; i++) {
			int index = random.nextInt(alphabet.length());
			char randomChar = alphabet.charAt(index);
			sb.append(randomChar);
		}
		String randomString = sb.toString();
		return randomString;
	}

	/** Get data from any results grid
	 * @param grid_Header
	 * @param grid_Results
	 * @param columnName
	 * @param tagName
	 * @return data
	 * @throws Exception
	 */
	public ArrayList<String> getDataFromResultsGrid(WebElement grid_Header,WebElement grid_Results,String columnName,String tagName) throws Exception 
	{
		ArrayList<String>data=new ArrayList<String>();
		try {
			waitForPageLoaded();
			int columnIndex = 0;
			List<WebElement> columns=grid_Header.findElements(By.tagName("th"));
			for(int cnum=0;cnum<columns.size();cnum++)
			{
				String actColumnName = (columns.get(cnum).getText());
				if(actColumnName.toUpperCase().contains(columnName.toUpperCase())){
					columnIndex = cnum;
					break;
				}
			}
			List<WebElement> results_rows_table = grid_Results.findElements(By.tagName("tr"));
			int rowsCount = results_rows_table.size();
			for(int rnum=0;rnum<rowsCount;rnum++){
				List<WebElement> resultsColumns= results_rows_table.get(rnum).findElements(By.tagName("td"));
				List<WebElement> resultsData = (resultsColumns.get(columnIndex).findElements(By.tagName(tagName)));
				for(int i = 0;i<resultsData.size();i++){
					String text = resultsData.get(i).getText();
					data.add(text);
				}
			}
		}catch (Exception e){
			log.error("Failed to get data from ", columnName, e);
			throw new Exception(e);
		}
		return data;
	}

	//Notepad Read

	public String notepadRead(String notepadname) throws IOException
	{
		String filename=System.getProperty("user.dir")+"\\ExternalTestData\\"+notepadname+".txt";
		BufferedReader br = new BufferedReader(new FileReader(filename));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append("\n");
				line = br.readLine();
			}
			return sb.toString();
		} finally {
			br.close();
		}
	}

	//Notepad Write

	public void notepadWrite(String filename,String subjectmessage) 
	{
		try
		{
			String verify, putData;
			String filepath=System.getProperty("user.dir")+"\\ExternalTestData\\"+filename+".txt";
			File file = new File(filepath);
			file.createNewFile();
			FileWriter fw = new FileWriter(file);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(subjectmessage);
			bw.flush();
			bw.close();
			FileReader fr         = new FileReader(file);
			BufferedReader br     = new BufferedReader(fr);
			while( br.readLine() != null )
			{
				verify = br.readLine();
				if(verify != null)
				{
					putData = verify.replaceAll("here", "there");
					bw.write(putData);
				}
			}
			br.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}

	}

	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}

	public String getCurrentSystemDateTime() throws Exception{
		String dateTime = null;
		try{
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm a");
			LocalDateTime now = LocalDateTime.now();
			dateTime = dtf.format(now);
			log.info("Current Date and Time is :"+dtf.format(now));
		}catch(Exception e){
			log.error("Unable to get the current Date Time",e);
		}
		return dateTime;
	}

	public String getIncreasedCurrentSystemDateTime(int i) throws Exception{
		String increasedCurrentDate = null;
		try{
			Date date = new Date();
			new SimpleDateFormat("yyyy-MM-dd");
			date = DateUtils.addMinutes(date, i);
			increasedCurrentDate = new SimpleDateFormat("MM/dd/yyyy hh:mm a").format(date);
			log.info("increased currentDate: "+increasedCurrentDate);

		}catch(Exception e){
			log.error("unable to add the time",e);
		}
		return increasedCurrentDate;
	}
	//List to Notepad Write
	public void notepadWrite(String filename,ArrayList<String> appoint) 
	{
		try
		{				
			String filepath=System.getProperty("user.dir")+"\\ExternalTestData\\"+filename+".txt";
			File file = new File(filepath);
			file.createNewFile();
			FileWriter fw = new FileWriter(file);
			BufferedWriter writer = new BufferedWriter(fw);
			for(String str: appoint) {
				  writer.write(str + System.lineSeparator());
				}
		
			writer.flush();
			writer.close();				
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}

	}
	//Notepad Read to List

	public ArrayList<String> notepadReadToList(String notepadname) throws IOException
	{
		ArrayList<String> listOfLines = new ArrayList<>();
		String filename=System.getProperty("user.dir")+"\\ExternalTestData\\"+notepadname+".txt";
		BufferedReader bufReader = new BufferedReader(new FileReader(filename));
		try {
			
			 String line = bufReader.readLine();
			 while (line != null) 
			 {
				 listOfLines.add(line);
				 line = bufReader.readLine(); 
				 } 	 
	
		} finally {
			bufReader.close();
		}
		return listOfLines;
	}
	 
	public void waitForframeToBeAvailableAndSwitchToIt(String frameNameOrId) {
			try {
				WebDriverWait wait = new WebDriverWait(driverEngine.getWebDriver(), explicitPeriod);
				 wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameNameOrId));
				log.info("Wait for SwitchTo iFrame: ", frameNameOrId);
			} catch (Exception e) {
				log.error("Wait for SwitchTo iFrame: ", e);
				throw e;
			}
		}
	
	public void switchToiFrame(String nameOrId) {
		try {
			driverEngine.getWebDriver().switchTo().frame(nameOrId);
			log.info("SwitchTo iFrame"+nameOrId);
		} catch (Exception e) {
			log.error("Unable to switch to iFrame", nameOrId, e);
			throw e;
		}
	}
	
	public void switchToiFrame(int index) {
		try {
			driverEngine.getWebDriver().switchTo().frame(index);
			log.info("SwitchTo iFrame"+index);
		} catch (Exception e) {
			log.error("Unable to switch to iFrame", ""+index, e);
			throw e;
		}
	}
	 
	 public void switchTodefaultContent() {
			try {
				driverEngine.getWebDriver().switchTo().defaultContent();
				log.info("Switch to Default Content");
			} catch (Exception e) {
				log.error("Unable to Default Content", "", e);
				throw e;
			}
		}
	 public String getCurrentSystemTime() throws Exception{
			String dateTime = null;
			try{
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("hh:mm a");
				LocalDateTime now = LocalDateTime.now();
				dateTime = dtf.format(now);
				log.info("Current Time is :"+dtf.format(now));
			}catch(Exception e){
				log.error("Unable to get the current Time",e);
			}
			return dateTime;
		}
	 public String getCurrentSystemDate() throws Exception{
			String date = null;
			try{
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
				LocalDateTime now = LocalDateTime.now();
				date = dtf.format(now);
				log.info("Current Date  is :"+dtf.format(now));
			}catch(Exception e){
				log.error("Unable to get the current Date",e);
			}
			return date;
	 }
	 
	public void clearValueAndSendKeys(WebElement element, String value,String elementName){
		clearValue(element, elementName);
		sendKeys(element, value, elementName);
	}

}
