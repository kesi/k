package com.ipas.hf.dbutilities;
import java.sql.SQLException;

import java.sql.Connection;



public class MsSqlConnect {
	private static ConnectionUtil connection = new MsSqlConnectionUtil();

	/**
	 * <p>
	 * This method returns the connection object of MS Access.
	 * </p>
	 * 
	 * @return Returns the {@link Connection} object.
	 * 
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public static Connection getConnection(String database) throws SQLException, ClassNotFoundException {
		return connection.getConnection(database);
	}

	/**
	 * <p>
	 * This method closes the opened connection object of the MS Access.
	 * </p>
	 * 
	 * @throws SQLException
	 */
	public void closeConnection() throws SQLException {
		connection.closeDefaultConnection();
	}
}
