package com.ipas.hf.rest;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.formula.functions.T;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import io.restassured.path.json.JsonPath;

public class JSONUtilities {
	public static String jsonToString(String filepath) {

		try (FileReader reader = new FileReader(filepath)) {
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(reader);
			JSONObject jsonObject = (JSONObject) obj;
			return jsonObject.toString();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return "";

	}

	public T getJSONPath(JsonPath jPath, String pathExpression) {

		T value = null;

		Object pathObject = jPath.get(pathExpression);
		if (pathObject instanceof ArrayList<?>) {
			value = (T) pathObject;
			return value;
		}
		value = (T) pathObject;
		return value;

	}
}

