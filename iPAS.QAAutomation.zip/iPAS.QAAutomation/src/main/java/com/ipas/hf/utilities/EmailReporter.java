package com.ipas.hf.utilities;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class EmailReporter {

  public static void mailTestNGReport(){
    String user = "testingtoolsravi@gmail.com";
    String pass = "satyasai2";
    // Map<String,String> mailTo = new HashMap<String,String>();
    List<String> mailTo = new ArrayList();
    mailTo.add("rmaddula@pelitas.com");
    mailTo.add("vreddy@pelitas.com");
    mailTo.add("rpolisetty@pelitas.com");
    mailTo.add("spatel@pelitas.com");
    mailTo.add("sayyalasomayajula@pelitas.com");

    
   
    
    
    
   
    Properties props = new Properties();
    props.put("mail.smtp.host", "smtp.gmail.com");
    props.put("mail.smtp.port", "587");
    props.put("mail.smtp.auth", "true");
    props.put("mail.smtp.starttls.enable", "true");
    Session session = Session.getInstance(props);
    try {
      session = Session.getInstance(props, new javax.mail.Authenticator() {

        @Override
        protected PasswordAuthentication getPasswordAuthentication(){
          return new PasswordAuthentication(user, pass);
        }

      });
    } catch (Exception e) {
      e.printStackTrace();
    }
    try {
      Message message = new MimeMessage(session);
      message.setFrom(new InternetAddress(user));
      for (String mail : mailTo) {
        message.addRecipient(Message.RecipientType.TO, new InternetAddress(mail));
      }
      DateFormat dfor = new SimpleDateFormat("dd/MM/yyyy");
		Date obj = new Date();
      message.setSubject("Summary Automation Execution Report on: "+dfor.format(obj));
      String filename =
          System.getProperty("user.dir") + "\\target\\SummaryReports\\Summary Report.html";
      BodyPart messageBodyPart1 = new MimeBodyPart();
      messageBodyPart1.setText("Summary Automation Execution Report");
      MimeBodyPart messageBodyPart2 = new MimeBodyPart();
      DataSource source = new FileDataSource(filename);
      messageBodyPart2.setDataHandler(new DataHandler(source));
      messageBodyPart2.setFileName(filename);
      Multipart multipart = new MimeMultipart();
      multipart.addBodyPart(messageBodyPart1);
      multipart.addBodyPart(messageBodyPart2);
      message.setContent(multipart);
      Transport.send(message);
      System.out.println("Mail sent successfully");
    } catch (MessagingException e) {
      e.printStackTrace();
    }
  }

}
