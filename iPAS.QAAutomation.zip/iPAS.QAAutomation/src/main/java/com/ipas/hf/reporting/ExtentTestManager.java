package com.ipas.hf.reporting;

import java.util.HashMap;
import java.util.Map;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

public class ExtentTestManager {

	private static Map<Long, ExtentTest> extentTestMap = new HashMap<Long, ExtentTest>();

	public static void removeTest() {
		extentTestMap.get(Thread.currentThread().getId());
	}

	public static void createTest(String testName) {
		ExtentReports extent = ExtentManager.getInstance();
		ExtentTest test = extent.createTest(testName);
		extentTestMap.put(Thread.currentThread().getId(), test);
	}

	public static ExtentTest getTest() {
		return extentTestMap.get(Thread.currentThread().getId());
	}

	public static void assignCategory(String categoryName) {
		ExtentTest test = extentTestMap.get(Thread.currentThread().getId());
		test.assignCategory(categoryName);
	}
	
	

}
