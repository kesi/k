package com.ipas.hf.rest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.everit.json.schema.Schema;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONTokener;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.Assert;
import org.testng.asserts.Assertion;

import com.google.gson.Gson;
import com.jayway.jsonpath.DocumentContext;
import com.ipas.hf.actions.WebActions;
import com.ipas.hf.azureutilities.CosmosDbDataValidation;
import com.ipas.hf.azureutilities.TodoDaoFactory;
import com.ipas.hf.reporting.StepLogging;

import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.http.Cookie;
import io.restassured.http.Cookies;
import io.restassured.http.Headers;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.QueryableRequestSpecification;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.SpecificationQuerier;

public class RestActions {
	private StepLogging log = StepLogging.getLoggingObject();
	private static FilterableRequestSpecification request;
	private static Response response;
	private JSONObject jsonObject;
	private String requestDataFile = null;
	private static final String SIUJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\SIUEventBasedData.json";
	private static final String ADTJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\ADTEventBasedData.json";
	private static final String SERVICETRACKERJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\ServiceTracker.json";
	private static final String FILTERJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\AccountSearchFilters.json";
	private static final String DIGITALDOCSJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\DigitalDocuments.json";
	private static final String UPDATEPATIENTVISITJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\UpdatePatientVisit.json";
	private static final String TESTDATADIRBODYVALID = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE";
	private static final String TESTDATADIRBODYREQUESTDATA = ".\\src\\main\\resources\\IPASTestData\\Body\\RequestData";
	private static final String TESTDATADIRSCHEMA = ".\\src\\main\\resources\\IPASTestData\\Headers\\Schemas";
	private static final String TESTDATADIRHEADERS = ".\\src\\main\\resources\\IPASTestData\\Headers";
	private static final int CONNECTIONTIMEOUT = 30000;
	private static final int SOCKETTIMEOUT = 30000;
	private static final int CONNECTIONMANAGERTIMEOUT = 30000;
	private static final String PostalADTJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\PostalAddressNotFound.json";
	private static final String PostalAUTOSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\PostalAutoRun.json";
	private static final String PostalAUTOGuarantorJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\PostalAutoGuarantor.json";
	private static final String PostalAUTOPatientAddressJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\PostalAutoPatientAddress.json";
	private static final String IdentityGuarantorValidAddressJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\IdentityVerifierGuarantorValidAddress.json";
	private static final String IdentityPatientValidAddressJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\IdentityVerifierPatientValidAddress.json";
	private static final String IdentityGuarantorInValidAddressJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\IdentityVerifierGuarantorInvalidAddress.json";
	private static final String IdentityPatientInValidAddressJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\IdentityVerifierPatientInValidAddress.json";
	private static final String IdentityPatientdAddressNotMatchJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\IdentityVerifierPatientAddressNotMatch.json";
	private static final String IdentityGuarantordAddressNotMatchJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\IdentityVerifierGuarantorAddressNotMatch.json";
	private static final String IdentityGuarantorHistoricalAddressJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\IdentityVerifierGuarantorHistoricalAddress.json";
	private static final String P2PGuarantorValidAddressJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\P2PGuarantorValidAddress.json";
	private static final String P2PGuarantorInValidAddressJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\P2PGuarantorInValidAddress.json";
	private static final String P2PGuarantorUnwillingJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\P2PGuarantorUnwilling.json";
	private static final String P2PGuarantorWillingJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\P2PGuarantorWilling.json";
	private static final String P2PPatientValidAddress = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\P2PPatientValidAddress.json";
	private static final String P2PPatientInValidAddress = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\P2PPatientInValidAddress.json";
	private static final String P2PPatientUnwilling = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\P2PPatientUnwilling.json";
	private static final String P2PPatientWilling = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\P2PPatientWilling.json";
	private static final String CosmosSIUJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\CosmosDBSIUEvent.json";
	private static final String CosmosADTJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\CosmosDBADTEvent.json";
	private static final String SIUNoObjects = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\SIUNoObjects.json";
	private static final String SIUAllObjects = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\SIUAllObjects.json";
	private static final String ADTNoObjects = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\ADTNoObjects.json";
	private static final String ADTAllObjects = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\ADTAllObjects.json";
	private static final String A03NoObjects = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\A03NoObjects.json";
	private static final String MedicalReview = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\MedicalReview.json";
	private static final String MedicalNotRun = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\MedicalNotRun.json";
	private static final String MedicalFail = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\MedicalFail.json";
	private static final String MedicalClear = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\MedicalClear.json";
	private static final String MedicalReviewManual = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\MedicalReviewManual.json";
	private static final String EstimatorNotRun = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\EstimatorNotRun.json";
	private static final String EstimatorPayerNotActive = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\EstimatorPayerNotActive.json";
	private static final String EstimatorNoInsurance = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\EstimatorNoInsurance.json";
	private static final String EstimatorReview = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\EstimatorReview.json";
	private static final String Financial = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\Financial.json";
	private static final String AddPatientFinancial = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\AddPatientFinancial.json";



	public static RequestSpecification getCreatedRequest() {
		return request;
	}

	public static Response getResponseReceived() {
		return response;
	}

	public void setRequestDataFile(String requestDataFile) {
		this.requestDataFile = requestDataFile;
	}

	public String getRequestDataFile() {
		return requestDataFile;
	}

	public void setRequestTimeout() {

		try {

			request.config(RestAssuredConfig.config().httpClient(
					HttpClientConfig.httpClientConfig().setParam("http.connection.timeout", CONNECTIONTIMEOUT)
					.setParam("http.socket.timeout", SOCKETTIMEOUT)
					.setParam("http.connection-manager.timeout", CONNECTIONMANAGERTIMEOUT)));

			log.info("Set Timeouts ");

		} catch (Exception e) {

			log.error("Set Timeouts Failed :", e);
			throw e;
		}

	}

	/**
	 * Set Base URI for the Request
	 *
	 * @param baseURI
	 */
	public void setBaseURI(String baseURI) {

		try {
			request.baseUri(baseURI);
			log.info("Set Baser URL as", baseURI);

		} catch (Exception e) {

			log.error("Set Base URL as: " + baseURI + " Failed :", e);
			throw e;
		}

	}

	/**
	 * Set Base Path for the Request
	 *
	 * @param basePathTerm
	 */
	public void setBasePath(String basePathTerm) {
		try {
			request.basePath(basePathTerm);
			log.info("Set Base Path as", basePathTerm);
		} catch (Exception e) {

			log.error("Set Base Path as: " + basePathTerm + " Failed :", e);
			throw e;
		}
	}

	/**
	 * Set Path params as a Key Value Pair
	 *
	 * @param param
	 * @param paramValue
	 */
	public void setPathParams(String param, String paramValue) {
		try {
			request.pathParam(param, paramValue);
			log.info("Set Path Param as", param + ":" + paramValue);
		} catch (Exception e) {

			log.error("Set Path Param as", param + ":" + paramValue + " Failed :", e);
			throw e;
		}
	}

	/**
	 * use Relaxed HTTPS validation with the request
	 *
	 */
	public void setRelaxedHTTPSValidationProtocolAsSSL() {

		try {

			request.relaxedHTTPSValidation();
			log.info("Set Relaxed HTTPS Validation Protocol as SSL");
		} catch (Exception e) {

			log.error("Set Relaxed HTTPS Validation Protocol as: SSL Failed :", e);
			throw e;
		}

	}

	/**
	 * Set the Type of Protocol for Relaxed Validation
	 *
	 * @param protocol
	 */
	public void setRelaxedHTTPSValidationProtocol(String protocol) {

		try {

			request.relaxedHTTPSValidation(protocol);
			log.info("Set Relaxed HTTPS Validation Protocol as ", protocol);
		} catch (Exception e) {

			log.error("Set Relaxed HTTPS Validation Protocol as: " + protocol + " Failed :", e);
			throw e;
		}

	}

	/**
	 * Request Setup
	 */
	public void setupRequest() {
		try {

			request = (FilterableRequestSpecification) RestAssured.given();
			log.info("Set Request Specification");
		} catch (Exception e) {

			log.error("SetRequest Specification Failed :", e);
			throw e;
		}
	}

	/**
	 * get a random string uuid
	 *
	 * @return
	 */
	public String getUUID() {

		String uuid = UUID.randomUUID().toString();
		log.info("UUID ", uuid);
		return uuid;

	}

	/**
	 * Add A Map which contains the headers to be added to the Request
	 *
	 * @param map
	 */
	public void addHeadersToRequest(Map<String, String> map) {

		try {
			Set<String> keys = map.keySet();
			for (String key : keys) {
				if (map.get(key).contains(",")) {
					List<String> multiValues = Arrays.asList(map.get(key).split(","));

					addHeader(key, "", multiValues.toString());
				} else {
					addHeader(key, map.get(key));
				}
			}

			log.info("Add Header Map to Specification");

		} catch (Exception e) {

			log.error("Add Header Map to Specification Failed :", e);
			throw e;
		}

	}

	public Map<String, String> getHeadersMapFromProperties(String headerFIleName) throws Exception {
		File folder = null;
		File rFile = null;
		try {
			folder = new File(TESTDATADIRHEADERS);
			File[] listOfFiles = folder.listFiles();

			for (File file : listOfFiles) {

				if (file.getName().replace(".properties", "").equals(headerFIleName)) {
					rFile = file;
					break;
				}

			}
			Properties properties = new Properties();
			try (FileReader reader = new FileReader(rFile)) {
				properties.load(reader);
				log.info("Load properties file for: " + headerFIleName);

			}
			Map<String, String> propMap = new HashMap<String, String>();
			Enumeration<?> propKeys = properties.propertyNames();
			while (propKeys.hasMoreElements()) {
				String key = (String) propKeys.nextElement();
				if (properties.getProperty(key).contains("uuid")) {
					propMap.put(key, getUUID());
				} else {
					propMap.put(key, properties.getProperty(key));
				}
			}
			return propMap;
		} catch (Exception e) {

			log.error("Add Properties Header Fiel to Map for " + headerFIleName + "Failed :", e);
			throw e;
		}

	}

	/**
	 * Add String body to the Request
	 *
	 * @param body
	 * @return
	 */
	public RequestSpecification addRequestBody(String body) {

		try {

			request.body(body);
			log.info("Add Body to Specification");
		} catch (Exception e) {

			log.error("Add Body to Specification Failed :", e);
			throw e;
		}
		return request;
	}

	/**
	 * Performa Get Request by the input path and set the response
	 *
	 * @param path
	 * @param strings
	 * @return
	 */
	public Response getResponsebyPath(String path, String... strings) {

		try {

			response = request.get(path, (Object[]) strings);
			log.info("Set Request Specification");
		} catch (Exception e) {

			log.error("SetRequest Specification Failed :", e);
			throw e;
		}
		return response;
	}

	/**
	 * Performa Get Request by the input path and set the response
	 *
	 * @param path
	 * @param strings
	 * @return
	 */
	public Response postResponsebyPath(String path, String... strings) {

		try {

			response = request.post(path, (Object[]) strings);
			log.info("Set Request Specification");
		} catch (Exception e) {

			log.error("SetRequest Specification Failed :", e);
			throw e;
		}
		return response;
	}

	/**
	 * Assert that the status code for the given Request is 200
	 */
	public void assertStatusCode200() {

		int statCode = 0;
		try {
			statCode = getStatusCode();
			Assert.assertEquals(statCode, 200);
			log.info("Assert Status code Expected: 200 Actual: " + statCode);
		} catch (AssertionError e) {

			log.info("Assert Status code Expected: 200 Actual: " + statCode);
			throw e;
		}

	}

	/**
	 * Assert that the status code for the given Request is 201
	 */
	public void assertStatusCode201() {

		int statCode = 0;
		try {
			statCode = getStatusCode();
			Assert.assertEquals(statCode, 201);
			log.info("Assert Status code Expected: 201 Actual: " + statCode);
		} catch (AssertionError e) {

			log.info("Assert Status code Expected: 201 Actual: " + statCode);
			throw e;
		}

	}

	/**
	 * Assert the status code for the given Request
	 */
	public void assertStatusCode(String expectedStatusCode) {

		int statCode = 0;
		try {
			statCode = getStatusCode();
			Assert.assertEquals(statCode + "", expectedStatusCode);
			log.info("Assert Status code Expected: " + expectedStatusCode + " Actual: " + statCode);
		} catch (AssertionError e) {

			log.info("Assert Status code Expected: " + expectedStatusCode + " Actual: " + statCode);
			throw e;
		}

	}

	/**
	 * Get the Status code for the Request
	 *
	 * @return
	 */
	public int getStatusCode() {
		int statCode = 0;
		try {
			statCode = response.statusCode();

			log.info("Get Status code : " + statCode);
		} catch (Exception e) {

			log.error("Get Status code Failed : ", e);
			throw e;
		}
		return statCode;
	}

	/**
	 * Assert Status Line of the Response
	 *
	 * @param statusLine
	 */
	public void assertStatusLine(String statusLine) {

		String statLine = "";
		try {
			statLine = getStatusLine();
			Assert.assertTrue(statLine.contains(statusLine));
			log.info("Assert Status Line Expected: " + statusLine + " Actual: " + statLine);
		} catch (AssertionError e) {

			log.error("Assert Status Line Expected: " + statusLine + " Actual: " + statLine, e);
			throw e;
		}

	}

	public void assertStatusLine200() {

		String statLine = "";
		try {
			statLine = getStatusLine();
			Assert.assertTrue(statLine.contains("200 OK"));
			log.info("Assert Status Line Expected: \"200 OK\" Actual: " + statLine);
		} catch (AssertionError e) {

			log.info("Assert Status Line Expected: \"200 OK\" Actual: " + statLine);
			throw e;
		}

	}

	/**
	 * Get the Status Line for the Request
	 *
	 * @return
	 */
	public String getStatusLine() {
		String statLine = "";
		try {

			statLine = response.statusLine();

			log.info("Get Status Line : " + statLine);
		} catch (Exception e) {

			log.error("Get Status code Line : ", e);
			throw e;
		}
		return statLine;
	}

	/**
	 * Get Respsone as a string
	 *
	 * @return
	 */
	public String getResponseAsString() {
		String responseString = null;
		try {
			responseString = response.asString();

			log.info("Get Response as String");
		} catch (Exception e) {

			log.error("Get Response as String Failed ", e);
			throw e;
		}
		return responseString;
	}

	/**
	 * Get Response Body
	 *
	 * @return
	 */
	public String getResponsebody() {
		String responseString = null;
		try {
			responseString = response.getBody().asString();

			log.info("Get Response as String");
		} catch (Exception e) {

			log.error("Get Response as String Failed ", e);
			throw e;
		}
		return responseString;
	}

	/**
	 * Get JsonPath from the Resposne
	 *
	 * @return
	 */
	public JsonPath getJsonPathFromResponse() {
		JsonPath jPath = null;
		try {
			if (response != null) {
				jPath = response.jsonPath();
			}

			log.info("Get Response as   JSON path");
		} catch (Exception e) {
			log.error("Get Response as JSON Path Failed ", e);
			throw e;
		}
		return jPath;
	}

	/**
	 * Get a Object by JSONPATH
	 *
	 * @param path
	 * @return
	 */
	public Object getObjectByJSONPath(String path) {
		Object object = null;
		try {
			JsonPath jPath = getJsonPathFromResponse();
			object = jPath.get(path);

			log.info("Get Object by JSON path");
		} catch (Exception e) {
			log.error("Get Object by JSON path Failed ", e);
			throw e;
		}
		return object;
	}

	/**
	 * Get String value by JSONPath
	 *
	 * @param path
	 * @return
	 */
	public String getValueByJSONPath(String path) {
		String value = null;
		try {
			JsonPath jPath = getJsonPathFromResponse();
			value = jPath.get(path);

			log.info("Get Object by JSON path");
		} catch (Exception e) {
			log.error("Get Object by JSON path Failed ", e);
			throw e;
		}
		return value;
	}

	/**
	 * Reset base URL to null
	 */
	public void resetBaseURI() {
		try {
			request.baseUri(null);
			log.info("Reset Base URL ");
		} catch (Exception e) {

			log.error("Reset Base URL  Failed :", e);
			throw e;
		}
	}

	/**
	 * Reset BasePath to null
	 */
	public void resetBasePath() {
		try {
			request.basePath(null);
			log.info("Reset Base Path ");
		} catch (Exception e) {

			log.error("Reset Base Path  Failed :", e);
			throw e;
		}
	}

	/**
	 * Set the content type for the Request
	 *
	 * @param Type
	 */
	public void setContentType(ContentType Type) {
		try {
			request.contentType(Type);
			log.info("Set content type:", Type.toString());
		} catch (Exception e) {

			log.error("Set content type Failed :" + Type.toString(), e);
			throw e;
		}
	}

	/**
	 * Perform a get Request
	 *
	 * @return
	 */
	public Response getRequestResponse() {

		try {
			response = request.get();
			log.info("Get Request Response");
		} catch (Exception e) {

			log.error("Get Request Response Failed :", e);
			throw e;
		}
		return response;
	}

	/**
	 * Set headers for the Request when the header is a multivalue header
	 *
	 * @param key
	 * @param value
	 * @param additionalValues
	 */
	public void addHeader(String key, String value, String... additionalValues) {
		try {
			request.header(key, value, (Object[]) additionalValues);

			log.info("Set Header :" + "Key" + key + "value" + value + "Additional Values: "
					+ additionalValues.toString());
		} catch (Exception e) {

			log.error("Set Header :" + "Key" + key + "value" + value + "Additional Values: "
					+ additionalValues.toString() + "Failed ", e);
			throw e;
		}
	}

	/**
	 * Set headers for the Request when the header is a multivalue header
	 *
	 * @param key
	 * @param value
	 * @param additionalValues
	 */
	public void addHeader(String key, String value) {
		try {
			request.header(key, value);
			log.info("Set Header :" + "Key" + key + "value" + value);
		} catch (Exception e) {

			log.error("Set Header :" + "Key" + key + "value" + value + "Failed ", e);
			throw e;
		}
	}

	/**
	 * Set headers for the Request when the header is a multivalue header
	 *
	 * @param key
	 * @param value
	 * @param additionalValues
	 */
	public void replaceHeader(String key, String value) {
		try {
			request.replaceHeader(key, value);
			log.info("Replace Header :" + "Key" + key + "value" + value);
		} catch (Exception e) {

			log.error("Replace Header :" + "Key" + key + "value" + value + "Failed ", e);
			throw e;
		}
	}

	/**
	 * Get Headers for the Current Request
	 *
	 * @return
	 */
	public Headers getHeadersFromResponse() {
		Headers headers = null;
		try {
			headers = response.getHeaders();
			log.info("Get Response Headers");
		} catch (Exception e) {

			log.error("Get Response Headers Failed ", e);
			throw e;
		}
		return headers;
	}

	/**
	 * Get Hedaers form Respsone by Name
	 *
	 * @param name
	 * @return
	 */
	public String getHeaderFromResponse(String name) {
		String header = null;
		try {
			header = response.getHeader(name);
			log.info("Get Response Header for: " + name);
		} catch (Exception e) {

			log.error("Get Response Header Failed for: " + name, e);
			throw e;
		}
		return header;
	}

	/**
	 * Get Cookie from Resposne By Name
	 *
	 * @param name
	 * @return String
	 */
	public String getCookie(String name) {
		String cookie = null;
		try {
			cookie = response.getCookie(name);
			log.info("Get Response Cookie for: " + name);
		} catch (Exception e) {

			log.error("Get Response Cookie Failed for: " + name, e);
			throw e;
		}
		return cookie;
	}

	/**
	 * Get a Map of Cookies from the Response
	 *
	 * @return cookieList
	 */
	public Map<String, String> getCookies() {
		Map<String, String> cookieList = null;
		try {
			cookieList = response.getCookies();
			log.info("Get Response Cookies List");
		} catch (Exception e) {

			log.error("Get Response Cookies List Failed", e);
			throw e;
		}
		return cookieList;
	}

	/**
	 * Get Detailed cookies from Request
	 *
	 * @return Cookies
	 */
	public Cookies getDetailedCookies() {
		Cookies cookieList = null;
		try {
			cookieList = response.getDetailedCookies();
			log.info("Get Detailed Cookies List");
		} catch (Exception e) {

			log.error("Get Detailed Cookies List Failed", e);
			throw e;
		}
		return cookieList;
	}

	/**
	 * Get Detailed cookies from Request by Name
	 *
	 * @param cookieName
	 * @return
	 */
	public Cookie getDetailedCookies(String cookieName) {
		Cookie cookieList = null;
		try {
			cookieList = response.getDetailedCookie(cookieName);
			log.info("Get Detailed Cookie by Name: " + cookieName);
		} catch (Exception e) {

			log.error("Get Detailed Cookie by Name Failed: " + cookieName, e);
			throw e;
		}
		return cookieList;
	}

	/**
	 * Get the Resposne time for request performed in ms
	 *
	 * @return responseTime in ms
	 */
	public long getResponseTime() {
		long responseTime = 0;
		try {
			responseTime = response.getTime();
			log.info("Get Response Time", responseTime + "");
		} catch (Exception e) {

			log.error("Get Response Time Failed", e);
			throw e;
		}
		return responseTime;
	}

	/**
	 * Get Reponse time fot the performed request in the input Unit
	 *
	 * @param unit
	 * @return
	 */
	public long getResponseTimeinMS(TimeUnit unit) {
		long responseTime = 0;
		try {
			responseTime = response.getTimeIn(unit);

			log.info("Get Response Time", responseTime + "");
		} catch (Exception e) {

			log.error("Get Response Time Failed", e);
			throw e;
		}
		return responseTime;
	}

	/**
	 * Perform the Type of request as the Request type GET,POST,PUT,PATCH,DELETE
	 *
	 * @param requestMethod
	 * @throws Exception
	 */
	public void performRequest(String requestMethod) throws Exception {
		if (requestMethod.toUpperCase().equals("GET")) {
			getRequestResponse();
		} else if (requestMethod.toUpperCase().equals("POST")) {
			postRequest();
		} else if (requestMethod.toUpperCase().equals("PATCH")) {
			patchRequest();
		} else if (requestMethod.toUpperCase().equals("PUT")) {
			putRequest();
		} else if (requestMethod.toUpperCase().equals("DELETE")) {
			deleteRequest();
		} else {
			throw new Exception("Request Method not found: " + requestMethod);
		}
	}

	/**
	 * Peform a Post Request for the request Spefification
	 *
	 * @return
	 */
	public Response postRequest() {

		try {
			response = request.post();

			log.info("Post Request");
		} catch (Exception e) {

			log.error("Post Request Failed", e);
			throw e;
		}
		return response;
	}

	/**
	 * Peform a Put Request for the request Spefification
	 *
	 * @return
	 */
	public Response putRequest() {

		try {
			response = request.put();

			log.info("Put Request");
		} catch (Exception e) {

			log.error("Put Request Failed", e);
			throw e;
		}
		return response;
	}

	/**
	 * Peform a patch Request for the request Spefification
	 *
	 * @return
	 */
	public Response patchRequest() {

		try {
			response = request.patch();

			log.info("Put Request");
		} catch (Exception e) {

			log.error("Put Request Failed", e);
			throw e;
		}
		return response;
	}

	/**
	 * Peform a Delete Request for the request Spefification
	 *
	 * @return
	 */
	public Response deleteRequest() {

		try {
			response = request.delete();

			log.info("Delete Request");
		} catch (Exception e) {

			log.error("Delete Request Failed", e);
			throw e;
		}
		return response;
	}

	/**
	 * Add Query param for the request
	 *
	 * @param queryParamMap
	 * @return
	 */
	public RequestSpecification addQueryParam(Map<String, ?> queryParamMap) {

		try {
			request.queryParams(queryParamMap);

			log.info("Add Query Map to Request");
		} catch (Exception e) {

			log.error("Add Query Map to Request Failed", e);
			throw e;
		}
		return request;
	}

	/**
	 * Add Path param to Request as a key-value
	 *
	 * @param parameterName
	 * @param parameterValue
	 */
	public void addPathParam(String parameterName, String parameterValue) {

		try {
			request.pathParam(parameterName, parameterValue);

			log.info("Add Path Param to Request ");
		} catch (Exception e) {

			log.error("Add Path Param to Request  Failed", e);
			throw e;
		}

	}

	/**
	 * Add Access token to the Request
	 *
	 * @param accessToken
	 */
	public void addAccessToken(String accessToken) {

		try {

			request.auth().oauth2(accessToken);

			log.info("Add Access Token to Request " + accessToken);
		} catch (Exception e) {

			log.error("Add Access Token to Request Failed", e);
			throw e;
		}

	}

	/**
	 * parse the file at input location to JSONObject
	 *
	 * @param filepath
	 * @return JSONObject
	 * @throws Exception
	 */
	public JSONObject jsonToString(String filepath) throws Exception {
		JSONObject jsonObject = null;
		try (FileReader reader = new FileReader(filepath)) {
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(reader);
			jsonObject = (JSONObject) obj;

		} catch (IOException | ParseException e) {
			throw e;
		}
		return jsonObject;

	}

	/**
	 * Set the value for a Existing Key in the JSON with the New Value
	 *
	 * @param jsonString
	 * @param path
	 * @param newValue
	 * @return
	 */
	public String setProperty(String jsonString, String path, String newValue) {
		String nJSON = null;
		try {
			DocumentContext context = com.jayway.jsonpath.JsonPath.parse(jsonString);

			context.set(path, newValue);
			nJSON = context.jsonString();
			log.info("Set Property in JSON at: " + path + " value: " + newValue);
		} catch (Exception e) {
			log.error("Failed to Set Property in JSON at: " + path + " value: " + newValue, e);
			throw e;
		}
		return nJSON;
	}

	/**
	 * Get the content in JSON file as a String from the Test Data Directory
	 *
	 * @param fileName
	 * @return String
	 * @throws Exception
	 */
	public String getRequestBodyJSONString(String fileName) throws Exception {
		File folder = new File(TESTDATADIRBODYVALID);
		File[] listOfFiles = folder.listFiles();

		File rFile = null;
		String text = null;
		for (File file : listOfFiles) {

			if (file.getName().replace(".json", "").equals(fileName)) {
				rFile = file;
				break;
			}

		}
		if (rFile == null) {
			throw new Exception("File with Name: " + fileName + " Not found in Directory: " + TESTDATADIRBODYVALID);
		}
		try (FileReader reader = new FileReader(rFile)) {
			Object object = new JSONParser().parse(reader);
			text = ((JSONObject) object).toJSONString();
			log.info("Parse json to String", fileName);
		} catch (IOException | ParseException e) {
			log.error("Parse json to String Failed: ", e);
			throw e;
		}
		return text;
	}

	public void schemaValidator(String schemaFileName) throws Throwable {
		try (InputStream stream = new FileInputStream(TESTDATADIRSCHEMA + "\\" + schemaFileName + ".json")) {
			InputStream responseJSONStream;
			String resposneJSON = getResponsebody();
			JSONParser pareser = new JSONParser();
			Object responseJSONObj = pareser.parse(resposneJSON);
			if (responseJSONObj instanceof JSONArray) {
				JSONObject object = new JSONObject();
				object = (JSONObject) ((JSONArray) responseJSONObj).get(0);
				responseJSONStream = new ByteArrayInputStream(object.toJSONString().getBytes());
			} else {
				responseJSONStream = new ByteArrayInputStream(resposneJSON.getBytes());
			}
			org.json.JSONObject responseObject = new org.json.JSONObject(new JSONTokener(responseJSONStream));

			org.json.JSONObject expectedJSONSchemaStream = new org.json.JSONObject(new JSONTokener(stream));
			Schema schema = SchemaLoader.load(expectedJSONSchemaStream);

			schema.validate(responseObject);

			log.info("Schema Validation Passed ");
		} catch (Throwable e) {

			log.error("Schema Validation Failed: ", e);
			throw e;
		}
	}

	public void schemaValidator(File schemaFile) throws Throwable {
		try (InputStream stream = new FileInputStream(schemaFile)) {
			String resposneJSON = getResponsebody();
			org.json.JSONObject rawSchema = new org.json.JSONObject(new JSONTokener(stream));
			Schema schema = SchemaLoader.load(rawSchema);
			schema.validate(new org.json.JSONObject(resposneJSON));
			log.info("Schema Validation Passed");
		} catch (Throwable e) {

			log.error("Schema Validation Failed: ", e);
			throw e;
		}
	}

	public String getDataByType(String datatype, String length) {

		String value = null;
		int numericalLength = 0;
		try {
			numericalLength = Integer.parseInt(length);
			if (datatype.toUpperCase().equals("STRING")) {
				value = randomString(numericalLength);

			}
			if (datatype.toUpperCase().equals("ALPHANUMERIC")) {
				value = randomAlphaNumeric(numericalLength);

			}
			if (datatype.toUpperCase().equals("SPECIALCHAR")) {
				value = randomSpecialChar(numericalLength);

			}
			if (datatype.toUpperCase().equals("SPECIALSTRING")) {
				value = randomSpecialCharString(numericalLength);

			}
			if (datatype.toUpperCase().equals("UUID")) {
				value = getUUID();
			}
			log.info("get Data of type: " + datatype + " value: " + value);
			return value;
		} catch (Exception e) {
			log.error("get Data of type:" + datatype + " Failed: ", e);
			throw e;
		}

	}

	public Map<String, String> getTestDataMap(String tcID, String dataRow) throws Exception {

		Map<String, String> map = null;
		try (FileReader file = new FileReader(TESTDATADIRBODYREQUESTDATA + "\\" + requestDataFile + ".json")) {

			JSONParser parser = new JSONParser();

			JSONObject object = (JSONObject) parser.parse(file);
			JSONObject tcData = (JSONObject) object.get(tcID);
			JSONObject iterationData = (JSONObject) tcData.get(dataRow);
			map = new Gson().fromJson(iterationData.toJSONString(), HashMap.class);
			log.info("Get Data Map for Row: " + dataRow + " For TC: " + tcID);
		} catch (Exception e) {
			log.error("Failed to Get Data Map for Row: " + dataRow + " For TC: " + tcID, e);
			throw e;
		}
		return map;
	}

	/**
	 * A string of input length containing chars from [a-z][A-Z]
	 *
	 * @param length
	 * @return
	 */
	public String randomString(int length) {
		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		String generatedString = null;
		Random random = new Random();
		try {
			generatedString = random.ints(leftLimit, rightLimit + 1).limit(length)
					.collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append).toString();
			log.info("Get Random String value: " + generatedString);
		} catch (Exception e) {
			log.error("Get Random String Failed: ", e);
			throw e;
		}
		return generatedString;
	}

	/**
	 * A string of input length containing chars from [a-z][A-Z][1-9]
	 *
	 * @param length
	 * @return
	 */
	public String randomAlphaNumeric(int length) {
		int leftLimit = 48; // letter 'a'
		int rightLimit = 122; // letter 'z'
		String generatedString = null;
		Random random = new Random();
		try {
			generatedString = random.ints(leftLimit, rightLimit + 1).limit(length)
					.collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append).toString();
			log.info("Get Random Alphanumeric value: " + generatedString);
		} catch (Exception e) {
			log.error("Get Random Alphanumeric Failed: ", e);
			throw e;
		}
		return generatedString;
	}

	/**
	 * A string of input length containing special chars from [~!@#$%^&*()_+{}|:?><]
	 *
	 * @param length
	 * @return
	 */
	public String randomSpecialChar(int length) {
		StringBuilder sb = new StringBuilder(length);
		try {
			final String alphabet = "~!@#$%^&*()_+{}|:?><";
			final int N = alphabet.length();
			Random rd = new Random();

			for (int i = 0; i < length; i++) {
				sb.append(alphabet.charAt(rd.nextInt(N)));
			}
			log.info("Get Random Special Characters: " + sb.toString());
		} catch (Exception e) {
			log.error("Get Random Special Characters Failed: ", e);
			throw e;
		}
		return sb.toString();
	}

	/**
	 * A string of input length containing special chars from [~!@#$%^&*()_+{}|:?><]
	 * and Alpahbets from [a-z][A-Z]
	 *
	 * @param length
	 * @return
	 */
	public String randomSpecialCharString(int length) {
		String finalString = null;
		try {
			int chars = length / 2;
			int sprcialChars = length - chars;

			String charString = randomString(chars);
			String specialCharSting = randomSpecialChar(sprcialChars);
			finalString = charString + specialCharSting;
			log.info("Get Random Special Characters: " + finalString);
		} catch (Exception e) {
			log.error("Get Random Special Characters Failed: ", e);
			throw e;
		}
		return finalString;

	}

	/**
	 * Get the Value of a Property by JSONPath as a String
	 *
	 * @param path
	 * @return
	 */
	public String getStringValueFromResponse(String jsonPath) {
		String value = null;
		try {
			String jsonString = getResponsebody();
			DocumentContext context = com.jayway.jsonpath.JsonPath.parse(jsonString);

			value = context.read(jsonPath).toString();

			log.info("Get Property in JSON as String at: " + jsonPath + " value: " + value);
		} catch (Exception e) {
			log.error("Failed to Get Property in JSON as String at: " + jsonPath + " value: ", e);
			throw e;
		}
		return value;
	}


	/**
	 * Get the Value of a Property by JSONPath as a String from a JSON String
	 *
	 * @param path
	 * @return
	 */
	public String getStringValueFromJSONString(String jsonPath, String jsonString) {
		String value = null;
		try {

			DocumentContext context = com.jayway.jsonpath.JsonPath.parse(jsonString);

			value = context.read(jsonPath).toString();

			log.info("Get Property From JSON as String at: " + jsonPath + " value: " + value);
		} catch (Exception e) {
			log.error("Failed to Get Property From JSON as String at: " + jsonPath + " value: ", e);
			throw e;
		}
		return value;
	}

	/**
	 * Get the Body of the Current Request
	 * 
	 * @return
	 */
	public String getRequestBody() {
		String body = null;
		try {
			QueryableRequestSpecification queryable = SpecificationQuerier.query(request);
			if (queryable.getBody() != null) {

				body = queryable.getBody().toString();

			}
			log.info("Get Request Body");
		} catch (Exception e) {
			log.error("Get Request Body Failed", e);
			throw e;
		}
		return body;
	}

	/**
	 * Get Value of the Path param Added in Request
	 * 
	 * @param paramName
	 * @return
	 */
	public String getPathParamValue(String paramName) {
		String value = null;
		try {

			value = request.getPathParams().get(paramName);
			log.info("Get Path Param:" + paramName + " value: " + value);
		} catch (Exception e) {
			log.error("Get Path Param Failed:" + paramName, e);
			throw e;
		}
		return value;

	}

	/**
	 * Remove cookie by Name
	 *
	 * @param cookieName
	 */
	public void removeCookie(String cookieName) {
		try {
			request.removeCookie(cookieName);
			log.info("Remove Cookie: " + cookieName);
		} catch (Exception e) {
			log.error("Remove Cookie Failed:" + cookieName, e);
			throw e;
		}

	}

	/**
	 * Remove cookie
	 *
	 * @param cookieName
	 */
	public void removeCookie(Cookie cookie) {
		try {
			request.removeCookie(cookie);
			log.info("Remove Cookie ");
		} catch (Exception e) {
			log.error("Remove Cookie Failed", e);
			throw e;
		}

	}

	/**
	 * Remove all Cookies
	 */
	public void removeAllCookies() {
		try {
			request.removeCookies();
			log.info("Remove All Cookie: ");
		} catch (Exception e) {
			log.error("Remove All Cookie Failed", e);
			throw e;
		}

	}

	/**
	 * Remove All cookies
	 *
	 * @param parameterName
	 */
	public void removeAllCookies(String parameterName) {
		try {
			request.removeFormParam(parameterName);
			log.info("Remove Form parameter: " + parameterName);
		} catch (Exception e) {
			log.error("Remove Form parameter Failed:" + parameterName, e);
			throw e;
		}

	}

	/**
	 * Remove Header By name
	 *
	 * @param headerName
	 */
	public void removeHeader(String headerName) {
		try {
			request.removeHeader(headerName);
			log.info("Remove Header: " + headerName);
		} catch (Exception e) {
			log.error("Remove Header Failed" + headerName, e);
			throw e;
		}

	}

	/**
	 * Remove All Headers
	 */
	public void removeHeader() {
		try {
			request.removeHeaders();
			log.info("Remove All Header: ");
		} catch (Exception e) {
			log.error("Remove All Header Failed", e);
			throw e;
		}

	}

	/**
	 * Remove All Headers
	 */
	public void removeNamedPathParam(String parameterName) {
		try {
			request.removeNamedPathParam(parameterName);
			log.info("Remove NamedPathParam: " + parameterName);
		} catch (Exception e) {
			log.error("Remove NamedPathParam Failed" + parameterName, e);
			throw e;
		}

	}

	/**
	 * Remove param
	 *
	 * @param parameterName
	 */
	public void removeParam(String parameterName) {
		try {
			request.removeParam(parameterName);
			log.info("Remove Param: " + parameterName);
		} catch (Exception e) {
			log.error("Remove Param Failed" + parameterName, e);
			throw e;
		}

	}

	/**
	 * Remove Path param
	 *
	 * @param pathParameterName
	 */
	public void removePathParam(String pathParameterName) {
		try {
			request.removePathParam(pathParameterName);
			log.info("Remove Path Param: " + pathParameterName);
		} catch (Exception e) {
			log.error("Remove Path Param Failed:" + pathParameterName, e);
			throw e;
		}

	}

	/**
	 * Remove query param
	 *
	 * @param queryParamName
	 */
	public void removeQueryParam(String queryParamName) {
		try {
			request.removeQueryParam(queryParamName);
			log.info("Remove Query Param: " + queryParamName);
		} catch (Exception e) {
			log.error("Remove Query Param Failed:" + queryParamName, e);
			throw e;
		}

	}

	/**
	 * Removed Unnamed Path Param by Name
	 *
	 * @param paramName
	 */
	public void removeUnnamedPathParam(String paramName) {
		try {
			request.removeUnnamedPathParam(paramName);
			log.info("Remove Unnamed Path Param: " + paramName);
		} catch (Exception e) {
			log.error("Remove Unnamed Path Param Failed:" + paramName, e);
			throw e;
		}

	}

	public void removeUnnamedPathParamByValue(String parameterValue) {
		try {
			request.removeUnnamedPathParamByValue(parameterValue);
			log.info("Remove Unnamed Path Param by value: " + parameterValue);
		} catch (Exception e) {
			log.error("Remove Unnamed Path Param by value Failed:" + parameterValue, e);
			throw e;
		}

	}

	@SuppressWarnings("unchecked")
	public void updateSIUJsonFile(String typeSIU) throws ParseException {
		String newNum = "";
		try {
			// read the JSON file
			FileReader reader = new FileReader(SIUJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject appointmentObject = (JSONObject) jsonObject.get("Appointment");

			if (typeSIU.equals("S12")) {
				// Update tenantPatientId
				try {
					String number = getUniqueNumber();
					newNum = "K" + number;					
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}
				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);

				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				try {
					// update appointmentStartDate and appointmentEndDate
					Object appointment = appointmentObject.get("AppointmentStartDate");
					String updatedDates = updatedDateAppointment(appointment);
					appointmentObject.put("AppointmentStartDate", updatedDates);
					appointmentObject.put("AppointmentEndDate", updatedDates);
					String appointmentId = getUniqueAppointmentNumber();				
					appointmentObject.put("AppointmentId", appointmentId);
				} catch (Exception e) {
					log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S12");
					eventObject.put("EventTypeDescription", "New Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}

			} else if (typeSIU.equals("S13")) {
				try {
					// update appointmentStartDate and appointmentEndDate
					Object appointment = appointmentObject.get("AppointmentStartDate");
					String updatedDate = updatedDateAppointment(appointment);
					appointmentObject.put("AppointmentStartDate", updatedDate);
					appointmentObject.put("AppointmentEndDate", updatedDate);
				} catch (Exception e) {
					log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Appointment Rescheduling");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			} else if (typeSIU.equals("S14")) {
				try{
					try {
						// update appointmentStartDate and appointmentEndDate
						Object appointment = appointmentObject.get("AppointmentStartDate");
						String updatedDate = nextDateAppointment(appointment);
						appointmentObject.put("AppointmentStartDate", updatedDate);
						appointmentObject.put("AppointmentEndDate", updatedDate);
					} catch (Exception e) {
						log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
						e.printStackTrace();
					}
					try {
						// update eventTypeCode and eventTypeDescription
						JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
						JSONObject event = (JSONObject) tnasaction.get(0);
						JSONObject eventObject = (JSONObject) event.get("EventType");						
						eventObject.put("EventTypeCode", "S14");
						eventObject.put("EventTypeDescription", "Appointment Modification");
					} catch (Exception e) {
						log.error("Failed to update eventTypeCode", e);
						e.printStackTrace();
					}
				}catch(Exception e){

				}

			} else if (typeSIU.equals("S15")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");
					System.out.println(eventObject.get("EventTypeCode"));
					eventObject.put("EventTypeCode", "S15");
					eventObject.put("EventTypeDescription", "Appointment Cancellation");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}

			} else if (typeSIU.equals("S16")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S16");
					eventObject.put("EventTypeDescription", "Appointment Discontinuation");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeSIU.equals("S17")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S17");
					eventObject.put("EventTypeDescription", "Appointment Deletion");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeSIU.equals("S18")) {		

				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S18");
					eventObject.put("EventTypeDescription", "Addition of Service/resource");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}

			} 
			else if (typeSIU.equals("S19")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S19");
					eventObject.put("EventTypeDescription", "Modification of Service/resource");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}

			} else if (typeSIU.equals("S20")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S20");
					eventObject.put("EventTypeDescription", "Cancellation of Service/resource");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			} else if (typeSIU.equals("S21")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S21");
					eventObject.put("EventTypeDescription", "Discontinuation of Service/resource");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			} 
			else if (typeSIU.equals("S22")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S22");
					eventObject.put("EventTypeDescription", "Deletion of Service/resource");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			} 
			else if (typeSIU.equals("S26")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S26");
					eventObject.put("EventTypeDescription", "Appointment No Show");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			FileWriter file = new FileWriter(SIUJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}

	public String getUniqueNumber() {
		String uniqueNumber = "";
		try {
			Date dNow = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("DDYYHHssMs");
			String s = ft.format(dNow);
			uniqueNumber = s.substring(0, Math.min(s.length(), 10));

		} catch (Exception e) {

		}
		return uniqueNumber;
	}

	public String getUniqueAppointmentNumber() {
		String uniqueNumber = "";
		try {
			Date dNow = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("DDYYHHssMs");
			String s = ft.format(dNow);
			uniqueNumber = s.substring(0, Math.min(s.length(), 10)) + "V2";

		} catch (Exception e) {

		}
		return uniqueNumber;
	}

	public String getCurrentDate() {
		String currentDate = "";
		try {
			Date date = new Date();
			currentDate = new SimpleDateFormat("yyyy-MM-dd").format(date);

		} catch (Exception e) {

		}
		return currentDate;

	}

	public String getCurrentDateTimeStamp() {
		String currentDate = "";
		try {
			Date date = new Date();
			currentDate = new SimpleDateFormat("yyyy/MM/dd HH:MM:SS").format(date);

		} catch (Exception e) {

		}
		return currentDate;

	}

	public String updatedDateAppointment(Object object) {
		String updatedDate = "";
		try {
			String date = object.toString();
			String currentDate = getCurrentDate();
			String array[] = date.split("T");
			updatedDate = currentDate + "T" + array[1];
			log.info("Updated appointment date");			
		} catch (Exception e) {
			log.error("Failed to update appointment date", e);
		}

		return updatedDate;

	}

	public String nextDateAppointment(Object object) {
		String nextDate = "";
		try {
			String dateFromObject = object.toString();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date dates = new Date();
			String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(dates);
			Date date = format.parse(currentDate);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			calendar.add(Calendar.DAY_OF_YEAR, 1);
			String nextDateFirst =  format.format(calendar.getTime()); 
			String array[] = dateFromObject.split("T");
			nextDate = nextDateFirst + "T" + array[1];
			log.info("Updated appointment date");
		} catch (Exception e) {
			log.error("Failed to update appointment date", e);
		}

		return nextDate;

	}

	/** To get the value from JSON response body*/
	public String getValueFromResponseandCompWithExpected(String value){
		String actualValue = "";
		try {
			String Value = getStringValueFromResponse(value);
			actualValue = Value.replaceAll("\\W", "");	
			log.info("Validate Response Body Content Matches the Expected Value: " + value
					+ " Actual value: " + actualValue);
		} catch (AssertionError e) {
			log.error("Validate Response Body Content Matches the Request Failed ", e);
		}
		return actualValue;
	}

	@SuppressWarnings("unchecked")
	public void updateADTJsonFile(String typeADT) throws ParseException {
		String newNum = "";
		try {
			// read the json file
			FileReader reader = new FileReader(ADTJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");			

			if (typeADT.equals("A01")) {
				// Update tenantPatientId
				try {
					String number = getUniqueNumber();
					newNum = "K" + number;
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}

				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);

				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A01");
					eventObject.put("EventTypeDescription", "Admit/visit notification");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("MsgOpt")) {
				// Update tenantPatientId
				try {
					String number = getUniqueNumber();
					newNum = "K" + number;
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}
				try {
					String number = getUniqueNumber();
					JSONArray msg = (JSONArray) patientObject.get("PatientPhoneNumber");
					JSONObject patientPhoneNumber = (JSONObject) msg.get(0);
					patientPhoneNumber.put("PhoneNumber", number);

				} catch (Exception e) {
					log.error("Failed to update patiend mobile number", e);
					e.printStackTrace();
				}
				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);

				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A01");
					eventObject.put("EventTypeDescription", "Admit/visit notification");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}			
			else if (typeADT.equals("A02")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A02");
					eventObject.put("EventTypeDescription", "Transfer a patient");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("A03")) {
				try {
					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDischargeDate",updatedDate);
				} catch (Exception e) {
					log.error("Failed to update visitDischargeDate", e);
					e.printStackTrace();
				}

				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A03");
					eventObject.put("EventTypeDescription", "Discharge/end visit");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("A04")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A04");
					eventObject.put("EventTypeDescription", "Registered");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("A05")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");				
					eventObject.put("EventTypeCode", "A05");
					eventObject.put("EventTypeDescription", "Pre-admit");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			} 
			else if (typeADT.equals("A06")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A06");
					eventObject.put("EventTypeDescription", "Change an outpatient to an inpatient");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("A07")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A07");
					eventObject.put("EventTypeDescription", "Change an inpatient to an outpatient");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			} 
			else if (typeADT.equals("A08")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A08");
					eventObject.put("EventTypeDescription", "Update patient information");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("A09")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A09");
					eventObject.put("EventTypeDescription", "Patient departing - tracking");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			} 
			else if (typeADT.equals("A10")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A10");
					eventObject.put("EventTypeDescription", "Patient arriving - tracking");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("A11")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A11");
					eventObject.put("EventTypeDescription", "Cancel admit/visit");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("A12")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A12");
					eventObject.put("EventTypeDescription", "Cancel transfer");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("A13")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A13");
					eventObject.put("EventTypeDescription", "Cancel discharge/end visit");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("A14")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A14");
					eventObject.put("EventTypeDescription", "Pending admit");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("A15")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A15");
					eventObject.put("EventTypeDescription", "Pending transfer");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("A16")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A16");
					eventObject.put("EventTypeDescription", "Pending discharge");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("A25")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A25");
					eventObject.put("EventTypeDescription", "Cancel pending discharge");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("A26")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");				
					eventObject.put("EventTypeCode", "A26");
					eventObject.put("EventTypeDescription", "Cancel pending transfer");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("A27")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A27");
					eventObject.put("EventTypeDescription", "Cancel pending admit");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (typeADT.equals("A38")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A38");
					eventObject.put("EventTypeDescription", "Cancel pre-admit");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}else if (typeADT.equals("A20")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A20");
					eventObject.put("EventTypeDescription", "Bed status update");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			FileWriter file = new FileWriter(ADTJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}	

	@SuppressWarnings("unchecked")
	public void updateAccountSearchFilterJSON(String genderType) throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(FILTERJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			try {
				String number = getUniqueNumber();
				newNum = "A" + number;
				System.out.println(newNum);
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(0);
				tenantPatient.put("TenantPatientId", newNum);
				String test = (String) tenantPatient.get("TenantPatientId");					
			} catch (Exception e) {
				log.error("Failed to update tenant patiend id", e);
				e.printStackTrace();
			}
			try {
				// update tenantPatientVisitId and visitDate
				JSONArray visit = (JSONArray) visitObject.get("TenantPatientVisitIdentifier");
				JSONObject patientVisit = (JSONObject) visit.get(0);
				patientVisit.put("TenantPatientVisitId", newNum);
				Object tt = visitObject.get("VisitDate");
				String updatedDate = updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);

			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}

			try{
				JSONObject patientGender = (JSONObject)	patientObject.get("PatientGender");
				if ("Other".contentEquals(genderType)) {
					patientGender.put("GenderCode", "O");
					patientGender.put("GenderDescription", genderType);
				}else if("Unknown".contentEquals(genderType)){
					patientGender.put("GenderCode", "U");
					patientGender.put("GenderDescription", genderType);
				}
				else if("Male".contentEquals(genderType)){
					patientGender.put("GenderCode", "M");
					patientGender.put("GenderDescription", genderType);
				}
				else if("Female".contentEquals(genderType)){
					patientGender.put("GenderCode", "F");
					patientGender.put("GenderDescription", genderType);
				}
			}
			catch (Exception e){
				log.error("Failed to update patient Gender infomartion", e);
				e.printStackTrace();
			}

			FileWriter file = new FileWriter(FILTERJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}


	@SuppressWarnings("unchecked")
	public void updateDigitalDocumentsJSON() throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(DIGITALDOCSJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			try {
				String number = getUniqueNumber();
				newNum = "A" + number;
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(0);
				tenantPatient.put("TenantPatientId", newNum);
				String test = (String) tenantPatient.get("TenantPatientId");	
			} catch (Exception e) {
				log.error("Failed to update tenant patiend id", e);
				e.printStackTrace();
			}
			try {
				// update tenantPatientVisitId and visitDate
				JSONArray visit = (JSONArray) visitObject.get("TenantPatientVisitIdentifier");
				JSONObject patientVisit = (JSONObject) visit.get(0);
				patientVisit.put("TenantPatientVisitId", newNum);
				Object tt = visitObject.get("VisitDate");
				String updatedDate = updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);

			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}



			FileWriter file = new FileWriter(DIGITALDOCSJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void ServiceTrackerADTJsonFile(String typeADT) throws ParseException {
		//ServiceTrackerJSON
		String newNum = "";

		try {
			// read the json file
			FileReader reader = new FileReader(SERVICETRACKERJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject visitlocationObject = (JSONObject) visitObject.get("VisitLocation");
			JSONObject LocationObject = (JSONObject) visitlocationObject.get("LocationPointOfCare");
			JSONObject patientGenderObject = (JSONObject) patientObject.get("PatientGender");

			// Update tenantPatientId
			try {
				String number = getUniqueNumber();
				newNum = "A" + number;
				System.out.println(newNum);
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(0);
				tenantPatient.put("TenantPatientId", newNum);
				String test = (String) tenantPatient.get("TenantPatientId");
				JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
				tenantPatientEPI.put("TenantPatientId", newNum);
			} catch (Exception e) {
				log.error("Failed to update tenant patiend id", e);
				e.printStackTrace();
			}

			try {
				// update AccountNumber and visitDate		
				visitObject.put("AccountNumber", newNum);
				visitObject.put("VisitNumber", newNum);
				Object tt = visitObject.get("VisitDate");
				String updatedDate = updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);
			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}


			if (typeADT.equals("A08")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A08");
					eventObject.put("EventTypeDescription", "Admit/visit notification");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}


			}
			else if (typeADT.equals("A38")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A38");
					eventObject.put("EventTypeDescription", "Cancel pre-admit");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			FileWriter file = new FileWriter(SERVICETRACKERJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}


	@SuppressWarnings("unchecked")
	public void updateServiceTrackerPhoneNumber(String mobileNumber) throws ParseException {
		//ServiceTrackerJSON
		try{
			// read the json file
			FileReader reader = new FileReader(SERVICETRACKERJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			try {

				//JSONObject patientPhone = (JSONObject) patientObject.get(0);
				JSONArray patientPhone = (JSONArray) patientObject.get("PatientPhoneNumber");
				JSONObject phoneNumber = (JSONObject) patientPhone.get(0);
				String patientPhoneNumber = (String) phoneNumber.get("PhoneNumber");
				System.out.println("Existing phone number is :"+patientPhoneNumber);
				phoneNumber.put("PhoneNumber",mobileNumber);
				patientPhoneNumber = (String) phoneNumber.get("PhoneNumber");
				System.out.println("Updated phone number is :"+patientPhoneNumber);	
			} catch (Exception e) {
				log.error("Failed to update Phone Number due to :", e);
				e.printStackTrace();
			}
			FileWriter file = new FileWriter(SERVICETRACKERJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();
		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void updateServiceTrackerADTJsonFile(String typeADT,String fieldname) throws ParseException {
		//ServiceTrackerJSON
		String newNum = "";

		try{
			// read the json file
			FileReader reader = new FileReader(SERVICETRACKERJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			//JSONObject patientContactObject = (JSONObject) jsonObject.get("PatientContact");
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject visitlocationObject = (JSONObject) visitObject.get("VisitLocation");
			JSONObject LocationObject = (JSONObject) visitlocationObject.get("LocationPointOfCare");
			JSONObject patientGenderObject = (JSONObject) patientObject.get("PatientGender");						



			if (typeADT.equals("A08")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A08");
					eventObject.put("EventTypeDescription", "Update patient information");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}			
			else if (typeADT.equals("A38")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A38");
					eventObject.put("EventTypeDescription", "Cancel pre-admit");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}

			try {

				@SuppressWarnings("unused")
				ArrayList<String> updateddata = new ArrayList<String>();

				// update FirstName,LastName,Gender,DOB,ProviderFirstName and ProviderLastName
				JSONArray visitProvider = (JSONArray) visitObject.get("VisitProvider");
				JSONObject provider = (JSONObject) visitProvider.get(0);
				JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
				JSONObject event = (JSONObject) tnasaction.get(0);
				String facilitycode = (String) event.get("FacilityCode");				

				if("PatientName".contentEquals(fieldname))
				{
					patientObject.put("PatientFirstName", "Ramya"+randomNumber(4));
					patientObject.put("PatientLastName","Polisetty"+randomNumber(2));
				}
				else if("PatientDateOfBirth".contentEquals(fieldname))
				{
					patientObject.put("patientDateOfBirth","19"+randomNumber(2)+"-07-29");
				}
				else if("Gender".contentEquals(fieldname))
				{
					String Gender =(String) patientGenderObject.get("GenderCode");
					if(Gender.equals("F"))
						patientGenderObject.put("GenderCode","M");
					else if(Gender.equals("M"))
						patientGenderObject.put("GenderCode","F");
				}
				else if("providerName".contentEquals(fieldname))
				{
					provider.put("ProviderFirstName","test"+randomNumber(3));
					provider.put("ProviderLastName","test"+randomNumber(3));
				}
			} catch (Exception e) {
				log.error("Failed to update visitDate and fetch facilitycode and poc code ", e);
				e.printStackTrace();
			}

			FileWriter file = new FileWriter(SERVICETRACKERJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public ArrayList<String> readJSON(String fieldname)
	{
		ArrayList<String> updatedJSONdata = new ArrayList<String>();

		try {
			// read the json file
			FileReader reader = new FileReader(SERVICETRACKERJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject visitlocationObject = (JSONObject) visitObject.get("VisitLocation");
			JSONObject LocationObject = (JSONObject) visitlocationObject.get("LocationPointOfCare");
			JSONObject patientGenderObject = (JSONObject) patientObject.get("PatientGender");

			try {

				// update eventTypeCode and eventTypeDescription
				JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
				JSONObject event = (JSONObject) tnasaction.get(0);
				JSONObject eventObject = (JSONObject) event.get("EventType");					
				eventObject.put("EventTypeCode", "A08");
				eventObject.put("EventTypeDescription", "Update patient information");
			} catch (Exception e) {
				log.error("Failed to update eventTypeCode", e);
				e.printStackTrace();
			}

			try {
				JSONArray visitProvider = (JSONArray) visitObject.get("VisitProvider");
				JSONObject provider = (JSONObject) visitProvider.get(0);
				JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
				JSONObject event = (JSONObject) tnasaction.get(0);
				String facilitycode = (String) event.get("FacilityCode");				
				Object tt = visitObject.get("VisitDate");
				String updatedDate = updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);
				String pointOfCareCode=(String) LocationObject.get("pointofCareCode");
				String firstName1=(String)patientObject.get("PatientFirstName");
				String lastName1 =(String)patientObject.get("PatientLastName");
				String DOB1 =(String) patientObject.get("patientDateOfBirth");//1956-09-29
				String Gender1 =(String) patientGenderObject.get("GenderCode");
				String provFirstName1 = (String) provider.get("ProviderFirstName");
				String provLastName1 = (String) provider.get("ProviderLastName");

				if("PatientName".contentEquals(fieldname))
				{
					updatedJSONdata.add(firstName1);
					updatedJSONdata.add(lastName1);

				}
				else if("PatientDateOfBirth".contentEquals(fieldname))
				{
					String DOB[]=DOB1.split("-");
					String DateOfBirth=DOB[1]+"/"+DOB[2]+"/"+DOB[0];
					updatedJSONdata.add(DateOfBirth);
				}
				else if("Gender".contentEquals(fieldname))
				{
					updatedJSONdata.add(Gender1);

				}
				else if("providerName".contentEquals(fieldname))
				{
					updatedJSONdata.add(provFirstName1);
					updatedJSONdata.add(provLastName1);
				}

			} catch (Exception e) {
				log.error("Failed to update visitDate and fetch facilitycode and poc code ", e);
				e.printStackTrace();
			}
			FileWriter file = new FileWriter(SERVICETRACKERJSONFILE);

			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();
		} 
		catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
		catch (Exception e) {
			// TODO: handle exception
		}	
		return updatedJSONdata;
	}

	@SuppressWarnings("unchecked")
	public void updatePointOfCare(String pocValue)
	{
		try {
			// read the json file
			FileReader reader = new FileReader(SERVICETRACKERJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject visitlocationObject = (JSONObject) visitObject.get("VisitLocation");
			JSONObject LocationObject = (JSONObject) visitlocationObject.get("LocationPointOfCare");
			JSONObject PointOfCareObject = (JSONObject) LocationObject.get("PointofCareCode");
			JSONObject patientGenderObject = (JSONObject) patientObject.get("PatientGender");
			LocationObject.put("PointofCareCode",pocValue);

			// File Writer creates a file in write mode at the given location
			FileWriter file = new FileWriter(SERVICETRACKERJSONFILE);
			file.write(jsonObject.toString());
			file.flush();
		}
		catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}

	/**
	 * A string of input length containing digits from [0-9]
	 *
	 * @param length
	 * @return
	 */

	public String randomNumber(int length) {
		StringBuilder sb = new StringBuilder(length);
		try {
			final String numeric = "1234567890";
			final int N = numeric.length();
			Random rd = new Random();
			for (int i = 0; i < length; i++) {
				sb.append(rd.nextInt(N));
			}

			log.info("Get Random Numbers: " + sb.toString());
		} catch (Exception e) {
			log.error("Get Random Number Failed: ", e);
			throw e;
		}
		return sb.toString();
	}


	@SuppressWarnings("unchecked")
	public void updatePatientVisitADTJsonFile(String typeADT) throws ParseException {
		//ServiceTrackerJSON
		String newNum = "";
		try {
			// read the json file
			FileReader reader = new FileReader(UPDATEPATIENTVISITJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject visitlocationObject = (JSONObject) visitObject.get("VisitLocation");
			JSONObject LocationObject = (JSONObject) visitlocationObject.get("LocationPointOfCare");


			if (typeADT.equals("A08")) {
				try {
					String number = getUniqueNumber();
					newNum = "A" + number;
					System.out.println(newNum);
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatient = (JSONObject) msg.get(0);
					tenantPatient.put("TenantPatientId", newNum);
					String test = (String) tenantPatient.get("TenantPatientId");					
				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}

				try {
					// update tenantPatientVisitId and visitDate
					JSONArray visit = (JSONArray) visitObject.get("TenantPatientVisitIdentifier");
					JSONObject patientVisit = (JSONObject) visit.get(0);
					patientVisit.put("TenantPatientVisitId", newNum);
					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);
				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}


				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A08");
					eventObject.put("EventTypeDescription", "Admit/visit notification");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}


				try {
					// get facility code and Point of care code
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					String facilitycode = (String) event.get("FacilityCode");       
					String pointOfCareCode=(String) LocationObject.get("pointofCareCode");
				} catch (Exception e) {
					log.error("Failed to update visitDate and fetch facilitycode and poc code ", e);
					e.printStackTrace();
				}
			}

			FileWriter file = new FileWriter(UPDATEPATIENTVISITJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}

	}
	@SuppressWarnings("unchecked")
	public void updateInruleSIUJsonFile(String typeSIU) throws ParseException {
		String newNum = "";
		try {
			// read the JSON file
			FileReader reader = new FileReader(SIUJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject appointmentObject = (JSONObject) jsonObject.get("Appointment");


			if (typeSIU.equals("S18")) {
				try {
					String number = getUniqueNumber();
					newNum = "A" + number;					
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);					

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}
				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);

				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				try {
					// update appointmentStartDate and appointmentEndDate
					Object appointment = appointmentObject.get("AppointmentStartDate");
					String updatedDates = updatedDateAppointment(appointment);
					appointmentObject.put("AppointmentStartDate", updatedDates);
					appointmentObject.put("AppointmentEndDate", updatedDates);
					String appointmentId = getUniqueAppointmentNumber();				
					appointmentObject.put("AppointmentId", appointmentId);
				} catch (Exception e) {
					log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
					e.printStackTrace();
				}

				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S18");
					eventObject.put("EventTypeDescription", "Addition of Service/resource");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			} 	

			FileWriter file = new FileWriter(SIUJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void updateInruleADTJsonFile(String typeADT) throws ParseException {
		String newNum = "";
		try {
			// read the json file
			FileReader reader = new FileReader(ADTJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");			

			if (typeADT.equals("A20")) {
				// Update tenantPatientId
				try {
					String number = getUniqueNumber();
					newNum = "A" + number;						
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatient = (JSONObject) msg.get(0);
					tenantPatient.put("TenantPatientId", newNum);
					String test = (String) tenantPatient.get("TenantPatientId");					
				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}

				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);
				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A20");
					eventObject.put("EventTypeDescription", "Bed status update");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			FileWriter file = new FileWriter(ADTJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void updateServiceTrackerJsonFile(String typeADT) throws ParseException {
		//ServiceTrackerJSON
		String newNum = "";

		try{
			// read the json file
			FileReader reader = new FileReader(SERVICETRACKERJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);	       

			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject visitlocationObject = (JSONObject) visitObject.get("VisitLocation");

			if (typeADT.equals("A04")) {
				try {
					System.out.println("Entered A04");
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					event.put("MessageType","ADT");
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A04");
					eventObject.put("EventTypeDescription", "Registered");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}

			else if (typeADT.equals("A08")) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					event.put("MessageType","ADT");
					eventObject.put("EventTypeCode", "A08");
					eventObject.put("EventTypeDescription", "Update patient information");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			FileWriter file = new FileWriter(SERVICETRACKERJSONFILE);
			//File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}


	@SuppressWarnings("unchecked")
	public void updateSIUToADT(String typeADT,String typeDesc)
	{
		try {
			// read the json file
			FileReader reader = new FileReader(SIUJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON

			JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
			JSONObject event = (JSONObject) tnasaction.get(0);
			event.put("MessageType","ADT");
			JSONObject eventObject = (JSONObject) event.get("EventType");					
			eventObject.put("EventTypeCode",typeADT);
			eventObject.put("EventTypeDescription",typeDesc);

			// File Writer creates a file in write mode at the given location
			FileWriter file = new FileWriter(SIUJSONFILE);
			file.write(jsonObject.toString());
			file.flush();
		}
		catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}


	@SuppressWarnings("unchecked")
	public void updatePostalADTJsonFile(String typeADT,String fileType) throws ParseException {
		String newNum = "";
		FileReader reader =null;
		try {
			// read the json file 
			if(fileType.contentEquals("PostalAuto")){
				reader = new FileReader(PostalAUTOSONFILE);
			}
			else if(fileType.contentEquals("PostalAddressNotFound")){
				reader = new FileReader(PostalADTJSONFILE);
			}
			else if(fileType.contentEquals("PostalAutoGuarantor")){
				reader = new FileReader(PostalAUTOGuarantorJSONFILE);
			}

			else if(fileType.contentEquals("PostalAutoPatientAddress")){
				reader = new FileReader(PostalAUTOPatientAddressJSONFILE);
			}
			else if(fileType.contentEquals("IdentityVerifierGuarantorValidAddress")){
				reader = new FileReader(IdentityGuarantorValidAddressJSONFILE);
			}
			else if(fileType.contentEquals("IdentityVerifierPatientValidAddress")){
				reader = new FileReader(IdentityPatientValidAddressJSONFILE);
			}
			else if(fileType.contentEquals("IdentityVerifierGuarantorInvalidAddress")){
				reader = new FileReader(IdentityGuarantorInValidAddressJSONFILE);
			}
			else if(fileType.contentEquals("IdentityVerifierPatientInValidAddress")){
				reader = new FileReader(IdentityPatientInValidAddressJSONFILE);
			}
			else if(fileType.contentEquals("IdentityVerifierPatientAddressNotMatch")){
				reader = new FileReader(IdentityPatientdAddressNotMatchJSONFILE);
			}
			else if(fileType.contentEquals("IdentityVerifierGuarantorAddressNotMatch")){
				reader = new FileReader(IdentityGuarantordAddressNotMatchJSONFILE);
			}
			else if(fileType.contentEquals("IdentityVerifierGuarantorHistoricalAddress")){
				reader = new FileReader(IdentityGuarantorHistoricalAddressJSONFILE);
			}
			else if(fileType.contentEquals("P2PGuarantorValidAddress")){
				reader = new FileReader(P2PGuarantorValidAddressJSONFILE);
			}
			else if(fileType.contentEquals("P2PGuarantorInValidAddress")){
				reader = new FileReader(P2PGuarantorInValidAddressJSONFILE);
			}
			else if(fileType.contentEquals("P2PGuarantorUnwilling")){
				reader = new FileReader(P2PGuarantorUnwillingJSONFILE);
			}
			else if(fileType.contentEquals("P2PGuarantorWilling")){
				reader = new FileReader(P2PGuarantorWillingJSONFILE);
			}
			else if(fileType.contentEquals("P2PPatientValidAddress")){
				reader = new FileReader(P2PPatientValidAddress);
			}
			else if(fileType.contentEquals("P2PPatientInValidAddress")){
				reader = new FileReader(P2PPatientInValidAddress);
			}
			else if(fileType.contentEquals("P2PPatientUnwilling")){
				reader = new FileReader(P2PPatientUnwilling);
			}
			else if(fileType.contentEquals("P2PPatientWilling")){
				reader = new FileReader(P2PPatientWilling);
			}
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");			

			if (typeADT.equals("A01")) {
				// Update tenantPatientId
				try {
					String number = getUniqueNumber();
					newNum = "K" + number;
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}

				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);
				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A01");
					eventObject.put("EventTypeDescription", "Admit/visit notification");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
				// File Writer creates a file in write mode at the given location
				if(fileType.contentEquals("PostalAuto")){
					FileWriter file =new FileWriter(PostalAUTOSONFILE);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("PostalAddressNotFound")) {
					FileWriter file = new FileWriter(PostalADTJSONFILE);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("PostalAutoGuarantor")) {
					FileWriter file = new FileWriter(PostalAUTOGuarantorJSONFILE);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if(fileType.contentEquals("PostalAutoPatientAddress")){						
					FileWriter file = new FileWriter(PostalAUTOPatientAddressJSONFILE);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("IdentityVerifierGuarantorValidAddress")) {
					FileWriter file = new FileWriter(IdentityGuarantorValidAddressJSONFILE);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("IdentityVerifierPatientValidAddress")) {
					FileWriter file = new FileWriter(IdentityPatientValidAddressJSONFILE);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("IdentityVerifierGuarantorInvalidAddress")) {
					FileWriter file = new FileWriter(IdentityGuarantorInValidAddressJSONFILE);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("IdentityVerifierPatientInValidAddress")) {
					FileWriter file = new FileWriter(IdentityPatientInValidAddressJSONFILE);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("IdentityVerifierPatientAddressNotMatch")) {
					FileWriter file = new FileWriter(IdentityPatientdAddressNotMatchJSONFILE);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("IdentityVerifierGuarantorAddressNotMatch")) {
					FileWriter file = new FileWriter(IdentityGuarantordAddressNotMatchJSONFILE);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("IdentityVerifierGuarantorHistoricalAddress")) {
					FileWriter file = new FileWriter(IdentityGuarantorHistoricalAddressJSONFILE);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("P2PGuarantorValidAddress")) {
					FileWriter file = new FileWriter(P2PGuarantorValidAddressJSONFILE);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("P2PGuarantorInValidAddress")) {
					FileWriter file = new FileWriter(P2PGuarantorInValidAddressJSONFILE);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("P2PGuarantorUnwilling")) {
					FileWriter file = new FileWriter(P2PGuarantorUnwillingJSONFILE);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("P2PGuarantorWilling")) {
					FileWriter file = new FileWriter(P2PGuarantorWillingJSONFILE);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("P2PPatientValidAddress")) {
					FileWriter file = new FileWriter(P2PPatientValidAddress);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("P2PPatientInValidAddress")) {
					FileWriter file = new FileWriter(P2PPatientInValidAddress);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("P2PPatientUnwilling")) {
					FileWriter file = new FileWriter(P2PPatientUnwilling);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("P2PPatientWilling")) {
					FileWriter file = new FileWriter(P2PPatientWilling);
					file.write(jsonObject.toString());
					file.flush();
				}
			}
		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}



	}
	public String updateAppointmentDuration() {
		String uniqueNumber = "";
		try {
			Date dNow = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("DDYYHHssMs");
			String s = ft.format(dNow);
			uniqueNumber = s.substring(0, Math.min(s.length(), 2));

		} catch (Exception e) {

		}
		return uniqueNumber;
	}
	@SuppressWarnings("unchecked")
	public void cosmosSIUJsonFile(String type) throws ParseException {
		String newNum = "";
		try {
			// read the JSON file
			FileReader reader = new FileReader(CosmosSIUJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject appointmentObject = (JSONObject) jsonObject.get("Appointment");
			JSONArray patientContact = (JSONArray) jsonObject.get("PatientContact");
			JSONArray diagnosis = (JSONArray) jsonObject.get("Diagnosis");
			JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
			JSONArray drg = (JSONArray) jsonObject.get("DRG");
			JSONArray observation = (JSONArray) jsonObject.get("Observation");
			JSONObject accident = (JSONObject) jsonObject.get("Accident");
			JSONArray claim = (JSONArray) jsonObject.get("ClaimOccurance");
			JSONArray guarantor = (JSONArray) jsonObject.get("Guarantor");
			JSONArray insu = (JSONArray) jsonObject.get("Insurance");
			JSONArray visitProvider =(JSONArray) visitObject.get("VisitProvider");
			JSONArray procedure = (JSONArray) jsonObject.get("Procedure");


			if (type.equals("S12")) {
				// Update tenantPatientId
				try {
					String number = getUniqueNumber();
					newNum = "K" + number;					
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}
				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);
					visitObject.put("VisitDischargeDate", updatedDate);

				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				try {
					// update appointmentStartDate and appointmentEndDate
					Object appointment = appointmentObject.get("AppointmentStartDate");
					String updatedDates = updatedDateAppointment(appointment);
					appointmentObject.put("AppointmentStartDate", updatedDates);
					appointmentObject.put("AppointmentEndDate", updatedDates);
					String appointmentId = getUniqueAppointmentNumber();				
					appointmentObject.put("AppointmentId", appointmentId);
				} catch (Exception e) {
					log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S12");
					eventObject.put("EventTypeDescription", "New Appointment");
					event.put("MessageType", "SIU");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("Appointment")){
				try {
					int randomNum = ThreadLocalRandom.current().nextInt(1, 59 + 1);
					String str=Integer.toString(randomNum);					
					CosmosDbDataValidation.notepadWrite("hello", str);
					appointmentObject.put("AppointmentDuration", str);
				} catch (Exception e) {
					log.error("Failed to update appointment time", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Update Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}

			}
			else if(type.equals("Patient")){
				try {
					String name=CosmosDbDataValidation.getRandomString(4);
					patientObject.put("PatientFirstName",name);
					patientObject.put("PatientLastName",name);						
					patientObject.put("PatientEmailAddress",name+"@gmail.com");
					/*JSONObject gender = (JSONObject) patientObject.get("PatientGender");
						gender.put("GenderCode", "F");*/
					JSONArray address = (JSONArray)	patientObject.get("PatientAddress");
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City", name);

				} catch (Exception e) {
					log.error("Failed to update patient information", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Update Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("PatientContact")){
				try {
					String name=CosmosDbDataValidation.getRandomString(5);
					CosmosDbDataValidation.notepadWrite("hello", name);
					JSONObject contactFirstName=(JSONObject) patientContact.get(1);						
					contactFirstName.put("ContactFirstName", name);

				} catch (Exception e) {
					log.error("Failed to update ContactFirstName", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Update Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("VisitProvider")){
				try {
					String name=CosmosDbDataValidation.getRandomString(6);
					CosmosDbDataValidation.notepadWrite("hello", name);						
					JSONObject provider =(JSONObject) visitProvider.get(3);
					provider.put("ProviderLastName", name);

				} catch (Exception e) {
					log.error("Failed to update Admitting provider last name", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Update Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("Insurance")){
				try {
					String name=CosmosDbDataValidation.getRandomString(4);
					CosmosDbDataValidation.notepadWrite("hello", name);						
					JSONObject inusrance = (JSONObject) insu.get(0);
					JSONObject insured=	(JSONObject) inusrance.get("insured");
					JSONObject inusranceAddress=(JSONObject) insured.get("insuredAddress");						
					inusranceAddress.put("city",name);

				} catch (Exception e) {
					log.error("Failed to update insured address", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Update Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("Guarantor")){
				try {
					String name=CosmosDbDataValidation.getRandomString(5);
					CosmosDbDataValidation.notepadWrite("hello", name);						

					JSONObject guaran = (JSONObject) guarantor.get(0);																
					guaran.put("GuarantorSpouseFirstName",name);

				} catch (Exception e) {
					log.error("Failed to update guarantor spouse name", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Update Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("Claim")){
				try {
					String name=CosmosDbDataValidation.getRandomString(3);
					CosmosDbDataValidation.notepadWrite("hello", name);						

					JSONObject claimOccurance = (JSONObject) claim.get(0);																
					claimOccurance.put("OccuranceCode",name);

				} catch (Exception e) {
					log.error("Failed to update claimOccuranceCode", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Update Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("Accident")){
				try {
					String name=CosmosDbDataValidation.getRandomString(3);
					CosmosDbDataValidation.notepadWrite("hello", name);						

					accident.put("AccidentCode",name);

				} catch (Exception e) {
					log.error("Failed to update AccidentCode", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Update Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("Observation")){
				try {
					String name=CosmosDbDataValidation.getRandomString(2);
					CosmosDbDataValidation.notepadWrite("hello", name);						

					JSONObject observa=(JSONObject) observation.get(0);
					observa.put("ObservationType",name);

				} catch (Exception e) {
					log.error("Failed to update observationType", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Update Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("Procedure")){
				try {
					String name=CosmosDbDataValidation.getRandomString(4);
					CosmosDbDataValidation.notepadWrite("hello", name);						

					JSONObject proce=(JSONObject) procedure.get(0);
					proce.put("ProcedureType",name);

				} catch (Exception e) {
					log.error("Failed to update ProcedureType", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Update Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("DRG")){
				try {
					int randomNum = ThreadLocalRandom.current().nextInt(2, 59 + 1);
					String name=Integer.toString(randomNum);							
					CosmosDbDataValidation.notepadWrite("hello", name);				

					JSONObject dr=(JSONObject) drg.get(0);
					dr.put("DRG",name);

				} catch (Exception e) {
					log.error("Failed to update DRG", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Update Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("Diagnosis")){
				try {
					String name=CosmosDbDataValidation.getRandomString(5);
					CosmosDbDataValidation.notepadWrite("hello", name);		
					JSONObject diag=(JSONObject) diagnosis.get(0);
					JSONObject description=(JSONObject) diag.get("DiagnosisDescription");
					description.put("DiagnosisName",name);

				} catch (Exception e) {
					log.error("Failed to update diagnosis description", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Update Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("SIUProcedureCode")){
				try {
					String name=CosmosDbDataValidation.getRandomString(2);
					String code=name+"1K";
					JSONObject inusrance = (JSONObject) insu.get(0);
					JSONObject insured=	(JSONObject) inusrance.get("insured");
					JSONObject inusranceAddress=(JSONObject) insured.get("insuredAddress");						
					inusranceAddress.put("city",name);

				} catch (Exception e) {
					log.error("Failed to update insured address", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Update Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("A08")){
				try {						
					String name=CosmosDbDataValidation.getRandomString(4);
					patientObject.put("PatientFirstName",name);
					patientObject.put("PatientLastName",name);						
					patientObject.put("PatientEmailAddress",name+"@gmail.com");						
					JSONArray address = (JSONArray)	patientObject.get("PatientAddress");
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City", name);
					ArrayList<String> patient=new ArrayList<>();
					String firstName=(String) patientObject.get("PatientFirstName");
					String laststName=(String) patientObject.get("PatientLastName");
					String email=(String) patientObject.get("PatientEmailAddress");
					String city=(String) patientAddress.get("City");
					String appointmentId=(String) appointmentObject.get("AppointmentId");
					patient.add(firstName);
					patient.add(laststName);
					patient.add(email);
					patient.add(city);
					patient.add(appointmentId);
					CosmosDbDataValidation.notepadWrite("hello", patient);

				} catch (Exception e) {
					log.error("Failed to update patient information", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A08");
					eventObject.put("EventTypeDescription", "Update");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("A03")){
				try {						
					String name=CosmosDbDataValidation.getRandomString(4);
					patientObject.put("PatientFirstName",name);
					patientObject.put("PatientLastName",name);						
					patientObject.put("PatientEmailAddress",name+"@gmail.com");						
					JSONArray address = (JSONArray)	patientObject.get("PatientAddress");
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City", name);
					//diagnosis
					JSONObject diag=(JSONObject) diagnosis.get(0);
					JSONObject description=(JSONObject) diag.get("DiagnosisDescription");
					description.put("DiagnosisName",name);
					//DRG
					JSONObject dr=(JSONObject) drg.get(0);
					dr.put("DRG",name);
					//Observation
					JSONObject observa=(JSONObject) observation.get(0);
					observa.put("ObservationType",name);
					//Procedure
					JSONObject proce=(JSONObject) procedure.get(0);
					proce.put("ProcedureType",name);
					//Accident
					accident.put("AccidentCode",name);
					//claimOccurance
					JSONObject claimOccurance = (JSONObject) claim.get(0);																
					claimOccurance.put("OccuranceCode",name);
					//Guarantor
					JSONObject guaran = (JSONObject) guarantor.get(0);																
					guaran.put("GuarantorSpouseFirstName",name);
					//Insurance
					JSONObject inusrance = (JSONObject) insu.get(0);
					JSONObject insured=	(JSONObject) inusrance.get("insured");
					JSONObject inusranceAddress=(JSONObject) insured.get("insuredAddress");						
					inusranceAddress.put("city",name);
					//VisitProvider
					JSONObject provider =(JSONObject) visitProvider.get(3);
					provider.put("ProviderLastName", name);
					//Patient Contact
					JSONObject contactFirstName=(JSONObject) patientContact.get(1);						
					contactFirstName.put("ContactFirstName", name);

				} catch (Exception e) {
					log.error("Failed to update all objects in JSON", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A03");
					eventObject.put("EventTypeDescription", "Update");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("A03Discharge")){
				try {						
					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDischargeDate",updatedDate);

				} catch (Exception e) {
					log.error("Failed to update all objects in JSON", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A03");
					eventObject.put("EventTypeDescription", "Discharge");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("PatientiPAS")){				
				try {
					String number = getUniqueNumber();
					newNum = "K" + number;					
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}
				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);

				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				try {
					// update appointmentStartDate and appointmentEndDate
					Object appointment = appointmentObject.get("AppointmentStartDate");
					String updatedDates = updatedDateAppointment(appointment);
					appointmentObject.put("AppointmentStartDate", updatedDates);
					appointmentObject.put("AppointmentEndDate", updatedDates);
					String appointmentId = getUniqueAppointmentNumber();				
					appointmentObject.put("AppointmentId", appointmentId);
				} catch (Exception e) {
					log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
					e.printStackTrace();
				}
				try {
					ArrayList<String> iPASPatient=CosmosDbDataValidation.notepadReadToList("hello");
					String lastName=iPASPatient.get(0);
					String firstName=iPASPatient.get(1);
					patientObject.put("PatientFirstName",firstName);
					patientObject.put("PatientLastName",lastName);					

				} catch (Exception e) {
					log.error("Failed to update patient information", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Update Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			FileWriter file = new FileWriter(CosmosSIUJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void SIUJsonFile(String type) throws ParseException {
		String newNum = "";
		FileReader reader = null ;
		try {
			// read the JSON file
			if(type.contentEquals("NoObjects")){
				reader = new FileReader(SIUNoObjects);
			}
			else if(type.contentEquals("AllObjects")){
				reader = new FileReader(SIUAllObjects);
			}
			else if(type.contentEquals("NoObjectsSIU")){
				reader = new FileReader(SIUNoObjects);
			}
			else if(type.contentEquals("NoObjectsSIUADT")){
				reader = new FileReader(SIUNoObjects);
			}
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);

			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject appointmentObject = (JSONObject) jsonObject.get("Appointment");
			JSONArray patientContact = (JSONArray) jsonObject.get("PatientContact");
			JSONArray diagnosis = (JSONArray) jsonObject.get("Diagnosis");
			JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
			JSONArray drg = (JSONArray) jsonObject.get("DRG");
			JSONArray observation = (JSONArray) jsonObject.get("Observation");
			JSONObject accident = (JSONObject) jsonObject.get("Accident");
			JSONArray claim = (JSONArray) jsonObject.get("ClaimOccurance");
			JSONArray guarantor = (JSONArray) jsonObject.get("Guarantor");
			JSONArray insu = (JSONArray) jsonObject.get("Insurance");
			JSONArray visitProvider =(JSONArray) visitObject.get("VisitProvider");
			JSONArray procedure = (JSONArray) jsonObject.get("Procedure");


			if (type.equals("NoObjects")) {					// Update tenantPatientId

				try {
					String number = getUniqueNumber();
					newNum = "K" + number;					
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}
				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);

				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				try {
					// update appointmentStartDate and appointmentEndDate
					Object appointment = appointmentObject.get("AppointmentStartDate");
					String updatedDates = updatedDateAppointment(appointment);
					appointmentObject.put("AppointmentStartDate", updatedDates);
					appointmentObject.put("AppointmentEndDate", updatedDates);
					String appointmentId = getUniqueAppointmentNumber();				
					appointmentObject.put("AppointmentId", appointmentId);
				} catch (Exception e) {
					log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S12");
					eventObject.put("EventTypeDescription", "New Appointment");
					event.put("MessageType", "SIU");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.contentEquals("AllObjects")){
				try{
									
					ArrayList<String> visitMatch=CosmosDbDataValidation.notepadReadToList("hello");
					String mr=visitMatch.get(0);
					String epi=visitMatch.get(1);
					String appointID=visitMatch.get(2);
					String accNumber=visitMatch.get(3);
					String vistNumber=visitMatch.get(4);
					String visitDate=visitMatch.get(5);
					String firstName =visitMatch.get(6);
					String lastName =visitMatch.get(7);			
					String email=visitMatch.get(8);
					String city=visitMatch.get(9);
					
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", mr);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", epi);
					appointmentObject.put("AppointmentId",appointID);

					visitObject.put("AccountNumber", accNumber);
					visitObject.put("VisitNumber", vistNumber);
					visitObject.put("VisitDate", visitDate);

					patientObject.put("PatientFirstName", firstName);
					patientObject.put("PatientLastName", lastName);
					patientObject.put("PatientEmailAddress", email);
					JSONArray address=(JSONArray) patientObject.get("PatientAddress");					
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City",city);
					
					
					//String appointmentID=(String) appointmentObject.get("AppointmentId");

					//diagnosis
					JSONObject diag=(JSONObject) diagnosis.get(0);
					JSONObject description=(JSONObject) diag.get("DiagnosisDescription");
					String diaName=(String) description.get("DiagnosisName");
					//DRG
					JSONObject dr=(JSONObject) drg.get(0);
					String drrg=(String) dr.get("DRG");
					//Observation
					JSONObject observa=(JSONObject) observation.get(0);
					String obser=(String) observa.get("ObservationType");
					//Procedure
					//JSONArray procedure=(JSONArray) patientObject.get("Procedure");					
					JSONObject pro =(JSONObject) procedure.get(0);
					String procedureType=(String) pro.get("ProcedureType");
					//Accident
					String acc=(String) accident.get("AccidentCode");
					//claimOccurance
					JSONObject claimOccurance = (JSONObject) claim.get(0);																
					String occ=(String) claimOccurance.get("OccuranceCode");
					//Guarantor
					JSONObject guaran = (JSONObject) guarantor.get(0);																
					String spouse=(String) guaran.get("GuarantorSpouseFirstName");
					//Insurance
					JSONObject inusrance = (JSONObject) insu.get(0);
					JSONObject insured=	(JSONObject) inusrance.get("insured");
					JSONObject inusranceAddress=(JSONObject) insured.get("insuredAddress");						
					String insur=(String) inusranceAddress.get("city");
					//VisitProvider
					JSONObject provider =(JSONObject) visitProvider.get(3);
					String provi=(String) provider.get("ProviderLastName");
					//Patient Contact
					JSONObject contactFirstName=(JSONObject) patientContact.get(1);	
					ArrayList<String> allObjects=new ArrayList<>();
					String contact=(String) contactFirstName.get("ContactFirstName");
					allObjects.add(firstName);
					allObjects.add(lastName);
					allObjects.add(email);
					allObjects.add(city);
					allObjects.add(appointID);
					allObjects.add(diaName);
					allObjects.add(drrg);
					allObjects.add(obser);
					allObjects.add(procedureType);
					allObjects.add(acc);
					allObjects.add(occ);
					allObjects.add(spouse);
					allObjects.add(insur);
					allObjects.add(provi);
					allObjects.add(contact);					
					CosmosDbDataValidation.notepadWrite("hello", allObjects);
				}
				catch(Exception e){
					log.error("Failed to update JSON data", e);
					e.printStackTrace();
				}

				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "New Appointment");
					event.put("MessageType", "SIU");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.contentEquals("NoObjectsSIU")){
				try{

					ArrayList<String> visitMatch=CosmosDbDataValidation.notepadReadToList("hello");
					String mr=visitMatch.get(0);
					String epi=visitMatch.get(1);
					String appointID=visitMatch.get(2);
					String accNumber=visitMatch.get(3);
					String vistNumber=visitMatch.get(4);
					String visitDate=visitMatch.get(5);
					String firstName =visitMatch.get(6);
					String lastName =visitMatch.get(7);			
					String email=visitMatch.get(8);
					String city=visitMatch.get(9);
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", mr);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", epi);
					appointmentObject.put("AppointmentId",appointID);

					visitObject.put("AccountNumber", accNumber);
					visitObject.put("VisitNumber", vistNumber);
					visitObject.put("VisitDate", visitDate);

					patientObject.put("PatientFirstName", firstName);
					patientObject.put("PatientLastName", lastName);
					patientObject.put("PatientEmailAddress", email);
					JSONArray address=(JSONArray) patientObject.get("PatientAddress");					
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City",city);					
				}
				catch(Exception e){
					log.error("Failed to update JSON data", e);
					e.printStackTrace();
				}

				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "New Appointment");
					event.put("MessageType", "SIU");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.contentEquals("NoObjectsSIUADT")){
				try{

					ArrayList<String> visitMatch=CosmosDbDataValidation.notepadReadToList("hello");
					String mr=visitMatch.get(0);
					String epi=visitMatch.get(1);					
					String accNumber=visitMatch.get(2);
					String vistNumber=visitMatch.get(3);
					String visitDate=visitMatch.get(4);
					String firstName =visitMatch.get(5);
					String lastName =visitMatch.get(6);			
					String email=visitMatch.get(7);
					String city=visitMatch.get(8);
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", mr);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", epi);

					visitObject.put("AccountNumber", accNumber);
					visitObject.put("VisitNumber", vistNumber);
					visitObject.put("VisitDate", visitDate);

					patientObject.put("PatientFirstName", firstName);
					patientObject.put("PatientLastName", lastName);
					patientObject.put("PatientEmailAddress", email);
					JSONArray address=(JSONArray) patientObject.get("PatientAddress");					
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City",city);					
				}
				catch(Exception e){
					log.error("Failed to update JSON data", e);
					e.printStackTrace();
				}
				try {
					// update appointmentStartDate and appointmentEndDate
					Object appointment = appointmentObject.get("AppointmentStartDate");
					String updatedDates = updatedDateAppointment(appointment);
					appointmentObject.put("AppointmentStartDate", updatedDates);
					appointmentObject.put("AppointmentEndDate", updatedDates);
					String appointmentId = getUniqueAppointmentNumber();				
					appointmentObject.put("AppointmentId", appointmentId);
				} catch (Exception e) {
					log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "Update Appointment");
					event.put("MessageType", "SIU");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			if(type.contentEquals("NoObjects")){
				FileWriter file = new FileWriter(SIUNoObjects);
				// File Writer creates a file in write mode at the given location
				file.write(jsonObject.toString());
				file.flush();
			}
			else if(type.contentEquals("AllObjects")){
				FileWriter file = new FileWriter(SIUAllObjects);
				// File Writer creates a file in write mode at the given location
				file.write(jsonObject.toString());	
				file.flush();
			}
			else if(type.contentEquals("NoObjectsSIU")){
				FileWriter file = new FileWriter(SIUNoObjects);
				// File Writer creates a file in write mode at the given location
				file.write(jsonObject.toString());	
				file.flush();
			}
			else if(type.contentEquals("NoObjectsSIUADT")){
				FileWriter file = new FileWriter(SIUNoObjects);
				// File Writer creates a file in write mode at the given location
				file.write(jsonObject.toString());	
				file.flush();
			}

		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void cosmosADTJsonFile(String type) throws ParseException {
		String newNum = "";
		try {
			// read the JSON file
			FileReader reader = new FileReader(CosmosADTJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");			
			JSONArray patientContact = (JSONArray) jsonObject.get("PatientContact");


			if (type.equals("A01")) {
				// Update tenantPatientId
				try {
					String number = getUniqueNumber();
					newNum = "K" + number;					
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}
				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);

				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}				
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A01");
					eventObject.put("EventTypeDescription", "Checked In");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("A08")){
				try {
					ArrayList<String> allInfo=new ArrayList<>();
					String name=CosmosDbDataValidation.getRandomString(4);
					patientObject.put("PatientFirstName",name);
					patientObject.put("PatientLastName",name);						
					patientObject.put("PatientEmailAddress",name+"@gmail.com");
					JSONArray address = (JSONArray)	patientObject.get("PatientAddress");
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City", name);			

					JSONObject contactFirstName=(JSONObject) patientContact.get(1);						
					contactFirstName.put("ContactFirstName", name);					

					JSONArray visitProvider =(JSONArray) visitObject.get("VisitProvider");
					JSONObject provider =(JSONObject) visitProvider.get(3);
					provider.put("ProviderLastName", name);

					JSONArray insu = (JSONArray) jsonObject.get("Insurance");
					JSONObject inusrance = (JSONObject) insu.get(0);
					JSONObject insured=	(JSONObject) inusrance.get("insured");
					JSONObject inusranceAddress=(JSONObject) insured.get("insuredAddress");						
					inusranceAddress.put("city",name);

					JSONArray guarantor = (JSONArray) jsonObject.get("Guarantor");
					JSONObject guaran = (JSONObject) guarantor.get(0);																
					guaran.put("GuarantorSpouseFirstName",name);

					JSONArray claim = (JSONArray) jsonObject.get("ClaimOccurance");
					JSONObject claimOccurance = (JSONObject) claim.get(0);																
					claimOccurance.put("OccuranceCode",name);

					JSONObject accident = (JSONObject) jsonObject.get("Accident");																					
					accident.put("AccidentCode",name);

					JSONArray observation = (JSONArray) jsonObject.get("Observation");
					JSONObject observa=(JSONObject) observation.get(0);
					observa.put("ObservationType",name);

					int randomNum = ThreadLocalRandom.current().nextInt(2, 59 + 1);
					String name1=Integer.toString(randomNum);				
					JSONArray drg = (JSONArray) jsonObject.get("DRG");
					JSONObject dr=(JSONObject) drg.get(0);
					dr.put("DRG",name1);


					JSONArray diagnosis = (JSONArray) jsonObject.get("Diagnosis");
					JSONObject diag=(JSONObject) diagnosis.get(0);
					JSONObject description=(JSONObject) diag.get("DiagnosisDescription");
					description.put("DiagnosisName",name);

					allInfo.add((String) patientObject.get("PatientFirstName"));
					allInfo.add((String)patientObject.get("PatientLastName"));
					allInfo.add((String)patientObject.get("PatientEmailAddress"));
					allInfo.add((String)patientAddress.get("City"));
					allInfo.add((String)contactFirstName.get("ContactFirstName"));
					allInfo.add((String)provider.get("ProviderLastName"));
					allInfo.add((String)inusranceAddress.get("city"));
					allInfo.add((String)guaran.get("GuarantorSpouseFirstName"));
					allInfo.add((String)claimOccurance.get("OccuranceCode"));
					allInfo.add((String)accident.get("AccidentCode"));
					allInfo.add((String)observa.get("ObservationType"));
					allInfo.add((String)dr.get("DRG"));
					allInfo.add((String)description.get("DiagnosisName"));

					CosmosDbDataValidation.notepadWrite("hello", allInfo);

				} catch (Exception e) {
					log.error("Failed to update patient information", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A08");
					eventObject.put("EventTypeDescription", "Update");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("A03")){
				try {
					String name=CosmosDbDataValidation.getRandomString(4);
					patientObject.put("PatientFirstName",name);
					patientObject.put("PatientLastName",name);						
					patientObject.put("PatientEmailAddress",name+"@gmail.com");
					JSONArray address = (JSONArray)	patientObject.get("PatientAddress");
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City", name);			

					JSONObject contactFirstName=(JSONObject) patientContact.get(1);						
					contactFirstName.put("ContactFirstName", name);					

					JSONArray visitProvider =(JSONArray) visitObject.get("VisitProvider");
					JSONObject provider =(JSONObject) visitProvider.get(3);
					provider.put("ProviderLastName", name);

					JSONArray insu = (JSONArray) jsonObject.get("Insurance");
					JSONObject inusrance = (JSONObject) insu.get(0);
					JSONObject insured=	(JSONObject) inusrance.get("insured");
					JSONObject inusranceAddress=(JSONObject) insured.get("insuredAddress");						
					inusranceAddress.put("city",name);

					JSONArray guarantor = (JSONArray) jsonObject.get("Guarantor");
					JSONObject guaran = (JSONObject) guarantor.get(0);																
					guaran.put("GuarantorSpouseFirstName",name);

					JSONArray claim = (JSONArray) jsonObject.get("ClaimOccurance");
					JSONObject claimOccurance = (JSONObject) claim.get(0);																
					claimOccurance.put("OccuranceCode",name);

					JSONObject accident = (JSONObject) jsonObject.get("Accident");																					
					accident.put("AccidentCode",name);

					JSONArray observation = (JSONArray) jsonObject.get("Observation");
					JSONObject observa=(JSONObject) observation.get(0);
					observa.put("ObservationType",name);

					int randomNum = ThreadLocalRandom.current().nextInt(2, 59 + 1);
					String name1=Integer.toString(randomNum);				
					JSONArray drg = (JSONArray) jsonObject.get("DRG");
					JSONObject dr=(JSONObject) drg.get(0);
					dr.put("DRG",name1);					

					JSONArray diagnosis = (JSONArray) jsonObject.get("Diagnosis");
					JSONObject diag=(JSONObject) diagnosis.get(0);
					JSONObject description=(JSONObject) diag.get("DiagnosisDescription");
					description.put("DiagnosisName",name);

					JSONArray procedure = (JSONArray) jsonObject.get("Procedure");
					JSONObject proType=(JSONObject) procedure.get(0);
					proType.put("ProcedureType",name);

				} catch (Exception e) {
					log.error("Failed to update patient information", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A03");
					eventObject.put("EventTypeDescription", "Discharge");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("SIUA03")){
				try {					

					String name=CosmosDbDataValidation.getRandomString(4);
					patientObject.put("PatientFirstName",name);
					patientObject.put("PatientLastName",name);						
					patientObject.put("PatientEmailAddress",name+"@gmail.com");
					JSONArray address = (JSONArray)	patientObject.get("PatientAddress");
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City", name);			

					JSONObject contactFirstName=(JSONObject) patientContact.get(1);						
					contactFirstName.put("ContactFirstName", name);					

					JSONArray visitProvider =(JSONArray) visitObject.get("VisitProvider");
					JSONObject provider =(JSONObject) visitProvider.get(3);
					provider.put("ProviderLastName", name);

					JSONArray insu = (JSONArray) jsonObject.get("Insurance");
					JSONObject inusrance = (JSONObject) insu.get(0);
					JSONObject insured=	(JSONObject) inusrance.get("insured");
					JSONObject inusranceAddress=(JSONObject) insured.get("insuredAddress");						
					inusranceAddress.put("city",name);

					JSONArray guarantor = (JSONArray) jsonObject.get("Guarantor");
					JSONObject guaran = (JSONObject) guarantor.get(0);																
					guaran.put("GuarantorSpouseFirstName",name);

					JSONArray claim = (JSONArray) jsonObject.get("ClaimOccurance");
					JSONObject claimOccurance = (JSONObject) claim.get(0);																
					claimOccurance.put("OccuranceCode",name);

					JSONObject accident = (JSONObject) jsonObject.get("Accident");																					
					accident.put("AccidentCode",name);

					JSONArray observation = (JSONArray) jsonObject.get("Observation");
					JSONObject observa=(JSONObject) observation.get(0);
					observa.put("ObservationType",name);

					int randomNum = ThreadLocalRandom.current().nextInt(2, 59 + 1);
					String name1=Integer.toString(randomNum);				
					JSONArray drg = (JSONArray) jsonObject.get("DRG");
					JSONObject dr=(JSONObject) drg.get(0);
					dr.put("DRG",name1);					

					JSONArray diagnosis = (JSONArray) jsonObject.get("Diagnosis");
					JSONObject diag=(JSONObject) diagnosis.get(0);
					JSONObject description=(JSONObject) diag.get("DiagnosisDescription");
					description.put("DiagnosisName",name);					

				} catch (Exception e) {
					log.error("Failed to update patient information", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A03");
					eventObject.put("EventTypeDescription", "Discharge");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("NewA08")){
				try {
					try {
						String number = getUniqueNumber();
						newNum = "K" + number;					
						JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
						JSONObject tenantPatientMR = (JSONObject) msg.get(0);
						tenantPatientMR.put("TenantPatientId", newNum);

						JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
						tenantPatientEPI.put("TenantPatientId", newNum);

					} catch (Exception e) {
						log.error("Failed to update tenant patiend id", e);
						e.printStackTrace();
					}
					try {
						// update AccountNumber,VisitNumber and VisitDate		

						visitObject.put("AccountNumber", newNum);
						visitObject.put("VisitNumber", newNum);

						Object tt = visitObject.get("VisitDate");
						String updatedDate = updatedDateAppointment(tt);
						visitObject.put("VisitDate", updatedDate);

					} catch (Exception e) {
						log.error("Failed to update tenantPatientVisitId and visitDate", e);
						e.printStackTrace();
					}				
					ArrayList<String> allInfo=new ArrayList<>();
					String name=CosmosDbDataValidation.getRandomString(4);
					patientObject.put("PatientFirstName",name);
					patientObject.put("PatientLastName",name);						
					patientObject.put("PatientEmailAddress",name+"@gmail.com");
					JSONArray address = (JSONArray)	patientObject.get("PatientAddress");
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City", name);			

					JSONObject contactFirstName=(JSONObject) patientContact.get(1);						
					contactFirstName.put("ContactFirstName", name);					

					JSONArray visitProvider =(JSONArray) visitObject.get("VisitProvider");
					JSONObject provider =(JSONObject) visitProvider.get(3);
					provider.put("ProviderLastName", name);

					JSONArray insu = (JSONArray) jsonObject.get("Insurance");
					JSONObject inusrance = (JSONObject) insu.get(0);
					JSONObject insured=	(JSONObject) inusrance.get("insured");
					JSONObject inusranceAddress=(JSONObject) insured.get("insuredAddress");						
					inusranceAddress.put("city",name);

					JSONArray guarantor = (JSONArray) jsonObject.get("Guarantor");
					JSONObject guaran = (JSONObject) guarantor.get(0);																
					guaran.put("GuarantorSpouseFirstName",name);

					JSONArray claim = (JSONArray) jsonObject.get("ClaimOccurance");
					JSONObject claimOccurance = (JSONObject) claim.get(0);																
					claimOccurance.put("OccuranceCode",name);

					JSONObject accident = (JSONObject) jsonObject.get("Accident");																					
					accident.put("AccidentCode",name);

					JSONArray observation = (JSONArray) jsonObject.get("Observation");
					JSONObject observa=(JSONObject) observation.get(0);
					observa.put("ObservationType",name);

					int randomNum = ThreadLocalRandom.current().nextInt(2, 59 + 1);
					String name1=Integer.toString(randomNum);				
					JSONArray drg = (JSONArray) jsonObject.get("DRG");
					JSONObject dr=(JSONObject) drg.get(0);
					dr.put("DRG",name1);


					JSONArray diagnosis = (JSONArray) jsonObject.get("Diagnosis");
					JSONObject diag=(JSONObject) diagnosis.get(0);
					JSONObject description=(JSONObject) diag.get("DiagnosisDescription");
					description.put("DiagnosisName",name);

					allInfo.add((String) patientObject.get("PatientFirstName"));
					allInfo.add((String)patientObject.get("PatientLastName"));
					allInfo.add((String)patientObject.get("PatientEmailAddress"));
					allInfo.add((String)patientAddress.get("City"));
					allInfo.add((String)contactFirstName.get("ContactFirstName"));
					allInfo.add((String)provider.get("ProviderLastName"));
					allInfo.add((String)inusranceAddress.get("city"));
					allInfo.add((String)guaran.get("GuarantorSpouseFirstName"));
					allInfo.add((String)claimOccurance.get("OccuranceCode"));
					allInfo.add((String)accident.get("AccidentCode"));
					allInfo.add((String)observa.get("ObservationType"));
					allInfo.add((String)dr.get("DRG"));
					allInfo.add((String)description.get("DiagnosisName"));

					CosmosDbDataValidation.notepadWrite("hello", allInfo);

				} catch (Exception e) {
					log.error("Failed to update patient information", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A08");
					eventObject.put("EventTypeDescription", "Update");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if (type.equals("PatientiPAS")) {
				// Update tenantPatientId
				try {
					String number = getUniqueNumber();
					newNum = "K" + number;					
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}
				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);

				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				try {
					ArrayList<String> iPASPatient=CosmosDbDataValidation.notepadReadToList("hello");
					String lastName=iPASPatient.get(0);
					String firstName=iPASPatient.get(1);
					patientObject.put("PatientFirstName",firstName);
					patientObject.put("PatientLastName",lastName);					

				} catch (Exception e) {
					log.error("Failed to update patient information", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A01");
					eventObject.put("EventTypeDescription", "Checked In");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			FileWriter file = new FileWriter(CosmosADTJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void cosmosSIUADTJsonFile(String type) throws ParseException {

		try {
			// read the JSON file
			FileReader reader = new FileReader(CosmosADTJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");			
			JSONArray patientContact = (JSONArray) jsonObject.get("PatientContact");

			if(type.contentEquals("SIUA03")){
				try {					
					ArrayList<String> visitMatch=CosmosDbDataValidation.notepadReadToList("hello");
					String mr=visitMatch.get(0);
					String epi=visitMatch.get(1);
					String appointID=visitMatch.get(2);
					String accNumber=visitMatch.get(3);
					String vistNumber=visitMatch.get(4);
					String visitDate=visitMatch.get(5);
					String firstName =visitMatch.get(6);
					String lastName =visitMatch.get(7);			
					String email=visitMatch.get(8);
					String city=visitMatch.get(9);
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", mr);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", epi);				

					visitObject.put("AccountNumber", accNumber);
					visitObject.put("VisitNumber", vistNumber);
					visitObject.put("VisitDate", visitDate);
					visitObject.put("VisitDischargeDate", visitDate);

					patientObject.put("PatientFirstName", firstName);
					patientObject.put("PatientLastName", lastName);
					patientObject.put("PatientEmailAddress", email);

				} catch (Exception e) {
					log.error("Failed to update patient information", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A03");
					eventObject.put("EventTypeDescription", "Discharge");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}	
			else if(type.contentEquals("SIUA08")){
				try {					
					ArrayList<String> visitMatch=CosmosDbDataValidation.notepadReadToList("hello");
					String mr=visitMatch.get(0);
					String epi=visitMatch.get(1);
					String appointID=visitMatch.get(2);
					String accNumber=visitMatch.get(3);
					String vistNumber=visitMatch.get(4);
					String visitDate=visitMatch.get(5);
					String firstName =visitMatch.get(6);
					String lastName =visitMatch.get(7);			
					String email=visitMatch.get(8);
					String city=visitMatch.get(9);
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", mr);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", epi);				

					visitObject.put("AccountNumber", accNumber);
					visitObject.put("VisitNumber", vistNumber);
					visitObject.put("VisitDate", visitDate);

					ArrayList<String> allInfo=new ArrayList<>();
					String name=CosmosDbDataValidation.getRandomString(4);
					patientObject.put("PatientFirstName",name);
					patientObject.put("PatientLastName",name);						
					patientObject.put("PatientEmailAddress",name+"@gmail.com");
					JSONArray address = (JSONArray)	patientObject.get("PatientAddress");
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City", name);		

					allInfo.add((String) patientObject.get("PatientFirstName"));
					allInfo.add((String)patientObject.get("PatientLastName"));
					allInfo.add((String)patientObject.get("PatientEmailAddress"));
					allInfo.add((String)patientAddress.get("City"));
					allInfo.add(appointID);

					CosmosDbDataValidation.notepadWrite("hello", allInfo);

				} catch (Exception e) {
					log.error("Failed to update patient information", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A08");
					eventObject.put("EventTypeDescription", "Update Patient Information");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}			
			FileWriter file = new FileWriter(CosmosADTJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void ADTJsonFile(String type) throws ParseException {
		String newNum = "";
		FileReader reader = null ;
		try {
			// read the JSON file
			if(type.contentEquals("NoObjects")){
				reader = new FileReader(SIUNoObjects);
			}
			else if(type.contentEquals("AllObjects")){
				reader = new FileReader(SIUAllObjects);
			}
			else if(type.contentEquals("NoObjectsSIU")){
				reader = new FileReader(SIUNoObjects);
			}
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);

			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject appointmentObject = (JSONObject) jsonObject.get("Appointment");
			JSONArray patientContact = (JSONArray) jsonObject.get("PatientContact");
			JSONArray diagnosis = (JSONArray) jsonObject.get("Diagnosis");
			JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
			JSONArray drg = (JSONArray) jsonObject.get("DRG");
			JSONArray observation = (JSONArray) jsonObject.get("Observation");
			JSONObject accident = (JSONObject) jsonObject.get("Accident");
			JSONArray claim = (JSONArray) jsonObject.get("ClaimOccurance");
			JSONArray guarantor = (JSONArray) jsonObject.get("Guarantor");
			JSONArray insu = (JSONArray) jsonObject.get("Insurance");
			JSONArray visitProvider =(JSONArray) visitObject.get("VisitProvider");


			if (type.equals("NoObjects")) {					// Update tenantPatientId

				try {
					String number = getUniqueNumber();
					newNum = "K" + number;					
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}
				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);

				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				try {
					// update appointmentStartDate and appointmentEndDate
					Object appointment = appointmentObject.get("AppointmentStartDate");
					String updatedDates = updatedDateAppointment(appointment);
					appointmentObject.put("AppointmentStartDate", updatedDates);
					appointmentObject.put("AppointmentEndDate", updatedDates);
					String appointmentId = getUniqueAppointmentNumber();				
					appointmentObject.put("AppointmentId", appointmentId);
				} catch (Exception e) {
					log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S12");
					eventObject.put("EventTypeDescription", "New Appointment");
					event.put("MessageType", "SIU");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.contentEquals("AllObjects")){
				try{
					ArrayList<String> allObjects=new ArrayList<>();
					ArrayList<String> visitMatch=CosmosDbDataValidation.notepadReadToList("hello");
					String mr=visitMatch.get(0);
					String epi=visitMatch.get(1);
					String appointID=visitMatch.get(2);
					String accNumber=visitMatch.get(3);
					String vistNumber=visitMatch.get(4);
					String visitDate=visitMatch.get(5);
					String firstName =visitMatch.get(6);
					String lastName =visitMatch.get(7);			
					String email=visitMatch.get(8);
					String city=visitMatch.get(9);
					
					
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", mr);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", epi);
					appointmentObject.put("AppointmentId",appointID);

					visitObject.put("AccountNumber", accNumber);
					visitObject.put("VisitNumber", vistNumber);
					visitObject.put("VisitDate", visitDate);

					patientObject.put("PatientFirstName", firstName);
					patientObject.put("PatientLastName", lastName);
					patientObject.put("PatientEmailAddress", email);
					JSONArray address=(JSONArray) patientObject.get("PatientAddress");					
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City",city);
					String appointmentID=(String) appointmentObject.get("AppointmentId");

					//diagnosis
					JSONObject diag=(JSONObject) diagnosis.get(0);
					JSONObject description=(JSONObject) diag.get("DiagnosisDescription");
					String diaName=(String) description.get("DiagnosisName");
					//DRG
					JSONObject dr=(JSONObject) drg.get(0);
					String drrg=(String) dr.get("DRG");
					//Observation
					JSONObject observa=(JSONObject) observation.get(0);
					String obser=(String) observa.get("ObservationType");
					//Accident
					String acc=(String) accident.get("AccidentCode");
					//claimOccurance
					JSONObject claimOccurance = (JSONObject) claim.get(0);																
					String occ=(String) claimOccurance.get("OccuranceCode");
					//Guarantor
					JSONObject guaran = (JSONObject) guarantor.get(0);																
					String spouse=(String) guaran.get("GuarantorSpouseFirstName");
					//Insurance
					JSONObject inusrance = (JSONObject) insu.get(0);
					JSONObject insured=	(JSONObject) inusrance.get("insured");
					JSONObject inusranceAddress=(JSONObject) insured.get("insuredAddress");						
					String insur=(String) inusranceAddress.get("city");
					//VisitProvider
					JSONObject provider =(JSONObject) visitProvider.get(3);
					String provi=(String) provider.get("ProviderLastName");
					//Patient Contact
					JSONObject contactFirstName=(JSONObject) patientContact.get(1);						
					String contact=(String) contactFirstName.get("ContactFirstName");
					allObjects.add(firstName);
					allObjects.add(lastName);
					allObjects.add(email);
					allObjects.add(city);
					allObjects.add(appointID);
					allObjects.add(contact);
					allObjects.add(provi);
					allObjects.add(insur);
					allObjects.add(spouse);
					allObjects.add(occ);
					allObjects.add(acc);
					allObjects.add(obser);
					allObjects.add(drrg);
					allObjects.add(diaName);
					
					CosmosDbDataValidation.notepadWrite("hello", allObjects);
				}
				catch(Exception e){
					log.error("Failed to update JSON data", e);
					e.printStackTrace();
				}

				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "New Appointment");
					event.put("MessageType", "SIU");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.contentEquals("NoObjectsSIU")){
				try{

					ArrayList<String> visitMatch=CosmosDbDataValidation.notepadReadToList("hello");
					String mr=visitMatch.get(0);
					String epi=visitMatch.get(1);
					String appointID=visitMatch.get(2);
					String accNumber=visitMatch.get(3);
					String vistNumber=visitMatch.get(4);
					String visitDate=visitMatch.get(5);
					String firstName =visitMatch.get(6);
					String lastName =visitMatch.get(7);			
					String email=visitMatch.get(8);
					String city=visitMatch.get(9);
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", mr);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", epi);
					appointmentObject.put("AppointmentId",appointID);

					visitObject.put("AccountNumber", accNumber);
					visitObject.put("VisitNumber", vistNumber);
					visitObject.put("VisitDate", visitDate);

					patientObject.put("PatientFirstName", firstName);
					patientObject.put("PatientLastName", lastName);
					patientObject.put("PatientEmailAddress", email);
					JSONArray address=(JSONArray) patientObject.get("PatientAddress");					
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City",city);					
				}
				catch(Exception e){
					log.error("Failed to update JSON data", e);
					e.printStackTrace();
				}

				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S13");
					eventObject.put("EventTypeDescription", "New Appointment");
					event.put("MessageType", "SIU");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			if(type.contentEquals("NoObjects")){
				FileWriter file = new FileWriter(SIUNoObjects);
				// File Writer creates a file in write mode at the given location
				file.write(jsonObject.toString());
				file.flush();
			}
			else if(type.contentEquals("AllObjects")){
				FileWriter file = new FileWriter(SIUAllObjects);
				// File Writer creates a file in write mode at the given location
				file.write(jsonObject.toString());	
				file.flush();
			}
			else if(type.contentEquals("NoObjectsSIU")){
				FileWriter file = new FileWriter(SIUNoObjects);
				// File Writer creates a file in write mode at the given location
				file.write(jsonObject.toString());	
				file.flush();
			}

		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void objectsADTJsonFile(String type) throws ParseException {
		String newNum = "";
		FileReader reader = null ;
		try {
			// read the JSON file
			if(type.contentEquals("NoObjects")){
				reader = new FileReader(ADTNoObjects);
			}
			else if(type.contentEquals("AllObjects")){
				reader = new FileReader(ADTAllObjects);
			}
			else if(type.contentEquals("NoObjectsADT")){
				reader = new FileReader(ADTNoObjects);
			}
			else if(type.contentEquals("SIUA03NoObjects")){
				reader = new FileReader(A03NoObjects);
			}
			else if(type.contentEquals("A03NoObjects")){
				reader = new FileReader(A03NoObjects);
			}
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);

			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject appointmentObject = (JSONObject) jsonObject.get("Appointment");
			JSONArray patientContact = (JSONArray) jsonObject.get("PatientContact");
			JSONArray diagnosis = (JSONArray) jsonObject.get("Diagnosis");
			JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
			JSONArray drg = (JSONArray) jsonObject.get("DRG");
			JSONArray observation = (JSONArray) jsonObject.get("Observation");
			JSONObject accident = (JSONObject) jsonObject.get("Accident");
			JSONArray claim = (JSONArray) jsonObject.get("ClaimOccurance");
			JSONArray guarantor = (JSONArray) jsonObject.get("Guarantor");
			JSONArray insu = (JSONArray) jsonObject.get("Insurance");
			JSONArray visitProvider =(JSONArray) visitObject.get("VisitProvider");


			if (type.equals("NoObjects")) {					// Update tenantPatientId

				try {
					String number = getUniqueNumber();
					newNum = "K" + number;					
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}
				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);

				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}				
				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A01");
					eventObject.put("EventTypeDescription", "Checked-In");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.contentEquals("AllObjects")){
				try{
					ArrayList<String> allObjects=new ArrayList<>();
					ArrayList<String> visitMatch=CosmosDbDataValidation.notepadReadToList("hello");
					String mr=visitMatch.get(0);
					String epi=visitMatch.get(1);					
					String accNumber=visitMatch.get(2);
					String vistNumber=visitMatch.get(3);
					String visitDate=visitMatch.get(4);
					String firstName =visitMatch.get(5);
					String lastName =visitMatch.get(6);			
					String email=visitMatch.get(7);
					String city=visitMatch.get(8);
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", mr);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", epi);					

					visitObject.put("AccountNumber", accNumber);
					visitObject.put("VisitNumber", vistNumber);
					visitObject.put("VisitDate", visitDate);

					patientObject.put("PatientFirstName", firstName);
					patientObject.put("PatientLastName", lastName);
					patientObject.put("PatientEmailAddress", email);
					JSONArray address=(JSONArray) patientObject.get("PatientAddress");					
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City",city);

					//diagnosis
					JSONObject diag=(JSONObject) diagnosis.get(0);
					JSONObject description=(JSONObject) diag.get("DiagnosisDescription");
					String diaName=(String) description.get("DiagnosisName");
					//DRG
					JSONObject dr=(JSONObject) drg.get(0);
					String drrg=(String) dr.get("DRG");
					//Observation
					JSONObject observa=(JSONObject) observation.get(0);
					String obser=(String) observa.get("ObservationType");
					//Accident
					String acc=(String) accident.get("AccidentCode");
					//claimOccurance
					JSONObject claimOccurance = (JSONObject) claim.get(0);																
					String occ=(String) claimOccurance.get("OccuranceCode");
					//Guarantor
					JSONObject guaran = (JSONObject) guarantor.get(0);																
					String spouse=(String) guaran.get("GuarantorSpouseFirstName");
					//Insurance
					JSONObject inusrance = (JSONObject) insu.get(0);
					JSONObject insured=	(JSONObject) inusrance.get("insured");
					JSONObject inusranceAddress=(JSONObject) insured.get("insuredAddress");						
					String insur=(String) inusranceAddress.get("city");
					//VisitProvider
					JSONObject provider =(JSONObject) visitProvider.get(3);
					String provi=(String) provider.get("ProviderLastName");
					//Patient Contact
					JSONObject contactFirstName=(JSONObject) patientContact.get(1);						
					String contact=(String) contactFirstName.get("ContactFirstName");
					allObjects.add(firstName);
					allObjects.add(lastName);
					allObjects.add(email);
					allObjects.add(city);					
					allObjects.add(contact);
					allObjects.add(provi);
					allObjects.add(insur);
					allObjects.add(spouse);
					allObjects.add(occ);
					allObjects.add(acc);
					allObjects.add(obser);
					allObjects.add(drrg);
					allObjects.add(diaName);
					CosmosDbDataValidation.notepadWrite("hello", allObjects);
				}
				catch(Exception e){
					log.error("Failed to update JSON data", e);
					e.printStackTrace();
				}

				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A08");
					eventObject.put("EventTypeDescription", "Update");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.contentEquals("NoObjectsADT")){
				try{

					ArrayList<String> visitMatch=CosmosDbDataValidation.notepadReadToList("hello");
					String mr=visitMatch.get(0);
					String epi=visitMatch.get(1);					
					String accNumber=visitMatch.get(2);
					String vistNumber=visitMatch.get(3);
					String visitDate=visitMatch.get(4);
					String firstName =visitMatch.get(5);
					String lastName =visitMatch.get(6);			
					String email=visitMatch.get(7);
					String city=visitMatch.get(8);
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", mr);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", epi);				

					visitObject.put("AccountNumber", accNumber);
					visitObject.put("VisitNumber", vistNumber);
					visitObject.put("VisitDate", visitDate);

					patientObject.put("PatientFirstName", firstName);
					patientObject.put("PatientLastName", lastName);
					patientObject.put("PatientEmailAddress", email);
					JSONArray address=(JSONArray) patientObject.get("PatientAddress");					
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City",city);					
				}
				catch(Exception e){
					log.error("Failed to update JSON data", e);
					e.printStackTrace();
				}

				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A08");
					eventObject.put("EventTypeDescription", "Update");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.contentEquals("SIUA03NoObjects")){
				try{

					ArrayList<String> visitMatch=CosmosDbDataValidation.notepadReadToList("hello");
					String mr=visitMatch.get(0);
					String epi=visitMatch.get(1);
					String appoint=visitMatch.get(2);
					String accNumber=visitMatch.get(3);
					String vistNumber=visitMatch.get(4);
					String visitDate=visitMatch.get(5);
					String firstName =visitMatch.get(6);
					String lastName =visitMatch.get(7);			
					String email=visitMatch.get(8);
					String city=visitMatch.get(9);
					
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", mr);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", epi);				

					visitObject.put("AccountNumber", accNumber);
					visitObject.put("VisitNumber", vistNumber);
					visitObject.put("VisitDate", visitDate);
					visitObject.put("VisitDischargeDate", visitDate);

					patientObject.put("PatientFirstName", firstName);
					patientObject.put("PatientLastName", lastName);
					patientObject.put("PatientEmailAddress", email);
					JSONArray address=(JSONArray) patientObject.get("PatientAddress");					
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City",city);					
				}
				catch(Exception e){
					log.error("Failed to update JSON data", e);
					e.printStackTrace();
				}

				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A03");
					eventObject.put("EventTypeDescription", "Discharge");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.contentEquals("A03NoObjects")){
				try{

					ArrayList<String> visitMatch=CosmosDbDataValidation.notepadReadToList("hello");
					String mr=visitMatch.get(0);
					String epi=visitMatch.get(1);				
					String accNumber=visitMatch.get(2);
					String vistNumber=visitMatch.get(3);
					String visitDate=visitMatch.get(4);
					String firstName =visitMatch.get(5);
					String lastName =visitMatch.get(6);			
					String email=visitMatch.get(7);
					String city=visitMatch.get(8);
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", mr);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", epi);				

					visitObject.put("AccountNumber", accNumber);
					visitObject.put("VisitNumber", vistNumber);
					visitObject.put("VisitDate", visitDate);
					System.out.println("VisitDAte: " +visitDate);

					patientObject.put("PatientFirstName", firstName);
					patientObject.put("PatientLastName", lastName);
					patientObject.put("PatientEmailAddress", email);
					JSONArray address=(JSONArray) patientObject.get("PatientAddress");					
					JSONObject patientAddress =(JSONObject) address.get(0);
					patientAddress.put("City",city);					
				}
				catch(Exception e){
					log.error("Failed to update JSON data", e);
					e.printStackTrace();
				}

				try {
					// update eventTypeCode and eventTypeDescription						
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A03");
					eventObject.put("EventTypeDescription", "Discharge");
					event.put("MessageType", "ADT");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			if(type.contentEquals("NoObjects")){
				FileWriter file = new FileWriter(ADTNoObjects);
				// File Writer creates a file in write mode at the given location
				file.write(jsonObject.toString());
				file.flush();
			}
			else if(type.contentEquals("AllObjects")){
				FileWriter file = new FileWriter(ADTAllObjects);
				// File Writer creates a file in write mode at the given location
				file.write(jsonObject.toString());	
				file.flush();
			}
			else if(type.contentEquals("NoObjectsADT")){
				FileWriter file = new FileWriter(ADTNoObjects);
				// File Writer creates a file in write mode at the given location
				file.write(jsonObject.toString());	
				file.flush();
			}
			else if(type.contentEquals("SIUA03NoObjects")){
				FileWriter file = new FileWriter(A03NoObjects);
				// File Writer creates a file in write mode at the given location
				file.write(jsonObject.toString());	
				file.flush();
			}
			else if(type.contentEquals("A03NoObjects")){
				FileWriter file = new FileWriter(A03NoObjects);
				// File Writer creates a file in write mode at the given location
				file.write(jsonObject.toString());	
				file.flush();
			}

		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void updateMedicalADTJsonFile(String typeADT,String fileType) throws ParseException {
		String newNum = "";
		FileReader reader =null;
		try {
			// read the json file 
			if(fileType.contentEquals("MedicalReview")){
				reader = new FileReader(MedicalReview);
			}
			else if(fileType.contentEquals("NotRun")){
				reader = new FileReader(MedicalNotRun);
			}
			else if(fileType.contentEquals("MedicalFail")){
				reader = new FileReader(MedicalFail);
			}
			else if(fileType.contentEquals("MedicalClear")){
				reader = new FileReader(MedicalClear);
			}
			else if(fileType.contentEquals("MedicalReviewManual")){
				reader = new FileReader(MedicalReviewManual);
			}
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");			

			if (typeADT.equals("A01")) {
				// Update tenantPatientId
				try {
					String number = getUniqueNumber();
					newNum = "K" + number;
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}

				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);
				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A01");
					eventObject.put("EventTypeDescription", "Admit/visit notification");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
				// File Writer creates a file in write mode at the given location
				if(fileType.contentEquals("MedicalReview")){
					FileWriter file =new FileWriter(MedicalReview);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("NotRun")) {
					FileWriter file = new FileWriter(MedicalNotRun);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("MedicalFail")) {
					FileWriter file = new FileWriter(MedicalFail);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("MedicalClear")) {
					FileWriter file = new FileWriter(MedicalClear);
					file.write(jsonObject.toString());
					file.flush();
				}
				else if (fileType.contentEquals("MedicalReviewManual")) {
					FileWriter file = new FileWriter(MedicalReviewManual);
					file.write(jsonObject.toString());
					file.flush();
				}
			}
		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void updateEstimatorADTJsonFile(String typeADT,String fileType) throws ParseException {
		String newNum = "";
		FileReader reader =null;
		try {
			// read the json file 
			if(fileType.contentEquals("EstimatorNotRun")){
				reader = new FileReader(EstimatorNotRun);
			}
			else if(fileType.contentEquals("EstimatorPayerNotActive")){
				reader = new FileReader(EstimatorPayerNotActive);
			}
			else if(fileType.contentEquals("EstimatorNoInsurance")){
				reader = new FileReader(EstimatorNoInsurance);
			}
			else if(fileType.contentEquals("EstimatorReview")){
				reader = new FileReader(EstimatorReview);
			}
			else if(fileType.contentEquals("EstimatorDeductibleInclude")){
				reader = new FileReader(EstimatorNotRun);
			}
			else if(fileType.contentEquals("EstimatorCoPayInclude")){
				reader = new FileReader(EstimatorNotRun);
			}
			else if(fileType.contentEquals("EstimatorDeductibleCoPayInclude")){
				reader = new FileReader(EstimatorNotRun);
			}
			else if(fileType.contentEquals("EstimatorWorklist")){
				reader = new FileReader(EstimatorNotRun);
			}
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");


			if (typeADT.equals("A01")) {
				// Update tenantPatientId
				try {
					String number = getUniqueNumber();
					newNum = "K" + number;
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}

				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);
				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A01");
					eventObject.put("EventTypeDescription", "Admit/visit notification");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
				if(fileType.contentEquals("EstimatorDeductibleInclude")){
					try {
						JSONArray insu = (JSONArray) jsonObject.get("Insurance");
						JSONObject inusrance = (JSONObject) insu.get(0);
						JSONObject insured =(JSONObject) inusrance.get("insured");
						inusrance.put("insurancePlanId", "Auto2023");
						inusrance.put("insurancePlanName", "Automation_DeductibleInclude");
						insured.put("insuredid", "TC001010");

					} catch (Exception e) {
						log.error("Failed to update Insurance PlanId and Name", e);
						e.printStackTrace();
					}
				}
				else if(fileType.contentEquals("EstimatorNotRun")){
					try {
						JSONArray insu = (JSONArray) jsonObject.get("Insurance");
						JSONObject inusrance = (JSONObject) insu.get(0);
						JSONObject insured =(JSONObject) inusrance.get("insured");
						inusrance.put("insurancePlanId", "Auto2021");
						inusrance.put("insurancePlanName", "Automation_NonSelf");
						insured.put("insuredid", "TC001010");
					} catch (Exception e) {
						log.error("Failed to update Insurance PlanId and Name", e);
						e.printStackTrace();
					}
				}
				else if(fileType.contentEquals("EstimatorCoPayInclude")){
					try {	
						JSONArray insu = (JSONArray) jsonObject.get("Insurance");
						JSONObject inusrance = (JSONObject) insu.get(0);
						JSONObject insured =(JSONObject) inusrance.get("insured");
						inusrance.put("insurancePlanId", "Auto2024");
						inusrance.put("insurancePlanName", "Automation_CoPayInclude");
						insured.put("insuredid", "TC001010");

					} catch (Exception e) {
						log.error("Failed to update Insurance PlanId and Name", e);
						e.printStackTrace();
					}
				}
				else if(fileType.contentEquals("EstimatorDeductibleCoPayInclude")){
					try {		
						JSONArray insu = (JSONArray) jsonObject.get("Insurance");
						JSONObject inusrance = (JSONObject) insu.get(0);
						JSONObject insured =(JSONObject) inusrance.get("insured");
						inusrance.put("insurancePlanId", "Auto2025");
						inusrance.put("insurancePlanName", "Automation_DeductibleCoPayInclude");
						insured.put("insuredid", "TC001010");

					} catch (Exception e) {
						log.error("Failed to update Insurance PlanId and Name", e);
						e.printStackTrace();
					}
				}
				else if(fileType.contentEquals("EstimatorWorklist")){
					try {	
						JSONArray insu = (JSONArray) jsonObject.get("Insurance");
						JSONObject inusrance = (JSONObject) insu.get(0);
						JSONObject insured =(JSONObject) inusrance.get("insured");
						inusrance.put("insurancePlanId", "Auto2021");
						inusrance.put("insurancePlanName", "Automation_NonSelf");
						insured.put("insuredid", "TC100100");

					} catch (Exception e) {
						log.error("Failed to update Insurance PlanId and Name", e);
						e.printStackTrace();
					}
				}

			}
			// File Writer creates a file in write mode at the given location
			if(fileType.contentEquals("EstimatorNotRun")){
				FileWriter file =new FileWriter(EstimatorNotRun);
				file.write(jsonObject.toString());
				file.flush();
			}
			else if (fileType.contentEquals("EstimatorPayerNotActive")){
				FileWriter file =new FileWriter(EstimatorPayerNotActive);
				file.write(jsonObject.toString());
				file.flush();

			}
			else if (fileType.contentEquals("EstimatorNoInsurance")){
				FileWriter file =new FileWriter(EstimatorNoInsurance);
				file.write(jsonObject.toString());
				file.flush();

			}
			else if (fileType.contentEquals("EstimatorReview")){
				FileWriter file =new FileWriter(EstimatorReview);
				file.write(jsonObject.toString());
				file.flush();

			}
			else if (fileType.contentEquals("EstimatorDeductibleInclude")){
				FileWriter file =new FileWriter(EstimatorNotRun);
				file.write(jsonObject.toString());
				file.flush();

			}
			else if (fileType.contentEquals("EstimatorCoPayInclude")){
				FileWriter file =new FileWriter(EstimatorNotRun);
				file.write(jsonObject.toString());
				file.flush();

			}
			else if (fileType.contentEquals("EstimatorDeductibleCoPayInclude")){
				FileWriter file =new FileWriter(EstimatorNotRun);
				file.write(jsonObject.toString());
				file.flush();

			}
			else if (fileType.contentEquals("EstimatorWorklist")){
				FileWriter file =new FileWriter(EstimatorNotRun);
				file.write(jsonObject.toString());
				file.flush();

			}
		}
		catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}	
		@SuppressWarnings("unchecked")
	public void financialClearancesonFile(String type) throws ParseException {
		String newNum = "";
		FileReader reader=null;
		try {
			
			if(type.contentEquals("A01")){
				reader = new FileReader(Financial);
			}
			else if(type.contentEquals("AddPatient")){
				reader = new FileReader(AddPatientFinancial);
			}
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
				

			if (type.equals("A01")) {
				// Update tenantPatientId
				try {
					String number = getUniqueNumber();
					newNum = "K" + number;
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}

				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);

				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A01");
					eventObject.put("EventTypeDescription", "Admit/visit notification");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if(type.equals("AddPatient")){
				// Update tenantPatientId
				try {
					String number = getUniqueNumber();
					newNum = "K" + number;
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatientMR = (JSONObject) msg.get(0);
					tenantPatientMR.put("TenantPatientId", newNum);

					JSONObject tenantPatientEPI = (JSONObject) msg.get(3);
					tenantPatientEPI.put("TenantPatientId", newNum);

				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}

				try {
					// update AccountNumber,VisitNumber and VisitDate		

					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);

					Object tt = visitObject.get("VisitDate");
					String updatedDate = updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);
					
					ArrayList<String> iPASPatient=CosmosDbDataValidation.notepadReadToList("testData");
					String firstName=iPASPatient.get(0);
					String lastName=iPASPatient.get(1);
					patientObject.put("PatientFirstName",firstName);
					patientObject.put("PatientLastName",lastName);					


				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "A01");
					eventObject.put("EventTypeDescription", "Admit/visit notification");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			// File Writer creates a file in write mode at the given location
			if(type.contentEquals("A01")){
				FileWriter file =new FileWriter(Financial);
				file.write(jsonObject.toString());
				file.flush();
			}
			else if (type.contentEquals("AddPatient")){
				FileWriter file =new FileWriter(AddPatientFinancial);
				file.write(jsonObject.toString());
				file.flush();

			}		

		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}	
}		