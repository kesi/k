package com.ipas.hf.api.steps;

import com.ipas.hf.reporting.ReportLibrary;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;
import io.restassured.http.ContentType;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.json.simple.parser.ParseException;
import org.everit.json.schema.ValidationException;
import org.testng.Assert;


public class AppiPasSteps {

	private ReportLibrary report = new ReportLibrary();
	private RestActions rest = new RestActions();
	private Properties prop = TestBase.apiProp;
	private Map<String, String> headerMap = new HashMap();
	private Map<String, String> dataMap = new HashMap();
	private String currentRequestBody;

	@Given("Setup Base URI for the {string} Request")
	public void setup_Base_URI_for_the_Request(String requestMethod) {

		try {
			rest.setupRequest();
			rest.setRequestTimeout();
			rest.setBaseURI(prop.getProperty("baseURI"));
			rest.setRelaxedHTTPSValidationProtocolAsSSL();
			if (!requestMethod.equals("GET")) {
				rest.setContentType(ContentType.JSON);
			}
			report.logPass("Setup Request base for " + requestMethod);
		} catch (Exception e) {

			report.logHardFail("Request Setup  for " + requestMethod + " failed", e);
		}

	}

	
	@Given("Setup URI for Message {string} Request")
	public void setup_URI_for_Message_Request(String requestMethod) {
		try {
			rest.setupRequest();
			rest.setRequestTimeout();
			rest.setBaseURI(prop.getProperty("messageURI"));
			rest.setRelaxedHTTPSValidationProtocolAsSSL();
			if (!requestMethod.equals("GET")) {
				rest.setContentType(ContentType.JSON);
			}
			report.logPass("Setup Request base for " + requestMethod);
		} catch (Exception e) {

			report.logHardFail("Request Setup  for " + requestMethod + " failed", e);
		}

	}
	
	@Given("Setup Request Endpoint for {string}")
	public void setup_Request_Endpoint_for(String requestName, DataTable table) {

		try {
			List<List<String>> tableList = table.asLists(String.class);
			for (List<String> list : tableList) {
				if (list.get(0).contains("basepath")) {
					rest.setBasePath(prop.getProperty(list.get(1)));
					continue;
				}
				if (list.get(0).contains("messagepath")) {
					rest.setBasePath(prop.getProperty(list.get(1)));
					continue;
				}
				if (list.get(0).contains("pathparam")) {
					rest.setPathParams(list.get(1), prop.getProperty(list.get(2)));
				}
			}

			report.logPass("Setup Requst Endpoint for: " + requestName);
		} catch (Exception e) {

			report.logHardFail("Setup Requst Endpoint for: " + requestName + " failed", e);
		}
	}

	@When("Users adds the Headers Parameters for {string}")
	public void users_adds_the_Headers_Parameters_for(String key) {
		try {
			headerMap = rest.getHeadersMapFromProperties(key);

			rest.addHeadersToRequest(headerMap);
			report.logPass("Add headers to Request for:" + key);
		} catch (Exception e) {

			report.logHardFail("Add headers to request for:" + key + " failed", e);
		}
	}

	@When("user adds the Request body from {string}")
	public void user_adds_the_Request_body_from(String requestBodyFileName) {

		try {
			currentRequestBody = rest.getRequestBodyJSONString(requestBodyFileName);
			rest.addRequestBody(currentRequestBody);
			report.logPass("Add Body to Request from " + requestBodyFileName);
		} catch (Exception e) {

			report.logHardFail("Add Body to Request" + requestBodyFileName + " failed", e);
		}

	}

	@Given("Load Test Data File {string}")
	public void load_Test_Data_File(String fileName) {
		try {
			rest.setRequestDataFile(fileName);
			report.logPass("Test Data File Load" + fileName);
		} catch (Exception e) {

			report.logHardFail("Add Body to Request" + fileName + " failed", e);
		}

	}

	@When("User sends a {string} Request")
	public void user_sends_a_Request(String requestMethod) {
		try {

			rest.performRequest(requestMethod);

			report.logPass("Send " + requestMethod + " Request");
		} catch (Exception e) {
			e.printStackTrace();
			report.logHardFail("Send " + requestMethod + " Request failed", e);
		}
	}

	@Then("Status code and Line of Response should match {string} and {string}")
	public void status_code_and_Line_of_Response_should_match_and(String statCodeKey, String statLineKey) {
		String responseStatusCode = null;
		String responseStatusLine = null;
		try {
			report.logJSONBlock("Response Payload", rest.getResponsebody());
			responseStatusCode = String.valueOf(rest.getStatusCode());
			String expectedStatusCode = dataMap.get(statCodeKey);
			Assert.assertEquals(responseStatusCode, expectedStatusCode);
			report.logPass("Status Code Validated Expected: " + expectedStatusCode + " Actual: " + responseStatusCode);
			responseStatusLine = rest.getStatusLine();
			String expectedStatusLine = dataMap.get(statLineKey);
			Assert.assertTrue(responseStatusLine.contains(expectedStatusLine));
			report.logPass("Status Line Validated Expected: " + expectedStatusLine + " Actual: " + responseStatusLine);
		} catch (AssertionError e) {

			report.logHardFail("Status code or Line Validation failed", e);
		}
	}

	@When("User Loads data for Test Case {string} and test data {string}")
	public void user_Loads_data_for_Test_Case_and_test_data(String testCaseID, String dataRow) {
		try {
			dataMap = rest.getTestDataMap(testCaseID, dataRow);
			report.logPass("Load Test Data for" + testCaseID + "with row:" + dataRow);
		} catch (Exception e) {

			report.logHardFail("Load Test Data for" + testCaseID + "with row:" + dataRow + " failed", e);
		}
	}

	@Then("The Response body should contain same {string} as the path Param {string}")
	public void the_Response_body_should_contain_same_as_the_path_Param(String path1, String param1) {
		try {

			String response1 = rest.getStringValueFromResponse(path1);
			//String expectedValue1 = rest.getPathParamValue(param1);
			String expectedValue1 = param1;
			Assert.assertEquals(response1.toUpperCase(), expectedValue1.toUpperCase());
			report.logPass("Validate Response Body Content Matches the Request at path: " + path1 + " Expected Value: "
					+ expectedValue1 + " Actual value: " + response1);
		} catch (AssertionError e) {

			report.logHardFail("Validate Response Body Content Matches the Request Failed ", e);
		}
	}

	@Then("The {string} in response should be same as request body {string}")
	public void the_in_response_should_be_same_as_request_body(String responsePath, String requestPath) {
		String responseValue = null;
		String requestValue = null;
		try {

			responseValue = rest.getStringValueFromResponse(responsePath);
			requestValue = rest.getStringValueFromJSONString(requestPath, rest.getRequestBody());
			Assert.assertEquals(responseValue.toUpperCase(), requestValue.toUpperCase());
			report.logPass(
					"Validate Response Body Content Matches the Request Body content at Response path: " + responsePath
					+ " RequestPath: " + requestPath + " Response Value: " + " Request value: " + requestValue);
		} catch (AssertionError e) {

			report.logHardFail("Validate Response Body Content Matches the Request Body content at Response path: "
					+ responsePath + " RequestPath: " + requestPath + " Response Value: " + " Request value: "
					+ requestValue + " Failed", e);
		}
	}

	@Then("The Schema of Response JSON should match the Expected Schema from {string}")
	public void the_Schema_of_Response_JSON_should_match_the_Expected_Schema_from(String schemaFileName) {
		try {

			rest.schemaValidator(schemaFileName);
			report.logPass("JSon Schema Validation Passed with File: " + schemaFileName);
		} catch (Throwable e) {
			if (e instanceof ValidationException) {

				List<ValidationException> vExceptions = ((ValidationException) e).getCausingExceptions();
				for (ValidationException validationException : vExceptions) {
					report.logFail("Schema Validation Failed: ", validationException);
				}
			}
			report.logHardFail("JSon Schema Validation Failed: ", e);
		}
	}

	@Given("User changes the path param {string}")
	public void user_changes_the_path_param(String param) {

		try {
			String value = dataMap.get("value");
			rest.setPathParams(param, value);
			report.logPass("Change path param:" + param + " to: " + value);
		} catch (Exception e) {

			report.logHardFail("Change path param:" + param + "Failed", e);
		}
	}

	@Then("I validate that Response body of Get Bank contains path Params {string}")
	public void i_validate_that_Response_body_of_Get_Bank_contains_path_Params(String param1) {
		try {
			String response1 = rest.getStringValueFromResponse("$.Name");
			String expectedValue1 = rest.getPathParamValue(param1);
			Assert.assertEquals(response1, expectedValue1.toUpperCase());
			report.logPass("Validate Response Body Content Matches the Expected Value: " + expectedValue1
					+ " Actual value: " + response1);
		} catch (AssertionError e) {
			report.logHardFail("Validate Response Body Content Matches the Request Failed ", e);
		}
	}

	@Then("Update json file based on given event type {string}")
	public void update_json_file_based_on_given_event_type(String typeSIU) {
		try {
			rest.updateSIUJsonFile(typeSIU);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Then("Get the value of {string} from response body and compare with expected status as {string}")
	public void get_the_value_of_from_response_body_and_compare_with_expected_status_as(String responseValue, String expectedValue) {
		String actualValue="";
		try {
			actualValue=rest.getValueFromResponseandCompWithExpected(responseValue);
			if((actualValue.contentEquals("CheckedIn"))||(actualValue.contentEquals("LocChange"))||(actualValue.contentEquals("StatusChanged"))||(actualValue.contentEquals("NoChange"))){
				actualValue=actualValue.replaceAll("(\\p{Ll})(\\p{Lu})","$1 $2");
			}
			Assert.assertEquals(actualValue, expectedValue);	
			report.logPass("Validate Response Body Content Matches the Expected Value : "  +  expectedValue  +  "  Actual value :  " + actualValue);
		} catch (AssertionError e) {
			report.logHardFail("Validate Response from Body Content Does not match with Actual", e);
		}

	}

	@Then("Update json file based on given ADT event type {string}")
	public void update_json_file_based_on_given_ADT_event_type(String typeADT) {
		try {
			rest.updateADTJsonFile(typeADT);
		} catch (ParseException e) {				
			e.printStackTrace();
		}
	}
	
	@Then("Post service tracker json file based on given ADT event type {string}")
	public void post_service_tracker_json_file_based_on_given_ADT_event_type(String typeADT) {
		try {
			rest.ServiceTrackerADTJsonFile(typeADT);
		} catch (ParseException e) {				
			e.printStackTrace();
		}
	}
	
	@Then("Update service tracker json file based on given ADT event type {string} and {string}")
	public void update_service_tracker_json_file_based_on_given_ADT_event_type(String typeADT,String fieldname) {
		try {
			rest.updateServiceTrackerADTJsonFile(typeADT,fieldname);
		} catch (Exception e) {				
			e.printStackTrace();
		}
	}
	
	@Then("Update service tracker json file based on given phonenumber as {string}")
	public void update_service_tracker_json_file_based_on_given_phonenumber(String mobileNumber) {
		try {
			rest.updateServiceTrackerPhoneNumber(mobileNumber);
		} catch (Exception e) {				
			e.printStackTrace();
		}
	}
	
	@Then("Post service tracker json file based on point of care code {string} and {string}")
	public void post_service_tracker_json_file_based_on_point_of_care_code(String typeADT,String pocCode) {
		//ServiceTracker
		try {
			rest.ServiceTrackerADTJsonFile(typeADT);
			rest.updatePointOfCare(pocCode);
		} catch (Exception e) {				
			e.printStackTrace();
		}
	}
	
	@Then("Update json file based on given SIU event type not in InRule {string}")
	public void update_json_file_based_on_given_SIU_event_type_not_in_InRule(String typeSIU) {
		try {
			rest.updateInruleSIUJsonFile(typeSIU);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Then("Update json file based on given ADT event type not in InRule {string}")
	public void update_json_file_based_on_given_ADT_event_type_not_in_InRule(String typeADT) {
		try {
			rest.updateInruleADTJsonFile(typeADT);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Then("Update service tracker json file based on given event type {string}")
	public void update_service_tracker_json_file_based_on_given_event_type(String typeADT) {
		//ServiceTracker
		try {
			rest.updateServiceTrackerJsonFile(typeADT);
		} catch (Exception e) {				
			e.printStackTrace();
		}
	}

	@Then("Update SIU to ADT event type as {string} and {string}")
	public void update_SIU_to_ADT_event_type(String typeADT,String typeDesc) {
		//ServiceTracker
		try {
			rest.updateSIUToADT(typeADT,typeDesc);
		} catch (Exception e) {				
			e.printStackTrace();
		}
	}	
	@Then("Update postal confirmation auto run json file based on given ADT event type {string} and file as {string}")
	public void update_postal_confirmation_auto_run_json_file_based_on_given_ADT_event_type_and_file_as(String typeADT, String fileType) {
		try {
			rest.updatePostalADTJsonFile(typeADT,fileType);
		} catch (ParseException e) {				
			e.printStackTrace();
		}
	}
	@Then("Update the medical necessity auto run json file based on given ADT event type {string} and file as {string}")
	public void update_the_medical_necessity_auto_run_json_file_based_on_given_ADT_event_type_and_file_as(String typeADT, String fileType) {
		try {
			rest.updateMedicalADTJsonFile(typeADT,fileType);
		} catch (ParseException e) {				
			e.printStackTrace();
		}
	}
	
	
	@Then("Update estimator auto run json file based on given ADT event type {string} and file as {string}")
	public void update_estimator_auto_run_json_file_based_on_given_ADT_event_type_and_file_as(String typeADT, String fileType) {
		try {
			rest.updateEstimatorADTJsonFile(typeADT,fileType);
		} catch (ParseException e) {				
			e.printStackTrace();
		}
	}
	@Then("Update the financial json filr on given input as {string}")
	public void update_the_financial_json_filr_on_given_input_as(String type) throws ParseException {
	rest.financialClearancesonFile(type);
	}


}
