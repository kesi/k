package com.ipas.hf.web.pages.ipasPages;

import java.io.File;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.testng.Assert;

import com.ipas.hf.engine.BrowserCapabilities;
import com.ipas.hf.web.pages.BasePage;



public class ExportExcelPage extends BasePage {	

	@FindBy(xpath = "//div[@class='Searchfilters']/div/div/div/div/div[2]")
	private WebElement btn_ToolIcon;

	String downloadPath=System.getProperty("user.dir")+"\\Downloads\\";

	/**
	 * File verification from the down loaded folder 
	 * @param fileName
	 */
	public boolean isFileDownloaded(String downloadPath,String fileName) {	
		boolean flag=false;
		try {		
			File dir = new File(downloadPath);
			File[] dir_contents = dir.listFiles();			
			for (int i = 0; i < dir_contents.length; i++) {			
				if (dir_contents[i].getName().contains(fileName))			
				
					dir_contents[i].delete();				
				flag=true;
				break;
			}
		} catch (Exception e) {
			flag=false;
		}
		return flag;

	}

	public void verifyExportExcelDownload(String fileName){
		boolean flag=false;
		try {
			Thread.sleep(5000);
			flag=isFileDownloaded(downloadPath,fileName);			
			if(flag){
				report.reportPass("File is downloaded successfully");
			}
			else{				
				throw new Exception("File is not download");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}


}


