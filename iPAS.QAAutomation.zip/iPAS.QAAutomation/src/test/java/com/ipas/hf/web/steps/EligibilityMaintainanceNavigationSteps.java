package com.ipas.hf.web.steps;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedCondition;
import com.ipas.hf.web.pages.ipasPages.EditUserPage;
import com.ipas.hf.web.pages.ipasPages.EligibityMaintainanceNavigationPage;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;
public class EligibilityMaintainanceNavigationSteps {

	EligibityMaintainanceNavigationPage maintainance = new EligibityMaintainanceNavigationPage();
	RestActions rest=new RestActions();

	@Then("Verify the navigation bar")
	public void Verify_the_navigation_bar() {
		maintainance.navigationBar();
	}

	@Then("Verify the Static Menu items on the navigation bar")
	public void Verify_the_Static_Menu_items_on_the_navigation_bar(DataTable menuitems) {
		maintainance.verifymenuItems(menuitems);
	}

	@Then("Verify the navigation to maintainance main page")
	public void Verify_the_navigation_to_maintainance_main_page() {
		maintainance.navigationMaintananceMainPage();
	}

	@Then("Verify the panels in maintainance main page")
	public void Verify_the_titles_in_maintainance_main_page(DataTable panels ) {
		maintainance.verifyPanelsMaintainance(panels);
	}

	@Then("Verify the menu option in Organizations and Users")
	public void Verify_the_menu_in_OrganizationsAndUsers(DataTable Menu ) {
		maintainance.verifyMenuOrgAndUsers(Menu);
	}

	@Then("verify the payer Panel")
	public void Verify_the_Payer_Panel(DataTable payer ) {
		maintainance.verifyPayerPanel(payer);
	}

	@Then("verify the profile and settings Icon")
	public void Verify_the_profile_and_settings_Icon( ) {
		maintainance.verifyProfileIcon();
	}


	@Then("verify when user selects one of the menu items")
	public void verify_when_user_selects_one_of_the_menu_items( ) {
		maintainance.verifyNavigation();
	}


}