package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.PropensityToPayPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class PropensityToPaySteps {

	PropensityToPayPage p2p=new PropensityToPayPage();

	@Then("Verify the display of PropensityToPay of {string} as {string}")
	public void verify_the_display_of_PropensityToPay_of_as(String panel, String title) {
		p2p.verifyPropensityToPay(panel, title);
	}

	@Then("Verify the propensity to pay {string} module status when {string}")
	public void verify_the_propensity_to_pay_module_status_when(String panel, String data) {
		p2p.verifyP2PModuletStatus(panel, data);
	}

	@Then("Verify expand and collapse of the propensity to pay Panel")
	public void verify_expand_and_collapse_of_the_propensity_to_pay_Panel() throws Exception {
		p2p.verifyExpandandCollapsP2PPanel();
	}

	@Then("Verify the {string} message as {string}")
	public void verify_the_message_as(String panel, String mesg) {
		p2p.verifyPropensityToPayMessage(panel, mesg);
	}
	@Then("Click on Propensity To Pay panel link")
	public void click_on_Propensity_To_Pay_panel_link() {
		p2p.clickOnP2PPanel();
	}
	@Then("Verify the PropensityToPay last run by in short and full panel")
	public void verify_the_PropensityToPay_last_run_by_in_short_and_full_panel() {
		p2p.verifyLastRunByInP2PPanel();
	}
	@Then("Verify the display of PropensityToPay information")
	public void verify_the_display_of_PropensityToPay_information(DataTable testdata) {
		p2p.verifyP2PVerificationResponse(testdata);
	}
	@Then("Click on Propensity To Pay Run check button")
	public void click_on_Propensity_To_Pay_Run_check_button() {
		p2p.clickOnP2PRunCheckBtn();
	}
	@Then("Click on cancel and cross options from P{int}P window and verify the navigation")
	public void click_on_cancel_and_cross_options_from_P_P_window_and_verify_the_navigation(Integer int1) {
		p2p.cancelAndCrossNavigationP2P();
	}
	@Then("Select the request type as {string}")
	public void select_the_request_type_as(String type) {
		p2p.selectRequestType(type);
	}
	@Then("Click on history from other options and select previous record as {string}")
	public void click_on_history_from_other_options_and_select_previous_record_as(String expMsg) {
		p2p.clickOnHistory(expMsg);
	}
	@Then("Verify the closing of History window")
	public void verify_the_closing_of_History_window() {
		p2p.closeHistory();
	}

	@Then("Click on View Credit Report and close")
	public void click_on_View_Credit_Report_and_close() {
		p2p.verifyCreditReport();
	}



}
