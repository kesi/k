package com.ipas.hf.web.steps;

import org.json.simple.parser.ParseException;

import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.ipasPages.AccountSearchFilteringPage;
import com.ipas.hf.web.pages.ipasPages.DefaultSearchPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class AccountSearchFilteringSteps {

	AccountSearchFilteringPage filter=new AccountSearchFilteringPage();


	@Then("Click on Filter icon and verify the list of fields on the Account search page")
	public void click_on_Filter_icon_and_verify_the_list_of_fields_on_the_Account_search_page(DataTable filterNames) throws Exception {
		filter.verifyFilterNames(filterNames);
	}
	

	@Then("Select filter as {string} and verify the field and default value as {string}")
	public void select_filter_as_and_verify_the_field_and_default_value_as(String filterName, String defaultValue) throws Exception {
		filter.verifytheFieldandDefaultValue(filterName,defaultValue);
	}
	
	@Then("Select filter as {string} and enter data as {string} and verify the results in Column as {string}")
	public void select_filter_as_and_enter_data_as_and_verify_the_results_in_Column_as(String filterName, String testData, String columnName) throws Exception {
		filter.verifyDatainAllColunms(filterName,testData,columnName);
	}
	
	@Then("Apply the filter as {string} with {string} and navigate to {string} page and come back to Account Search page")
	public void apply_the_filter_as_with_and_navigate_to_page_and_come_back_to_Account_Search_page(String filterName, String testData,String pageName) throws Exception {
		filter.verifyAppliedFilterValues(filterName,testData,pageName);	
	}
	
	@Then("Update json file based on Gender Type {string}")
	public void update_json_file_based_on_Gender_Type(String genderType) throws ParseException {
		filter.updateAccountSearchFilterJSON(genderType);
	}
	
	@Then("Verify the display of data when apply filter with {string} as {string} and {string} as {string}")
	public void verify_the_display_of_data_when_apply_filter_with_as_and_as(String filter1, String genderName, String filter2, String emailID) throws Exception {
		filter.applyFilterforMultipleFields(filter1, genderName, filter2, emailID);
	}
}