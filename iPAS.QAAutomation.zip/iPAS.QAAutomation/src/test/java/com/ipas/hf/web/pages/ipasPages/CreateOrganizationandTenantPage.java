package com.ipas.hf.web.pages.ipasPages;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class CreateOrganizationandTenantPage extends BasePage {

	@FindBy(linkText="Organization Maintenance")
	private WebElement lnk_OrganizationMaintenance;
	
	@FindBy(xpath="//div[@class='e-gridcontent']/div/table/tbody/tr")
	private WebElement tbl_Tenants;

	@FindBy(xpath="//a[(text()='Organization Maintenance')]/../../div[2]")
	private WebElement lbl_OrganizationMaintenanceText;

	@FindBy(xpath="//span[normalize-space()='Organizations & Users']/../../..")
	private WebElement atr_OrganizationsUsers;

	@FindBy(xpath="//span[normalize-space()='Organizations & Users']")
	private WebElement lbl_OrganizationsUsers;

	@FindBy(xpath="//span[@class='breadcrum-active']")
	private WebElement lbl_Breadcrum;

	@FindBy(xpath="//div[@class='breadcrum-container']/span")
	private List<WebElement> lbl_Breadcrum_All;

	@FindBy(xpath="//button[contains(text(),'Add New Organization')]")
	private WebElement btn_AddNewOrganization;
	
	@FindBy(xpath="//button[contains(text(),'Add New Tenant')]")
	private WebElement btn_AddNewTenant;
	
	@FindBy(xpath="//ejs-textbox[@placeholder='Organization Name']")
	private WebElement txt_OrganizationName;

	@FindBy(xpath="//ejs-textbox[@placeholder='Organization Name']/span/input")
	private WebElement txt_OrganizationName1;

	@FindBy(xpath="//div[@class='mandatory']/div")
	private WebElement lbl_MandatoryMessage;
	
	@FindBy(xpath="//div[@class='mandatory']/div")
	private List<WebElement> lbl_MandatoryMessageAllFeilds;

	@FindBy(xpath="//div[@class='neworgnisation modal-header']/h4/span")
	private WebElement lbl_ModelWindowTitle;

	@FindBy(xpath="//div[@class='neworgnisation modal-header']/button")
	private WebElement btn_AddNewOrganizationCloseX;

	@FindBy(xpath="//div[@class='neworgnisation modal-header']/../form/div/div/div/label")
	private WebElement lbl_OrganizationName;

	@FindBy(xpath="//button[contains(text(),'Cancel')]")
	private WebElement btn_Cancel;

	@FindBy(xpath="//button[normalize-space()='Add']")
	private WebElement btn_Add;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs; 

	@FindBy(xpath = "//div[@class='newtenant modal-header']/h4")
	private WebElement lbl_AddTenantTitle; 

	@FindBy(xpath = "//div[@class='newtenant modal-header']/button")
	private WebElement lbl_AddTenantCloseX; 

	@FindBy(xpath="//div[@class='newtenant modal-body']//child::label")
	private List<WebElement> lbl_AddTenantAllFeilds;

	@FindBy(xpath="//div[@class='newtenant modal-body']//child::input")
	private List<WebElement> atr_AddTenantAllFeilds;
	
	@FindBy(xpath="//div[@class='newtenant modal-body']/div/div/div/div/ejs-dropdownlist/span/input")
	private WebElement dd_Organization;
	
	@FindBy(xpath="//ejs-textbox[@placeholder='Tenant Name']/span/input")
	private WebElement txt_TenantName;
	
	@FindBy(xpath="//ejs-textbox[@placeholder='Short Name']/span/input")
	private WebElement txt_ShortName;
	
	@FindBy(xpath="//ejs-textbox[@placeholder='CRM ID']/span/input")
	private WebElement txt_CRMID;
	
	@FindBy(xpath="//ejs-textbox[@placeholder='Web Analytics Site Id']/span/input")
	private WebElement txt_WebAnalyticsSiteId;
	
	@FindBy(xpath="//ejs-dropdownlist[@placeholder='Select Authentication Method']/span")
	private WebElement dd_AuthenticationMethod;
	
	@FindBy(xpath="//ejs-textbox[@placeholder='URL']/span/input")
	private WebElement txt_URL;
	
	@FindBy(xpath="//div[contains(@class,'newtenant modal-footer')]/div/div/span/button[1]")
	private WebElement btn_Cancel_AddTenant;
	
	@FindBy(xpath="//div[contains(@class,'newtenant modal-footer')]/div/div/span/button[1]")
	private WebElement btn_Save_AddTenant;
	
	ViewTenantsPage viewTenants=new ViewTenantsPage();
	public CreateOrganizationandTenantPage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyLableNameandTextMessage(DataTable testData){
		List<String> expData = testData.asList(String.class);
		StringBuilder unmatch=new StringBuilder();
		try {
			String actLinkName=webActions.waitAndGetText(lnk_OrganizationMaintenance, "Organization Maintenance Link");
			if(actLinkName.contentEquals(expData.get(0))){
				report.reportPass("Successfully verified the Organization Maintenance link");
			}else{
				report.reportFail("Failed to verify the Organization Maintenance link", true);
				unmatch.append("Failed to verify the Organization Maintenance link");
			}
			String actText=webActions.waitAndGetText(lbl_OrganizationMaintenanceText, "Organization Maintenance Text");
			if(actText.contentEquals(expData.get(1))){
				report.reportPass("Successfully verified the Organization Maintenance text message");
			}else{
				report.reportFail("Failed to verify the Organization Maintenance text message", true);
				unmatch.append("Failed to verify the Organization Maintenance text message");
			}
			webActions.click(lbl_OrganizationsUsers, "Organizations Users");
			webActions.waitForPageLoaded();
			String actCollapse=webActions.getAttributeValue(atr_OrganizationsUsers, "aria-expanded", "Organizations Users");
			if("false".contentEquals(actCollapse)){
				report.reportPass("Successfully Collapsed the Organizations Users panel");
			}else{
				report.reportFail("Failed to Collapse the Organizations Users panel", true);
				unmatch.append("Failed to Collapse the Organizations Users panel");
			}

			webActions.click(lbl_OrganizationsUsers, "Organizations Users");
			webActions.waitForPageLoaded();
			String actExpand=webActions.getAttributeValue(atr_OrganizationsUsers, "aria-expanded", "Organizations Users");
			if("true".contentEquals(actExpand)){
				report.reportPass("Successfully Expanded the Organizations Users panel");
			}else{
				report.reportFail("Failed to Expand the Organizations Users panel", true);
				unmatch.append("Failed to Expand the Organizations Users panel");
			}
			String actBreadcrum=webActions.waitAndGetText(lbl_Breadcrum, "Breadcrum");
			if(actBreadcrum.contentEquals(expData.get(2))){
				report.reportPass("Successfully verified the Breadcrum");
			}else{
				report.reportFail("Failed to verify the Breadcrum", true);
				unmatch.append("Failed to verify the Breadcrum");
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyAddNewOrganizationFieldNamesandValidationMessages(DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			ArrayList<String> expData = new ArrayList<>(testData.asList());
			ArrayList<String> actData=new ArrayList<String>();
			webActions.waitAndClick(lnk_OrganizationMaintenance, "Organization Maintenance Link");
			webActions.waitAndClick(btn_AddNewOrganization, "Add New Organization");
			actData.add(webActions.waitAndGetText(lbl_ModelWindowTitle, "Window title"));
			actData.add(webActions.getText(lbl_OrganizationName, "Organization Name"));
			actData.add(webActions.getAttributeValue(txt_OrganizationName, "placeholder", "Organization Name Text Box"));
			webActions.click(txt_OrganizationName, "Add New Organization");
			webActions.pressTab();
			actData.add(webActions.getText(lbl_MandatoryMessage, "Mandatory message"));
			report.reportInfo("Actual Data is: "+actData);
			report.reportInfo("Expected Data is: "+expData);
			ArrayList<String> unmatchData=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatchData.size()==0){
				report.reportPass("Successfully verified the field names and validation message.");
			}else{
				report.reportFail("Failed to verify the field names and validation message: "+unmatchData, true);
				unmatch.append("Failed to verify the field names and validation message: "+unmatchData);
			}
			webActions.waitForPageLoaded();
			webActions.click(btn_AddNewOrganizationCloseX, "Add New Organization CloseX");
			report.reportPass("Successfully closed the model window by clicking on closeX button");
			webActions.waitAndClick(btn_AddNewOrganization, "Add New Organization");
			webActions.waitForPageLoaded();
			webActions.click(btn_Cancel, "Cancel");
			report.reportPass("Successfully closed the model window by clicking on Cancel button");

			ArrayList<String>actualBreadcrumbTitles=webActions.getDatafromWebTable(lbl_Breadcrum_All);
			ArrayList<String> expectedBreadcrumbTitles=new ArrayList<String>();
			expectedBreadcrumbTitles.add("Maintenance");
			expectedBreadcrumbTitles.add("Tenants");
			report.reportInfo("Actual Breadcrumb is: "+actualBreadcrumbTitles);
			report.reportInfo("Expected Breadcrumb is: "+expectedBreadcrumbTitles);
			ArrayList<String> unmatchBreadcrumb=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles, expectedBreadcrumbTitles);
			if(unmatchBreadcrumb.size()==0){
				report.reportPass("Successfully verified the Breadcrumb Titles");
			}else{
				report.reportFail("Failed to verify the Breadcrumb Titles: "+unmatchBreadcrumb, true);
				unmatch.append("Failed to verify the Breadcrumb Titles: "+unmatchBreadcrumb);
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void waitforTenantsGrid(){
		try {
			webActions.waitAndClick(lnk_OrganizationMaintenance, "Organization Maintenance Link");
			webActions.waitForVisibilityOfAllElements(tbl_Tenants, "Tenants Grid");
		} catch (Exception e) {
		}
	}

	public String createNewOrganization(String orgName){
		orgName=orgName+"_"+webActions.getRandomString(5);
		try {
			waitforTenantsGrid();
			webActions.waitAndClick(btn_AddNewOrganization, "Add New Organization");
			webActions.waitForPageLoaded();
			webActions.waitAndClick(txt_OrganizationName1, "Organization Name");
			webActions.sendKeys(txt_OrganizationName1, orgName, "Organization Name");
			webActions.waitAndClick(btn_Add, "Add");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle = titleContent[0];
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message after Organization created: "+actContent);
			String successMessage="Organization created successfully.";
			report.reportInfo("Expected alert message after Organization created: "+successMessage);
			report.reportInfo("Newly created Organization Name: "+orgName);
			if(successMessage.contains(actContent)){
				report.reportPass("Successfully created Organization");
			}else{
				report.reportFail("Failed to created Organization: "+actContent, true);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
		return orgName;
	}

	public void verifyFieldNamesinAddTenantModelWindow(DataTable feildNames){
		try {
			ArrayList<String> expFeildNames = new ArrayList<>(feildNames.asList());
			webActions.waitAndClick(lnk_OrganizationMaintenance, "Organization Maintenance Link");
			webActions.waitAndClick(btn_AddNewTenant, "Add New Tenant");
			webActions.waitForVisibilityOfAllElements(lbl_AddTenantAllFeilds, "AddTenant All Feilds");
			ArrayList<String> actFeildNames=new ArrayList<String>();
			actFeildNames.add(webActions.getText(lbl_AddTenantTitle, "Add Tenant Title"));
			actFeildNames.addAll(webActions.getDatafromWebTable(lbl_AddTenantAllFeilds));
			report.reportInfo("Actual feild names: "+actFeildNames);
			report.reportInfo("Expected feild names : "+expFeildNames);
			ArrayList<String> unmatchFeildNames=webActions.getUmatchedInArrayComparision(actFeildNames, expFeildNames);
			if(unmatchFeildNames.size()==0){
				report.reportPass("Successfully verified the feild names in Add Tenant model window");
			}else{
				report.reportFail("Failed to verify the feild names in Add Tenant model window: "+unmatchFeildNames);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyPlaceholderinAddTenantModelWindow(DataTable placeholder){
		try {
			ArrayList<String> expPlaceholder = new ArrayList<>(placeholder.asList());
			ArrayList<String> actPlaceholder=webActions.getListofAttributeValuesfromWebPage(atr_AddTenantAllFeilds, "placeholder");
			report.reportInfo("Actual placeholders: "+actPlaceholder);
			report.reportInfo("Expected placeholders : "+expPlaceholder);
			ArrayList<String> unmatchPlaceholders=webActions.getUmatchedInArrayComparision(actPlaceholder, expPlaceholder);
			if(unmatchPlaceholders.size()==0){
				report.reportPass("Successfully verified the placeholders in Add Tenant model window");
			}else{
				report.reportFail("Failed to verify the placeholders in Add Tenant model window: "+unmatchPlaceholders);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyMandatoryvalidationMessages(DataTable messages){
		try {
			ArrayList<String> expMessages = new ArrayList<>(messages.asList());
			webActions.click(txt_TenantName, "TenantName");
			for (int i = 0; i <6; i++) {
				webActions.pressTab();
			}
			webActions.waitForPageLoaded();
			ArrayList<String>actMessages=webActions.getDatafromWebTable(lbl_MandatoryMessageAllFeilds);
			report.reportInfo("Actual Validation messages: "+actMessages);
			report.reportInfo("Expected Validation messages : "+expMessages);
			ArrayList<String> unmatchMessages=webActions.getUmatchedInArrayComparision(actMessages, expMessages);
			if(unmatchMessages.size()==0){
				report.reportPass("Successfully verified the mandatory validation messages in Add Tenant model window");
			}else{
				report.reportFail("Failed to verify the mandatory validation messages in Add Tenant model window: "+unmatchMessages);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void verifyValidationMessagesinAddTenantModelWindow(DataTable messages){
		try {
			ArrayList<String> expMessages = new ArrayList<>(messages.asList());
			webActions.waitAndClick(lnk_OrganizationMaintenance, "Organization Maintenance Link");
			webActions.waitAndClick(btn_AddNewTenant, "Add New Tenant");
			webActions.waitForVisibilityOfAllElements(lbl_AddTenantAllFeilds, "AddTenant All Feilds");
			webActions.sendKeys(txt_ShortName, "123@$ abcde", "Short Name");
			webActions.sendKeys(txt_CRMID, "abcd@as", "CRMID");
			webActions.sendKeys(txt_WebAnalyticsSiteId, "abcdefghi", "WebAnalyticsSiteId");
			webActions.sendKeys(txt_URL, "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwx", "URL");
			webActions.pressTab();
			ArrayList<String> actMessages=new ArrayList<String>();
			webActions.waitForPageLoaded();
			actMessages.addAll(webActions.getDatafromWebTable(lbl_MandatoryMessageAllFeilds));
			report.reportInfo("Actual messages: "+actMessages);
			report.reportInfo("Expected messages: "+expMessages);
			ArrayList<String> unmatchMessages=webActions.getUmatchedInArrayComparision(actMessages, expMessages);
			if(unmatchMessages.size()==0){
				report.reportPass("Successfully verified the validation messages in Add Tenant model window");
			}else{
				report.reportFail("Failed to verify the validation messages in Add Tenant model window: "+unmatchMessages);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void verifyCancelButton(){
		try {
			webActions.waitAndClick(lnk_OrganizationMaintenance, "Organization Maintenance Link");
			webActions.waitAndClick(btn_AddNewTenant, "Add New Tenant");
			webActions.waitForVisibilityOfAllElements(lbl_AddTenantAllFeilds, "AddTenant All Feilds");
			webActions.click(lbl_AddTenantCloseX, "Close X");
			report.reportPass("Successfully closed the Add New Tenant by clicking on Close X button");
			webActions.waitAndClick(btn_AddNewTenant, "Add New Tenant");
			webActions.waitForVisibilityOfAllElements(lbl_AddTenantAllFeilds, "AddTenant All Feilds");
			webActions.waitAndClick(btn_Cancel_AddTenant, "Cancel");
			report.reportPass("Successfully closed the Add New Tenant by clicking on Cancel button");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public String addNewTenant(DataTable testData){
		String organization=getDatafromMap(testData,"Organization");
		String tenantName=getDatafromMap(testData,"Tenant Name");
		tenantName=tenantName+"_"+webActions.getRandomString(5);
		try {
			organization=createNewOrganization(organization);
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_AddNewTenant, "Add New Tenant");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_AddTenantAllFeilds, "AddTenant All Feilds");
			webActions.sendKeys(dd_Organization,organization,"Organization");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_TenantName,tenantName, "Tenant Name");
			webActions.sendKeys(txt_ShortName, getDatafromMap(testData,"Short Name"), "Short Name");
			webActions.sendKeys(txt_CRMID, getDatafromMap(testData,"CRM ID"), "CRM ID");
			webActions.sendKeys(txt_WebAnalyticsSiteId, getDatafromMap(testData,"Web Analytics Site Id"), "Web Analytics Site Id");
			webActions.sendKeys(dd_AuthenticationMethod, getDatafromMap(testData,"Authentication Method"), "Authentication Method");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_URL, getDatafromMap(testData,"URL"), "URL");
			webActions.waitForPageLoaded();
			webActions.pressTab();
			webActions.pressTab();
			webActions.pressEnter();
			//webActions.click(btn_Save_AddTenant, "Save");
			//webActions.clickBYJS(btn_Save_AddTenant, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle = titleContent[0];
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message after Tenant created: "+actContent);
			String successMessage="Tenant created successfully.";
			report.reportInfo("Expected alert message after Tenant created: "+successMessage);
			report.reportInfo("Newly created Tenant Name: "+tenantName);
			if(successMessage.contains(actContent)){
				report.reportPass("Successfully created Tenant");
			}else{
				report.reportFail("Failed to created Tenant: "+actContent);
			}
			webActions.waitForPageLoaded();
			viewTenants.enterTestData("Tenant Name", tenantName);
			ArrayList<String> actData=webActions.getDataFromResultsGrid(viewTenants.grid_Header,viewTenants.grid_Results,"Tenant Name",viewTenants.getTagName("Tenant Name"));
			report.reportInfo("Actual Tenant Name: "+actData);
			report.reportInfo("Expected Tenant Name: "+tenantName);
			ArrayList<String>unMatchData=webActions.isFullArrayMatchWithData(actData,tenantName);
			if(unMatchData.size()==0){
				report.reportPass("Successfully verified the Tenant Name");
			}else{
				report.reportFail("Failed to verify the Tenant Name: "+unMatchData);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
		return tenantName;
	}
	
	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(lnk_OrganizationMaintenance);
	}

}
