package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.ModuleStatusServiceTrackerPage;
import com.ipas.hf.web.pages.ipasPages.SignalRPage;

import cucumber.api.java.en.Then;

public class ModuleStatusServiceTrackerSteps {
	
	Login logIn = new Login();
	HomePage home = new HomePage();
	ModuleStatusServiceTrackerPage modStatus=new ModuleStatusServiceTrackerPage();
	SignalRPage signalR   =new SignalRPage();

	
	@Then("Verify Service Tracker module status as {string} in All Modules in Account Search")
	public void Verify_service_tracker_module_status_in_Account_Search(String type) {
		modStatus.accountsearchModuleStatus(type);
	}
	
	@Then("Verify Service Tracker module status as {string} and {string} in Needs Attention in Account Search")
	public void Verify_service_tracker_module_status_in_Needs_Attention_in_Account_Search(String moduleName,String moduleStatus) {
		modStatus.getModuleStatusinNeedAttention(moduleName, moduleStatus);
	}
	
	@Then("simple search in Service Tracker with AccountNumber as {string}")
	public void simple_search_in_Service_Tracker(String AccountNum) {
		modStatus.AcctNumber = logIn.getVisitIdFromResponse(AccountNum);
		modStatus.serviceTrackerSimpleSearch(modStatus.AcctNumber);
	}
	
	@Then("simple search with Page refresh in Service Tracker with AccountNumber as {string}")
	public void simple_search_with_page_refresh_in_Service_Tracker(String AccountNum) {
		modStatus.AcctNumber = logIn.getVisitIdFromResponse(AccountNum);
		modStatus.serviceTrackerSimpleSearchPageRefresh(modStatus.AcctNumber);
		signalR.VerifyVisitCardisDisplayed(modStatus.AcctNumber);
	}
	
	@Then("Verify the module status as {string} on service tracker board with Account Number as {string}")
	public void Verify_the_module_status_on_Service_Tracker_board(String type,String Acctnum) {
		modStatus.AcctNumber = logIn.getVisitIdFromResponse(Acctnum);
		modStatus. modStatusServiceTrackerBoard(type,modStatus.AcctNumber);
	}
	
	@Then("Verify the success icon in financial clearance status in service tracker with AccountNumber as {string}")
	public void Verify_the_success_icon_in_financial_clearance_status_in_Service_Tracker(String AccountNum) {
		modStatus.AcctNumber = logIn.getVisitIdFromResponse(AccountNum);
		modStatus.successIconServiceTracker(modStatus.AcctNumber);
	}
	
	
	@Then("Verify the high priority status in Account Search")
	public void Verify_high_priority_module_status_in_Account_Search() {
		modStatus.highPriorityAcctSearch();
	}
	
	@Then("Verify the module status changed to {string} in All Data Panel with Account Number as {string}")
	public void Verify_the_module_status_in_All_Data_Panel_in_Service_Tracker(String Status,String AccountNum) {
		modStatus.AcctNumber = logIn.getVisitIdFromResponse(AccountNum);
		modStatus.AllDataPanel(Status,modStatus.AcctNumber);
	}
	
	@Then("Verify the module status changed to {string} in Service Tracker Panel")
	public void Verify_the_module_status_changed_in_Service_Tracker_Panel(String Status) {
		modStatus.modStatServTrackerPanel(Status);
	}
	
	@Then("Verify the display of wheel chair on service tracker board")
	public void Verify_the_display_of_wheelchair_on_service_tracker_board() {
		modStatus.wheelChairDisplayedBoard();
	}
	
	@Then("Verify the display of wheel chair in All Data panel with Account Number as {string}")
	public void Verify_the_display_of_wheelchair_in_AllData_panel(String AccountNum) {
		modStatus.AcctNumber = logIn.getVisitIdFromResponse(AccountNum);
		modStatus.wheelChairAllDataPanel(modStatus.AcctNumber);
	}
	
	@Then("Verify the display of wheel chair in Service Tracker panel")
	public void Verify_the_display_of_wheelchair_in_serviceTracker_panel(){
		modStatus.wheelChairServiceTrackerPanel();
	}
	
	@Then("Verify the wheel chair is not displayed on service tracker board")
	public void Verify_the_wheelchair_is_not_displayed_on_service_tracker_board() {
		modStatus.wheelChairNotDisplayedBoard();
	}
	
	@Then("Verify the wheel chair is not displayed in All Data panel with Account Number as {string}")
	public void Verify_the_wheelchair_is_not_displayed_in_AllData_panel(String AccountNum) {
		modStatus.AcctNumber = logIn.getVisitIdFromResponse(AccountNum);
		modStatus.wheelChairNotDisplayedAllData(modStatus.AcctNumber);
	}
	
	@Then("Verify the wheel chair is not displayed in Service Tracker panel")
	public void Verify_the_wheelchair_is_not_displayed_in_serviceTracker_panel() {
		modStatus.wheelChairNotDisplayedServiceTracker();
	}
	
	@Then("Verify able to enable wheel chair on service tracker board as {string}")
	public void Verify_able_to_enable_wheel_chair_on_service_tracker_board(String selectMode) {
		modStatus.enableWheelChair(selectMode);
	}
	
	@Then("Navigate to Service Tracker Panel with Account Number as {string}")
	public void navigate_to_Service_tracker_panel(String AccountNum)  {
		modStatus.AcctNumber = logIn.getVisitIdFromResponse(AccountNum);
		modStatus.NavigateToServiceTrackerPanelModelWindow(modStatus.AcctNumber);
	}
	
	@Then("Open Model Window")
	public void Open_Model_Window()
	{
		modStatus.openModelWindow();
	}
	
	@Then("Change the Module status in Model Window as {string}")
	public void Change_the_Module_Status_in_Model_Window(String type)
	{
		modStatus.changeModuleStatus(type);
	}
	
	@Then("Verify the module status as {string} in Service Tracker panel")
	public void Verify_the_module_status_in_serviceTracker_panel(String Status) {
		modStatus.modStatServTrackerPanel(Status);;
	}
	
	@Then("Verify the navigation to Service Tracker panel")
	public void Verify_the_navigation_to_serviceTracker_panel() {
		modStatus.navigateToServiceTrackerPanel();
	}
}
