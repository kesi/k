package com.ipas.hf.web.pages.ipasPages;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

public class SpecialAssistancePage extends BasePage {

	String resetPassword="";
	private RestActions rest = new RestActions();

	@FindBy(xpath = "//input[@id='username']")
	private WebElement txt_UserName;

	@FindBy(xpath ="//div/div/div[@class='e-toolbar-item e-template'][1]")
	private WebElement tab_SPAssitance;

	@FindBy(xpath="//label[@for='checked']")
	private WebElement lbl_WheelChair;

	@FindBy(xpath="//ejs-tab[1]/div[2]/div[2]/div[1]/form[1]/div[2]/button[1]")
	private WebElement btn_SACancel;

	@FindBy(xpath="//ejs-tab[1]/div[2]/div[2]/div[1]/form[1]/div[2]/button[2]")
	private WebElement btn_SASubmit;

	@FindBy(xpath="//ejs-switch[1]/span[@class='e-switch-handle']")
	private WebElement rdbtn_WheelChair;

	@FindBy(xpath="//span[@class='e-switch-handle e-switch-active']")
	private WebElement rdbtn_Active;

	@FindBy(xpath="//span[@class='e-switch-handle']")
	private WebElement rdbtn_InActive;

	@FindBy(xpath="//div[@class='card-header']/img[@src='assets/images/wheelchair.png']")
	private WebElement img_VistCardWheelChair;

	@FindBy(xpath = "//form[1]/div[1]/ejs-textbox[1]/span[1]/input[1]")
	private WebElement txt_Location;

	public SpecialAssistancePage() {
		PageFactory.initElements(driver, this);
	}

	public void navigateToSpecialAssistance() throws Exception{
		try{
			webActions.waitForVisibility(tab_SPAssitance, "Special Assitance");
			report.reportInfo("Special Asistance Tab is displayed");
			webActions.clickBYJS(tab_SPAssitance, "Special Assistance");
			report.reportInfo("Clicked on Special Assistance");
			Thread.sleep(2000);
			webActions.waitForVisibility(lbl_WheelChair, "Wheel Chair");
			String actText = webActions.getText(lbl_WheelChair, "Wheel Chair");
			if(actText.trim().contentEquals("Request Wheelchair")){
				report.reportPass("Request Wheelchair Label is displaed properly");
			}else{
				throw new Exception("Failed to read Request Wheelchair Label");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyCancel() throws Exception{
		try{
			webActions.assertDisplayed(btn_SACancel, "Cancel");
			report.reportInfo("Cancel button is displayed");
			String btnCancel =webActions.getAttributeValue(btn_SACancel, "class", "Cancel");
			if(btnCancel.contentEquals("btn btn-light btn-md")){
				report.reportPass("Cancel button is in Enabled mode");
			}else{
				throw new Exception("Cancel button is not displayed in Enabled mode");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifySubmit() throws Exception{
		try{
			webActions.assertDisplayed(btn_SASubmit, "Submit");
			report.reportInfo("Submit button is displayed");
			String btnSubmit =webActions.getAttributeValue(btn_SASubmit, "class", "Submit");
			if(btnSubmit.contentEquals("btn btn btn-primary btn-md")){
				report.reportPass("Submit button is in disabled mode");
			}else{
				throw new Exception("Submit button is not displayed in the Disabled Mode");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void selectWheelChair(String selectMode) throws Exception{
		try{
			if(selectMode.contentEquals("Enabled")){
				webActions.waitForVisibility(rdbtn_WheelChair, "WheelChair RadioButton",15);
				if(webActions.isDisplayed(rdbtn_WheelChair, "WheelChair RadioButton")){	
					report.reportInfo("Wheel chair is displayed as Disabled");
					webActions.waitForVisibility(rdbtn_WheelChair, "WheelChair RadioButton",15);
					webActions.clickBYJS(rdbtn_WheelChair, "WheelChair RadioButton");
					report.reportInfo("Clicked on Wheel chair Radiobutton");
					Thread.sleep(3000);
					webActions.waitForVisibility(rdbtn_Active, "Wheel Chair",15);
					if(webActions.isDisplayed(rdbtn_Active, "Wheel Chair"))
						report.reportPass("WheelChair radio button is displayed as Enabled");
				}else{
					throw new Exception("Failed to identify WheelChair radio button as enabled");
				}	
			}
			else if(selectMode.contentEquals("Disabled")){
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(rdbtn_Active, "WheelChair RadioButton",15);
				if(webActions.isDisplayed(rdbtn_Active, "WheelChair RadioButton")){
					report.reportInfo("Wheel chair is displayed as Enabled");
					webActions.waitForVisibility(rdbtn_Active, "WheelChair Deselect",15);
					webActions.clickBYJS(rdbtn_Active, "WheelChair Deselect");
					webActions.waitForPageLoaded();
					Thread.sleep(3000);
					webActions.waitForVisibility(rdbtn_InActive, "Disabled Wheel Chair",1);
					if(webActions.isDisplayed(rdbtn_InActive, "WheelChair Deselect")){
						report.reportPass("Wheel chair is disabled");
					}
				}else {
					throw new Exception("Failed to identify WheelChair radio button as disabled");
				}
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyWheelChair() throws Exception{
		try{
			webActions.waitForVisibility(rdbtn_WheelChair, "WheelChair RadioButton",15);
			webActions.waitForClickAbility(rdbtn_WheelChair, "Wheel Chair");
			report.reportInfo("Wheel Chair Radio button is displayed");
			String actValue= webActions.getAttributeValue(rdbtn_WheelChair, "class", "Radio button On");
			if(actValue.contentEquals("e-switch-handle e-switch-active")){
				report.reportPass("Wheel Chair option is selected");
			}else if(actValue.contentEquals("e-switch-handle")){
				report.reportPass("Wheel Chair option is deselected");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		} 
	}

	public void clickSASubmit() throws Exception{
		try{
			webActions.assertDisplayed(btn_SASubmit, "Submit");
			report.reportInfo("Submit button is displayed");
			webActions.clickBYJS(btn_SASubmit, "Submit Buton");
			Thread.sleep(3000);
			report.reportPass("Clicked on Submit button in Model Window");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void clickCancel() throws Exception{
		try{
			webActions.assertDisplayed(btn_SACancel, "Cancel");
			report.reportInfo("Cancel button is displayed");
			webActions.click(btn_SACancel, "Cancel Buton");
			report.reportPass("Clicked on Cancel button in Special Assistance Tab");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void wheelChairNotDisplayed() throws Exception{		
		try{webActions.waitForPageLoaded();
			webActions.isDisplayed(img_VistCardWheelChair, "WheelChair Icon");
			report.reportFail("Wheel Chair is displayed");
		}catch(Exception e){
			report.reportPass("Wheel Chair is Not displayed");
		}		
	}

	public void wheelChairDisplayed() throws Exception{
		try{	
			webActions.waitForPageLoaded();
			if(webActions.isDisplayed(img_VistCardWheelChair, "WheelChair Icon")){
				report.reportPass("Wheel Chair is displayed");
			}else{
				throw new Exception("unable to find wheel chair icon on visit card");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void enterLocation(String data) throws Exception{
		try{
			webActions.waitForVisibility(txt_Location, "Location TextBox");
			report.reportInfo("Location Text box is displayed in Special Assitance Tab");
			webActions.sendKeys(txt_Location, data, "Location TextBox");
			report.reportPass("Entered Data in Location Text Box");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyLocationDisabled() throws Exception{
		try{webActions.waitForPageLoaded();
		String actText= webActions.getAttributeValue(txt_Location, "disabled", "Location TextBox");
		if(actText.contentEquals("true")){
			report.reportPass("Location textbox is disabled");
		}else{
			throw new Exception("Location text box is not in expected mode");
		}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyLocationEnabled() throws Exception{
		try{
			String actText= webActions.getAttributeValue(txt_Location, "class", "Location TextBox");
			if(actText.contentEquals("form-control mt-10 mb-15 ng-untouched ng-pristine ng-valid e-control e-textbox e-lib e-input")){
				report.reportPass("Location textbox is enabled");
			}else{
				throw new Exception("Location text box is not in expected mode");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public SpecialAssistancePage openIpasApp() {
		try {
			String URL = TestBase.prop.ipasURL();
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to Open iPAS application");
		}
		return (SpecialAssistancePage) base(SpecialAssistancePage.class);
	}



	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_UserName);
	}

}
