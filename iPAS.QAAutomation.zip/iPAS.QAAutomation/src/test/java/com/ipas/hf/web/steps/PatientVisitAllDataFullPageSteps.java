package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.PatientVisitAllDataFullPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class PatientVisitAllDataFullPageSteps {

	PatientVisitAllDataFullPage visitFullPage=new PatientVisitAllDataFullPage();

	@Then("Verify the display of title as {string} for All Data Panel")
	public void verify_the_display_of_title_as_for_All_Data_Panel(String panelTitle) {
		visitFullPage.verifyAllDataPanelTitle(panelTitle);

	}	
	@Then("Get the value from response body as {string} and verify the displayed breadcrumb based on followed by Patient Visit number as {string} and as {string}")
	public void get_the_value_from_response_body_as_and_verify_the_displayed_breadcrumb_based_on_followed_by_Patient_Visit_number_as_and_as(String visitId, String pageNavigation, String data) throws Exception {
		visitFullPage.verifyDisplayedBreadcrumbFollowedbyAllData(visitId,pageNavigation,data);
	}

	@Then("Click on All Data Link")
	public void click_on_All_Data_Link() {
		visitFullPage.clickOnAllDataLink();
	}

	@Then("Verify the patient visit summary information fileds on All Data Full Page")
	public void verify_the_patient_visit_summary_information_fileds_on_All_Data_Full_Page(DataTable summaryfields) {
		visitFullPage.verifyVisitSUmmaryFields(summaryfields);
	}

	@Then("Verify the Patient visit summary information on All Data Full Page as {string}")
	public void verify_the_Patient_visit_summary_information_on_All_Data_Full_Page_as(String scenarioName) {
		visitFullPage.verifyVisitSummaryInfo(scenarioName);
	}

	@Then("Verify the display of {string} on summary")
	public void verify_the_display_of_on_summary(String data) {
		visitFullPage.verifyPatientName(data);
	}

	@Then("Verify the display of panels")
	public void verify_the_display_of_panels(DataTable panles) {
		visitFullPage.verifyPanelsTitle(panles);
	}

	@Then("Verify expand and collapse of {string}")
	public void verify_expand_and_collapse_of(String panelName) throws Exception {
		visitFullPage.verifyExpandandCollapseOfthePanel(panelName);
	}

	@Then("Get the value from JSON and get value of {string} and verify the value from {string}")
	public void get_the_value_from_JSON_and_get_value_of_and_verify_the_value_from(String value, String panelName) {
		visitFullPage.verifyFullPagePanelValues(value, panelName);
	}


}