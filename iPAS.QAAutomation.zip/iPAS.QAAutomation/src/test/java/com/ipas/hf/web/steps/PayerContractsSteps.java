package com.ipas.hf.web.steps;


import com.ipas.hf.web.pages.ipasPages.PayerContractsPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class PayerContractsSteps {

	PayerContractsPage payCont = new PayerContractsPage();

	
	@Then("Verify the GUI components in Patient Responsibility Estimator Panel")
	public void verify_the_GUI_components_in_Patient_Responsibility_Estimator_Panel(DataTable testData) {
		payCont.verifyGUIComponentsinPatientResponsibilityEstimatorPanel(testData);
	}
	
	@Then("Verify the Breadcrumb for Add Contract page")
	public void verify_the_Breadcrumb_for_Add_Contract_page(DataTable testData) {
		payCont.verifyGUIComponentsinAddContractPage(testData);
	}

	@Then("Verify the mandatory field validation messages and Cancel  Button")
	public void verify_the_mandatory_field_validation_messages_and_Cancel_Button(DataTable testData) {
		payCont.verifytheMandatoryFieldValidationMessageAndCancelButtonFunctionality(testData);
	}
	
	@Then("Navigate to Add Contract Page")
	public void navigate_to_Add_Contract_Page() {
		payCont.navigateAddContractPage();
	}

	@Then("Verify the Add Contract")
	public void verify_the_Add_Contract(DataTable testData) {
		payCont.AddContract(testData);
	}
	
	@Then("Verify the Update Contract")
	public void verify_the_Update_Contract(DataTable testData) {
	    payCont.updateContract(testData);
	}
	
	@Then("Verify the Add Contract and assign to plan code")
	public void verify_the_Add_Contract_and_assign_to_plan_code(DataTable testData) {
		payCont.navigatePayerConfiguration(testData);
	}

}