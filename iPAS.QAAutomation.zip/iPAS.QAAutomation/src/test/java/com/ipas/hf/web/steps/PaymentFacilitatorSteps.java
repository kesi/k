package com.ipas.hf.web.steps;



import org.json.simple.parser.ParseException;

import com.ipas.hf.web.pages.ipasPages.PaymentFacilitatorPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class PaymentFacilitatorSteps {

	PaymentFacilitatorPage payments=new PaymentFacilitatorPage();

	@Then("Search Account Number in {string} page and navigate to Patient Visit Main Page")
	public void search_Account_Number_in_page_and_navigate_to_Patient_Visit_Main_Page(String pageName) {
		payments.navigatePatientVisitMainPage(pageName);
	}

	@Then("Verify the validation error message in the Panel if {string} when navigate from {string} page")
	public void verify_the_validation_error_message_in_the_Panel_if_when_navigate_from_page(String errorMessage, String pageName) {
		payments.verifytheErrorMessageifNoPaymentsinPanel(errorMessage, pageName);
	}
	
	@Then("Navigate to Payment Facilitator page from {string} page")
	public void navigate_to_Payment_Facilitator_page_from_page(String pageName) {
		payments.navigatetoPaymentFacilitatorPage(pageName);
	}
	
	@Then("Navigate to {string} module by click on module link from Needs Attention")
	public void navigate_to_module_by_click_on_module_link_from_Needs_Attention(String moduleName) {
		payments.clickModuleLinkFromNeedsAttentioninAccountSearchPage(moduleName);
	}

	@Then("Verify the display Patient Visit Summary Information in Payments Facilitator page {string}")
	public void verify_the_display_Patient_Visit_Summary_Information_in_Payments_Facilitator_page(String scenarioName) {
		payments.verifyPatientVisitSummaryInformation(scenarioName);
	}
	
	@Then("Verify the display of field names under Current Visit section")
	public void verify_the_display_of_field_names_under_Current_Visit_section(DataTable fieldNames) {
		payments.verifyCurrentVisitSectionFeildNames(fieldNames);
	}
	
	@Then("Verify the display of header names under Historical Balance section")
	public void verify_the_display_of_header_names_under_Historical_Balance_section(DataTable fieldNames) {
		payments.verifyHistoricalBalanceFeildNames(fieldNames);
	}

	@Then("Verify the displayed breadcrumb as {string} when navigate from {string} page")
	public void verify_the_displayed_breadcrumb_as_when_navigate_from_page(String menuName,String pageName) {
		payments.verifyDisplayedBreadcrumb(menuName,pageName);
	}
	
	@Then("Verify the warning alert title as {string} message as {string} if user leaves page without saving changes")
	public void verify_the_warning_alert_title_as_message_as_if_user_leaves_page_without_saving_changes(String alertTitle,String alertMessage ) {
		payments.verifyWarningAlertMessageWhenUserLeavesPageWithoutSavingChanges(alertTitle, alertMessage);
	}
	
	@Then("Verify the functionality of Save Payment and Initiate Payment")
	public void verify_the_functionality_of_Save_Payment_and_Initiate_Payment(DataTable testData) {
	  payments.savePaymentandInitiatePayment(testData);
	}
	
	@Then("Save Payment Amount and verify the amounts in Payment Facilitator Panel and Financial Clearance Status")
	public void save_Payment_Amount_and_verify_the_amounts_in_Payment_Facilitator_Panel_and_Financial_Clearance_Status(DataTable testData) {
		payments.savePaymentVerifytheAmountsinPaymentFacilitatorPanelandFinancialClearanceStatus(testData);
	}
	
	@Then("Verify the functionality of Save Payment with discount and Initiate Payment")
	public void verify_the_functionality_of_Save_Payment_with_discount_and_Initiate_Payment(DataTable testData) {
		payments.savePaymentwithDiscountandInitiatePayment(testData);
	}
	
	@Then("Verify the validation error message if value is empty in Payment and Total Amount fields")
	public void verify_the_validation_error_message_if_value_is_empty_in_Payment_and_Total_Amount_fields(DataTable errorMessages) {
		payments.verifyTheValidationErrorMessageIfValueIsEmpty(errorMessages);
	}
	
	@Then("Verify the Fields in Collect Payment Window and cancel the payment")
	public void verify_the_Fields_in_Collect_Payment_Window_and_cancel_the_payment(DataTable feilds) {
		payments.verifyTheFeildsInCollectPaymentWindow(feilds);
	}
	
	@Then("Verify the Remaining Balance in current visit section and Financial Clearance Status in all pages")
	public void verify_the_Remaining_Balance_in_current_visit_section_and_Financial_Clearance_Status_in_all_pages(DataTable testData) {
		payments.savePaymentandInitiatePartialPayment(testData);
	}
	
	@Then("Update json file for Payment Facilitator and Estimate Amount {string}")
	public void update_json_file_for_Payment_Facilitator_and_Estimate_Amount(String estimateAmount) throws Exception {
		payments.updatePaymentFacilitatorJSON(estimateAmount);
	}
	
	@Then("Update Account Number in json file")
	public void update_Account_Number_in_json_file() throws Exception {
		payments.updateAccountNumber();
	}
	
	@Then("Verify the functionality of multiple account payments and verify the data if switch anther account")
	public void verify_the_functionality_of_multiple_account_payments_and_verify_the_data_if_switch_anther_account(DataTable testData) {
		payments.multipleAccountPaymentsAndVerifytheDataifSwitchAntherAccount(testData);
	}
	
	@Then("Save Payment and Initiate Payment without validations")
	public void save_Payment_and_Initiate_Payment_without_validations(DataTable testData) {
		payments.savePaymentandInitiatePaymentWithoutValidations(testData);
	}
	
	@Then("Verify the fields names in Reverse Payment window")
	public void verify_the_fields_names_in_Reverse_Payment_window(DataTable fields) {
		payments.verifyFieldsNamesinReversePayment(fields);
	}

	@Then("Verify the validation messages in Reverse Payment window")
	public void verify_the_validation_messages_in_Reverse_Payment_window(DataTable messages) {
		payments.verifyValidationMessagesinReversePayment(messages);
	}
	
	@Then("Verify the Reversal Payment")
	public void verify_the_Reversal_Payment(DataTable testData) {
		payments.reversePaymentandVerifyData(testData);
	}
	
	@Then("Verify the reversal payment functionality from Historical visit section")
	public void verify_the_reversal_payment_functionality_from_Historical_visit_section(DataTable testData) {
		payments.verifyReversePaymentfromHistoricalVisitSection(testData);
	}
	
	@Then("Verify the validation message if Total amount less than discounted amount")
	public void verify_the_validation_message_if_Total_amount_less_than_discounted_amount(DataTable testData) {
		payments.verifyValidationMessageifTotalAmountLessThanDiscountAmount(testData);
	}
	
	@Then("Verify the data in payment receipt file")
	public void verify_the_data_in_payment_receipt_file(DataTable testData) throws Exception {
		payments.verifyDatainPaymentReceipt(testData);
	}
	
	@Then("Verify the payment receipt is able to open when click on Receipt buttons")
	public void verify_the_payment_receipt_is_able_to_open_when_click_on_Receipt_buttons(DataTable testData) throws Exception {
		payments.verifyPaymentReceiptWhenClickonReceiptButton(testData);
	}
	
	@Then("Add New Patient from iPAS and Initiate Payment")
	public void add_New_Patient_from_iPAS_and_Initiate_Payment(DataTable testData) {
		payments.addNewPatientandInitiatePayment(testData);
	}
	
	@Then("Verify the Payment type and Amount values in Panel")
	public void verify_the_Payment_type_and_Amount_values_in_Panel(DataTable testData) {
		payments.verifyPaymentTypeAndPaymentAmounts(testData);
	}
	
	@Then("Update Estimate Amount {string}")
	public void update_Estimate_Amount(String estimateAmount) throws Exception {
		payments.updatePatientResponsiblityEstimate(estimateAmount);
	}

	@Then("Verify the Payment Panel if Estimate amount is null and save visit charge with CoPay type")
	public void verify_the_Payment_Panel_if_Estimate_amount_is_null_and_save_visit_charge_with_CoPay_type(DataTable testData) {
		payments.verifyPaymentPanelifEstimateAmountisNULLandSavePayament(testData);
	}

	@Then("Verify the Payment facilitator will IGNORE a patient visit charge is already saved with CoPay")
	public void verify_the_Payment_facilitator_will_IGNORE_a_patient_visit_charge_is_already_saved_with_CoPay(DataTable testData) {
		payments.verifythePatientVisitChargeisAlreadySavedwithCoPay(testData);
	}

}
