package com.ipas.hf.web.pages.ipasPages;

import java.awt.HeadlessException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Sleeper;

import com.ipas.hf.dbutilities.SqlQueries;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;


public class VIMServiceTrackerPage extends BasePage {

	private JSONObject jsonObject;
	private static final String VIMServiceTracker = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\VIMServiceTracker.json";
	private StepLogging log = StepLogging.getLoggingObject();

	private RestActions rest = new RestActions();

	@FindBy(xpath="//span[contains(text(),'Confirm Visit')]")
	private WebElement btn_Confirm;

	@FindBy(xpath="//a[contains(text(),'VIM Terms & Conditions')]")
	private WebElement lnk_VIMTermsConditions;


	@FindBy(xpath="//div[@class='visit-status']//h3")
	private WebElement lbl_StatusHeader;

	@FindBy(xpath="//div[@class='visit-status']//p")
	private WebElement lbl_StatusMessage;

	@FindBy (xpath = "//service-tracker-lobby//ejs-dropdownlist/span/input")
	private WebElement ddl_Lobby;

	@FindBy (xpath = "//button[contains(text(),'Apply')]")
	private WebElement btn_Apply;

	@FindBy (xpath = "(//div[@class='service-tracker-panel']//div/span)[3]")
	private WebElement lbl_ServiceTrackerShortPanelStatus;

	@FindBy (xpath="//a[text()=' Service Tracker']")
	private WebElement lnk_ServiceTracker;

	@FindBy (xpath = "(//div[@class='panel-containArea']//span)[3]")
	private WebElement lbl_ServiceTrackerFullPageStatus;

	@FindBy (xpath = "//table[@class='e-table']/tbody/tr[2]/td/div")
	private List <WebElement> lbl_Tracking_History;

	@FindBy (linkText="Send arrival notice")
	private WebElement btn_SendArrivalNotice;

	@FindBy (xpath="//p[contains(text(),'Scheduled')]")
	private WebElement lbl_Scheduled;

	@FindBy (xpath="//a[contains(text(),'Submit')]")
	private WebElement btn_Submit;

	@FindBy (xpath="//a[contains(text(),'Cancel')]")
	private WebElement btn_Cancel;

	@FindBy (xpath="//p[@class='desktop_container_title']")
	private WebElement lbl_HeaderMessage;

	@FindBy (xpath="//p[@class='subheader']")
	private WebElement lbl_Message;

	@FindBy (xpath="//span[contains(text(),'I need wheelchair assistance')]")//label[@for='mat-slide-toggle-1-input']
	private WebElement toggle_Wheelchair;

	@FindBy (xpath="//h3[contains(text(),'Message submitted')]")
	private WebElement lbl_AlertHeaderMessage;

	@FindBy (xpath="//p[contains(text(),'Thank you for letting us know you have arrived.')]")
	private WebElement lbl_AlertMessage;

	@FindBy (xpath="//a[contains(text(),'OK')]")
	private WebElement btn_OK;

	@FindBy (xpath="//h3[contains(text(),'You sent arrival notice')]")
	private WebElement lbl_SentMessage;

	@FindBy (xpath="//div[@class='visit-status']//h3")
	private WebElement lbl_ConfirmHeaderMessage;

	@FindBy (xpath="//div[@class='visit-status']//p")
	private WebElement lbl_ConfirmMessage;

	@FindBy (xpath="//span[contains(text(),'Transactions')]")
	private WebElement btn_Transactions;

	@FindBy (xpath="//div[@class='header']/h5")
	private WebElement lbl_TransactionsHeaderTitle;

	@FindBy (xpath="//div[@class='grid']/div[2]")
	private WebElement lbl_EventType;

	@FindBy (xpath="//div[@class='grid']/div[4]")
	private WebElement lbl_EventDate;

	@FindBy (xpath="//div[@class='header']/img")
	private WebElement btn_TransactionsClose;

	@FindBy (xpath="//mat-form-field//input")
	private WebElement txt_LocationDetails;

	@FindBy (xpath="//p[contains(text(),'Share My Visit')]")
	private WebElement lnk_ShareMyVisit;

	@FindBy (xpath="//input[@formcontrolname='firstName']")
	private WebElement txt_FirstName;

	@FindBy (xpath="//input[@formcontrolname='lastName']")
	private WebElement txt_LastName;

	@FindBy (xpath="//input[@formcontrolname='phoneNumber']")
	private WebElement txt_PhoneNumber;


	@FindBy(xpath="//mat-radio-button//div[@class='mat-radio-label-content']")
	private List<WebElement> lbl_RelationshipToPatient;

	@FindBy (xpath="//a[contains(text(),'Confirm')]")
	private WebElement btn_Confirm_AddAuthorizedUser;

	@FindBy (xpath="//div[@class='agreement u-margin-top-medium']/mat-checkbox")
	private WebElement chk_TermsAndConditions;

	@FindBy (xpath="//mat-dialog-container[@role='dialog']//app-button[2]/a")
	private WebElement btn_Confirm_TermsConditions;

	@FindBy (xpath="//p[contains(text(),'Pending Validation')]")
	private WebElement lbl_PendingValidation;

	@FindBy (xpath="//h3[contains(text(),'Main screen')]")
	private WebElement lnk_MainScreen;

	@FindBy (xpath="//img[@class='user-icon']/..")
	private WebElement lbl_UsersCount;

	@FindBy (xpath="//span[@class='more-action']")
	private WebElement btn_MoreAction;

	@FindBy (xpath="//div[contains(text(),'AUTHORIZED USERS')]")
	private WebElement tab_AuthorizedUsers;

	@FindBy (xpath="//table[@role='grid']/tbody/tr/td/span")
	private List<WebElement> tr_AuthorizedUsers;

	@FindBy (xpath="//span[contains(text(),'Authorized Users')]")
	private WebElement lbl_UsersCountServiceTracker;




	VIMLoginPage vim=new VIMLoginPage();
	PaymentFacilitatorPage payment=new PaymentFacilitatorPage();
	Login logIn=new Login();
	ExportExcelPage file=new ExportExcelPage();

	public VIMServiceTrackerPage() {
		PageFactory.initElements(driver, this);
	}


	public void confirmVisit(DataTable testData){
		try {
			ArrayList<String>actData=new ArrayList<String>();
			ArrayList<String>expData=new ArrayList<String>(testData.asList());
			String actButtonName=webActions.waitAndGetText(btn_Confirm, "Confirm");
			if(actButtonName.contentEquals("Confirm Visit")){
				report.reportPass("Confirm Visit button label name is verified successfully");
			}else{
				report.reportFail("Failed to verify Confirm Visit button label name");
			}
			webActions.waitAndClick(btn_Confirm, "Confirm Visit");
			String statusHeader=webActions.waitAndGetText(lbl_StatusHeader, "StatusHeader");
			actData.add(statusHeader);

			String statusMessage=webActions.waitAndGetText(lbl_StatusMessage, "StatusMessage").replace("\n", "").replace("\r", "");
			actData.add(statusMessage);
			report.reportInfo("Actual Data is: "+actData);
			report.reportInfo("Expected Data is: "+expData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the message after click on confirm visit");
			}else{
				report.reportFail("Failed to verify the message after click on confirm visit");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void selectLobby(String lobbyName){
		try {
			webActions.sendKeys(ddl_Lobby, lobbyName, "Lobby");
			webActions.click(btn_Apply, "Apply");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void clickVisitIDServiceTracker(){
		try{
			String visitID= logIn.getVisitIdFromResponse("$..displayPatientAccountId");
			/*Thread.sleep(5000);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();*/
			driver.findElement(By.linkText(visitID)).click();	
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			report.reportPass("clicked on Link");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyServiceTrackerStatusShotPanel(String expStatus){
		try {
			clickVisitIDServiceTracker();
			String status=webActions.waitAndGetText(lbl_ServiceTrackerShortPanelStatus, "Status");
			report.reportInfo("Service Tracker Short Panel Status: "+status);
			report.reportInfo("Expected Status in Service Tracker Short Panel: "+expStatus);
			if(status.contentEquals(expStatus)){
				report.reportPass("Successfully verified the Service Tracker Short Panel Status");
			}else{
				report.reportFail("Fail to verify the Service Tracker Short Panel Status");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyTrackingHistory(DataTable testData){
		try {
			ArrayList<String>expData=new ArrayList<String>(testData.asList());
			StringBuilder verify=new StringBuilder();
			expData.add(webActions.getCurrentSystemDate());
			ArrayList<String> actData=new ArrayList<String>();
			webActions.click(lnk_ServiceTracker, "Service Tracker");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String actStatus=webActions.waitAndGetText(lbl_ServiceTrackerFullPageStatus, "Status");
			report.reportInfo("Actual Status in Service Tracker Full page: "+actStatus);
			if(actStatus.contentEquals(expData.get(0))){
				report.reportPass("Successfully verified the Status in Service Tracker Full page");
			}
			else{
				report.reportFail("Fail to verify the Status in Service Tracker Full page",true);
				verify.append("Fail to verify the Status in Service Tracker Full page");
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();

			/*for (WebElement el: lbl_Tracking_History) {
				actData.add(el.getText());
			}*/
			for (int i = 0; i <=2; i++) {
				actData.add(lbl_Tracking_History.get(i).getText());
			}
			report.reportInfo("Actual Tracking History: "+actData);
			report.reportInfo("Expected Tracking History: "+expData);
			ArrayList<String>unMatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unMatch.size()==0){
				report.reportPass("Successfully verified the Tracking History in Service Tracker Full page");
			}
			else{
				report.reportFail("Fail to verify the Tracking History in Service Tracker Full page"+unMatch,true);
				verify.append("Fail to verify the Tracking History in Service Tracker Full page");
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyTransactions(DataTable testData){
		try {
			ArrayList<String>expData=new ArrayList<>(testData.row(1));
			expData.add(webActions.getCurrentSystemDate());
			ArrayList<String>actData=new ArrayList<>();
			webActions.waitAndClick(btn_Transactions, "Transactions");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			actData.add(webActions.waitAndGetText(lbl_EventType, "EventType"));
			actData.add(webActions.waitAndGetText(lbl_EventDate, "EventDate"));
			report.reportInfo("Actual Transactions data: "+actData);
			report.reportInfo("Expected Transactions data: "+expData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Transactions data");
				webActions.click(btn_TransactionsClose, "Close");
			}else{
				report.reportFail("Fail to verify the Transactions data: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}


	public void sendArrivalNotice(DataTable testData){
		try {
			StringBuffer verify=new StringBuffer();
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			ArrayList<String> actData=new ArrayList<String>();
			String btnName=webActions.waitAndGetText(btn_SendArrivalNotice, "SendArrivalNotice");
			if(btnName.contentEquals("Send arrival notice")){
				report.reportPass("Send Arrival Notice Button verified successfully");
			}else{
				report.reportFail("Fail to verify the Send Arrival Notice Button",true);
				verify.append("Fail to verify the Send Arrival Notice Button");
			}
			webActions.waitAndClick(btn_SendArrivalNotice, "SendArrivalNotice");
			actData.add(webActions.waitAndGetText(lbl_HeaderMessage, "HeaderMessage"));
			actData.add(webActions.waitAndGetText(lbl_Message, "Message").replace("\n", "").replace("\r", ""));

			webActions.click(btn_Submit, "Submit");
			actData.add(webActions.waitAndGetText(lbl_AlertHeaderMessage, "AlertHeaderMessage"));
			actData.add(webActions.waitAndGetText(lbl_AlertMessage, "AlertMessage"));
			webActions.waitAndClick(btn_OK, "OK");
			actData.add(webActions.waitAndGetText(lbl_SentMessage, "SentMessage"));
			actData.add(webActions.waitAndGetText(lbl_ConfirmHeaderMessage, "ConfirmHeaderMessage"));
			actData.add(webActions.waitAndGetText(lbl_ConfirmMessage, "ConfirmMessage").replace("\n", "").replace("\r", ""));
			report.reportInfo("Actual data: "+actData);
			report.reportInfo("Expected data: "+expData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the label names and alert messages");
			}
			else{
				report.reportFail("Fail to verify the label names and alert messages: "+unmatch,true);
				verify.append("Fail to verify the label names and alert messages");
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void sendArrivalNoticeWithWheelChair(String parking, DataTable testData){
		try {
			StringBuffer verify=new StringBuffer();
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			ArrayList<String> actData=new ArrayList<String>();
			String btnName=webActions.waitAndGetText(btn_SendArrivalNotice, "SendArrivalNotice");
			if(btnName.contentEquals("Send arrival notice")){
				report.reportPass("Send Arrival Notice Button verified successfully");
			}else{
				report.reportFail("Fail to verify the Send Arrival Notice Button",true);
				verify.append("Fail to verify the Send Arrival Notice Button");
			}
			webActions.waitAndClick(btn_SendArrivalNotice, "SendArrivalNotice");
			actData.add(webActions.waitAndGetText(lbl_HeaderMessage, "HeaderMessage"));
			actData.add(webActions.waitAndGetText(lbl_Message, "Message").replace("\n", "").replace("\r", ""));

			webActions.click(toggle_Wheelchair, "WheelChair");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			Thread.sleep(3000);
			driver.findElement(By.xpath("//p[text()='"+parking+"']")).click();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(txt_LocationDetails, "LocationDetails");
			webActions.sendKeys(txt_LocationDetails, "Automation Testing", "LocationDetails");
			webActions.waitForPageLoaded();
			webActions.click(btn_Submit, "Submit");
			actData.add(webActions.waitAndGetText(lbl_AlertHeaderMessage, "AlertHeaderMessage"));
			actData.add(webActions.waitAndGetText(lbl_AlertMessage, "AlertMessage"));
			webActions.waitAndClick(btn_OK, "OK");
			actData.add(webActions.waitAndGetText(lbl_SentMessage, "SentMessage"));
			actData.add(webActions.waitAndGetText(lbl_ConfirmHeaderMessage, "ConfirmHeaderMessage"));
			actData.add(webActions.waitAndGetText(lbl_ConfirmMessage, "ConfirmMessage").replace("\n", "").replace("\r", ""));
			report.reportInfo("Actual data: "+actData);
			report.reportInfo("Expected data: "+expData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the label names and alert messages");
			}
			else{
				report.reportFail("Fail to verify the label names and alert messages: "+unmatch,true);
				verify.append("Fail to verify the label names and alert messages");
			}

			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void addAuthorizedUser(DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			String actText=webActions.waitAndGetText(lnk_ShareMyVisit, "Share My Visit");
			if(actText.contentEquals("Share My Visit")){
				report.reportPass("Successfully verified the Share My Visit label name");
			}else{
				report.reportFail("Failed to verify the Share My Visit label name",true);
				verify.append("Failed to verify the Share My Visit label name");
			}
			webActions.waitAndClick(lnk_ShareMyVisit, "Share My Visit");
			String firstName=webActions.getDatafromMap(testData, "First Name");
			String lastName=webActions.getDatafromMap(testData, "Last Name");
			webActions.waitAndClick(txt_FirstName, "First Name");
			webActions.sendKeys(txt_FirstName, firstName, "First Name");
			webActions.sendKeys(txt_LastName, lastName, "Last Name");
			webActions.sendKeys(txt_PhoneNumber, webActions.getDatafromMap(testData, "Phone Number"), "Phone Number");
			for (WebElement webElement : lbl_RelationshipToPatient) {
				String actRelationship=webElement.getText();
				if(actRelationship.contentEquals(webActions.getDatafromMap(testData, "Relationship"))){
					webElement.click();
					break;
				}
			}
			webActions.click(btn_Confirm_AddAuthorizedUser, "Confirm");
			webActions.waitAndClick(chk_TermsAndConditions, "Terms And Conditions");
			webActions.click(btn_Confirm_TermsConditions, "Confirm");
			String actStatus=webActions.waitAndGetText(lbl_PendingValidation, "PendingValidation");
			if(actStatus.contains(webActions.getDatafromMap(testData, "Status"))){
				report.reportPass("Successfully verified the added user status");
			}else{
				report.reportFail("Failed to verify the added user status",true);
				verify.append("Failed to verify the added user status");
			}
			String expAuthorizedUser=firstName+" "+lastName;
			String actAuthorizedUser=driver.findElement(By.xpath("//p[contains(text(),'"+expAuthorizedUser+"')]")).getText();
			if(actAuthorizedUser.contains(expAuthorizedUser)){
				report.reportPass("Successfully User is added to the list");
			}else{
				report.reportFail("Fail to verify the User is added to the list.",true);
				verify.append("Fail to verify the User is added to the list.");
			}

			webActions.click(lnk_MainScreen, "Main Screen");
			String actUsersCount=webActions.waitAndGetText(lbl_UsersCount, "UsersCount");
			if(actUsersCount.contains("1")){
				report.reportPass("Successfully verified the User count after user is added");
			}else{
				report.reportFail("Fail to verify the User count after user is added",true);
				verify.append("Fail to verify the User count after user is added");
			}

			String actAuthorizedUserName=driver.findElement(By.xpath("//p[contains(text(),'"+expAuthorizedUser+"')]")).getText();
			if(actAuthorizedUserName.contains(expAuthorizedUser)){
				report.reportPass("Successfully verified the added username in the VIM main page");
			}else{
				report.reportFail("Fail to verify the added username in the VIM main page",true);
				verify.append("Fail to verify the added username in the VIM main page");
			}

			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyAuthorizedUserServiceTracker(DataTable testData){
		try {
			ArrayList<String>expData=new ArrayList<String>(testData.row(1));
			StringBuffer verify=new StringBuffer();
			clickVisitIDServiceTracker();
			webActions.waitAndGetText(lbl_ServiceTrackerShortPanelStatus, "Status");
			webActions.waitAndClick(lnk_ServiceTracker, "Service Tracker");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_MoreAction, "More Action");
			webActions.waitAndClick(tab_AuthorizedUsers, "AuthorizedUsers");
			String actCount=webActions.waitAndGetText(lbl_UsersCountServiceTracker, "UsersCount");
			if(actCount.contentEquals("1 Authorized Users")){
				report.reportPass("Successfully verified the User count in Service Tracker iPAS");
			}else{
				report.reportFail("Fail to verify the User count in Service Tracker iPAS",true);
				verify.append("Fail to verify the User count in Service Tracker iPAS");
			}
			ArrayList<String>actData=webActions.getDatafromWebTable(tr_AuthorizedUsers);
			report.reportInfo("Actual Authorized Users data is: "+actData);
			report.reportInfo("Expected Authorized Users data is: "+expData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Authorized User data in Service Tracker iPAS");
			}else{
				report.reportFail("Fail to verify the Authorized User data in Service Tracker iPAS: "+unmatch,true);
				verify.append("Fail to verify the Authorized User data in Service Tracker iPAS: "+unmatch);
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void navigatePatientVisitAllDataPage(){
		try {
			String accountNumber = logIn.getVisitIdFromResponse("$..displayPatientAccountId");
			payment.searchAccountNuberinAccountSearchPage(accountNumber);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}


	@SuppressWarnings("unchecked")
	public void updateVIMServiceTrackerJSON() throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(VIMServiceTracker);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			try {
				String number = rest.getUniqueNumber();
				newNum = "A" + number;
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(0);
				tenantPatient.put("TenantPatientId", newNum);

				tenantPatient = (JSONObject) msg.get(3);
				tenantPatient.put("TenantPatientId", newNum);

				String test = (String) tenantPatient.get("TenantPatientId");	
			} catch (Exception e) {
				log.error("Failed to update tenant patiend id", e);
				e.printStackTrace();
			}
			try {
				visitObject.put("AccountNumber", newNum);
				visitObject.put("VisitNumber", newNum);
				Object tt = visitObject.get("VisitDate");
				String updatedDate = rest.updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);

			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}

			FileWriter file = new FileWriter(VIMServiceTracker);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}


	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(lnk_VIMTermsConditions);
	}

}
