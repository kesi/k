package com.ipas.hf.web.steps;

import java.util.Properties;

import org.json.simple.parser.ParseException;

import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.utilities.ConfigProperties;
import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.ServiceTrackerSimpleSearchPage;
import com.ipas.hf.web.pages.ipasPages.UpdateVisitPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ServiceTrackerSimpleSearchSteps {
	private ConfigProperties configProp = TestBase.prop;
	ServiceTrackerSimpleSearchPage stsSearch = new ServiceTrackerSimpleSearchPage();
	UpdateVisitPage updateVisit = new UpdateVisitPage();
	Login logIn = new Login();
	
	
	@Then("Post json data using event type as {string}")
	public void post_json_data_using_event_type_as(String eventType) throws ParseException {
		stsSearch.updatePatientVisitJsonFile(eventType);
	}

	@Then("Search with Patient First Name and search in Service Tracker Board as {string}")
	public void search_with_Patient_First_Name_and_search_in_Service_Tracker_Board_as(String patientFirstName) throws Exception {
		String pName= stsSearch.getVisitIdFromResponse("$..patientLastName");
		updateVisit.simpleSearch(pName);
		stsSearch.comparePatientNameOnVisitCard(pName);
	}

	@Then("Search with Last Name and search in Service Tracker Board as {string}")
	public void search_with_Last_Name_and_search_in_Service_Tracker_Board_as(String patientLastName) throws Exception {
		String pName= logIn.getVisitIdFromResponse(patientLastName);
		updateVisit.simpleSearch(pName);
		stsSearch.comparePatientNameOnVisitCard(pName);
	}

	@Given("Enter data as {string} and verify the results")
	public void enter_data_as_and_verify_the_results(String responseValue) throws Exception {
		stsSearch.srchWithVisitIDAndVerifyVCardCount(responseValue);
	}

	@Then("Verify the message in ST Page as {string}")
	public void verify_the_message_in_ST_Page_as(String expMessage) throws Exception {
		stsSearch.verifyNoRecordsFoundMsg(expMessage);
	}

	@Then("Verify visit card is displayed on Service Tracker Board Page with account number as {string}")
	public void verify_visit_card_is_displayed_on_Service_Tracker_Board_Page_with_account_number_as(String responseValue) throws Exception {
		String visitID= logIn.getVisitIdFromResponse(responseValue);
		stsSearch.verifyDisplayOfVisitCard(visitID);
		//stsSearch.verifyVisitCardisDisplayed(visitID);
	}
	
	@Then("verify locked icon on service tracker card and service tracker panels")
	public void verify_locked_icon_on_service_tracker_card_and_service_tracker_panels() {
		stsSearch.verifyLockedIconinServiceTarcker();
	}

	@Then("verify the Account unlock process from service card")
	public void verify_the_Account_unlock_process_from_service_card() {
		stsSearch.unlockTheLockedAccount();
	}
}
