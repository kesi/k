package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.swing.text.html.HTML;

import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class PayerContractsPage extends BasePage {

	@FindBy(xpath="//span[contains(text(),'Patient Responsibility Estimator')]")
	private WebElement panel_PatientResponsibilityEstimator;

	@FindBy(xpath="//div[contains(text(),'Maintain Facility Payer Contracts for patient resp')]")
	private WebElement lbl_PatientResponsibilityEstimatorPanel;

	@FindBy(xpath="//span[contains(text(),'Patient Responsibility Estimator')]/../../..")
	private WebElement expand_PatientResponsibilityEstimator;

	@FindBy(linkText="Payer Contract Configuration")
	private WebElement lnk_PayerContractConfiguration;

	@FindBy(xpath="//div[contains(@class,'breadcrum-container')]/span")
	private List<WebElement> lbl_Breadcrumb;

	@FindBy(xpath="//button[text()='Add New Contract']")
	private WebElement btn_AddNewContract;

	@FindBy(xpath="//button[text()='Apply']")
	private WebElement btn_Apply;

	@FindBy(xpath="//input[@placeholder='Name']")
	private WebElement txt_ContractName;

	@FindBy(id="startDate_input")
	private WebElement txt_StartDate;

	@FindBy(id="EndDate_input")
	private WebElement txt_EndDate;

	@FindBy(xpath="//ejs-dropdownlist[@formcontrolname='Payer']/span")
	private WebElement dd_Payer;

	@FindBy(xpath="//ejs-dropdownlist[@formcontrolname='estimateProductRefId']/span")
	private WebElement dd_PlanType;

	String networkType="//ejs-radiobutton/input[@value='";

	@FindBy(xpath="//ejs-radiobutton[1]/label")
	private WebElement rd_InNetwork;

	@FindBy(xpath="//ejs-radiobutton[2]/label")
	private WebElement rd_OutNetwork;

	@FindBy(xpath="//ejs-switch[@formcontrolname='deductibleIncludedInOutOfPocket']/input")
	private WebElement switch_DeductibleIncludedInOutOfPocket;

	@FindBy(xpath="//ejs-switch[@formcontrolname='copayIncludedInOutOfPocket']/input")
	private WebElement switch_CopayIncludedInOutOfPocket;

	@FindBy(xpath="(//ejs-numerictextbox[@formcontrolname='selfPayPercentOfCharges']/span/input)[1]")
	private WebElement txt_SelfPayPercentOfCharges;

	@FindBy(xpath="//button[contains(text(),'Select CPT')]")
	private WebElement btn_SelctCPT;

	@FindBy(xpath="(//span/ejs-checkbox)[3]")
	private WebElement chk_SelctCPT;

	String selctCPT="(//span/ejs-checkbox)[";

	@FindBy(xpath="//button[contains(text(),'Add')]")
	private WebElement btn_Add;

	@FindBy(xpath="(//ejs-numerictextbox[@formcontrolname='secondProcedurePaysAt']/span/input)[1]")
	private WebElement txt_SecondProcedurePaysAt;

	@FindBy(xpath="(//ejs-numerictextbox[@formcontrolname='thirdProcedurePaysAt']/span/input)[1]")
	private WebElement txt_ThirdProcedurePaysAt;

	@FindBy(xpath="(//ejs-numerictextbox[@formcontrolname='additionalProcedurePaysAt']/span/input)[1]")
	private WebElement txt_AdditionalProcedurePaysAt;						

	@FindBy(xpath="//button[text()='Cancel']")
	private WebElement btn_Cancel;

	@FindBy(xpath="//span[(text()='Save')]")
	private WebElement btn_Save;

	@FindBy(xpath="//div[@class='mandatory']")
	private List<WebElement> lbl_MandatoryMessages;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;

	@FindBy(xpath = "//input[@placeholder='Type Contract Name']")
	private WebElement txt_SearchBox;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr[1]/td[1]//a")
	private WebElement tr_ContractName;

	@FindBy(xpath = "//span[text()='Update']")
	private WebElement btn_Update;

	@FindBy(linkText = "Maintenance")
	private WebElement lnk_Maintenance;

	@FindBy(xpath = "(//ejs-switch[@disablelink='EditEligibilityPlanCodeSettings'])[1]")
	private WebElement switch_ActiveEligibiltyPlan;		

	@FindBy(xpath = "//ejs-dropdownlist[@disablelink='EditEligibilityPlanCodeSettings']/span")
	private WebElement dd_PayerCode;	

	@FindBy(xpath ="//button[contains(text(),'Save')]")
	private WebElement btn_Save_EligibilityPlanCode;

	@FindBy(xpath ="//ejs-switch[@role='switch']")
	private WebElement switch_ActiveEstimatorPlan;

	@FindBy(xpath ="//ejs-dropdownlist[@id='payerContractId']/span")
	private WebElement dd_SelectContract;

	@FindBy(xpath ="//a[contains(text(),'Save')]")
	private WebElement btn_Save_EstimatorPlan;

	HomePage home =new HomePage();
	CreateABNFormPage abn=new CreateABNFormPage();
	EligibilityPayerMaintenancePage epm=new EligibilityPayerMaintenancePage();
	public PayerContractsPage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyGUIComponentsinPatientResponsibilityEstimatorPanel(DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			ArrayList<String>expData=new ArrayList<String>(testData.asList());
			ArrayList<String> actData=new ArrayList<String>();
			actData.add(webActions.waitAndGetText(panel_PatientResponsibilityEstimator, "PatientResponsibilityEstimator"));
			actData.add(webActions.waitAndGetText(lnk_PayerContractConfiguration, "PayerContractConfiguration"));
			actData.add(webActions.waitAndGetText(lbl_PatientResponsibilityEstimatorPanel, "PatientResponsibilityEstimatorPanel"));
			ArrayList<String>unMatchPanelData=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unMatchPanelData.size()==0){
				report.reportPass("Successfully verified GUI components in Patient Responsibility Estimator Panel", true);
			}else{
				verify.append("Failed to verify GUI components in Patient Responsibility Estimator Panel: "+unMatchPanelData);
				report.reportFail("Failed to verify GUI components in Patient Responsibility Estimator Panel", true);
			}

			webActions.click(panel_PatientResponsibilityEstimator, "PatientResponsibilityEstimator");
			String actStatus=webActions.getAttributeValue(expand_PatientResponsibilityEstimator, "aria-expanded", "expand_PatientResponsibilityEstimator");
			if("true".contains(actStatus)){
				report.reportPass("Successfully collapsed the Patient Responsibility Estimator Panel", true);
			}else{
				verify.append("Failed to collapse the Patient Responsibility Estimator Panel: "+actStatus);
				report.reportFail("Failed to collapse the Patient Responsibility Estimator Panel", true);
			}

			webActions.waitForPageLoaded();
			webActions.click(panel_PatientResponsibilityEstimator, "PatientResponsibilityEstimator");
			String actEpandStatus=webActions.getAttributeValue(expand_PatientResponsibilityEstimator, "aria-expanded", "expand_PatientResponsibilityEstimator");
			if("false".contains(actEpandStatus)){
				report.reportPass("Successfully expanded the Patient Responsibility Estimator Panel: ", true);
			}else{
				verify.append("Failed to expand the Patient Responsibility Estimator Panel"+actEpandStatus);
				report.reportFail("Failed to expand the Patient Responsibility Estimator Panel", true);
			}

			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyGUIComponentsinAddContractPage(DataTable breadcrumb ){
		try {
			ArrayList<String> expectdBreadcrumb = new ArrayList<>(breadcrumb.asList());
			webActions.refreshPage();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_PayerContractConfiguration, "PayerContractConfiguration");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(tr_ContractName, "ContractName", 20);
			webActions.waitAndClick(btn_AddNewContract, "AddNewContract");
			ArrayList<String> actualBreadcrumb=webActions.getDatafromWebTable(lbl_Breadcrumb);
			report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumb);
			report.reportInfo("Expected Breadcrumb Titles "+expectdBreadcrumb);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumb, expectdBreadcrumb);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Breadcrumb Titles in Add Contract page");
			}else{
				throw new Exception("Fail to verify the Breadcrumb Titles in Add Contract page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifytheMandatoryFieldValidationMessageAndCancelButtonFunctionality(DataTable validationMessages){
		try {
			ArrayList<String> expectdValidationMessages = new ArrayList<>(validationMessages.asList());
			webActions.waitForPageLoaded();
			webActions.waitAndGetText(btn_Cancel, "Cancel");
			webActions.click(txt_ContractName, "Contract Name");
			webActions.click(txt_StartDate, "Start Date");
			webActions.waitForLoad();
			webActions.click(txt_EndDate, "End Date");
			webActions.waitForLoad();
			ArrayList<String> actualValidationMessages=webActions.getDatafromWebTable(lbl_MandatoryMessages);
			report.reportInfo("Actual Validation Messages: "+actualValidationMessages);
			report.reportInfo("Expected Validation Messages: "+expectdValidationMessages);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualValidationMessages, expectdValidationMessages);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Mandatory Field Validation Messages in Add Contarct page");
			}else{
				throw new Exception("Fail to verify the Mandatory Field Validation Messages in Add Contarct page: "+unmatch);
			}
			webActions.click(btn_Cancel, "Cancel");
			webActions.waitForLoad();
			String expName=webActions.waitAndGetText(btn_AddNewContract, "AddNewContract");
			if("Add New Contract".contains(expName)){
				report.reportPass("Successfully verified the Cancel button in Add Contarct page");
			}else{
				throw new Exception("Fail to verify the Cancel button in Add Contarct page: "+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void navigateAddContractPage(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_PayerContractConfiguration, "PayerContractConfiguration");
			webActions.waitForVisibility(tr_ContractName, "ContractName", 20);
			webActions.waitAndClick(btn_AddNewContract, "AddNewContract");
			webActions.waitAndGetText(btn_Save, "Save");
		} catch (Exception e) {
			report.reportFail("Not able to navigate to Add Contract page: "+e);
		}
	}

	public String AddContract(DataTable testData){
		String contractName="";
		try {
			StringBuilder unmatch=new StringBuilder();
			contractName=webActions.getDatafromMap(testData, "Contract Name");
			contractName+=webActions.getRandomString(5);
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_ContractName, contractName, "Contract Name");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_StartDate, webActions.getSystemCurrentDate(), "StartDate");
			webActions.sendKeys(txt_EndDate, webActions.getNextDate(90), "EndDate");
			//webActions.sendKeys(dd_Payer, webActions.getDatafromMap(testData, "Payer"), "Payer");
			selectDropdown(dd_Payer, webActions.getDatafromMap(testData, "Payer"), "Payer");
			//webActions.sendKeys(dd_PlanType, webActions.getDatafromMap(testData, "Plan Type"), "PlanType");
			selectDropdown(dd_PlanType, webActions.getDatafromMap(testData, "Plan Type"), "PlanType");
			webActions.waitForPageLoaded();
			String Nt=webActions.getDatafromMap(testData, "Network Type");
			if("No".contentEquals(Nt)){
				webActions.click(rd_OutNetwork, "Out Network");
			}
			String deductibleincluded=webActions.getDatafromMap(testData, "Deductible included");
			if(deductibleincluded.contentEquals("Yes")){
				webActions.click(switch_DeductibleIncludedInOutOfPocket, "DeductibleIncludedInOutOfPocket");
			}
			String copayincluded=webActions.getDatafromMap(testData, "Copay included");
			if(copayincluded.contentEquals("Yes")){
				webActions.click(switch_CopayIncludedInOutOfPocket, "CopayIncludedInOutOfPocket");
			}
			String payerType=webActions.getDatafromMap(testData, "Payer Type");
			if("Self Pay".contentEquals(payerType)){
				webActions.waitForPageLoaded();
				webActions.sendKeys(txt_SelfPayPercentOfCharges, webActions.getDatafromMap(testData, "Percent of Charges"), "SelfPayPercentOfCharges");
			}
			webActions.waitForPageLoaded();
			webActions.click(btn_SelctCPT, "Selct CPT");
			webActions.waitForVisibility(chk_SelctCPT, "chk_SelctCPT", 15);
			webActions.waitForPageLoaded();
			for (int i = 2; i <=5; i++) {
				driver.findElement(By.xpath(selctCPT+i+"]")).click();
			}
			webActions.waitForPageLoaded();
			webActions.click(btn_Add, "Add");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_SecondProcedurePaysAt, webActions.getDatafromMap(testData, "Second Procedure Pays At"), "SecondProcedurePaysAt");
			webActions.sendKeys(txt_ThirdProcedurePaysAt, webActions.getDatafromMap(testData, "Third Procedure Pays At"), "ThirdProcedurePaysAt");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_AdditionalProcedurePaysAt, webActions.getDatafromMap(testData, "Additional Procedure Pays At"), "AdditionalProcedurePaysAt");
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_Save, "Save");
			webActions.click(btn_Save, "Save");
			try {
				String actContent = getAlertMessage();
				report.reportInfo("Actual alert message after user is created: "+actContent);
				if(("Data saved successfully.".contains(actContent))){
					report.reportPass("Successfully displayed the alert message after Contract is added: "+actContent);
				}
				else{
					unmatch.append("Alert message is not displayed/matched after Contract is added");
					report.reportFail("Alert message is not displayed/matched after Contract is added: "+actContent,true);
				}
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibility(tr_ContractName, "ContractName", 20);
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			webActions.waitAndClick(txt_SearchBox, "Search");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_SearchBox, contractName, "Search");
			webActions.click(btn_Apply, "Apply");
			webActions.waitForPageLoaded();
			String actContractName=webActions.waitAndGetText(tr_ContractName, "ContractName");
			if(contractName.contains(actContractName)){
				report.reportPass("Successfully displayed the Contract in the Payer Contracts grid: "+actContractName);	
			}else{
				unmatch.append("Fail to verify the Contract Name in the Payer Contracts grid: "+actContractName);
				report.reportFail("Fail to verify the Contract Name in the Payer Contracts grid: "+actContractName,true);
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
		return contractName;
	}

	public void updateContract(DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			String contractName=AddContract(testData);
			webActions.waitForPageLoaded();
			webActions.click(tr_ContractName, "ContractName");
			webActions.waitAndGetText(btn_Update, "Update");
			contractName=getDatafromMap(testData, "Contract Name");
			contractName+=webActions.getRandomString(5);
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_ContractName, "Contract Name");
			webActions.sendKeys(txt_ContractName, contractName, "Contract Name");
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_StartDate, "StartDate");
			webActions.sendKeys(txt_StartDate, webActions.getNextDate(1), "StartDate");
			webActions.clearValue(txt_EndDate, "EndDate");
			webActions.sendKeys(txt_EndDate, webActions.getNextDate(60), "EndDate");
			//webActions.sendKeys(dd_Payer, webActions.getDatafromMap(testData, "Payer"), "Payer");
			//selectDropdown(dd_Payer, webActions.getDatafromMap(testData, "Payer"), "Payer");
			//webActions.sendKeys(dd_PlanType, webActions.getDatafromMap(testData, "Plan Type"), "PlanType");
			selectDropdown(dd_PlanType, getDatafromMap(testData, "Plan Type"), "PlanType");
			webActions.waitForPageLoaded();
			String Nt=getDatafromMap(testData, "Network Type");
			if("No".contentEquals(Nt)){
				webActions.click(rd_OutNetwork, "Out Network");
			}
			else if("Yes".contentEquals(Nt)){
				webActions.click(rd_InNetwork, "In Network");
			}

			webActions.click(switch_DeductibleIncludedInOutOfPocket, "DeductibleIncludedInOutOfPocket");
			webActions.click(switch_CopayIncludedInOutOfPocket, "CopayIncludedInOutOfPocket");

			String payerType=getDatafromMap(testData, "Payer Type");
			if("Self Pay".contentEquals(payerType)){
				webActions.waitForPageLoaded();
				webActions.click(txt_SelfPayPercentOfCharges, "SelfPayPercentOfCharges");
				webActions.waitForPageLoaded();
				webActions.sendKeys(txt_SelfPayPercentOfCharges, getDatafromMap(testData, "Percent of Charges"), "SelfPayPercentOfCharges");

			}
			webActions.waitForPageLoaded();
			webActions.click(btn_SelctCPT, "Selct CPT");
			webActions.waitForVisibility(chk_SelctCPT, "chk_SelctCPT", 15);
			webActions.waitForPageLoaded();
			for (int i = 6; i <=8; i++) {
				driver.findElement(By.xpath(selctCPT+i+"]")).click();
			}
			webActions.waitForPageLoaded();
			webActions.click(btn_Add, "Add");
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_SecondProcedurePaysAt, "SecondProcedurePaysAt");
			webActions.sendKeys(txt_SecondProcedurePaysAt, getDatafromMap(testData, "Second Procedure Pays At"), "SecondProcedurePaysAt");
			webActions.clearValue(txt_ThirdProcedurePaysAt, "ThirdProcedurePaysAt");
			webActions.sendKeys(txt_ThirdProcedurePaysAt,getDatafromMap(testData, "Third Procedure Pays At"), "ThirdProcedurePaysAt");
			webActions.clearValue(txt_AdditionalProcedurePaysAt, "AdditionalProcedurePaysAt");
			webActions.sendKeys(txt_AdditionalProcedurePaysAt, getDatafromMap(testData, "Additional Procedure Pays At"), "AdditionalProcedurePaysAt");
			webActions.click(btn_Update, "Update");
			try {
				String actContent = getAlertMessage();
				report.reportInfo("Actual alert message after user is created: "+actContent);
				if(("Data updated successfully.".contains(actContent))){
					report.reportPass("Successfully displayed the alert message after Contract is updated: "+actContent);
				}
				else{
					unmatch.append("Alert message is not displayed/matched after Contract is updated");
					report.reportFail("Alert message is not displayed/matched after Contract is updated: "+actContent,true);
				}
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibility(tr_ContractName, "ContractName", 20);
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			webActions.waitAndClick(txt_SearchBox, "Search");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_SearchBox, contractName, "Search");
			webActions.click(btn_Apply, "Apply");
			webActions.waitForPageLoaded();
			String actContractName=webActions.waitAndGetText(tr_ContractName, "ContractName");
			if(contractName.contains(actContractName)){
				report.reportPass("Successfully updated the Contract and displayed in the Payer Contracts grid: "+actContractName);	
			}else{
				unmatch.append("Fail to update the Contract and displayed in the Payer Contracts grid: "+actContractName);
				report.reportFail("Fail to update the Contract and displayed in the Payer Contracts grid: "+actContractName,true);
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void navigatePayerConfiguration(DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			String contractName=AddContract(testData);
			webActions.click(lnk_Maintenance, "Maintenance");
			abn.clickPayerMintenace();
			epm.clickOnAddNewPlan();
			String planCode=epm.createNewPlanCode(testData);
			webActions.waitForPageLoaded();
			String moduleName=webActions.getDatafromMap(testData, "Module Name");
			String facility=webActions.getDatafromMap(testData, "Facility");
			String payerType=webActions.getDatafromMap(testData, "Payer Type");
			if("Non Self Pay".contentEquals(payerType)){
				webActions.waitForPageLoaded();
				abn.navigateFacilityConfig(moduleName, planCode, facility);
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				for (WebElement webElement : abn.tr_Rows) {
					String txt=webElement.getText();
					if(planCode.contentEquals(txt)){					
						webElement.click();
						webActions.waitForPageLoaded();
						break;
					}
				}
				webActions.click(switch_ActiveEligibiltyPlan, "Active Eligibity");
				webActions.waitForPageLoaded();
				webActions.scrollBarHandle(btn_Save_EligibilityPlanCode, "Save"); 
				webActions.waitForPageLoaded();
				selectDropdown(dd_PayerCode, webActions.getDatafromMap(testData, "Payer Code"), "Payer Code");
				webActions.waitForPageLoaded();
				webActions.click(btn_Save_EligibilityPlanCode, "Save");
				String actContent=getAlertMessage();
				if("Request processed successfully.".contentEquals(actContent)){
					report.reportPass("Successfully mapped the payer code to facility plan code/names: "+actContent);
				}
				else{
					unmatch.append("Failed to map the payer code to facility plan code/name");
					report.reportFail("Failed to map the payer code to facility plan code/name: "+actContent,true);
				}
			}
			webActions.waitForPageLoaded();
			abn.navigateFacilityConfig("Estimator", planCode, facility);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			for (WebElement webElement : abn.tr_Rows) {
				String txt=webElement.getText();
				if(planCode.contentEquals(txt)){					
					webElement.click();
					webActions.waitForPageLoaded();
					break;
				}
			}
			webActions.click(switch_ActiveEstimatorPlan, "Active Estimator");
			webActions.waitForPageLoaded();
			selectDropdown(dd_SelectContract, contractName, "Select Contract");
			webActions.waitForPageLoaded();
			webActions.click(btn_Save_EstimatorPlan, "Save");
			String actContent=getAlertMessage();
			if("Data saved successfully.".contentEquals(actContent)){
				report.reportPass("Successfully mapped the payer contract to facility plan code/name: "+actContent);
			}
			else{
				unmatch.append("Failed to map the payer contract to facility plan code/name");
				report.reportFail("Failed to map the payer contract to facility plan code/name: "+actContent,true);
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void selectDropdown(WebElement element,String valuetoSelect,String elementName) throws Exception{
		try {
			if (!valuetoSelect.isEmpty()) {
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.click(element, elementName);
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				driver.findElement(By.xpath("//li[contains(.,'" + valuetoSelect + "')]")).click();
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public String getAlertMessage(){
		String actContent="";
		try {
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Alert Message");
			String[] titleContent=msg.split("\\n");
			actContent=titleContent[1];
		} catch (Exception e) {
		}
		return actContent;
	}

	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(1).get(keyName);	
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(lnk_PayerContractConfiguration);
	}

}