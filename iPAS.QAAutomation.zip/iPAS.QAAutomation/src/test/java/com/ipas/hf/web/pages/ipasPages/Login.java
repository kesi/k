package com.ipas.hf.web.pages.ipasPages;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

public class Login extends BasePage {

	String resetPassword="";
	private RestActions rest = new RestActions();

	@FindBy(xpath = "//input[@id='username']")
	private WebElement txt_UserName;

	@FindBy(xpath = "//input[@id='password']")
	private WebElement txt_Password;

	@FindBy(xpath = "//input[@id='kc-login']")
	private WebElement btn_Login;

	@FindBy(xpath = "//span[contains(text(),'Login ')]")
	private WebElement txt_Login;

	@FindBy(xpath = "//p[contains(text(),' Enter your User ID and Password to login.')]")
	private WebElement txt_Guide;

	@FindBy(xpath = "//a[contains(text(),' Forgot Password?')]")
	private WebElement lnk_ForgotPwd;

	@FindBy(xpath = "//a[contains(text(),' Having trouble Logging In')]")
	private WebElement lnk_HavingTbl;

	@FindBy(xpath = "//span[contains(text(),'Invalid User ID or Password.')]")
	private WebElement txt_errorMessage;

	@FindBy(xpath = "//span[contains(text(),'Forgot Password?')]")
	private WebElement txt_frgotPassword;

	@FindBy(xpath = "//p[contains(text(),'Enter your ID and instructions')]")
	private WebElement txt_instructions;

	@FindBy(id = "btnSubmit1")
	private WebElement btn_ResetPassword;

	@FindBy(xpath = "//span[contains(text(),'Please enter User ID.')]")
	private WebElement txt_enterUserID;

	@FindBy(xpath = "//span[contains(text(),'We have sent an email to you.')]")
	private WebElement txt_emailSuccessMessage;

	@FindBy(xpath = "//input[@id='identifierId']")
	private WebElement txt_gmailUserID;

	@FindBy(id = "identifierNext")
	private WebElement btn_gmaiNext;

	@FindBy(name = "password")
	private WebElement txt_gmailPassword;

	@FindBy(id = "passwordNext")
	private WebElement btn_passwrdNext;

	@FindBy(xpath = "//input[@placeholder='Search mail']")
	private WebElement txt_gmailSearch;

	@FindBy(xpath = "//td[5]/div/div/div[2]/span/span")
	private List<WebElement> lst_mailBox;

	@FindBy(xpath = "//span[contains(text(),'0 minutes ago')]//following::a[1]")
	private WebElement lnk_ResetPwd;

	@FindBy(xpath = "//*[@id=':az']")
	private WebElement btn_delete;

	@FindBy(xpath = "//*[@id=':bw']")
	private WebElement lnk_deleteMessage;

	@FindBy(xpath = "//h1")
	private WebElement lbl_verifyNumber;

	@FindBy(xpath = "//*[@id='view_container']/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div/ul/li[3]/div")
	private WebElement lnk_confirmNumber;

	@FindBy(id = "phoneNumberId")
	private WebElement txt_PhoneNumber;

	@FindBy(xpath = "//*[@id='view_container']/div/div/div[2]/div/div[2]/div/div[1]/div/div/button")
	private WebElement btn_phoneNext;

	@FindBy(xpath = "//p[contains(text(),'Enter your New Password')]")
	private WebElement lbl_newPassWord;

	@FindBy(xpath = "//li[contains(text(),'Minimum of 8 characters')]")
	private WebElement lbl_8Characters;

	@FindBy(xpath = "//li[contains(text(),'At least one upper and lower case')]")
	private WebElement lbl_upperLowerCase;

	@FindBy(xpath = "//li[contains(text(),'At least one special character')]")
	private WebElement lbl_specialChar;

	@FindBy(id = "password-new")
	private WebElement txt_newPassword;

	@FindBy(id = "password-confirm")
	private WebElement txt_confirmPassword;

	@FindBy(xpath = "//*[@value='Change Password']")
	private WebElement btn_changePassword;

	@FindBy(xpath = "//span[contains(text(),'Please enter New Password.')]")
	private WebElement lbl_enterNewPassword;

	@FindBy(xpath = "//span[contains(text(),'must contain at least 1 special characters.')]")
	private WebElement lbl_specialCharacter;

	@FindBy(xpath = "//span[contains(text(),' minimum length 8.')]")
	private WebElement lbl_minimumLength;

	@FindBy(xpath = "//span[contains(text(),'must contain at least 1 upper case characters.')]")
	private WebElement lbl_upperChar;

	@FindBy(xpath = "//span[contains(text(),'Passwords don't match.')]")
	private WebElement lbl_passwordDontMatch;

	@FindBy(xpath = "//span[contains(text(),'must not be equal to any of last 6 passwords.')]")
	private WebElement lbl_lastSixPassword;

	@FindBy(xpath = "//a[@data-toggle='dropdown']//img")
	private WebElement lnk_Menu;

	@FindBy(xpath = "//*[contains(text(),' Logout')]")
	private WebElement lnk_Logout;

	@FindBy(xpath = "//label[contains(text(),'Search')]//following::input[1]")
	private WebElement txt_SimpleSearch;

	@FindBy (xpath= "//li[@id='p-highlighted-option']/span")
	private WebElement li_SimpleSeacrh;

	@FindBy (linkText= "Account Search")
	private WebElement lnk_AccountSearch;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody/tr/td")
	private WebElement lbl_GridRecords; 
	
	@FindBy(xpath="//div[@class='emptyinfo']")
	private WebElement lbl_NoDataMsg;

	public Login() {
		PageFactory.initElements(driver, this);
	}

	public Login openIpasApp() {
		try {
			String URL = TestBase.prop.ipasURL();
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to Open iPAS application");
		}
		return (Login) base(Login.class);
	}

	public void verifyFields() {
		try {
			webActions.assertDisplayed(txt_UserName, "User name Field");
			webActions.assertDisplayed(txt_Password, "Password Field");
			webActions.assertDisplayed(btn_Login, "Login button");
			report.reportPass("Verified username,Password and Login button successfully");
		} catch (Exception e) {
			report.reportFail("Fail to verify username,Password and Login button");
		}

	}

	public void verifyLoginText(String login) {
		try {
			String textLogIn = webActions.getText(txt_Login, "Login Text");
			if (textLogIn.equals(login)) {
				report.reportPass("Verified LogIn text successfully");
			}
		} catch (Exception e) {
			report.reportFail("Failed to verify LogIn text");
		}

	}

	public void VerifyGuideText(String guideText) {
		try {
			String textGuide = webActions.getText(txt_Guide, "Guide Text");
			if (textGuide.equals(guideText)) {
				report.reportPass("Verified Guide text successfully - " + textGuide);
			}
		} catch (Exception e) {
			report.reportFail("Failed to verify Guide text");
		}

	}

	public void verifyPassWordLink() {
		try {
			webActions.assertDisplayed(lnk_ForgotPwd, "Forgot Password Link");
			report.reportPass("Verified Forgot PassWord link successfully");
		} catch (Exception e) {
			report.reportFail("Fail to verify Forgot PassWord link");
		}

	}

	public void VerifyHavingTroubleLink() {
		try {
			webActions.assertDisplayed(lnk_HavingTbl, "HAving Trouble link");
			report.reportPass("Verified Having trouble to login link successfully");
		} catch (Exception e) {
			report.reportFail("Fail to verify Having trouble to ligin link");
		}

	}

	public void clickLogin() {
		try {
			webActions.click(btn_Login, "Login Button");
			report.reportPass("Clicked on Login button");
		} catch (Exception e) {
			report.reportFail("Fail to click on login button");
		}

	}

	public void validateErrorMessage(String errorMessage) {
		try {
			String errorText = webActions.getText(txt_errorMessage, "Error message");
			if (errorText.equals(errorMessage)) {
				report.reportPass("Verified error message successfully - " + errorText);
			}
		} catch (Exception e) {
			report.reportFail("Failed to verify error message");
		}

	}

	public void enterUserName(String userName) {
		try {
			webActions.sendKeys(txt_UserName, userName, "Uesr Name");
			report.reportPass("Entered user name in to field");
		} catch (Exception e) {
			report.reportFail("Fail to enter user name");
		}

	}

	public void enterPassWord(String passWord) {
		try {
			webActions.clearValue(txt_UserName, "User Name");
			webActions.sendKeys(txt_Password, passWord, "Password");
			report.reportPass("Entered Password in to field");
		} catch (Exception e) {
			report.reportFail("Fail to enter Password");
		}

	}

	public HomePage login(String userName, String passWord) {
		try {

			webActions.waitUntilPresentAndDisplayed(txt_UserName, "UserName");
			webActions.sendKeys(txt_UserName, userName, "UserName");
			webActions.sendKeys(txt_Password, passWord, "Password");
			webActions.clickBYJS(btn_Login, "Login button");
			report.reportPass("Login Success");
		} catch (Exception e) {
			report.reportHardFail(e, "Login With Valid Credentials");
		}
		return (HomePage) base(HomePage.class);
	}

	public void clickForgotPassword() {
		try {
			webActions.click(lnk_ForgotPwd, "Forgot password link");
			report.reportPass("Clicked on forgot password link successfully");
		} catch (Exception e) {
			report.reportFail("Fail to click on forgot password link");
		}

	}

	public void verifyHeader() {
		try {
			webActions.waitUntilisDisplayed(txt_frgotPassword, "Forgot Password");
			webActions.click(txt_frgotPassword, "Forgot password Header");
			report.reportPass("Verified Forgot Password header successfully");
		} catch (Exception e) {
			report.reportFail("Fail to verify header");
		}

	}

	public void verifyResetPasswordText(String text) {
		try {
			String textHeader = webActions.getText(txt_instructions, "Instruntions header text");
			if (textHeader.equals(text)) {
				report.reportPass("Text displayed as : " + textHeader);
			}

		} catch (Exception e) {
			report.reportFail("Fail to verify text: " + text);
		}

	}

	public void verifyTextButton() {
		try {
			webActions.assertDisplayed(btn_ResetPassword, "Reset Password button");
			report.reportPass("Reset Password button verified successfully");
		} catch (Exception e) {
			report.reportFail("Fail to verify Reset Password Button");
		}

	}

	public void clickRestButton() {
		try {
			webActions.click(btn_ResetPassword, "Reset password button");
			report.reportPass("Clicked on Reset Password button successfully");
		} catch (Exception e) {
			report.reportFail("Fail to click on Reset password button");
		}

	}

	public void verifyResetError(String error) {
		try {
			webActions.waitUntilisDisplayed(txt_enterUserID, "Enter user id error");
			String errorMessage = webActions.getText(txt_enterUserID, "Enter user id error");
			if (errorMessage.equals(error)) {
				report.reportPass("Error message verified successfully");
			}

		} catch (Exception e) {
			report.reportFail("Fail to verify Error message");
		}

	}

	public void enterUserIdAndClick(String userID) {
		try {
			webActions.sendKeys(txt_UserName, userID, "User name field");
			webActions.click(btn_ResetPassword, "Reset password button");
			report.reportPass("Clicked on Reset Password button successfully");
		} catch (Exception e) {
			report.reportFail("Fail to enter userid and click on Reset password button");
		}

	}

	public void verifyEmailMessage(String message) {
		try {
			webActions.waitUntilisDisplayed(txt_emailSuccessMessage, "Success message");
			String successMessage = webActions.getText(txt_emailSuccessMessage, "Success message");
			if (successMessage.equals(message)) {
				report.reportPass("Success message verified successfully and displayed as :" + successMessage);
			}

		} catch (Exception e) {
			report.reportFail("Fail to verify Success message");
		}

	}

	public void resetPassword() {
		try {
			goToGamail();
			try {
				Set<String> windows = driver.getWindowHandles();
				Iterator<String> it = windows.iterator();
				String mainWindow = it.next();
				String popupWindow = it.next();
				driver.switchTo().window(popupWindow);
				webActions.waitUntilisDisplayed(txt_newPassword, "New PassWord");
				String number = webActions.getUniqueNumber();
				resetPassword = "iPAS@" + number;
				webActions.sendKeys(txt_newPassword, resetPassword, "New Password");
				report.reportPass("Entered new password successfully as: " + resetPassword);
				webActions.sendKeys(txt_confirmPassword, resetPassword, "New Password");
				report.reportPass("Entered confirm new password successfully as: " + resetPassword);
				webActions.click(btn_changePassword, "Change password");
				report.reportPass("Reset password button clicked successfully");
				webActions.waitForVisibility(lnk_Menu, "Menu");
				webActions.click(lnk_Menu, "Menu");
				webActions.click(lnk_Logout, "Log out link");
				webActions.waitUntilNotPresent(lnk_Logout, "LogoOut link");
				report.reportPass("Logged out successfully");
			} catch (Exception e) {
				report.reportFail("Fail to Switch window and Reset password");
			}

		} catch (Exception e) {
			report.reportFail("Reset password failed");
		}

	}

	public void goToGamail() {
		try {
			String gmailURL = TestBase.prop.gmailURL();
			webActions.loadURL(gmailURL);
			report.reportPass("Login to the Gmail application");
			webActions.waitUntilisDisplayed(txt_gmailUserID, "Gmail User name");
			webActions.sendKeys(txt_gmailUserID, "passowrdexpiry", "Email");
			webActions.click(btn_gmaiNext, "Next button");
			webActions.waitUntilisDisplayed(txt_gmailPassword, "Gmail password name");
			webActions.sendKeys(txt_gmailPassword, "iPAS@2020", "Password");
			webActions.click(btn_passwrdNext, "Password next");
			Thread.sleep(3000);
			try {
				boolean header = webActions.isDisplayed(lnk_confirmNumber, "Verify number page");
				if (header) {
					webActions.click(lnk_confirmNumber, "Confirm number");
					webActions.waitUntilisDisplayed(txt_PhoneNumber, "Phone number");
					webActions.sendKeys(txt_PhoneNumber, "9515159883", "Phone number");
					webActions.click(btn_phoneNext, "Next button");
					report.reportPass("Phone number verification done succeessfully in Gmail");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			webActions.waitUntilisDisplayed(txt_gmailSearch, "Gmail search field name");
			webActions.sendKeys(txt_gmailSearch, "Reset Password for Pelitas iPAS", "Search");
			webActions.keyBoardEnter(txt_gmailSearch, "Search");
			webActions.waitUntilListisDisplayed(lst_mailBox, "Gmail Mail list");
			lst_mailBox.get(0).click();
			webActions.waitForVisibility(lnk_ResetPwd, "Gmail search field name");
			webActions.click(lnk_ResetPwd, "Reset password link");
			report.reportPass("Successfully clicked on Rest Password link from mail");
			Thread.sleep(3000);
		} catch (Exception e) {
			report.reportFail("Failed to go to Gmail and perform click on reset password");
		}
	}

	public void verifySuccessResetMessage() {
		try {
			webActions.waitUntilNotPresent(txt_newPassword, "New Password");
			report.reportPass("Password reset completed successfully");
		} catch (Exception e) {
			report.reportFail("Reset password action failed");
		}

	}

	public void loginResetPassword() {
		try {
			String URL = TestBase.prop.ipasURL();
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
			webActions.waitUntilPresentAndDisplayed(txt_UserName, "UserName");
			webActions.sendKeys(txt_UserName, "automation4", "UserName");
			webActions.sendKeys(txt_Password, resetPassword, "Password");
			webActions.clickBYJS(btn_Login, "Login button");
			report.reportPass("Login Success");
			webActions.waitForVisibility(lnk_Menu, "Menu");
			webActions.click(lnk_Menu, "Menu");
			webActions.click(lnk_Logout, "Log out link");
			webActions.waitUntilNotPresent(lnk_Logout, "LogoOut link");
			report.reportPass("Logged out successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to login with Reset password iPAS application");
		}
	}

	public void goToResetPage() {
		try {
			goToGamail();
			try {
				Set<String> windows = driver.getWindowHandles();
				Iterator<String> it = windows.iterator();
				String mainWindow = it.next();
				String popupWindow = it.next();
				driver.switchTo().window(popupWindow);
				webActions.waitUntilisDisplayed(txt_newPassword, "New PassWord");
				report.reportPass("Switched to iPAS page successfully");
			} catch (Exception e) {
				report.reportFail("Failed to move to new iPAS reset password page");
			}
		} catch (Exception e) {

		}
	}

	public void withOutPassword(String errorMessage) {
		try {
			webActions.click(btn_changePassword, "Change password button");
			webActions.waitUntilisDisplayed(lbl_enterNewPassword, "Validation message");
			String Message = webActions.getText(lbl_enterNewPassword, "Validation message");
			if (Message.contains(errorMessage)) {
				report.reportPass("Error message verified successfully and displayed as " + Message);
			}

		} catch (Exception e) {
			report.reportFail("Failed to verify validation message: " + errorMessage);
		}
	}

	public void minimumLength(String value, String errorMessage) {
		try {
			webActions.sendKeys(txt_newPassword, value, "New password");
			webActions.sendKeys(txt_confirmPassword, value, "Confirm password");
			webActions.click(btn_changePassword, "Change password button");
			webActions.waitUntilisDisplayed(lbl_minimumLength, "Validation message");
			String Message = webActions.getText(lbl_minimumLength, "Validation message");
			if (Message.contains(errorMessage)) {
				report.reportPass("Minimum length message verified successfully and displayed as " + Message);
			}
		} catch (Exception e) {
			report.reportFail("Failed to verify validation message: " + errorMessage);
		}
	}

	public void withOutUpperCase(String value, String errorMessage) {
		try {
			webActions.sendKeys(txt_newPassword, value, "New password");
			webActions.sendKeys(txt_confirmPassword, value, "Confirm password");
			webActions.click(btn_changePassword, "Change password button");
			webActions.waitUntilisDisplayed(lbl_upperChar, "Validation message");
			String Message = webActions.getText(lbl_upperChar, "Validation message");
			if (Message.contains(errorMessage)) {
				report.reportPass("One upper case message verified successfully and displayed as " + Message);
			}
		} catch (Exception e) {
			report.reportFail("Failed to verify validation message: " + errorMessage);
		}
	}

	public void withOutSpecialChar(String value, String errorMessage) {
		try {
			webActions.sendKeys(txt_newPassword, value, "New password");
			webActions.sendKeys(txt_confirmPassword, value, "Confirm password");
			webActions.click(btn_changePassword, "Change password button");
			webActions.waitUntilisDisplayed(lbl_specialCharacter, "Validation message");
			String Message = webActions.getText(lbl_specialCharacter, "Validation message");
			if (Message.contains(errorMessage)) {
				report.reportPass("Special character message verified successfully and displayed as " + Message);
			}
		} catch (Exception e) {
			report.reportFail("Failed to verify validation message: " + errorMessage);
		}
	}

	public void lastPassword(String errorMessage) {
		try {
			System.out.println(resetPassword);
			webActions.sendKeys(txt_newPassword, resetPassword, "New password");
			webActions.sendKeys(txt_confirmPassword, resetPassword, "Confirm password");
			webActions.click(btn_changePassword, "Change password button");
			webActions.waitUntilisDisplayed(lbl_lastSixPassword, "Validation message");
			String Message = webActions.getText(lbl_lastSixPassword, "Validation message");
			if (Message.contains(errorMessage)) {
				report.reportPass(
						"Not equl to last password message verified successfully and displayed as " + Message);
			}
		} catch (Exception e) {
			report.reportFail("Failed to verify validation message: " + errorMessage);
		}
	}

	public void passWordNotMatch(String value1, String value2, String errorMessage) {
		try {
			webActions.sendKeys(txt_newPassword, value1, "New password");
			webActions.sendKeys(txt_confirmPassword, value2, "Confirm password");
			webActions.click(btn_changePassword, "Change password button");
			webActions.waitUntilisDisplayed(lbl_passwordDontMatch, "Validation message");
			String Message = webActions.getText(lbl_passwordDontMatch, "Validation message");
			if (Message.contains(errorMessage)) {
				report.reportPass("Password does not match message verified successfully and displayed as " + Message);
			}
		} catch (Exception e) {
			report.reportFail("Failed to verify validation message: " + errorMessage);
		}
	}

	public String getVisitIdFromResponse(String visitId){
		String displayVisitId = "";
		try {
			String visitIdValue = rest.getStringValueFromResponse(visitId);
			displayVisitId = visitIdValue.replaceAll("\\W", "");
			report.logPass("Validate Response Body Content Matches the Expected Value: " + visitId
					+ " Actual value: " + displayVisitId);
		} catch (AssertionError e) {
			report.logHardFail("Validate Response Body Content Matches the Request Failed ", e);
		}
		return displayVisitId;
	}

	public void simpleSearch(String value){
		try{
			webActions.waitUntilPresentAndDisplayed(txt_SimpleSearch, "Simple search");
			webActions.clearValue(txt_SimpleSearch, "Simple Search");
			webActions.waitForPageLoaded();
			try{
				webActions.waitForVisibility(lbl_GridRecords, "gridResults");
			}
			catch(Exception e){
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(lbl_NoDataMsg,"SearchResults");
			}
			webActions.sendKeys(txt_SimpleSearch, value, "Visit id");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
			webActions.waitUntilisDisplayed(li_SimpleSeacrh, "Simple search");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.click(li_SimpleSeacrh, "SimpleSearchAutoPopulate");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_GridRecords, "gridResults");
		}catch(Exception e){
		}
	}

	public void verifyAccountSearchLink(String expLabelName){
		try {
			webActions.waitUntilPresentAndDisplayed(lnk_AccountSearch, "Account Search");
			String actLabelName=webActions.waitAndGetText(lnk_AccountSearch, "Account Search");
			if(expLabelName.contains(actLabelName)){
				report.reportPass("Successfully login to the application and verified Account Search link text: "+actLabelName);
			}else{
				throw new Exception("Failed to verify the login to the application");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}	
	}

	///////////////////////////*******************ELIGIBILTY MODULE********************//////////////////////

	public Login openApplication(String tenant) {
		
		try {
			String URL="";
			if(tenant.contentEquals("washington")){
				
				URL = TestBase.prop.washingtonURL();
			}
			else if(tenant.contentEquals("eligibility")){
				URL = TestBase.prop.eligibilityURL();
			}
			
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to Open iPAS application");
		}
		return (Login) base(Login.class);
	}

	public void loginApplication(String userName, String passWord) {
		try {

			webActions.waitUntilPresentAndDisplayed(txt_UserName, "UserName");
			webActions.sendKeys(txt_UserName, userName, "UserName");
			webActions.sendKeys(txt_Password, passWord, "Password");
			webActions.clickBYJS(btn_Login, "Login button");
			webActions.waitForPageLoaded();
			report.reportPass("Login Success");
		} catch (Exception e) {
			report.reportHardFail(e, "Login With Valid Credentials");
		}
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_UserName);
	}

}
