package com.ipas.hf.web.steps;

import com.ipas.hf.azureutilities.CosmosDbDataValidation;
import com.ipas.hf.web.pages.ipasPages.MaintenancePage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class MaintenanceSteps {
	CosmosDbDataValidation comos=new CosmosDbDataValidation();
	MaintenancePage mainPage=new MaintenancePage();	

	@Then("Verify the display of {string} from maintenance page")
	public void verify_the_display_of_from_maintenance_page(String panels,DataTable panelNames) {
		mainPage.verifyPanelSectionData(panels, panelNames);
	}

	@Then("Verify the display of {string} under each panel from maintenance page")
	public void verify_the_display_of_under_each_panel_from_maintenance_page(String sections,DataTable sectionNames) {
		mainPage.verifyPanelSectionData(sections,sectionNames);
	}

	@Then("Verify the display of {string} under each section of panels from maintenance page")
	public void verify_the_display_of_under_each_section_of_panels_from_maintenance_page(String data,DataTable sectionData) {
		mainPage.verifyPanelSectionData(data,sectionData);
	}	

	@Then("Click on {string} labels link and verify the display of page")
	public void click_on_labels_link_and_verify_the_display_of_page(String page) {
		mainPage.verifyPageNavigation(page);
	}
	@Then("Verify the Last Updated column")
	public void verify_the_Last_Updated_column() {
		mainPage.verifyLastUpdatedDetails();
	}
	@Then("Verify the column header names")
	public void verify_the_column_header_names(DataTable transaction) {
		mainPage.verifyColumnHeaders(transaction);
	}	

	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the AutoRunFlag of {string}")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_AutoRunFlag_of(String dataBase, String containerName, String toggle) {
		String id="b18c3f89-fbff-4ed5-8cea-1f3e8054e8e9";
		mainPage.verifyAutoRunFlag(dataBase, containerName,id,toggle);

	}


}
