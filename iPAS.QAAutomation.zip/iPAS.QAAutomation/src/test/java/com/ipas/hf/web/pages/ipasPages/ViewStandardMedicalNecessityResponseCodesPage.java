package com.ipas.hf.web.pages.ipasPages;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class ViewStandardMedicalNecessityResponseCodesPage extends BasePage {

	@FindBy(xpath="//span[(text()='Medical Necessity Check')]")
	private WebElement lbl_MedicalNecessityCheckPanel;

	@FindBy(linkText="Medical Necessity Response Configuration")
	private WebElement lnk_MedicalNecessityResponseConfiguration;

	@FindBy(xpath="//span[@class='breadcrum-active']")
	private WebElement lbl_Breadcrum;

	@FindBy(xpath="//span[(text()='Medical Necessity Check')]/../../..")
	private WebElement atr_MedicalNecessityCheck;

	@FindBy(xpath="//a[(text()='Medical Necessity Response Configuration')]/../../div[2]")
	private WebElement lbl_MedicalNecessityCheckPanelHelpText;

	@FindBy(xpath="//div[@class='breadcrum-container noprint']/span")
	private List<WebElement> lbl_Breadcrum_All;

	@FindBy(xpath="//div[@class='search-bar']//child::label")
	private List<WebElement> lbl_FieldNames;

	@FindBy(xpath="//div[@class='search-result']//child::th//div//span")
	private List<WebElement> lbl_HeaderNames;

	@FindBy(xpath="//ejs-dropdownlist[contains(@id,'ej2_dropdownlist')]/span/input")
	private WebElement option_ResponseType;

	@FindBy(xpath="//div[@class='e-gridcontent']/div/table/tbody/tr")
	private List<WebElement> tr_Results;

	String activeSwitch ="//div[@class='e-gridcontent']/div/table/tbody/tr[";
	String activeSwitch1 ="]/td[7]/ejs-switch";
	
	@FindBy(xpath="//table[@class='e-table']/tbody/tr[1]/td[2]/div/a")
	private WebElement lnk_Code_Edit_ID;
	
	@FindBy(xpath="//div[@class='modal-header']/h4/span")
	private WebElement lbl_ModelHeader;
	
	@FindBy(xpath="//div[@class='modal-header']/../div[2]/div/label")
	private WebElement lbl_ResponseStatus;
	
	@FindBy(xpath="//div[@class='modal-header']/../div[3]/div/ipas-button")
	private List<WebElement> lbl_Buttons;

	@FindBy(xpath="//a[contains(text(),'Cancel')]")
	private WebElement btn_Cancel;
	
	@FindBy(xpath="//a[contains(text(),'Save')]")
	private WebElement btn_Save;
	
	@FindBy(xpath="//ejs-dropdownlist[@id='ddlelement']/span/span[2]")
	private WebElement dd_ResponseStatus;
	
	String responseStatus ="//table[@class='e-table']/tbody/tr[";
	
	String responseStatus1 ="]/td[1]/div/financial-clearance-status/img";
	
	String codeEditID ="]/td[2]/div/a";
	
	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;
	
	public ViewStandardMedicalNecessityResponseCodesPage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyMedicalNecessityCheckPanelAndHelpText(DataTable testData){
		ArrayList<String> expData = new ArrayList<String>(testData.asList());
		StringBuilder unmatch=new StringBuilder();
		ArrayList<String>actData=new ArrayList<String>();
		try {
			webActions.refreshPage();webActions.waitForPageLoaded();
			actData.add(webActions.waitAndGetText(lbl_MedicalNecessityCheckPanel, "Medical Necessity Check Panel"));
			actData.add(webActions.waitAndGetText(lnk_MedicalNecessityResponseConfiguration, "Medical Necessity Response Configuration"));
			actData.add(webActions.waitAndGetText(lbl_MedicalNecessityCheckPanelHelpText, "Medical Necessity Check Panel Help Text"));
			actData.add(webActions.waitAndGetText(lbl_Breadcrum, "Breadcrum"));

			report.reportInfo("Displayed Lable Names in Medical Necessity Check panel: "+actData);
			report.reportInfo("Expected Lable Names in Medical Necessity Check panel: "+expData);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Label Names in Medical Necessity Check panel successfully");
			}
			else{
				report.reportFail("Fail to verify Label Names in Medical Necessity Check panel", true);
				unmatch.append("Fail to verify Label Names in Medical Necessity Check panel");
			}


			webActions.click(lbl_MedicalNecessityCheckPanel, "Medical Necessity Check Panel");
			webActions.waitForPageLoaded();
			String actCollapse=webActions.getAttributeValue(atr_MedicalNecessityCheck, "aria-expanded", "Medical Necessity Check Panel");
			if("false".contentEquals(actCollapse)){
				report.reportPass("Successfully Collapsed the Medical Necessity Check Panel");
			}else{
				report.reportFail("Failed to Collapse the Medical Necessity Check Panel", true);
				unmatch.append("Failed to Collapse the Medical Necessity Check Panel");
			}

			webActions.click(lbl_MedicalNecessityCheckPanel, "Medical Necessity Check Panel");
			webActions.waitForPageLoaded();
			String actExpand=webActions.getAttributeValue(atr_MedicalNecessityCheck, "aria-expanded", "Medical Necessity Check Panel");
			if("true".contentEquals(actExpand)){
				report.reportPass("Successfully Expanded the Medical Necessity Check Panel");
			}else{
				report.reportFail("Failed to Expand the Medical Necessity Check Panel", true);
				unmatch.append("Failed to Expand the Medical Necessity Check Panel");
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyDefaultResponseTypeValueAndFieldNames(DataTable fieldNames,String responseType){
		try {
			StringBuilder unmatch=new StringBuilder();
			ArrayList<String>expFieldNames=new ArrayList<String>(fieldNames.asList());
			ArrayList<String> actFieldNames=webActions.getDatafromWebTable(lbl_FieldNames);
			report.reportInfo("Actual Field Names in Medical Necessity Response page: "+actFieldNames);
			report.reportInfo("Expected Field Names in Medical Necessity Response page: "+expFieldNames);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actFieldNames, expFieldNames);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Field Names in Medical Necessity Response page");
			}
			else{
				report.reportFail("Fail to verify Field Names in Medical Necessity Response page", true);
				unmatch.append("Fail to verify Field Names in Medical Necessity Response page");
			}
			webActions.waitForPageLoaded();
			String actResponseType=webActions.getValue(option_ResponseType, "ResponseType");
			report.reportInfo("Actual Response Type: "+actResponseType);
			report.reportInfo("Expected Response Type: "+responseType);
			if(responseType.contentEquals(actResponseType)){
				report.reportPass("Verified default Response Type");
			}
			else{
				report.reportFail("Fail to verify default Response Type ", true);
				unmatch.append("Fail to verify default Response Type: "+actResponseType);
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyBreadcrumb(DataTable breadcrumb){
		try {
			ArrayList<String>expBreadcrumb=new ArrayList<String>(breadcrumb.asList());
			ArrayList<String> actBreadcrumb=webActions.getDatafromWebTable(lbl_Breadcrum_All);
			report.reportInfo("Actual Breadcrumb: "+actBreadcrumb);
			report.reportInfo("Expected Breadcrumb: "+expBreadcrumb);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actBreadcrumb, expBreadcrumb);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Breadcrumb in Medical Necessity Response page");
			}
			else{
				report.reportFail("Fail to verify Breadcrumb in Medical Necessity Response page");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void navigateMedicalNecessityResponsePage(){
		try {
			webActions.refreshPage();webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_MedicalNecessityResponseConfiguration, "Medical Necessity Response Configuration");
			webActions.waitForVisibilityOfAllElements(lbl_HeaderNames, "Header Names");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
		}
	}

	public void verifyGridHeaderNamesForStandardResponseType(DataTable headerNames){
		try {
			ArrayList<String> expHeaderNames=new ArrayList<>(headerNames.asList());
			ArrayList<String> actHeaderNames=webActions.getDatafromWebTable(lbl_HeaderNames);
			report.reportInfo("Actual Header Names: "+actHeaderNames);
			report.reportInfo("Expected Header Names: "+expHeaderNames);
			ArrayList<String>unmatcHeaderNames=webActions.getUmatchedInArrayComparision(actHeaderNames, expHeaderNames);
			if(unmatcHeaderNames.size()==0){
				report.reportPass("Verified Result Grid Header Names for Standard Response Type");
			}
			else{
				report.reportFail("Fail to verify Result Grid Header Names for Standard Response Type"+unmatcHeaderNames);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void enableResponseCode(String responseCodeStatus ){
		try {
			int totalRows=tr_Results.size();
			if ("Disable".contentEquals(responseCodeStatus)) {
				for (int i = 1; i <= totalRows; i++) {
					String activeStatus = driver.findElement(By.xpath(activeSwitch+i+activeSwitch1))
							.getAttribute("aria-checked");
					if ("true".contentEquals(activeStatus)) {
						driver.findElement(By.xpath(activeSwitch+i+activeSwitch1)).click();
						String activeStatusAfterChange = driver.findElement(By.xpath(activeSwitch+i+activeSwitch1))
								.getAttribute("aria-checked");
						if ("false".contentEquals(activeStatusAfterChange)) {
							report.reportPass("Verified Result Grid Header Names for Standard Response Type");
						} else {
							report.reportFail("Fail to verify Breadcrumb in Medical Necessity Response page");
						}
						break;
					}
				} 
			}else if("Enable".contentEquals(responseCodeStatus)){
				for (int i = 1; i <= totalRows; i++) {
					String rowStatus=driver.findElement(By.xpath(activeSwitch+i+activeSwitch1)).getAttribute("aria-checked");
					if("false".contentEquals(rowStatus)){
						driver.findElement(By.xpath(activeSwitch+i+activeSwitch1)).click();
						String rowStatusAfterChange=driver.findElement(By.xpath(activeSwitch+i+activeSwitch1)).getAttribute("aria-checked");
						if("true".contentEquals(rowStatusAfterChange)){
							report.reportPass("Verified Result Grid Header Names for Standard Response Type");
						}else{
							report.reportFail("Fail to verify Breadcrumb in Medical Necessity Response page");
						}
						break;
					}
				}
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void verifyFieldNamesinResponseStatusodelWindow(DataTable names){
		try {
			ArrayList<String> expNames=new ArrayList<>(names.asList());
			String codeEditId=webActions.waitAndGetText(lnk_Code_Edit_ID, "CodeEditID");
			webActions.click(lnk_Code_Edit_ID, "CodeEditID");
			webActions.waitForPageLoaded();
			ArrayList<String> actNames=new ArrayList<>();
			actNames.add(codeEditId+" - "+webActions.waitAndGetText(lbl_ModelHeader, "Model Header Name"));
			actNames.add(webActions.getText(lbl_ResponseStatus, "ResponseStatus"));
			actNames.addAll(webActions.getDatafromWebTable(lbl_Buttons));
			
			report.reportInfo("Displayed Lable Names in Response Status model window: "+actNames);
			report.reportInfo("Expected Lable Names in Response Status model window: "+expNames);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actNames, expNames);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Label Names in Response Status model window successfully");
			}
			else{
				report.reportFail("Fail to verify Label Names in Response Status model window: "+unmatchedLabelNames, true);
			}
			webActions.click(btn_Cancel, "Cancel");
			report.reportPass("Response Status model window successfully closed by click on Cancel button");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void changeResponseStatus(String changeStatus,String message){
		try {
			int totalRows=tr_Results.size();
			String actCodeEditID=null;
			String expStatus=getResponseStatus(changeStatus);
			StringBuilder unmatch=new StringBuilder();
			for (int i = 1; i <= totalRows; i++) {
				String activeStatus = driver.findElement(By.xpath(responseStatus+i+responseStatus1)).getAttribute("src");
				if(!activeStatus.contains(expStatus)){
					actCodeEditID=driver.findElement(By.xpath(responseStatus+i+codeEditID)).getText();
					driver.findElement(By.xpath(responseStatus+i+codeEditID)).click();
					selectResponseStatusDropDown(changeStatus);
					webActions.waitForVisibility(txt_ToastMsgs, "Messages");
					String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
					String[] titleContent=msg.split("\\n");
					String actTitle = titleContent[0];
					String actContent = titleContent[1];
					report.reportInfo("Actual alert message: "+actContent);
					report.reportInfo("Expected alert message: "+message);
					webActions.waitForJSandJQueryToLoad();
					webActions.waitForPageLoaded();
					if(message.contains(actContent)){
						report.reportPass("Successfully changed the status");
					}else{
						report.reportFail("Failed to changed the status: "+actContent,true);
						unmatch.append("Failed to changed the status: "+actContent);
					}
					break;
				}
			}
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
			for (int i = 1; i <= totalRows; i++) {
				String actCodeEditIDAfterChange=driver.findElement(By.xpath(responseStatus+i+codeEditID)).getText();
				if(actCodeEditIDAfterChange.contentEquals(actCodeEditID)){
					String activeStatus = driver.findElement(By.xpath(responseStatus+i+responseStatus1)).getAttribute("src");
					if(activeStatus.contains(expStatus)){
						report.reportPass("Successfully verified the status after update the status: "+changeStatus);
					}
					else{
						report.reportFail("Failed to verify the status after update the status: "+activeStatus);
						unmatch.append("Failed to verify the status after update the status: "+activeStatus);
					}
					break;
				}
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public String getResponseStatus(String status){
		switch (status) {
		case "Clear":
			status="success";
			break;
		case "Review":
			status="alert";
			break;
		case "Needs Attention":
			status="error";
			break;
		}
		return status;
	}
	
	public void selectResponseStatusDropDown(String responseStatus){
		try {
			int row = 0;
			switch (responseStatus) {
			case "Clear":
				row=1;
				break;
			case "Review":
				row=2;
				break;
			case "Needs Attention":
				row=3;
				break;
			}
			webActions.click(dd_ResponseStatus, "Response Status");
			webActions.waitForPageLoaded();
			driver.findElement(By.xpath("//ul[@id='ddlelement_options']/li["+row+"]")).click();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
			webActions.click(btn_Save, "Save");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(lnk_MedicalNecessityResponseConfiguration);
	}

}
