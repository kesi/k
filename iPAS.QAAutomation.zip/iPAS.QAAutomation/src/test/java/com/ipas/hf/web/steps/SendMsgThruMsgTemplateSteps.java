package com.ipas.hf.web.steps;

import java.util.Properties;

import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.utilities.ConfigProperties;
import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.SendMsgThruMsgTemplatePage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SendMsgThruMsgTemplateSteps {
	SendMsgThruMsgTemplatePage msgTemplate = new SendMsgThruMsgTemplatePage();
	
	@Then("Verify Template Message Drop Down in Message Hub opened on Visit Card")
	public void verify_Template_Message_Drop_Down_in_Message_Hub_opened_on_Visit_Card() throws Exception {
		msgTemplate.verifyMessageTemplateDropDownOnVisitCard();
	}
	
	@Then("Verify Message Box is displayed in Message Window on Visit Card")
	public void verify_Message_Box_is_displayed_in_Message_Window_on_Visit_Card() throws Exception {
		msgTemplate.verifyMessageBoxOnVisitCard();
	}
	
	@Then("Verify help text in Message Window through Visit Card as {string}")
	public void verify_help_text_in_Message_Window_through_Visit_Card_as(String expText) throws Exception {
		msgTemplate.verifyHelpTextOnMessageWindow(expText);
	}
	
	@Then("Verify help text of Drop Down as {string}")
	public void verify_help_text_of_Drop_Down_as(String expDrpDwnText) throws Exception {
		msgTemplate.verifyDropDownTemplateMsg(expDrpDwnText);
	}
	
	@Then("Verify user can enter text in Message Text box as {string}")
	public void verify_user_can_enter_text_in_Message_Text_box_as(String actValue) throws Exception {
		msgTemplate.enterTextinMessageBox(actValue);
	}
	
	@Then("Verify Send button in disabled mode in Message Hub before entering Text in MsgText Box")
	public void verify_Send_button_in_disabled_mode_in_Message_Hub_before_entering_Text_in_MsgText_Box() throws Exception {
		msgTemplate.verifySendButtonModeIsDisabled();
	}
	
	@Then("Verify Send button in enabled mode in Message Hub after entering Text in MsgText Box")
	public void verify_Send_button_in_enabled_mode_in_Message_Hub_after_entering_Text_in_MsgText_Box() throws Exception {
		msgTemplate.verifySendButtonModeIsEnabled();
	}
	
	@Then("Select value from Message Template DropDown as {string}")
	public void select_value_from_Message_Template_DropDown_as(String tempValue) throws Exception {
		msgTemplate.selectMsgTemplate(tempValue);
	}
	
	@Then("Verify display of maximum chars allowed Message in Message window as {string}")
	public void verify_display_of_maximum_chars_allowed_Message_in_Message_window_as(String expMaxValue) throws Exception {
		msgTemplate.verifyMaxLengthMsg(expMaxValue);
	}

	@Then("Verify maximum length allowed message in Message Hub as {string}")
	public void verify_maximum_length_allowed_message_in_Message_Hub_as(String expMaxLengthValue) throws Exception {
		msgTemplate.verifyMaxLengthAllowedMsg(expMaxLengthValue);
	}
	
	@Then("Verify user can edit the selected message as {string} and {string}")
	public void verify_user_can_edit_the_selected_message_as_and(String tempValue, String expTextValue) throws Exception {
		msgTemplate.verifyUserCanEditMsg(tempValue,expTextValue);
	}
	
	@Then("Verify user can enter text in Message Box opened from Visit Card as {string}")
	public void verify_user_can_enter_text_in_Message_Box_opened_from_Visit_Card_as(String actValue) throws Exception {
		msgTemplate.enterTextinMessageBoxOpenedOnVisitCard(actValue);
	}

	@Then("Select message from Message Template opened from Visit Card as {string}")
	public void select_message_from_Message_Template_opened_from_Visit_Card_as(String tempValue) throws Exception {
		msgTemplate.selectMsgTemplateOpenedOnVisitCard(tempValue);
	}


}
