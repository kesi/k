package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.AddNewRulePage;
import com.ipas.hf.web.pages.ipasPages.ErrorCategoriesAndChallengePage;
import com.ipas.hf.web.pages.ipasPages.ViewStandardMedicalNecessityResponseCodesPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class ErrorCategoriesAndChallengeSteps {

	ErrorCategoriesAndChallengePage errorCatChal=new  ErrorCategoriesAndChallengePage();
	
	@Then("Navigate to Error Categories and Challenge Configuration page")
	public void navigate_to_Error_Categories_and_Challenge_Configuration_page() {
		errorCatChal.clickCategoriesChallengeConfiguration();
	}

	@Then("Verify Breadcrumb in Error Categories and Challenge Configuration page")
	public void verify_Breadcrumb_in_Error_Categories_and_Challenge_Configuration_page(DataTable testData) {
		errorCatChal.verifyBreadcrumb(testData);
	}
	
	@Then("Verify the tab names in Error Categories and Challenge Configuration page")
	public void verify_the_tab_names_in_Error_Categories_and_Challenge_Configuration_page(DataTable testData) {
	  errorCatChal.verifyErrorCategoriesAndChallengeConfigurationTabs(testData);
	}
	
	@Then("Verify mandatory field validation error message in Error Categories tab")
	public void verify_mandatory_field_validation_error_message_in_Error_Categories_tab(DataTable testData) {
		errorCatChal.VerifyMandatoryValidationMessage(testData);
	}
	
	@Then("Verify the creation of Error Category")
	public void verify_the_creation_of_Error_Category(DataTable testData) {
		errorCatChal.createErrorCategory(testData);
	}
	
	@Then("Verify the Edit and Delete functionality")
	public void verify_the_Edit_and_Delete_functionality(DataTable testData) {
		
	}
	
	@Then("Verify the Edit functionality")
	public void verify_the_Edit_functionality(DataTable testData) {
		errorCatChal.editErrorCategory(testData);
	}

	@Then("Verify the Delete functionality {string}")
	public void verify_the_Delete_functionality(String message) {
		errorCatChal.deleteErrorCategory(message);
	}

	@Then("Verify mandatory field validation error message in Challenge Reasons tab {string}")
	public void verify_mandatory_field_validation_error_message_in_Challenge_Reasons_tab(String expMessage) {
		errorCatChal.verifyMandatoryValidationMessageChallengeReason(expMessage);
	}
	
	@Then("Verify the add new Challenge Reasons {string}")
	public void verify_the_add_new_Challenge_Reasons(String challengeReason) {
		errorCatChal.addNewChallengeReason(challengeReason);
	}
	
	@Then("Verify the update Challenge Reasons {string}")
	public void verify_the_update_Challenge_Reasons(String challengeReason) {
		errorCatChal.editChallengeReason(challengeReason);
	}

	@Then("Verify the delete Challenge Reason functionality {string}")
	public void verify_the_delete_Challenge_Reason_functionality(String expMessage) {
		errorCatChal.deleteChallengeReason(expMessage);
	}
	
	@Then("Verify mandatory field validation error message in Challenge Response tab {string}")
	public void verify_mandatory_field_validation_error_message_in_Challenge_Response_tab(String expMessage) {
		errorCatChal.verifyMandatoryValidationMessageChallengeResponse(expMessage);
	}
	
	@Then("Verify the add new Challenge Response {string}")
	public void verify_the_add_new_Challenge_Response(String challengeResponse) {
		errorCatChal.addNewChallengeResponse(challengeResponse);
	}

	@Then("Verify the update Challenge Response {string}")
	public void verify_the_update_Challenge_Response(String challengeResponse) {
		errorCatChal.editChallengeResponse(challengeResponse);
	}

	@Then("Verify the delete Challenge Response functionality {string}")
	public void verify_the_delete_Challenge_Response_functionality(String expMessage) {
		errorCatChal.deleteChallengeResponse(expMessage);
	}

	
}
