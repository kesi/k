package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.ServiceTrackerPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class ServiceTrackerSteps {

	Login logIn = new Login();
	HomePage home = new HomePage();
	ServiceTrackerPage srvTracker = new ServiceTrackerPage();

	@Then("Navigate to ServiceTracker Page: Page Title as {string}")
	public void navigate_to_ServiceTracker_Page_Page_Title_as(String pageTitle) throws Exception {
		srvTracker.navigatetoServiceTrackerPage(pageTitle);
	}

	@Then("Verify the fields and button: Page Tile as {string}, Search Text Box, Faciltiy, Lobby, Service Deparmtnet drop downs and Apply, Columns Button")
	public void verify_the_fields_and_button_Page_Tile_as_Search_Text_Box_Faciltiy_Lobby_Service_Deparmtnet_drop_downs_and_Apply_Columns_Button(String pageTitle) throws Exception{
		srvTracker.verifyFieldsDisplay(pageTitle);

	}

	@Then("Verify the display of Default Feilds")
	public void verify_the_display_of_Default_Feilds(DataTable testData) {
		srvTracker.verifyDefaultValues(testData);
	}

	@Then("Verify the Default Grid  Status Columns")
	public void verify_the_Default_Grid_Status_Columns(DataTable defaultStatus) {
		srvTracker.defaultGridStatusColumns(defaultStatus);
	}

	@Then("Verify Total Status names under Columns list")
	public void total_Status_names_under_Columns_list(DataTable totalStatus ) throws Exception {
		srvTracker.totalColumnStatus(totalStatus);
	}

	@Then("Verify selected Status is displayed as Column Name: Status Name as {string}")
	public void verify_selected_Status_is_displayed_as_Column_Name_Status_Name_as(String statusName) throws Exception {
		srvTracker.verifySelectedColumnInGrid(statusName);
	}

	@Then("Verify and compare default Status names from columns list and grid")
	public void verify_and_compare_default_Status_names_from_columns_list_and_grid() {
		srvTracker.compareDefaultStatusInGridAndColumnsList();
	}

	@Then("Verify selected all status displayed on the Service Tracker Board")
	public void verify_selected_all_status_displayed_on_the_Service_Tracker_Board(DataTable columnsListToSelect) throws Exception {
		srvTracker.verifyAllSelectedColumnInGrid(columnsListToSelect);
	}

	@Then("Verify unchecked status is not displayed on the Service Tracker Board")
	public void verify_unchecked_status_is_not_displayed_on_the_Service_Tracker_Board(DataTable statusToUnselect) {
		srvTracker.unselectedAndVerifyStatusInGrid(statusToUnselect);
	}

	@Then("Verify Status names with Initial Capital Letters")
	public void verify_Status_names_with_Initial_Capital_Letters() {
		srvTracker.verifyStatusNamesWithInitCap();
	}

	@Then("Verify Date of Service in Service Tracker Page")
	public void verify_Date_of_Service_in_Service_Tracker_Page() throws Exception {
		srvTracker.compareDateOfService();
	}

}
