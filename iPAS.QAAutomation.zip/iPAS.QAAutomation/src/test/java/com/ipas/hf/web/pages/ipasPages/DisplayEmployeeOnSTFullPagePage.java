package com.ipas.hf.web.pages.ipasPages;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.time.DateUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class DisplayEmployeeOnSTFullPagePage extends BasePage {

	@FindBy(xpath = "//input[@id='username']")
	private WebElement txt_UserName;

	@FindBy(xpath = "//div[@class='e-gridcontent']//tbody/tr[2]/td")
	private List<WebElement> lst_StatusHistoryElements;

	@FindBy(xpath = "//div[@class='e-gridcontent']//tbody/tr[2]/td[1]")
	private WebElement txt_StatuName;

	@FindBy(xpath = "//div[@class='e-gridcontent']//tbody/tr[2]/td[2]/div/p")
	private WebElement txt_EmployeeName;

	@FindBy(xpath = "//div[@class='e-gridcontent']//tbody/tr[2]/td[3]")
	private WebElement txt_StratDate;

	@FindBy(xpath = "//div[@class='e-gridcontent']//tbody/tr[2]/td[2]/div[1]/span")
	private WebElement txt_Manual;

	public DisplayEmployeeOnSTFullPagePage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyDataOnSTFullPageStatusHistory(DataTable options) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitUntilListisDisplayed(lst_StatusHistoryElements, "HistoryData");
			report.reportInfo("History Data is displayed successfully");

			ArrayList<String> expectedHistoryData = new ArrayList<>(options.asList());

			report.reportInfo("Expected History Data is : "+expectedHistoryData);

			ArrayList<String> actualHistoryData = new ArrayList<String>();
			actualHistoryData.add(webActions.waitAndGetText(txt_StatuName, "StatusName"));
			actualHistoryData.add(webActions.waitAndGetText(txt_EmployeeName, "EmployeeName").trim());

			report.reportInfo("Actual History Data is : "+actualHistoryData);

			ArrayList<String>unmatchedOptionNames=webActions.getUmatchedInArrayComparision(actualHistoryData, expectedHistoryData);
			if(unmatchedOptionNames.size()==0){
				report.reportPass("Verified History Data is displayed successfully");
			}
			else{
				throw new Exception("Fail to verify History Data and unmatched Data is : "+unmatchedOptionNames);
			}

		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public String getCurrentSystemDateTime() throws Exception{
		String dateTime = null;
		try{
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm a");
			LocalDateTime now = LocalDateTime.now();
			dateTime = dtf.format(now);
			report.reportInfo("Current Date and Time is :"+dtf.format(now));
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
		return dateTime;
	}

	public String getIncreasedCurrentSystemDateTime() throws Exception{
		String increasedCurrentDate = null;
		try{
			Date date = new Date();
			new SimpleDateFormat("yyyy-MM-dd");
			date = DateUtils.addMinutes(date, 1);
			increasedCurrentDate = new SimpleDateFormat("MM/dd/yyyy hh:mm a").format(date);
			report.reportInfo("increased currentDate: "+increasedCurrentDate);

		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
		return increasedCurrentDate;
	}

	public void verifyCurrentDate() throws Exception{
		String actCurrentDate = null; String expCurrentDate = null; String increasedExpCurrentDate = null;
		try{
			webActions.waitForPageLoaded();

			actCurrentDate = webActions.waitAndGetText(txt_StratDate, "StartDate");			
			report.reportInfo("Status changed Date and Time from Application is : "+actCurrentDate);

			expCurrentDate = getCurrentSystemDateTime();
			increasedExpCurrentDate = getIncreasedCurrentSystemDateTime();

			if(actCurrentDate.contentEquals(expCurrentDate)||actCurrentDate.contentEquals(increasedExpCurrentDate)){
				report.reportPass("Notes created Date and Time dispalyed properly");
			}else{
				throw new Exception("Failed to read Notes created Date and Time");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}


	public void verifyManualText() throws Exception{
		String actualText = null;
		try{
			webActions.waitForPageLoaded();
			actualText = webActions.waitAndGetText(txt_Manual, "ManualTest");
			report.reportInfo("Moved By column text is :"+actualText);
			if(actualText.contentEquals("Manual")){
				report.reportPass("Manual Text is displayed successfully");
			}else{
				throw new Exception("Failed to read Manual Text on Status History Page");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}


	public DisplayEmployeeOnSTFullPagePage openIpasApp() {
		try {
			String URL = TestBase.prop.ipasURL();
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to Open iPAS application");
		}
		return (DisplayEmployeeOnSTFullPagePage) base(DisplayEmployeeOnSTFullPagePage.class);
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_UserName);
	}

}
