package com.ipas.hf.web.steps;

import java.util.Properties;

import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.utilities.ConfigProperties;
import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.SpecialAssistancePage;
import com.ipas.hf.web.pages.ipasPages.UpdateVisitPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SpecialAssistanceSteps {
	private ConfigProperties configProp = TestBase.prop;
	SpecialAssistancePage SPAPage = new SpecialAssistancePage();
	UpdateVisitPage updateVisit = new UpdateVisitPage();

	@Then("Navigate to Special Assistance Tab")
	public void navigate_to_Special_Assistance_Tab() throws Exception {
		SPAPage.navigateToSpecialAssistance();
	}

	@Then("Verify Submit and Cancel buttons")
	public void verify_Submit_and_Cancel_buttons() throws Exception {
		SPAPage.verifyCancel();
		SPAPage.verifySubmit();
	}

	@Then("Click on WheelChair to {string}")
	public void click_on_WheelChair_to(String selectMode) throws Exception {
		SPAPage.selectWheelChair(selectMode);
	}

	@Then("Verify on WheelChair")
	public void click_on_WheelChair() throws Exception {
		SPAPage.verifyWheelChair();
	}

	@Then("Click Submit button and close the Model Window")
	public void Click_on_Submit_button_and_close_the_Model_Window() throws Exception {
		SPAPage.clickSASubmit();
		updateVisit.closeModelWindow();
	}

	@Then("Verify WheelChair Icon on Visit Card")
	public void verify_WheelChair_Icon_on_Visit_Card() throws Exception {
		SPAPage.wheelChairDisplayed();
	}

	@Then("Verify No WheelChair Icon on Visit Card")
	public void verify_No_WheelChair_Icon_on_Visit_Card() throws Exception {
		SPAPage.wheelChairNotDisplayed();
	}


	@Then("Click Submit button")
	public void Click_Submit_button() throws Exception {
		SPAPage.clickSASubmit();
	}
	@Then("Click on Cancel Button")
	public void click_on_Cancel_Button() throws Exception {
		SPAPage.clickCancel();
	}

	@Then("Close Model Window")
	public void close_Model_Window() throws Exception {
		updateVisit.closeModelWindow();
	}

	@Then("Enter Data in Location Text Box as {string}")
	public void enter_Data_in_Location_Text_Box_as(String data) throws Exception {
		SPAPage.enterLocation(data);
	}

	@Then("Verify Location TextBox Enabled")
	public void verify_Location_TextBox_Enabled() throws Exception {
		SPAPage.verifyLocationEnabled();
	}

	@Then("Verify Location TextBox Disabled")
	public void verify_Location_TextBox_Disabled() throws Exception {
		SPAPage.verifyLocationDisabled();
	}


}
