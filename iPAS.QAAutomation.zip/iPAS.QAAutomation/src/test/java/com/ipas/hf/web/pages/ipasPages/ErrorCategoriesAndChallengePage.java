package com.ipas.hf.web.pages.ipasPages;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class ErrorCategoriesAndChallengePage extends BasePage {

	@FindBy(linkText="Error Categories & Challenge Configuration")
	private WebElement lnk_ErrorCategorieChallengeConfiguration;

	@FindBy(xpath="//span[@class='breadcrum-active']")
	private WebElement lbl_Breadcrum;

	@FindBy(xpath="//ejs-dropdownlist[@id='facilityLookup']/span/input")
	private WebElement dd_Facility;
	
	@FindBy(xpath="//ejs-dropdownlist[@id='facilityLookup']")
	private WebElement dd_Facility1;

	@FindBy(xpath="//div[@class='breadcrum-container noprint']/span")
	private List<WebElement> lbl_Breadcrum_All;

	@FindBy(xpath="//div[@aria-label='tab-header']/div/div/div")
	private List<WebElement> lbl_FieldNames;

	@FindBy(xpath="//div[@class='table-wrapper']/section[1]/div[1]/span")
	private WebElement lbl_Active;
	
	@FindBy(xpath="//div[@role='presentation']/div")
	private List<WebElement> tab_Names;
	
	@FindBy(xpath="(//table[@role='grid'])[2]/tbody/tr/td")
	private List<WebElement> tr_Rows;
	
	@FindBy(xpath="//a[contains(text(),'Add New Error Category')]")
	private WebElement btn_AddNewErrorCategory;
	
	@FindBy(xpath="//*[@class='error']")
	private List<WebElement> lbl_ErrorMessages;
	
	@FindBy(css="input.form-control.ng-untouched.ng-pristine.ng-invalid")
	private WebElement txt_ErrorCategory;
	
	@FindBy(xpath="//input[@class='form-control valueContainer ng-untouched ng-pristine ng-valid e-control e-numerictextbox e-lib e-input']")
	private WebElement txt_ErrorWeight;
	
	@FindBy(xpath="//span[@class='e-input-group e-control-wrapper e-ddl e-lib e-keyboard']")
	private WebElement dd_ModuleStatus;
	
	@FindBy(xpath="//button[contains(text(),'Save')]")
	private WebElement btn_Save;
	
	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;
	
	@FindBy(xpath="//tbody/tr[3]/td[1]/input[1]")
	private WebElement txt_ErrorCategory_Edit;
	
	@FindBy(xpath="//tbody/tr[3]/td[4]/ejs-dropdownlist[1]/span")
	private WebElement dd_ModuleStatus_Edit;
	
	@FindBy(xpath="//img[@class='pointer']")
	private WebElement btn_Delete;
	
	@FindBy(xpath="//div[contains(text(),'CHALLENGE REASONS')]")
	private WebElement lnk_ChallengeReasons;
	
	@FindBy(xpath="//a[contains(text(),'Add New Reason')]")
	private WebElement btn_AddNewReason;
	
	@FindBy(xpath="//span[@class='error']")
	private WebElement lbl_Error_ChallengeReasons;
	
	@FindBy(xpath="//tbody/tr[4]/td[1]/input[1]")
	private WebElement txt_ChallengeReasons;
	
	@FindBy(xpath="//div[@hideauthorize='AddEditChallengeReasonConfig']//button[contains(text(),'Save')]")
	private WebElement btn_Save_ChallengeReasons;
	
	/*@FindBy(xpath="//tbody/tr[4]/td[1]/input[1]")
	private WebElement txt_ChallengeReasons_Edit;*/
	
	@FindBy(xpath="//tbody/tr[4]/td[2]/img[1]")
	private WebElement btn_Delete_ChallengeReasons;
	
	@FindBy(xpath="//div[contains(text(),'CHALLENGE RESPONSE')]")
	private WebElement lnk_ChallengeResponse;
	
	@FindBy(xpath="//a[contains(text(),'Add New Response')]")
	private WebElement btn_AddNewResponse;
	
	@FindBy(xpath="//tbody/tr[5]/td[1]/input[1]")
	private WebElement txt_ChallengeResponses;
	
	@FindBy(xpath="//div[@hideauthorize='AddEditChallengeResponseConfig']//button[contains(text(),'Save')]")
	private WebElement btn_Save_ChallengeResponse;
	
	@FindBy(xpath="//tbody/tr[5]/td[2]/img")
	private WebElement btn_Delete_ChallengeResponses;
	
	@FindBy(xpath="//a[contains(text(),'Maintenance')]")
	private WebElement lnk_Maintenance;
	

	public ErrorCategoriesAndChallengePage() {
		PageFactory.initElements(driver, this);
	}

	public void clickCategoriesChallengeConfiguration(){
		webActions.click(lnk_ErrorCategorieChallengeConfiguration, "ErrorCategorieChallengeConfiguration");
		//webActions.waitForVisibilityOfAllElements(lbl_FieldNames, "Field Names");
		try {
			webActions.waitForVisibilityOfAllElements(tr_Rows, "Rows");
		} catch (Exception e) {
		}
	}

	public void verifyBreadcrumb(DataTable breadcrumb){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lnk_Maintenance, "Maintenance");
			webActions.waitForPageLoaded();
			webActions.refreshPage();
			try {
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(lnk_ErrorCategorieChallengeConfiguration, "ErrorCategorieChallengeConfiguration", 15);
			} catch (Exception e) {
				webActions.waitForPageLoaded();
			}
			webActions.waitAndClick(lnk_ErrorCategorieChallengeConfiguration, "ErrorCategorieChallengeConfiguration");
			//clickCategoriesChallengeConfiguration();
			webActions.waitForPageLoaded();
			ArrayList<String>expBreadcrumb=new ArrayList<String>(breadcrumb.asList());
			ArrayList<String> actBreadcrumb=webActions.getDatafromWebTable(lbl_Breadcrum_All);
			report.reportInfo("Actual Breadcrumb: "+actBreadcrumb);
			report.reportInfo("Expected Breadcrumb: "+expBreadcrumb);
			ArrayList<String>unmatchedBreadcrumb=webActions.getUmatchedInArrayComparision(actBreadcrumb, expBreadcrumb);
			if(unmatchedBreadcrumb.size()==0){
				report.reportPass("Verified Breadcrumb in Error Categories And Challenge page");
			}
			else{
				report.reportFail("Fail to verify Breadcrumb in Error Categories And Challenge page: "+unmatchedBreadcrumb);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyErrorCategoriesAndChallengeConfigurationTabs(DataTable testData){
		try {
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			ArrayList<String>actData=webActions.getDatafromWebTable(tab_Names);
			report.reportInfo("Expected tab names: "+expData);
			report.reportInfo("Actual tab names: "+actData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Error Categories and Challenge Configuration tabs");
			}else{
				report.reportFail("Failed to verify the Error Categories and Challenge Configuration tabs: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void VerifyMandatoryValidationMessage(DataTable testData){
		try {
			ArrayList<String>expData=new ArrayList<>(testData.asList());
			webActions.click(btn_AddNewErrorCategory, "Add New Error Category");
			webActions.click(btn_AddNewErrorCategory, "Add New Error Category");
			ArrayList<String> actData=webActions.getDatafromWebTable(lbl_ErrorMessages);
			report.reportInfo("Expected messages: "+expData);
			report.reportInfo("Actual messages: "+actData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified mandatory field validation error message in ERROR CATEGORIES tab");	
			}else{
				report.reportFail("Failed to verify mandatory field validation error message in ERROR CATEGORIES tab: "+unmatch);	
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void createErrorCategory(DataTable testData){
		try {
			try {
				webActions.waitForVisibility(txt_ErrorCategory, "ErrorCategory", 10);
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_AddNewErrorCategory, "Add New Error Category");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_ErrorCategory, getDatafromMap(testData,"Error Category"), "Error Category");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_ErrorWeight, getDatafromMap(testData,"Error Weight"), "Error Weight");
			webActions.waitForPageLoaded();
			selectDropdown(dd_ModuleStatus, getDatafromMap(testData,"Module Status"), "Module Status");
			webActions.waitForPageLoaded();
			webActions.click(btn_Save, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle = titleContent[0];
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			if(actContent.contains(getDatafromMap(testData,"Message"))){
				report.reportPass("Successfully created the Error Categories ");
			}else{
				report.reportFail("Failed to create the Error Categories");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void editErrorCategory(DataTable testData){
		try {
			try {
				webActions.waitForVisibility(txt_ErrorCategory_Edit, "ErrorCategory", 10);
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_ErrorCategory_Edit, "Error Category");
			webActions.sendKeys(txt_ErrorCategory_Edit, getDatafromMap(testData,"Error Category"), "Error Category");
			webActions.waitForPageLoaded();
			selectDropdown(dd_ModuleStatus_Edit, getDatafromMap(testData,"Module Status"), "Module Status");
			webActions.waitForPageLoaded();
			webActions.click(btn_Save, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			if(actContent.contains(getDatafromMap(testData,"Message"))){
				report.reportPass("Successfully updated the Error Categories ");
			}else{
				report.reportFail("Failed to update the Error Categories");
			}
			
			
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void deleteErrorCategory(String expMessage){
		try {
			try {
				webActions.waitForVisibility(btn_Delete, "Delete", 10);
			} catch (Exception e) {
			}
			webActions.waitAndClick(btn_Delete, "Delete");
			webActions.waitForPageLoaded();
			webActions.click(btn_Save, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			if(actContent.contains(expMessage)){
				report.reportPass("Successfully deleted the Error Categories ");
			}else{
				report.reportFail("Failed to delete the Error Categories");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void navigateChallengeReason() throws Exception{
		webActions.click(lnk_ChallengeReasons, "Challenge Reasons");
		webActions.waitForPageLoaded();
	}

	public void verifyMandatoryValidationMessageChallengeReason(String expMessage){
		try {
			navigateChallengeReason();
			try {
				webActions.waitForVisibility(txt_ChallengeReasons, "ChallengeReasons", 5);
			} catch (Exception e) {
			}
			webActions.click(btn_AddNewReason, "Add New Reason");
			webActions.click(btn_AddNewReason, "Add New Reason");
			String actMessage=webActions.waitAndGetText(lbl_Error_ChallengeReasons, "Error message");
			report.reportInfo("Expected messages: "+expMessage);
			report.reportInfo("Actual messages: "+actMessage);
			if(actMessage.contains(expMessage)){
				report.reportPass("Successfully verified mandatory field validation error message in Challenge Reason tab");	
			}else{
				report.reportFail("Failed to verify mandatory field validation error message in Challenge Reason tab: "+actMessage);	
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void addNewChallengeReason(String challengeReason){
		try {
			navigateChallengeReason();
			try {
				webActions.waitForVisibility(txt_ChallengeReasons, "ChallengeReasons", 8);
			} catch (Exception e) {
			}
			webActions.click(btn_AddNewReason, "Add New Reason");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_ChallengeReasons, challengeReason, "Challenge Reason");
			webActions.waitForPageLoaded();
			webActions.click(btn_Save_ChallengeReasons, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			if(actContent.contains("Data saved successfully.")){
				report.reportPass("Successfully added the Challenge Reason ");
			}else{
				report.reportFail("Failed to add the Challenge Reason");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void editChallengeReason(String challengeReason){
		try {
			navigateChallengeReason();
			try {
				webActions.waitForVisibility(txt_ChallengeReasons, "ChallengeReasons", 8);
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_ChallengeReasons, "Challenge Reason");
			webActions.sendKeys(txt_ChallengeReasons, challengeReason, "Challenge Reason");
			webActions.waitForPageLoaded();
			webActions.click(btn_Save_ChallengeReasons, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			if(actContent.contains("Data saved successfully.")){
				report.reportPass("Successfully updated the Challenge Reason ");
			}else{
				report.reportFail("Failed to update the Challenge Reason");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void deleteChallengeReason(String expMessage){
		try {
			navigateChallengeReason();
			try {
				webActions.waitForVisibility(btn_Delete_ChallengeReasons, "Delete", 8);
			} catch (Exception e) {
			}
			webActions.waitAndClick(btn_Delete_ChallengeReasons, "Delete");
			webActions.waitForPageLoaded();
			webActions.click(btn_Save_ChallengeReasons, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			if(actContent.contains(expMessage)){
				report.reportPass("Successfully deleted the Challenge Reason ");
			}else{
				report.reportFail("Failed to delete the Challenge Reason");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void navigateChallengeResponse() throws Exception{
		webActions.click(lnk_ChallengeResponse, "Challenge Responses");
		webActions.waitForPageLoaded();
	}
	
	public void verifyMandatoryValidationMessageChallengeResponse(String expMessage){
		try {
			navigateChallengeResponse();
			try {
				webActions.waitForVisibility(btn_AddNewResponse, "Add New Response", 5);
			} catch (Exception e) {
			}
			webActions.click(btn_AddNewResponse, "Add New Response");
			webActions.click(btn_AddNewResponse, "Add New Response");
			String actMessage=webActions.waitAndGetText(lbl_Error_ChallengeReasons, "Error message");
			report.reportInfo("Expected messages: "+expMessage);
			report.reportInfo("Actual messages: "+actMessage);
			if(actMessage.contains(expMessage)){
				report.reportPass("Successfully verified mandatory field validation error message in Challenge Response tab");	
			}else{
				report.reportFail("Failed to verify mandatory field validation error message in Challenge Response tab: "+actMessage);	
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void addNewChallengeResponse(String challengeResponse){
		try {
			navigateChallengeResponse();
			try {
				webActions.waitForVisibility(txt_ChallengeResponses, "Challenge Response", 8);
			} catch (Exception e) {
			}
			webActions.click(btn_AddNewResponse, "Add New Response");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_ChallengeResponses, challengeResponse, "Challenge Response");
			webActions.waitForPageLoaded();
			webActions.click(btn_Save_ChallengeResponse, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			if(actContent.contains("Data saved successfully.")){
				report.reportPass("Successfully added the Challenge Response ");
			}else{
				report.reportFail("Failed to add the Challenge Response");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void editChallengeResponse(String challengeResponse){
		try {
			navigateChallengeResponse();
			try {
				webActions.waitForVisibility(txt_ChallengeResponses, "Challenge Response", 8);
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_ChallengeResponses, "Challenge Response");
			webActions.sendKeys(txt_ChallengeResponses, challengeResponse, "Challenge Response");
			webActions.waitForPageLoaded();
			webActions.click(btn_Save_ChallengeResponse, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			if(actContent.contains("Data saved successfully.")){
				report.reportPass("Successfully updated the Challenge Response ");
			}else{
				report.reportFail("Failed to update the Challenge Response");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void deleteChallengeResponse(String expMessage){
		try {
			navigateChallengeResponse();
			try {
				webActions.waitForVisibility(btn_Delete_ChallengeResponses, "Delete", 8);
			} catch (Exception e) {
			}
			webActions.waitAndClick(btn_Delete_ChallengeResponses, "Delete");
			webActions.waitForPageLoaded();
			webActions.click(btn_Save_ChallengeResponse, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			if(actContent.contains(expMessage)){
				report.reportPass("Successfully deleted the Challenge Response ");
			}else{
				report.reportFail("Failed to delete the Challenge Responses");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	

	public void selectDropdown(WebElement element,String valuetoSelect,String elementName) throws Exception{
		try {
			if (!valuetoSelect.isEmpty()) {
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.click(element, elementName);
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				driver.findElement(By.xpath("//li[contains(.,'" + valuetoSelect + "')]")).click();
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void selectResponseStatusDropDown(DataTable testData){
		try {
			String responseStatus=getDatafromMap(testData,"Module Status");
			int row = 0;
			switch (responseStatus) {
			case "Clear":
				row=1;
				break;
			case "Review":
				row=2;
				break;
			case "Needs Attention":
				row=3;
				break;
			}
			//webActions.click(dd_ResponseStatus, "Response Status");
			webActions.waitForPageLoaded();
			driver.findElement(By.xpath("//ul[@id='ddlelement_options']/li["+row+"]")).click();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public String getResponseStatus(String status){
		switch (status) {
		case "Clear":
			status="success";
			break;
		case "Review":
			status="alert";
			break;
		case "Needs Attention":
			status="error";
			break;
		}
		return status;
	}

	public String getUniqueNumber(int length) {
		String uniqueNumber = "";
		try {
			Date dNow = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("DDYYHHssMs");
			String s = ft.format(dNow);
			uniqueNumber = s.substring(0, Math.min(s.length(), length));

		} catch (Exception e) {

		}
		return uniqueNumber;
	}


	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(lnk_ErrorCategorieChallengeConfiguration);
	}

}
