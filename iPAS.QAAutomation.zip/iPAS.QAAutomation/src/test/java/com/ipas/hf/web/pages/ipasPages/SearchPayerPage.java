package com.ipas.hf.web.pages.ipasPages;
import org.openqa.selenium.support.ui.ExpectedCondition;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.codoid.products.fillo.Select;
import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

import com.ipas.hf.web.pages.BasePage;

public class SearchPayerPage extends BasePage{


	@FindBy(xpath="//lib-panel[2]/div/ejs-accordion/div/div[2]/div/div/div/ul/li/div[1]/a")
	private WebElement lnk_payer;
	
	@FindBy(linkText = "Configure Payer Codes")
	private WebElement lnk_configurePayerCodes;
	
	@FindBy(xpath="//a[text()='Organization Maintenance']")
	private WebElement lnk_orgMaintainance;
	
	@FindBy(xpath="//div[@class='maintenance-control-section']/ejs-dashboardlayout/div/lib-panel[2]/div/ejs-accordion/div/div[2]/div/div/div/ul/li/div[1]/a")
	private WebElement configurePayerCOdes;
	
	@FindBy(xpath="//div[text()='Configure Payer Codes to Connection Methods and monitor performance across associated modules.']")
	private WebElement txt_configurePayerNotes;
	

	@FindBy(xpath="//span[@class='breadcrum-active' and text()='Configure Payer Codes']")
	private WebElement breadcrumb_configurePayerCodes;

	@FindBy(xpath="//div[@class='search-control']/label[text()='Search']")
	private WebElement txt_searchfield;

	@FindBy(xpath="//div[@class='search-control']//div[@class='e-input-group']/input[@type='text']")
	private WebElement txt_searchinputbox;
	
	@FindBy(xpath="//base-slider-switch[@class='active-switch']//span[@class='e-switch-on']")
	private WebElement toggle_switch;
	
	@FindBy(xpath="//span[@class='ml-2 isActive']")
	private WebElement switch_Active;
	
	@FindBy(xpath="//span[@class='e-switch-off']")
	private WebElement switch_Inactive;
	

	@FindBy(xpath="//div[@class='connection-dropdown']/label[text()='Connection']")
	private WebElement txt_connectionfield;

	@FindBy(xpath="//input[@class='e-input']")
	private WebElement dd_connectionfield;

	@FindBy(xpath="//select[@name='connection']")
	private String select_connectionfield;

	@FindBy(xpath="//a[@class='btn [--blue]' and text()='Search']")
	private WebElement button_search;

	@FindBy(xpath="//span[@class='e-label' and text()='Inactive']//preceding::span[@class='e-icons e-frame e-check']")
	private WebElement chkbox_inactive;

	@FindBy(xpath="//a[@class='btn btn--white' and text()='Add Payer Code ']")
	private WebElement button_AddPayerCode;

	@FindBy(xpath="//div[@class='d-flex mb-2 result' and text()='Results 0']")
	private WebElement txt_resultcount;

	@FindBy(xpath="//div[@class='emptyinfo template-noReuslt']/img[@src='assets/images/error.png']")
	private WebElement error_Noresults;
	
	@FindBy(xpath = "//table[@id='formGrid_content_table']/tbody")
	private WebElement grid_Results;
	
	@FindBy(xpath = "//td[contains(@aria-label,'Payer Code/ Payer Description')]//span")
	private WebElement grid_Payer_Results;
	
	@FindBy(xpath = "//td[contains(@aria-label,'Connection')]")
	private WebElement grid_Connection_Results;
	
	@FindBy(xpath = "//div[@class='control-section payergridclass']")
	private WebElement grid_Header;
	
	 @FindBy(xpath = "//table[@id='formGrid_content_table']/tbody/tr/td")
	 private WebElement lbl_GridRecords;



	@FindBy(xpath="//ul[@class='navbar-nav']/li/a")
	private List<WebElement> lst_menuItems;

	@FindBy(xpath="//span[@class='panel-title']")
	private List<WebElement> lst_panelNames;

	@FindBy(xpath="(//div[@class='e-acrdn-item e-select e-expand-state e-selected e-active'])[1]//div[@class='panel-containArea']//div[@class='contain-text']")
	private List<WebElement> lst_menuOrgUsers;

	@FindBy(xpath="(//div[@class='e-acrdn-item e-select e-expand-state e-selected e-active'])[2]//div[@class='panel-containArea']//div[@class='contain-text']")
	private List<WebElement> lst_payerpanel;

	@FindBy(linkText = "Maintenance")
	private WebElement lnk_Maintenance;

	private StepLogging log = StepLogging.getLoggingObject();




	RestActions rest=new RestActions();
	HomePage homePage=new HomePage();


	public SearchPayerPage() {
		PageFactory.initElements(driver, this);
	}
	
	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}
	
	public void navigateToconfigurePayerCodes(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lnk_configurePayerCodes,"Configure Payer Codes");
			report.reportPass("Should click on configure payer codes");
			webActions.waitForPageLoaded();
			webActions.isDisplayed(breadcrumb_configurePayerCodes, "BreadCrumb Configure Payer Codes");
			report.reportPass("Should display the breadcrumb for configure payer codes");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifySearchCriteria(){
		try {
			webActions.waitForPageLoaded();
			webActions.isDisplayed(txt_searchfield, "Search Field");
			report.reportPass("Should display the search criteria section in configure payer codes");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifySearchfield(){
		try {
			String expectedPlaceholder="Type PELITAS Payer Code or Description";
			webActions.waitForPageLoaded();
			webActions.waitUntilEnabledAndClick(lnk_configurePayerCodes,"Payer Codes");
			webActions.sendKeys(lnk_configurePayerCodes,"","Payer Codes");
			webActions.click(lnk_configurePayerCodes,"Configure Payer Codes");
			webActions.isDisplayed(txt_searchfield, "Search Field");
			report.reportPass("Should display the search criteria section in configure payer codes");
			webActions.isDisplayed(txt_searchinputbox, "Search Input Box");
			report.reportPass("Should display the search field as Text Input Box");
			String actualPlaceholder=txt_searchinputbox.getAttribute("placeholder");
			if(actualPlaceholder.contentEquals(expectedPlaceholder))
			{
				report.reportPass("Should display the placeholder for search input box as :"+expectedPlaceholder);
			}
			else{
				throw new Exception("Fail to display the placeholder for search input box and displayed as "+actualPlaceholder);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyConnectionfield(){
		try {
			webActions.waitForPageLoaded();
			webActions.isDisplayed(txt_connectionfield, "Connection Field");
			report.reportPass("Should display the Connection field in search criteria section");
			webActions.click(dd_connectionfield, "Connection field dropdown");
			report.reportPass("Should click on Connection field dropdown");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyApplybutton(){
		try {
			webActions.waitForPageLoaded();
			webActions.isDisplayed(button_search, "Search Button");
			report.reportPass("Should display Search Button in search criteria section");
			webActions.isDisplayed(chkbox_inactive, "Inactive checkBox checked");
			report.reportPass("Should display Inactive checkBox checked by default in search criteria section");
			webActions.isDisplayed(button_AddPayerCode, "Add Payer Code Button");
			report.reportPass("Should display Add Payer Code Button in search criteria section");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyNoResultsFound(){
		try {
			String expectedErrorMessage=" Your search did not have any results ";
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			if(txt_resultcount.isDisplayed())
			{
				String actualMessage=error_Noresults.getText();
				if(expectedErrorMessage.contentEquals(actualMessage))
				{
					report.reportPass("Should display  Your search did not have any results error message when the result count is 0");
				}
				else{
					throw new Exception("Fail to display error message");
				}
			}
		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	
	
	public ArrayList<String> getGridData(WebElement grid_Header,WebElement grid_Results,String columnName,String fieldName) throws Exception 
	{
		ArrayList<String>data=new ArrayList<String>();
		try {
			webActions.waitForPageLoaded();
			Integer columnIndex = null;
			List<WebElement> rows_table = grid_Header.findElements(By.tagName("tr"));
			List<WebElement> columns=rows_table.get(0).findElements(By.tagName("th"));
			for(int cnum=0;cnum<columns.size();cnum++)
			{
				String actColumnName = (columns.get(cnum).getText());
				if(actColumnName.toUpperCase().contains(columnName.toUpperCase())){
					columnIndex = cnum;
					break;
				}
			}
			//to get tag name
			String tagName="";
			if("Status".contentEquals(columnName)){
				tagName="span";
			}
			else {
				tagName="div";
			}
			List<WebElement> results_rows_table = grid_Results.findElements(By.tagName("tr"));
			int rowsCount = results_rows_table.size();

			for(int rnum=0;rnum<rowsCount;rnum++){
				List<WebElement> resultsColumns= results_rows_table.get(rnum).findElements(By.tagName("td"));
				List<WebElement> resultsData = (resultsColumns.get(columnIndex).findElements(By.tagName(tagName)));
				for(int i = 0;i<resultsData.size();i++){
					if ("Payer".contentEquals(columnName)) {
						data.addAll(getPayerColumnData(fieldName, i, resultsData));
					}
					else if("Connection".contentEquals(columnName)){
						String text = resultsData.get(i).getText();
						data.add(text);
						}
					
					else{
						String text = resultsData.get(i).getText();
						data.add(text);
						break;
					}
				}
			}
		}catch (Exception e){
			log.error("Failed to get data from ", columnName, e);
			throw new Exception(e);
		}
		return data;
	}
	
	public ArrayList<String> getPayerColumnData(String fieldName,int row,List<WebElement> resultsData){
		String text="";
		ArrayList<String>data=new ArrayList<String>();
		if("PayerCode".contentEquals(fieldName)){
			if(row==0){
				text = resultsData.get(row).getText();
				String[] splited = text.split("\\s+");
				text=splited[0];
				data.add(text);
			}					
		}
		else if("PayerDescription".contentEquals(fieldName)){
			if (row==2) {
				text = resultsData.get(row).getText();
				data.add(text.replaceAll("\\s(?=[A-Z])|(?<=\\s)\\s+", ""));
			} 
		}
		return data;
	}
	
	
	public void verifySearchFunctionality(String Identifier,String connection){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_searchinputbox,Identifier,"SearchInput");
			webActions.waitForPageLoaded();
			webActions.sendKeys(dd_connectionfield,connection,"Connection");
			webActions.waitForPageLoaded();
			webActions.click(button_search, "Search Button");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			report.reportInfo(Identifier + "Actual value :"+grid_Payer_Results.getText());
			report.reportInfo(connection + "Actual value :"+grid_Connection_Results.getText());
			if(grid_Payer_Results.getText().trim().toLowerCase().contains(Identifier.trim().toLowerCase())&&grid_Connection_Results.getText().trim().contains(connection.trim())){
				report.reportPass("Successfully validated search results matching the search criteria :"+connection);
				webActions.click(grid_Payer_Results, "CLick on the result");
				webActions.waitForPageLoaded();
			}
			else{
				throw new Exception("Data verification failed, and unmatched data");
			}
		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyToggle(){
		try {
			webActions.waitForPageLoaded();
			if(toggle_switch.isDisplayed()){
				report.reportPass("Successfully displayed toggle switch");
				webActions.waitForPageLoaded();
			}
			else{
				throw new Exception("Failed to display toggle switch");
			}
		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifySwitchToggle(String toggle){
		try {
			webActions.waitForPageLoaded();
			if(!toggle_switch.getText().equals(toggle)){
				report.reportPass("Successfully displayed toggle switch");
				webActions.waitForPageLoaded();
			}
			else{
				throw new Exception("Failed to display toggle switch");
			}
		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}