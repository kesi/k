package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class EligibilityEditPage extends BasePage {
	AddPatientVisitPage addpatient=new AddPatientVisitPage();

	@FindBy(xpath="//lib-panel[2]/div/ejs-accordion/div/div[2]/div/div/div/ul/li/div[1]/a")
	private WebElement lnk_payer;

	@FindBy(linkText = "Configure Payer Codes")
	private WebElement lnk_configurePayerCodes;

	@FindBy(xpath="//a[text()='Organization Maintenance']")
	private WebElement lnk_orgMaintainance;

	@FindBy(xpath="//div[@class='maintenance-control-section']/ejs-dashboardlayout/div/lib-panel[2]/div/ejs-accordion/div/div[2]/div/div/div/ul/li/div[1]/a")
	private WebElement configurePayerCOdes;

	@FindBy(xpath="//div[text()='Configure Payer Codes to Connection Methods and monitor performance across associated modules.']")
	private WebElement txt_configurePayerNotes;

	@FindBy(xpath="//span[@class='breadcrum-active' and text()='Configure Payer Codes']")
	private WebElement breadcrumb_configurePayerCodes;

	@FindBy(xpath="//span[@class='breadcrum-active']")
	private WebElement breadcrumb_editEligibility;

	@FindBy(xpath="//div[@class='search-control']/label[text()='Search']")
	private WebElement txt_searchfield;

	@FindBy(xpath="//div[@class='search-control']//div[@class='e-input-group']/input[@type='text']")
	private WebElement txt_searchinputbox;

	@FindBy(xpath="//div[@class='connection-dropdown']/label[text()='Connection']")
	private WebElement txt_connectionfield;

	@FindBy(xpath="//input[@class='e-input']")
	private WebElement dd_connectionfield;

	@FindBy(xpath="//select[@name='connection']")
	private String select_connectionfield;

	@FindBy(xpath="//a[@class='btn [--blue]' and text()='Search']")
	private WebElement button_search;
	
	@FindBy(xpath="//a[contains(text(),'Cancel')]")
	private WebElement button_cancel;
	
	@FindBy(xpath="//span[@class='e-label' and text()='Inactive']//preceding::span[@class='e-icons e-frame e-check']")
	private WebElement chkbox_inactive;

	@FindBy(xpath="//a[@class='btn btn--white' and text()='Add Payer Code ']")
	private WebElement button_AddPayerCode;

	@FindBy(xpath="//div[@class='d-flex mb-2 result' and text()='Results 0']")
	private WebElement txt_resultcount;

	@FindBy(xpath="//div[@class='emptyinfo template-noReuslt']/img[@src='assets/images/error.png']")
	private WebElement error_Noresults;

	@FindBy(xpath = "//table[@id='formGrid_content_table']/tbody")
	private WebElement grid_Results;

	@FindBy(xpath = "//span[@class='e-switch-handle e-switch-active']")
	private WebElement switch_active;
	
	@FindBy(xpath = "//span[@class='e-switch-off']")
	private WebElement switch_inactive;
	
	@FindBy(xpath = "//span[@class='ml-2 isActive']")
	private WebElement txt_Switch;
	
	@FindBy(xpath = "//div[@class='control-section payergridclass']")
	private WebElement grid_Header;

	@FindBy(xpath = "//table[@id='formGrid_content_table']/tbody/tr/td")
	private WebElement lbl_GridRecords;
	
	@FindBy(xpath = "//div[@id='serviceCodes']/div[@class='headtitle']/span")
	private WebElement lbl_ServicesCodes;
	
	@FindBy(xpath = "//div[@class='grid-wrapper']//div[@class='headtitle']/span")
	private WebElement lbl_ConnectionLabel;
	
	@FindBy(xpath = "//div[@id='payerDetails']/div[1]/h3")
	private  List<WebElement> lst_PayerCode;
	
	@FindBy(xpath = "//div[@id='payerDetails']/div[1]/h3")
	private  List<WebElement> lst_PayerValues;
	
	@FindBy(xpath = "//div[@id='searchCriteria']//h3")
	private  List<WebElement> lst_SearchCriteria;
	
	@FindBy(xpath = "//div[@id='serviceCodes']//div[contains(text(),'Service Code') or contains(text(),'Description')]")
	private  List<WebElement> lst_ServiceCodes;
	
	@FindBy(xpath = "//div[@id='serviceCodes']//i")
	private  List<WebElement> txt_Results;
	
	@FindBy(xpath = "//div[@id='payerDetails']/div[2]/h3")
	private List<WebElement> lbl_Connection;

	@FindBy(xpath = "(//td[contains(@aria-label,'PELITAS Payer Code/ Payer Description')]/a)[1]")
	private WebElement grid_payerCodeResults;

	@FindBy(xpath="//ul[@class='navbar-nav']/li/a")
	private List<WebElement> lst_menuItems;

	@FindBy(xpath="//span[@class='panel-title']")
	private List<WebElement> lst_panelNames;

	@FindBy(xpath="(//div[@class='e-acrdn-item e-select e-expand-state e-selected e-active'])[1]//div[@class='panel-containArea']//div[@class='contain-text']")
	private List<WebElement> lst_menuOrgUsers;

	@FindBy(xpath="(//div[@class='e-acrdn-item e-select e-expand-state e-selected e-active'])[2]//div[@class='panel-containArea']//div[@class='contain-text']")
	private List<WebElement> lst_payerpanel;

	@FindBy(linkText = "Maintenance")
	private WebElement lnk_Maintenance;
	
	@FindBy(xpath="//a[text()='Add Payer Code ']")
	private WebElement btn_addPayerCode;

	@FindBy(xpath="//label[text()='Payer Code']/../input")
	private WebElement txt_PayerCode;

	@FindBy(xpath="//input[@name='payerCodeDescription']")
	private WebElement txt_PayerDesc;

	@FindBy(xpath="//label[text()='Description']/../span[text()='*']")
	private WebElement asterix_PayerDesc;

	@FindBy(xpath="//input[@aria-placeholder='Please Select']")
	private WebElement dd_Connection;

	@FindBy(xpath="//td[contains(@aria-label,'EDI Vendor Payer Code')]/div/input")
	private WebElement txt_EDIVendorCode;

	@FindBy(xpath="//td[contains(@aria-label,'EDI Vendor Description')]/div/input")
	private WebElement txt_EDIVendorDesc;
	
	@FindBy(xpath="//a[contains(text(),'Add New Connection')]")
	private WebElement btn_AddNewConnection;

	@FindBy(xpath="//a[contains(text(),'Save')]")
	private WebElement btn_Save;
	
	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;
	
	@FindBy(xpath="(//tr/td/span/img[@src='assets/images/trash-icon.png'])[last()]")
	private WebElement btn_Trash;
	
	@FindBy(xpath="//div[@class='breadcrum-container']/span")
	private List<WebElement> lbl_Breadcrumb;

	private StepLogging log = StepLogging.getLoggingObject();



	public EligibilityEditPage() {
		PageFactory.initElements(driver, this);
	}

	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}

	RestActions rest=new RestActions();
	HomePage homePage=new HomePage();
	
	public void verifyBreadcrumbinEditEligibility(DataTable breadcrumb ){
		try {
			ArrayList<String> expectdBreadcrumb = new ArrayList<>(breadcrumb.asList());
			webActions.waitForPageLoaded();
			ArrayList<String> actualBreadcrumb=webActions.getDatafromWebTable(lbl_Breadcrumb);
			report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumb);
			report.reportInfo("Expected Breadcrumb Titles "+expectdBreadcrumb);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumb, expectdBreadcrumb);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Breadcrumb Titles in Edit Eligibility page");
			}else{
				throw new Exception("Fail to verify the Breadcrumb Titles in Edit Eligibility page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyHyperlink(DataTable testData){
		try {
			webActions.waitForPageLoaded();
			String searchInput=getDatafromMap(testData,"SearchInput");
			String connection=getDatafromMap(testData,"Connection");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_searchinputbox,searchInput,"SearchInput");
			webActions.waitForPageLoaded();
			webActions.sendKeys(dd_connectionfield,connection,"Connection");
			webActions.waitForPageLoaded();
			webActions.click(button_search, "Search Button");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.waitUntilisDisplayed(grid_Results,"Grid Results");
			String expectedValue1[]=grid_payerCodeResults.getText().split("\\s+");
			String expectedValue=expectedValue1[0];
            report.reportInfo("Expected Payer Value :"+expectedValue);
			if(searchInput.contains(expectedValue))
			{
				if(grid_payerCodeResults.isDisplayed())
				{
					report.reportPass("Should display hyperlink as the matching record");
				}
				else{
					throw new Exception("Failed to display matching record as a hyperlink");
				}
			}
			else
			{
				throw new Exception("Failed to display matching record in search results");
			}

		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyEditEligibility(DataTable testData){
		try {
			webActions.waitForPageLoaded();
			String searchInput=getDatafromMap(testData,"SearchInput");
			String connection=getDatafromMap(testData,"Connection");
			addpatient.notepadWrite("searchInput",searchInput);
			addpatient.notepadWrite("connection",connection);
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_searchinputbox,searchInput,"SearchInput");
			webActions.waitForPageLoaded();
			webActions.sendKeys(dd_connectionfield,connection,"Connection");
			webActions.waitForPageLoaded();
			webActions.click(button_search, "Search Button");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.waitUntilisDisplayed(grid_Results,"Grid Results");
			String expectedValue1[]=grid_payerCodeResults.getText().split("\\s+");
			String expectedValue=expectedValue1[0];
            report.reportInfo("Expected Payer Value :"+expectedValue);
            String payerDescription=expectedValue1[1];
            addpatient.notepadWrite("payerDescription",payerDescription);
			if(searchInput.contains(expectedValue))
			{
				webActions.click(grid_payerCodeResults,"Matching record");
				report.reportPass("Should display and click on the matching record");
				webActions.waitForPageLoaded();
				if(breadcrumb_editEligibility.getText().contentEquals(searchInput))
				{
					report.reportPass("Successfully navigated to Edit Eligibility Screen");
				}
				else{
					throw new Exception("Failed to navigate to Edit Eligibility Screen");
				}
			}
			else{
				throw new Exception("Failed to display matching record on the search screen");
			}
		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	
	public void verifyToggleSwitch(){
		try {

            webActions.waitForPageLoaded();
			if(switch_active.isDisplayed())
			{
				webActions.isDisplayed(txt_Switch, "Switch Active or Inactive");
				String SwitchText=txt_Switch.getText();
				if(SwitchText.contentEquals("Active"))
				{
					report.reportPass("Toggle is in the Active position and displayed the word Active Successfully");
					webActions.click(switch_active, "Active Switch");
					webActions.click(btn_Save, "Save Button");
				}
				
				else{
					throw new Exception("Failed to display Active text when switch is active");
				}
			}
			
			else if(switch_inactive.isDisplayed())
			{
				webActions.isDisplayed(txt_Switch, "Switch Active or Inactive");
				String SwitchText=txt_Switch.getText();
				if(SwitchText.contentEquals("Inactive"))
				{
					report.reportPass("Toggle is in InActive position and displayed the word InActive Successfully");
					webActions.click(switch_inactive, "InActive Switch");
				}
				
				else{
					throw new Exception("Failed to display InActive text when switch is Inactive");
				}
			}
			
		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyLabels(DataTable testData){
		try {
			ArrayList<String> expLabelNames = new ArrayList<>(testData.asList());
			report.reportInfo("Expected Label Names: "+expLabelNames);
			ArrayList<String> actLabelNames=webActions.getDatafromWebTable(lst_PayerCode);
			report.reportInfo("Displayed Actual Label Names as  "+actLabelNames);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified payer code label names in edit eligibility Successfully");
			}
			else{
				throw new Exception("Fail to verify payer code label names and unmatched Names are: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyLabelConnection(DataTable testData){
		try {
			ArrayList<String> expLabelNames = new ArrayList<>(testData.asList());
			report.reportInfo("Expected Column names in search criteria: "+expLabelNames);
			ArrayList<String> actLabelNames=webActions.getDatafromWebTable(lst_SearchCriteria);
			report.reportInfo("Displayed Actual Column names in search criteria: "+actLabelNames);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified Column names in search criteria Successfully");
			}
			else{
				throw new Exception("Fail to verify Column names in search criteria and unmatched Names are: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyLabelValues(DataTable testData){
		try {
			String searchInput=addpatient.notepadRead("searchInput");
			String connection=addpatient.notepadRead("connection");
			String payerDescription=addpatient.notepadRead("payerDescription");
			ArrayList<String> expLabelNames = new ArrayList<>(testData.asList());
			report.reportInfo("Expected Label Names: "+expLabelNames);
			ArrayList<String> actLabelNames=webActions.getDatafromWebTable(lst_PayerCode);
			report.reportInfo("Displayed Actual Label Names as  "+actLabelNames);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified payer code label names in edit eligibility Successfully");
			}
			else{
				throw new Exception("Fail to verify payer code label names and unmatched Names are: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyColumnLabels(DataTable testData){
		try {
			ArrayList<String> expLabelNames = new ArrayList<>(testData.asList());
			report.reportInfo("Expected Label Names: "+expLabelNames);
			ArrayList<String> actLabelNames=webActions.getDatafromWebTable(lst_PayerCode);
			report.reportInfo("Displayed Actual Label Names as  "+actLabelNames);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified payer code label names in edit eligibility Successfully");
			}
			else{
				throw new Exception("Fail to verify payer code label names and unmatched Names are: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyCancelFunct(){
		try {
			webActions.isDisplayed(breadcrumb_editEligibility,"BreadCrumb Edit Eligibility");
			report.reportPass("Should be present in edit eligibility screen Successfully");
			webActions.waitForPageLoaded();
			webActions.click(button_cancel,"Cancel");
			report.reportPass("Should click on Cancel Button");
			webActions.waitForPageLoaded();
			webActions.isDisplayed(breadcrumb_configurePayerCodes, "Configure Payer Codes");
			report.reportPass("Should Be Navigated back to Configure Payer Codes page successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyServiceCodes(String label){
		try {
			String expectedLabelName=label;
			String actualLabelName=webActions.getText(lbl_ServicesCodes,"Service Codes label Name");
			if(expectedLabelName.contains(actualLabelName))
			{
				report.reportPass("Should Display Section label Name as "+ actualLabelName +"successfully");
			}
			else{
				throw new Exception("Fail to display Section label Name as"+actualLabelName);
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyColumnHeaderServiceCodes(DataTable testData){
		try {
			ArrayList<String> expLabelNames = new ArrayList<>(testData.asList());
			report.reportInfo("Expected Column Header names in ServiceCodes: "+expLabelNames);
			ArrayList<String> actLabelNames=webActions.getDatafromWebTable(lst_ServiceCodes);
			report.reportInfo("Displayed Actual Column names in search criteria: "+actLabelNames);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified Column Header names in Service Codes Section Successfully");
			}
			else{
				throw new Exception("Fail to verify Column Header names in Service Codes Section: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyResultsDisplay(String testData){
		try {
			report.reportInfo("Expected display names in ServiceCodes: "+testData);
			ArrayList<String> actualNames=webActions.getDatafromWebTable(txt_Results);
			String results[]=actualNames.get(0).split("//s");
			String actualLabelName=results[0];
			report.reportInfo("Displayed Actual display names in ServiceCodes: "+actualLabelName);
			if(testData.contains(actualLabelName)){
				report.reportPass("Verified display results in Service Codes Section Successfully");
			}
			else{
				throw new Exception("Fail to verify display results in Service Codes Section: "+actualLabelName);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyConnection(String label){
		try {
			String expectedLabelName=label;
			String actualLabelName=webActions.getText(lbl_ConnectionLabel,"Connection label Name");
			if(expectedLabelName.contains(actualLabelName))
			{
				report.reportPass("Should Display Section label Name as "+ actualLabelName + "successfully");
			}
			else{
				throw new Exception("Fail to display Section label Name as"+actualLabelName);
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void addNewConnection(String connection,String vendorCode,String vendorDesc){

		try {
			String messageTitle ="Success!";
			String messageContent="Data saved successfully.";
			StringBuilder unmatch=new StringBuilder();

			webActions.waitForPageLoaded();
			webActions.click(btn_Trash,"Trash Icon");
			webActions.click(btn_AddNewConnection, "Add New Connection Button");
			webActions.waitForPageLoaded();
			webActions.sendKeys(dd_Connection,connection,"Connection");
			webActions.sendKeys(txt_EDIVendorCode,vendorCode, "EDI Vendor Code");
			webActions.sendKeys(txt_EDIVendorDesc,vendorDesc, "EDI Vendor Description");
			report.reportPass("Should enter the values in Add payer code successfully");
			webActions.click(btn_Save, "Save");
			report.reportPass("Should click on Save Button successfully");
			try {
				String msg=webActions.getText(txt_ToastMsgs, "Messages");
				String[] titleContent=msg.split("\\n");
				String actTitle=titleContent[0];
				String actContent=titleContent[1];
				report.reportInfo("Save successfull message displayed: "+msg);
				if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent)))
				{
					report.reportPass("Successfully new connection is added and alert message is matched: "+msg);
				}
				else
				{
					unmatch.append("Alert message is not captured/matched after new connection: "+msg);
				}		
			} catch (Exception e) {
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyTrashIcon(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_AddNewConnection, "Add New Connection Button");
			webActions.click(btn_Trash,"Trash Icon");
			webActions.waitForPageLoaded();
			report.reportPass("Should click on Trash Icon successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}