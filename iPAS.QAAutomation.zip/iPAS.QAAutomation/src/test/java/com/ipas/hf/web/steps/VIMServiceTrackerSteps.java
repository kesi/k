package com.ipas.hf.web.steps;

import org.json.simple.parser.ParseException;

import com.ipas.hf.web.pages.ipasPages.EligibityPage;
import com.ipas.hf.web.pages.ipasPages.VIMPaymentPage;
import com.ipas.hf.web.pages.ipasPages.VIMServiceTrackerPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class VIMServiceTrackerSteps {
	
	VIMServiceTrackerPage vimst=new VIMServiceTrackerPage();
	EligibityPage eligibility=new EligibityPage();
	
	
	@Then("Update VIMServiceTracker JSON file")
	public void update_VIMServiceTracker_JSON_file() throws Exception {
		vimst.updateVIMServiceTrackerJSON();
	}
	
	@Then("Click on Confirm Visit and verify results")
	public void click_on_Confirm_Visit_and_verify_results(DataTable testData) {
		vimst.confirmVisit(testData);
	}

	@Then("Select a Lobby {string}")
	public void select_a_Lobby(String lobbyName) {
		vimst.selectLobby(lobbyName);
	}

	@Then("Verify the {string} Status in Service Tracker Shot Panel")
	public void verify_the_Status_in_Service_Tracker_Shot_Panel(String expStatus) {
	    vimst.verifyServiceTrackerStatusShotPanel(expStatus);
	}
	
	@Then("Verify the Status and Tracking History in Service Tracker Full page")
	public void verify_the_Status_and_Tracking_History_in_Service_Tracker_Full_page(DataTable testData) {
		vimst.verifyTrackingHistory(testData);
	}
	@Then("Click on Send Arrival Notice and verify results")
	public void click_on_Send_Arrival_Notice_and_verify_results(DataTable testData) {
	   vimst.sendArrivalNotice(testData);
	}
	
	@Then("Verify the data in Transactions")
	public void verify_the_data_in_Transactions(DataTable testData) {
	   vimst.verifyTransactions(testData);
	}
	
	@Then("Click on Send Arrival Notice with WheelChair by select parking {string}")
	public void click_on_Send_Arrival_Notice_with_WheelChair_by_select_parking(String parking,DataTable testData) {
		vimst.sendArrivalNoticeWithWheelChair(parking, testData);
	}
	
	@Then("Share My Visit from VIM")
	public void share_My_Visit_from_VIM(DataTable testData) {
		vimst.addAuthorizedUser(testData);
	}

	@Then("Verify the Authorized Users in Service Tracker full page")
	public void verify_the_Authorized_Users_in_Service_Tracker_full_page(DataTable testData) {
		vimst.verifyAuthorizedUserServiceTracker(testData);
	}

}
