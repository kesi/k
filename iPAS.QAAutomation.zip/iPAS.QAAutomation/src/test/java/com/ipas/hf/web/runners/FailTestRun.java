package com.ipas.hf.web.runners;

import java.io.IOException;
import org.openqa.selenium.OutputType;
import com.ipas.hf.engine.ConcurrentEngine;
import com.ipas.hf.testbase.TestBase;

import cucumber.api.CucumberOptions;
import cucumber.api.Scenario;
import cucumber.api.java.After;

@CucumberOptions(features = {"@target/WebRerun.txt"} ,
    glue = {"com.ipas.hf.web", "com.ipas.hf.testbase"} , plugin = {"pretty"})
public class FailTestRun extends TestBase {

  @After()
  public void removeUsedData(){
   // BasePage.removeTestData();
  }

  @After
  public void after(Scenario scenario) throws IOException{
    if (scenario.isFailed()) {
      byte[] bytes =
          (ConcurrentEngine.getEngine().getWebDriver()).getScreenshotAs(OutputType.BYTES);
      scenario.embed(bytes, "image/png");
    }
  }

}
