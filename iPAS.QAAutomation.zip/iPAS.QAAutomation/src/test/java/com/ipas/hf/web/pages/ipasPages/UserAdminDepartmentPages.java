package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class UserAdminDepartmentPages extends BasePage{
	

	@FindBy(xpath = "//img[@src='assets/images/cog.png']")
	private WebElement img_Settings;
	
	@FindBy(xpath = "//ipas-app-navigations[1]//nav[1]//div[1]/a[@class='dropdown-item']/span")
	private List<WebElement> lst_Settings;
	
	@FindBy(xpath="//table[@class='e-table']//thead/tr")
	private WebElement lbl_Headers;
	
	@FindBy(xpath = "(//div[@class='card' and @style='cursor: pointer;'])[1]")
	private WebElement lbl_BillingDepartMentCard;
	
	@FindBy(xpath = "(//div[@class='card' and @style='cursor: pointer;'])[2]")
	private WebElement lbl_RiskDepartMentCard;
	
	@FindBy(xpath = "(//ipas-app-navigations[1]//nav[1]//div[1]/a[@class='dropdown-item']/span)[2]")
	private WebElement lbl_ChangeDepartment;
	
	@FindBy(xpath = "//span[contains(text(),'Hello!')]")
	private WebElement lbl_PopUpTitle;
	
	@FindBy(xpath = "//span[contains(text(),'What Department are you working today?')]")
	private WebElement lbl_PopUpContent;
	
	@FindBy(xpath = "//div[@class='card']/div")
	private List<WebElement> lbl_PopUpFacilityDepartments;
	
	@FindBy(xpath = "//div[@class='card']/div[2]")
	private List<WebElement> lbl_PopUpDepartments;
	
	@FindBy(xpath = "//div[@class='card' and @style='cursor: pointer;']")
	private WebElement lbl_DepartMentCards;
	
	@FindBy(xpath = "(//div[@class='userLabel'])[1]")
	private WebElement lbl_FacilityiPAS;
	
	@FindBy(xpath = "(//div[@class='userOperaterID'])[1]")
	private WebElement lbl_DepartmentiPAS;
	
	@FindBy(xpath = "(//button[@class='btn btn-primary btn-md'])[1]")
	private WebElement Btn_AccountApplyBtn;
	
	public UserAdminDepartmentPages() {
		PageFactory.initElements(driver, this);
	}
	
	public void verifyFacilityDepartmentsOnPopUp(DataTable testData){
		try {
			webActions.waitForPageLoaded();
			ArrayList<String> expecteddata = new ArrayList<>(testData.asList());
			report.reportInfo("Expected data on the pop up: "+expecteddata);			
			webActions.waitForPageLoaded();
			ArrayList<String> actualColumnNames=webActions.getDatafromWebTable(lbl_PopUpFacilityDepartments);
			report.reportInfo("Displayed data on the pop up: "+actualColumnNames);
			ArrayList<String>unmatchedColumnNames=webActions.getUmatchedInArrayComparision(actualColumnNames, expecteddata);
			if(unmatchedColumnNames.size()==0){
				report.reportPass("Verified facility departments on the pop up successfully");
			}
			else{
				throw new Exception("Fail to verify facility departments on the pop up and unmatched data is : "+unmatchedColumnNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	/**
	 * to select the required option from settings menu
	 * @param element
	 * @param valueToSelect
	 */
	public void selectOptionfromSettingsList(String valueToSelect) {
		try {
			webActions.waitForPageLoaded();		
			clickOnSettings();
			webActions.waitForPageLoaded();
			webActions.click(lbl_ChangeDepartment, "ChangeDepartment");
			webActions.waitForPageLoaded();			
		} catch (Exception e) {
			report.reportFail("Fail to select the option from Settings");
		}
	}

	public void clickOnSettings(){
		try {
			webActions.waitForPageLoaded();			
			webActions.click(img_Settings, "SettingsImage");
			webActions.waitUntilListisDisplayed(lst_Settings, "SettingsList");
			report.reportPass("Clicked on Settings Image");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnDepartmentCards(String card){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_DepartMentCards, "DepartMentCard");
			if("Billing and Insurance".contentEquals(card)){
				webActions.click(lbl_BillingDepartMentCard, "DepartMentCard");
			}
			else if ("Risk Management".contentEquals(card)){
				webActions.click(lbl_RiskDepartMentCard, "DepartMentCard");
			}		
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyContentOnPopUp(DataTable testData){
		try {
			webActions.waitForPageLoaded();
			ArrayList<String> expectedContent = new ArrayList<>(testData.asList());
			report.reportInfo("Expected data on the pop up: "+expectedContent);			
			webActions.waitForPageLoaded();
			ArrayList<String> actualContent = new ArrayList<>();
			actualContent.add(webActions.getText(lbl_PopUpTitle, "PopUptitle"));
			actualContent.add(webActions.getText(lbl_PopUpContent, "PopUpContent"));
			report.reportInfo("Displayed data on the pop up: "+actualContent);
			ArrayList<String>unmatchedColumnNames=webActions.getUmatchedInArrayComparision(actualContent, expectedContent);
			if(unmatchedColumnNames.size()==0){
				report.reportPass("Verified data on the pop up successfully");
			}
			else{
				throw new Exception("Fail to verify data on the pop up and unmatched data is : "+unmatchedColumnNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyFacilityDepartmentAtiPAS(DataTable testData){
		try {
			webActions.waitForPageLoaded();
			ArrayList<String> expectedContent = new ArrayList<>(testData.asList());
			report.reportInfo("Expected data on the iPAS header: "+expectedContent);
			ArrayList<String> actualContent = new ArrayList<>();
			webActions.waitForPageLoaded();
			actualContent.add(webActions.getText(lbl_FacilityiPAS, "Facility"));
			actualContent.add(webActions.getText(lbl_DepartmentiPAS, "Department"));
			report.reportInfo("Displayed data on the iPAS header: "+actualContent);
			ArrayList<String>unmatchedColumnNames=webActions.getUmatchedInArrayComparision(actualContent, expectedContent);
			if(unmatchedColumnNames.size()==0){
				report.reportPass("Verified data at iPAS header successfully");
			}
			else{
				throw new Exception("Fail to verify data at iPAS header and unmatched data is : "+unmatchedColumnNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyApplyBtn(){
		try {
			webActions.waitForPageLoaded();
			webActions.assertDisplayed(Btn_AccountApplyBtn, "ApplyButton");
			report.reportPass("Apply button is displayed on Account Search Page");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
