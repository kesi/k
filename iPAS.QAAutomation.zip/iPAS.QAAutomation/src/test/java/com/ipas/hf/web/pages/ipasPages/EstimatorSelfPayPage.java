package com.ipas.hf.web.pages.ipasPages;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.server.handler.GetAlertText;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class EstimatorSelfPayPage extends BasePage {

	private JSONObject jsonObject;
	private static final String EstimatorSelfPay = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\EstimatorSelfPay.json";
	private StepLogging log = StepLogging.getLoggingObject();

	@FindBy(linkText="Estimator")
	public WebElement lnk_Estimator;

	@FindBy(xpath="//button[text()='Confirm']")
	private WebElement btn_Confirm;

	@FindBy(xpath="//button[text()='Save']")
	private WebElement btn_Save;

	@FindBy(xpath="//ejs-numerictextbox[@formcontrolname='copay']/span/input[1]")
	private WebElement txt_Copay;

	@FindBy(xpath="//ejs-numerictextbox[@formcontrolname='deductible']/span/input[1]")
	private WebElement txt_Deductible;

	@FindBy(xpath="//ejs-numerictextbox[@formcontrolname='coinsurance']/span/input[1]")
	private WebElement txt_Coinsurance;

	@FindBy(xpath="//div[@class='form-body']/div[1]//a")
	public WebElement lnk_1stCPTCodeEdit;

	@FindBy(xpath="//div[@class='form-body']/div[1]//img")
	private WebElement btn_1stCPTCodeDelete;

	@FindBy(linkText="Add New CPT")
	private WebElement lnk_AddNewCPT;

	@FindBy(xpath="//ejs-textbox[@id='search_text']//input")
	private WebElement txt_CPTSearch;

	@FindBy(xpath="//button[@class='btn btn-primary']")
	private WebElement btn_Save_CPT;


	@FindBy(xpath="(//table[@class='e-table'])[3]/tbody/tr[1]/td[1]")
	private WebElement tr_CPTRow;

	String tr_CPTCode="//td[contains(text(),'";
	String tr_CPTCode1="')]";

	@FindBy(xpath="(//table[@class='e-table']//ejs-radiobutton)[1]//span")
	private WebElement rd_CPTCode;

	@FindBy(xpath="//div[@class='form-body']/div/div//span")
	private List<WebElement> lbl_Amounts;

	@FindBy(xpath="(//ejs-numerictextbox[@max='9999999.99'])[1]/span/input[1]")
	private WebElement lbl_EstimatedAllowableAmount;

	@FindBy(xpath="//div[@class='totalResponsibility']/div[2]")
	public WebElement lbl_TotalResponsibility;

	@FindBy(xpath="//button[contains(text(),'Send To Payment Facilitator')]")
	private WebElement btn_SendToPaymentFacilitator;

	@FindBy(xpath="//button[text()='New Estimate']")
	private WebElement btn_NewEstimate;

	@FindBy(xpath="//button[text()='All Estimates']")
	private WebElement btn_AllEstimates;

	@FindBy(xpath="(//div[@class='title']/span)[4]") //(//div[@class='title'])[6]/span[2]
	public WebElement lbl_EstimateID;

	@FindBy(xpath="//div[@class='notrun']/span")
	private List<WebElement> lbl_LastRanInfo;

	@FindBy(xpath="//div[@id='last-run-info']/span")
	private List<WebElement> lbl_LastRanInfo_ShortPanel;

	@FindBy(xpath="//div[@class='estimatedDataArea']/div[1]/span")
	private List<WebElement> lbl_Names_ShortPanel;

	@FindBy(xpath="//div[@class='estimatedDataArea']/div[2]")
	private WebElement lbl_Amount_ShortPanel;

	@FindBy(xpath="//ejs-dropdownlist[@id='estimateDiscount']/span/input")
	private WebElement dd_EstimateDiscount;

	@FindBy(xpath="//ipas-estimator-short-pannel//financial-clearance-status/img")
	private WebElement lbl_FinancialClearance_ShortPanel;		

	@FindBy(xpath="(//financial-clearance-status)[2]/img")
	private WebElement lbl_FinancialClearance;

	@FindBy(xpath="(//table[@class='e-table']/tbody)[4]/tr[1]/td")
	private List <WebElement> lbl_HitoryEstimate;	

	@FindBy(xpath="(//table[@class='e-table']/tbody)[4]/tr[1]")
	private WebElement tr_HitoryEstimate;

	@FindBy(xpath="(//table[@class='e-table']/tbody)[4]/tr[2]")
	private WebElement tr_HitoryEstimate2;

	@FindBy(xpath="(//table[@class='e-table']/tbody)[4]/tr[2]/td[1]")
	private WebElement lbl_EstimateId_History;

	@FindBy(xpath="//div[@class='notrun']/span[1]")
	private WebElement lbl_LastRanInfo_Status;	

	@FindBy(xpath="//div[@class='notrun']/span[3]")
	private WebElement lbl_LastRanInfo_Employee;

	@FindBy(xpath="//div[@class='notrun']/span[4]")
	private WebElement lbl_LastRanInfo_DateTime;

	@FindBy(xpath="//img[contains(@class,'note-icon')]")
	private WebElement btn_AddNote_Icon;

	@FindBy(xpath="//td[contains(text(),'No records to display')]")
	public WebElement lbl_NoRecords;

	@FindBy(xpath="//button[contains(text(),'Add Note')]")
	private WebElement btn_AddNote;

	@FindBy(xpath="//button[@title='Close']")
	private WebElement btn_Close_AddNote;

	@FindBy(xpath="//ejs-textbox[@maxlength='250']//textarea")
	private WebElement txt_Notes;

	@FindBy(xpath="(//table[@class='e-table'])[4]//tr[1]/td")
	private List<WebElement> lbl_NoteData;

	@FindBy(xpath="(//table[@class='e-table'])[2]//tr[1]/td")
	private List<WebElement> lbl_NoteData_ShortPanel;

	@FindBy(xpath="//a[text()='Add New CPT']/..")
	private WebElement btn_AddNewCPT_Disabled;

	@FindBy(linkText="Patient Responsibility Estimator")
	private WebElement lnk_PatientResponsibilityEstimator;

	@FindBy(xpath="//img[@src='assets/images/benifitImages/gotoeligibility.PNG']")
	private WebElement lnk_GotoEligibility;

	@FindBy(xpath="//p[@class='title d-flex']")
	private WebElement lbl_Eligibility;

	@FindBy(xpath="(//a[text()='Account Search'])[1]")
	private WebElement lnk_AccountSearch;
	
	@FindBy(xpath="//div[@class='col beforeDiscountArea']/div[2]")
	private WebElement lbl_BeforeDiscount;
	
	@FindBy(xpath="//div[@class='col patientTotal']/div[2]")
	private WebElement lbl_PatientTotal;

	private RestActions rest = new RestActions();
	PaymentFacilitatorPage payment=new PaymentFacilitatorPage();
	Login login=new Login();
	PayerContractsPage pcp=new PayerContractsPage();

	public EstimatorSelfPayPage() {
		PageFactory.initElements(driver, this);
	}

	public void navigateAllDataPage(){
		try {
			String accountNumber=getDataFromJSONFile("AccountNumber");
			payment.searchAccountNuberinAccountSearchPage(accountNumber);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			try {
				webActions.waitForVisibility(lnk_Estimator, "Estimator", 15);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
			}
		} catch (Exception e) {

		}
	}

	public void navigateEstimatorFullpage(){
		navigateAllDataPage();
		webActions.waitAndClick(lnk_Estimator, "Estimator");
		try {
			webActions.waitForVisibility(lnk_1stCPTCodeEdit, "CPT Code", 20);
			webActions.waitForPageLoaded();
		} catch (Exception e) {
		}
	}

	public void navigatePaymentFacilitatorPage(){
		try {
			navigateAllDataPage();
			webActions.waitAndClick(payment.lnk_PaymentFacilitator, "Payment Facilitator");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			payment.waitforPaymentFacilitatorPage();
		} catch (Exception e) {
		}
	}

	public void navigateToEstimateFromPaymentFacilitator(){
		try {
			String accountNumber=getDataFromJSONFile("AccountNumber");
			driver.findElement(By.linkText(accountNumber)).click();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			try {
				webActions.waitForVisibility(lnk_Estimator, "Estimator", 15);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
			}
			webActions.click(lnk_Estimator, "Estimator");
			try {
				webActions.waitForVisibility(lnk_1stCPTCodeEdit, "CPT Code", 20);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
			}
		} catch (Exception e) {
		}
	}



	public void verifyEstimatePageforSelfPay(){
		try {
			ArrayList<String> actData=new ArrayList<>();
			actData.add(webActions.getAttributeValue(txt_Copay, "disabled", "Copay"));
			actData.add(webActions.getAttributeValue(txt_Deductible, "disabled", "Deductible"));
			actData.add(webActions.getAttributeValue(txt_Coinsurance, "disabled", "Coinsurance"));
			actData.add(webActions.getAttributeValue(btn_Save, "disabled", "Save"));
			actData.add(webActions.getAttributeValue(btn_Confirm, "disabled", "Confirm"));

			ArrayList<String> unmatch=webActions.isFullArrayMatchWithData(actData, "true");
			if(unmatch.size()==0){
				report.reportPass("Successfully verified Copay Deductible CoInsurance Fields are in the disabled mode for Self Pay");
			}else{
				report.reportFail("Copay Deductible CoInsurance Fields are not in the disabled mode for Self Pay");
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}


	public void editCPTCode(){
		try {
			webActions.click(lnk_1stCPTCodeEdit, "Edit CPT");
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibility(rd_CPTCode, "CPT Code", 30);
			} catch (Exception e) {
			}
			webActions.waitAndClick(rd_CPTCode, "CPT Code");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitUntilEnabledAndClick(btn_Save_CPT, "Save");
			waitForPageLoade(3);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void deleteCPTCode(){
		try {
			webActions.click(btn_1stCPTCodeDelete, "Delete CPT");
			String actAlertMsg=pcp.getAlertMessage();
			waitForPageLoade(2);
			if("Deleted successfully.".contains(actAlertMsg)){
				report.reportPass("Alert message matched and CPT deleted successfully");
				webActions.waitForLoad();
			}else{
				report.reportFail("Alert message is not matched CPT not deleted successfully",true);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void addCPTCode(DataTable testData){
		try {
			ArrayList<String> cpts=new ArrayList<String>(testData.asList());
			for (String cptCode : cpts) {
				webActions.waitForLoad();
				webActions.waitAndClick(lnk_AddNewCPT, "CPT Code");
				webActions.waitForLoad();
				webActions.waitForVisibility(txt_CPTSearch, "CPT Search", 10);
				webActions.click(txt_CPTSearch, "CPT Search");
				waitForPageLoade(2);
				webActions.sendKeys(txt_CPTSearch, cptCode, "CPT Searchs");
				waitForPageLoade(5);
				driver.findElement(By.xpath(tr_CPTCode+cptCode+tr_CPTCode1)).click();
				webActions.waitForLoad();
				webActions.waitForVisibility(rd_CPTCode, "CPT Code", 10);
				webActions.waitAndClick(rd_CPTCode, "CPT Code");
				webActions.waitForLoad();
				webActions.waitForJSandJQueryToLoad();
				webActions.waitUntilEnabledAndClick(btn_Save_CPT, "Save");
				String actAlertMsg=pcp.getAlertMessage();
				if("Data saved successfully.".contains(actAlertMsg)){
					report.reportPass("Alert message matched and CPT added successfully");
					webActions.waitForLoad();
				}else{
					report.reportFail("Alert message is not matched CPT not added successfully",true);
				}
			}
			waitForPageLoade(5);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyMultiProcedureDiscounting(DataTable testData){
		try {
			ArrayList<Double> actAmounts=getCPTCodeAmounts();
			double ChargeAmount, AllowableAmount = 0;
			Integer ofCharges=getIntValuefromMap(testData, "of Charges");
			int second=getIntValuefromMap(testData, "Second Procedure Pays At");
			int third=getIntValuefromMap(testData, "Third Procedure Pays At");
			int additional=getIntValuefromMap(testData, "Additional Procedure Pays At");
			for (int i = 0; i < actAmounts.size(); i++) {
				if(i==0){
					ChargeAmount=actAmounts.get(i);
					double ActualAllowableAmount=ChargeAmount*ofCharges/100;
					AllowableAmount=ChargeAmount-ActualAllowableAmount;
				}
				if(i==1){
					ChargeAmount=actAmounts.get(i);
					double ActualAllowableAmount=ChargeAmount*ofCharges/100;
					ActualAllowableAmount=ChargeAmount-ActualAllowableAmount;
					double SecondProcedure=ActualAllowableAmount*second/100;
					AllowableAmount+=ActualAllowableAmount-SecondProcedure;
				}
				if(i==2){
					ChargeAmount=actAmounts.get(i);
					double ActualAllowableAmount=ChargeAmount*ofCharges/100;
					ActualAllowableAmount=ChargeAmount-ActualAllowableAmount;
					double SecondProcedure=ActualAllowableAmount*third/100;
					AllowableAmount+=ActualAllowableAmount-SecondProcedure;
				}
				if(i>=3){
					ChargeAmount=actAmounts.get(i);
					double ActualAllowableAmount=ChargeAmount*ofCharges/100;
					ActualAllowableAmount=ChargeAmount-ActualAllowableAmount;
					double SecondProcedure=ActualAllowableAmount*additional/100;
					AllowableAmount+=ActualAllowableAmount-SecondProcedure;
				}
			}
			DecimalFormat df = new DecimalFormat("#,##0.00");
			String calculatedAmount=df.format(AllowableAmount);
			report.reportInfo("Expected Estimated Allowable Amount by Calculations: "+calculatedAmount);
			String estimatedAllowableAmount=webActions.getAttributeValue(lbl_EstimatedAllowableAmount,"aria-valuenow", "EstimatedAllowableAmount");
			double estimatedAllowableAmt=Double.parseDouble(estimatedAllowableAmount);
			estimatedAllowableAmount = df.format(estimatedAllowableAmt);
			report.reportInfo("Actual Estimated Allowable Amount from Application: "+estimatedAllowableAmount);
			if(calculatedAmount.contentEquals(estimatedAllowableAmount)){
				report.reportPass("Successfully verified the Estimated Allowable Amount when apply Multi Procedure Discounting");
			}else{
				report.reportFail("Fail verify the Estimated Allowable Amount when apply Multi Procedure Discounting");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}


	public void saveEstimate(){
		try {
			webActions.click(btn_Save, "Save");
			String actAlertMsg=pcp.getAlertMessage();
			waitForPageLoade(3);
			if("Estimator saved successfully".contains(actAlertMsg)){
				report.reportPass("Alert message matched and Estimator saved successfully: "+actAlertMsg);
			}else{
				report.reportFail("Alert message is not matched and Estimator not saved successfully: "+actAlertMsg);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void confirmEstimate(){
		try {
			webActions.click(btn_Confirm, "Confirm");
			String actAlertMsg=pcp.getAlertMessage();
			if("Estimator confirmed successfully".contains(actAlertMsg)){
				report.reportPass("Alert message matched and Estimator confirmed successfully: "+actAlertMsg);
				webActions.waitForLoad();
			}else{
				report.reportFail("Alert message is not matched and Estimator not confirmed successfully: "+actAlertMsg,true);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void clickNewEstimate(){
		try {
			try {
				webActions.waitForVisibility(btn_NewEstimate, "New Estimate", 20);
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_NewEstimate, "New Estimate");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void clickAllEstimates(){
		try {
			webActions.click(btn_AllEstimates, "AllEstimates");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void sendToPayementFacilitatorAndVerifyPaymentDetails(){
		try {
			waitForPageLoade(5);
			webActions.click(btn_SendToPaymentFacilitator, "SendToPaymentFacilitator");
			String actAlertMsg=pcp.getAlertMessage();
			if("Send to payment facilitator successfully".contains(actAlertMsg)){
				report.reportPass("Alert message matched and Send to payment facilitator successfully: "+actAlertMsg);
				webActions.waitForLoad();
			}else{
				report.reportFail("Alert message is not matched and Send to payment facilitator not successfully: "+actAlertMsg);
			}
			boolean btnDisplay = false;
			try {
				waitForPageLoade(3);
				btnDisplay=webActions.isDisplayed(btn_SendToPaymentFacilitator, "SendToPaymentFacilitator");
			} catch (Exception e) {
			}
			if(btnDisplay==false){
				report.reportPass("Send to Payment Facilitator is not displayed after successfully send");
			}else{
				report.reportFail("Send to Payment Facilitator is displaying after successfully send");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}

	public void VerifyEstimateAmountinPaymentFacilitator(){
		try {
			StringBuilder verify=new StringBuilder();
			String accountNumber=getDataFromJSONFile("AccountNumber");
			String totalResponsibility=webActions.waitAndGetText(lbl_TotalResponsibility, "TotalResponsibility");
			driver.findElement(By.linkText(accountNumber)).click();

			ArrayList<String> actLabelNames=payment.getActualLabelNamesinPanel();
			ArrayList<String> expLabelNames=getExpectedLabelNamesinPanel();
			ArrayList<String> unmatchLabels=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchLabels.size()==0){
				report.reportPass("Label names matched successfully in Panel: "+actLabelNames);
			}else{
				report.reportFail("Label names are not matched in Panel: "+unmatchLabels,true);
				verify.append("Label names are not matched in Panel");
			}

			ArrayList<String> actAmounts=payment.getActualAmountsinPanel();
			ArrayList<String>expAmounts=getExpectedAmountsinPanel(totalResponsibility);
			report.reportInfo("Expected Payment Amounts in panel: "+expAmounts);
			report.reportInfo("Actual Payment Amounts in panel: "+actAmounts);
			ArrayList<String> unmatchAmounts=webActions.getUmatchedInArrayComparision(actAmounts, expAmounts);
			if(unmatchAmounts.size()==0){
				report.reportPass("Payment Amounts matched successfully in Panel: "+actAmounts);
			}else{
				report.reportFail("Payment Amounts not matched in Panel: "+unmatchAmounts,true);
				verify.append("Payment Amounts not matched in Panel");
			}

			String actaulFCPFStatus=payment.getActualFinancialClearanceStatusinPanel();
			if(actaulFCPFStatus.contains("error")){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Panel");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Panel",true);
				verify.append("Failed to verify the Financial Clearance Status in Payment Facilitator Panel");
			}

			webActions.waitAndClick(payment.lnk_PaymentFacilitator, "Payment Facilitator");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			payment.waitforPaymentFacilitatorPage();
			ArrayList<String> actAmountsPaymentFacilitator=getActualAmountsAfterSavePayment();
			ArrayList<String> expAmountsPaymentFacilitator=getExpectedAmountsAfterSavePayment(totalResponsibility);
			report.reportInfo("Expected amounts 'Adjusted Amount' 'Paid' 'Remaining Balance' in the Payment Facilitator page: "+expAmountsPaymentFacilitator);
			report.reportInfo("Actual amounts 'Adjusted Amount' 'Paid' 'Remaining Balance' in the Payment Facilitator page: "+actAmountsPaymentFacilitator);
			ArrayList<String> unmatchAmountsPaymentFacilitatorPage=webActions.getUmatchedInArrayComparision(actAmountsPaymentFacilitator, expAmountsPaymentFacilitator);
			if(unmatchAmounts.size()==0){
				report.reportPass("Saved Payment Amounts matched successfully in Payment Facilitator page: "+actAmountsPaymentFacilitator);
			}else{
				report.reportFail("Saved Payment Amounts are not matched in Payment Facilitator page: "+unmatchAmountsPaymentFacilitatorPage,true);
				verify.append("Saved Payment Amounts are not matched in Payment Facilitator page:");
			}

			String actFinClearStatus=payment.getFinClearStatusinPaymentFacilitatorPage();
			if(actFinClearStatus.contains("error")){
				report.reportPass("Successfully verifed the Financial Clearance Status after save in Payment Facilitator Page");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status after save in Payment Facilitator Page",true);
				verify.append("Failed to verify the Financial Clearance Status after save in Payment Facilitator Page");
			}

			if(verify.length()!=0){
				report.reportFail(""+verify);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}


	}

	public ArrayList<String> getExpectedLabelNamesinPanel(){
		ArrayList<String>expLabelNames=new ArrayList<String>();
		expLabelNames.add("Estimate");
		expLabelNames.add("Amount Collected");
		expLabelNames.add("Remaining Balance"); 
		report.reportInfo("Expected label names in panel: "+expLabelNames);
		return expLabelNames;
	}

	public ArrayList<String> getExpectedAmountsinPanel(String totalResponsibility){
		ArrayList<String>expAmounts=new ArrayList<String>();
		expAmounts.add(totalResponsibility);
		expAmounts.add("0.00");
		expAmounts.add(totalResponsibility);
		report.reportInfo("Expected Amounts in panel: "+expAmounts);
		return expAmounts;
	}

	public ArrayList<String> getActualAmountsAfterSavePayment(){
		ArrayList<String>actSavedAmounts=new ArrayList<String>();
		payment.waitforFCStatusChange();
		actSavedAmounts.add(webActions.getAttributeValue(payment.dd_PaymentType,"value", "Adjusted Amount"));
		actSavedAmounts.add(webActions.getAttributeValue(payment.txt_TotalAmount,"value","Adjusted Amount"));
		actSavedAmounts.add(webActions.waitAndGetText(payment.txt_AdjustedAmount, "Adjusted Amount"));
		actSavedAmounts.add(webActions.waitAndGetText(payment.txt_Paid, "Paid"));
		actSavedAmounts.add(webActions.waitAndGetText(payment.txt_RemainingBalance, "Remaining Balance"));
		return actSavedAmounts;
	}

	public ArrayList<String> getExpectedAmountsAfterSavePayment(String totalResponsibility){
		ArrayList<String>expSavedAmounts=new ArrayList<String>();
		expSavedAmounts.add("Estimate");
		expSavedAmounts.add(totalResponsibility);
		expSavedAmounts.add(totalResponsibility);
		expSavedAmounts.add("0.00");
		expSavedAmounts.add(totalResponsibility);
		return expSavedAmounts;
	}

	public ArrayList<Double> getCPTCodeAmounts(){
		ArrayList<Double> data= new ArrayList<Double>();
		try {
			webActions.waitForPageLoaded();
			List<WebElement> allElement = lbl_Amounts;
			for (WebElement we: allElement) { 
				String txt=we.getText().replaceAll("[$,]", "");
				String[] splited = txt.split("\\s+");
				txt=splited[0];
				data.add(Double.valueOf(txt));
			}
			Collections.sort(data);
			Collections.reverse(data);
			report.reportInfo("CPT Amounts: "+data);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
		return data;
	}

	public void verifysendToPayementFacilitatorButton(){
		try {
			waitForPageLoade(5);
			boolean btnDisplay = false;
			try {
				waitForPageLoade(3);
				btnDisplay=webActions.isDisplayed(btn_SendToPaymentFacilitator, "SendToPaymentFacilitator");
			} catch (Exception e) {
			}
			if(btnDisplay==false){
				report.reportPass("Send to payment facilitator is not displayed when Patient visit having PatientResponsibilityEstimate amount");
			}else{
				report.reportFail("Send to payment facilitator is displaying if Patient visit having PatientResponsibilityEstimate amount");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyEstimateHistory(DataTable testData){
		try {
			String discount=webActions.getDatafromMap(testData, "Discount");
			waitForPageLoade(50);
			webActions.sendKeys(dd_EstimateDiscount,discount, "EstimateDiscount");
			String status=webActions.getDatafromMap(testData, "Status");
			if ("Pending".contentEquals(status)) {
				saveEstimate();
			}else{
				confirmEstimate();
			}
			ArrayList<String> expData=new ArrayList<String>();
			waitForPageLoade(5);
			expData.add(webActions.getAttributeValue(lbl_FinancialClearance, "src", "FinancialClearance"));
			List<WebElement> list = lbl_LastRanInfo;
			for (WebElement we: list) { 
				String txt=we.getText();
				if(!txt.isEmpty()){
					expData.add(txt);
				}
			}
			expData.add("Estimate");
			expData.add(discount);
			expData.add(webActions.waitAndGetText(lbl_TotalResponsibility, "TotalResponsibility"));
			driver.findElement(By.linkText(getDataFromJSONFile("AccountNumber"))).click();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			try {
				webActions.waitForVisibility(lnk_Estimator, "Estimator", 15);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
			}
			ArrayList<String> actData=new ArrayList<String>();
			actData.add(webActions.getAttributeValue(lbl_FinancialClearance_ShortPanel, "src", "FinancialClearance"));
			List<WebElement> listShort = lbl_LastRanInfo_ShortPanel;
			for (WebElement we: listShort) { 
				String txt=we.getText();
				if(!txt.isEmpty()){
					actData.add(txt);
				}
			}
			List<WebElement> listShortNames = lbl_Names_ShortPanel;
			for (WebElement we: listShortNames) { 
				String txt=we.getText();
				if(!txt.isEmpty()){
					actData.add(txt);
				}
			}
			actData.add(webActions.getText(lbl_Amount_ShortPanel, "Amount"));
			report.reportInfo("Expected data from long panel: "+expData);
			report.reportInfo("Actual data from Short panel: "+actData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Estimate History: "+actData);
			}else{
				report.reportFail("Failed to verify the Estimate History: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void switchToEstimateHistory(DataTable testData){
		try {
			waitForPageLoade(50);
			String status=webActions.getDatafromMap(testData, "Status");
			if ("Pending".contentEquals(status)) {
				saveEstimate();
			}else{
				confirmEstimate();
			}
			ArrayList<String> expData=new ArrayList<String>();
			waitForPageLoade(5);
			String id=webActions.waitAndGetText(lbl_EstimateID, "EstimateID");
			id=id.substring(0, id.length()-1).trim();
			expData.add(id);
			expData.add(webActions.waitAndGetText(lbl_LastRanInfo_DateTime, "DateTime"));
			String employee=webActions.waitAndGetText(lbl_LastRanInfo_Employee, "Employee");
			employee=employee.substring(12, employee.length());
			expData.add(employee);
			expData.add(webActions.waitAndGetText(lbl_LastRanInfo_Status, "Status"));
			webActions.click(btn_AllEstimates, "All Estimate");
			webActions.waitAndGetText(tr_HitoryEstimate, "HitoryEstimate");
			ArrayList<String> actData=new ArrayList<>();
			List<WebElement> list=lbl_HitoryEstimate;
			for (int i = 0; i < list.size(); i++) {
				String txt=list.get(i).getText();
				if(i==1){
					String txt1=txt.substring(0, 16);
					String d=txt.substring(20, 22);
					String[]a=txt1.split(" ");
					String b=a[0];
					String c=a[1];
					txt=b+", "+c+" "+d;
				}
				actData.add(txt);
			}
			report.reportInfo("Expected data from long panel: "+expData);
			report.reportInfo("Actual data from Estimate History popup window: "+actData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Estimate History popup window: "+actData);
			}else{
				report.reportFail("Failed to verify the Estimate History popup window: "+unmatch);
			}

			String estimateId_History=webActions.waitAndGetText(lbl_EstimateId_History, "EstimateId_History");
			webActions.click(lbl_EstimateId_History, "EstimateId_History");
			waitForPageLoade(5);
			String estimateId=webActions.waitAndGetText(lbl_EstimateID, "EstimateID");
			estimateId=estimateId.substring(0, id.length()-1).trim();
			if(estimateId_History.contains(estimateId)){
				report.reportPass("Successfully switch To Estimate History: "+estimateId_History);
			}else{
				report.reportFail("Fail to switch To Estimate History: "+estimateId);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyNoRecordsAddNoteWindow(){
		try {
			webActions.click(btn_AddNote_Icon, "Add Note Icon");
			String actMessage=webActions.waitAndGetText(lbl_NoRecords, "No Records");
			if("No records to display".contentEquals(actMessage)){
				report.reportPass("Successfully verified the message when note is not added: "+actMessage);
				webActions.click(btn_Close_AddNote, "Close");
			}else{
				report.reportFail("Failed to verify the message when note is not added: "+actMessage);
				webActions.click(btn_Close_AddNote, "Close");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void addAndViewNotesforEstimate(DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			waitForPageLoade(3);
			webActions.click(btn_AddNote_Icon, "Add Note Icon");
			webActions.waitForVisibility(lbl_NoRecords, "No Records", 10);
			String note=webActions.getDatafromMap(testData, "Note");
			webActions.sendKeys(txt_Notes, note+" Full Page", "Notes text");
			webActions.click(btn_AddNote, "Add Note");
			String actAlertMsg=pcp.getAlertMessage();
			waitForPageLoade(2);
			if("Note created successfully.".contains(actAlertMsg)){
				report.reportPass("Alert message is matched when Note is added from the full page");
				webActions.waitForLoad();
			}else{
				report.reportFail("Alert message is not matched when Note is added from the full page: "+actAlertMsg,true);
				verify.append("Alert message is not matched when Note is added from the full page");
			}

			ArrayList<String>expData=new ArrayList<>();
			expData.add(note+" Full Page");
			expData.add(webActions.getDatafromMap(testData, "Operator"));
			expData.add(webActions.getCurrentSystemDateTime());
			report.reportInfo("Expected note details added from full page: "+expData);

			ArrayList<String>actData=getNoteDetailsinFullPage();
			report.reportInfo("Actual note details added from full page: "+actData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the note details in the full page");
				webActions.click(btn_Close_AddNote, "Close Note");
			}else{
				report.reportFail("Failed to verify the note details in the full page: "+unmatch,true);
				webActions.click(btn_Close_AddNote, "Close Note");
				verify.append("Failed to verify the note details in the full page");
			}
			String accountNumber=getDataFromJSONFile("AccountNumber");
			//waitForPageLoade(3);
			driver.findElement(By.linkText(accountNumber)).click();
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_AddNote_Icon, "Note Icon",10);
			webActions.click(btn_AddNote_Icon, "Note Icon");
			webActions.waitForPageLoaded();
			waitForPageLoade(3);
			ArrayList<String>actData_ShortPanel=getNoteDetailsinShortPanel();
			report.reportInfo("Actual Note details in Short panel which is added from Full page: : "+actData_ShortPanel);
			ArrayList<String>unmatch_ShortPanel=webActions.getUmatchedInArrayComparision(actData_ShortPanel, expData);
			if(unmatch_ShortPanel.size()==0){
				report.reportPass("Successfully verified the note details in short panel wich is added in Full page");
			}else{
				report.reportFail("Failed to verify the note details in short panel wich is added in Full page: "+unmatch_ShortPanel,true);
				verify.append("Failed to verify the note details in short panel wich is added in Full page");
			}
			webActions.sendKeys(txt_Notes, note+" Short Panel", "Notes text");

			webActions.click(btn_AddNote, "Add Note");
			String actAlertMsgShortPanel=pcp.getAlertMessage();
			waitForPageLoade(2);
			if("Note created successfully.".contains(actAlertMsgShortPanel)){
				report.reportPass("Alert message is matched when Note is added from the short panel");
				webActions.waitForLoad();
			}else{
				report.reportFail("Alert message is not matched when Note is added from the short panel: "+actAlertMsgShortPanel,true);
				verify.append("Alert message is not matched when Note is added from the short panel");
			}

			ArrayList<String>expData_ShortPanelAdded=new ArrayList<>();
			expData_ShortPanelAdded.add(note+" Short Panel");
			expData_ShortPanelAdded.add(webActions.getDatafromMap(testData, "Operator"));
			expData_ShortPanelAdded.add(webActions.getCurrentSystemDateTime());
			report.reportInfo("Expected note details added from short panel: "+expData_ShortPanelAdded);
			ArrayList<String>actData_ShortPanelAdded=getNoteDetailsinShortPanel();
			report.reportInfo("Actual note details added from Short panel: "+actData_ShortPanelAdded);

			ArrayList<String>unmatch_ShortPanelAdded=webActions.getUmatchedInArrayComparision(actData_ShortPanelAdded, expData_ShortPanelAdded);
			if(unmatch_ShortPanelAdded.size()==0){
				report.reportPass("Successfully verified the note details in short panel wich is added in short panel");
				webActions.click(btn_Close_AddNote, "Close Note");
			}else{
				report.reportFail("Failed to verify the note details in short panel wich is added in short panel"+unmatch_ShortPanelAdded,true);
				webActions.click(btn_Close_AddNote, "Close Note");
				verify.append("Failed to verify the note details in short panel wich is added in short panel");
			}
			webActions.waitForPageLoaded();
			webActions.click(lnk_Estimator, "Estimator");
			try {
				webActions.waitForVisibility(lnk_1stCPTCodeEdit, "CPT Code", 20);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
			}
			webActions.click(btn_AddNote_Icon, "Add Note Icon");
			waitForPageLoade(3);
			ArrayList<String>actDataFullPage=getNoteDetailsinFullPage();
			report.reportInfo("Actual note details in full page which is added from short panel: "+actDataFullPage);

			report.reportInfo("Expected note details added from full page: "+expData_ShortPanelAdded);
			ArrayList<String>unmatchFullPage=webActions.getUmatchedInArrayComparision(actDataFullPage, expData_ShortPanelAdded);
			if(unmatchFullPage.size()==0){
				report.reportPass("Successfully verified the note details in the full page which is added in short panel");
			}else{
				report.reportFail("Failed to verify the note details in the full page which is added in short panel: "+unmatchFullPage,true);
				verify.append("Failed to verify the note details in the full page which is added in short panel: ");
			}
			if(verify.length()!=0)
			{
				report.reportFail(""+verify);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifytheEstimatorWorkSheetforConfirmedStatus(){
		try {
			webActions.click(btn_Close_AddNote, "Colse");
			StringBuffer verify=new StringBuffer();
			waitForPageLoade(1);
			String expButtonStatus="isDisabled";
			String actEditCPT=webActions.getAttributeValue(lnk_1stCPTCodeEdit, "class", "Edit CPT Code");
			if(expButtonStatus.contentEquals(actEditCPT)){
				report.reportPass("Successfully Verified the Edit CPT button is in the Disabled mode for Confirmed Estimate");
			}else{
				report.reportFail("Fail to verify the Edit CPT button is in Disabled mode for Confirmed Estimate",true);
				verify.append("Fail to verify the Edit CPT button is in Disabled mode for Confirmed Estimate");
			}
			String actDeleteCPT=webActions.getAttributeValue(btn_1stCPTCodeDelete, "class", "Delete CPT Code");
			if(actDeleteCPT.contains(expButtonStatus)){
				report.reportPass("Successfully Verified the Delete CPT button is in the Disabled mode for Confirmed Estimate");
			}else{
				report.reportFail("Fail to verify the Delete CPT button is in Disabled mode for Confirmed Estimate",true);
				verify.append("Fail to verify the Delete CPT button is in Disabled mode for Confirmed Estimate");
			}
			String actAddNewCPT=webActions.getAttributeValue(btn_AddNewCPT_Disabled, "class", "Add new CPT Code");
			if(actAddNewCPT.contains(expButtonStatus)){
				report.reportPass("Successfully Verified the Add CPT button is in the Disabled mode for Confirmed Estimate");
			}else{
				report.reportFail("Fail to verify the Add CPT button is in Disabled mode for Confirmed Estimate",true);
				verify.append("Fail to verify the Add CPT button is in Disabled mode for Confirmed Estimate");
			}
			String actSaveButton=webActions.getAttributeValue(btn_Save, "disabled", "Save");
			if("true".contains(actSaveButton)){
				report.reportPass("Successfully Verified the Save button is in the Disabled mode for Confirmed Estimate");
			}else{
				report.reportFail("Fail to verify the Save button is in Disabled mode for Confirmed Estimate",true);
				verify.append("Fail to verify the Save button is in Disabled mode for Confirmed Estimate");
			}
			String actConfirmButton=webActions.getAttributeValue(btn_Confirm, "disabled", "Confirm");
			if("true".contains(actConfirmButton)){
				report.reportPass("Successfully Verified the Confirm button is in the Disabled mode for Confirmed Estimate");
			}else{
				report.reportFail("Fail to verify the Confirm button is in Disabled mode for Confirmed Estimate",true);
				verify.append("Fail to verify the Confirm button is in Disabled mode for Confirmed Estimate");
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void navigateToEstimateFromNeedsAttention(){
		try {
			StringBuilder unmatch=new StringBuilder();
			String accountNumber=getDataFromJSONFile("AccountNumber");
			login.simpleSearch(accountNumber);
			webActions.waitForPageLoaded();
			webActions.click(lnk_PatientResponsibilityEstimator, "Patient Responsibility Estimator");
			try {
				webActions.waitForVisibility(lnk_1stCPTCodeEdit, "CPT Code", 20);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
			}
			ArrayList<String> actualBreadcrumbTitles = webActions.getDatafromWebTable(payment.lbl_Breadcrum);

			ArrayList<String>expectedBreadcrumbTitles=new ArrayList<String>();
			expectedBreadcrumbTitles.add("Account Search");
			expectedBreadcrumbTitles.add("Estimator");
			ArrayList<String> unmatchBreadcrumb=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles, expectedBreadcrumbTitles);
			if(unmatchBreadcrumb.size()==0){
				report.reportPass("Successfully navigated to Estimator full page: "+actualBreadcrumbTitles);
			}else{
				report.reportFail("Failed to navigate to Estimator full page: "+unmatchBreadcrumb,true);
				unmatch.append("Failed to navigate to Estimator full page");
			}
			editCPTCode();
			confirmEstimate();
			webActions.waitForPageLoaded();
			waitForPageLoade(3);
			webActions.click(lnk_GotoEligibility, "Eligibility");
			
			String actEligibility=webActions.waitAndGetText(lbl_Eligibility, "Eligibility");
			if("Eligibility Verification".contains(actEligibility)){
				report.reportPass("Successfully verified the Eligibility page title: "+actEligibility);
			}else{
				report.reportFail("Fail to verify the Eligibility page title: "+actEligibility,true);
				unmatch.append("Fail to verify the Eligibility page title");
			}
			ArrayList<String> actualBreadcrumbTitles_Eligibility = webActions.getDatafromWebTable(payment.lbl_Breadcrum);
			expectedBreadcrumbTitles.add("Eligibility Verification");
			ArrayList<String> unmatchBreadcrumb_Eligibility=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles_Eligibility, expectedBreadcrumbTitles);
			if(unmatchBreadcrumb_Eligibility.size()==0){
				report.reportPass("Successfully navigated to Eligibility from Estimator page: "+actualBreadcrumbTitles_Eligibility);
			}else{
				report.reportFail("Failed to navigate Eligibility from Estimator page: "+unmatchBreadcrumb_Eligibility,true);
				unmatch.append("Failed to navigate Eligibility from Estimator page");
			}
			webActions.click(lnk_AccountSearch, "Account Search");
			waitForPageLoade(5);
			webActions.click(payment.lnk_NeedsAttention, "Needs Attention");
			waitForPageLoade(3);
			webActions.click(lnk_PatientResponsibilityEstimator, "Patient Responsibility Estimator");
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibility(lnk_1stCPTCodeEdit, "CPT Code", 20);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
			}
			ArrayList<String> actualBreadcrumbTitles_Estimate = webActions.getDatafromWebTable(payment.lbl_Breadcrum);

			ArrayList<String>expectedBreadcrumbTitles_Estimate=new ArrayList<String>();
			expectedBreadcrumbTitles_Estimate.add("Account Search");
			expectedBreadcrumbTitles_Estimate.add("Estimator");
			ArrayList<String> unmatchBreadcrumb_Estimate=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles_Estimate, expectedBreadcrumbTitles_Estimate);
			if(unmatchBreadcrumb_Estimate.size()==0){
				report.reportPass("Successfully navigated to Estimator full page from All Modules popup: "+actualBreadcrumbTitles_Estimate);
			}else{
				report.reportFail("Failed to navigate to Estimator full page from All Modules popup: "+unmatchBreadcrumb_Estimate,true);
				unmatch.append("Failed to navigate to Estimator full page from All Modules popup");
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
			
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void applyDiscounttoEstimateandSaveorConfirm(DataTable testData){
		try {
			String status=webActions.getDatafromMap(testData, "Status");
			String discount=webActions.getDatafromMap(testData, "Discount Name");
			waitForPageLoade(5);
			webActions.sendKeys(dd_EstimateDiscount,discount, "Estimate Discount");
			webActions.waitForPageLoaded();
			waitForPageLoade(1);
			if ("Pending".contentEquals(status)) {
				saveEstimate();
			}else{
				confirmEstimate();
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void calculateDiscountAmount(DataTable testData){
		try {
			applyDiscounttoEstimateandSaveorConfirm(testData);
			DecimalFormat df = new DecimalFormat("#,##0.00");
			StringBuffer unmatch=new StringBuffer();
			webActions.waitForPageLoaded();
			String discountType=webActions.getDatafromMap(testData, "Discount Type");
			String discountValue=webActions.getDatafromMap(testData, "Discount Value");
			String beforeDiscount= webActions.waitAndGetText(lbl_BeforeDiscount, "BeforeDiscount").replaceAll("[$,]", "");
			double estimateAfterDiscount;
			String expectedEstimatedPatientTotal = "";
			if("Dollar".contentEquals(discountType)){
				estimateAfterDiscount=getDoubleValue(beforeDiscount)-getDoubleValue(discountValue);
				expectedEstimatedPatientTotal = df.format(estimateAfterDiscount);
			}else {
				double discountPercentValue=getDoubleValue(beforeDiscount)*getDoubleValue(discountValue)/100;
				estimateAfterDiscount=getDoubleValue(beforeDiscount)-discountPercentValue;
				expectedEstimatedPatientTotal = df.format(estimateAfterDiscount);
			}
			report.reportInfo("Expected Calculated Estimate Amount After applying the discount with "+discountType +": "+expectedEstimatedPatientTotal);
			String estimatePatientTotal= webActions.waitAndGetText(lbl_PatientTotal, "Estimated Patient Total").replaceAll("[$,]", "");
			report.reportInfo("Actual Estimated Patient Total after applying the discount with "+discountType +": "+estimatePatientTotal);
			if(expectedEstimatedPatientTotal.contentEquals(estimatePatientTotal)){
				report.reportPass("Successfully verified the Estimated Patient Total after applying the discount with "+discountType);
			}else{
				report.reportFail("Fail to verify the Estimated Patient Total after applying the discount with "+discountType,true);
				unmatch.append("Fail to verify the Estimated Patient Total after applying the discount with "+discountType);
			}
			
			String totalPatientResponsibility= webActions.waitAndGetText(lbl_TotalResponsibility, "Total Patient Responsibility").replaceAll("[$,]", "");
			report.reportInfo("Actual Total Patient Responsibility after applying the discount with "+discountType +": "+totalPatientResponsibility);
			if(expectedEstimatedPatientTotal.contentEquals(totalPatientResponsibility)){
				report.reportPass("Successfully verified the Total Patient Responsibility after applying the discount with "+discountType);
			}else{
				report.reportFail("Fail to verify the Total Patient Responsibility after applying the discount with "+discountType,true);
				unmatch.append("Fail to verify the Total Patient Responsibility after applying the discount with "+discountType);
			}
			
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public double getDoubleValue(String amount){
		return Double.parseDouble(amount);
	}

	public ArrayList<String> getNoteDetailsinFullPage(){
		ArrayList<String>data=new ArrayList<>();
		List<WebElement> list=lbl_NoteData;
		for (int i = 0; i < list.size(); i++) {
			String txt=list.get(i).getText();
			if(i==2){
				String txt1=txt.substring(0, 16);
				String txt2=txt.substring(20, 22);
				txt=txt1+" "+txt2;
			}
			data.add(txt);
		}
		return data;
	}

	public ArrayList<String> getNoteDetailsinShortPanel(){
		ArrayList<String>data=new ArrayList<>();
		List<WebElement> list=lbl_NoteData_ShortPanel;
		for (int i = 0; i < list.size(); i++) {
			String txt=list.get(i).getText();
			if(i==2){
				String txt1=txt.substring(0, 16);
				String txt2=txt.substring(20, 22);
				txt=txt1+" "+txt2;
			}
			data.add(txt);
		}
		return data;
	}

	@SuppressWarnings("unchecked")
	public void updateEstimatorSelfPayJSON(String estimateAmount) throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(EstimatorSelfPay);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			try {
				String number = rest.getUniqueNumber();
				newNum = "A" + number;
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(0);
				tenantPatient.put("TenantPatientId", newNum);

				tenantPatient = (JSONObject) msg.get(3);
				tenantPatient.put("TenantPatientId", newNum);

				String test = (String) tenantPatient.get("TenantPatientId");	
			} catch (Exception e) {
				log.error("Failed to update tenant patiend id", e);
				e.printStackTrace();
			}
			try {
				visitObject.put("AccountNumber", newNum);
				visitObject.put("VisitNumber", newNum);
				Object tt = visitObject.get("VisitDate");
				String updatedDate = rest.updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);

			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}

			try {
				visitObject.put("PatientResponsibilityEstimate",estimateAmount);
			} catch (Exception e) {
				log.error("Failed to update PatientResponsibilityEstimate", e);
				e.printStackTrace();
			}

			FileWriter file = new FileWriter(EstimatorSelfPay);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}


	public String getDataFromJSONFile(String fieldName){
		String expectedResponseValue=null;
		try {
			FileReader reader = new FileReader(EstimatorSelfPay);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");

			if(fieldName.contentEquals("AccountNumber")){
				expectedResponseValue = (String) visitObject.get("AccountNumber");	
			}
		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return expectedResponseValue;
	}

	public void waitForPageLoade(int seconds){
		try {
			Thread.sleep(seconds*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public int getIntValuefromMap(DataTable testData,String keyName){
		String data=(String) testData.asMaps(String.class, String.class).get(0).get(keyName);
		return Integer.valueOf(data);
	}


	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
