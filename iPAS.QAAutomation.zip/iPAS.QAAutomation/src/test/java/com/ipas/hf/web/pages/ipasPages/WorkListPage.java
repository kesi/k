package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class WorkListPage extends BasePage{

	PatientVisitSummaryAllDataPanelPage visitSummary=new PatientVisitSummaryAllDataPanelPage();

	@FindBy(xpath="(//ejs-grid//tbody)[2]/tr")
	private WebElement lbl_AAGridData;

	@FindBy(xpath = "(//ejs-grid//tbody)[2]/tr/td[2]//a")
	private List<WebElement> tbl_AccountNumbers;

	@FindBy(xpath = "//ejs-tab//div[@class='e-tab-text']")
	private List<WebElement> tbl_WorkListTabs;

	@FindBy(xpath="//th[")
	private WebElement lbl_AAGridHeaders;

	@FindBy(xpath="//th[2]/div[3]")
	private WebElement lbl_AccountNumberFilter;

	@FindBy(xpath="//button[contains(text(),'Filter')]")
	private WebElement btn_Filter;

	@FindBy(xpath="//button[@data-toggle='dropdown']")
	private WebElement lnk_Dots;

	@FindBy(xpath="//div[@class='tools']/a")
	private WebElement lnk_Exportexcel;

	@FindBy(xpath="//button[contains(text(),'Clear')]")
	private WebElement btn_Clear;

	@FindBy(xpath="//span[@class='e-frame e-icons e-selectall e-check']")
	private WebElement chk_SelectAll;

	@FindBy(xpath="//div[@class='e-checkboxlist e-fields']/div[2]/div/span[1]")
	private WebElement chk_FirstRecord;

	@FindBy(xpath="//span[@class='e-frame e-icons e-selectall e-uncheck']")
	private WebElement chk_UnSelectAll;

	@FindBy(xpath="e-frame e-icons e-selectall e-stop")
	private WebElement chk_SelectAllAfter;

	@FindBy(xpath="//ejs-grid//input[@placeholder='Search']")
	private WebElement lbl_SearchBox;

	@FindBy(xpath="//span[contains(text(),'No Matches Found')]")
	private WebElement lbl_NoMatchMsg;

	@FindBy(xpath="//span[@title='Search']")
	private WebElement lbl_CrossOption;
	@FindBy(xpath="//div[@id='three']//app-ipas-document-management-pannel/ejs-accordion/div/div[2]/div/div/ul/li/div[1]")
	private List<WebElement> lbl_DigitalDocMangerPanel;

	@FindBy(xpath="//ejs-accordion/div[1]/div[2]/div/div/ul/li/div[2]")
	private WebElement lbl_DataInAllDataPanel;
	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[2]")
	private List<WebElement> lbl_VisitSummaryData;

	@FindBy(xpath="//tbody/tr[1]/td[2]//a")
	private WebElement lnk_AccountNumber;

	@FindBy(xpath="//ipas-breadcrumb//a")
	private WebElement lnk_WorkListBrd;

	@FindBy(xpath="//span[@class='ttlcount']")
	private WebElement lbl_AccountsCount;

	@FindBy(xpath="(//ejs-tab//div[@class='e-tab-text'])[2]")
	private WebElement btn_Challenge;

	@FindBy(xpath = "(//ejs-grid//tbody)[2]/tr/td[9]")
	private List<WebElement> tbl_ChallengeStatus;

	@FindBy(xpath="(//ejs-tab//div[@class='e-tab-text'])[3]")
	private WebElement btn_Eligibility;

	@FindBy(xpath="//tbody/tr[1]/td[1]//a")
	private WebElement lnk_AccountNumberEligibility;

	@FindBy(xpath = "(//ejs-grid//tbody)[2]/tr/td[1]//a")
	private List<WebElement> tbl_EligibilityAccountNumbers;

	@FindBy(xpath = "(//tbody/tr[1]/td[2])[2]")
	private WebElement tbl_ChallengeAccountNumbers;

	@FindBy(xpath="//th[1]/div[3]")
	private WebElement lbl_EligibilityNumberFilter;


	@FindBy(xpath="//a[contains(text(),'Worklists')]")
	private WebElement lnk_WorkList;

	@FindBy(linkText="Eligibility Verification")
	private WebElement lnk_Eligibility;

	@FindBy(xpath="//div[contains(@class,'e-tab-wrap')]")
	private List<WebElement> tabs_AllInsurances;

	@FindBy(xpath = "(//tbody/tr/td[1])[2]")
	private WebElement tbl_EligibilityAccountNumber;

	@FindBy(xpath = "(//div[contains(text(),'FAQ')])[1]")
	public WebElement btn_FAQ;
	
	@FindBy(xpath = "//tbody/tr[1]/td[4]/div")
	public WebElement lnk_AccountNo_FAQ;
	
	public WorkListPage() {
		PageFactory.initElements(driver, this);
	}
	public void verifyColumnNames(String page,DataTable columnNames) {
		ArrayList<String> expectedData = new ArrayList<>(columnNames.asList());
		ArrayList<String> actualPanelNames= new ArrayList<>();
		try {	

			if(page.contentEquals("AA")){							
				webActions.waitForPageLoaded();
				for(int i=2;i<=9;i++){
					String ele="//th["+i+"]"+"/div/span";
					WebElement element=driver.findElement(By.xpath(ele));
					actualPanelNames.add(webActions.getText(element, "Names"));
				}							

			}
			else if(page.contentEquals("Challenge")){
				webActions.waitForPageLoaded();				
				for(int i=2;i<=12;i++){
					String ele="//th["+i+"]"+"/div/span";
					WebElement element=driver.findElement(By.xpath(ele));
					actualPanelNames.add(webActions.getText(element, "Names"));
				}	
			}
			else if(page.contentEquals("Eligibility")){
				webActions.waitForPageLoaded();				
				for(int i=1;i<=14;i++){
					if(i==9 || i==11 || i==13){
						continue;
					}
					String ele="//th["+i+"]"+"/div/span";
					WebElement element=driver.findElement(By.xpath(ele));
					actualPanelNames.add(webActions.getText(element, "Names"));
				}	
			}
			report.reportInfo("Expected column Names: "+expectedData);
			report.reportInfo("Displayed column Names in AA Page: "+actualPanelNames);
			ArrayList<String>unmatchedPanelNames=webActions.getUmatchedInArrayComparision(actualPanelNames, expectedData);
			if(unmatchedPanelNames.size()==0){
				report.reportPass("Verified column Names from" +page+ " page successfully");
			}
			else{
				throw new Exception("Fail to verify column names from" +page+ "page and unmatched column names are: "+unmatchedPanelNames);
			}

		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyTabs(DataTable names){
		try {
			ArrayList<String> expectedData = new ArrayList<>(names.asList());
			ArrayList<String> actualPanelNames=webActions.getDatafromWebTable(tbl_WorkListTabs);
			report.reportInfo("Expected column Names: "+expectedData);
			report.reportInfo("Displayed column Names in AA Page: "+actualPanelNames);
			ArrayList<String>unmatchedPanelNames=webActions.getUmatchedInArrayComparision(actualPanelNames, expectedData);
			if(unmatchedPanelNames.size()==0){
				report.reportPass("Verified tabs from worklist successfully");
			}
			else{
				throw new Exception("Fail to verify worklist tabs and unmatched column names are: "+unmatchedPanelNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyFiterWindow(){
		try {	
			Thread.sleep(2000);
			webActions.click(lbl_AccountNumberFilter, "AccFilter");
			webActions.waitForVisibility(btn_Filter, "Filter");
			webActions.assertDisplayed(btn_Filter, "Filter");
			report.reportPass("Search Filter window opned successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyfilterMode(String type){
		try {
			if(type.contentEquals("unCheck")){
				webActions.click(chk_SelectAll, "SelectAll");
				webActions.waitForPageLoaded();
				boolean flag=btn_Filter.isEnabled();
				if(flag){
					report.reportFail("Fail to Verify Filter mode successfully");
				}
				else{
					report.reportPass("Verified Filter mode successfully");
				}
			}
			else if(type.contentEquals("Check")){
				webActions.click(chk_UnSelectAll, "SelectAll");
				webActions.waitForPageLoaded();
				boolean flag=btn_Filter.isEnabled();
				if(flag){

					report.reportPass("Verified Filter mode successfully");
				}
				else{
					report.reportFail("Fail to Verify Filter mode");
				}
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifySearchFilterMessage(String testData,String msg){
		try {
			webActions.waitForPageLoaded();
			webActions.sendKeys(lbl_SearchBox, testData, "SearchField");
			webActions.waitForVisibility(lbl_NoMatchMsg, "Message");
			String actMsg=webActions.getText(lbl_NoMatchMsg, "Message");
			if(actMsg.contentEquals(msg)){
				report.reportPass("Verified validation message successfully");
			}else{
				report.reportFail("Fail to Verify validation message");
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnCrossAndVerify(){
		try {
			webActions.click(lbl_CrossOption, "crossOption");
			webActions.waitForPageLoaded();
			boolean flag=btn_Filter.isEnabled();
			if(flag){

				report.reportPass("Verified Filter mode successfully");
			}
			else{
				report.reportFail("Fail to Verify Filter mode");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnClearAndVerify(){
		try {
			webActions.click(btn_Clear, "Clear");
			webActions.waitForPageLoaded();
			report.reportPass("Verified clear button successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickOnAccountLinkNumber(String page) throws Exception{
		try {
			if("AA".contentEquals(page) || "Challenge".contentEquals(page)){
				webActions.waitForPageLoaded();
				String accountNumber=webActions.getText(lnk_AccountNumber, "Account Number");
				report.reportInfo("Account Number is: "+accountNumber);
				webActions.click(lnk_AccountNumber, "Account Number");	
			}
			else if("Eligibility".contentEquals(page)){
				webActions.waitForPageLoaded();
				String accountNumber=webActions.getText(lnk_AccountNumberEligibility, "Account Number");
				report.reportInfo("Account Number is: "+accountNumber);
				webActions.click(lnk_AccountNumberEligibility, "Account Number");	
			}			

			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_DigitalDocMangerPanel, "DigitalDocs");

			visitSummary.waitforPaymentFacilitatorPanel();
			report.reportInfo("Navigated to the Patient Visit Summary page");			
			webActions.waitForVisibilityOfAllElements(lbl_DataInAllDataPanel, "DataInAllData");
			webActions.waitForVisibilityOfAllElements(lbl_VisitSummaryData, "SummaryData");

		} catch (Exception e) {
			throw e;
		}

	}
	public void clickOnWorkListBreadCrumb(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lnk_WorkListBrd, "workList");
			webActions.waitForPageLoaded();
			Thread.sleep(5000);			
			webActions.waitUntilisDisplayed(lbl_AAGridData, "Default grid");			
			report.reportPass("Successfully clicked on worklist breadcrumb");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public ArrayList<String> getAccountNumbers(List<WebElement> elements, String elementName){
		ArrayList<String> data= new ArrayList<String>();
		List<WebElement> allElement = elements;
		for (WebElement we: allElement) { 
			String txt=we.getText().trim();						
			data.add(txt);			
		}
		return data;
	}
	public int getResultsCount(){	
		String count=webActions.getText(lbl_AccountsCount, "Accounts count");
		String[] counts=count.split(" ");
		String value=counts[0];
		return Integer.parseInt(value);
	}
	public void verifyAccountsCount(){
		try {			
			ArrayList<String> resultsCount=getAccountNumbers(tbl_AccountNumbers,"Total Rows");
			int expResultsCount=resultsCount.size();
			int actResultsCount=getResultsCount();
			if(actResultsCount==expResultsCount){
				report.reportPass("Accounts count is verified successfully and  result count is: "+expResultsCount);
			}
			else{
				throw new Exception("Accounts count verification is failed and expected count is:" +expResultsCount+ "but displyed results count is: "+actResultsCount);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void performSearchAndVerifyCount(){
		try {
			webActions.click(lbl_AccountNumberFilter, "AccFilter");
			webActions.waitForVisibility(btn_Filter, "Filter");
			webActions.click(chk_SelectAll, "SelectAll");
			webActions.waitForPageLoaded();
			webActions.click(chk_FirstRecord, "SelectAll");
			webActions.waitForPageLoaded();
			webActions.click(btn_Filter, "Filter");
			webActions.waitForPageLoaded();
			verifyAccountsCount();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnExport(){
		try {
			webActions.click(lnk_Dots, "threeDots");
			Thread.sleep(1000);
			webActions.waitForVisibility(lnk_Exportexcel, "ExportExcel");
			webActions.click(lnk_Exportexcel, "ExportExcel");
			Thread.sleep(1000);
			webActions.waitForPageLoaded();
			report.reportPass("Successfully slected export excel");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickOnTab(String tab){
		try {
			if(tab.contentEquals("Challenge")){
				webActions.click(btn_Challenge, "ChallengeBtn");
				webActions.waitForVisibility(tbl_ChallengeAccountNumbers, "records",60);
			}
			else if(tab.contentEquals("Eligibility")){
				webActions.click(btn_Eligibility, "EligibilityBtn");
				webActions.waitForVisibilityOfAllElements(tbl_EligibilityAccountNumbers, "Records");
			}else if(tab.contentEquals("FAQ")){
				webActions.click(btn_FAQ, "FAQ");
				webActions.waitForVisibility(lnk_AccountNo_FAQ, "records",60);
			}
			webActions.waitForPageLoaded();			
			report.reportPass("Successfully slected" +tab+ "tab");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickSelectAllAndVerifyCount(){
		try {
			webActions.click(lbl_AccountNumberFilter, "AccFilter");
			webActions.waitForVisibility(btn_Filter, "Filter");
			webActions.click(chk_FirstRecord, "SelectAll");
			webActions.waitForPageLoaded();		
			webActions.click(chk_UnSelectAll, "SelectAll");
			webActions.waitForPageLoaded();			
			webActions.click(btn_Filter, "Filter");
			webActions.waitForPageLoaded();
			verifyAccountsCount();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyChallengedRecords(String status){
		try {			
			ArrayList<String> actualStatus=getAccountNumbers(tbl_ChallengeStatus,"Total Rows");			
			ArrayList<String>unmatchedPanelNames=webActions.isFullArrayMatchWithData(actualStatus, status);
			if(unmatchedPanelNames.size()==0){
				report.reportPass("Verified records status from worklist challenge tab successfully");
			}
			else{
				throw new Exception("Fail to verify status of records from challenge tab and unmatched column names are: "+unmatchedPanelNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyEligibilityAccountsCount(){
		try {			
			ArrayList<String> resultsCount=getAccountNumbers(tbl_EligibilityAccountNumbers,"Total Rows");
			int expResultsCount=resultsCount.size();
			int actResultsCount=getResultsCount();
			if(actResultsCount==expResultsCount){
				report.reportPass("Accounts count is verified successfully and  result count is: "+expResultsCount);
			}
			else{			
				throw new Exception("Accounts count verification is failed and expected count is:" +expResultsCount+ "but displyed results count is: "+actResultsCount);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void performSearchAndVerifyEligibilityCount(){
		try {
			webActions.click(lbl_EligibilityNumberFilter, "AccFilter");
			webActions.waitForVisibility(btn_Filter, "Filter");
			webActions.click(chk_SelectAll, "SelectAll");
			webActions.waitForPageLoaded();
			webActions.click(chk_FirstRecord, "SelectAll");
			webActions.waitForPageLoaded();
			webActions.click(btn_Filter, "Filter");
			webActions.waitForPageLoaded();
			verifyEligibilityAccountsCount();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickSelectAllAndEligibilityCount(){
		try {
			webActions.click(lbl_EligibilityNumberFilter, "AccFilter");
			webActions.waitForVisibility(btn_Filter, "Filter");
			webActions.click(chk_FirstRecord, "SelectAll");
			webActions.waitForPageLoaded();		
			webActions.click(chk_UnSelectAll, "SelectAll");
			webActions.waitForPageLoaded();			
			webActions.click(btn_Filter, "Filter");
			webActions.waitForPageLoaded();
			verifyEligibilityAccountsCount();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickOnEligibilityAccountFilter(){
		try {	
			Thread.sleep(2000);
			webActions.click(lbl_EligibilityNumberFilter, "AccFilter");
			webActions.waitForVisibility(btn_Filter, "Filter");
			webActions.assertDisplayed(btn_Filter, "Filter");
			report.reportPass("Search Filter window opned successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyEligibilityAccountNumber(String accNumber){
		try {
			webActions.waitForLoad();
			webActions.sendKeys(lbl_SearchBox, accNumber, "SearchField");
			webActions.waitForLoad();
			Thread.sleep(3000);
			webActions.click(btn_Filter, "Filter");
			webActions.waitForPageLoaded();
			Thread.sleep(3000);
			ArrayList<String> numbers=webActions.getDatafromWebTable(tbl_EligibilityAccountNumbers);
			ArrayList<String>unmatchedAccNumbers=webActions.isFullArrayMatchWithData(numbers, accNumber);
			if(unmatchedAccNumbers.size()==0){
				report.reportPass("Verified account numbers from worklist eligibility tab successfully");
			}
			else{
				throw new Exception("Fail to verify account numbers from eligibility tab and unmatched numbers are: "+unmatchedAccNumbers);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void navigateToWorList(){
		try {
			webActions.waitForPageLoaded();	
			webActions.click(lnk_WorkList, "Worklist");
			webActions.waitForPageLoaded();
			try {
				Thread.sleep(3000);
				webActions.waitUntilisDisplayed(lbl_AAGridData, "Default grid");
				report.reportPass("Clicked on worklist link and navigated to the worklist Page Successfully");
			} catch (Exception e) {
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());	
		}
	}
	public void clickOnEligibile(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_Eligibility, "Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(tabs_AllInsurances, "All Insurances");
		} catch (Exception e) {
			report.reportFail(e.getMessage());	
		}
	}
	public void verifySearchFilter(String accountNumber){
		try {
			webActions.click(btn_Challenge, "ChallengeBtn");
			webActions.waitForVisibility(tbl_ChallengeAccountNumbers, "records",60);
			webActions.waitForPageLoaded();
			webActions.click(btn_Eligibility, "EligibilityBtn");
			webActions.waitForVisibilityOfAllElements(tbl_EligibilityAccountNumbers, "Records");
			webActions.waitForPageLoaded();
			ArrayList<String> numbers=webActions.getDatafromWebTable(tbl_EligibilityAccountNumbers);
			ArrayList<String>unmatchedAccNumbers=webActions.isFullArrayMatchWithData(numbers, accountNumber);
			if(unmatchedAccNumbers.size()==0){
				report.reportPass("Verified account numbers from worklist eligibility tab successfully");
			}
			else{
				throw new Exception("Fail to verify account numbers from eligibility tab and unmatched numbers are: "+unmatchedAccNumbers);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}
}