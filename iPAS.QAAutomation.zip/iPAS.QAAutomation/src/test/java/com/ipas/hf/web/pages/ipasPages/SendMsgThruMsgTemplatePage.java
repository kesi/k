package com.ipas.hf.web.pages.ipasPages;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;
import com.jayway.jsonpath.internal.function.text.Concatenate;

public class SendMsgThruMsgTemplatePage extends BasePage {

	@FindBy(xpath = "//input[@id='username']")
	private WebElement txt_UserName;

	@FindBy(xpath = "//app-ipas-messaging-panel[1]/div[5]/ejs-dropdownlist[1]/span[1]")
	private WebElement drpdwn_MsgTemplate;
	
	@FindBy(xpath = "//app-ipas-messaging-panel[1]/div[5]/ejs-dropdownlist[1]/span[1]/input")
	private WebElement drpdwnValue_MsgTemplate;
	
	@FindBy(xpath = "//app-ipas-messaging-panel[1]/div[5]/textarea[1]")
	private WebElement txtBox_MsgBox;

	@FindBy(xpath = "//app-ipas-messaging-panel[1]/div[5]/textarea[@placeholder='Type message here']")
	private WebElement msg_MsgTemplate;

	@FindBy(xpath = "//button[contains(text(),'Send')]")
	private WebElement btn_Send;
	
	@FindBy(xpath = "//div[5]/textarea[@class='ng-valid ng-touched ng-dirty']")
	private WebElement msg_MsgTemplateText;
	
	@FindBy(xpath = "//app-ipas-messaging-panel[1]/div[5]/div[1]/p[1]")
	private WebElement msg_MaxLengthMsg;
	
	@FindBy(xpath = "//ipas-service-tracker-messaging-content[1]/div[1]/div[2]/p[1]")
	private WebElement txt_FirstMsg;
		
	@FindBy(xpath = "//ipas-service-tracker-messaging-content[1]/div[1]/div[3]/p[1]")
	private WebElement txt_SecondMsg;
		
	@FindBy(xpath = "//ipas-service-tracker-messaging-content[1]/div[1]/div[4]/p[1]")
	private WebElement txt_ThirdMsg;
	
	public SendMsgThruMsgTemplatePage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyMessageTemplateDropDownOnVisitCard() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(drpdwn_MsgTemplate, "DropDown",15);
			if(drpdwn_MsgTemplate.isDisplayed()){
				report.reportPass("Message Template Drop Down is displayed successfully");
			}else{
				throw new Exception("Unable to find Message Template Drop Down");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyMessageBoxOnVisitCard() throws Exception{
		try{
			webActions.waitForPageLoaded();
			if(txtBox_MsgBox.isDisplayed()){
				report.reportPass("Message Text Box is displayed successfully");
			}else{
				throw new Exception("Unable to find Message Text Box");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyHelpTextOnMessageWindow(String expText) throws Exception{
		try{
			webActions.waitForPageLoaded();
			String actText = webActions.getAttributeValue(msg_MsgTemplate, "placeholder", "MsgTemplateText");
			report.reportInfo("Actual Help Text in Message Hub through Visit Card is :"+actText);
			report.reportInfo("Expected Help Text in Message Box is :"+expText);
			if(actText.contentEquals(expText)){
				report.reportPass("Help Text is displayed successfully in Message Hub on Visit Card");
			}else{
				throw new Exception("Failed to read Help Text Message on Message Text Box");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDropDownTemplateMsg(String expDrpDwnText) throws Exception{
		try{
			webActions.waitForPageLoaded();
			String actDrpDwnMsg = webActions.getAttributeValue(drpdwnValue_MsgTemplate, "placeholder", "DropDownMsg");
			report.reportInfo("Actual Drop Down Template Message is :"+actDrpDwnMsg);
			report.reportInfo("Expected Help Text in Messae Box is :"+expDrpDwnText);
			if(actDrpDwnMsg.contentEquals(expDrpDwnText)){
				report.reportPass("Help Text is displayed successfully in Message Template Drop Down");
			}else{
				throw new Exception("Failed to read Help Text in Msg Template Drop Down ");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void enterTextinMessageBox(String expMsgText) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.sendKeys(txtBox_MsgBox, expMsgText, "MsgBox");
			report.reportPass("Enter text in Message Box");
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_Send, "SEndButn");
			webActions.waitForClickAbilityAndClick(btn_Send, "Sendbutn");
			report.reportInfo("Clicked on Send button");
			//webActions.refreshPage();
			Thread.sleep(5000);
			webActions.waitForPageLoaded();
			webActions.scrollUpPage();
			webActions.waitForVisibility(txtBox_MsgBox,  "MsgBox",20);
			String actMsgText = webActions.getText(txt_FirstMsg, "FirstMsg");
			report.reportInfo("Message in Message Hub is :"+actMsgText);
			
			if(actMsgText.contentEquals(expMsgText)){
				report.reportPass("Selected message is displayed in Message Hub successfully");
			}else{
				report.reportFail("Selected message is not displayed in message Hub");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void enterTextinMessageBoxOpenedOnVisitCard(String expMsgText) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.sendKeys(txtBox_MsgBox, expMsgText, "MsgBox");
			report.reportPass("Enter text in Message Box");
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_Send, "SEndButn");
			webActions.waitForClickAbilityAndClick(btn_Send, "Sendbutn");
			report.reportInfo("Clicked on Send button");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndGetText(txt_FirstMsg,  "FirstMsg");
			//String actMsgText = webActions.waitAndGetText(txt_FirstMsg, "FirstMsg");
			String actMsgText =driver.findElement(By.xpath("//p[contains(text(),'"+expMsgText+"')]")).getText();
			report.reportInfo("Message in Message Hub is :"+actMsgText);
			if(actMsgText.contentEquals(expMsgText)){
				report.reportPass("Selected message is displayed in Message Hub successfully");
			}else{
				report.reportFail("Selected message is not displayed in message Hub");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	
	
	
	public void verifySendButtonModeIsEnabled() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.sendKeys(txtBox_MsgBox, "Testing", "MsgBox");
			report.reportPass("Enter text in Message Box");
			webActions.scrollBarHandle(btn_Send, "SendBtn");
			if(btn_Send.isEnabled()){
				report.reportPass("Send button is in enabled mode");
			}else{
				throw new Exception("unable to find send button");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifySendButtonModeIsDisabled() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_Send, "SendBtn");
			if(!btn_Send.isEnabled()){
				report.reportPass("Send button is in disabled mode");
			}else{
				throw new Exception("unable to find send button");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	
	
	public void selectMsgTemplate(String tempValue) throws Exception{
		try{
			webActions.waitForVisibility(drpdwn_MsgTemplate, "Template Drop Down",15);
			webActions.waitForClickAbility(drpdwn_MsgTemplate, "Template Drop Down");
			webActions.clickBYJS(drpdwn_MsgTemplate, "Template Drop Down");
			report.reportPass("Clicked on Template drop down");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(drpdwnValue_MsgTemplate, "Template",15);
			webActions.waitForClickAbility(drpdwnValue_MsgTemplate, "Template");
			webActions.sendKeys(drpdwnValue_MsgTemplate, tempValue, "Template");
			webActions.waitForPageLoaded();
			report.reportPass("Template value is selected :"+tempValue);			
			//webActions.scrollBarHandle(btn_Send, "SendButn");
			webActions.waitForClickAbility(btn_Send, "Sendbutn");
			webActions.click(btn_Send, "Sendbutn");
			report.reportInfo("Clicked on Send button");
			Thread.sleep(5000);
			webActions.waitForPageLoaded();
			webActions.scrollUpPage();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			//webActions.waitForVisibility(txt_FirstMsg, "MsgText",5);
			String actMsgText = webActions.waitAndGetText(txt_FirstMsg, "FirstMsg");
			report.reportInfo("Message in Message Hub is :"+actMsgText);
			report.reportInfo("Expected message is : https://qa.myvim.com/ai?l=QI2SNqhvukya4jaFEI4Xog%3D%3D");
			if(actMsgText.contentEquals("https://qa.myvim.com/ai?l=QI2SNqhvukya4jaFEI4Xog%3D%3D")){
				report.reportPass("Selected message is displayed in Message Hub successfully");
			}else{
				report.reportFail("Selected message is not displayed in message Hub");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	
	public void selectMsgTemplateOpenedOnVisitCard(String tempValue) throws Exception{
		try{
			webActions.waitForVisibility(drpdwn_MsgTemplate, "Template Drop Down",15);
			webActions.waitForClickAbility(drpdwn_MsgTemplate, "Template Drop Down");
			webActions.clickBYJS(drpdwn_MsgTemplate, "Template Drop Down");
			report.reportPass("Clicked on Template drop down");
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(drpdwnValue_MsgTemplate, "Template");
			webActions.sendKeys(drpdwnValue_MsgTemplate, tempValue, "Template");
			webActions.waitForPageLoaded();
			report.reportPass("Template value is selected :"+tempValue);
			Thread.sleep(5000);
			webActions.scrollBarHandle(btn_Send, "SendButn");
			webActions.waitForClickAbilityAndClick(btn_Send, "Sendbutn");
			report.reportInfo("Clicked on Send button");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndGetText(txt_SecondMsg, "SecondMsg");
			//String actMsgText = webActions.waitAndGetText(txt_FirstMsg, "FirstMsg");
			String actMsgText = driver.findElement(By.xpath("//p[contains(text(),'"+tempValue+"')]")).getText();
			report.reportInfo("Message in Message Hub is :"+actMsgText);
			report.reportInfo("Expected message is :"+tempValue);
			if(actMsgText.contentEquals(tempValue)){
				report.reportPass("Selected message is displayed in Message Hub successfully");
			}else{
				report.reportFail("Selected message is not displayed in message Hub");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyMaxLengthMsg(String expValue) throws Exception{
		try{
			webActions.waitForPageLoaded();
			String actValue = webActions.getText(msg_MaxLengthMsg, "MSg");
			report.reportInfo("Actual Max Length msg is :"+actValue);
			if(actValue.contentEquals(expValue)){
				report.reportPass("Max Length message is displayed successfully");
			}else{
				throw new Exception("Failed to read Max length message");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyMaxLengthAllowedMsg(String expValue) throws Exception{
		try{
			webActions.waitForPageLoaded();
			String data = "Verify the full message template text is displayed in Message box if selected message template have more than 160 characters window  the full message template v";
			webActions.sendKeys(txtBox_MsgBox, data, "MsgBox");
			report.reportInfo("Enter data in message box");
			webActions.waitForPageLoaded();
			String actValue = webActions.getText(msg_MaxLengthMsg, "MSg");
			report.reportInfo("Actual Max Length msg is :"+actValue);
			if(actValue.contentEquals(expValue)){
				report.reportPass("Max Length message is displayed successfully");
			}else{
				throw new Exception("Failed to read Max length message");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyUserCanEditMsg(String tempValue, String expTextValue) throws Exception{
		String expMSgText= null;
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(drpdwn_MsgTemplate, "Template Drop Down",25);
			webActions.waitForClickAbility(drpdwn_MsgTemplate, "Template Drop Down");
			webActions.clickBYJS(drpdwn_MsgTemplate, "Template Drop Down");
			report.reportPass("Clicked on Template drop down");
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(drpdwnValue_MsgTemplate, "Template");
			webActions.sendKeys(drpdwnValue_MsgTemplate, tempValue, "Template");
			report.reportPass("Template value is selected :"+tempValue);
			webActions.waitForPageLoaded();
			webActions.sendKeys(txtBox_MsgBox, expTextValue, "MsgBox");
			report.reportPass("Enter text in Message Box");
			webActions.scrollBarHandle(btn_Send, "SendBtn");
			webActions.clickBYJS(btn_Send, "SendBtn");
			webActions.waitForPageLoaded();
			expMSgText = tempValue+expTextValue;
			report.reportInfo("Expected Message is :"+expMSgText);
			webActions.waitAndGetText(txt_SecondMsg, "SecondMsg");
			//String actMsgText = webActions.getText(txt_FirstMsg, "TextBoxMsg");
			String actMsgText = driver.findElement(By.xpath("//p[contains(text(),'"+expMSgText+"')]")).getText();
			report.reportInfo("Actual Message is :"+actMsgText);
			if(actMsgText.contentEquals(expMSgText)){
				report.reportPass("User can edit the selected message");
			}else{
				throw new Exception("Failed to read selected and edited message");
			}		
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	
	
	public SendMsgThruMsgTemplatePage openIpasApp() {
		try {
			String URL = TestBase.prop.ipasURL();
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to Open iPAS application");
		}
		return (SendMsgThruMsgTemplatePage) base(SendMsgThruMsgTemplatePage.class);
	}



	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_UserName);
	}

}
