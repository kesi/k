package com.ipas.hf.web.steps;

import java.util.Properties;

import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.utilities.ConfigProperties;
import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.ViewNotesIconOnServiceTrackerPanelPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class ViewNotesIconOnServiceTrackerPanelSteps {
	ViewNotesIconOnServiceTrackerPanelPage notesIcononSTPanel = new ViewNotesIconOnServiceTrackerPanelPage();
	
	Login logIn = new Login();
	HomePage home = new HomePage();

	@Then("Verify Notes Icon on Visit Card")
	public void verify_Notes_Icon_on_Visit_Card() throws Exception {
		notesIcononSTPanel.verifyNotesIconOnVisitCard();
	}

	@Then("Verify Notes Icon on Service Tracker Panel")
	public void verify_Notes_Icon_on_Service_Tracker_Panel() throws Exception {
		notesIcononSTPanel.verifyNotesIconOnServiceTrackerPanel();
	}

	@Then("Verify Notes Icon on Service Tracker Full Page")
	public void verify_Notes_Icon_on_Service_Tracker_Full_Page() throws Exception {
		notesIcononSTPanel.verifyNotesIconOnServiceTrackerFullPage();
	}

	@Then("Verify the Data in Notes Window Grid of Service Tracker Full Page")
	public void verify_the_Data_in_Notes_Window_Grid_of_Service_Tracker_Full_Page(DataTable data) throws Exception {
		notesIcononSTPanel.verifyCreatedNotesDataOnSTFullPage(data);
	}

	@Then("Verify Notes Icon is not displayed on Visit Card")
	public void verify_Notes_Icon_is_not_displayed_on_Visit_Card() throws Exception {
		notesIcononSTPanel.verifyNotesIconIsNotDisplayedOnVisitCard();
	}


	@Then("Verify Notes Icon is not displayed on Service Tracker Panel")
	public void verify_Notes_Icon_is_not_displayed_on_Service_Tracker_Panel() throws Exception {
		notesIcononSTPanel.verifyNotesIconIsNotDisplayedOnServiceTrackerPanel();
	}

	@Then("Verify Notes Icon is not displayed on Service Tracker FullPage")
	public void verify_Notes_Icon_is_not_displayed_on_Service_Tracker_FullPage() throws Exception {
		notesIcononSTPanel.verifyNotesIconIsNotDisplayedOnServiceTrackerFullPage();
	}

	@Then("Verify Notes Created Time on Notes Window")
	public void verify_Notes_Created_Time_on_Notes_Window() throws Exception {
		notesIcononSTPanel.compareNotesCreatedTime();
	}
	
	@Then("Verify Notes button is in Disabled mode")
	public void verify_Notes_button_is_in_Disabled_mode() throws Exception {
		notesIcononSTPanel.verifyAddNotesButtonInDisabledMode();
	}
	
	@Then("Verify Notes button is in Enabled Mode")
	public void verify_Notes_button_is_in_Enabled_Mode() throws Exception {
		notesIcononSTPanel.verifyAddNotesButtonInEnabledMode();
	}
}
