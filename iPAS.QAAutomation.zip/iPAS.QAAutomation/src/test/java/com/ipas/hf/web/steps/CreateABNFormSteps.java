package com.ipas.hf.web.steps;


import org.json.simple.parser.ParseException;

import com.ipas.hf.web.pages.ipasPages.CreateABNFormPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class CreateABNFormSteps {
	
	CreateABNFormPage mednec=new CreateABNFormPage();
	
	@Then("Update Auto Run for {string} Plan Code or Name as {string} and facility {string} as {string}")
	public void update_Auto_Run_for_Plan_Code_or_Name_as_and_facility_as(String moduleName, String plan_Name_Code, String facility, String runStatus) throws Exception {
		mednec.medNecAutoRunTurnOnAndTrunOff(moduleName, plan_Name_Code, facility, runStatus);
	}

	@Then("Navigate to Medical Necessity page")
	public void navigate_to_Medical_Necessity_page() {
		mednec.navigateMedicalNecessityPage();
	}
	
	@Then("Create ABN form in Medical Necessity")
	public void create_ABN_form_in_Medical_Necessity() {
		mednec.createABNForm();
	}
	
	@Then("Verify {string} form in Digital DocManger")
	public void verify_form_in_Digital_DocManger(String formName) {
		mednec.verifyABNForminDigitalDocuments(formName);
	}

	@Then("Update Medical Necessity JSON file")
	public void update_Medical_Necessity_JSON_file() throws ParseException {
		mednec.updateMedNecJSON();
	}
	
	@Then("Verify the Medical Necessity History functionality")
	public void verify_the_Medical_Necessity_History_functionality() {
		mednec.verifyMedicalNecessityHistory();
	}
	
	@Then("Navigate to Medical Necessity for All Modules popup in Account Search")
	public void navigate_to_Medical_Necessity_for_All_Modules_popup_in_Account_Search() {
		mednec.navigateMedicalNecessityLongPanelFromAllModulesPopup();
	}



	
	
}