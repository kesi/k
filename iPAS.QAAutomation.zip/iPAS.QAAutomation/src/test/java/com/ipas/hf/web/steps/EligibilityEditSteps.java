package com.ipas.hf.web.steps;

import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.ipasPages.AddPatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.EditUserPage;
import com.ipas.hf.web.pages.ipasPages.EligibilityEditPage;
import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class EligibilityEditSteps {

	EligibilityEditPage editEligibility = new EligibilityEditPage();
	RestActions rest=new RestActions();
	AddPatientVisitPage addpatient=new AddPatientVisitPage();

	@Then("Verify the BreadCrumb for Eligibility Edit screen")
	public void Verify_the_BreadCrumb_for_Eligibility_Edit_screen(DataTable breadcrumb) throws InterruptedException {
		editEligibility.verifyBreadcrumbinEditEligibility(breadcrumb);
	}
	
	@Then("Verify the PELITAS Payer Code or Payer Description will be a hyperlink")
	public void Verify_the_PELITAS_Payer_Code_or_Payer_Description_will_be_a_hyperlink(DataTable testData) throws InterruptedException {
		editEligibility.verifyHyperlink(testData);
	}
	
	@Then("Verify the screen will be replaced with the Edit Eligibility screen")
	public void Verify_the_screen_will_be_replaced_with_the_Edit_Eligibility_Screen(DataTable testData) throws InterruptedException {
		
		editEligibility.verifyEditEligibility(testData);
	}
	
	@Then("Verify the Toggle Switch is Active or Inactive")
	public void Verify_the_Toggle_Switch_is_Active_or_Inactive() throws InterruptedException {
		editEligibility.verifyToggleSwitch();
	}
	
	@Then("Verify label stacked In bold font")
	public void Verify_label_stacked_in_bold_font(DataTable testData) throws InterruptedException {
		editEligibility.verifyLabels(testData);
	}
	
	@Then("Verify the label Connection")
	public void Verify_the_label_Connection(DataTable testData) throws InterruptedException {
		editEligibility.verifyLabelConnection(testData);
	}
	
	@Then("Verify the values stacked in regular font")
	public void Verify_the_values_stacked_in_regular_font(DataTable testData) throws InterruptedException {
		editEligibility.verifyLabels(testData);
	}
	
	@Then("Verify the column labels in search criteria")
	public void Verify_the_column_labels_in_search_criteria(DataTable testData) throws InterruptedException {
		editEligibility.verifyLabelConnection(testData);
	}
	
	@Then("Verify the Cancel button functionality in edit eligibility")
	public void Verify_the_Cancel_button_functionality_in_edit_eligibility() throws InterruptedException {
		editEligibility.verifyCancelFunct();
	}
	
	@Then("Verify the service codes section label as {string}")
	public void Verify_the_Service_Codes_section_label(String label) throws InterruptedException {
		editEligibility.verifyServiceCodes(label);
	}
	
	@Then("Verify the column headers in service codes")
	public void Verify_the_column_headers_in_servicecodes(DataTable testData) throws InterruptedException {
		editEligibility.verifyColumnHeaderServiceCodes(testData);
	}
	
	@Then("Verify the display of the {string} in service codes")
	public void verify_the_display_of_the_result_in_service_codes(String testData) throws InterruptedException {
		editEligibility.verifyResultsDisplay(testData);
	}
	
	@Then("Verify the connection section label as {string}")
	public void Verify_the_connection_section_label(String label) throws InterruptedException {
		editEligibility.verifyConnection(label);
	}
	
	@Then("Verify the Editable fields under Connection Type in Edit screen")
	public void Verify_the_Editable_fields_in_Edit_screen(String label) throws InterruptedException {
		editEligibility.verifyConnection(label);
	}
	
	@Then("verify adding of new connection as {string}")
	public void verify_adding_of_New_Payer(String connection) {
		String vendorCode=rest.randomString(5);
		String vendorDesc=rest.randomString(5);
		addpatient.notepadWrite("EDIVendorCode",vendorCode);
		addpatient.notepadWrite("EDIVendorDescription",vendorDesc); 
		addpatient.notepadWrite("Connection",connection);
		editEligibility.addNewConnection(connection,vendorCode,vendorDesc);
	}
	
	@Then("verify the trash icon in connection type section")
	public void verify_the_trash_icon_in_connection_type_section() {
		editEligibility.verifyTrashIcon();
	}
}