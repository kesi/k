package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class PropensityToPayPage extends BasePage {

	@FindBy(xpath = "//ipas-propensity-to-pay-pannel//ejs-accordion//span/div/a")
	private WebElement txt_P2PShortPanelTitle;

	@FindBy(xpath = "//ipas-propensity-to-pay-details//div[@class='title']/span")
	private WebElement txt_P2PFullPanelTitle;

	@FindBy(xpath = "//ipas-propensity-to-pay-pannel//div/img")
	private WebElement img_P2PShortPanelModuleStatus;

	@FindBy(xpath = "//ipas-propensity-to-pay-details//financial-clearance-status/img")
	private WebElement img_P2PFullPanelModuleStatus;

	@FindBy(xpath="//ipas-propensity-to-pay-pannel//ejs-accordion//div[@class='e-toggle-icon']/span")
	private WebElement icon_P2PExpandCollapse;

	@FindBy(xpath="(//ipas-propensity-to-pay-pannel//div/span)[3]")
	private WebElement txt_P2PShortPanelMsg;

	@FindBy(xpath="(//ipas-propensity-to-pay-details//div/span)[3]")
	private WebElement txt_P2PFullPanelMsg;

	@FindBy(xpath="//ipas-propensity-to-pay-details//div")
	private WebElement lbl_P2PFullPanelFields;

	@FindBy(xpath="//ipas-propensity-to-pay-pannel//div/p")
	private WebElement txt_P2PShortLastRunBy;
	@FindBy(xpath="(//ipas-propensity-to-pay-details//div/span)[4]")
	private WebElement txt_P2PFullPanelLastRunBy;

	@FindBy(xpath="//ipas-propensity-to-pay-details//div/p")
	private List<WebElement> lbl_P2PFullPanelsections;

	@FindBy(xpath="//ipas-propensity-to-pay-details//div/h6")
	private WebElement lbl_P2PFullPanelVerificationResponse;

	@FindBy(xpath="//ipas-propensity-to-pay-details//ul/li")
	private List<WebElement> lbl_P2PFullPanelResponse;

	@FindBy(xpath="(//ipas-propensity-to-pay-details//financial-clearance-status/img)[2]")
	private WebElement txt_P2PFullPanelDataElementsStatus;

	@FindBy(xpath="(//ipas-propensity-to-pay-details//p)[2]")
	private WebElement txt_P2PFullPanelDataElementsMsg;

	@FindBy(xpath="//a[contains(text(),'Run Credit Check')]")
	private WebElement btn_P2PRunCreditCheck;

	@FindBy(xpath="(//div[@class='modal-body'])[2]//label")
	private List<WebElement> lbl_P2PNewRequestWindowFields;

	@FindBy(xpath="(//button[contains(text(),'Cancel')])[3]")
	private WebElement btn_P2PNewRequestWindowCancel;


	@FindBy(xpath="//ipas-propensity-to-pay-details//div/button")
	private WebElement btn_P2PFullPanelOtherOptions;

	@FindBy(xpath="(//button[@class='close'])[4]")
	private WebElement btn_P2PNewRequestWindowCross;

	@FindBy(xpath="//ejs-dropdownlist/span")
	private WebElement ddl_P2PNewRequestdropdown;

	@FindBy(xpath="//ipas-propensity-to-pay-details//button")
	private WebElement btn_P2POtherOption;

	@FindBy(xpath="//a[contains(text(),'History')]")
	private WebElement btn_P2PHistory;

	@FindBy(xpath="//span[@class='modal-title']/span")
	private WebElement lbl_P2PHistoryTitle;

	@FindBy(xpath="(//thead/tr/th/div/span)[1]")
	private WebElement lbl_P2PHistoryDate;

	@FindBy(xpath="//tbody/tr/td[3]/span")
	private WebElement lbl_P2PHistoryMessage;

	@FindBy(xpath="(//button[@class='close'])[3]")
	private WebElement btn_P2PHistoryClose;

	@FindBy(xpath="//a[contains(text(),'View Credit Report')]")
	private WebElement btn_P2PCreditReport;

	@FindBy(xpath="//button[contains(text(),'Download')]")
	private WebElement btn_P2PCreditReportDownload;

	@FindBy(xpath="(//button[contains(text(),'Cancel')])[2]")
	private WebElement btn_P2PCreditReportCancel;

	public PropensityToPayPage() {
		PageFactory.initElements(driver, this);
	}


	public void verifyPropensityToPay(String panel,String title){
		String actTitle="";
		try {
			webActions.waitForPageLoaded();		
			report.reportInfo("Expected short panel info: "+title);

			if(panel.contentEquals("Short Panel")){
				actTitle=webActions.getText(txt_P2PShortPanelTitle, "title");
				report.reportInfo("Displayed Short Panel Title: "+actTitle);
			}
			else if(panel.contentEquals("Full Panel")){
				actTitle=webActions.getText(txt_P2PFullPanelTitle, "title");
				report.reportInfo("Displayed Full Panel Title: "+actTitle);
			}

			if(actTitle.contentEquals(title)){
				report.reportPass("Verified successfully" +panel+  " title");
			}
			else{
				report.reportFail("Fail to verify postal" +panel+ " title and unmatched data is: "+actTitle);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyP2PModuletStatus(String panel, String data){
		try {
			String moduleStatus = "";
			if("Short Panel".contentEquals(panel)){
				webActions.waitForVisibility(img_P2PShortPanelModuleStatus, "ModuleStatus");
				moduleStatus=webActions.getAttributeValue(img_P2PShortPanelModuleStatus, "src", "IdentityShortPanel");
			}			
			else if("Full Panel".contentEquals(panel)){
				webActions.waitForVisibility(img_P2PFullPanelModuleStatus, "ModuleStatus");
				moduleStatus=webActions.getAttributeValue(img_P2PFullPanelModuleStatus, "src", "IdentityFullPanel");
			}
			else if("FullPanelDataElements".contentEquals(panel)){
				webActions.waitForVisibility(txt_P2PFullPanelDataElementsStatus, "ModuleStatus");
				moduleStatus=webActions.getAttributeValue(txt_P2PFullPanelDataElementsStatus, "src", "P2PFullPanelDataElements");
			}
			/*else if("ShortPanelDataElements".contentEquals(panel)){
				webActions.waitForVisibility(txt_IdentityVerifierShortPanelDataElementsStatus, "ModuleStatus");
				moduleStatus=webActions.getAttributeValue(txt_IdentityVerifierShortPanelDataElementsStatus, "src", "IdentityShortPanelDataElements");
			}*/
			if("Address not found".contentEquals(data)){
				if(moduleStatus.contains("error_sm")){
					report.reportPass("Verified P2P " +panel+ " module status when address not found");
				}
			}
			else if("AddressValid".contentEquals(data)){
				if(moduleStatus.contains("success_sm")){
					report.reportPass("Verified P2P " +panel+ " module status");
				}
			}
			else if("AddressReview".contentEquals(data)){
				if(moduleStatus.contains("alert_sm")){
					report.reportPass("Verified P2P " +panel+ " module status");
				}
			}
			else{
				report.reportFail("Fail to verify propensity to pay " +panel+ "module status and actual displayed image is : " + moduleStatus);
			}		
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyExpandandCollapsP2PPanel() throws Exception{
		StringBuilder unmatch=new StringBuilder();		
		webActions.waitForVisibility(img_P2PShortPanelModuleStatus, "ModuleStatus");		
		String actualExpandStatus=webActions.getAttributeValue(icon_P2PExpandCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons e-expand-icon".contentEquals(actualExpandStatus)){			
			report.reportPass("By default short Panel is displayed in Expand mode");
		}else{
			unmatch.append("Panle is not dispalyed in Expand mode by default");
			report.reportFail("Propensity To Pay Panel is not dispalyed in Expand mode by default");
		}
		webActions.waitAndClick(icon_P2PExpandCollapse, "ExpandandCollapse");
		webActions.waitForPageLoaded();
		String actualCollapseStatus=webActions.getAttributeValue(icon_P2PExpandCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons".contentEquals(actualCollapseStatus)){
			report.reportPass("Propensity To Pay Panel Successfully Collapsed");
		}
		else{
			unmatch.append("Propensity To Pay Panel is not Collapsed");
			report.reportFail("Propensity To Pay Panel is not Collapsed");
		}		
		if(unmatch.length()==0){
			report.reportPass("Propensity To Pay Panel Successfully Expanded and Collapsed");
		}else{
			report.reportFail("Failed to verify the Expand and Collapse of the Propensity To Pay Panel"+unmatch);
		}

	}
	public void verifyPropensityToPayMessage(String panel,String mesg){
		String actMsg="";
		try {
			webActions.waitForPageLoaded();		
			report.reportInfo("Expected short panel info: "+mesg);

			if(panel.contentEquals("Short Panel")){
				actMsg=webActions.getText(txt_P2PShortPanelMsg, "msg");
				report.reportInfo("Displayed Short Panel message: "+actMsg);
			}
			else if(panel.contentEquals("Full Panel")){
				actMsg=webActions.getText(txt_P2PFullPanelMsg, "msg");
				report.reportInfo("Displayed Full Panel message: "+actMsg);
			}
			else if(panel.contentEquals("FullPanelDataElements")){
				actMsg=webActions.getText(txt_P2PFullPanelDataElementsMsg, "msg");
				report.reportInfo("Displayed Full Panel data elements message: "+actMsg);
			}
			if(actMsg.contentEquals(mesg)){
				report.reportPass("Verified successfully" +panel+  " message");
			}
			else{
				report.reportFail("Fail to verify P2P " +panel+ " message and unmatched data is: "+actMsg);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnP2PPanel(){
		try {
			webActions.waitForVisibility(txt_P2PShortPanelTitle, "Identity");
			webActions.click(txt_P2PShortPanelTitle, "IdentityPanel");
			webActions.waitForVisibility(lbl_P2PFullPanelFields, "PanelLable");
			Thread.sleep(1000);
			report.reportInfo("Navigated to the Propensity to pay Full Page");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyLastRunByInP2PPanel(){
		String actCurrentDateTime = null; String expCurrentDateTime = null; String increasedCurrentDateTime = null;String fullPanelCurrentDateTime = null;
		try {			
			webActions.waitForVisibility(txt_P2PShortPanelTitle, "PanelText");
			String actCurrentDate = webActions.waitAndGetText(txt_P2PShortLastRunBy, "LastRunDateTime");
			actCurrentDateTime=actCurrentDate.replace(",", "");			
			report.reportInfo("Dsiplayed last run date from application: "+actCurrentDateTime);			
			String expCurrentDate = webActions.getCurrentSystemDateTime();
			String increasedTime=webActions.getIncreasedCurrentSystemDateTime(-1);
			expCurrentDateTime="Last ran by Auto "+ expCurrentDate;
			increasedCurrentDateTime="Last ran by Auto "+ increasedTime;
			report.reportInfo("system current date time: "+expCurrentDateTime);
			if(actCurrentDateTime.contentEquals(expCurrentDateTime)||actCurrentDateTime.contentEquals(increasedCurrentDateTime))
			{
				report.reportPass("Verified last run by date and time");
			}else{
				report.reportFail("Failed to verify last run by date and time",true);
			}
			clickOnP2PPanel();
			String fullPanelCurrentDate = webActions.waitAndGetText(txt_P2PFullPanelLastRunBy, "LastRunDateTime");
			fullPanelCurrentDateTime=fullPanelCurrentDate.replace(",", "");			
			report.reportInfo("Dsiplayed last run date from application: "+actCurrentDateTime);

			if(fullPanelCurrentDateTime.contentEquals(expCurrentDateTime)||fullPanelCurrentDateTime.contentEquals(increasedCurrentDateTime))
			{
				report.reportPass("Verified last run by date and time in identity full panel");
			}else{
				report.reportFail("Failed to verify last run by date and time in identity full panel");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyP2PVerificationResponse(DataTable testdata){
		try {
			ArrayList<String> actualData =new ArrayList<String>();
			ArrayList<String> expData=new ArrayList<>(testdata.asList());			
			webActions.waitForPageLoaded();
			ArrayList<String> sections=webActions.getDatafromWebTable(lbl_P2PFullPanelsections);
			actualData.addAll(sections);			
			actualData.add(webActions.getText(lbl_P2PFullPanelVerificationResponse, "VerificationResponse"));
			ArrayList<String> address=webActions.getDatafromWebTable(lbl_P2PFullPanelResponse);
			actualData.addAll(address);		

			report.reportInfo("Expected information :"+ expData);
			report.reportInfo("Actual information :"+ actualData);
			ArrayList<String>unmatchedInformation=webActions.getUmatchedInArrayComparision(actualData, expData);
			if(unmatchedInformation.size()==0){
				report.reportPass("Verified successfully propensity to pay information");
			}
			else{
				throw new Exception("Fail to verify propensity to pay information and unmatched data is: "+unmatchedInformation);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnP2PRunCheckBtn(){
		try {
			webActions.waitForVisibility(btn_P2PRunCreditCheck, "RunCreditCheck");
			webActions.click(btn_P2PRunCreditCheck, "RunCreditCheck");
			webActions.waitForVisibilityOfAllElements(lbl_P2PNewRequestWindowFields, "P2PNewrequestPage");
			report.reportInfo("Navigated to the propensity to pay New Request Page");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void cancelAndCrossNavigationP2P(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_P2PNewRequestWindowCancel, "NewRequestCancelBtn");
			webActions.waitForVisibilityOfAllElements(lbl_P2PFullPanelResponse, "PanelInformation");
			webActions.assertDisplayed(btn_P2PFullPanelOtherOptions, "OtherOptions");
			report.reportPass("otheroption is displayed");
			clickOnP2PRunCheckBtn();
			webActions.click(btn_P2PNewRequestWindowCross, "NewRequestCrossOprtion");
			webActions.waitForVisibilityOfAllElements(lbl_P2PFullPanelResponse, "PanelText");
			webActions.assertDisplayed(btn_P2PFullPanelOtherOptions, "OtherOptions");
			report.reportPass("otheroption is displayed");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void selectRequestType(String type){
		try {
			if("Patient".contentEquals(type)){
				webActions.waitForPageLoaded();
				webActions.click(ddl_P2PNewRequestdropdown, "RequestType");			
				webActions.sendKeys(ddl_P2PNewRequestdropdown,type, "RequestType");
				webActions.pressTab();				
				webActions.waitForPageLoaded();

			}
			else{

			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnHistory(String expMsg){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_P2POtherOption, "OtherOption");
			webActions.waitForVisibility(btn_P2PHistory, "History");
			webActions.click(btn_P2PHistory, "History");
			webActions.waitForVisibility(lbl_P2PHistoryTitle, "Title");
			webActions.waitForVisibility(lbl_P2PHistoryDate, "Date");
			String previousMsg=webActions.getText(lbl_P2PHistoryMessage, "HistoryRecord");			
			if(previousMsg.contentEquals(expMsg)){
				report.reportPass("Verified previous history status message successfully");
				webActions.click(lbl_P2PHistoryMessage, "HistoryRecord");
				webActions.waitForVisibility(txt_P2PFullPanelMsg, "Message");
			}
			else{
				report.reportFail("Fail to verfiy previous history message and displayed message is : " + previousMsg);
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void closeHistory(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_P2POtherOption, "OtherOption");
			webActions.waitForVisibility(btn_P2PHistory, "History");
			webActions.click(btn_P2PHistory, "History");
			webActions.waitForVisibility(lbl_P2PHistoryTitle, "Title");
			webActions.waitForVisibility(lbl_P2PHistoryDate, "Date");
			webActions.click(btn_P2PHistoryClose, "CrossOption");
			webActions.waitForPageLoaded();
			webActions.assertDisplayed(btn_P2PRunCreditCheck, "RunCredit");
			report.reportPass("Close the history window successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyCreditReport(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_P2POtherOption, "OtherOption");
			webActions.waitForVisibility(btn_P2PCreditReport, "creditReport");
			webActions.click(btn_P2PCreditReport, "creditReport");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_P2PCreditReportDownload, "Down");
			webActions.click(btn_P2PCreditReportCancel, "Cancel");
			webActions.waitForPageLoaded();
			webActions.assertDisplayed(btn_P2PRunCreditCheck, "RunCredit");
			report.reportPass("Verified Credit report");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
