package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.AlertPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class AlertSteps {
	AlertPage alert=new AlertPage();

	@Then("Click on bell icon and verify the display of window")
	public void click_on_bell_icon_and_verify_the_display_of_window() {
		alert.verifyNotificationsWindow();
	}
	@Then("Verify the alerts count")
	public void verify_the_alerts_count() {
		alert.verifyAlertsCount();
	}
	@Then("Click on notifications icon")
	public void click_on_notifications_icon() {
		alert.clickOnBellIcon();
	}	
	@Then("Click on {string} and verify the navigation")
	public void click_on_and_verify_the_navigation(String moduleName) {
		alert.verifyNavigation(moduleName);
	}
	
	@Then("Click on Account search and notifications bell icon")
	public void click_on_Account_search_and_notifications_bell_icon() {
	   alert.clickAccountSearchLinkAndBellIcon();
	}
}
