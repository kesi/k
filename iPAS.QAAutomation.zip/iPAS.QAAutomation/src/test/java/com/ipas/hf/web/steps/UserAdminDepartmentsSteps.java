package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.UserAdminDepartmentPages;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class UserAdminDepartmentsSteps {
	
	UserAdminDepartmentPages department=new UserAdminDepartmentPages();
	
	@Then("Select the option as {string} from Settings")
	public void select_the_option_as_from_Settings(String option) throws InterruptedException {		
	 department.selectOptionfromSettingsList(option);
	}
	@Then("Verify the display of content on the pop up")
	public void verify_the_display_of_content_on_the_pop_up(DataTable testData) {
	   department.verifyContentOnPopUp(testData);
	}

	@Then("Veirfy the display of facility departments on the pop up")
	public void veirfy_the_display_of_facility_departments_on_the_pop_up(DataTable testData) {
	 department.verifyFacilityDepartmentsOnPopUp(testData);
	}
	
	@Then("Select the facility depart as {string} from department pop up and verify the iPAS header")
	public void select_the_facility_depart_as_from_department_pop_up_and_verify_the_iPAS_header(String card,DataTable testData) {
		department.clickOnDepartmentCards(card);		
	   department.verifyFacilityDepartmentAtiPAS(testData);
	}
	@Then("Verify the Apply button")
	public void verify_the_Apply_button() {
	   department.verifyApplyBtn();
	}

}
