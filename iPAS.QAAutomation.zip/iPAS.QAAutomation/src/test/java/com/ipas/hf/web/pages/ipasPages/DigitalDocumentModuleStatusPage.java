package com.ipas.hf.web.pages.ipasPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.BasePage;

public class DigitalDocumentModuleStatusPage extends BasePage{

	@FindBy(xpath = "//app-ipas-document-management-pannel/div/ejs-accordion/div/div[1]/div[1]/div/img")
	private WebElement lbl_DigitalDocumentPanelStatus;

	@FindBy(xpath = "//div[@id='document-manager-page']/div/div[1]/div/span/img")
	private WebElement lbl_DigitalDocumentWindowStatus;

	@FindBy(xpath = "//div[@id='detail-document-table']/div/ejs-listview/div/ul/li/div")
	private WebElement tbl_DDMPage ;

	@FindBy(xpath="//button[text()='Change Status']")
	private WebElement btn_ChangeStatus;

	@FindBy(xpath="//div[@ id='document-viewer-section']/div[1]/span/img")
	private WebElement lbl_DocsAndFormsStatus;

	@FindBy(xpath="//div[@id='detail-document-table']/div[1]//div[@class='e-list-item-header']/span/img")
	private WebElement lbl_DocsAndFormsStatusInPage;

	@FindBy(xpath="//select[@id='status']")
	private WebElement dd_Status;

	@FindBy(xpath="//button[@class='btn btn-light btn-xs'][(text()='Change Status')]")
	private WebElement btn_ChangeStatus_Popup;

	public DigitalDocumentModuleStatusPage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyDigitalDocumentPanelStatus(){
		try {
			webActions.waitForLoad();
			String actdefaultDigitalStatus=webActions.getAttributeValue(lbl_DigitalDocumentPanelStatus, "src", "DigitalPanel");
			if(actdefaultDigitalStatus.contains("error")){
				report.reportPass("Default digital document panel status is displayed as pending mode");
			}			
			else if(actdefaultDigitalStatus.contains("success")){
				report.reportPass("Default digital document panel status is displayed as clear mode");
			}
			else{
				report.reportFail("Default digital document panel status is not displayed as pending/clear mode and actual displayed image is : " + actdefaultDigitalStatus);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDigitalDocumentWindowStatus(){
		try {
			String actdefaultDigitalStatus=webActions.getAttributeValue(lbl_DigitalDocumentWindowStatus, "src", "DigitalDocumentWindow");
			if(actdefaultDigitalStatus.contains("error")){
				report.reportPass("Default digital document window status is displayed as pending mode");
			}
			else{
				report.reportFail("Default digital document window status is not displayed as pending mode and actual displayed image is : " + actdefaultDigitalStatus);
			}		
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDocumentAndForsStatusinDigitalDocumentsMangerPage() throws Exception{
		try {

			webActions.waitForVisibility(tbl_DDMPage, "DDMPage");				
			for (int i =1; i <=5; i++) {
				if(i==2||i==4||i==5){				
					String xpath1="//*[@id='document-list']//ul/li";
					String xpath2="/div/ejs-checkbox";			
					webActions.clickAction(driver.findElement(By.xpath(xpath1+"["+i+"]"+xpath2)), "documents");
					String actDocsAndFormsStatusInPanel=webActions.getAttributeValue(lbl_DocsAndFormsStatusInPage, "src", "DocsAndForms");					
					webActions.waitForVisibility(btn_ChangeStatus, "ChangeStatus");
					String actDocsAndFormsStatus=webActions.getAttributeValue(lbl_DocsAndFormsStatus, "src", "DocsAndForms");
					if((actDocsAndFormsStatusInPanel.contains("error") )&& (actDocsAndFormsStatus.contains("error"))){
						report.reportPass("default docs and forms displayed in pending mode");
					}
					else{
						report.reportFail("default docs and forms is not displayed in pending mode and actual displayed image is : " +actDocsAndFormsStatus );
					}

				}
			}			
			for (int i =1; i <=11; i++) {
				if(i==2||i==3||i==4||i==5||i==6||i==8||i==9||i==10||i==11){				
					String xpath1="//*[@id='form-list']//ul/li";
					String xpath2="/div/ejs-checkbox";			
					webActions.clickAction(driver.findElement(By.xpath(xpath1+"["+i+"]"+xpath2)), "documents");
					String actDocsAndFormsStatusInPanel=webActions.getAttributeValue(lbl_DocsAndFormsStatusInPage, "src", "DocsAndForms");	
					webActions.waitForVisibility(btn_ChangeStatus, "ChangeStatus");
					String actDocsAndFormsStatus=webActions.getAttributeValue(lbl_DocsAndFormsStatus, "src", "DocsAndForms");
					if((actDocsAndFormsStatusInPanel.contains("error") )&& (actDocsAndFormsStatus.contains("error"))){
						report.reportPass("default docs and forms displayed in pending mode");
					}
					else{
						report.reportFail("default docs and forms is not displayed in pending mode and actual displayed image is : " +actDocsAndFormsStatus );
					}					
				}

			}		
		} catch (Exception e) {	
			report.reportFail(e.getMessage());			
		}
	}


	public void verifyDocumentAndFormsStatus() throws Exception{
		try {

			webActions.waitForVisibility(tbl_DDMPage, "DDMPage");				
			for (int i =1; i <=5; i++) {
				if(i==2||i==4||i==5){				
					String xpath1="//*[@id='document-list']//ul/li";
					String xpath2="/div/ejs-checkbox";			
					webActions.clickAction(driver.findElement(By.xpath(xpath1+"["+i+"]"+xpath2)), "documents");
					webActions.waitForVisibility(btn_ChangeStatus, "ChangeStatus");
					webActions.waitAndClick(btn_ChangeStatus, "ChangeStatus");
					Thread.sleep(5000);
					webActions.selectByVisibleText(dd_Status, "Complete", "Status Dropdown");
					Thread.sleep(5000);
					webActions.waitAndClick(btn_ChangeStatus_Popup, "Change Status Popup");
					Thread.sleep(10000);
					String actDocsAndFormsStatusInPanel=webActions.getAttributeValue(lbl_DocsAndFormsStatusInPage, "src", "DocsAndForms");					
					String actDocsAndFormsStatus=webActions.getAttributeValue(lbl_DocsAndFormsStatus, "src", "DocsAndForms");
					if((actDocsAndFormsStatusInPanel.contains("success") )&& (actDocsAndFormsStatus.contains("success"))){
						report.reportPass("Documents and Forms status got cleared");
					}
					else{
						report.reportFail("Document and Forms status is not displayed in clear mode and actual displayed image is : " +actDocsAndFormsStatus );
					}

				}
			}			
			for (int i =1; i <=11; i++) {
				if(i==2||i==3||i==4||i==5||i==6||i==8||i==9||i==10||i==11){				
					String xpath1="//*[@id='form-list']//ul/li";
					String xpath2="/div/ejs-checkbox";			
					webActions.clickAction(driver.findElement(By.xpath(xpath1+"["+i+"]"+xpath2)), "documents");
					webActions.waitForVisibility(btn_ChangeStatus, "ChangeStatus");
					webActions.waitAndClick(btn_ChangeStatus, "ChangeStatus");
					Thread.sleep(5000);
					webActions.selectByVisibleText(dd_Status, "Complete", "Status Dropdown");
					Thread.sleep(5000);
					webActions.waitAndClick(btn_ChangeStatus_Popup, "Change Status Popup");
					Thread.sleep(10000);
					String actDocsAndFormsStatusInPanel=webActions.getAttributeValue(lbl_DocsAndFormsStatusInPage, "src", "DocsAndForms");					
					String actDocsAndFormsStatus=webActions.getAttributeValue(lbl_DocsAndFormsStatus, "src", "DocsAndForms");
					if((actDocsAndFormsStatusInPanel.contains("success") )&& (actDocsAndFormsStatus.contains("success"))){
						report.reportPass("Documents and Forms status got cleared");
					}
					else{
						report.reportFail("Document and Forms status is not displayed in clear mode and actual displayed image is : " +actDocsAndFormsStatus );
					}

				}
			}		
		} catch (Exception e) {	
			report.reportFail(e.getMessage());			
		}
	}
	public void verifyDigitalDocumentManagerWindowStatus(){
		try {
			String actDigitalStatus=webActions.getAttributeValue(lbl_DigitalDocumentWindowStatus, "src", "DigitalDocumentManagerWindow");
			if(actDigitalStatus.contains("success")){
				report.reportPass("Digital document manager window status is displayed as clear mode");
			}
			else{
				report.reportFail("Digital document window status is not displayed as clear mode and actual displayed image is : " + actDigitalStatus);
			}		
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
