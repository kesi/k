package com.ipas.hf.web.pages.ipasPages;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.web.pages.BasePage;
import com.rajatthareja.reportbuilder.Report;

import io.cucumber.datatable.DataTable;

public class EstimatorNonSelfPage extends BasePage {

	@FindBy(xpath = "//ipas-estimator-short-pannel//img")
	private WebElement img_EstimatorShortPanel;

	@FindBy(xpath="(//ipas-estimator-short-pannel//span[1])[3]")
	public WebElement txt_EstimatorShortPanelMsg;

	@FindBy(xpath="(//ipas-estimator-short-pannel//span[1])[2]")
	public WebElement icon_EstimatorExpandCollapse;

	@FindBy(xpath="(//ipas-estimator-short-pannel//span[1])[1]//a")
	public WebElement txt_EstimatorShortPanelTitle;

	@FindBy(xpath="//ipas-estimator-short-pannel//span[@hideauthorize='CreateEstimate']")
	public WebElement icon_EstimatorShortPanelSearchIcon;

	@FindBy(xpath="//ipas-estimator-search-estimate//button[1]")
	public WebElement btn_PTCEstimatorWndowCancel;

	@FindBy(xpath="//ipas-estimator-search-estimate//button[2]")
	public WebElement btn_PTCEstimatorWndowAddEstimate;

	@FindBy(xpath="//td[contains(text(),'No records to display')]")
	public WebElement txt_PTCEstimatorWndowMsg;

	@FindBy(xpath="//span[contains(text(),'PTC Ref #')]")
	public WebElement txt_PTCEstimatorWndowheader;

	@FindBy(xpath="//ipas-estimator-run-estimate-container//div[@class='title']/span")
	public WebElement txt_EstimatorFullPageTitle;

	@FindBy(xpath="//ipas-estimator-run-estimate-container//financial-clearance-status/img")
	public WebElement txt_EstimatorFullPageModule;

	@FindBy(xpath="//span[contains(text(),'Visit Details')]")
	public WebElement lbl_EstimatorFullPageVisit;

	@FindBy(xpath="//div[@class='contain-text self-pay-title'][1]")
	public WebElement lbl_EstimatorFullPageFacility;

	@FindBy(xpath="//div[@class='contain-text self-pay-title'][2]")
	public WebElement lbl_EstimatorFullPageProvider;

	@FindBy(xpath="(//div[@class='contain-value self-pay-value'][1])[1]")
	public WebElement txt_EstimatorFullPageFacilityName;

	@FindBy(xpath="(//div[@class='contain-value self-pay-value'][1])[2]")
	public WebElement lbl_EstimatorFullPageProviderName;

	@FindBy(xpath="//span[contains(text(),'Estimate Summary')]")
	public WebElement lbl_EstimateSummary;

	@FindBy(xpath="//span[contains(text(),'Eligible')]")
	public WebElement lbl_EstimateEligibilityStatus;

	@FindBy(xpath="//span[contains(text(),'Health Benefit Plan Coverage')]")
	public WebElement lbl_BenefitType;

	@FindBy(xpath="//ipas-estimator-non-self-estimate-presenter/div[2]/div/div")
	public WebElement lbl_EstimateSummarySection;

	@FindBy(xpath="(//div[@class='pull-left']//button)[1]")
	public WebElement btn_EstimateCancelBtn;

	@FindBy(xpath="(//div[@class='pull-left']//button)[2]")
	public WebElement btn_EstimateSaveBtn;

	@FindBy(xpath="(//div[@class='pull-left']//button)[3]")
	public WebElement btn_EstimateConfirmBtn;

	@FindBy(xpath="//a[contains(text(),'Add New CPT')]")
	public WebElement lnk_EstimateAddCPT;

	@FindBy(xpath = "//ipas-estimator-run-estimate-container//financial-clearance-status/img")
	private WebElement img_EstimatorFullPanel;

	@FindBy(xpath="//span[contains(text(),'Not Run')]")
	public WebElement txt_EstimatorFullPanelMsg;

	@FindBy(xpath="//ipas-estimator-non-self-estimate-presenter//div[@class='contain-text border-1']/div[1]")
	public WebElement lbl_EstimatorInsuarncePlanName;

	@FindBy(xpath="//ipas-estimator-non-self-estimate-presenter//span/i")
	public WebElement lbl_EstimatorRunTime;

	@FindBy(xpath="//ipas-eligibility-verification-eligibility-status-panel//span/i")
	public WebElement lbl_EligibilityRunTime;

	@FindBy(xpath="//ipas-estimator-non-self-estimate-presenter//a[contains(text(),'Go to Eligibility')]")
	public WebElement Icon_GoToEligibility;

	@FindBy(xpath="//ipas-estimator-non-self-estimate-presenter//a[contains(text(),'View Benefits')]")
	public WebElement Icon_ViewBenefits;

	@FindBy(xpath="//div[contains(@class,'e-tab-wrap')]")
	private List<WebElement> tabs_AllInsurances;

	@FindBy(xpath="//button[(text()='Recheck Eligibility')]")
	private WebElement btn_RecheckEligibility;

	@FindBy(xpath="//div[contains(text(),'Secondary - ')]")
	private WebElement tab_Secondary;

	@FindBy(xpath="//a[contains(text(),'Estimator')]")
	private WebElement lnk_Estimator;	

	@FindBy(xpath="//ipas-eligibility-verification-eligibility-status-panel//div[@class='pay-section']/div")
	private WebElement lbl_EligibilityBenefitInfor;

	@FindBy(xpath="//ipas-estimator-view-estimate-withprocedures//div[@class='row cptfont']/div")
	private String lbl_EmrCptInfo;

	@FindBy(xpath="//td[contains(text(),'No records to display')]")
	public WebElement lbl_AddCPTWindow;

	@FindBy(xpath="//ipas-medical-necessity-cpt-icd-footer//button[1]")
	public WebElement btn_AddCPTWindowCancel;

	@FindBy(xpath="//ipas-medical-necessity-cpt-icd-footer//button[2]")
	public WebElement btn_AddCPTWindowSave;

	@FindBy(xpath="//input[@name='search_text']")
	public WebElement txt_AddCPTWindowSearch;

	@FindBy(xpath="(//input[@name='search_text'])[2]")
	public WebElement txt_RevCodeWindowSearch;

	@FindBy(xpath="(//input[@name='search_text'])[1]")
	public WebElement txt_RevCodeWindowSearch_EditCpt;

	@FindBy(xpath="(//ipas-medical-necessity-cpt-icd-grid//tr/td)[4]")
	public WebElement lbl_CPTWindowSearchResults;

	@FindBy(xpath="//ejs-radiobutton/label/span")
	public WebElement btn_CPTWindowSearchResults;

	@FindBy(xpath="//button[contains(text(),'New Estimate')]")
	public WebElement btn_NewEstimate;

	@FindBy(xpath="//button[contains(text(),'All Estimates')]")
	public WebElement btn_AllEstimates;

	@FindBy(xpath="//ipas-estimator-view-estimate-withprocedures//div[@class='row cptfont']/div[5]/div/img")
	public WebElement Icon_DeleteCPT;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;

	@FindBy(xpath = "//div[@class='breadcrum-container noprint']/span[2]/a")
	private WebElement lnk_AccountNumber;

	@FindBy(xpath="//span[contains(text(),'No payment has created yet')]")
	private WebElement lbl_NoPayments;

	@FindBy(xpath="//ipas-payment-facilitator-pannel/ejs-accordion/div")
	private WebElement tbl_PaymentFacilitatorPanel;

	@FindBy(xpath="//div[@id='three']//app-ipas-document-management-pannel/div/ejs-accordion/div/div[2]/div/div/ul/li/div[1]")
	private List<WebElement> lbl_DigitalDocMangerPanel;

	@FindBy(xpath="//ejs-accordion/div[1]/div[2]/div/div/ul/li/div[2]")
	private WebElement lbl_DataInAllDataPanel;

	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[2]")
	private List<WebElement> lbl_VisitSummaryData;

	@FindBy(xpath="//ejs-accordion[2]//table[7]/tr/td[1]/span[1]/span")
	private WebElement lbl_CPTCode1;

	@FindBy(xpath="//ejs-accordion[2]//table[7]/tr/td[1]/span[2]/span")
	private WebElement lbl_CPTCode2;

	@FindBy(xpath="//a[contains(text(),'Add Items')]")
	private WebElement lnk_AddItems;

	@FindBy(xpath="(//ipas-medical-necessity-cpt-icd-header//h5)[2]")
	private WebElement lbl_ChargeMasterWindowTitle;


	@FindBy(xpath="//ipas-medical-necessity-cpt-icd-header//h5")
	private WebElement lbl_EditChargeMasterWindowTitle;

	@FindBy(xpath="//span[contains(text(),'Enter minimum 3 characters')]")
	private WebElement lbl_CptValidationMsg;
	@FindBy(xpath="(//ipas-medical-necessity-cpt-icd-footer//button[1])[2]")
	public WebElement btn_AddChargeWindowCancel;

	String tr_CPTCode="//td[contains(text(),'";

	String tr_CPTCode1="')]";

	@FindBy(xpath="(//table[@class='e-table']//ejs-radiobutton)[1]//span")
	private WebElement rd_RevCode;

	@FindBy(xpath="//button[contains(text(),'Add')]")
	private WebElement Btn_RevCodeAdd;

	@FindBy(xpath="//span[contains(text(),'Added by User')]")
	private WebElement lbl_RevCodeMsg;

	@FindBy(xpath="(//ipas-estimator-view-estimate-withprocedures//a)[2]")
	public WebElement lnk_EditCPTWindow;

	@FindBy(xpath="//ejs-radiobutton/label/span")
	public WebElement btn_EditCPTWindow;

	@FindBy(xpath="(//input[@name='search_text'])[1]")
	public WebElement txt_RevCodeEditCptWindowSearch;

	/*@FindBy(xpath="(//ipas-estimator-view-estimate-withprocedures//img)[3]")
	public WebElement lnk_BundleCPT;*/

	@FindBy(xpath="(//img[@src='assets/images/up-arrow.png'])[1]")
	public WebElement lnk_BundleCPT;

	@FindBy(xpath="(//ejs-checkbox//span[@class='e-icons e-frame e-check'])[1]")
	public WebElement Btn_RevCodeRadioBtn;

	@FindBy(xpath="//tbody/tr[1]/td[3]//input")
	public WebElement Txt_Units;

	@FindBy(xpath="//td[@aria-label=' is template cell column header Amount']/div")
	public WebElement Lbl_RevAmount;

	@FindBy(xpath="//span[@class='pull-right']")
	public WebElement Lbl_CPTAmount;

	@FindBy(xpath="//ipas-estimator-view-estimate-withprocedures//div[@class='row cptfont']/div[6]/span")
	public WebElement Lbl_EstimatePageCPTAmount;

	@FindBy(xpath="//ipas-estimator-view-estimate-withprocedures//div[@class='row']/div[5]/span")
	public WebElement Lbl_EstimatePageRevAmount;

	@FindBy(xpath="//ipas-estimator-view-estimate-withprocedures//div[@class='row']/div[4]")
	public WebElement Lbl_EstimatePageRevUnit;	

	@FindBy(xpath="//ipas-estimator-estimator-benefits-nonmedicare//p[@class='sub-title']")
	public List<WebElement> Lbl_DefaultBenefits;

	@FindBy(xpath="//ipas-estimator-estimator-benefits-nonmedicare//p[@class='item-title']")
	public List<WebElement> Lbl_DefaulserviceName;

	@FindBy(xpath="//ipas-estimator-estimator-benefits-nonmedicare//p[@style='margin-bottom: 0px;']")
	public List<WebElement> Lbl_DefaulBenefistAmt;

	@FindBy(xpath="(//ipas-estimator-view-estimate-withprocedures//div[@class='row cptfont']/div[6]/span)")
	public List<WebElement> Lbl_CPTAmounts;

	@FindBy(xpath="(//ipas-estimator-view-estimate-withprocedures//div[@class='row']/div[5]/span)")
	public List<WebElement> Lbl_RevCodeAmounts;

	@FindBy(xpath="(//ipas-estimator-calculate-amount//div[@id='facilityData']//div[@class='detailsText'])[2]")
	public WebElement Lbl_EstimateChargeAmount;

	@FindBy(xpath="(//ejs-numerictextbox[@max='9999999.99'])[1]/span/input[1]")
	private WebElement lbl_EstimatedAllowableAmount;	

	@FindBy(xpath="(//ejs-numerictextbox[@max='9999999.99'])[2]/span/input[1]")
	private WebElement lbl_CoPay;	

	@FindBy(xpath="(//ejs-numerictextbox[@max='9999999.99'])[3]/span/input[1]")
	private WebElement lbl_Deductible;	

	@FindBy(xpath="(//ejs-numerictextbox[@max='9999999.99'])[4]/span/input[1]")
	private WebElement lbl_CoInsurance;

	String coPay="(//ejs-numerictextbox[@max='9999999.99'])[";
	String value="]/span/input[1]";

	@FindBy(xpath="(//ipas-estimator-calculate-amount//div[@id='facilityData']//div[@class='detailsText'])[6]")
	public WebElement Lbl_EstimateBeforeDiscountAmount;

	@FindBy(xpath="//ejs-dropdownlist[@id='estimateDiscount']/span/input")
	private WebElement dd_EstimateDiscount;

	@FindBy(xpath="//div[@class='col patientTotal']/div[2]")
	private WebElement lbl_PatientTotal;

	@FindBy(xpath="//div[@class='totalResponsibility']/div[2]")
	private WebElement lbl_PatientResponsibility;

	@FindBy(xpath="(//ipas-estimator-estimator-benefits-nonmedicare//ejs-accordion//span[@class='e-tgl-collapse-icon e-icons'])[2]")
	private WebElement Icon_BloodCharges;

	@FindBy(xpath="(//td/input[@type='radio'])[2]")
	private WebElement btn_BloodCharges_CoPay;	

	@FindBy(xpath="(//td/input[@type='radio'])[9]")
	private WebElement btn_HospoitalFamility_CoInsurance;

	@FindBy(xpath="(//ipas-estimator-estimator-benefits-nonmedicare//ejs-accordion//span[@class='e-tgl-collapse-icon e-icons'])[2]")
	private WebElement Icon_Hospital;

	@FindBy(xpath="//button[contains(text(),'Save Changes')]")
	private WebElement btn_BenefitsSave;

	@FindBy(xpath="//ipas-estimator-estimator-benefits-nonmedicare//button[contains(text(),'Cancel')]")
	private WebElement btn_Cancel;

	@FindBy(xpath="//button[contains(text(),'Send To Digital Document')]")
	private WebElement btn_SendToDD;

	@FindBy(xpath="//button[@id='input_2']")
	private WebElement btn_FormSubmit;

	@FindBy(xpath="//div[@id='detail-document-table']/div[1]//div[@class='e-list-item-header']/span/img")
	private WebElement lbl_DocsAndFormsStatusInPage;

	@FindBy(xpath="//div[@ id='document-viewer-section']/div[1]/span/img")
	private WebElement lbl_DocsAndFormsStatus;

	@FindBy(xpath = "//app-ipas-document-management-pannel/div/ejs-accordion/div/div[1]/div[1]/div/img")
	private WebElement lbl_DigitalDocumentPanelStatus;

	@FindBy(xpath = "//div[@id='document-manager-page']/div/div[1]/div/span/img")
	private WebElement lbl_DigitalDocumentWindowStatus;


	public EstimatorNonSelfPage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyEstimatorShortPanelStatus(String status){
		try {
			String estimatorShortPanelStatus=webActions.getAttributeValue(img_EstimatorShortPanel, "src", "EstimatorStatus");
			if("NeedsAttention".contentEquals(status)){				
				if(estimatorShortPanelStatus.contains("error_sm")){
					report.reportPass("Verified estimator short panel status mode successfully");
				}
				else{
					report.reportFail("Fail to verify estimator short panel status and actual displayed image is : " + estimatorShortPanelStatus);
				}
			} 
		}
		catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyEstimatorShortPanelMsg(String msg){
		try {
			String estimatorShortPanelMsg=webActions.getText(txt_EstimatorShortPanelMsg, "EstimatorMsg");					
			if(estimatorShortPanelMsg.contains(msg)){
				report.reportPass("Verified estimator short panel message successfully");
			}
			else{
				report.reportFail("Fail to verify estimator short panel message and actual displayed msg is : " + estimatorShortPanelMsg);
			}

		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyExpandandCollapsePanel() throws Exception{
		StringBuilder unmatch=new StringBuilder();					
		String actualExpandStatus=webActions.getAttributeValue(icon_EstimatorExpandCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons e-expand-icon".contentEquals(actualExpandStatus)){
			report.reportPass("By default Estimator Panel is displayed in Expand mode");
		}else{
			unmatch.append("Panle is not dispalyed in Expand mode by default");
			report.reportFail("Panle is not dispalyed in Expand mode by default");
		}
		webActions.waitAndClick(icon_EstimatorExpandCollapse, "ExpandandCollapse");
		webActions.waitForPageLoaded();
		String actualCollapseStatus=webActions.getAttributeValue(icon_EstimatorExpandCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons".contentEquals(actualCollapseStatus)){
			report.reportPass("Estimator Panel Successfully Collapsed");
		}
		else{
			unmatch.append("Estimator Panle is not Collapsed");
			report.reportFail("Estimator Panle is not Collapsed");
		}		
		if(unmatch.length()==0){
			report.reportPass("Estimator Panel Successfully Expanded and Collapsed");
		}else{
			report.reportFail("Failed to verify the Expand and Collapse of the Estimator Panel"+unmatch);
		}

	}	
	public void verifyEstimatorShortPanelTitle(String msg){
		try {
			String estimatorShortPanelMsg=webActions.getText(txt_EstimatorShortPanelTitle, "EstimatorTitle");					
			if(estimatorShortPanelMsg.contains(msg)){
				report.reportPass("Verified estimator short panel title successfully");
			}
			else{
				report.reportFail("Fail to verify estimator short panel title and actual displayed title is : " + estimatorShortPanelMsg);
			}

		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickSearchIconOnShortPanel(){
		try {
			webActions.clickAction(icon_EstimatorShortPanelSearchIcon, "SearchIcon");
			webActions.waitForPageLoaded();
			//webActions.waitForVisibility(txt_PTCEstimatorWndowMsg, "PTCWindowMsg");
			webActions.waitForVisibility(btn_PTCEstimatorWndowAddEstimate, "PTCWindowAddEstimate");
			webActions.waitForVisibility(btn_PTCEstimatorWndowCancel, "PTCWindowAddCancel");
			webActions.clickAction(btn_PTCEstimatorWndowCancel, "PTCWindowAddCancel");
			webActions.waitForPageLoaded();
			String act=webActions.getText(txt_PTCEstimatorWndowheader, "headercolumn");
			if(act.contentEquals("PTC Ref #")){
				report.reportPass("Successfully navigated to the PTC window");
			}
			else{
				report.reportFail("Fail to navigate to teh PTC window");
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnEstimatorShortPanel(){
		try {
			webActions.waitForVisibility(txt_EstimatorShortPanelTitle, "TitleLink");
			webActions.clickAction(txt_EstimatorShortPanelTitle, "TitleLink");
			webActions.waitForPageLoaded();
			waitForPageLoade(5);
			webActions.waitForVisibility(txt_EstimatorFullPageModule, "ModuleStatus");
			webActions.waitForVisibility(lnk_EstimateAddCPT, "AddCPT");
			webActions.waitForVisibility(btn_EstimateCancelBtn, "CancelBtn");
			webActions.waitForPageLoaded();
			report.reportInfo("Successfully navigated to the Estimator full page");

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyEstimatorFullPanelStatus(String status){
		try {
			String estimatorShortPanelStatus=webActions.getAttributeValue(img_EstimatorFullPanel, "src", "EstimatorStatus");
			if("NeedsAttention".contentEquals(status)){				
				if(estimatorShortPanelStatus.contains("error_sm")){
					report.reportPass("Verified estimator full panel status mode successfully");
				}
				else{
					report.reportFail("Fail to verify estimator full panel status and actual displayed image is : " + estimatorShortPanelStatus);
				}
			} 
		}
		catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyEstimatorFullPanelMsg(String msg){
		try {
			String estimatorShortPanelMsg=webActions.getText(txt_EstimatorFullPanelMsg, "EstimatorMsg");					
			if(estimatorShortPanelMsg.contains(msg)){
				report.reportPass("Verified estimator full panel message successfully");
			}
			else{
				report.reportFail("Fail to verify estimator full panel message and actual displayed msg is : " + estimatorShortPanelMsg);
			}

		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyEstimatorFullPage(DataTable testData){	

		try {
			ArrayList<String> actualData = new ArrayList<>();
			ArrayList<String> expectedData = new ArrayList<>(testData.asList());
			report.reportInfo("Expected Summary Info Fields: "+expectedData);
			actualData.add(webActions.getText(txt_EstimatorFullPageFacilityName, "facilityName"));
			actualData.add(webActions.getText(lbl_EstimateEligibilityStatus, "EligibilityStatus"));
			actualData.add(webActions.getText(lbl_BenefitType, "BenefitType"));
			report.reportInfo("Displayed Summary Fields in Application: "+actualData);
			ArrayList<String>unmatchedSummarFields=webActions.getUmatchedInArrayComparision(actualData, expectedData);
			if(unmatchedSummarFields.size()==0){
				report.reportPass("Verified fields from estimator full page");
			}
			else{
				throw new Exception("Fail to verify fields from estimator full page and unmatched fields are: "+unmatchedSummarFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	public void verifyProviderName(){
		try {
			webActions.waitForPageLoaded();
			String actualProviderName=webActions.getText(lbl_EstimatorFullPageProviderName, "ProviderInfo").trim();
			String expProviderName=webActions.notepadRead("hello").trim();
			report.reportInfo("Expected provider name:" + expProviderName);
			report.reportInfo("Actual provider name:" + actualProviderName);
			if(actualProviderName.contentEquals(expProviderName)){
				report.reportPass("Verified provider name successfully");
			}
			else{
				report.reportFail("Fail to verify provider name and displayed name is: " + actualProviderName);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyPlanName(){
		try {
			webActions.waitForPageLoaded();
			String actualPlanName=webActions.getText(lbl_EstimatorInsuarncePlanName, "PlanName").trim();
			String expPlanName=webActions.notepadRead("hello").trim();
			report.reportInfo("Expected paln name:" + expPlanName);
			report.reportInfo("Actual plan name:" + actualPlanName);
			if(actualPlanName.contentEquals(expPlanName)){
				report.reportPass("Verified plan name successfully");
			}
			else{
				report.reportFail("Fail to verify plan name and displayed name is: " + actualPlanName);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void goToEligibility(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(Icon_GoToEligibility, "GoToEligibility");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(tabs_AllInsurances, "All Insurances");			
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibility(lbl_EligibilityBenefitInfor, "EligibilityInfo");
			Thread.sleep(3000);
			webActions.waitForVisibility(btn_RecheckEligibility, "Recheck Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyEligibilityRunTime(){
		try {
			goToEligibility();
			String eligibilityRunTime=webActions.getText(lbl_EligibilityRunTime, "EligibilityRunTime");
			webActions.clickAction(lnk_Estimator, "EstimatorLink");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txt_EstimatorFullPageModule, "ModuleStatus");
			webActions.waitForVisibility(lnk_EstimateAddCPT, "AddCPT");
			webActions.waitForVisibility(btn_EstimateCancelBtn, "CancelBtn");
			webActions.waitForPageLoaded();
			Thread.sleep(3000);
			report.reportInfo("Successfully navigated to the Estimator full page");
			report.reportInfo("Eligibility run time: " + eligibilityRunTime);
			String estimatorEligibilityRunTime=webActions.getText(lbl_EstimatorRunTime, "estimatorEligibilityRunTime");
			report.reportInfo("Estimator run time: " + estimatorEligibilityRunTime);
			if(eligibilityRunTime.contentEquals(estimatorEligibilityRunTime)){
				report.reportPass("Verified eligibility run time successfully");
			}
			else{
				report.reportFail("Fail to verifyeligibility run time and displayed time is: " + estimatorEligibilityRunTime);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyEMRCptCodeInfo(){
		ArrayList<String> expCptInfo=new ArrayList<>();
		ArrayList<String> actCptInfo=new ArrayList<>();
		try {
			for (int i = 1; i <=4; i++) {					
				actCptInfo.add(webActions.getText(driver.findElement(By.xpath("//ipas-estimator-view-estimate-withprocedures//div[@class='row cptfont']/div["+i+"]")), "cptInfo").trim());
			}
			expCptInfo=webActions.notepadReadToList("hello");
			ArrayList<String>unmatchedSummarFields=webActions.getUmatchedInArrayComparision(actCptInfo, expCptInfo);
			report.reportInfo("CPT infor from EMR: " +expCptInfo);
			report.reportInfo("CPT infor from Eestimate: " +actCptInfo);
			if(unmatchedSummarFields.size()==0){
				report.reportPass("Verified EMR cpt info successfully from estimate full page");
			}
			else{
				throw new Exception("Fail to verify EMR cpt info from estimator full page and unmatched fields are: "+unmatchedSummarFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void addCPTCode(String cptCode, String condition){
		try {
			waitForPageLoade(3);
			webActions.click(lnk_EstimateAddCPT, "AddCpt");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_AddCPTWindow, "CPTLabel");
			webActions.waitForVisibility(btn_AddCPTWindowCancel, "CPTCancel");
			waitForPageLoade(2);
			webActions.sendKeys(txt_AddCPTWindowSearch, cptCode, "cptSearchBox");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_CPTWindowSearchResults, "CPTSearchResults");
			webActions.click(lbl_CPTWindowSearchResults, "CPTSearchResults");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_CPTWindowSearchResults, "CPTLineItems");
			webActions.click(btn_CPTWindowSearchResults, "CPTLineItems");
			webActions.waitForPageLoaded();
			if("Save".contentEquals(condition)){
				webActions.waitForClickAbilityAndClick(btn_AddCPTWindowSave, "CPTSaveBtn");
				waitForPageLoade(2);
				report.reportPass("Add New CPT Successfully");
			}
			else if("AddItem".contentEquals(condition)){
				webActions.waitForClickAbilityAndClick(lnk_AddItems, "AddItem");
				webActions.waitForPageLoaded();
				waitForPageLoade(2);
				webActions.waitForVisibility(lbl_ChargeMasterWindowTitle, "Title");
				webActions.waitForPageLoaded();
				report.reportPass("Successfully navigated to the charge master window");
			}
			else{
				report.reportInfo("Condition did not match");
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void waitForPageLoade(int seconds){
		try {
			Thread.sleep(seconds*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public void deleteEMRCPTCode(){
		try {
			webActions.waitForPageLoaded();
			webActions.clickAction(Icon_DeleteCPT, "CPTdelete");
			webActions.waitForPageLoaded();
			String actAlertMsg=getAlertMessage();
			if("Deleted successfully.".contains(actAlertMsg)){
				report.reportPass("Deleted the CPT successfully");
			}else{
				report.reportFail("Fail to delete the cpt");
			}			
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public String getAlertMessage(){
		String actContent="";
		try {
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Alert Message");
			String[] titleContent=msg.split("\\n");
			actContent=titleContent[1];
		} catch (Exception e) {
		}
		return actContent;
	}
	public void clickEstimateSave(){
		try {
			webActions.clickAction(btn_EstimateSaveBtn, "EstimateSave");
			webActions.waitForPageLoaded();
			String actAlertMsg=getAlertMessage();
			if("Estimator saved successfully.".contains(actAlertMsg)){
				report.reportPass("Saved the estimate successfully successfully");
			}else{
				report.reportFail("Fail to save the estimate");
			}		
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void goToVisitMainPageFromEstimatorFullPage(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lnk_AccountNumber, "AccountNumber");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_DigitalDocMangerPanel, "DigitalDocs");			
			waitforPaymentFacilitatorPanel();
			report.reportInfo("Navigated to the Patient Visit Summary page");
			//webActions.refreshPage();
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_DataInAllDataPanel, "DataInAllData");
			webActions.waitForVisibilityOfAllElements(lbl_VisitSummaryData, "SummaryData");

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void waitforPaymentFacilitatorPanel() throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(lbl_NoPayments, "No Payments Error Message");
		} catch (Exception e) {
			webActions.waitForVisibility(tbl_PaymentFacilitatorPanel, "Payment Facilitator Panel");
		}
	}
	public void verifyProcedureCodesFromAllData(DataTable testData){
		ArrayList<String> expCpts=new ArrayList<>(testData.asList());
		ArrayList<String> actCpts=new ArrayList<>();
		try {		
			webActions.waitForPageLoaded();
			String cpt=webActions.getText(lbl_CPTCode1, "EMRCPT");
			int len=cpt.length();
			String emrCPT=cpt.substring(0, len-1);
			actCpts.add(emrCPT);
			actCpts.add(webActions.getText(lbl_CPTCode2, "iPASCPT"));
			report.reportInfo("Actual cpts codes: " +actCpts );
			report.reportInfo("Expected cpts codes: " +expCpts );
			ArrayList<String>unmatchedCPts=webActions.getUmatchedInArrayComparision(actCpts, expCpts);
			if(unmatchedCPts.size()==0){
				report.reportPass("Verified cpts from all data full page successfully");
			}
			else{
				throw new Exception("Fail to verify cpts from all data full page and unmatched cpts are: "+unmatchedCPts);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyValidationMsgInCptAndChargeMaster(String cptCode, String msg, String window){
		try {				
			String actualMsg="";
			if("CPT".contentEquals(window)){
				webActions.clearValue(txt_AddCPTWindowSearch, "cptSearchBox");
				waitForPageLoade(2);
				webActions.sendKeys(txt_AddCPTWindowSearch, cptCode, "cptSearchBox");
				webActions.pressTab();
				waitForPageLoade(3);
				actualMsg=webActions.waitAndGetText(lbl_CptValidationMsg, "ValidationMsg");
				webActions.waitAndClick(btn_AddCPTWindowCancel, "CPTCancel");
				webActions.waitForPageLoaded();
			}
			else if("ChargeMaster".contentEquals(window)){
				webActions.clearValue(txt_RevCodeWindowSearch, "ChargeMasterSearchBox");
				waitForPageLoade(2);
				webActions.sendKeys(txt_RevCodeWindowSearch, cptCode, "ChargeMasterSearchBox");
				webActions.pressTab();
				waitForPageLoade(3);
				actualMsg=webActions.waitAndGetText(lbl_CptValidationMsg, "ValidationMsg");
				webActions.waitAndClick(btn_AddChargeWindowCancel, "ChargeCancel");
				webActions.waitForPageLoaded();

			}
			
			if(msg.contentEquals(actualMsg)){
				report.reportPass("Successfully verified validation message");
			}
			else{
				report.reportFail("Fail to verify validation message");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void CptWindowSave(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForClickAbilityAndClick(btn_AddCPTWindowSave, "CPTSaveBtn");
			webActions.waitForPageLoaded();
			waitForPageLoade(3);
			report.reportPass("Add New CPT Successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void RevCodeWindowSave(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForClickAbilityAndClick(btn_AddCPTWindowSave, "CPTSaveBtn");
			webActions.waitForPageLoaded();
			waitForPageLoade(1);
			report.reportPass("Add New Rev code Successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void addRevCodes(String window,String type,String unit,DataTable testData){		
		try {
			ArrayList<String> revCodes=new ArrayList<String>(testData.asList());
			for (String revCode : revCodes) {
				report.reportInfo("Revenue Code: "+revCode);
				webActions.waitForLoad();
				if("AddCpt".contentEquals(window)){
					webActions.clearValue(txt_RevCodeWindowSearch, "RevSearchBox");
					waitForPageLoade(2);
					webActions.sendKeys(txt_RevCodeWindowSearch, revCode, "RevSearchBox");
				}
				else if ("EditCpt".contentEquals(window)){
					webActions.clearValue(txt_RevCodeEditCptWindowSearch, "RevSearchBox");
					waitForPageLoade(2);
					webActions.sendKeys(txt_RevCodeEditCptWindowSearch, revCode, "RevSearchBox");
				}
				webActions.waitForPageLoaded();
				waitForPageLoade(2);
				webActions.clickAction(Txt_Units, "unit");
				webActions.waitForPageLoaded();
				webActions.clearValue(Txt_Units, "unit");
				waitForPageLoade(1);
				webActions.sendKeys(Txt_Units, unit, "unit");
				waitForPageLoade(2);
				WebElement revCodeLine=driver.findElement(By.xpath(tr_CPTCode+revCode+tr_CPTCode1));
				revCodeLine.click();
				webActions.waitForPageLoaded();
				waitForPageLoade(2);
				//webActions.waitForVisibility(revCodeLine, "Rev Code", 10);
				//webActions.waitAndClick(revCodeLine, "Rev Code");
				ArrayList<String> amount=new ArrayList<>();
				amount.add(webActions.getText(Lbl_RevAmount, "RevCode amount"));
				webActions.click(Btn_RevCodeAdd, "Save");
				waitForPageLoade(2);
				String cptAmount=webActions.getText(Lbl_CPTAmount, "CPTCode amount");
				String cptAmt=cptAmount.substring(0, 5);
				amount.add(cptAmt);
				webActions.notepadWrite("hello", amount);
				if(type.contentEquals("Multiple")){
					webActions.waitForClickAbilityAndClick(lnk_AddItems, "AddItem");
					webActions.waitForPageLoaded();
					//webActions.waitForVisibility(lbl_ChargeMasterWindowTitle, "Title");
					waitForPageLoade(2);				
					report.reportPass("Successfully navigated to the charge master window");
				}
				else if (type.contentEquals("Single")){
					break;					
				}
			}
			waitForPageLoade(5);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyRevCodeMsg(String expMsg){
		try {
			waitForPageLoade(1);
			String actmsg=webActions.getText(lbl_RevCodeMsg, "RevCodeMsg");
			if(actmsg.contentEquals(expMsg)){
				report.reportPass("Verified rev code added message successfully");
			}
			else{
				report.reportFail("Fail to verify rev code message");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyAddedCptCodeInfo(DataTable dataTable){
		ArrayList<String> expCptInfo=new ArrayList<>(dataTable.asList());
		ArrayList<String> actCptInfo=new ArrayList<>();
		try {
			for (int i = 2; i <=5; i++) {					
				actCptInfo.add(webActions.getText(driver.findElement(By.xpath("//ipas-estimator-view-estimate-withprocedures//div[@class='row cptfont']/div["+i+"]")), "cptInfo").trim());
			}
			ArrayList<String>unmatchedSummarFields=webActions.getUmatchedInArrayComparision(actCptInfo, expCptInfo);
			report.reportInfo("CPT infor from EMR: " +expCptInfo);
			report.reportInfo("CPT infor from Eestimate: " +actCptInfo);
			if(unmatchedSummarFields.size()==0){
				report.reportPass("Verified added cpt info successfully from estimate full page");
			}
			else{
				throw new Exception("Fail to verify added cpt info from estimator full page and unmatched fields are: "+unmatchedSummarFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyRevenueCodeInfo(DataTable dataTable){
		ArrayList<String> expRevInfo=new ArrayList<>(dataTable.asList());
		ArrayList<String> actRevInfo=new ArrayList<>();
		try {
			for (int i = 1; i <=4; i++) {					
				actRevInfo.add(webActions.getText(driver.findElement(By.xpath("//ipas-estimator-view-estimate-withprocedures//div[@class='row']/div["+i+"]")), "cptInfo").trim());
			}	
			ArrayList<String>unmatchedSummarFields=webActions.getUmatchedInArrayComparision(actRevInfo, expRevInfo);
			report.reportInfo("Rev code info from expected: " +expRevInfo);
			report.reportInfo("Added Rev code info from Eestimate: " +actRevInfo);
			if(unmatchedSummarFields.size()==0){
				report.reportPass("Verified Revenue code info successfully from estimate full page");
			}
			else{
				throw new Exception("Fail to verify reenue code info from estimator full page and unmatched fields are: "+unmatchedSummarFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void EditCPTCode(String condition){
		try {
			webActions.waitForPageLoaded();			
			webActions.waitForVisibility(lnk_EditCPTWindow, "EditCPTLink");
			webActions.click(lnk_EditCPTWindow, "EditCPTLink");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_AddCPTWindowCancel, "CPTCancel");
			waitForPageLoade(5);			
			webActions.click(btn_EditCPTWindow, "EditCPTResults");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lnk_AddItems, "AddItem");
			if("Save".contentEquals(condition)){
				webActions.waitForClickAbilityAndClick(btn_AddCPTWindowSave, "CPTSaveBtn");
				webActions.waitForPageLoaded();
				report.reportPass("Add New CPT Successfully");
			}
			else if("AddItem".contentEquals(condition)){
				webActions.waitForClickAbilityAndClick(lnk_AddItems, "AddItem");
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(lbl_EditChargeMasterWindowTitle, "Title");
				webActions.waitForPageLoaded();
				report.reportPass("Successfully navigated to the charge master window");
			}
			else{
				report.reportInfo("Condition did not match");
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void expandCPTBundle(){
		try {
			waitForPageLoade(5);
			webActions.clickAction(lnk_BundleCPT, "BundleExpand");
			webActions.waitForPageLoaded();
			waitForPageLoade(3);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void unCheckTheFirstRevCode(){
		try {
			webActions.click(Btn_RevCodeRadioBtn, "RevCode");
			webActions.waitForPageLoaded();
			waitForPageLoade(1);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void cptRevAmountsCalculations(String unit){
		try {
			ArrayList<String> actAmts=new ArrayList<>();
			ArrayList<String> expAmts=new ArrayList<>();
			actAmts.add(webActions.getText(Lbl_EstimatePageRevAmount,"RevAmt"));
			actAmts.add(webActions.getText(Lbl_EstimatePageCPTAmount,"CPTAmt"));
			actAmts.add(unit);
			ArrayList<String> amts=webActions.notepadReadToList("hello");
			String revAmount=amts.get(0);
			String cptAmount=amts.get(1);			
			// removing first character 
			revAmount=revAmount.substring(1);	
			revAmount=revAmount.substring(0, 2);
			int i=Integer.parseInt(revAmount);
			int unitt=Integer.parseInt(unit);
			int rev=i*unitt;
			String revAm=Integer.toString(rev);
			String revAmt="$"+revAm+".00";
			expAmts.add(revAmt);
			expAmts.add(cptAmount);
			expAmts.add(webActions.getText(Lbl_EstimatePageRevUnit, "Revunit"));
			ArrayList<String>unmatchedSummarFields=webActions.getUmatchedInArrayComparision(actAmts, expAmts);
			report.reportInfo("Expected amounts info" +expAmts);
			report.reportInfo("Displyed amounts " +actAmts);
			if(unmatchedSummarFields.size()==0){
				report.reportPass("Verified cpt and Revenue code amounts successfully from estimate full page");
			}
			else{
				throw new Exception("Fail to verify cpt and revenue code amounts from estimator full page and unmatched fields are: "+unmatchedSummarFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickBenefitsIcon(){
		try {
			webActions.click(Icon_ViewBenefits, "BenefitsIcon");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(Lbl_DefaultBenefits, "BenefitsNames");
			waitForPageLoade(2);
			report.reportInfo("Successfully navigated to the benefits page");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyDefaultBenefits(DataTable dataTable){
		try {
			ArrayList<String> expBenefits=new ArrayList<>(dataTable.asList());
			ArrayList<String> actBenefits=new ArrayList<>();
			actBenefits=webActions.getDatafromWebTable(Lbl_DefaultBenefits);
			ArrayList<String>unmatchedSummarFields=webActions.getUmatchedInArrayComparision(actBenefits, expBenefits);
			report.reportInfo("Expected benefits: " +expBenefits);
			report.reportInfo("Actual benefits: " +actBenefits);
			if(unmatchedSummarFields.size()==0){
				report.reportPass("Verified default benefits from view benefits");
			}
			else{
				throw new Exception("Fail to verify default benefits and unmatched fields are: "+unmatchedSummarFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyBenefitsServcieName(String expData){
		try {

			ArrayList<String> actBenefitServiceName=new ArrayList<>();
			actBenefitServiceName=webActions.getDatafromWebTable(Lbl_DefaulserviceName);
			ArrayList<String>unmatchedSummarFields=webActions.isFullArrayMatchWithData(actBenefitServiceName, expData);
			report.reportInfo("Expected benefit service name: " +expData);
			report.reportInfo("Actual benefit service name: " +actBenefitServiceName);
			if(unmatchedSummarFields.size()==0){
				report.reportPass("Verified default benefits service name from view benefits");
			}
			else{
				throw new Exception("Fail to verify default benefits service name and unmatched fields are: "+unmatchedSummarFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyDefaultBenefitsAmounts(DataTable dataTable){
		try {
			ArrayList<String> expBenefits=new ArrayList<>(dataTable.asList());
			ArrayList<String> actBenefits=new ArrayList<>();
			actBenefits=webActions.getDatafromWebTable(Lbl_DefaulBenefistAmt);
			ArrayList<String>unmatchedSummarFields=webActions.getUmatchedInArrayComparision(actBenefits, expBenefits);
			report.reportInfo("Expected benefits ampounts: " +expBenefits);
			report.reportInfo("Actual benefits amounts: " +actBenefits);
			if(unmatchedSummarFields.size()==0){
				report.reportPass("Verified default benefits amounts from view benefits");
			}
			else{
				throw new Exception("Fail to verify default benefits amoiunts and unmatched fields are: "+unmatchedSummarFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void calculateEstimateChargeAmt(){
		try {
			Double cpts=0.00;
			Double revCodes=0.00;
			Double sumOfCptsRev=0.00;
			ArrayList<Double> sumOfCpts=getCPTCodeAmounts();			
			for(int i=0;i<sumOfCpts.size();i++){				
				cpts=cpts+sumOfCpts.get(i);
			}
			System.out.println("CPT amount: "+cpts);
			ArrayList<Double> sumOfRevCodes=getRevCodeAmounts();			
			for(int i=0;i<sumOfRevCodes.size();i++){				
				revCodes=revCodes+sumOfRevCodes.get(i);
			}
			System.out.println("Rev amount: "+revCodes);
			sumOfCptsRev=cpts+revCodes;
			DecimalFormat df = new DecimalFormat("#,##0.00");			
			String calculatedAmount=df.format(sumOfCptsRev);
			String estimatechargeamount=webActions.getText(Lbl_EstimateChargeAmount, "estimatechargeamount").replaceAll("[$]", "");
			report.reportInfo("Sum of cpts and rev code amounts:" +calculatedAmount);
			report.reportInfo("Estimatd charge amount:" +estimatechargeamount);
			if(calculatedAmount.contentEquals(estimatechargeamount)){
				report.reportPass("Verfied estimated charge amount successfully");
			}
			else{
				report.reportFail("Fail to verify estimated charge amount");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public ArrayList<Double> getCPTCodeAmounts(){
		ArrayList<Double> data= new ArrayList<Double>();
		try {
			webActions.waitForPageLoaded();
			List<WebElement> allElement = Lbl_CPTAmounts;
			for (WebElement we: allElement) { 
				String txt=we.getText().replaceAll("[$,]", "");
				txt=txt.substring(0, txt.length()-8).trim();
				data.add(Double.valueOf(txt));
			}			
			report.reportInfo("CPT Amounts: "+data);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
		return data;
	}
	public ArrayList<Double> getRevCodeAmounts(){
		ArrayList<Double> data= new ArrayList<Double>();
		try {
			webActions.waitForPageLoaded();
			List<WebElement> allElement = Lbl_RevCodeAmounts;
			for (WebElement we: allElement) { 
				String txt=we.getText().replaceAll("[$,]", "");
				data.add(Double.valueOf(txt));
			}			
			report.reportInfo("Rev code Amounts: "+data);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
		return data;
	}
	public void enterAllowableAmount(String amt){
		try {
			webActions.clearValue(lbl_EstimatedAllowableAmount, "AllowableAmount");
			waitForPageLoade(1);
			webActions.sendKeys(lbl_EstimatedAllowableAmount, amt, "AllowableAmount");
			webActions.pressTab();
			waitForPageLoade(2);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyCoPayCoInsuranceDeductible(DataTable dataTable){
		try {
			ArrayList<String> CoValues=new ArrayList<>();
			ArrayList<String> expBenefitValues=new ArrayList<>(dataTable.asList());	
			for (int i = 2; i <=4; i++) {
				//CoValues.add(webActions.getText(driver.findElement(By.xpath(coPay+i+value)), "BenefitValues").replaceAll("[$,]", ""));
				CoValues.add(webActions.getAttributeValue(driver.findElement(By.xpath(coPay+i+value)), "aria-valuenow", "BenefitValues"));
			}
			ArrayList<String>unmatchedSummarFields=webActions.getUmatchedInArrayComparision(CoValues, expBenefitValues);
			report.reportInfo("Expected benefits ampounts: " +expBenefitValues);
			report.reportInfo("Actual benefits amounts: " +CoValues);
			if(unmatchedSummarFields.size()==0){
				report.reportPass("Verified coPay Co-Insuarnce and Deductible amounts from estimate");
			}
			else{
				throw new Exception("Fail to verify coPay Co-Insuarnce and Deductible amounts from estimate and unmatched fields are: "+unmatchedSummarFields);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public Double getBenefitsAmounts(){
		Double data=0.00;
		try {
			webActions.waitForPageLoaded();
			for (int i = 2; i <=4; i++) {
				String text=webActions.getAttributeValue(driver.findElement(By.xpath(coPay+i+value)), "aria-valuenow", "BenefitValues").replaceAll("[$,]", "");
				data=data+Double.valueOf(text);
			}					
			report.reportInfo("Total benefits Amounts: "+data);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
		return data;
	}
	public void verifyEstimateBeforeDiscount(){
		try {
			Double sumOfBenefits=getBenefitsAmounts();
			DecimalFormat df = new DecimalFormat("#,##0.00");			
			String calculatedAmount=df.format(sumOfBenefits);
			String estimateBeforeDiscount=webActions.getText(Lbl_EstimateBeforeDiscountAmount, "estimateBeforeDiscount").replaceAll("[$]", "");
			report.reportInfo("Sum of benefits amounts:" +calculatedAmount);
			report.reportInfo("Estimate before discount amount:" +estimateBeforeDiscount);
			if(calculatedAmount.contentEquals(estimateBeforeDiscount)){
				report.reportPass("Verfied estimate before discount amount successfully");
			}
			else{
				report.reportFail("Fail to verify estimate before discount amount");
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void VerifyTotalPatientResponsibility(){
		try {
			webActions.waitForPageLoaded();			
			String beforediscount=webActions.getText(Lbl_EstimateBeforeDiscountAmount, "befortediscount");
			String PatientTotal=webActions.getText(lbl_PatientTotal, "PatientTotal");
			String TotalResposibility=webActions.getText(lbl_PatientResponsibility, "PatientResponsibility");
			report.reportInfo("Estimate before discount: " + beforediscount);
			report.reportInfo("Estimate patient total: " + PatientTotal);
			report.reportInfo("Total patient responsibility: " + TotalResposibility);
			if(beforediscount.contentEquals(PatientTotal) && beforediscount.contentEquals(TotalResposibility)){
				report.reportPass("Successfully verified the patient total and Responsibility amount");
			}
			else{
				report.reportFail("Fail to verify the patient total and patient responsibility amounts");
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void selectBenefits(){
		try {
			webActions.clickAction(Icon_BloodCharges, "BenefitsIcon");
			webActions.waitForPageLoaded();
			waitForPageLoade(2);
			webActions.clickAction(btn_BloodCharges_CoPay, "CoPay");
			webActions.waitForPageLoaded();
			waitForPageLoade(1);
			//webActions.clickAction(Icon_BloodCharges, "BenefitsIcon");
			//waitForPageLoade(2);
			webActions.clickAction(Icon_Hospital, "BenefitsIcon");
			webActions.waitForPageLoaded();
			waitForPageLoade(2);
			webActions.clickAction(btn_HospoitalFamility_CoInsurance, "CoPay");
			webActions.waitForPageLoaded();
			waitForPageLoade(1);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void clickBenefitsSave(){
		try {
			webActions.waitAndClick(btn_BenefitsSave, "BenefitsSave");
			webActions.waitForPageLoaded();
			waitForPageLoade(2);
			report.reportInfo("Successfully selected the save benefits button");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyServcieName(DataTable dataTable){
		try {
			ArrayList<String> expBenefitServiceName=new ArrayList<>(dataTable.asList());
			ArrayList<String>	actBenefitServiceName=webActions.getDatafromWebTable(Lbl_DefaulserviceName);
			ArrayList<String>unmatchedSummarFields=webActions.getUmatchedInArrayComparision(actBenefitServiceName, expBenefitServiceName);
			report.reportInfo("Expected benefit service names: " +expBenefitServiceName);
			report.reportInfo("Actual benefit service names: " +actBenefitServiceName);
			if(unmatchedSummarFields.size()==0){
				report.reportPass("Verified default benefits service name from view benefits");
			}
			else{
				throw new Exception("Fail to verify default benefits service name and unmatched fields are: "+unmatchedSummarFields);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void enterValuesInCoPayDeductibleCoInsurance(DataTable testData){
		try {
			//ArrayList<String> expValues = new ArrayList<String>(testData.row(1));
			webActions.clearValue(lbl_CoPay, "Co_pay");
			webActions.sendKeys(lbl_CoPay, webActions.getDatafromMap(testData, "CoPay"), "CoPay");
			waitForPageLoade(1);
			webActions.clearValue(lbl_Deductible, "Deductible");
			webActions.sendKeys(lbl_Deductible, webActions.getDatafromMap(testData, "Deductible"), "Deductible");
			waitForPageLoade(1);
			webActions.clearValue(lbl_CoInsurance, "CoInsurance");
			webActions.sendKeys(lbl_CoInsurance, webActions.getDatafromMap(testData, "CoInsurance"), "CoInsurance");
			waitForPageLoade(1);
			webActions.pressTab();
			report.reportInfo("Successfully entered the benefits values");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void cancleBenefitsWindow(){
		try {
			webActions.waitAndClick(btn_Cancel, "BenefitsCancel");
			webActions.waitForPageLoaded();
			waitForPageLoade(2);
			report.reportInfo("Successfully close the benefits window");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void clickReviewBenefitsIcon(){
		try {
			webActions.click(Icon_ViewBenefits, "BenefitsIcon");
			webActions.waitForPageLoaded();
			waitForPageLoade(3);
			report.reportInfo("Successfully navigated to the benefits page");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickSendToDigitalDocument(){
		try {
			waitForPageLoade(5);	
			webActions.waitAndClick(btn_SendToDD, "SendToDD");	
			webActions.waitForPageLoaded();
			String actAlertMsg=getAlertMessage();
			if("Send to digital document successfully".contains(actAlertMsg)){
				report.reportPass("Alert message matched and Send to digital document successfully: "+actAlertMsg);
				webActions.waitForLoad();
			}else{
				report.reportFail("Alert message is not matched and Send to digital document not successfully: "+actAlertMsg);
			}			

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void submitEstimatorForm(){
		try {
			waitForPageLoade(5);
			driver.switchTo().frame(0);
			webActions.waitForPageLoaded();
			webActions.click(btn_FormSubmit, "SUbmitBtn");
			webActions.waitForPageLoaded();
			waitForPageLoade(10);
			driver.switchTo().parentFrame();
			waitForPageLoade(3);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void submitEstimateFormFromDD(){
		try {				
			String xpath3="//span[contains(text(),'Estimate Form')]";
			webActions.clickAction(driver.findElement(By.xpath(xpath3)), "documents");	
			webActions.waitForPageLoaded();
			driver.switchTo().frame(0);
			waitForPageLoade(5);
			webActions.click(btn_FormSubmit, "SUbmitBtn");
			webActions.waitForPageLoaded();
			waitForPageLoade(30);
			String actDocsAndFormsStatus=webActions.getAttributeValue(lbl_DocsAndFormsStatus, "src", "DocsAndForms");
			driver.switchTo().parentFrame();
			String actDocsAndFormsStatusInPanel=webActions.getAttributeValue(lbl_DocsAndFormsStatusInPage, "src", "DocsAndForms");				

			if((actDocsAndFormsStatusInPanel.contains("success") )&& (actDocsAndFormsStatus.contains("success"))){
				report.reportPass("Documents and Forms status got cleared");
			}
			else{
				report.reportFail("Document and Forms status is not displayed in clear mode and actual displayed image is : " +actDocsAndFormsStatus );
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyDDModuleStatus(String panel){
		try {
			if("FullPanel".contentEquals(panel)){
				String actdefaultDigitalStatus=webActions.getAttributeValue(lbl_DigitalDocumentWindowStatus, "src", "DigitalDocumentWindow");
				if(actdefaultDigitalStatus.contains("success")){
					report.reportPass("Default digital document window status is displayed as clear mode");
				}
				else{
					report.reportFail("Default digital document window status is not displayed as clear mode and actual displayed image is : " + actdefaultDigitalStatus);
				}

			}
			else if("ShortPanel".contentEquals(panel)){
				waitForPageLoade(2);
				String actDigitalStatus=webActions.getAttributeValue(lbl_DigitalDocumentPanelStatus, "src", "DigitalPanel");
				if(actDigitalStatus.contains("success")){
					report.reportPass("Default digital document panel status is displayed as clear mode");
				}
				else{
					report.reportFail("Default digital document panel status is not displayed as clear mode and actual displayed image is : " + actDigitalStatus);
				}
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
