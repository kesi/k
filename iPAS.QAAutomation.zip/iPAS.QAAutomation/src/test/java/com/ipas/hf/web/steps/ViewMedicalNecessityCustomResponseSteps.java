package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.ViewMedicalNecessityCustomResponsePage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class ViewMedicalNecessityCustomResponseSteps {

	ViewMedicalNecessityCustomResponsePage viewCustomResp=new ViewMedicalNecessityCustomResponsePage();	
	
	@Then("Change Response Type as {string}")
	public void change_Response_Type_as(String responseType) {
		viewCustomResp.changeResponseType(responseType);
	}
	
	@Then("Verify Result Grid Header Names for Custom Response Type")
	public void verify_Result_Grid_Header_Names_for_Custom_Response_Type(DataTable headerNames) {
		viewCustomResp.verifyGridHeaderNamesForCustomResponseType(headerNames);
	}

	@Then("Verify {string} iocn for all Custom Response Codes")
	public void verify_iocn_for_all_Custom_Response_Codes(String iconName) {
		viewCustomResp.verifyTrashIconForCustomResponseCodes(iconName);
	}
	
	@Then("Verify the CPT Code as Hyperlink all Custom Response Codes")
	public void verify_the_CPT_Code_as_Hyperlink_all_Custom_Response_Codes() {
		viewCustomResp.verifyCPTCodeasHyperlinkForCustomResponseCodes();
	}

	
}
