package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;


public class EligibilityAddPayerCodePage extends BasePage {

	RestActions rest=new RestActions();
	HomePage homePage=new HomePage();

	@FindBy(xpath="//a[text()='Add Payer Code ']")
	private WebElement btn_addPayerCode;

	@FindBy(xpath="//label[text()='Payer Code']/../input")
	private WebElement txt_PayerCode;

	@FindBy(xpath="//input[@name='payerCodeDescription']")
	private WebElement txt_PayerDesc;

	@FindBy(xpath="//label[text()='Description']/../span[text()='*']")
	private WebElement asterix_PayerDesc;

	@FindBy(xpath="//ipas-dropdownlist[@name='connection']/ejs-dropdownlist/span")
	private WebElement dd_Connection;

	@FindBy(xpath="//ipas-dropdownlist[@name='payerTypeList']/ejs-dropdownlist/span")
	private WebElement dd_PayerType;

	@FindBy(xpath="//td[contains(@aria-label,'EDI Vendor Payer Code')]/div/input")
	private WebElement txt_EDIVendorCode;

	@FindBy(xpath="//td[contains(@aria-label,'EDI Vendor Description')]/div/input")
	private WebElement txt_EDIVendorDesc;

	@FindBy(xpath="//tr[@class='e-emptyrow']/td[text()='No records to display']")
	private WebElement txt_noRecordsFound;

	@FindBy(xpath="//a[contains(text(),'Add New Connection')]")
	private WebElement btn_AddNewConnection;

	@FindBy(xpath="//a[contains(text(),'Save')]")
	private WebElement btn_Save;

	@FindBy(xpath="//a[contains(text(),'Cancel')]")
	private WebElement btn_Cancel;

	@FindBy(xpath="//tr/td/span/img[@src='assets/images/trash-icon.png']")
	private WebElement btn_Trash;

	@FindBy(xpath="//tr/td/div/img[@src='/assets/images/reorder.png']")
	private WebElement btn_PriorityIcon;

	/*@FindBy(linkText = "Maintenance")
	private String lnk_Maintenance;*/

	private String lnk_Maintenance="Maintenance";

	@FindBy(xpath="//div[@class='breadcrum-container']/span")
	private List<WebElement> lbl_Breadcrumb;

	@FindBy(xpath="//div[@class='headtitle']/span")
	private List<WebElement> lbl_sections;

	@FindBy(xpath="//div[@class='headtitle']//following::div[1]//label")
	private List<WebElement> lst_payerInformation;

	@FindBy(xpath="//span[@class='e-headertext']")
	private List<WebElement> lst_connectionType;

	@FindBy(xpath="//div[@class='error']/div")
	private List<WebElement> lst_mandatoryfields;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;


	public EligibilityAddPayerCodePage() {
		PageFactory.initElements(driver, this);
	}



	public void verifyAddPayerCodeButton(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitUntilisDisplayed(btn_addPayerCode,"Add Payer Code Button");
			if(btn_addPayerCode.isDisplayed()){
				report.reportPass("Should display Add Payer Code Successfully");
			}
			else{
				throw new Exception("Fail to display Add Payer Code Button");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickAddPayerCode(){
		try {
			String expectedPage="https://administrationqa.ipas360.com/#/maintenance/payer/addpayer";
			webActions.waitForPageLoaded();
			webActions.waitUntilisDisplayed(btn_addPayerCode,"Add Payer Code Button");
			report.reportPass("Should display Add Payer Code Successfully");
			webActions.click(btn_addPayerCode, "Add Payer Code");
			report.reportPass("Should click on Add Payer Code Successfully");
			webActions.waitForPageLoaded();
			String actualPage=driver.getCurrentUrl();
			if(expectedPage.contentEquals(actualPage))
			{
				report.reportPass("Page Navigation Successfull when user clicks on Add payer code.");
			}
			else
			{
				throw new Exception("Fail to navigate to Add Payer page");
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyNavigationToMaintainancePage(){
		try {
			String expectedColor="rgba(255, 255, 255, 1)";//#FFFFFF
			webActions.waitForPageLoaded();
			webActions.waitUntilisDisplayed(btn_addPayerCode,"Add Payer Code Button");
			report.reportPass("Should display Add Payer Code Successfully");
			webActions.click(btn_addPayerCode, "Add Payer Code");
			report.reportPass("Should click on Add Payer Code Successfully");
			webActions.waitForPageLoaded();
			String actualColor = driver.findElement(By.linkText(lnk_Maintenance)).getCssValue("color");
			report.reportInfo("actualColor: "+actualColor);
			if(expectedColor.contentEquals(actualColor))
			{
				report.reportPass("Maintainance tab is successfully displayed in White Color");
			}
			else
			{
				throw new Exception("Fail to display maintainance tab in white color");
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyBreadCrumbsAddPayer(DataTable breadcrumb){
		try {
			ArrayList<String> expectdBreadcrumb = new ArrayList<>(breadcrumb.asList());
			webActions.waitForPageLoaded();
			ArrayList<String> actualBreadcrumb=webActions.getDatafromWebTable(lbl_Breadcrumb);
			report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumb);
			report.reportInfo("Expected Breadcrumb Titles "+expectdBreadcrumb);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumb, expectdBreadcrumb);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Breadcrumb Titles in Edit User page");
			}else{
				throw new Exception("Fail to verify the Breadcrumb Titles in Edit User page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifytheSections(DataTable sections){
		try {
			ArrayList<String> expectdSections = new ArrayList<>(sections.asList());
			ArrayList<String> actualSections =new ArrayList<String>();
			actualSections.addAll(webActions.getDatafromWebTable(lbl_sections));
			report.reportInfo("Actual Sections in Add Payer: "+actualSections);
			report.reportInfo("Expected Sections in Add Payer: "+expectdSections);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualSections, expectdSections);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Sections in Add Payer");
			}else{
				throw new Exception("Fail to verify the Sections in Add Payer: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyPayerInformationSection(DataTable sections){
		try {
			ArrayList<String> expectdSections = new ArrayList<>(sections.asList());
			ArrayList<String> actualSections =new ArrayList<String>();
			actualSections.addAll(webActions.getDatafromWebTable(lst_payerInformation));
			report.reportInfo("Actual Sections in Add Payer: "+actualSections);
			report.reportInfo("Expected Sections in Add Payer: "+expectdSections);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualSections, expectdSections);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the payerInformation Section in Add Payer");
			}else{
				throw new Exception("Fail to verify payerInformation Section in Add Payer: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyConnectionTypeSection(DataTable sections){
		try {
			ArrayList<String> expectdSections = new ArrayList<>(sections.asList());
			ArrayList<String> actualSections =new ArrayList<String>();
			for(int i=1;i<lst_connectionType.size();i++)
			{
				String txt=lst_connectionType.get(i).getText();
				if(!txt.isEmpty()){
					actualSections.add(txt);
				}
			}
			report.reportInfo("Actual fields in Connection Type: "+actualSections);
			report.reportInfo("Expected fields in Connection Type: "+expectdSections);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualSections,expectdSections);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Connection Type Section in Add Payer");
			}else{
				throw new Exception("Fail to verify Connection Type Section in Add Payer: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}



	public void verifyMandatoryFieldValidationMessage(DataTable mandatory){
		try {
			ArrayList<String> expectdMandatoryFields = new ArrayList<>(mandatory.asList());
			ArrayList<String> actualMandatoryFields =new ArrayList<String>();
			webActions.waitForPageLoaded();
			webActions.click(btn_AddNewConnection, "Add New Connection");
			report.reportPass("Should click on Add New Connection Button");
			webActions.click(btn_Save, "Save");
			report.reportPass("Should click on Save Button");
			actualMandatoryFields.addAll(webActions.getDatafromWebTable(lst_mandatoryfields));
			report.reportInfo("Actual Mandatory field messages in Add Payer: "+actualMandatoryFields);
			report.reportInfo("Expected Mandatory field messages in Add Payer: "+expectdMandatoryFields);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualMandatoryFields, expectdMandatoryFields);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Mandatory fields in Add Payer");
			}else{
				throw new Exception("Fail to verify Mandatory fields in Add Payer: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyValidationMessageMinimumMaximum(String length,String testData,DataTable minimum){
		try {
			ArrayList<String> expectdValidationMessage = new ArrayList<>(minimum.asList());
			ArrayList<String> actualValidationMessage =new ArrayList<String>();
			webActions.waitForPageLoaded();
			webActions.click(btn_AddNewConnection, "Add New Connection");
			report.reportPass("Should click on Add New Connection Button");
			webActions.sendKeys(txt_PayerDesc,testData,"Payer Description");
			webActions.sendKeys(txt_EDIVendorCode,testData,"EDI Vendor Code");
			webActions.sendKeys(txt_EDIVendorDesc,testData,"EDI Vendor Description");
			webActions.click(btn_Save, "Save");
			report.reportPass("Should click on Save Button");
			actualValidationMessage.addAll(webActions.getDatafromWebTable(lst_mandatoryfields));
			report.reportInfo("Actual validation message in Add Payer: "+actualValidationMessage);
			report.reportInfo("Expected validation message in Add Payer: "+expectdValidationMessage);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualValidationMessage, expectdValidationMessage);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the validation message in Add Payer");
			}else{
				throw new Exception("Fail to verify validation message in Add Payer: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyPayerInformationFields(){
		try {
			webActions.waitForPageLoaded();
			if(!txt_PayerCode.isEnabled())
			{
				report.reportPass("Should display Payer Code in a Disabled Mode");
			}
			else{
				throw new Exception("Fail to display Payer Code in a Disabled Mode");
			}

			if(txt_PayerDesc.isDisplayed()&&asterix_PayerDesc.isDisplayed())
			{
				report.reportPass("Should display Payer Description field as a Text Box and display it as a mandatory field");
			}
			else{
				throw new Exception("Fail to display Payer Description field");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyAddNewConnection(){
		try {
			webActions.waitForPageLoaded();
			if(txt_noRecordsFound.isDisplayed())
			{
				report.reportPass("Should display No Records found and disable save button");
				webActions.click(btn_AddNewConnection, "Add New Connection button");
				report.reportPass("Should click on Add New Connection button");
				if(btn_Save.isEnabled())
				{
					report.reportPass("Should enable save button when clicked on Add New Connection button");
				}
				else{
					throw new Exception("Fail to  enable save button");
				}

			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickAddNewConnectionMultipleTimes(DataTable messages){
		try {
			ArrayList<String> expectdValidation = new ArrayList<>(messages.asList());
			ArrayList<String> actualValidation =new ArrayList<String>();
			webActions.click(btn_AddNewConnection, "Add New Connection button");
			webActions.click(btn_AddNewConnection, "Add New Connection button");
			report.reportPass("Should click on Add New Connection button multiple times");
			actualValidation.addAll(webActions.getDatafromWebTable(lst_mandatoryfields));
			report.reportInfo("Actual validation message when clicked on add new connection multiple times: "+actualValidation);
			report.reportInfo("Expected validation message: "+expectdValidation);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualValidation, expectdValidation);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the validation message when clicked on add new connection multiple times");
			}else{
				throw new Exception("Fail to verify validation message when clicked on add new connection multiple times: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyButtons(){
		try {
			webActions.waitForPageLoaded();
			webActions.isDisplayed(btn_AddNewConnection, "Add New Connection");
			webActions.click(btn_AddNewConnection, "Add New Connection");
			webActions.waitForPageLoaded();
			webActions.isDisplayed(btn_PriorityIcon, "Priority Icon");
			webActions.isDisplayed(btn_Trash, "Trash Icon");
			webActions.isDisplayed(btn_Save, "Save Button");
			webActions.isDisplayed(btn_Cancel, "Cancel Button");
			report.reportPass("Should verify Priority Icon,Add New Connection,Trash Icon,Save and Cancel Buttons successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}	
	public void AddNewConnectionIcons(){
		try {
			webActions.waitForPageLoaded();
			webActions.isDisplayed(btn_AddNewConnection, "Add New Connection");
			webActions.click(btn_AddNewConnection, "Add New Connection");
			webActions.waitForPageLoaded();
			webActions.isDisplayed(btn_PriorityIcon, "Priority Icon");
			webActions.isDisplayed(btn_Trash, "Trash Icon");
			webActions.isDisplayed(btn_Save, "Save Button");
			webActions.isDisplayed(btn_Cancel, "Cancel Button");
			report.reportPass("Should verify Priority Icon,Add New Connection,Trash Icon,Save and Cancel Buttons successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void AddNewPayerCode(String payerDesc,String connection){
		try {
			String messageTitle ="Success!";
			String messageContent="Data saved successfully";
			StringBuilder unmatch=new StringBuilder();

			webActions.waitForPageLoaded();
			webActions.isDisplayed(btn_AddNewConnection, "Add New Connection");
			webActions.click(btn_AddNewConnection, "Add New Connection");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_PayerDesc,payerDesc, "Payer Description");
			webActions.waitForPageLoaded();
			webActions.sendKeys(dd_PayerType,"Commercial","PayerType");
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_AddNewConnection, "btn_AddNewConnection");
			webActions.waitForPageLoaded();
			webActions.sendKeys(dd_Connection,connection,"Connection");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_EDIVendorCode,"AAA", "EDI Vendor Code");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_EDIVendorDesc,"BCBS of OH", "EDI Vendor Description");
			webActions.waitForPageLoaded();
			webActions.click(btn_Save, "Save");
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle=titleContent[0];
			String actContent=titleContent[1];
			report.reportInfo("Save successfull message displayed: "+msg);
			if(messageContent.contentEquals(actContent))
			{
				report.reportPass("Successfully user is created and alert message is matched");
			}
			else
			{
				report.reportFail("Alert message is not captured/matched after creation");
			}		

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void SearchPayerCode(String payerDesc,String connection){
		try {
			String messageTitle ="Success!";
			String messageContent="Data saved successfully.";
			StringBuilder unmatch=new StringBuilder();

			webActions.waitForPageLoaded();
			webActions.isDisplayed(btn_AddNewConnection, "Add New Connection");
			webActions.click(btn_AddNewConnection, "Add New Connection");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_PayerDesc,payerDesc, "Payer Description");
			webActions.sendKeys(dd_Connection,connection,"Connection");
			webActions.sendKeys(txt_EDIVendorCode,"AAA", "EDI Vendor Code");
			webActions.sendKeys(txt_EDIVendorDesc,"BCBS of OH", "EDI Vendor Description");
			report.reportPass("Should enter the values in Add payer code successfully");
			webActions.click(btn_Save, "Save");
			report.reportPass("Should click on Save Button successfully");
			try {
				String msg=webActions.getText(txt_ToastMsgs, "Messages");
				String[] titleContent=msg.split("\\n");
				String actTitle=titleContent[0];
				String actContent=titleContent[1];
				report.reportInfo("Save successfull message displayed: "+msg);
				if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent)))
				{
					report.reportPass("Successfully user is created and alert message is matched: "+msg);
				}
				else
				{
					unmatch.append("Alert message is not captured/matched after creation: "+msg);
				}		
			} catch (Exception e) {
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}