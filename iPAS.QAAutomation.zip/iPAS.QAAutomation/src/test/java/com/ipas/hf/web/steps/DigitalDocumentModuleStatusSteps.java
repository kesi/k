package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.DigitalDocumentModuleStatusPage;

import cucumber.api.java.en.Then;

public class DigitalDocumentModuleStatusSteps {

	DigitalDocumentModuleStatusPage ddModuleStatus=new DigitalDocumentModuleStatusPage();

	@Then("Verify the display of digital document panel status")
	public void verify_the_display_of_digital_document_panel_status() {
		ddModuleStatus.verifyDigitalDocumentPanelStatus();
	}
	@Then("Verify the display of digital document window status")
	public void verify_the_display_of_digital_document_window_status() {
		ddModuleStatus.verifyDigitalDocumentWindowStatus();
	}
	@Then("Verify documents and forms default display status")
	public void verify_documents_and_forms_default_display_status() throws Exception {
		ddModuleStatus.verifyDocumentAndForsStatusinDigitalDocumentsMangerPage();
	}

	@Then("Verify documents and forms display status when status changed to complete")
	public void verify_documents_and_forms_display_status_when_status_changed_to_complete() throws Exception {
		ddModuleStatus.verifyDocumentAndFormsStatus();
	}
	@Then("Verify the digital document manager window status")
	public void verify_the_digital_document_manager_window_status() {
		ddModuleStatus.verifyDigitalDocumentManagerWindowStatus();
	}

}
