package com.ipas.hf.web.pages.ipasPages;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.time.DateUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class ViewNotesIconOnServiceTrackerPanelPage extends BasePage {

	String resetPassword="";
	private RestActions rest = new RestActions();

	@FindBy(xpath = "//input[@id='username']")
	private WebElement txt_UserName;

	@FindBy(xpath = "//div[2]/div[1]/div[3]/div[1]/div[1]/img[@src='assets/images/note.png']")
	private WebElement img_NotesIconOnVisitCard;

	@FindBy(xpath = "//app-ipas-service-tracker-panel[1]//div[1]//div[1]/img[@src='assets/images/note.png']")
	private WebElement img_NotesIconOnSTPanel;

	@FindBy(xpath = "//ipas-service-tracker-details[1]//div[1]/div[2]/div[1]/span[2]/img[@src='assets/images/note.png']")
	private WebElement img_NotesIconOnSTFullPage;

	@FindBy(xpath = "//ejs-dialog[1]/div[1]/div[1]/span[contains(text(),'Notes')]")
	private WebElement txt_NotesTextOnNotesWindow;

	@FindBy(xpath = "//ejs-dialog[1]//ejs-grid[1]/div[3]/div[1]//tr[1]/td")
	private List<WebElement> txt_NotesGridDataOnSTFullPage;

	@FindBy(xpath = "//ejs-dialog[1]//ejs-grid[1]/div[3]/div[1]//tr[1]/td[3]")
	private WebElement txt_NotesGridDateDataOnSTFullPage;

	@FindBy(xpath = "//ejs-dialog[1]//ejs-grid[1]/div[3]/div[1]//tr[1]/td[2]")
	private WebElement txt_NotesGridUserNameOnSTFullPage;

	@FindBy(xpath = "//ejs-dialog[1]//ejs-grid[1]/div[3]/div[1]//tr[1]/td[1]")
	private WebElement txt_NotesGridNotesDataOnSTFullPage;

	@FindBy(xpath = "//div[@class='st modal-dialog modal-xl']//a[contains(text(),'Notes')]")
	private WebElement btn_NotesOnModalWindow;
	
	@FindBy(xpath = "//ejs-textbox[1]/span[1]/textarea[1]")
	private WebElement txtBox_NotesTextBox;
	
	@FindBy(xpath = "//button[contains(text(),'Add Note')]")
	private WebElement btn_AddNotesInNotesWindow;

	public ViewNotesIconOnServiceTrackerPanelPage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyNotesIconOnVisitCard() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(img_NotesIconOnVisitCard, "NotesIcon");
			report.reportPass("Notes Icon on Visit Card is displayed Successfully");
			if(img_NotesIconOnVisitCard.isDisplayed()){
				report.reportPass("Notes Icon is displayed on Visit Card");
				webActions.waitForClickAbilityAndClick(img_NotesIconOnVisitCard, "NotesIconOnVisitCard");
				report.reportPass("Clicked on Notes Icon on Visit Card");
				String notesText = webActions.getText(txt_NotesTextOnNotesWindow, "NotesText");
				if(notesText.contentEquals("Notes")){
					report.reportPass("Notes Text is displayed on Notes Window");
				}else{
					throw new Exception("Failed to read Notes Text on Notes Window");
				}
			}else{
				throw new Exception("Notes Icon is not displayed on Visit Card");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyNotesIconOnServiceTrackerPanel() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(img_NotesIconOnSTPanel, "NotesIcon");
			report.reportPass("Notes Icon on Service Tracker Panel is displayed Successfully");
			if(img_NotesIconOnSTPanel.isDisplayed()){
				report.reportPass("Notes Icon is displayed on Service Tracker Panel");
				webActions.waitForClickAbilityAndClick(img_NotesIconOnSTPanel, "NotesIconOnSTPanel");
				report.reportPass("Clicked on Notes Icon on Service Tracker Panel");
				String notesText = webActions.getText(txt_NotesTextOnNotesWindow, "NotesText");
				if(notesText.contentEquals("Notes")){
					report.reportPass("Notes Text is displayed on Notes Window");
				}else{
					throw new Exception("Failed to read Notes Text on Notes Window");
				}
			}else{
				throw new Exception("Notes Icon is not displayed on Visit Card");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyNotesIconOnServiceTrackerFullPage() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(img_NotesIconOnSTFullPage, "NotesIcon");
			report.reportPass("Notes Icon on Service Tracker Full Page is displayed Successfully");
			if(img_NotesIconOnSTFullPage.isDisplayed()){
				report.reportPass("Notes Icon is displayed on Service Tracker Full Page");
				webActions.waitForClickAbilityAndClick(img_NotesIconOnSTFullPage, "NotesIconOnSTFull Page");
				report.reportPass("Clicked on Notes Icon on Service Tracker Full Page");
				String notesText = webActions.getText(txt_NotesTextOnNotesWindow, "NotesText");
				if(notesText.contentEquals("Notes")){
					report.reportPass("Notes Text is displayed on Notes Window");
				}else{
					throw new Exception("Failed to read Notes Text on Notes Window");
				}
			}else{
				throw new Exception("Notes Icon is not displayed on Visit Card");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyCreatedNotesDataOnSTFullPage(DataTable data) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitUntilListisDisplayed(txt_NotesGridDataOnSTFullPage, "GridData");
			report.reportPass("Grid Data is displayed properly");
			ArrayList<String> expNotesGridData = new ArrayList<>(data.asList());
			expNotesGridData.add(webActions.getSystemCurrentDate());
			report.reportInfo("Expected Notes Grid Data is : "+expNotesGridData);

			ArrayList<String> actGridData = new ArrayList<String>();
			actGridData.add(webActions.waitAndGetText(txt_NotesGridNotesDataOnSTFullPage, "NotesData"));
			actGridData.add(webActions.waitAndGetText(txt_NotesGridUserNameOnSTFullPage, "NotesUserName"));
			actGridData.add(getDateValueFromNotesGrid());
			report.reportInfo("Data from Application is :"+actGridData);

			ArrayList<String> unmatchedNotesGridData = webActions.getUmatchedInArrayComparision(actGridData, expNotesGridData);
			if(unmatchedNotesGridData.size()==0){
				report.reportPass("Verified Notes Grid Data successfully");
			}
			else{
				throw new Exception("Fail to verify Notes Grid data and unmatched data is: "+unmatchedNotesGridData);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public String getDateValueFromNotesGrid() throws Exception{
		String actDateValue = null; String dateValueFromGrid =null;
		try{
			webActions.waitForPageLoaded();
			actDateValue = webActions.waitAndGetText(txt_NotesGridDateDataOnSTFullPage, "DateValue");
			report.reportInfo("Date value is :"+actDateValue);
			dateValueFromGrid = actDateValue.substring(0,11);
			report.reportInfo("Expected Data is after split is : "+dateValueFromGrid);			
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
		return dateValueFromGrid;
	}

	public void verifyNotesIconIsNotDisplayedOnVisitCard() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.isDisplayed(img_NotesIconOnVisitCard, "Notes Icon");
			report.reportFail("Notes Icon is not displayed on Visit Card");
		}catch(Exception e){
			report.reportPass("Notes Icon not displayed on Visit Card");
		}
	}


	public void verifyNotesIconIsNotDisplayedOnServiceTrackerPanel() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.isDisplayed(img_NotesIconOnSTPanel, "Notes Icon");
			report.reportFail("Notes Icon displayed on St Panel");
		}catch(Exception e){
			report.reportPass("Notes Icon is not displayed on STPanel");
		}
	}

	public void verifyNotesIconIsNotDisplayedOnServiceTrackerFullPage() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.isDisplayed(img_NotesIconOnSTFullPage, "Notes Icon");
			report.reportFail("Notes Icon is displayed on STFullPage");
		}catch(Exception e){
			report.reportPass("Notes Icon is not displayed on STFullPage");
		}
	}


	public void compareNotesCreatedTime() throws Exception{
		try{
			webActions.waitForPageLoaded();
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd hh:mm a");
			LocalDateTime now = LocalDateTime.now();
			String expNotesCreatedTime = dtf.format(now).substring(11,17).trim();
			report.reportInfo("Expected Notes created Time is :"+expNotesCreatedTime);
			webActions.waitForPageLoaded();
			String actNotesCreatedTime = webActions.waitAndGetText(txt_NotesGridDateDataOnSTFullPage, "DateData");
			report.reportInfo("Actual Notes created date and time is: "+actNotesCreatedTime);

			actNotesCreatedTime = actNotesCreatedTime.substring(11,16).trim();
			report.reportInfo("Actual Notes created time is: "+actNotesCreatedTime);	

			if(expNotesCreatedTime.contains(actNotesCreatedTime)){
				report.reportPass("Notes created Time is displayed successfully");
			}else{
				throw new Exception("Failed to compare actual and expected Notes Created Time");
			}		
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyAddNotesButtonInDisabledMode() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_AddNotesInNotesWindow, "AddNotesBtn",2);
			report.reportInfo("Add Notes button is displayed");
			if(!btn_AddNotesInNotesWindow.isEnabled()){
				report.reportPass("Notes button is in disabled mode");
			}else{
				throw new Exception("Notes button is in enabled mode");
			}
				
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyAddNotesButtonInEnabledMode() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.sendKeys(txtBox_NotesTextBox, "Test", "Msg");
			report.reportPass("Text is entered successfully");
			if(btn_AddNotesInNotesWindow.isEnabled()){
				report.reportPass("Notes button is in enabled mode");
			}else{
				throw new Exception("Notes button is in disabled mode");
			}
				
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	
	public ViewNotesIconOnServiceTrackerPanelPage openIpasApp() {
		try {
			String URL = TestBase.prop.ipasURL();
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to Open iPAS application");
		}
		return (ViewNotesIconOnServiceTrackerPanelPage) base(ViewNotesIconOnServiceTrackerPanelPage.class);
	}



	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_UserName);
	}

}
