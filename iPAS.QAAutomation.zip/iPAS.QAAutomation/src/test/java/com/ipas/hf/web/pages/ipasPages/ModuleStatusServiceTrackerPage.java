package com.ipas.hf.web.pages.ipasPages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.BasePage;



public class ModuleStatusServiceTrackerPage extends BasePage {
	PatientVisitPage visit=new PatientVisitPage();
	UpdateVisitPage updatevisit=new UpdateVisitPage();
	public ModuleStatusServiceTrackerPage() {
		PageFactory.initElements(driver, this);
	}

	public String AcctNumber;


	@FindBy(xpath="//a[@class='fa fa-ellipsis-h fa-w']")
	private WebElement btn_threedots;

	@FindBy(xpath="//h5[text()='All Modules ']")
	private WebElement lbl_AllModules;

	@FindBy(xpath="(//a[@class='close'])[last()]")
	private WebElement btn_close;

	@FindBy(xpath="//img[@src='assets/images/success_sm.png']")
	private WebElement icon_success;

	@FindBy(xpath="//img[@src='assets/images/alert_sm.png']")
	private WebElement icon_alert;
	
	@FindBy(xpath="//table[@id='asgrid_content_table']/tbody/tr/td[9]/div//a[text()='Service Tracker']//preceding::financial-clearance-status[1]/img[@src='assets/images/error_sm.png']")
	private WebElement icon_alert_ServiceTracker_NeedsAttention;
	
	@FindBy(xpath="//div[@class='st modal-content']/../..//financial-clearance-status/img")
	private WebElement icon_alert_modelWindow;

	@FindBy(xpath="//div[@class='st modal-content']/../..//financial-clearance-status/img")
	private WebElement icon_success_modelWindow;

	@FindBy(xpath="//div[@class='card-body']//financial-clearance-status/img']")
	private WebElement icon_success_financial_clearance_servTracker;

	@FindBy(xpath="//div[@class='card-body']//financial-clearance-status/img")
	private WebElement icon_alert_financial_clearance_servTracker;

	@FindBy(xpath="//img[@src='assets/images/high_priority.png']")
	private WebElement icon_highpriority;

	@FindBy(xpath="//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_searchbox;

	@FindBy(xpath="//img[@src='assets/images/more.png']")
	private WebElement btn_threedots_serviceTracker;

	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@formcontrolname='serviceTrackerStatusId']/span/span")
	private WebElement drpdwn_IntakeStatus;

	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@formcontrolname='serviceTrackerStatusId']/span//input")
	private WebElement drpvalue_IntakeStatus;

	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@placeholder ='Select Registrar']/span//input")
	private WebElement drpvalue_Registrar;

	@FindBy(xpath = "//span[@class='e-icons e-frame']")
	private WebElement chkbox_Highpriority;

	@FindBy(xpath = "//span[@class='e-icons e-frame e-check']")
	private WebElement checked_Highpriority;

	@FindBy(xpath="//a[text()=' Service Tracker']")
	private WebElement lnk_serviceTracker_AllData;

	@FindBy(xpath="//img[@src='assets/images/more.png']")
	private WebElement btn_ThreeDots_ServTrackerPnl;

	@FindBy(xpath="//span[text()='High Priority']//preceding::span[1]")
	private WebElement chkBox_HighPriority_ServTrackerPnl;


	@FindBy(xpath="//span[text()=' Service Tracker']")
	private WebElement txt_serviceTracker_ServiceTrackerPnl;

	@FindBy(xpath = "//button[contains(text(),'Submit')]")
	private WebElement btn_Submit;

	@FindBy(xpath = "(//button[contains(text(),'Cancel')])[2]")
	private WebElement btn_Cancel;

	@FindBy(xpath = "(//button[@class='close'])[3]")
	private WebElement btn_Close;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;

	@FindBy(xpath = "//div[@class='allData-control-section']")
	private WebElement pnl_AllData;

	@FindBy(xpath = "//a[text()=' Service Tracker']//preceding::financial-clearance-status[1]/img[@src='assets/images/error_sm.png']")
	private WebElement icon_AllData_Alert;

	@FindBy(xpath = "//img[@alt='priority']")
	private WebElement icon_AllData_highPriority;

	@FindBy(xpath = "//img[@src='assets/images/wheelchair.png']")
	private WebElement icon_AllData_wheelChair;
	
	@FindBy(xpath = "//financial-clearance-status//img[@src='assets/images/error.png']")
	private WebElement icon_servTracker_Alert;

	@FindBy(xpath = "//img[@src='assets/images/high_priority.png']")
	private WebElement icon_servTracker_highPriority;

	@FindBy(xpath = "//img[@src='assets/images/success_sm.png']")
	private WebElement icon_servTracker_Clearance;

	@FindBy(xpath = "//img[@src='assets/images/wheelchair.png']")
	private WebElement icon_servTracker_wheelChair;

	@FindBy(xpath = "//a[text()=' Service Tracker']//preceding::financial-clearance-status[1]/img[@src='assets/images/success_sm.png']")
	private WebElement icon_AllData_Success;

	@FindBy(xpath = "//div[@id='allDataPasentDetails']/div/financial-clearance-status/img[@src='assets/images/success.png']")
	private WebElement icon_AllData_PDetails_Success;

	@FindBy(xpath = "//a[@class='textblue']")
	private WebElement lnk_visitcard;

	@FindBy(xpath="//ejs-switch[1]/span[@class='e-switch-handle']")
	private WebElement rdbtn_WheelChair;

	@FindBy(xpath="//span[@class='e-switch-handle e-switch-active']")
	private WebElement rdbtn_Active;

	@FindBy(xpath="//span[@class='e-switch-handle']")
	private WebElement rdbtn_InActive;

	@FindBy(xpath="(//button[@class='close'])[last()]")
	private WebElement btn_MWindowClose;

	@FindBy(xpath="//ejs-tab[1]/div[2]/div[2]/div[1]/form[1]/div[2]/button[2]")
	private WebElement btn_MWindowSubmit;
	
	@FindBy(xpath="//table[@class='e-table']//thead/tr/th")
	private WebElement lbl_Headers_AS;
	
	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr/td[9]/div/div")
	private List<WebElement> li_AllModuleNameNeedsAttention;
	
	@FindBy(xpath = "//div[@class='e-acrdn-header-content']")
	private List<WebElement> li_AllData_ModStatus;
	
	@FindBy(xpath = "//div[@class='e-headercelldiv']/span")
	private List<WebElement> li_ServiceTracker_panel_tracking_columns;

	@FindBy(xpath="//div[@id='three']//app-ipas-document-management-pannel/div/ejs-accordion/div/div[2]/div/div/ul/li/div[1]")
	private List<WebElement> lbl_DigitalDocMangerPanel;
	
	@FindBy(xpath="//ejs-accordion/div[1]/div[2]/div/div/ul/li/div[2]")
	private WebElement lbl_DataInAllDataPanel;	

	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[2]")
	private List<WebElement> lbl_VisitSummaryData;

	public void accountsearchModuleStatus(String type) {
		try {
			
			if("Success".contentEquals(type))
			{
				webActions.waitForPageLoaded();
				webActions.waitUntilisDisplayed(btn_threedots, "Account Search >> Three Dots");
				webActions.doubleClick(btn_threedots, "Account Search >> Three Dots");
				report.reportPass("Should click on three dots in the record selected");
				webActions.waitUntilisDisplayed(lbl_AllModules, "All Modules");
				webActions.isDisplayed(lbl_AllModules, "All Modules Popup");
				report.reportPass("Should display All Modules Pop up");
				webActions.waitForPageLoaded();
				webActions.isDisplayed(icon_success, "Success in Account search");
				report.reportPass("Should display Service Tracker with clearance symbol in Account Search");
				webActions.click(btn_close, "close button");
			}
			else if("Alert".contentEquals(type)) 
			{
				webActions.waitForPageLoaded();
				webActions.isDisplayed(icon_alert_ServiceTracker_NeedsAttention, "Alert Icon on Needs Attention");
				report.reportPass("Should display Alert icon in Needs Attention in Account Search");
				/*webActions.waitUntilisDisplayed(btn_threedots, "Account Search >> Three Dots");
				webActions.doubleClick(btn_threedots, "Account Search >> Three Dots");
				report.reportPass("Should click on three dots in the record selected");
				webActions.waitUntilisDisplayed(lbl_AllModules, "All Modules");
				webActions.isDisplayed(lbl_AllModules, "All Modules Popup");
				report.reportPass("Should display All Modules Pop up");
				webActions.waitForPageLoaded();
				webActions.isDisplayed(icon_alert, "Alert icon in Account search");
				report.reportPass("Should display Alert icon in Account Search");
				webActions.click(btn_close, "close button");	*/		}
		} catch (Exception e) {
			report.reportFail("Failed to display module status in account search due to: " + e,true);
		}
	}

	public void serviceTrackerSimpleSearch(String AcctNum) {
		try {
			webActions.waitUntilisDisplayed(txt_searchbox, "Service Tracker >> SearchBox");
			webActions.clearValue(txt_searchbox,"Search Input Box");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_searchbox,AcctNum, "Enter Account Number "+AcctNum);
			report.reportPass("Should Enter Account number in search input box");
		} catch (Exception e) {
			report.reportFail("Failed to display module status due to: " + e,true);
		}
	}

	public void serviceTrackerSimpleSearchPageRefresh(String AcctNum) {
		try {
			webActions.refreshPage();
			visit.serviceTrackerPageValidation();
			webActions.waitUntilisDisplayed(txt_searchbox, "Service Tracker >> SearchBox");
			webActions.clearValue(txt_searchbox,"Search Input Box");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_searchbox,AcctNum, "Enter Account Number "+AcctNum);
			report.reportPass("Should Enter Account number in search input box");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail("Failed to display module status due to: " + e,true);
		}
	}

	public void chgModStatServTracBrd(String type,String Acctnum)
	{

	}

	public void modStatusServiceTrackerBoard(String type,String Acctnum) {
		try {
			webActions.waitForPageLoaded();
			if("Success".contentEquals(type))
			{
				webActions.waitForPageLoaded();
				webActions.waitForPageLoaded();
				webActions.waitForPageLoaded();
				webActions.waitForElementToBeNotPresent(icon_highpriority, "High Priority Icon");
				report.reportPass("Should not display High Priority Icon on the visit card");
				webActions.waitForPageLoaded();
				webActions.waitForPageLoaded();
				webActions.waitForPageLoaded();
				webActions.waitForElementToBeNotPresent(icon_alert, "Service tracker - Alert icon ");
				report.reportPass("Should not display Service Tracker alert on the board");
			}
			if("Highpriority".contentEquals(type))
			{
				webActions.waitForPageLoaded();
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(icon_highpriority, "High Priority Icon");
				webActions.isDisplayed(icon_highpriority, "High Priority Icon");
				report.reportPass("Should display High Priority Icon on the visit card");
				webActions.waitForPageLoaded();
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(icon_alert, "Service tracker - Alert icon ");
				webActions.isDisplayed(icon_alert, "Service tracker - Alert icon ");
				report.reportPass("Should display Service Tracker alert on the board");
			}


			String messageTitle ="Success!";
			String messageContent="Data saved successfully.";
			webActions.waitUntilisDisplayed(btn_threedots_serviceTracker, "Service Tracker three dots");
			webActions.click(btn_threedots_serviceTracker, "Three dots");
			report.reportPass("Three dots on the visit card");
			webActions.waitForVisibility(chkbox_Highpriority, "High Priority");
			webActions.check(chkbox_Highpriority, "High Priority");
			report.reportPass("Check the high priority");
			if(!btn_Submit.isEnabled())
			{
				webActions.check(chkbox_Highpriority, "High Priority");
				webActions.click(btn_Submit, "Submit Button");
			}
			else
			{
				webActions.click(btn_Submit, "Submit Button");
			}
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle=titleContent[0];
			String actContent=titleContent[1];
			report.reportInfo("Actual alert message after user created: "+msg);
			report.reportInfo("Actual title :"+actTitle);
			report.reportInfo("Actual content :"+actContent);
			if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent)))
			{
				report.reportPass("Successfully user is created and alert message is matched: "+msg);
			}
			webActions.click(btn_Close, "Close button");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(icon_highpriority, "High Priority Icon");
			webActions.isDisplayed(icon_highpriority, "High Priority Icon");
			report.reportPass("Should display High Priority Icon on the visit card");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(icon_alert, "Service tracker - Alert icon ");
			webActions.isDisplayed(icon_alert, "Service tracker - Alert icon ");
			report.reportPass("Should display Service Tracker alert on the board");
		}
		catch (Exception e) {
			report.reportFail("Failed to display module status due to: " + e,true);
		}
	}

	public void successIconServiceTracker(String AcctNumber) {
		try {
			String messageTitle ="Success!";
			String messageContent="Data saved successfully.";
			String xpath6="//a[text()=' ";
			String xpath7=" ']";
			String xpath8=xpath6+AcctNumber+xpath7;
			driver.findElement(By.xpath(xpath8));
			webActions.waitUntilisDisplayed(btn_threedots_serviceTracker, "Service Tracker three dots");
			webActions.waitForPageLoaded();
			webActions.click(btn_threedots_serviceTracker, "Service Tracker three dots");
			webActions.waitForPageLoaded();
			report.reportPass("Should click on Three dots on Visit Card with Account Number :"+AcctNumber);
			webActions.isDisplayed(icon_alert_modelWindow, "Alert Icon in Model Window");
			if(checked_Highpriority.isSelected())
			{
				webActions.click(checked_Highpriority, "High Priority CheckBox");	
				report.reportPass("Should uncheck High Priority CheckBox");
			}
			if(!btn_Submit.isEnabled())
			{
				webActions.clickBYJS(checked_Highpriority, "High Priority CheckBox");	
				webActions.click(btn_Submit, "Submit Button");
				report.reportPass("Should click on Submit Button in Model Window");
			}
			else
			{
				webActions.click(btn_Submit, "Submit Button");
				report.reportPass("Should click on Submit Button in Modal Window");

			}
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle=titleContent[0];
			String actContent=titleContent[1];
			report.reportInfo("Actual alert message after user created: "+msg);
			report.reportInfo("Actual title :"+actTitle);
			report.reportInfo("Actual content :"+actContent);
			if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent)))
			{
				report.reportPass("Successfully user is created and alert message is matched: "+msg);
			}
			webActions.click(btn_Close, "Close button");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(icon_success_financial_clearance_servTracker, "Service tracker - Success icon Financial Clearance Status ");
			webActions.isDisplayed(icon_success_financial_clearance_servTracker, "Service tracker - Success icon ");
			report.reportPass("Should display Service Tracker Success on the board");
			webActions.click(btn_threedots_serviceTracker, "Service Tracker three dots");
			report.reportPass("Should click on Three dots on Visit Card with Account Number :"+AcctNumber);
			webActions.isDisplayed(icon_success_modelWindow, "Service tracker - Success icon - Model Window ");
			report.reportPass("Should display Service Tracker Success on the Model Window");
			webActions.click(btn_Close, "Close button");
			webActions.waitForPageLoaded();
			webActions.waitUntilisDisplayed(lnk_visitcard,"Visit Card");
			try {
				if(lnk_visitcard.isDisplayed())
				{
					webActions.click(lnk_visitcard,"Visit Card with Account Number :"+AcctNumber);
					report.reportPass("Should click on Visit Card with Account Number :"+AcctNumber);
					webActions.waitUntilisDisplayed(pnl_AllData, "All Data Panel");
					webActions.isDisplayed(pnl_AllData, "All Data Panel");
					report.reportPass("Should navigate to All Data Panel");
					webActions.waitForPageLoaded();
					webActions.waitForVisibility(icon_AllData_Success, "Success Icon in All Data");
					webActions.isDisplayed(icon_AllData_Success, "Success Icon in All Data");
					report.reportPass("Should display Success icon in  All Data Panel");
					webActions.isDisplayed(icon_AllData_PDetails_Success, "Success Icon in All Data Personal Details Panel");
					report.reportPass("Should display Success icon in  All Data Panel Personal Details section");
				}	
			} catch (Exception e) {
				report.reportFail("Failed to display visit card on service tracker board due to: " + e,true);
			}
		} catch (Exception e) {
			report.reportFail("Failed to display module status in All Data Panel due to: " + e,true);
		}
	}

	public void highPriorityAcctSearch() {
		try {
			webActions.waitUntilisDisplayed(btn_threedots, "Account Search >> Three Dots");
			webActions.doubleClick(btn_threedots, "Account Search >> Three Dots");
			report.reportPass("Should click on three dots in the record selected");
			webActions.waitUntilisDisplayed(lbl_AllModules, "All Modules");
			webActions.isDisplayed(lbl_AllModules, "All Modules Popup");
			report.reportPass("Should display All Modules Pop up");
			if(icon_alert.isDisplayed())
			{
				report.reportPass("Should display Service Tracker with Alert symbol in Account Search");
				webActions.click(btn_close, "close button");
			}
			else
			{
				report.reportFail("Failed to display Service Tracker with Alert symbol in Account Search",true);
			}


		} catch (Exception e) {
			report.reportFail("Failed to display module status due to: " + e,true);
		}
	}

	public void AllDataPanel(String Status,String AcctNumber) {
		try {
			String xpath1="//a[text()=' ";
			String xpath2=" ']";
			String xpath4=xpath1+AcctNumber+xpath2;
			WebElement visitcardbody = driver.findElement(By.xpath(xpath4));
			webActions.waitForPageLoaded();
			if(visitcardbody.isDisplayed())
			{
				webActions.click(visitcardbody,"Visit Card with Account Number :"+AcctNumber);
				report.reportPass("Should click on Visit Card with Account Number :"+AcctNumber);
				//webActions.waitUntilisDisplayed(pnl_AllData, "All Data Panel");
				//webActions.isDisplayed(pnl_AllData, "All Data Panel");
				//report.reportPass("Should navigate to All Data Panel");
				webActions.waitForPageLoaded();
				webActions.waitForVisibilityOfAllElements(lbl_DigitalDocMangerPanel, "DigitalDocs");
				Thread.sleep(2000);				
				report.reportInfo("Navigated to the Patient Visit Summary page");			
				webActions.waitForVisibilityOfAllElements(lbl_DataInAllDataPanel, "DataInAllData");
				webActions.waitForVisibilityOfAllElements(lbl_VisitSummaryData, "SummaryData");
				webActions.waitForPageLoaded();
				try {
					if("Alert".contentEquals(Status))
					{
						webActions.waitForPageLoaded();
						webActions.isDisplayed(icon_AllData_Alert, "Alert Icon in All Data");
						report.reportPass("Should display Alert icon in  All Data Panel");
						webActions.waitForPageLoaded();
						webActions.waitUntilisDisplayed(icon_AllData_highPriority, "High Priority Icon in All Data");
						webActions.isDisplayed(icon_AllData_highPriority, "High Priority Icon in All Data");
						report.reportPass("Should display High priority icon in  All Data Panel");
					}
					else if("Success".contentEquals(Status))
					{
						webActions.waitForPageLoaded();
						webActions.isDisplayed(icon_AllData_Success, "Success Icon in All Data");
						report.reportPass("Should display Success or clearance icon in  All Data Panel");
					}

				} catch (Exception e) {
					report.reportFail("Failed to display module status in All Data Panel due to: " + e,true);
				}
			}
		} catch (Exception e) {
			report.reportFail("Failed to display visit card on board due to: " + e,true);
		}
	}

	public void navigateToServiceTrackerPanel() {
		try {
			webActions.waitForPageLoaded();
			if(lnk_serviceTracker_AllData.isDisplayed())
			{
				webActions.waitUntilisDisplayed(lnk_serviceTracker_AllData, "Service Tracker All Data link");
				webActions.click(lnk_serviceTracker_AllData,"Service tracker Al Data link");
				report.reportPass("Should click on Service Tracker on All Data Panel");
				webActions.waitForPageLoaded();
				webActions.waitUntilisDisplayed(txt_serviceTracker_ServiceTrackerPnl,"Service Tracker in Service Tracker Panel");
				webActions.waitForPageLoaded();
			}
		} catch (Exception e) {
			report.reportFail("Failed to display Service Tracker link in Service Tracker Panel due to: " + e,true);
		}
	}	

	public void modStatServTrackerPanel(String Status) {
		try {
			webActions.waitForPageLoaded();
			//webActions.waitForVisibilityOfAllElements(li_ServiceTracker_panel_tracking_columns, "Service Tracker panel");
			report.reportPass("Should navigate to service tracker Panel");
			if("Alert".contentEquals(Status))
			{
				webActions.waitForPageLoaded();
				webActions.isDisplayed(icon_servTracker_Alert, "Alert Icon in Service Tracker Panel");
				report.reportPass("Should display Alert icon in Service Tracker Panel ");
				webActions.waitUntilisDisplayed(icon_servTracker_highPriority, "High Priority Icon in Service Tracker Panel");
				webActions.isDisplayed(icon_servTracker_highPriority, "High Priority Icon in Service Tracker Panel");
				report.reportPass("Should display High priority icon in  Service Tracker Panel");
			}

			else if("Success".contentEquals(Status))
			{
				webActions.isDisplayed(icon_servTracker_Clearance, "Success Icon in Service Tracker Panel");
				report.reportPass("Should display Success icon in Service Tracker Panel ");
			}

		} catch (Exception e) {
			report.reportFail("Failed to display Service Tracker link in Service Tracker Panel due to: " + e,true);
		}
	}	
	public void modStatusChangeServiceTrackerPanel() {
		try {
			String messageTitle ="Success!";
			String messageContent="Data saved successfully.";
			webActions.waitForPageLoaded();
			if(btn_ThreeDots_ServTrackerPnl.isDisplayed())
			{
				webActions.waitUntilisDisplayed(btn_ThreeDots_ServTrackerPnl, "Service Tracker All Data link");
				webActions.click(btn_ThreeDots_ServTrackerPnl,"Service tracker Al Data link");
				report.reportPass("Should click on Three dots in Service Tracker Panel");
				webActions.waitUntilisDisplayed(txt_serviceTracker_ServiceTrackerPnl,"Service Tracker in Service Tracker Panel");
				if(!chkBox_HighPriority_ServTrackerPnl.isSelected())
				{
					webActions.check(chkBox_HighPriority_ServTrackerPnl, "CheckBox HighPriority");
					report.reportPass("Should Check the checkbox in high priority in Service Tracker Panel");
				}
				webActions.click(btn_Submit, "Submit Button");
				report.reportPass("Should click on submit button");
				String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
				String[] titleContent=msg.split("\\n");
				String actTitle=titleContent[0];
				String actContent=titleContent[1];
				report.reportInfo("Actual alert message after user created: "+msg);
				report.reportInfo("Actual title :"+actTitle);
				report.reportInfo("Actual content :"+actContent);
				if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent)))
				{
					report.reportPass("Successfully user is created and alert message is matched: "+msg);
				}
				webActions.click(btn_Close, "Close button");
				webActions.waitForPageLoaded();
				webActions.waitUntilisDisplayed(icon_servTracker_Clearance, "Clearance/Success Icon in Service Tracker Panel");
				webActions.isDisplayed(icon_servTracker_highPriority, "Clearance/Success Icon in Service Tracker Panel");
				report.reportPass("Should display Clearance/Success Icon icon in  Service Tracker Panel");
			}
		} catch (Exception e) {
			report.reportFail("Failed to display More options in Service Tracker Panel due to: " + e,true);
		}
	}

	public void modStatusServiceTrackerPanel(String type) {
		try {
			webActions.waitUntilisDisplayed(btn_ThreeDots_ServTrackerPnl, "Service Tracker All Data link");
			webActions.waitForPageLoaded();
			try {
				if("Alert".contentEquals(type))
				{
					webActions.waitForPageLoaded();
					if(btn_ThreeDots_ServTrackerPnl.isDisplayed())
					{
						webActions.click(btn_ThreeDots_ServTrackerPnl,"Service tracker Al Data link");
						report.reportPass("Should click on Three dots in Service Tracker Panel");
						webActions.waitForPageLoaded();
						webActions.waitUntilisDisplayed(icon_servTracker_Alert, "Alert Icon in Service Tracker Panel");
						webActions.isDisplayed(icon_servTracker_Alert, "Alert Icon in Service Tracker Panel");
						report.reportPass("Should displayAlert Icon in Service Tracker Panel");
						webActions.waitUntilisDisplayed(icon_servTracker_highPriority, "High Priority Icon in Service Tracker Panel");
						webActions.isDisplayed(icon_servTracker_highPriority, "High Priority Icon in Service Tracker Panel");
						report.reportPass("Should display High Priority Icon in Service Tracker Panel");
					}
				}

				if("Success".contentEquals(type))
				{
					webActions.waitForPageLoaded();
					if(btn_ThreeDots_ServTrackerPnl.isDisplayed())
					{
						webActions.click(btn_ThreeDots_ServTrackerPnl,"Service tracker Al Data link");
						report.reportPass("Should click on Three dots in Service Tracker Panel");
						webActions.waitForPageLoaded();
						webActions.waitUntilisDisplayed(icon_servTracker_Clearance, "Success or Clearance Icon in Service Tracker Panel");
						webActions.isDisplayed(icon_servTracker_Clearance, "Success/Clearance icon in Service Tracker Panel");
						report.reportPass("Should display Success/Clearance Icon in Service Tracker Panel");
					}
				}	
			} catch (Exception e) {
				report.reportFail("Failed to display Module Status type as "+type+"in Service Tracker Panel due to: " + e,true);
			}

		} catch (Exception e) {
			report.reportFail("Failed to display Module Status in Service Tracker Panel due to: " + e,true);
		}
	}

	public void selectIntakeStatus(String value) throws Exception{
		try{
			report.reportInfo("value is :"+value);
			webActions.waitForVisibility(drpdwn_IntakeStatus, "Intake Status Drop Down");
			webActions.clickBYJS(drpdwn_IntakeStatus, "Intake Status Drop Down");
			report.reportPass("Clicked on Registrar drop down");
			webActions.waitForVisibility(drpvalue_IntakeStatus, "Intake Status");
			webActions.sendKeys(drpvalue_Registrar, value, "Intake Status");
			report.reportPass("Intake Status value is selected :"+value);
			webActions.click(btn_Submit, "Submit Button");
			report.reportPass("Clicked on Submit Button");
		}catch(Exception e){
			report.reportFail("Failed due to :",true);
		}
	}

	public void wheelChairAllDataPanel(String AcctNumber) {
		try {

			webActions.waitUntilisDisplayed(btn_threedots_serviceTracker, "Service Tracker three dots");
			String xpath1="//a[text()=' ";
			String xpath2=" ']";
			String xpath4=xpath1+AcctNumber+xpath2;
			WebElement visitcardbody = driver.findElement(By.xpath(xpath4));
			if(visitcardbody.isDisplayed())
			{
				webActions.click(visitcardbody,"Visit Card with Account Number :"+AcctNumber);
				report.reportPass("Should click on Visit Card with Account Number :"+AcctNumber);
				webActions.waitUntilisDisplayed(pnl_AllData, "All Data Panel");
				webActions.isDisplayed(pnl_AllData, "All Data Panel");
				report.reportPass("Should navigate to All Data Panel");
				webActions.waitForPageLoaded();
				webActions.isDisplayed(icon_AllData_wheelChair, "Wheel Chair Icon in All Data");
				report.reportPass("Should display Wheel chair icon in  All Data Panel");
			}
		} catch (Exception e) {
			report.reportFail("Failed to display wheel chair in All Data Panel due to: " + e,true);
		}
	}

	public void wheelChairNotDisplayedBoard(){		
		try{
			webActions.isDisplayed(icon_servTracker_wheelChair, "WheelChair Icon on Board");
			report.reportFail("Wheel Chair is displayed on service tracker board",true);
		}catch(Exception e){
			report.reportPass("Wheel Chair is not displayed on service tracker board");
		}		
	}

	public void wheelChairDisplayedBoard(){		
		try{
			webActions.isDisplayed(icon_servTracker_wheelChair, "WheelChair Icon on Board");
			report.reportPass("Wheel Chair is displayed on service tracker board");

		}catch(Exception e){
			report.reportFail("Wheel Chair is not displayed on service tracker board",true);
		}		
	}

	public void wheelChairNotDisplayedAllData(String AcctNumber){		
		try{
			webActions.waitUntilisDisplayed(btn_threedots_serviceTracker, "Service Tracker three dots");
			String xpath1="//a[text()=' ";
			String xpath2=" ']";
			String xpath4=xpath1+AcctNumber+xpath2;
			WebElement visitcardbody = driver.findElement(By.xpath(xpath4));
			if(visitcardbody.isDisplayed())
			{
				webActions.click(visitcardbody,"Visit Card with Account Number :"+AcctNumber);
				report.reportPass("Should click on Visit Card with Account Number :"+AcctNumber);
				webActions.waitUntilisDisplayed(pnl_AllData, "All Data Panel");
				webActions.isDisplayed(pnl_AllData, "All Data Panel");
				report.reportPass("Should navigate to All Data Panel");
				webActions.waitForPageLoaded();
				try{
					webActions.waitForElementToBeNotPresent(icon_AllData_wheelChair, "WheelChair Icon in ALL Data");
					report.reportPass("Wheel Chair is not displayed in All Data Panel");	
				}catch(Exception e){
					report.reportFail("Wheel Chair is displayed in All Data Panel",true);
				}	
			}
		} catch (Exception e) {
			report.reportFail("Failed to not display wheel chair in All Data Panel due to: " + e,true);
		}
	}





	public void wheelChairNotDisplayedServiceTracker(){		
		try {
			webActions.waitForPageLoaded();
			if(lnk_serviceTracker_AllData.isDisplayed())
			{
				webActions.waitUntilisDisplayed(lnk_serviceTracker_AllData, "Service Tracker All Data link");
				webActions.click(lnk_serviceTracker_AllData,"Service tracker Al Data link");
				report.reportPass("Should click on Service Tracker on All Data Panel");
				webActions.waitForPageLoaded();
				webActions.waitUntilisDisplayed(txt_serviceTracker_ServiceTrackerPnl,"Service Tracker in Service Tracker Panel");
				webActions.waitForPageLoaded();
				try {
					webActions.waitForElementToBeNotPresent(icon_servTracker_wheelChair, "WheelChair Icon is not present in Service Tracker Panel");
					report.reportPass("Wheel Chair is not displayed in Service Tracker Panel");	
				} catch (Exception e) {
					report.reportFail("Wheel Chair is displayed in Service Tracker Panel",true);
				}
			}
		} catch (Exception e) {
			report.reportFail("Failed to not display wheel chair in service tracker Panel due to: " + e,true);
		}
	}

	public void wheelChairServiceTrackerPanel() {
		try {
			webActions.waitForPageLoaded();
			if(lnk_serviceTracker_AllData.isDisplayed())
			{
				webActions.waitUntilisDisplayed(lnk_serviceTracker_AllData, "Service Tracker All Data link");
				webActions.click(lnk_serviceTracker_AllData,"Service tracker Al Data link");
				report.reportPass("Should click on Service Tracker on All Data Panel");
				webActions.waitForPageLoaded();
				webActions.waitUntilisDisplayed(txt_serviceTracker_ServiceTrackerPnl,"Service Tracker in Service Tracker Panel");
				webActions.waitForPageLoaded();
				webActions.isDisplayed(icon_servTracker_wheelChair, "Wheel Chair Icon in Service Tracker Panel");
				report.reportPass("Should display Wheel Chair icon in Service Tracker Panel ");
			}
		} catch (Exception e) {
			report.reportFail("Failed to display wheel chair in All Data Panel due to: " + e,true);
		}
	}



	public void enableWheelChair(String selectMode){
		try{
			int flag = 0;
			if(selectMode.contentEquals("True")){
				try {
					if(rdbtn_InActive.isDisplayed())
					{
						flag=1;
					}
				} catch (Exception e) {
					flag=0;
				}
				try {
					webActions.waitForPageLoaded();
					if(flag==1){	
						report.reportInfo("Wheel chair is displayed as Disabled");
						webActions.clickBYJS(rdbtn_WheelChair, "WheelChair RadioButton");
						report.reportInfo("Clicked on Wheel chair Radiobutton");
						webActions.waitForVisibility(rdbtn_Active, "Wheel Chair");
						webActions.waitForPageLoaded();
						webActions.assertDisplayed(btn_MWindowSubmit, "Submit");
						report.reportInfo("Submit button is displayed");
						webActions.clickBYJS(btn_MWindowSubmit,"submit");
						report.reportPass("Should click on submit button");
						updatevisit.getfilterMessages();
					}
					else{
						webActions.waitForPageLoaded();
						report.reportPass("WheelChair radio button is displayed as Enabled");
					}
				} catch (Exception e) {
					report.reportFail("Failed to identify WheelChair radio button as enabled",true);
				}
			}
			else if(selectMode.contentEquals("False")){
				webActions.waitForPageLoaded();
				try {
					if(rdbtn_Active.isDisplayed())
					{
						flag=1;
					}
				} catch (Exception e) {
					flag=0;
				}
				if(flag==1){
					report.reportInfo("Wheel chair is displayed as Enabled");
					webActions.clickBYJS(rdbtn_Active, "WheelChair Deselect");
					webActions.waitForPageLoaded();
					webActions.waitForVisibility(rdbtn_InActive, "Disabled Wheel Chair");
					webActions.click(btn_MWindowSubmit,"submit");
					report.reportPass("Should click on submit button");
					updatevisit.getfilterMessages();
				}
				else {
					webActions.waitForPageLoaded();
					report.reportPass("Wheel chair is already disabled");
				}
			}
			webActions.click(btn_MWindowClose,"Close Button");
			report.reportPass("Should click on Close Button");

		}catch(Exception e){
			report.reportFail("Failed to display wheel chair due to :",true);
		}
	}

	public void NavigateToServiceTrackerPanelModelWindow(String AcctNumber) {
		try{
			String xpath1="//a[text()=' ";
			String xpath2=" ']";
			String xpath4=xpath1+AcctNumber+xpath2;
			WebElement visitcardbody = driver.findElement(By.xpath(xpath4));
			if(visitcardbody.isDisplayed())
			{
				webActions.click(visitcardbody,"Visit Card with Account Number :"+AcctNumber);
				report.reportPass("Should click on Visit Card with Account Number :"+AcctNumber);
				webActions.waitUntilisDisplayed(pnl_AllData, "All Data Panel");
				webActions.isDisplayed(pnl_AllData, "All Data Panel");
				report.reportPass("Should navigate to All Data Panel");
				webActions.waitForPageLoaded();
				try {
					if(lnk_serviceTracker_AllData.isDisplayed())
					{
						webActions.waitUntilisDisplayed(lnk_serviceTracker_AllData, "Service Tracker All Data link");
						webActions.click(lnk_serviceTracker_AllData,"Service tracker Al Data link");
						report.reportPass("Should click on Service Tracker on All Data Panel");
						webActions.waitForPageLoaded();
						webActions.waitUntilisDisplayed(txt_serviceTracker_ServiceTrackerPnl,"Service Tracker in Service Tracker Panel");
						webActions.waitForPageLoaded();
						report.reportPass("Should navigate to service tracker Panel");

					}
				} catch (Exception e) {
					report.reportFail("Failed to navigate to service tracker panel due to: " + e,true);
				}
			}
		} catch (Exception e) {
			report.reportFail("Failed to display visit card due to: " + e,true);
		}
	}

	public void openModelWindow() {
		try{
			webActions.waitUntilisDisplayed(btn_ThreeDots_ServTrackerPnl, "Service Tracker All Data link");
			if(btn_ThreeDots_ServTrackerPnl.isDisplayed())
			{
				webActions.click(btn_ThreeDots_ServTrackerPnl,"Service tracker Al Data link");
				report.reportPass("Should click on Three dots in Service Tracker Panel");
				webActions.waitForPageLoaded();
			}

		} catch (Exception e) {
			report.reportFail("Failed to display more options due to: " + e,true);
		}
	}

	public void changeModuleStatus(String type) {

		try{
			String messageTitle ="Success!";
			String messageContent="Data saved successfully.";
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			if("Success".contentEquals(type))
			{
				//webActions.uncheck(chkbox_Highpriority, "High Priority");
				if(checked_Highpriority.isDisplayed())
				{
					webActions.click(checked_Highpriority, "CheckBox HighPriority");
					report.reportPass("Should UnCheck the checkbox in high priority in Model Window");
				}
				report.reportPass("UnCheck the high priority");
			}
			else if("Alert".contentEquals(type))
			{
				if(chkbox_Highpriority.isDisplayed())
				{
					webActions.click(chkbox_Highpriority, "CheckBox HighPriority");
					report.reportPass("Should Check the checkbox in high priority in Model Window");
				}
			}
			try {
				if(!btn_Submit.isEnabled())
				{
					webActions.check(chkbox_Highpriority, "High Priority");
					webActions.click(btn_Submit, "Submit Button");
				}
				else
				{
					webActions.click(btn_Submit, "Submit Button");
				}

			} catch (Exception e) {
				report.reportFail("Failed as Submit button is not enabled due to: " + e,true);
			}
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle=titleContent[0];
			String actContent=titleContent[1];
			report.reportInfo("Actual alert message after user created: "+msg);
			report.reportInfo("Actual title :"+actTitle);
			report.reportInfo("Actual content :"+actContent);
			if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent)))
			{
				report.reportPass("Successfully user is created and alert message is matched: "+msg);
			}
			webActions.click(btn_Close, "Close button");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
		}
		catch (Exception e) {
			report.reportFail("Failed to display more options due to: " + e,true);
		}
	}
	
	
	public void getModuleStatusinNeedAttention(String expModuleName,String expModuleStatus){
		String actModuleStatus="";
		StringBuilder unmatch=new StringBuilder();
		try {
		List<WebElement> moduleName=li_AllModuleNameNeedsAttention;
			for (WebElement webElement : moduleName) {
				String actModuleName=webElement.getText().trim();
				if(actModuleName.contentEquals(expModuleName)){
					actModuleStatus=webElement.findElement(By.tagName("financial-clearance-status")).findElement(By.tagName("img")).getAttribute("src");
					break;
				}
			}
			if(actModuleStatus.contains(expModuleStatus)){
				report.reportPass("Successfully verified the Module Status in Needs Attention");
			}else{
				unmatch.append("Failed to verify the Module Status in Needs Attention");
				report.reportFail("Failed to verify the Module Status in Needs Attention",true);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

	@Override
	protected ExpectedCondition<?> getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
