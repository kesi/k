package com.ipas.hf.web.steps;

import com.ipas.hf.azureutilities.CosmosDbDataValidation;
import com.ipas.hf.web.pages.ipasPages.MedicalNecessityPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class MedicalNecessitySteps {
	MedicalNecessityPage medical=new MedicalNecessityPage();
	CosmosDbDataValidation cosmos=new CosmosDbDataValidation();

	@Then("Verify the display of Medical Necessity {string}")
	public void verify_the_display_of_Medical_Necessity(String panel, DataTable testdata) {
		medical.verifyMedicalPanel(panel, testdata);
	}

	@Then("Verify the medical necessity of {string} module status when {string}")
	public void verify_the_medical_necessity_of_module_status_when(String panel, String data) {
		medical.verifyMedicalPanelModuletStatus(panel, data);
	}

	@Then("Verify the medical necessity module status as {string}")
	public void verify_the_medical_necessity_module_status_as(String status) {
		medical.verifymoduleStatus(status);
	}

	@Then("Verify the display of last run by in both short and full panels of medical necessity")
	public void verify_the_display_of_last_run_by_in_both_short_and_full_panels_of_medical_necessity() {
		medical.verifyLastRunByInMedicalPanel();
	}

	@Then("Verify expand and collapse of the medical necessity Panel")
	public void verify_expand_and_collapse_of_the_medical_necessity_Panel() throws Exception {
		medical.verifyExpandandCollapsPostalPanel();
	}
	@Then("Click on Medical necessity short panel")
	public void click_on_Medical_necessity_short_panel() {
		medical.clickOnMedicalShortPanel();
	}

	@Then("Verify the display of fileds")
	public void verify_the_display_of_fileds(DataTable testdata) {
		medical.verifyMedicalFullPanelFields(testdata);
	}

	@Then("Verify the ICD code mode as {string}")
	public void verify_the_ICD_code_mode_as(String mode) {
		medical.verifyICDCodeMode(mode);
	}

	@Then("Connect to {string} cosmosDB and {string} conatiner and verify the display of ICD and CPT code values")
	public void connect_to_cosmosDB_and_conatiner_and_verify_the_display_of_ICD_and_CPT_code_values(String dataBase, String containerName) {
		String id=cosmos.getPatientVisitIdFromResponse();
		cosmos.readICDANDCPTCodesFromCosmos(dataBase, containerName, id);
		medical.verifyICDAndCPTCodes();

	}
	@Then("Click on medical necessity check and verify the links and buttons")
	public void click_on_medical_necessity_check_and_verify_the_links_and_buttons(DataTable testdata) {
		medical.verifyMedicalFullPanelLinksAndButtons(testdata);
	}
	@Then("Delete the ICD and CPT codes and verify")
	public void delete_the_ICD_and_CPT_codes_and_verify(DataTable testdata) {
		medical.verifyICDandCPTmessages(testdata);
	}
	@Then("Verify the run button mode as {string}")
	public void verify_the_run_button_mode_as(String mode) {
		medical.verifyRunBtnMode(mode);
	}
	@Then("Click on Cancel button and verify the navigation")
	public void click_on_Cancel_button_and_verify_the_navigation() {
		medical.verifyNavigation();
	}
	@Then("Verify the display of medical necessity results as {string}")
	public void verify_the_display_of_medical_necessity_results_as(String type, DataTable testdata) {
		medical.verifyMedicalNecessityResults(type, testdata);
	}
	@Then("Verify the display of links and fields on full page")
	public void verify_the_display_of_links_and_fields_on_full_page(DataTable testdata) {
		medical.verifyFieldsForNotRun(testdata);
	}

	@Then("Verify the create ABN button mode as {string}")
	public void verify_the_create_ABN_button_mode_as(String mode) {
		medical.verifyCreateABNBtnMode(mode);
	}
	/*@Then("Update Auto Run for {string} Plan Code or Name as {string} and facility {string} as {string}")
	public void update_Auto_Run_for_Plan_Code_or_Name_as_and_facility_as(String moduleName, String plan_Name_Code, String facility, String runStatus) throws Exception {
		medical.medNecAutoRunTurnOnAndTrunOff(moduleName, plan_Name_Code, facility, runStatus);
	}*/
	@Then("Click on ICD text and verify the window fields")
	public void click_on_ICD_text_and_verify_the_window_fields(DataTable testdata) {
		medical.verifyICDWindowFields(testdata);
	}

	@Then("Enter invalid ICD code in search box and verify as {string}")
	public void enter_invalid_ICD_code_in_search_box_and_verify_as(String input) {
		medical.verifyICDValidationMsg(input);
	}

	@Then("Click on Cancel button and verify navigation")
	public void click_on_Cancel_button_and_verify_navigation() {
		medical.verifyICDNavigation();
	}
	@Then("Click on CPT link and veirfy the fields")
	public void click_on_CPT_link_and_veirfy_the_fields(DataTable testdata) {
		medical.verifyCPTWindowFields(testdata);
	}

	@Then("Enter invalid CPT code in search box and verify as {string}")
	public void enter_invalid_CPT_code_in_search_box_and_verify_as(String input) {
		medical.verifyCPTValidationMsg(input);
	}
	@Then("Click on CPT Cancel button and verify navigation")
	public void click_on_CPT_Cancel_button_and_verify_navigation() {
		medical.verifyCPTNavigation();
	}
	@Then("Select ICD code as {string} from ICD window")
	public void select_ICD_code_as_from_ICD_window(String code) {
		medical.selectICDCode(code);
	}
	@Then("Select CPT code as {string} from CPT window")
	public void select_CPT_code_as_from_CPT_window(String code) {
		medical.selectCPTCode(code);
	}
	@Then("Verify the display of message as {string}")
	public void verify_the_display_of_message_as(String expMsg) {
		medical.verifyCPTMsg(expMsg);
	}
	@Then("Click on Run button")
	public void click_on_Run_button() {
		medical.clickOnRunBtn();
	}
	@Then("Verify the display of CPT codes")
	public void verify_the_display_of_CPT_codes(DataTable testdata) {
		medical.verifyCPTcodes(testdata);
	}	
	@Then("Verify the display of last run for medical necessity manual run")
	public void verify_the_display_of_last_run_for_medical_necessity_manual_run() {
		medical.verifyLastRunByInMedicalPanel_Manual();
	}
}
