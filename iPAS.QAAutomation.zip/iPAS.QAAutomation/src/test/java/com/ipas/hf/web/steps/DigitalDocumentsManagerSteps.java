package com.ipas.hf.web.steps;


import org.json.simple.parser.ParseException;

import com.ipas.hf.web.pages.ipasPages.DigitalDocumentsManagerPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class DigitalDocumentsManagerSteps {

	DigitalDocumentsManagerPage digitalDoc=new DigitalDocumentsManagerPage();

	@Then("Get get Patient VisitId from response body {string}  and verify the displayed breadcrumb based on followed by Patient Visit number as {string}")
	public void get_get_Patient_VisitId_from_response_body_and_verify_the_displayed_breadcrumb_based_on_followed_by_Patient_Visit_number_as(String responseValue, String menuName) throws Exception {
		digitalDoc.verifyDisplayedBreadcrumb(responseValue,menuName);
	}

	@Then("Update json file for Digital Documents {string}")
	public void update_json_file_for_Digital_Documents(String eventType) throws Exception {
		digitalDoc.updateDigitalDocumentsJSON(eventType);
	}


	@Then("Verify the display Patient Visit Summary Information {string}")
	public void verify_the_display_Patient_Visit_Summary_Information(String scenarioName) throws Exception {
		digitalDoc.verifyPatientVisitSummaryInformation(scenarioName);
	}

	@Then("Verify the display label names")
	public void verify_the_display_label_names(DataTable lableName) throws Exception {
		digitalDoc.verifyTheLabelNames(lableName);
	}

	@Then("Verify the Expand and Collapse the panel")
	public void verify_the_Expand_and_Collapse_the_panel() throws Exception {
		digitalDoc.verifyExpandandCollapsethePanel();
	}

	@Then("Verify the displayed breadcrumb as {string} when navigate from {string}")
	public void verify_the_displayed_breadcrumb_as_when_navigate_from(String menuName,String pageName) throws Exception {
		digitalDoc.verifyDisplayedBreadcrumbFollowedbyDigitalDocumentsManager(menuName,pageName);
	}
	
	@Then("Verify the error message if documents count is zero {string} when navigate from {string}")
	public void verify_the_error_message_if_documents_count_is_zero_when_navigate_from(String errorMessage,String pageName) throws Exception {
		digitalDoc.verifytheErrorMessage(errorMessage,pageName);
	}
	
	@Then("Verify the display of label names in the Digital Document Manager page")
	public void verify_the_display_of_label_names_in_the_Digital_Document_Manager_page(DataTable labelss) throws Exception {
		digitalDoc.verifyLabelNamesinDigitalDocumentsMangerPage(labelss);
	}

	@Then("Verify navigation and Verify the display Patient Visit Summary Information {string} in DDM page")
	public void verify_navigation_and_Verify_the_display_Patient_Visit_Summary_Information_in_DDM_page(String scenarioName) {
	digitalDoc.verifyPatientVisitSummaryInformationinDDMPage(scenarioName);
	}
	
	@Then("Verify the Digital Documents count and Financial Clearance Status")
	public void verify_the_Digital_Documents_count_and_Financial_Clearance_Status(DataTable testData) throws Exception {
		digitalDoc.verifyDocumentsCountandFinancialClearanceStatus(testData);
	}

	@Then("Verify drag and drop")
	public void verify_drag_and_drop() throws Exception {
		digitalDoc.dragDrop();
	}
	
	@Then("Update Digital Documents JSON File {string}")
	public void update_Digital_Documents_JSON_File(String fieldName) throws Exception {
		digitalDoc.updateDigitalDocumentsJSONFile(fieldName);
	}
	
	@Then("Select Form {string}")
	public void select_Form(String formName) {
		digitalDoc.clickOnFormName(formName);
	}
	
	@Then("Submit the Pre Registrationform")
	public void submit_the_Pre_Registrationform(DataTable testData) {
		digitalDoc.enterPreRegistrationForm(testData);
	}
	
	@Then("Navigate to Digital Document Manger full page")
	public void navigate_to_Digital_Document_Manger_full_page() {
		digitalDoc.navigateDigitalDocumentsManagerFullPage();
	}


	@Then("Open {string} Form Discrepancy window")
	public void open_Form_Discrepancy_window(String formName, DataTable testData) {
		digitalDoc.openDiscrepancyWindow(formName, testData);
	}



}
