package com.ipas.hf.web.steps;


import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.ipasPages.EditNewsPage;
import com.ipas.hf.web.pages.ipasPages.EditUserPage;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class EditNewsSteps {

	EditNewsPage editnews = new EditNewsPage();
	RestActions rest=new RestActions();
	
	@Then("verify the News List page display")
	public void verify_the_News_List_page_display() {
		editnews.navigateToNewsList();
	}
	
	@Then("verify the Hyperlink in News list")
    public void verify_the_Hyperlink_in_News_list() {
		editnews.verifyHyperlink();
	}
	
	@Then("verify when user clicks the News title")
	public void verify_when_user_clicks_the_News_title() {
		editnews.navigateToNewsList();
		editnews.navigateToEditNews();
	}
	
	@Then("verify the breadcrumbs at the top of the page")
	public void verify_the_breadcrumbs_at_the_top_of_the_page(DataTable breadcrumb) {
		editnews.verifyBreadcrumbinEditNewsPage(breadcrumb);
	}
	
	@Then("verify Edit News Page will consist of the following section")
	public void verify_the_Edit_News_sections(DataTable Titlenames) {
		editnews.verifyEditNewsTitles(Titlenames);
	}
	
	@Then("verify the sections for content in Edit News")
	public void verify_the_sections_for_content() {
		editnews.verifyContentSection();
	}
	
	@Then("verify the fields for settings section in Edit News")
	public void verify_the_fields_for_settings_section(DataTable Sections) {
		editnews.verifySettingsSections(Sections);
	}
	
	@Then("Verify the mandatory fields displayed in edit News")
	public void verify_the_mandatory_fields_displayed_in_edit_News(DataTable mandatoryFields) {
		editnews.verifyMandatoryfieldsEditNews(mandatoryFields);
	}
	
	@Then("Verify the Save functionality in edit News")
	public void verify_the_Save_functionality_in_edit_News() {
		editnews.verifySaveFunctionality();
	}
	
	@Then("Verify the validations for News Title in edit News")
	public void verify_the_validations_in_edit_News(DataTable ValidationMsg) {
		editnews.verifyValidationsNewsTitle(ValidationMsg);
	}
}
