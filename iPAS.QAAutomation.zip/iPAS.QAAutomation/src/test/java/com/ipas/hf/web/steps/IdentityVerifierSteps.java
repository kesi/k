package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.IdentityVerifierPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class IdentityVerifierSteps {

	IdentityVerifierPage identity=new IdentityVerifierPage();

	@Then("Verify the display of Identity Verifier of {string} as {string}")
	public void verify_the_display_of_Identity_Verifier_of_as(String panel, String title) {
		identity.verifyIdentityVerifier(panel, title);
	}
	@Then("Verify the identity verifier {string} module status when {string}")
	public void verify_the_identity_verifier_module_status_when(String panel, String data) {
		identity.verifyIdentityModuletStatus(panel, data);	  
	}
	@Then("Verify expand and collapse of the Identity verifier Panel")
	public void verify_expand_and_collapse_of_the_Identity_verifier_Panel() throws Exception {
		identity.verifyExpandandCollapsIdentityPanel();
	}
	@Then("Click on identity verifier panel link")
	public void click_on_identity_verifier_panel_link() {
		identity.clickOnIdentityPanel();
	}
	@Then("Verify the last run by in short and full panel")
	public void verify_the_last_run_by_in_short_and_full_panel() {
		identity.verifyLastRunByInIdentityPanel();
	}
	@Then("Verify the display of information")
	public void verify_the_display_of_information(DataTable testdata) {
		identity.verifyVerificationResponse(testdata);
	}
	@Then("Verify the display of information on the {string} as {string}")
	public void verify_the_display_of_information_on_the_as(String panel, String mesg) {
		identity.verifyIdentityVerifierMessage(panel, mesg);
	}
	@Then("Click on Identity New Request button")
	public void click_on_Identity_New_Request_button() {
		identity.clickOnIdentityNewRequestBtn();
	}

	@Then("Verify the display of {string} in indetity verifier new request window")
	public void verify_the_display_of_in_indetity_verifier_new_request_window(String scenario,DataTable testData) {
		identity.verifyIdetifierFiedsInNewRequestWindow(scenario, testData);
	}
	@Then("Click on cancel and cross options from identity window and verify the navigation")
	public void click_on_cancel_and_cross_options_from_identity_window_and_verify_the_navigation() {
		identity.cancelAndCrossNavigation();
	}
	@Then("Verify the display of message on the identity {string} panel as {string}")
	public void verify_the_display_of_message_on_the_identity_panel_as(String panel, String message) {
		identity.verifyIdentityMsgForManualRun(panel, message);
	}

	@Then("Click on identity verifier panel link for manaul request")
	public void click_on_identity_verifier_panel_link_for_manaul_request() {
		identity.clickOnIdentityPanelManual();
	}

	@Then("Click on request button")
	public void click_on_request_button() {
		identity.clickOnRequest();
	}

	@Then("Verify the last run by for manual request in Identity full and short panels")
	public void verify_the_last_run_by_for_manual_request_in_Identity_full_and_short_panels() {
		identity.verifyManualLastRunByInPostalPanel();
	}
	@Then("Navigate to visit main page")
	public void navigate_to_visit_main_page() {
		identity.navigateToVisitMainPage();
	}
	@Then("Enter the valid data in new request window")
	public void enter_the_valid_data_in_new_request_window(DataTable testData) {
		identity.enterAddressInIdentityWindow(testData);
	}
	@Then("Verify the display of historical identity verifier on selecting the history from history window")
	public void verify_the_display_of_historical_identity_verifier_on_selecting_the_history_from_history_window() {
		identity.verifyHistoricalIdentityTitle();
	}
	@Then("Click on current request")
	public void click_on_current_request() {
		identity.clickOnCurrentRequest();
	}
	@Then("Verify the display of historical address")
	public void verify_the_display_of_historical_address(DataTable testdata) {
		identity.verifyHistoricalAddress(testdata);
	}





}
