package com.ipas.hf.apiui.runners;


	
	import java.io.IOException;

	import com.ipas.hf.reporting.ExtentSummary;
	import com.ipas.hf.testbase.TestBase;

	import cucumber.api.CucumberOptions;
	import cucumber.api.Scenario;
	import cucumber.api.java.After;
	import cucumber.api.java.Before;

	@CucumberOptions(features = { "src/test/resources/features/APIBasedUI" }, glue = { "com.ipas.hf.api","com.ipas.hf.web",
			"com.ipas.hf.testbase" }, monochrome = true, plugin = { "json:target/cucumber-reports/cucumber.json",
					"rerun:target/APIRerun.txt" }

	)
	public class APIUITestRunner extends TestBase {

		@Before
		public void before(Scenario scenario) throws Exception {

		}

		@After(order = 1)
		public void after(Scenario scenario) throws IOException {
			String name = scenario.getName();
			if (scenario.isFailed()) {
				ExtentSummary.logFailTest(name);

			} else {
				ExtentSummary.logPassTest(name);
			}
		}



}
