package com.ipas.hf.web.steps;

import java.util.ArrayList;
import java.util.Properties;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.utilities.ConfigProperties;
import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.UpdateVisitPage;
import com.ipas.hf.web.pages.ipasPages.VPVServiceTrackerPanelPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class VPVServiceTrackerPanelSteps {

	private ConfigProperties configProp = TestBase.prop;
	VPVServiceTrackerPanelPage vsrvcPanel = new VPVServiceTrackerPanelPage();
	UpdateVisitPage updateVisit = new UpdateVisitPage();
	Login logIn = new Login();
	HomePage home = new HomePage();

	@Then("Click on VisitID on Visit Card to navigate to Service Tracker Panel")
	public void click_on_VisitID_on_Visit_Card_to_navigate_to_Service_Tracker_Panel() {
		//String visitID= updateVisit.getValuefromJSONresponseBasedOnObject();
		String visitID=logIn.getVisitIdFromResponse("$..displayPatientAccountId");
		vsrvcPanel.clickVisitID(visitID);
	}
	
	@Then("Click on PatientVisitId on Visit Card to navigate to Service Tracker Panel")
	public void click_on_PatientVisitId_on_Visit_Card_to_navigate_to_Service_Tracker_Panel() {
		String visitID= updateVisit.getValuefromJSONresponseBasedOnObject();
		vsrvcPanel.clickVisitID(visitID);
	}
	
	
	@Then("Search with Visit Card with Visit ID :VisitID as {string}")
	public void search_with_Visit_Card_with_Visit_ID_VisitID_as(String visitID) throws Exception {
		vsrvcPanel.simpleSearch(visitID);
	}

	@Then("Verify Patinet Visit Main Page All Data")
	public void verify_Patinet_Visit_Main_Page() {
		vsrvcPanel.verifyPVMainPageAllData();
	}

	@Then("Verify BreadCrumb for ServiceTracker and VisitID as {string}")
	public void verify_BreadCrumb_for_ServiceTracker_and_VisitID(String responseValue) {
		String visitID= logIn.getVisitIdFromResponse(responseValue);
		vsrvcPanel.verifyBreadCrumb(visitID);
	}

	@Then("Verify ServiceTracker is displayed on the Second column")
	public void verify_ServiceTracker_is_displayed_on_the_Second_column() {
		vsrvcPanel.verifyServiceTrackerOnSecondColumn();
	}

	@Then("Click on ServiceTracker BreadCrumb in Main Page verify page navigation to Service Tracker Page")
	public void click_on_ServiceTracker_BreadCrumb_in_Main_Page_verify_page_navigation_to_Service_Tracker_Page() throws Exception {
		vsrvcPanel.clikOnServiceTrackerBreadCrumb();
	}

	@Then("Verify D is displayed beside the Service Department as {string}")
	public void verify_D_is_displayed_beside_the_Service_Department_as(String pocCode) throws Exception {
		vsrvcPanel.verifyDBeforeServiceDepartment(pocCode);
	}

	@Then("Verify Service Department name is displayed on Service Tracker panel against to patient visit")
	public void verify_Service_Department_name_is_displayed_on_Service_Tracker_panel_against_to_patient_visit() throws Exception {

	}

	@Then("Verify the Destination, Registrar")
	public void verify_the_Destination_Registrar_and_Priority_values() throws Exception {
		vsrvcPanel.readDestRegistOnCard();
	}

	@Then("Verify the Destination, Registrar values on Vist Card and ST Panel")
	public void verify_the_Destination_Registrar_values_on_Vist_Card_and_ST_Panel() throws Exception {
		Thread.sleep(20000);
		ArrayList<String> actList = vsrvcPanel.readDestRegistOnCard();		
		String visitID= updateVisit.getValuefromJSONresponseBasedOnObject();
		vsrvcPanel.clickVisitID(visitID);
		ArrayList<String> expList = vsrvcPanel.readDataInVisitMainPage();
		vsrvcPanel.compareDataonVisitCardAndPanel(actList,expList);
	}	
	
	@Then("Verify the display of Wait Time on Service Tracker Panel")
	public void verify_the_display_of_Wait_Time_on_Service_Tracker_Panel() throws Exception {
		String visitID= updateVisit.getValuefromJSONresponseBasedOnObject();
		vsrvcPanel.simpleSearch(visitID);
		vsrvcPanel.compareWaitTime(visitID);
	}


	@Then("Verify Current Status on Visit Card and Service Tracker Panel")
	public void verify_Current_Status_on_Visit_Card_and_Service_Tracker_Panel() throws Exception {
		vsrvcPanel.compareStatusOnSTPanel();	
	}
	
	@Then("Verify expand and collapse of the Service Tracker Panel")
	public void verify_expand_and_collapse_of_the_Service_Tracker_Panel() throws Exception {
		updateVisit.verifyExpandandCollapseServiceTrackerPanel();
	}
}

