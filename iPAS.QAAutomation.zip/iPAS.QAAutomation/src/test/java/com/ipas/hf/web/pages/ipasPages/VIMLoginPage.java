package com.ipas.hf.web.pages.ipasPages;

import java.awt.HeadlessException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.dbutilities.SqlQueries;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;


public class VIMLoginPage extends BasePage {

	String resetPassword="";
	private RestActions rest = new RestActions();



	@FindBy(xpath = "//input[@formcontrolname='firstName']")
	private WebElement txt_FirstName; 

	@FindBy(xpath = "//input[@formcontrolname='lastName']")
	private WebElement txt_LastName; 

	@FindBy(xpath = "//button[@aria-label='Open calendar']")
	private WebElement btn_OpenCalendar; 

	@FindBy(xpath = "//a[contains(text(),'Confirm')]")
	private WebElement btn_Confirm; 

	@FindBy(xpath = "//input[@formcontrolname='valcode']")
	private WebElement txt_OTP; 

	@FindBy(linkText = "Let's begin!")
	private WebElement btn_LetsBegin;

	@FindBy(xpath = "//div[@class='summary-grid']/div")
	private List<WebElement> lbl_SummaryGrid;

	@FindBy(xpath = "//p[normalize-space()='Complete documents']")
	private WebElement lnk_CompleteDocuments;

	@FindBy(xpath = "//div[contains(text(),'Physicians Order')]")
	private WebElement lnk_PhysiciansOrder;

	@FindBy(xpath = "//p[contains(text(),'Click here to upload file')]")
	private WebElement btn_ClickHereToUploadFile;

	@FindBy(xpath ="//mat-dialog-container//app-information-dialog/h3")
	private WebElement lbl_SuccessMessage;

	@FindBy(xpath = "//a[contains(text(),'OK')]")
	private WebElement btn_OK;

	@FindBy(xpath = "//div[contains(text(),'Physicians Order')]/img")
	private WebElement img_PhysiciansOrder;

	@FindBy(xpath = "//div[contains(text(),'Photo Id')]")
	private WebElement lnk_PhotoId;

	@FindBy(xpath = "//div[contains(text(),'Photo Id')]/img")
	private WebElement img_PhotoId;

	@FindBy(xpath = "//div[contains(text(),'Insurance Card')]")
	private WebElement lnk_InsuranceCard;

	@FindBy(xpath = "//div[contains(text(),'Insurance Card')]/img")
	private WebElement img_InsuranceCard;

	@FindBy(xpath = "//span[(text()='Upload Documents')]/../p[2]")
	private WebElement lbl_UploadDocumentsCount;

	@FindBy(xpath = "//span[contains(text(),'Complete Documents')]/../p")
	private WebElement lbl_CompleteDocumentsCount;

	@FindBy(xpath = "//p[contains(text(),'Complete documents')]/../p[2]")
	private WebElement lbl_CompleteDocumentsCount_Home;


	String year1="//td[@aria-label='";
	String year2="']";

	String month1="//td[contains(@aria-label,'";
	String month2="')]";

	String day1="//div[normalize-space()='";
	String day2="']";


	@FindBy(xpath = "//a[contains(text(),'Try again')]")
	private WebElement btn_TryAgain;

	@FindBy(xpath = "//div[@class='validation-header']/h3")
	private WebElement lbl_ValidationHeader;

	@FindBy(xpath = "//div[@class='validation-header']/../p[1]")
	private WebElement lbl_ValidationMessage;





	public VIMLoginPage() {
		PageFactory.initElements(driver, this);
	}

	public void openVIMApplication() throws Throwable {
		try {
			String VIMURL = TestBase.prop.VIMURL();
			String InvitationReference=null;
			
			for (int i=0; i<20; i++) {
				System.out.println("Iteration: "+i);
				try {
					InvitationReference = SqlQueries.getInvitationReference(getPatientVisitId())
							.replaceAll("\\+", "%2b").replaceAll("\\/", "%2f");
					System.out.println(i+" :If Cond Iteration: "+InvitationReference);
					if(InvitationReference!=null){
						break;
					}
				} catch (Exception e) {
				}
			}
			System.out.println("End Iteration: ");
			InvitationReference=InvitationReference.substring(0, InvitationReference.length() - 2);
			VIMURL=VIMURL+InvitationReference+"%3d%3d";
			report.reportInfo("VIM Base Url: "+VIMURL);
			webActions.loadURL(VIMURL);
			report.reportPass("VIM Application opened successfully");
		} catch (Exception e) {
			report.reportFail("Failed to open VIM application: "+e);
		}
	}

	public String getPatientFirstName(){
		String patientFirstName = rest.getStringValueFromResponse("$..patientFirstName");
		patientFirstName=replaceAll(patientFirstName);
		return patientFirstName;
	}

	public String getPatientLastName(){
		String patientLastName = rest.getStringValueFromResponse("$..patientLastName");
		patientLastName=replaceAll(patientLastName);
		return patientLastName;
	}

	public String getPatientDateOfBirth(){
		String patientDateOfBirth = rest.getStringValueFromResponse("$..patientDateOfBirth");
		patientDateOfBirth=replaceAll(patientDateOfBirth);
		return patientDateOfBirth;
	}

	public String getPatientVisitId(){
		String patientVisitId = rest.getStringValueFromResponse("$..patientVisitId");
		patientVisitId=replaceAll(patientVisitId);
		return patientVisitId;
	}
	public void loginVIM() {
		try {
			webActions.waitForPageLoaded();
			webActions.waitUntilPresentAndDisplayed(txt_FirstName, "First Name");
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibility(txt_FirstName, "First Name", 60);
			//webActions.waitUntilPresentAndDisplayed(txt_FirstName, "First Name");
			webActions.sendKeys(txt_FirstName, getPatientFirstName(), "First Name");
			webActions.sendKeys(txt_LastName, getPatientLastName(), "Last Name");
			webActions.click(btn_OpenCalendar, "Calendar");
			driver.findElement(By.xpath(year1+getYear(getPatientDateOfBirth())+year2)).click();
			driver.findElement(By.xpath(month1+getMonth(getPatientDateOfBirth())+month2)).click();
			driver.findElement(By.xpath(day1+getDay(getPatientDateOfBirth())+day2)).click();
			webActions.click(btn_Confirm, "Confirm");
			webActions.waitForPageLoaded();
			String verificationCode=SqlQueries.getVerificationCode(getPatientVisitId());
			webActions.waitForVisibility(txt_OTP, "Verification Code");
			webActions.sendKeys(txt_OTP, verificationCode, "Verification Code");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_LetsBegin,"LetsBegin");
			webActions.click(btn_LetsBegin, "LetsBegin");
			webActions.waitUntilListisDisplayed(lbl_SummaryGrid, "SummaryGrid");
			Thread.sleep(5000);
			report.reportPass("Successfully login VIM application");
		} catch (Exception e) {
			report.reportFail("Failed to login VIM application: "+e);
		}
	}

	public void uploadDocuments(DataTable testData){
		try {
			ArrayList<String>data=new ArrayList<>(testData.asList());
			uploadPhysiciansOrder(data.get(0),data.get(3),data.get(6));
			uploadPhotoId(data.get(1),data.get(4),data.get(6));
			uploadInsuranceCard(data.get(2),data.get(5),data.get(6));
		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}
	public void uploadPhysiciansOrder(String fileName,String expSuccessMessage,String expStatus) throws Exception{
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.waitAndClick(lnk_CompleteDocuments, "Complete Documents");
			webActions.waitForVisibility(lnk_PhysiciansOrder, "Physicians Order");
			webActions.waitAndClick(lnk_PhysiciansOrder, "Physicians Order");
			webActions.waitAndClick(btn_ClickHereToUploadFile, "Click Here To Upload File");
			Thread.sleep(5000);
			uploadFile(fileName);
			webActions.waitAndClick(btn_Confirm, "Confirm");
			webActions.waitForVisibility(lbl_SuccessMessage, "Success Message");
			String actSuccessMessage=webActions.waitAndGetText(lbl_SuccessMessage, "Success Message");
			if(expSuccessMessage.contentEquals(actSuccessMessage)){
				report.reportPass("Successfully verified the message after upload the Physicians Order: "+actSuccessMessage);
			}else{
				unmatch.append("Fail to verify the message after upload the Physicians Order: "+actSuccessMessage);
				report.reportFail("Fail to verify the message after upload the Physicians Order: "+actSuccessMessage,true);
			}
			webActions.waitAndClick(btn_OK, "OK");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			Thread.sleep(5000);
			webActions.waitForVisibility(img_PhysiciansOrder, "Physicians Order");
			String actStatus=webActions.getAttributeValue(img_PhysiciansOrder, "src", "Physicians Order Status");
			if(actStatus.contains(expStatus)){
				report.reportPass("Successfully verified the status after upload the Physicians Order");
			}else{
				unmatch.append("Fail to verify the status after upload the Physicians Order");
				report.reportFail("Fail to verify the status after upload the Physicians Order",true);
			}
			if(unmatch.length()==0){
				report.reportPass("Successfully upload the Physicians Order");
			}else{
				throw new Exception("Fail to upload the Physicians Order: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void uploadPhotoId(String fileName,String expSuccessMessage,String expStatus) throws Exception{
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.waitAndClick(lnk_PhotoId, "Photo Id");
			webActions.waitAndClick(btn_ClickHereToUploadFile, "Click Here To Upload File");
			Thread.sleep(5000);
			uploadFile(fileName);
			webActions.waitAndClick(btn_Confirm, "Confirm");
			webActions.waitForVisibility(lbl_SuccessMessage, "Success Message");
			String actSuccessMessage=webActions.waitAndGetText(lbl_SuccessMessage, "Success Message");
			if(expSuccessMessage.contentEquals(actSuccessMessage)){
				report.reportPass("Successfully verified the message after upload the PhotoId: "+actSuccessMessage);
			}else{
				unmatch.append("Fail to verify the message after upload the PhotoId: "+actSuccessMessage);
				report.reportFail("Fail to verify the message after upload the PhotoId: "+actSuccessMessage,true);
			}
			webActions.waitAndClick(btn_OK, "OK");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			Thread.sleep(5000);
			webActions.waitForVisibility(img_PhotoId, "Photo Id Status");
			String actStatus=webActions.getAttributeValue(img_PhotoId, "src", "Photo Id Status");
			if(actStatus.contains(expStatus)){
				report.reportPass("Successfully verified the status after upload the Photo Id");
			}else{
				unmatch.append("Fail to verify the status after upload the Photo Id");
				report.reportFail("Fail to verify the status after upload the Photo Id",true);
			}

			if(unmatch.length()==0){
				report.reportPass("Successfully upload the Photo Id");
			}else{
				throw new Exception("Fail to upload the Photo Id: "+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void uploadInsuranceCard(String fileName,String expSuccessMessage,String expStatus) throws Exception{
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.waitAndClick(lnk_InsuranceCard, "Insurance Card");
			webActions.waitAndClick(btn_ClickHereToUploadFile, "Click Here To Upload File");
			Thread.sleep(5000);
			uploadFile(fileName);
			webActions.waitAndClick(btn_Confirm, "Confirm");
			webActions.waitForVisibility(lbl_SuccessMessage, "Success Message");
			String actSuccessMessage=webActions.waitAndGetText(lbl_SuccessMessage, "Success Message");
			if(expSuccessMessage.contentEquals(actSuccessMessage)){
				report.reportPass("Successfully verified the message after upload the Insurance Card: "+actSuccessMessage);
			}else{
				unmatch.append("Fail to verify the message after upload the Insurance Card: "+actSuccessMessage);
				report.reportFail("Fail to verify the message after upload the Insurance Card: "+actSuccessMessage,true);
			}
			webActions.waitAndClick(btn_OK, "OK");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			Thread.sleep(5000);
			webActions.waitForVisibility(img_InsuranceCard, "Insurance Card Status");
			String actStatus=webActions.getAttributeValue(img_InsuranceCard, "src", "Insurance Card Status");
			if(actStatus.contains(expStatus)){
				report.reportPass("Successfully verified the status after upload the Insurance Card");
			}else{
				unmatch.append("Fail to verify the status after upload the Insurance Card");
				report.reportFail("Fail to verify the status after upload the Insurance Card",true);
			}

			if(unmatch.length()==0){
				report.reportPass("Successfully upload the Insurance Card");
			}else{
				throw new Exception("Fail to upload the Insurance Card: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyDocumentsCount(){
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String actCount=webActions.waitAndGetText(lbl_UploadDocumentsCount, "UploadDocumentsCount");
			if("3/3".contentEquals(actCount)){
				report.reportPass("Successfully verified the Uploaded documents count: "+actCount);
			}else{
				unmatch.append("Fail to verify the Uploaded documents count: "+actCount);
				report.reportFail("Fail to verify the Uploaded documents count: "+actCount,true);
			}

			String actCompleteDocumentsCount=webActions.waitAndGetText(lbl_CompleteDocumentsCount, "Complete Documents Count");

			if(actCompleteDocumentsCount.contains("3")){
				report.reportPass("Successfully verified the Uploaded documents count in Complete Documents section: "+actCompleteDocumentsCount);
			}else{
				unmatch.append("Fail to verify the Uploaded documents count in Complete Documents section: "+actCompleteDocumentsCount);
				report.reportFail("Fail to verify the Uploaded documents count in Complete Documents section: "+actCompleteDocumentsCount,true);
			}

			webActions.click(lbl_CompleteDocumentsCount, "Complete Documents Count");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String actDocumentsCountinHome=webActions.waitAndGetText(lbl_CompleteDocumentsCount_Home, "Complete Documents Count_Home");
			report.reportInfo("Actual documents count in Complete Documents section in Home:"+actDocumentsCountinHome);
			if(actDocumentsCountinHome.contains("3")){
				report.reportPass("Successfully verified the Uploaded documents count in Complete Documents section in Home page: "+actCompleteDocumentsCount);
			}else{
				unmatch.append("Fail to verify the Uploaded documents count in Complete Documents section in Home page: "+actCompleteDocumentsCount);
				report.reportFail("Fail to verify the Uploaded documents count in Complete Documents section in Home page: "+actCompleteDocumentsCount,true);
			}
			if(unmatch.length()==0){
				report.reportPass("Successfully verified the Uploaded documents count in all sections");
			}else{
				throw new Exception("Fail to verify the Uploaded documents count in all sections: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String replaceAll(String input){
		return input.replaceAll("[\\[\\]\"]", "");
	}

	public  String getYear(String date){
		String[] parts = date.split("T");
		date=parts[0];
		String[] date1 = date.split("-");
		return date1[0];
	}
	public  String getMonth(String date){
		String[] parts = date.split("T");
		date=parts[0];
		String[] date1 = date.split("-");
		return getMonthName(date1[1]);
	}

	public String getMonthName(String month){
		String monthName="";
		if("01".contentEquals(month)){
			monthName="January";
		}else if("02".contentEquals(month)){
			monthName="February";
		}
		else if("03".contentEquals(month)){
			monthName="March";
		}
		else if("04".contentEquals(month)){
			monthName="April";
		}
		else if("05".contentEquals(month)){
			monthName="May";
		}
		else if("06".contentEquals(month)){
			monthName="June";
		}
		else if("07".contentEquals(month)){
			monthName="July";
		}
		else if("08".contentEquals(month)){
			monthName="August";
		}
		else if("09".contentEquals(month)){
			monthName="September";
		}
		else if("10".contentEquals(month)){
			monthName="October";
		}
		else if("11".contentEquals(month)){
			monthName="November";
		}
		else if("12".contentEquals(month)){
			monthName="December";
		}
		return monthName;
	}
	public  String getDay(String date){
		String[] parts = date.split("T");
		date=parts[0];
		String[] date1 = date.split("-");
		return date1[2];
	}


	public void setClipboardData(String fileName) {
		try {
			fileName=System.getProperty("user.dir")+"\\UploadDocuments\\"+fileName;
			StringSelection fileSelection = new StringSelection(fileName);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(fileSelection, fileSelection);
		} catch (HeadlessException e) {
			e.printStackTrace();
		}
	}

	public void uploadFile(String fileName) {
		try {
			setClipboardData(fileName);
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			Thread.sleep(3000);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			Thread.sleep(3000);
			robot.keyRelease(KeyEvent.VK_ENTER);
		} catch (Exception exp) {
			exp.printStackTrace();
		}
	}

	public void unsuccessfulVIMLogin(String expMessage) {
		try {
			enterInvalidCredentials();
			webActions.waitAndClick(btn_TryAgain, "TryAgain");
			enterInvalidCredentials();
			webActions.waitAndClick(btn_TryAgain, "First Name");
			enterInvalidCredentials();
			String actMessage=webActions.waitAndGetText(lbl_ValidationMessage, "ValidationMessage");
			if(expMessage.contentEquals(actMessage)){
				report.reportPass("Successfully verifed the Multiple validation attempts were unsuccessful");
			}
			else{
				report.reportFail("Failed to verify the Multiple validation attempts were unsuccessful");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void enterInvalidCredentials(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitAndClick(txt_FirstName, "First Name");
			webActions.sendKeys(txt_FirstName, "Testing", "First Name");
			webActions.sendKeys(txt_LastName, "Testing", "Last Name");
			webActions.click(btn_OpenCalendar, "Calendar");
			driver.findElement(By.xpath(year1+"2002"+year2)).click();
			driver.findElement(By.xpath(month1+"January"+month2)).click();
			driver.findElement(By.xpath(day1+"11"+day2)).click();
			webActions.click(btn_Confirm, "Confirm");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
		}
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_FirstName);
	}

}
