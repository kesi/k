package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.FindBy;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;


public class FAQProgramsPage extends BasePage {	

	EstimatorNonSelfPage enonSelf=new EstimatorNonSelfPage();
	IdentityVerifierPage identity=new IdentityVerifierPage();
	Login logIn=new Login();

	@FindBy(xpath="//a[contains(text(),'Financial Assistance Qualifier')]")
	private WebElement lnk_FAQ;

	@FindBy(xpath="//a[(text()='Create New Case')]")
	private WebElement btn_CreateNewCase;

	@FindBy(xpath="(//ipas-faq-tabs-container//div/img)[3]")
	private WebElement img_Programs;
	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;

	@FindBy(xpath="//a[@hideauthorize='AddEditFAQProg']")
	private WebElement lnk_AddPrograms;

	@FindBy(xpath="(//ipas-button/a)[3]")
	private WebElement btn_ProgramsCancel;

	@FindBy(xpath="(//ipas-button/a)[4]")
	private WebElement btn_ProgramsSave;

	@FindBy(xpath="//img[@src='assets/images/up-arrow.png']")
	private WebElement img_ProgramsFormsDocsArrow;

	@FindBy(xpath="//h6[contains(text(),'Forms')]")
	private WebElement lbl_FormsTitle;

	@FindBy(xpath="//h6[contains(text(),'Documents')]")
	private WebElement lbl_DocsTitle;

	@FindBy(xpath="//p[contains(text(),'FAQ Program Form')]")
	private WebElement lnk_Form1;

	@FindBy(xpath="//p[contains(text(),'Program ID Card')]")
	private WebElement lnk_Form2;

	@FindBy(xpath="//p[contains(text(),'Tax Documentation')]")
	private WebElement lnk_Doc1;

	@FindBy(xpath="//p[contains(text(),'Proof of Income')]")
	private WebElement lnk_Doc2;


	@FindBy(xpath="(//ejs-datepicker/span/input)[1]")
	private WebElement txt_ProgramsStartDate;

	@FindBy(xpath="//ejs-dropdownlist[@formcontrolname='programStatusId']/span//input")
	private List<WebElement> txt_ProgramsStatus;

	@FindBy(xpath="//ipas-faq-manage-programs//financial-clearance-status/img")
	private List<WebElement> txt_FormsDocsFinancialStatus;

	@FindBy(xpath="(//tbody/tr/td[@class='e-rowcell'])")
	private List<WebElement> lbl_ProgramsFromWindow;	

	@FindBy(xpath="//input[@placeholder='Type Program Name']")
	private WebElement txt_ProgramsSearchBox;

	@FindBy(xpath="(//tr/td[2])[2]")
	private WebElement lbl_ProgramsSearchResults;

	@FindBy(xpath="//img[@src='assets/images/delete_new.png']")
	private WebElement btn_ProgramsDelete;

	@FindBy(xpath="(//ejs-dropdownlist[@id='ddlelement']//input)[2]")
	private WebElement ddl_ProgramStatus;

	@FindBy(xpath="//div[@hideauthorize='DeleteFAQProg']/img")
	private WebElement icon_ProgramsDelete;

	@FindBy(xpath="//ipas-faq-details//div/span[@class='tag']")
	private WebElement lbl_ProgramStatusDesc;

	@FindBy(xpath="//ejs-dropdownlist[@formcontrolname='programStatusId']/span/input")
	private WebElement ddl_ProgramStatusValue;

	@FindBy(xpath="//ipas-faq-details//financial-clearance-status/img")
	private WebElement img_ProgramModuleStatus;

	@FindBy(xpath="//ipas-app-faq-short-panel//financial-clearance-status/img")
	private WebElement img_ProgramShortModuleStatus;

	@FindBy(xpath="//p[contains(text(),'Auto Assigned Program 2')]")
	private WebElement lbl_Program1Desc;

	@FindBy(xpath="//p[contains(text(),'Auto Assigned Program 1')]")
	private WebElement lbl_Program2Desc;

	@FindBy(xpath="(//p[contains(text(),'Program Start Date')])[1]")
	private WebElement lbl_Program1StartDate;

	@FindBy(xpath="(//p[contains(text(),'Program Start Date')])[2]")
	private WebElement lbl_Program2StartDate;

	@FindBy(xpath="(//p[contains(text(),'Program End Date')])[1]")
	private WebElement lbl_Program1EndDate;

	@FindBy(xpath="(//p[contains(text(),'Program End Date')])[2]")
	private WebElement lbl_Program2EndDate;

	@FindBy(xpath="(//p[@class='black-text bold'])[2]")
	private WebElement lbl_Program2StartDateValue;

	@FindBy(xpath="(//p[@class='black-text bold'])[5]")
	private WebElement lbl_Program1StartDateValue;

	@FindBy(xpath="//span[contains(text(),'Approved')]")
	private WebElement lbl_Program2Status;

	@FindBy(xpath="//span[contains(text(),'Pending')]")
	private WebElement lbl_Program1Status;


	@FindBy(xpath="//div[@hideauthorize='DeleteFAQProg']/img")
	private List<WebElement> img_ProgramsDelete;

	@FindBy(xpath="(//ejs-dropdownlist/span/input)[3]")
	private WebElement dd_ProgramStatus;


	@FindBy(xpath="//ipas-faq-manage-programs/div/div[2]")
	private WebElement lnk_AddProgramsDisbaled;

	@FindBy(xpath = "//div[@id='detail-document-table']/div/ejs-listview/div/ul/li/div")
	private WebElement tbl_DDMPage ; 

	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[2]")
	private WebElement lbl_VisitSummaryData;	

	@FindBy(xpath = "//div[@class='breadcrum-container noprint']/span[3]/a")
	private WebElement lnk_FAQBreadCrumb;

	@FindBy(xpath = "//span[contains(text(),'Digital Documents Manager')]")
	private WebElement lbl_DDWindowName;

	@FindBy(xpath = "//div[@id='document-viewer-section']/span/h2")
	private WebElement lbl_DocumentViewerContent;

	@FindBy(xpath = "//span[contains(text(),'Tax Documentation')]")
	private WebElement lnk_FAQTaxDocument;

	@FindBy(xpath = "//span[contains(text(),'Proof of Income')]")
	private WebElement lnk_FAQProofDocument;

	@FindBy(xpath = "//span[contains(text(),'FAQ Program Form')]")
	private WebElement lnk_FAQProgramForm;

	@FindBy(xpath = "//span[contains(text(),'Program ID Card')]")
	private WebElement lnk_FAQIDcardForm;

	@FindBy(xpath="//button[text()='Change Status']")
	private WebElement btn_ChangeStatus;

	@FindBy(xpath="//div[@ id='document-viewer-section']/div[1]/span/img")
	private WebElement lbl_DocsAndFormsStatus;

	@FindBy(xpath="//div[@id='detail-document-table']/div[1]//div[@class='e-list-item-header']/span/img")
	private WebElement lbl_DocsAndFormsStatusInPage;

	@FindBy(xpath="//select[@id='status']")
	private WebElement dd_Status;

	@FindBy(xpath="//button[@class='btn btn-light btn-xs'][(text()='Change Status')]")
	private WebElement btn_ChangeStatus_Popup;

	@FindBy(xpath="//input[@formcontrolname='totalCharges']")
	private WebElement txt_TotalCharges;

	@FindBy(xpath="//div[@hideauthorize='DeleteFAQMmbVst']/img")
	private WebElement icon_DeleteMeber;

	@FindBy(xpath="//a[@hideauthorize='AddEditFAQMmbVst']")
	private WebElement lnk_AddVisit;

	@FindBy(xpath="//ipas-faq-manage-members-visit//form//div[6]/p")
	private WebElement txt_PatientResponsibilityValue;	

	@FindBy(xpath="//ipas-faq-manage-members-visit//form//div[7]/p")
	private WebElement txt_ProgramName;

	@FindBy(xpath="(//ipas-faq-members-visit-list//ipas-button/a)[1]")
	private WebElement btn_AddVisit_Apply;	

	@FindBy(xpath="(//ipas-faq-members-visit-list//ipas-button/a)[2]")
	private WebElement btn_AddVisit_Cancel;

	@FindBy(xpath="(//ipas-faq-members-visit-list//ipas-button/a)[3]")
	private WebElement btn_AddVisit;

	@FindBy(xpath="//input[@placeholder='Type Account Number, MRN or Patient']")
	private WebElement txt_AddVisitSearchBox;

	@FindBy(xpath="//td[contains(text(),'No records to display')]")
	private WebElement txt_AddVisitMsg;

	@FindBy(xpath="(//td[1])[2]/div/span[1]")
	private WebElement chk_AddVisitResults;	

	@FindBy(xpath="//p[contains(text(),'Only patient visits that do not exist on a case wi')]")
	private WebElement chk_AddVisitResultsMSG;

	@FindBy(xpath="(//ipas-faq-manage-members-visit//p)[18]")
	private WebElement txt_AddVisitPatientName;

	@FindBy(xpath="(//ipas-faq-manage-members-visit//p)[21]")
	private WebElement txt_AddVisitProgramName;	

	@FindBy(xpath="(//div[@hideauthorize='DeleteFAQMmbVst']/img)[2]")
	private WebElement icon_AddedVisitDeleteIcon;

	@FindBy(xpath="(//ipas-faq-tabs-container//div/img)[2]")
	private WebElement img_Screening;

	@FindBy(xpath="//select[@name='q140_guarantor']")
	private WebElement drp_Guarantor;

	@FindBy(xpath ="//button[@type='submit']")
	private WebElement btn_Submit;

	@FindBy(xpath="//p[contains(@class,'status-info')]")
	private WebElement lbl_RunInfo;

	@FindBy(xpath="//div[@class='case-info']//span")
	private WebElement lbl_Status;

	@FindBy(xpath="//ejs-dropdownlist[@id='ddlelement']/span/input")
	private WebElement ddl_Status;

	@FindBy(xpath="(//financial-clearance-status)[2]/img")
	private WebElement atr_FCStatusFullPage;

	@FindBy(xpath="//ipas-faq-details//h2[1]")
	private WebElement lbl_HeaderMessage;

	@FindBy(xpath="//ipas-app-faq-short-panel//financial-clearance-status/img")
	private WebElement atr_FCStatusShortPanel;

	@FindBy(xpath="(//div[@class='description'])[1]//p")
	private List<WebElement> lbl_ShortPanelData;

	@FindBy(xpath="//div[contains(text(),'Would you like to select a discount for this progr')]")
	private WebElement txt_DiscountPopUpMsg;

	@FindBy(xpath="//button[contains(text(),'No')]")
	private WebElement btn_DiscountPopUp_No;

	@FindBy(xpath="//button[contains(text(),'Yes')]")
	private WebElement btn_DiscountPopUp_Yes;

	@FindBy(xpath="//ejs-dropdownlist[@formcontrolname='discountTypeId']/span/input")
	private WebElement ddl_ProgramDiscount;

	@FindBy(xpath="//ejs-dropdownlist[@formcontrolname='programStatusId']/span")
	private List<WebElement> txt_ProgramsStatus_enabled;

	@FindBy(xpath="(//ejs-dropdownlist/span/input)[3]")
	private WebElement dd_ProgramStatus_enable;


	@FindBy(xpath="//a[contains(text(),'Payment Facilitator')]")
	private WebElement btn_PaymentFacilitator;

	public FAQProgramsPage() {
		PageFactory.initElements(driver, this);
	}

	public void goToProgramsTab(){
		try {
			createNewCase();
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(img_Programs, "ProgramsTab", 20);
			webActions.click(img_Programs, "ProgramsTab");
			enonSelf.waitForPageLoade(3);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void createNewCase (){
		webActions.click(lnk_FAQ, "FAQ");
		try {
			webActions.waitForVisibility(btn_CreateNewCase, "CreateNewCase", 20);
			webActions.waitForPageLoaded();
			webActions.click(btn_CreateNewCase, "CreateNewCase");			
			enonSelf.waitForPageLoade(2);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}		
	}

	public void addPrograms(String value){
		try {
			//webActions.waitForVisibility(img_Programs, "ProgramsTab");
			//webActions.click(img_Programs, "ProgramsTab");			
			enonSelf.waitForPageLoade(2);
			webActions.waitForVisibility(lnk_AddPrograms, "AddPrograms", 20);
			selectDropdown(lnk_AddPrograms,value,"Addprograms");
			webActions.click(btn_ProgramsSave, "Save");
			webActions.waitForPageLoaded();
			enonSelf.waitForPageLoade(5);
			report.reportInfo("Successfully added the programs");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyProgramsAfterAdd(String program){
		try {
			enonSelf.waitForPageLoade(3);
			webActions.waitAndClick(lnk_AddPrograms, "AddPrograms");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			enonSelf.waitForPageLoade(2);
			ArrayList<String> displayedPrgrams=webActions.getDatafromWebTable(lbl_ProgramsFromWindow);
			report.reportInfo("Displayed programs from window: "+ displayedPrgrams);
			report.reportInfo("Added program is : " +program );
			for (String str : displayedPrgrams) {
				if(str.contentEquals(program)){
					report.reportFail("Added program is displayed from window even after added");
					break;
				}			
			}
			report.reportPass("Added program is not display from programs window");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifySearchCriteriaResults(String value){
		try {
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_ProgramsSearchBox, value, "ProgramsSearchBox");
			enonSelf.waitForPageLoade(2);
			String results=webActions.getText(lbl_ProgramsSearchResults, "Searchresults");
			if(results.contentEquals(value)){
				report.reportPass("Successfully verify the search results");
			}
			else{
				report.reportFail("Fail to verify the search results");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickCancelAndVerify(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_ProgramsCancel, "CancelBtn");
			webActions.waitForPageLoaded();
			verifyProgramStartDateAndStatus();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void selectDropdown(WebElement element,String valuetoSelect,String elementName) throws Exception{
		try {
			if (!valuetoSelect.isEmpty()) {
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.click(element, elementName);
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				driver.findElement(By.xpath("//td[contains(text(),'" + valuetoSelect + "')]")).click();			
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
			}
		} catch (Exception e) {
			throw e;
		}
	}
	public void verifyFormsDocs(DataTable testData){
		try {
			ArrayList<String> actCptData=new ArrayList<String>(testData.asList());
			ArrayList<String> expCptData=new ArrayList<String>();
			webActions.waitForPageLoaded();
			webActions.click(img_ProgramsFormsDocsArrow, "FormsDocs");
			webActions.waitForVisibility(lbl_FormsTitle, "Forms");
			webActions.waitForVisibility(lbl_DocsTitle, "Docs");
			webActions.waitForPageLoaded();
			expCptData.add(webActions.getText(lnk_Form1, "Forms"));
			expCptData.add(webActions.getText(lnk_Form2, "Forms"));
			expCptData.add(webActions.getText(lnk_Doc1, "Forms"));
			expCptData.add(webActions.getText(lnk_Doc2, "Forms"));
			report.reportInfo("Actual forms and documents: "+actCptData);
			report.reportInfo("Expected forms and documents "+expCptData);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actCptData, expCptData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the froms and documenst after adding the program");
			}else{
				throw new Exception("Fail to verify the forms and docs and unmatched data is: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyProgramStartDateAndStatus(){
		try {
			String status="Pending 1";
			webActions.waitForPageLoaded();
			String actstartDate=webActions.getAttributeValue(txt_ProgramsStartDate, "value", "startDate");
			String expStartDate=webActions.getSystemCurrentDate();
			if(actstartDate.contentEquals(expStartDate)){
				report.reportPass("Successfully verify the program start date");
			}
			else{
				report.reportFail("Fail to verify the programs start date and displayed is : "+ actstartDate,true);
			}
			String actStatus=webActions.getAttributeValue(ddl_ProgramStatusValue,"value", "ProgramsStatus");
			if(status.contentEquals(actStatus)){
				report.reportPass("Successfully verify the program status");
			}
			else{
				report.reportFail("Fail to verify the programs status date and displayed is : "+ actStatus);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyProgramsStatus(String status){
		try {
			String fromsDocsStatus="";
			if(status.contentEquals("Pending")){
				fromsDocsStatus="assets/images/error_sm.png";
			}
			else if(status.contentEquals("Clear")){
				fromsDocsStatus="assets/images/success_sm.png";
			}
			ArrayList<String> actFinanceStatus=webActions.getListofAttributeValuesfromWebPage(txt_FormsDocsFinancialStatus, "src");			
			ArrayList<String> unmatch=webActions.isFullArrayMatchWithData(actFinanceStatus, fromsDocsStatus);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the forms and document financial status");
			}else{
				throw new Exception("Fail to verify the forms and document financial status and unmatched data is: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyProgramsAfterDelete(String program){
		try {
			webActions.click(btn_ProgramsDelete, "DeleteIcon");
			webActions.waitForPageLoaded();
			enonSelf.waitForPageLoade(3);
			webActions.waitAndClick(lnk_AddPrograms, "AddPrograms");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			enonSelf.waitForPageLoade(2);
			ArrayList<String> displayedPrgrams=webActions.getDatafromWebTable(lbl_ProgramsFromWindow);
			report.reportInfo("Displayed programs from window: "+ displayedPrgrams);
			report.reportInfo("Added program is : " +program );
			for (String str : displayedPrgrams) {
				if(str.contentEquals(program)){
					report.reportPass("Added program is displayed from window after deleting");
					break;
				}
				else{

				}
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void changeProgramsStatus(String status){
		try {
			webActions.waitForPageLoaded();
			webActions.sendKeys(ddl_ProgramDiscount, "10% Maternity", "Discount");
			enonSelf.waitForPageLoade(2);
			webActions.clickAction(ddl_ProgramStatusValue, "ProgramsStatus");
			enonSelf.waitForPageLoade(1);
			webActions.sendKeys(ddl_ProgramStatusValue, status, "ProgramsStatus");
			enonSelf.waitForPageLoade(2);
			webActions.waitForPageLoaded();			

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyProgramfields(){
		try {
			enonSelf.waitForPageLoade(5);
			ArrayList<String> programStatus=webActions.getListofAttributeValuesfromWebPage(txt_ProgramsStatus, "disabled");
			webActions.waitForPageLoaded();
			programStatus.add(webActions.getAttributeValue(dd_ProgramStatus, "disabled", "mode"));
			report.reportInfo("Program status mode:"+ programStatus);
			ArrayList<String> unmatch=webActions.isFullArrayMatchWithData(programStatus, "true");
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the program status");
			}else{
				report.reportFail("Fail to verify the program status and unmatched data is: "+unmatch,true);
			}
			ArrayList<String> programDeleteIcon=webActions.getListofAttributeValuesfromWebPage(img_ProgramsDelete, "src");
			report.reportInfo("Delete icon mode:"+ programDeleteIcon);
			ArrayList<String> unmatch1=webActions.isFullArrayMatchWithData(programDeleteIcon, "assets/images/delete_disabled_new.png");
			if(unmatch1.size()==0){
				report.reportPass("Successfully verified the program delete icon mode");
			}else{
				report.reportFail("Fail to verify the delete icon mode and unmatched data is: "+unmatch1,true);
			}
			String addProgramlink=webActions.getAttributeValue(lnk_AddProgramsDisbaled, "class", "AddProgramLink");
			report.reportInfo("Add Programs links mode:"+ addProgramlink);
			enonSelf.waitForPageLoade(3);
			if(addProgramlink.contains("element-disabled")){
				report.reportPass("Add programs link is disabled");
			}
			else{
				report.reportFail("Fail to verify the add programs link");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyProgramStatus(String status){
		try {
			String statusDescription="";
			webActions.waitForPageLoaded();
			String expStatus=webActions.getAttributeValue(ddl_ProgramStatus, "aria-label", "statusDropDown");
			String expStatusDesc=webActions.getText(lbl_ProgramStatusDesc, "ProgramsStatus");
			if(status.contentEquals("Complete")){
				statusDescription="Programs - Complete";
			}
			else if(status.contentEquals("")){

			}
			if(status.contentEquals(expStatus) && statusDescription.contentEquals(expStatusDesc)){
				report.reportPass("Successfully verified the programs status");
			}
			else{
				report.reportFail("Fail to verify the program status");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyFAQModuleStatus(String status){
		try {

			String expStatus="";
			String fullModuleStatus=webActions.getAttributeValue(img_ProgramModuleStatus, "src", "moduleStatus").trim();			
			if(status.contentEquals("Clear")){
				expStatus="https://prmcqa.ipas360.com/assets/images/success_sm.png";
			}
			else{

			}			
			identity.navigateToVisitMainPage();
			String shortModuleStatus=webActions.getAttributeValue(img_ProgramShortModuleStatus, "src", "moduleStatus").trim();	
			report.reportInfo("Full module status:"+fullModuleStatus);
			report.reportInfo("Short module status:"+shortModuleStatus);
			report.reportInfo("expected module status:"+expStatus);
			if((fullModuleStatus.contentEquals(expStatus)) && (shortModuleStatus.contentEquals(expStatus))){
				report.reportPass("Successfully verified the programs full and short panel status");
			}
			else{
				report.reportFail("Fail to verify the program full and short panel status");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyShortPanelPrograms(DataTable testData){
		try {
			ArrayList<String> exptProgramsInfo=new ArrayList<>(testData.asList());
			ArrayList<String> actProgramsInfo=new ArrayList<>();			
			webActions.waitForVisibility(lbl_Program2Desc, "programName");
			actProgramsInfo.add(webActions.getText(lbl_Program2Desc, "Name"));
			actProgramsInfo.add(webActions.getText(lbl_Program2StartDate, "StartDate"));
			actProgramsInfo.add(webActions.getText(lbl_Program2EndDate, "EndDate"));
			actProgramsInfo.add(webActions.getText(lbl_Program1Desc, "Name"));
			actProgramsInfo.add(webActions.getText(lbl_Program1StartDate, "StartDate"));
			actProgramsInfo.add(webActions.getText(lbl_Program1EndDate, "EndDate"));
			actProgramsInfo.add(webActions.getText(lbl_Program2Status, "Status"));
			actProgramsInfo.add(webActions.getText(lbl_Program1Status, "Status"));
			actProgramsInfo.add(webActions.getText(lbl_Program2StartDateValue, "StartDate"));
			actProgramsInfo.add(webActions.getText(lbl_Program1StartDateValue, "StartDate"));
			exptProgramsInfo.add(webActions.getCurrentSystemDate());
			exptProgramsInfo.add(webActions.getCurrentSystemDate());
			report.reportInfo("Actual short panel info: " + actProgramsInfo);
			report.reportInfo("Expected short panel info: " + exptProgramsInfo);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actProgramsInfo, exptProgramsInfo);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the programs infor from short panel");
			}else{
				throw new Exception("Fail to verify the program infor from short panel unmatched data is: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyDDNavigation(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(img_ProgramsFormsDocsArrow, "FormsDocs");
			webActions.waitForVisibility(lbl_FormsTitle, "Forms");
			webActions.waitForVisibility(lbl_DocsTitle, "Docs");
			webActions.waitForPageLoaded();
			for (int i = 7; i <=10; i++) {
				String xpath="(//ipas-faq-manage-programs//p)";
				webActions.waitForPageLoaded();
				if(i!=7){
					webActions.click(img_ProgramsFormsDocsArrow, "FormsDocs");
					webActions.waitForVisibility(lbl_FormsTitle, "Forms");
					webActions.waitForVisibility(lbl_DocsTitle, "Docs");
					webActions.waitForPageLoaded();
				}				
				webActions.waitAndClick(driver.findElement(By.xpath(xpath+"["+i+"]")), "formDocLInk");
				webActions.waitForVisibility(tbl_DDMPage, "DDMWindow");
				webActions.waitForVisibility(lbl_VisitSummaryData, "VisitSummary");
				enonSelf.waitForPageLoade(3);
				webActions.waitForPageLoaded();
				String actualContent = webActions.getText(lbl_DocumentViewerContent, "Default Content");
				if (actualContent.contentEquals("No Document/Form selected for display")){
					report.reportPass("Successfully navigated to the DD page from FAQ");
					report.reportInfo("Actual Message: "+actualContent);					
				}
				else{
					report.reportFail("Fail to navigate to the DD page from FAQ");
				}
				webActions.waitAndClick(lnk_FAQBreadCrumb, "FAQBreadCrumb");
				enonSelf.waitForPageLoade(3);
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void changeStatusOfFAQForms(DataTable testData){
		try {
			ArrayList<String> formsList=new ArrayList<>(testData.asList());
			for (int i =0; i <formsList.size(); i++) {								
				String xpath1="//span[contains(text(),'";
				String xpath2="')]";	
				String form=formsList.get(i);
				WebElement e=driver.findElement(By.xpath(xpath1+form+xpath2));					
				webActions.clickAction(e, "documents");
				webActions.waitForVisibility(btn_ChangeStatus, "ChangeStatus");
				webActions.waitAndClick(btn_ChangeStatus, "ChangeStatus");
				enonSelf.waitForPageLoade(5);
				webActions.selectByVisibleText(dd_Status, "Complete", "Status Dropdown");
				enonSelf.waitForPageLoade(5);
				webActions.waitAndClick(btn_ChangeStatus_Popup, "Change Status Popup");
				enonSelf.waitForPageLoade(10);
				String actDocsAndFormsStatusInPanel=webActions.getAttributeValue(lbl_DocsAndFormsStatusInPage, "src", "DocsAndForms");					
				String actDocsAndFormsStatus=webActions.getAttributeValue(lbl_DocsAndFormsStatus, "src", "DocsAndForms");
				if((actDocsAndFormsStatusInPanel.contains("success") )&& (actDocsAndFormsStatus.contains("success"))){
					report.reportPass("Documents and Forms status got cleared");
				}
				else{
					report.reportFail("Document and Forms status is not displayed in clear mode and actual displayed image is : " +actDocsAndFormsStatus );
				}

			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void backToProgramsTab(){
		try {	
			webActions.click(lnk_FAQ, "FAQ");
			webActions.waitForPageLoaded();
			enonSelf.waitForPageLoade(3);
			webActions.waitForVisibility(img_Programs, "ProgramsTab", 20);
			webActions.waitAndClick(img_Programs, "ProgramsTab");
			enonSelf.waitForPageLoade(3);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyMembersvisitsData(){
		try {
			ArrayList<String> expData=new ArrayList<>();
			ArrayList<String> accData=new ArrayList<>();
			String account = logIn.getVisitIdFromResponse("$..displayPatientAccountId");
			String mrn = logIn.getVisitIdFromResponse("$..displayPatientId");
			String firstName = logIn.getVisitIdFromResponse("$..patientFirstName");
			String lastName = logIn.getVisitIdFromResponse("$..patientLastName");
			String patientName=firstName+" "+lastName;
			String visitDate=webActions.getSystemCurrentDate();
			expData.add(account);
			expData.add(mrn);
			expData.add(patientName);
			expData.add(visitDate);				
			for (int i =10; i <=13; i++) {								
				String xpath1="(//ipas-faq-manage-members-visit//p)[";
				String xpath2="]";	
				WebElement e=driver.findElement(By.xpath(xpath1+i+xpath2));	
				accData.add(webActions.getText(e, "meberInfo").trim());
			}
			report.reportInfo("Data from response: " + expData);
			report.reportInfo("Data from iPAS FAQ: " + accData);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(accData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the member visit information from FAQ");
			}else{
				throw new Exception("Fail to verify the member visit infor and unmatched data is: "+unmatch);
			}
		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyDefaultAddVisitLink(){
		try {		
			ArrayList<String> actModes=new ArrayList<>();
			ArrayList<String> expModes=new ArrayList<>();
			expModes.add("true");
			expModes.add("assets/images/delete_disabled_new.png");
			expModes.add("addrowitem element-disabled");
			actModes.add(webActions.getAttributeValue(txt_TotalCharges, "disabled", "totalsCharges"));
			actModes.add(webActions.getAttributeValue(icon_DeleteMeber, "src", "deleteIcon"));
			actModes.add(webActions.getAttributeValue(lnk_AddVisit, "class", "AddVisit"));
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actModes, expModes);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the member visit fileds/link default modes from FAQ");
			}else{
				throw new Exception("Fail to verify the member visit fields/links default modes and unmatched data is: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyChargesAndProgram(String value, String program){
		try {
			ArrayList<String> actModes=new ArrayList<>();
			ArrayList<String> expModes=new ArrayList<>();
			webActions.sendKeys(txt_TotalCharges, value, "totalCharges");
			webActions.pressTab();
			webActions.waitForPageLoaded();
			enonSelf.waitForPageLoade(3);
			actModes.add(webActions.getText(txt_PatientResponsibilityValue, "ResponsibilityValue"));
			actModes.add(webActions.getText(txt_ProgramName, "ProgramName"));
			actModes.add(webActions.getAttributeValue(icon_DeleteMeber, "src", "deleteIcon"));
			String val="$"+value;
			expModes.add(val);
			expModes.add(program);
			expModes.add("assets/images/delete_disabled_new.png");
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actModes, expModes);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the reponsibility amount and program from FAQ");
			}else{
				throw new Exception("Fail to verify the reponsibility amount and program and unmatched data is: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void updateProgramsStatus(String status){
		try {
			webActions.waitForPageLoaded();
			webActions.sendKeys(ddl_ProgramDiscount, "10% Maternity", "Discount");
			enonSelf.waitForPageLoade(2);
			try{
				webActions.waitForPageLoaded();
				webActions.clickAction(ddl_ProgramStatusValue, "ProgramsStatus");
				enonSelf.waitForPageLoade(1);
				webActions.sendKeys(ddl_ProgramStatusValue, status, "ProgramsStatus");
				enonSelf.waitForPageLoade(5);
			}
			catch (Exception e){
				report.reportFail(e.getMessage());
			}
		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void addVisits(String value){
		try {				
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lnk_AddVisit, "AddVisit", 20);
			webActions.click(lnk_AddVisit, "AddVisit");
			webActions.waitForVisibility(txt_AddVisitMsg, "NorecordsMsg");
			webActions.waitForVisibility(btn_AddVisit_Cancel, "Cancel");
			webActions.clearValue(txt_AddVisitSearchBox, "searchBox");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_AddVisitSearchBox, value, "patienName");
			webActions.waitForPageLoaded();
			webActions.click(btn_AddVisit_Apply, "ApplyBtn");
			webActions.waitForVisibility(chk_AddVisitResultsMSG, "ResultsMsg");
			enonSelf.waitForPageLoade(5);
			webActions.click(chk_AddVisitResults, "Results");
			webActions.waitForPageLoaded();
			webActions.click(btn_AddVisit, "AddVisit");	
			webActions.waitForPageLoaded();
			enonSelf.waitForPageLoade(5);
			report.reportInfo("Successfully added the additional visit");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyAddedvisitInfo(DataTable testData){
		try {
			ArrayList<String> expVisit=new ArrayList<String>(testData.asList());
			ArrayList<String> actVisit=new ArrayList<String>();
			webActions.waitForPageLoaded();			
			actVisit.add(webActions.getText(txt_AddVisitPatientName, "PatientName"));
			actVisit.add(webActions.getText(txt_AddVisitProgramName, "ProgramName"));			
			report.reportInfo("Actual visit info: "+actVisit);
			report.reportInfo("Expected visit info "+expVisit);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actVisit, expVisit);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the patient and program name after adding the visit");
			}else{
				throw new Exception("Fail to verify the patient and program names and unmatched data is: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void deleteAddedVisitAndVerify(){
		try {
			webActions.waitAndClick(icon_AddedVisitDeleteIcon, "TrashIcon");
			enonSelf.waitForPageLoade(2);
			String trashMode=webActions.getAttributeValue(icon_DeleteMeber, "src", "deleteIcon");
			String expMode="assets/images/delete_disabled_new.png";
			if(trashMode.contentEquals(expMode)){
				report.reportPass("Successfully verify the trash icon mode for default visit");
			}else{
				report.reportFail("Fail to verify the trash icon mode: " + trashMode);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void goToScreeningTab(){
		try {
			createNewCase();
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(img_Screening, "ScreeningTab", 20);
			webActions.click(img_Screening, "ScreeningTab");
			enonSelf.waitForPageLoade(5);
			report.reportInfo("Successfully navigated to the screening tab");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void submitScreeningForm(){
		try {
			driver.switchTo().frame(0);
			webActions.waitForPageLoaded();
			webActions.clickAction(drp_Guarantor, "guarantorDropdown");
			webActions.selectByVisibleText(drp_Guarantor, "Yes", "guarantordrp");
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_Submit, "Submit");
			webActions.click(btn_Submit,  "Submit");
			webActions.waitForPageLoaded();
			enonSelf.waitForPageLoade(10);			
			webActions.waitForVisibility(btn_Submit, "Submit");
			driver.switchTo().parentFrame();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void SwitchToProgramTab(){
		try {		
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(img_Programs, "ProgramsTab", 20);
			webActions.click(img_Programs, "ProgramsTab");
			enonSelf.waitForPageLoade(3);
			report.reportInfo("Successfully navigated to the programs tab");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public  String getFinancialClearanceStatus(DataTable testData){
		String expFCStatusPF=webActions.getDatafromMap(testData, "Financial Clearance Status");
		if(expFCStatusPF.contentEquals("Needs Attention")){
			expFCStatusPF="error";
		}else if(expFCStatusPF.contentEquals("Clear")){
			expFCStatusPF="success";
		}
		return expFCStatusPF;
	}

	public String getAlertMessage(){
		String actContent="";
		try {
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Alert Message");
			String[] titleContent=msg.split("\\n");
			actContent=titleContent[1];
		} catch (Exception e) {
		}
		return actContent;
	}

	public void changeStatusVerifyData(DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			String status=webActions.getDatafromMap(testData, "Status");
			String date=webActions.getSystemCurrentDate();
			String tab=webActions.getDatafromMap(testData, "Tab Name");
			String operator=webActions.getDatafromMap(testData, "Operator");
			ArrayList<String> expData = new ArrayList<String>();
			expData.add(tab);
			expData.add(status);
			expData.add(date);
			expData.add(operator);

			if (!status.contentEquals("Not Started")) {	
				enonSelf.waitForPageLoade(5);
				//webActions.waitForClickAbilityAndClick(ddl_Status, "Status");				
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.sendKeys(ddl_Status, status, "Status");
				String actAlertMessage = getAlertMessage();
				if ("Data saved successfully.".contains(actAlertMessage)) {
					report.reportPass(
							"Successfully verified the alert message after change the status: " + actAlertMessage);
				} else {
					report.reportFail("Fail to verify the alert message after change the status: " + actAlertMessage,
							true);
					unmatch.append("Fail to verify the alert message after change the status");
				} 
			}
			String actRunInfo=webActions.waitAndGetText(lbl_RunInfo, "Ran Info");

			if(actRunInfo.contains(operator+" "+date)){
				report.reportPass("Successfully verified the last ran information: "+actRunInfo);	
			}else{
				report.reportFail("Fail to verify the last ran information: "+actRunInfo,true);
				unmatch.append("Fail to verify the last ran information");
			}

			String actStatus=webActions.waitAndGetText(lbl_Status, "Status");
			if(actStatus.contains("Programs - "+status)){
				report.reportPass("Successfully verified the Status in Full Page: "+actStatus);
			}else{
				report.reportFail("Fail to verify the Status in Full Page: "+actStatus,true);
				unmatch.append("Fail to verify the Status in Full Page");
			}

			String actFCStatusFullPage=webActions.getAttributeValue(atr_FCStatusFullPage, "src", "FCStatusFullPage");
			String expFCStatus=getFinancialClearanceStatus(testData);
			if(actFCStatusFullPage.contains(expFCStatus)){
				report.reportPass("Successfully verified the Financial Clearance Status in Full Page: "+actFCStatusFullPage);
			}else{
				report.reportFail("Fail to verify the Financial Clearance Status in Full Page: "+actFCStatusFullPage);
				unmatch.append("Fail to verify the Financial Clearance Status in Full Page");
			}


			if((status.contentEquals("Complete"))||(status.contentEquals("Does not Qualify"))){
				ArrayList<String> programStatus=webActions.getListofAttributeValuesfromWebPage(txt_ProgramsStatus, "disabled");
				webActions.waitForPageLoaded();
				programStatus.add(webActions.getAttributeValue(dd_ProgramStatus, "disabled", "mode"));
				report.reportInfo("Program status mode:"+ programStatus);
				ArrayList<String> unmatchh=webActions.isFullArrayMatchWithData(programStatus, "true");
				if(unmatchh.size()==0){
					report.reportPass("Successfully verified the program status");
				}else{
					report.reportFail("Fail to verify the program status and unmatched data is: "+unmatchh,true);
				}
				ArrayList<String> programDeleteIcon=webActions.getListofAttributeValuesfromWebPage(img_ProgramsDelete, "src");
				report.reportInfo("Delete icon mode:"+ programDeleteIcon);
				ArrayList<String> unmatch1=webActions.isFullArrayMatchWithData(programDeleteIcon, "assets/images/delete_disabled_new.png");
				if(unmatch1.size()==0){
					report.reportPass("Successfully verified the program delete icon mode");
				}else{
					report.reportFail("Fail to verify the delete icon mode and unmatched data is: "+unmatch1,true);
				}
				String addProgramlink=webActions.getAttributeValue(lnk_AddProgramsDisbaled, "class", "AddProgramLink");
				report.reportInfo("Add Programs links mode:"+ addProgramlink);
				enonSelf.waitForPageLoade(3);
				if(addProgramlink.contains("element-disabled")){
					report.reportPass("Add programs link is disabled");
				}
				else{
					report.reportFail("Fail to verify the add programs link");
				}

			}

			enonSelf.goToVisitMainPageFromEstimatorFullPage();
			String actFCStatusShortPanel=webActions.getAttributeValue(atr_FCStatusShortPanel, "src", "FCStatusShortPanel");
			if(actFCStatusShortPanel.contains(expFCStatus)){
				report.reportPass("Successfully verified the Financial Clearance Status in Short panel: "+actFCStatusFullPage);
			}else{
				report.reportFail("Fail to verify the Financial Clearance Status in Short panel: "+actFCStatusFullPage);
				unmatch.append("Fail to verify the Financial Clearance Status in Short panel");
			}

			ArrayList<String> actData=webActions.getDatafromWebTable(lbl_ShortPanelData);
			report.reportInfo("Actual case data in short panel: "+actData);
			report.reportInfo("Expected case data in short panel: "+expData);
			ArrayList<String>unMatchData=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unMatchData.size()==0){
				report.reportPass("Successfully verified the case data in short panel: "+actData);
			}else{
				report.reportFail("Fail to verify the case data in short panel: "+unMatchData);
				unmatch.append("Fail to verify the case data in short panel");
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}
	public void updateProgramsStatusAndVerifyDiscountPopup(String status){				
		try{
			webActions.waitForPageLoaded();
			webActions.clickAction(ddl_ProgramStatusValue, "ProgramsStatus");
			webActions.waitForPageLoaded();
			enonSelf.waitForPageLoade(1);
			webActions.sendKeys(ddl_ProgramStatusValue, status, "ProgramsStatus");
			webActions.waitForPageLoaded();
			enonSelf.waitForPageLoade(3);
			webActions.waitForVisibility(txt_DiscountPopUpMsg, "PopUpMsg");
			String msg=webActions.getText(txt_DiscountPopUpMsg, "PopUpMsg");
			if(msg.contentEquals("Would you like to select a discount for this program prior to approving the program?")){
				report.reportPass("Discount popup is displayed successfully");
			}
			else{
				report.reportFail("Fail to verify the discount popup");
			}
		}
		catch (Exception e){
			report.reportFail(e.getMessage());
		}
	}
	public void verifyProgramFieldsBasedOnDiscountPopUpOption(String option){
		try {
			if("Yes".contentEquals(option)){
				webActions.click(btn_DiscountPopUp_Yes, "yes");
				webActions.waitForPageLoaded();	
				verifyProgramTabfields();
			}
			else if ("No".contentEquals(option)){
				webActions.click(btn_DiscountPopUp_No, "No");
				webActions.waitForPageLoaded();
				verifyProgramfields();
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyProgramTabfields(){
		try {
			enonSelf.waitForPageLoade(5);
			ArrayList<String> programStatus=webActions.getListofAttributeValuesfromWebPage(txt_ProgramsStatus_enabled, "aria-disabled");
			webActions.waitForPageLoaded();
			programStatus.add(webActions.getAttributeValue(dd_ProgramStatus_enable, "aria-disabled", "mode"));
			report.reportInfo("Program status mode:"+ programStatus);
			ArrayList<String> unmatch=webActions.isFullArrayMatchWithData(programStatus, "false");
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the program status");
			}else{
				report.reportFail("Fail to verify the program status and unmatched data is: "+unmatch,true);
			}
			ArrayList<String> programDeleteIcon=webActions.getListofAttributeValuesfromWebPage(img_ProgramsDelete, "src");
			report.reportInfo("Delete icon mode:"+ programDeleteIcon);
			ArrayList<String> unmatch1=webActions.isFullArrayMatchWithData(programDeleteIcon, "assets/images/delete_new.png");
			if(unmatch1.size()==0){
				report.reportPass("Successfully verified the program delete icon mode");
			}else{
				report.reportFail("Fail to verify the delete icon mode and unmatched data is: "+unmatch1,true);
			}
			String addProgramlink=webActions.getAttributeValue(lnk_AddProgramsDisbaled, "class", "AddProgramLink");
			report.reportInfo("Add Programs links mode:"+ addProgramlink);
			enonSelf.waitForPageLoade(3);
			if(addProgramlink.contains("element-enabled")){
				report.reportPass("Successfully verified the Add Program link");
			}
			else{
				report.reportFail("Fail to verify the add programs link");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyPaymentButton(){
		try {
			webActions.waitForPageLoaded();
			boolean falg=webActions.isDisplayed(btn_PaymentFacilitator, "payment");
			if(falg){
				report.reportPass("Verified successfully payment button");
			}
			else{
				report.reportFail("Fail to verify payment button");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
