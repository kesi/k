package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.BasePage;
import com.ipas.hf.web.steps.PatientVisitCardSteps;

import io.cucumber.datatable.DataTable;

public class PatientVisitPage extends BasePage{

	public PatientVisitPage() {
		PageFactory.initElements(driver, this);
	}

	public String visitIdvalue;
	public String patientVisitID;
	public String patientAppointmentID;
	public String patientName;

	@FindBy(xpath = "//div[@class='content-wrapper']")
	private WebElement grid_serviceTrackerBoard;

	@FindBy(xpath="//div[@class='Servicetrackerfilters']")
	private WebElement grid_filters;

	@FindBy(xpath ="//a[text()='Service Tracker']")
	private WebElement tab_serviceTracker;

	@FindBy(xpath = "//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_Search;

	@FindBy(xpath = "(//label[text()='Facility']//following::ejs-dropdownlist[@id='ddlelement'])[1]")
	private WebElement drp_Facility;

	@FindBy(xpath = "(//label[text()='Lobby']//following::ejs-dropdownlist[@id='ddlelement'])[1]")
	private WebElement drp_Lobby;

	@FindBy(xpath = "(//label[text()='Service Department']//following::ejs-dropdownlist[@id='ddlelement'])[1]")
	private WebElement drp_ServDpt;

	@FindBy(xpath = "(//label[text()='Visit Date']//following::ejs-dropdownlist[@id='ddlelement'])[1]")
	private WebElement drp_VisitDate;

	@FindBy(xpath = "//button[contains(text(),'Columns')]")
	private WebElement btn_Columns;

	@FindBy(xpath = "//button[@class='btn btn-primary btn-md']")
	private WebElement btn_Apply;

	@FindBy(xpath = "//button[@class='btn btn-light w-md']")
	private WebElement btn_Tools;

	@FindBy(xpath = "//div[contains(@id,'e-dropdown-btn_')]//ul")
	private WebElement lst_ColumnBox;

	@FindBy(xpath = "//div[@class='e-header-text']")
	private WebElement txt_header;

	@FindBy(xpath = "//table[@class='e-kanban-table e-content-table']//td")
	private WebElement lst_visitCardCount;
	
	@FindBy(xpath = "//div[@class='e-header-text']")
	private WebElement lst_headerCardCount;
	

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		//
		return null;
	}

	public void serviceTrackerPageValidation() throws Exception
	{
		webActions.click(tab_serviceTracker,"tab_serviceTracker");
		webActions.waitForVisibility(grid_filters,"Filters of Service Page");
		report.reportPass("Should load Service Tracker Board with Filters");
		webActions.waitUntilisDisplayed(grid_filters,"Filters of Service Page");
		webActions.waitUntilisDisplayed(grid_serviceTrackerBoard, "Service Tracker Board");
		webActions.isDisplayed(grid_serviceTrackerBoard, "Service Tracker Board");
		report.reportPass("Should display Service Tracker Board with Default Status Headers");
	}

	public void verifyDefaultFilters(String pageTitle) {
		try {
			webActions.waitUntilisDisplayed(grid_serviceTrackerBoard,"Service Tracker Board");
			report.reportPass("Wait until Service Tracker Board is Loaded");
			webActions.assertDisplayed(txt_Search, "Search Field");
			report.reportInfo("Verified the 'Search Field'");
			webActions.assertDisplayed(drp_VisitDate, "Visit Date");
			report.reportInfo("Verified the 'Visit Date'");
			webActions.assertDisplayed(drp_Facility, "Facility");
			report.reportInfo("Verified the 'Facility' Dropdown");
			webActions.assertDisplayed(btn_Apply, "Apply Button");
			report.reportInfo("Verified the 'Apply' Button");
			webActions.assertDisplayed(btn_Columns, "Columns Dropdown Button");
			report.reportInfo("Verified the 'Columns Dropdown Button'");
			String actPageTitle=webActions.getPageTitle();
			if(pageTitle.contentEquals(actPageTitle)){
				report.reportPass("Verified all fields in default search successfully");	
			}else{
				throw new Exception("Fail to verify the default Fields and page title and actual displayed page title is: "+actPageTitle);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	//	 }
	//	        public void defaultColumnName(DataTable columnNames) {
	//			try{
	//				List<String> defaultColumns = new ArrayList<>();
	//				webActions.waitForVisibility(btn_Columns,"Columns Button",120);
	//				List<String> expColNames = columnNames.asList(String.class);
	//				report.reportInfo("Column Names to be displayed are : "+expColNames);
	//				webActions.click(btn_Columns,"Columns Dropdown");
	//				webActions.waitForVisibility(txt_header,"Columns Dropdown");
	//				List<WebElement> options = txt_header.findElements(By.tagName("div"));
	//				options = txt_header.findElements(By.tagName("div"));
	//				for(int i =0;i<options.size();i++){
	//					
	//					String test = options.get(i).getText();
	//					System.out.println("value of list :"+test);
	//					if(options.get(i).getText().equals(value)){
	//						String test = options.get(i).getText();
	//						System.out.println(test);
	//						String xpath1 = "(//span[text()='";
	//						String xpath2 = "']//preceding::span[1]//preceding::li[1])[last()]";
	//						String xpath3 = xpath1+value+xpath2;
	//						WebElement uncheckBox = driver.findElement(By.xpath(xpath3));
	//						if(uncheckBox.getAttribute("aria-selected").equals("true"))
	//						webActions.click(uncheckBox, value);
	//						break;
	//					}
	//					
	//					
	//			 catch (Exception e) {
	//					report.reportFail(e.getMessage());
	//				}		
	//		}
	public void verifyDefaultColumns() {
		try {
			webActions.waitUntilisDisplayed(grid_serviceTrackerBoard,"Service Tracker Board");
			report.reportPass("Wait until Service Tracker Board is Loaded");
			webActions.assertDisplayed(txt_Search, "Search Field");
			report.reportInfo("Verified the 'Search Field'");
			webActions.assertDisplayed(drp_VisitDate, "Visit Date");
			report.reportInfo("Verified the 'Visit Date'");
			webActions.assertDisplayed(drp_Facility, "Facility");
			report.reportInfo("Verified the 'Facility' Dropdown");
			webActions.assertDisplayed(btn_Apply, "Apply Button");
			report.reportInfo("Verified the 'Apply' Button");
			webActions.assertDisplayed(btn_Columns, "Columns Dropdown Button");
			report.reportInfo("Verified the 'Columns Dropdown Button'");

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	public void defaultColumnName1(DataTable columnNames) {
		try{
			List<String> defaultColumns = new ArrayList<>();
			List<String> headerColumns =new ArrayList<>();
			List<String> expColNames = columnNames.asList(String.class);
			webActions.waitForVisibility(txt_header,"Columns Dropdown");
			List<WebElement> headerOpt = txt_header.findElements(By.tagName("div"));
			headerOpt = txt_header.findElements(By.tagName("div"));
			for(int i =0;i<headerOpt.size();i++){
				headerColumns.add(headerOpt.get(i).getText());
			}
			webActions.waitForVisibility(btn_Columns,"Columns Dropdown");
			webActions.click(btn_Columns,"Columns Dropdown");
			webActions.waitForVisibility(lst_ColumnBox,"Columns Dropdown");
			List<WebElement> options = lst_ColumnBox.findElements(By.tagName("li"));
			for(int x = 0;x<expColNames.size();x++){        
				String value =expColNames.get(x);
				for(int i =0;i<options.size();i++){
					if(options.get(i).getText().equalsIgnoreCase(value)){
						String xpath1 = "//span[text()='";
						String xpath2 = "']//preceding::div[1]";
						String xpath3 = xpath1+value+xpath2;
						List<WebElement> checkBox = driver.findElements(By.xpath(xpath3));
						String valueChecked=checkBox.get(0).getAttribute("aria-checked");
						if(valueChecked.equals("true")){
							defaultColumns.add(options.get(i).getText());
							report.reportPass("Verified the default selected fields from column list successfully: "+value);                            
						}
						else{
							String valueChecked1=checkBox.get(1).getAttribute("aria-checked");
							if(valueChecked1.equals("true")){ 
								defaultColumns.add(checkBox.get(0).getText());
								report.reportPass("Verified the default selected fields from column list successfully: "+value);
							}
						}
					}
				}
			}

			try {
				if(headerColumns.equals(headerColumns))
				{
					report.reportPass("verified the Header Columns on the Board with the Default Columns "+defaultColumns);
				}

			} catch (Exception e) {

				report.reportFail("Failed: To verify the Header columns on the Board with the Default Columns "+e.getMessage());
			}
		}
		catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifystatusCardCount(DataTable statusNames) {
		try {
			
			int statusCardCount=0;
			List<WebElement> visitCardColumns = lst_visitCardCount.findElements(By.tagName("div"));
			List<WebElement> headerCardColumns = lst_headerCardCount.findElements(By.tagName("div"));

			for(int i =0;i<headerCardColumns.size();i++){
				System.out.println("Header Card Columns are :"+headerCardColumns);
				String []countArray=headerCardColumns.get(i).getText().split(" ");
				String count       =countArray[1];
				System.out.println("Count Item for Column "+i+ "is "+count);
			}


		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}
	
	public void verifystatuscount(DataTable statusNames )
	{

		List<String> defaultColumns = new ArrayList<>();
		List<String> headerColumns =new ArrayList<>();
		List<String> statusCount =new ArrayList<>();

		List<String> expColNames = statusNames.asList(String.class);
		webActions.waitForVisibility(txt_header,"Columns Dropdown");
		List<WebElement> headerOpt = txt_header.findElements(By.tagName("div"));
		headerOpt = txt_header.findElements(By.tagName("div"));
		for(int i =0;i<headerOpt.size();i++){
			headerColumns.add(headerOpt.get(i).getText());
			String xpath="//div[@class='e-header-text']//following::div[1]";
			
		}
		webActions.waitForVisibility(lst_ColumnBox,"Columns Dropdown");
		List<WebElement> options = lst_ColumnBox.findElements(By.tagName("li"));
		for(int x = 0;x<expColNames.size();x++){        
			String value =expColNames.get(x);
			for(int i =0;i<options.size();i++){
				if(options.get(i).getText().equalsIgnoreCase(value)){
					String xpath1 = "//span[text()='";
					String xpath2 = "']//preceding::div[1]";
					String xpath3 = xpath1+value+xpath2;
					List<WebElement> checkBox = driver.findElements(By.xpath(xpath3));
					String valueChecked=checkBox.get(0).getAttribute("aria-checked");
					if(valueChecked.equals("true")){
						defaultColumns.add(options.get(i).getText());
						report.reportPass("Verified the default selected fields from column list successfully: "+value);                            
					}
					else{
						String valueChecked1=checkBox.get(1).getAttribute("aria-checked");
						if(valueChecked1.equals("true")){ 
							defaultColumns.add(checkBox.get(0).getText());
							report.reportPass("Verified the default selected fields from column list successfully: "+value);
						}
					}
				}
			}
		}

		try {
			if(headerColumns.equals(headerColumns))
			{
				report.reportPass("verified the Header Columns on the Board with the Default Columns "+defaultColumns);
			}

		} catch (Exception e) {

			report.reportFail("Failed: To verify the Header columns on the Board with the Default Columns "+e.getMessage());
		}
	
	}
}
