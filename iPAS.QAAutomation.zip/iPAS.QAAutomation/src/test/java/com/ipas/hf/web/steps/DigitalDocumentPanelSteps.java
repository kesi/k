package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.DigitalDocumentPanelPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class DigitalDocumentPanelSteps {

	DigitalDocumentPanelPage ddpp=new DigitalDocumentPanelPage();

	@Then("Verify the display of section names under documents and forms")
	public void verify_the_display_of_section_names_under_documents_and_forms(DataTable sectionNames) {
		ddpp.verifyPanelSections(sectionNames);
	}
	@Then("Verify the display of default status for Documents and Forms")
	public void verify_the_display_of_default_status_for_Documents_and_Forms(DataTable testData) {
		ddpp.verifyDefaultStatusForDocsAndForms(testData);
	}

	@Then("Verify the display of labels under Documents and Forms")
	public void verify_the_display_of_labels_under_Documents_and_Forms(DataTable testData) {
		ddpp.verifyLabelsOfDocsAndForms(testData);
	}

	@Then("Verify the display of content as {string} at document viewer section")
	public void verify_the_display_of_content_as_at_document_viewer_section(String expContent) {
		ddpp.verifyDefaultDisplayContent(expContent);
	}

	@Then("Click on docuemnt section and verify the display of message as {string} in docuemnt viewer")
	public void click_on_docuemnt_section_and_verify_the_display_of_message_as_in_docuemnt_viewer(String expMsg) {
		ddpp.verifyDocumentViewerMsg(expMsg);
	}
	@Then("Click on documents and verify the buttons and their mode")
	public void click_on_documents_and_verify_the_buttons_and_their_mode(DataTable dataTable) {
		ddpp.verifyDocumentsButtons();
	}

	@Then("Click on Forms and verify the display of buttons and their default display mode")
	public void click_on_Forms_and_verify_the_display_of_buttons_and_their_default_display_mode() {
		ddpp.verifyFormsButtons();
	}

	@Then("Submit the Pre registration form and verify the status")
	public void submit_the_Pre_registration_form_and_verify_the_status() {
		ddpp.verifyPreRegistrationForm();
	}

	@Then("Verif display of fields and buttons")
	public void verif_display_of_fields_and_buttons() {
		ddpp.verifyChangeStatusButtons();
	}
	@Then("Verify the default selected value from status drop down on Change Status window")
	public void verify_the_default_selected_value_from_status_drop_down_on_Change_Status_window(DataTable testData) {
		ddpp.verifyDefaultSelectedValueinChangeStatus(testData);
	}

	@Then("Verify the closing of change status window")
	public void verify_the_closing_of_change_status_window() {
		ddpp.verifyChangeStatusWindowClose();
	}

	@Then("Submit the Condition of Admission form and verify the status")
	public void submit_the_Condition_of_Admission_form_and_verify_the_status() {
		ddpp.verifyAdmissionForm();
	}

	@Then("Submit the General Pain and Medical History form and verify the status")
	public void submit_the_General_Pain_and_Medical_History_form_and_verify_the_status() {
	   ddpp.verifyGeneralPainAndMedicalHistory();
	}

}
