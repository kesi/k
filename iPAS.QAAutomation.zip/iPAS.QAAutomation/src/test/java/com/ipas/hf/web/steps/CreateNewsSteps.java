package com.ipas.hf.web.steps;

import java.util.Properties;

import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.utilities.ConfigProperties;
import com.ipas.hf.web.pages.ipasPages.CreateNewsPage;
import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class CreateNewsSteps {
	CreateNewsPage createNewsPage = new CreateNewsPage();

	@Then("Click on News in Maintenace Tab and Verify AddNews button and Content Text")
	public void click_on_News_in_Maintenace_Tab_and_Verify_AddNews_button_and_Content_Text() throws Exception {
		createNewsPage.clickNewsToNavigateNewsList();
	}

	@Then("Verify Title is required when text is not entered in News Title")
	public void verify_Title_is_required_when_text_is_not_entered_in_News_Title() throws Exception {
		createNewsPage.verifyTitleisrequired();
	}

	@Then("Create News with valid Data")
	public void create_News_with_valid_Data(DataTable testData,String messageTitle,String messageContent) throws Exception {
		createNewsPage.createNews(testData,messageTitle,messageContent);
	}
	
	@Then("Verify mandatory msg for Facility as {string} when Facility is selected")
	public void verify_mandatory_msg_for_Facility_as_when_Facility_is_selected(String expText) throws Exception {
		createNewsPage.verifyFacilityRequiredMsg(expText);
	}

	@Then("Verify mandatory msg for Role as {string} when Role is selected")
	public void verify_mandatory_msg_for_Role_as_when_Role_is_selected(String expText) throws Exception {
		createNewsPage.verifyRoleRequiredMsg(expText);
	}
	
	@Then("Verify mandatory msg for Start Date as {string} when Date is not entered in Start Date")
	public void verify_mandatory_msg_for_Start_Date_as_when_Date_is_not_entered_in_Start_Date(String expText) throws Exception {
		createNewsPage.verifyStartDateMandatoryMsg(expText);
	}

	@Then("Create News with the following data and verify alert message as title {string} and content as {string}")
	public void create_News_with_the_following_data_and_verify_alert_message_as_title_and_content_as(String messageTitle,String messageContent,DataTable testData) throws Exception {
		createNewsPage.createNews(testData,messageTitle,messageContent);
	}

	@Then("verify the display of button in News Details Page")
	public void verify_the_display_of_button_in_News_Details_Page() throws Exception {
		createNewsPage.verifyCancelSaveBtns();
	}
	
	@Then("Verify the display of Search Text Box in News Config Page")
	public void verify_the_display_of_Search_Text_Box_in_News_Config_Page() throws Exception {
		createNewsPage.verifySearchTextBox();
	}
	
	@Then("Verify the list of grid Headers in News Config Page")
	public void verify_the_list_of_grid_Headers_in_News_Config_Page(DataTable testData) throws Exception {
		createNewsPage.verifyNewsListGridHeaders(testData);
	}
	
	@Then("Verify Results Text below Search Text Box")
	public void verify_Results_Text_below_Search_Text_Box() throws Exception {
		createNewsPage.verifyResultsText();
	}
	
	@Then("Search the newly Created News in News List as {string}")
	public void search_the_newly_Created_News_in_News_List_as(String searchValue) throws Exception {
		createNewsPage.searchCreatedNews(searchValue);
	}
	
	@Then("Verify News Descriptive Text as {string}")
	public void verify_News_Descriptive_Text_as(String expNewsPanelText) throws Exception {
		createNewsPage.verifyNewsDescriptiveText(expNewsPanelText);
	}
	
	@Then("Create News with all fields data and verify alert message as title {string} and content as {string}")
	public void create_News_with_all_fields_data_and_verify_alert_message_as_title_and_content_as(String messageTitle,String messageContent,DataTable testData) throws Exception {
		createNewsPage.createNewsWithAllFieldsData(testData,messageTitle,messageContent);		
	}
	
	@Then("Verify the Cancel button functionality in News Details Page")
	public void verify_the_Cancel_button_functionality_in_News_Details_Page() throws Exception {
		createNewsPage.verifyCancelButtonFunctionality();
	}

	@Then("Verify the count of News under News List")
	public void verify_the_count_of_News_under_News_List() throws Exception {
		createNewsPage.verifyNewsCountUnderNewsList();
	}
	
	@Then("Verify the Validation msg if user enter maximum length characters as {string}")
	public void verify_the_Validation_msg_if_user_enter_maximum_length_characters_as(String testData, DataTable validationMessages) throws Exception {
		createNewsPage.validationMessageForNewsTitle(testData,validationMessages);
	}
	
	@Then("Verify the Grid Values in News List Page")
	public void verify_the_Grid_Values_in_News_List_Page() throws Exception {
		createNewsPage.readGridDataFromNewsListPage();
	}
}



