package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

public class VPVServiceTrackerPanelPage extends BasePage {
	private RestActions rest = new RestActions();
	UpdateVisitPage updateVisit = new UpdateVisitPage();
	Login logIn = new Login();

	@FindBy(xpath = "//label[contains(text(),'Search')]//following::input[1]")
	private WebElement txt_SimpleSearch;

	@FindBy(xpath = "//input[@id='username']")
	private WebElement txt_UserName;

	@FindBy(xpath = "//input[@id='password']")
	private WebElement txt_Password;

	@FindBy(xpath = "//all-data/div/div/ipas-breadcrumb/div/span[1]/a")
	private WebElement lnk_brdcrmb_SrvceTracker;

	@FindBy(xpath = "//span[@class='breadcrum-active']")
	private WebElement lbl_brdcrmb_VisitID;

	@FindBy(xpath = "//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']")
	private List<WebElement> li_DefaultGridStatusNames1;

	@FindBy(xpath = "//a[contains(text(),'All Data')]")
	private WebElement lnk_AllData;

	@FindBy(xpath = "//ejs-dashboardlayout[1]/div[2]//app-ipas-service-tracker-panel[1]//div//span//a")
	private WebElement lnk_SrvTracker;

	@FindBy(xpath="//a[@class='breadcrum']")
	private WebElement lbl_Breadcrum_Service;

	@FindBy(xpath = "//all-data-panels[1]//app-ipas-service-tracker-panel[1]//div[1]/p[1]")
	private WebElement data_VisitMainPage;

	@FindBy(xpath = "//div[@class='e-toast-message']/div[1]")
	private WebElement msg_Success;

	@FindBy(xpath ="//label[1]/span[2]")
	private WebElement visitCard_WaitTime;

	@FindBy(xpath ="//p[contains(text(),'Waiting for')]")
	private WebElement srvT_WaitTime;

	@FindBy(xpath ="//div/div/div/p[2][@class='waiting-text errortext']")
	private WebElement srvT_WaitTimeColor;
	
	@FindBy(xpath ="//app-ipas-service-tracker-panel//div/div/div/div/span[1]")
	private WebElement srvTrckrPanel_StatusName;
	
	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@formcontrolname='serviceTrackerStatusId']/span/span")
	private WebElement drpdwn_IntakeStatus;
	
	@FindBy(xpath="//form[@id='EditForm']//div[1]/div[@class='st modal-header']/button[@class='close']")
	private WebElement btn_MWindowClose;
	
	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@formcontrolname='serviceTrackerStatusId']/span//input")
	private WebElement drpvalue_IntakeStatus;
	
	public VPVServiceTrackerPanelPage() {
		PageFactory.initElements(driver, this);
	}

	public String getVisitIdFromResponse(String visitId){
		String displayVisitId = "";
		try {
			String visitIdValue = rest.getStringValueFromResponse(visitId);
			displayVisitId = visitIdValue.replaceAll("\\W", "");
			report.logPass("Validate Response Body Content Matches the Expected Value: " + visitId
					+ " Actual value: " + displayVisitId);
		} catch (AssertionError e) {
			report.logHardFail("Validate Response Body Content Matches the Request Failed ", e);
		}
		return displayVisitId;
	}

	public void simpleSearch(String value){
		try{
			webActions.waitUntilPresentAndDisplayed(txt_SimpleSearch, "Simple search");
			webActions.sendKeys(txt_SimpleSearch, value, "Visit id");
			webActions.keyBoardEnter(txt_SimpleSearch,"Simple search");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void clickVisitID(String value){
		try{
			Thread.sleep(5000);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			driver.findElement(By.linkText(value)).click();			
			report.reportPass("clicked on Link");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyPVMainPageAllData(){
		try{
			webActions.waitForVisibility(lnk_AllData, "All Data",30);
			report.reportPass("All Data Page is displayed Successfully");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyBreadCrumb(String visitID) {
		try{
			webActions.waitForVisibility(lnk_brdcrmb_SrvceTracker, "Service Tracker");
			String srvctext = webActions.getText(lnk_brdcrmb_SrvceTracker, "Service Tracker");
			report.reportPass("Bread crumb value is "+srvctext);
			webActions.waitForVisibility(lbl_brdcrmb_VisitID, "Visit ID");
			String text = webActions.getText(lbl_brdcrmb_VisitID, "Visit ID");
			report.reportInfo("bread crum value is "+text);
			if((srvctext.contentEquals("Service Tracker")) && (text.contentEquals(visitID))){
				report.reportPass("bread crum value are matched"+text+"  "+visitID);
			}else{
				throw new Exception("uanble to verify the bread crum value for VisitID");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void clikOnServiceTrackerBreadCrumb() throws Exception{
		try{
			webActions.waitForClickAbilityAndClick(lnk_brdcrmb_SrvceTracker, "Service Tracker");
			report.reportPass("Clicked on Service Tracker Link");
			webActions.waitUntilListisDisplayed(li_DefaultGridStatusNames1, "list in grid");
			report.reportPass("Page is navigated to Service Tracker Page and Grid columns are displayed");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyServiceTrackerOnSecondColumn(){
		try{
			String expPanelName = "Service Tracker";
			webActions.waitForVisibility(lnk_SrvTracker, "Service Tracker");
			report.reportInfo("Service Tracker Panel is displayed properly");
			String actPanelName= webActions.getText(lnk_SrvTracker, "Service Tracker");
			if(expPanelName.contentEquals(actPanelName)){
				report.reportPass("Service Tracker is displayed at the top of the Second Column in Patient Main Page");
			}else{
				throw new Exception("Failed to read Service Tracker Panel Name in Patient Visit Main Page");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDBeforeServiceDepartment(String pocCode) throws Exception{
		String actpocOnCard =null;
		try{
			String jsonPOCCode = logIn.getVisitIdFromResponse(pocCode);
			report.reportInfo("POC from json file is :"+jsonPOCCode);
			if(jsonPOCCode.contentEquals("MFM")){
				actpocOnCard="Maternal Fetal Medicine";
			}else if(jsonPOCCode.contentEquals("UCC")){
				actpocOnCard="Urgent Care Center";
			}
			webActions.waitForVisibility(data_VisitMainPage, "Data");
			report.reportInfo("Data is displayed on the Panel");
			String data = webActions.getText(data_VisitMainPage, "Data");
			String[] data1 = data.split(":");
			data=data1[0];
			String srvDept = data1[1];
			String[] stpSrvcDepartment = srvDept.split(",");
			String stpSD=stpSrvcDepartment[0];
			if(data.contentEquals("D") && actpocOnCard.contentEquals(stpSD)){
				report.reportPass("D is displayed before Service Department Name in Patient Visit Main Page");
			}else{
				throw new Exception ("Failed to read D before Service Department Name in Patient Visit Main Page");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public ArrayList<String> readDestRegistOnCard() throws Exception{

		ArrayList<String> data = new ArrayList<>();		
		List<WebElement> patientDetails = driver.findElements(By.xpath("//div/div/div/div[2]/span"));
		report.reportInfo("List of all Elements are :"+patientDetails.size());
		for(int expData =1;expData<=patientDetails.size();expData++){
			if(expData==4){
				String xpath1 = "//div/div/div/div[2]/span[";
				String xpath2 ="]";
				String xpath3 =xpath1+expData+xpath2;
				WebElement valuesss = driver.findElement(By.xpath(xpath3));
				String txt = webActions.getText(valuesss, "elements");
				String[] text =txt.split(":\\s");
				txt = text[1];
				data.add(txt);
			}			
			else if(expData==5||expData==6){
				String xpath1 = "//div/div/div/div[2]/span[";
				String xpath2 ="]";
				String xpath3 =xpath1+expData+xpath2;
				WebElement valuesss = driver.findElement(By.xpath(xpath3));
				String txt = webActions.getText(valuesss, "elements");
				String[] text =txt.split(",");
				txt =text[1].trim();		
				data.add(txt);
			}
		}
		return data;
	}

	public ArrayList<String> readDataInVisitMainPage() throws Exception{
		webActions.waitForVisibility(data_VisitMainPage, "Data");
		String data = webActions.getText(data_VisitMainPage, "Data");
		String[] data1 = data.split(":");
		data=data1[1];
		ArrayList<String> expectedListData=new ArrayList<String> (Arrays.asList(data.split("\\s*,\\s*")));
		report.reportPass("Data on Patient Visit Main page is  :"+expectedListData);		    	
		return  expectedListData;
	}

	public void compareDataonVisitCardAndPanel(ArrayList<String> actList, ArrayList<String> expList) {
		try{
			ArrayList<String> unmatched = webActions.getUmatchedInArrayComparision(actList,expList);
			if(unmatched.size()==0){
				report.reportPass("Service Department, Destination and Registrar values are dispayed successfully");
			}else{
				throw new Exception("Fail to verify Service Department, Destination and Registrar Names:"+unmatched);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifySuccessMessage(){
		try{
			webActions.waitForVisibility(msg_Success, "Success Msg");
			if(webActions.isDisplayed(msg_Success, "Success Msg")){
				report.reportPass("Success message is displayed sucessfully");
			}else{
				throw new Exception("Success message is not displayed");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void compareWaitTime(String visitID) throws Exception{
		boolean flag = false;
		try{
			flag=webActions.isDisplayed(visitCard_WaitTime, "Success Msg");
			if(flag==true){
				report.reportPass("Success message is displayed sucessfully");
				String actWaitTime = webActions.getText(visitCard_WaitTime, "Wait Time");
				String[] acttime1 =actWaitTime.split("M");
				actWaitTime = acttime1[0];
				int actWTime = Integer.parseInt(actWaitTime);
				clickVisitID(visitID);					
				String expWaitTime = webActions.getText(srvT_WaitTime, "Wait Time");
				String[] time1 = expWaitTime.split("for\\s*");
				expWaitTime = time1[1];
				String[] time2 = expWaitTime.split("M");
				expWaitTime = time2[0];
				int expWTime = Integer.parseInt(expWaitTime);
				String actTextColor = webActions.getAttributeValue(srvT_WaitTimeColor, "class", "WaitTimeColor");
				report.reportInfo("Wait Time color is attribute value is :"+actTextColor);
				if((expWTime==actWTime || expWTime<=actWTime+1)&&(actTextColor.contentEquals("waiting-text errortext"))){
					report.reportPass("Wait Time is displayed properly on Service Tracker Panel");
				}else{
					throw new Exception("Wait Time is not displayed properly on the Service Tracker Panel");
				}
			}
		}catch(Exception e){
			if(flag==false){
				report.reportPass("Wait Time is not displayed against the Intake Status");
			}
		}
	}

	public void compareStatusOnSTPanel() throws Exception{
		try{
			String visitID= updateVisit.getValuefromJSONresponseBasedOnObject();
			updateVisit.simpleSearch(visitID);
			updateVisit.openModelWindow(visitID);
			String actStatus = getIntakeStatusFromModelWindow();
			clickVisitID(visitID);
			String expStatus = getStatusOnSTPanel();
			if(actStatus.contentEquals(expStatus)){
				report.reportPass("Status is matched");
			}else{
				throw new Exception("Unable to Compare Status on Visit Card and Service Tracker Full Page");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	
	public String getStatusOnSTPanel() throws Exception{
		String stfpStatus = null;
		try{
			webActions.waitForVisibility(data_VisitMainPage, "ServiceTrakcerPanelData");
			report.reportInfo("Data is displayed on Service Tracker Panel");
			stfpStatus =webActions.getText(srvTrckrPanel_StatusName, "STFP Status");
			report.reportInfo("Status on Service Tracker Full Page is :"+stfpStatus);
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}return stfpStatus;
	}
	
	public String getIntakeStatusFromModelWindow() throws Exception {
		String prsntStatus= null;
		try{
			webActions.waitForVisibility(drpdwn_IntakeStatus, "Intake Status Drop Down");
			report.reportPass("Intake Status drop down is displayed");
			webActions.waitForPageLoaded();
			prsntStatus= webActions.getAttributeValue(drpvalue_IntakeStatus, "aria-label", "dropdown");
			webActions.waitForVisibility(btn_MWindowClose, "X Buton");
			report.reportPass("Close button is displayed on modal window");
			webActions.click(btn_MWindowClose, "X Buton");
			report.reportPass("Clicked on X button in Model Window");
			webActions.waitForPageLoaded();
		}catch(Exception e){
			report.reportFail(e.getMessage());
		} return prsntStatus;
	}
	
	
	public VPVServiceTrackerPanelPage openIpasApp() {
		try {
			String URL = TestBase.prop.ipasURL();
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to Open iPAS application");
		}
		return (VPVServiceTrackerPanelPage) base(VPVServiceTrackerPanelPage.class);
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_UserName);
	}

}
