package com.ipas.hf.web.pages.ipasPages;

import org.openqa.selenium.support.ui.ExpectedCondition;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

import com.ipas.hf.web.pages.BasePage;

public class EligibityMaintainanceNavigationPage extends BasePage{

	@FindBy(xpath="//img[@src='assets/images/logo.png']")
	private WebElement img_logo;

	@FindBy(xpath="//div[@class='e-card-content employee-info']")
	private WebElement txt_welcome;

	@FindBy(xpath="//ul[@class='navbar-nav']")
	private WebElement txt_menuBar;

	@FindBy(xpath="//ul[@class='navbar-nav']/li/a")
	private List<WebElement> lst_menuItems;

	@FindBy(xpath="//span[@class='panel-title']")
	private List<WebElement> lst_panelNames;

	@FindBy(xpath="(//div[@class='e-acrdn-item e-select e-expand-state e-selected e-active'])[1]//div[@class='panel-containArea']//div[@class='contain-text']")
	private List<WebElement> lst_menuOrgUsers;

	@FindBy(xpath="(//div[@class='e-acrdn-item e-select e-expand-state e-selected e-active'])[2]//div[@class='panel-containArea']//div[@class='contain-text']")
	private List<WebElement> lst_payerpanel;

	@FindBy(linkText = "Maintenance")
	private WebElement lnk_Maintenance;

	@FindBy(xpath="//span[@class='breadcrum-active']")
	private WebElement breadcrumb_Maintenance;

	@FindBy(xpath="//img[@alt='settings']")
	private List<WebElement> icon_profile;

	@FindBy(xpath="//span[@class='nav-right-info p-10']")
	private WebElement txt_userid;


	RestActions rest=new RestActions();
	HomePage homePage=new HomePage();


	public EligibityMaintainanceNavigationPage() {
		PageFactory.initElements(driver, this);
	}

	public void navigationBar(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitUntilisDisplayed(img_logo, "Home page logo");
			webActions.isDisplayed(txt_welcome,"Welcome Note");
			report.reportPass("Should display a Welcome Note");
			webActions.isDisplayed(txt_menuBar, "Navigation Bar");
			report.reportPass("Should display Navigation bar whenlogged into the application");
			webActions.waitUntilisDisplayed(lnk_Maintenance, "Maintenance Menu");
			webActions.isDisplayed(lnk_Maintenance,"Maintenance Menu");
			report.reportPass("Should display Maintenance Menu on Navigation Bar");
			webActions.click(lnk_Maintenance, "Maintenance");
			report.reportPass("Should click on Maintenance menu");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifymenuItems(DataTable menuItems){
		try {
			webActions.waitForPageLoaded();
			webActions.waitUntilisDisplayed(txt_menuBar,"Menu Bar");
			ArrayList<String> expmenuItems = new ArrayList<>(menuItems.asList());
			report.reportInfo("Expected Menu Names: "+expmenuItems);
			ArrayList<String> actmenuItems=webActions.getDatafromWebTable(lst_menuItems);
			report.reportInfo("Displayed Actual Menu items  "+actmenuItems);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actmenuItems, expmenuItems);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified Menu items on navigation bar Successfully");
			}
			else{
				throw new Exception("Fail to verify Menu items on navigation bar and unmatched Menu items are: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyPanelsMaintainance(DataTable panels){
		try {
			webActions.waitForPageLoaded();
			ArrayList<String> exppanels = new ArrayList<>(panels.asList());
			report.reportInfo("Expected panels Names: "+exppanels);
			ArrayList<String> actpanels=webActions.getDatafromWebTable(lst_panelNames);
			report.reportInfo("Displayed  panel names  "+actpanels);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actpanels, exppanels);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified Panels on Maintainance main page Successfully");
			}
			else{
				throw new Exception("Fail to Panels on Maintainance main page and unmatched panels are: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void navigationMaintananceMainPage(){
		try {
			webActions.waitForPageLoaded();
			String expectedBreadCrumb="Maintenance";
			String actualBreadCrumb=webActions.getText(breadcrumb_Maintenance, "Maintainance Breadcrumb");
			if(expectedBreadCrumb.contentEquals(actualBreadCrumb))
			{
				report.reportPass("Displayed the BreadCrumb successfully");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyMenuOrgAndUsers(DataTable Menu){
		try {
			webActions.waitForPageLoaded();
			ArrayList<String> expMenu = new ArrayList<>(Menu.asList());
			report.reportInfo("Expected Menu Options in Organizations and Users: "+expMenu);
			ArrayList<String> actMenu=webActions.getDatafromWebTable(lst_menuOrgUsers);
			report.reportInfo("Displayed  Menu Options in Organizations and Users  "+actMenu);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actMenu, expMenu);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified Menu Options in Organizations and Users Successfully");
			}
			else{
				throw new Exception("Fail to verify Menu Options in Organizations and Users and unmatched values are: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyPayerPanel(DataTable payerpanel){
		try {
			webActions.waitForPageLoaded();
			ArrayList<String> expPayerPanel = new ArrayList<>(payerpanel.asList());
			report.reportInfo("Expected Menu Options in Payer Panel: "+expPayerPanel);
			ArrayList<String> actpayerpanel=webActions.getDatafromWebTable(lst_payerpanel);
			report.reportInfo("Displayed  Menu Options in Payer Panel  "+actpayerpanel);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actpayerpanel, expPayerPanel);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified Menu Options in Payer Panel Successfully");
			}
			else{
				throw new Exception("Fail to verify Menu Options in Payer Panel and unmatched values are: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyProfileIcon(){
		try {
			webActions.waitForPageLoaded();
			if(icon_profile.size()==2)
			{
				if(!txt_userid.getText().isEmpty())
				{
					report.reportPass("Should display Profile icons and User Id on Navigation bar successfully");
				}
			}
			else
			{
				throw new Exception("Fail to display Profile icons and User Id on Navigation bar");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyNavigation(){
		try {
			webActions.waitForPageLoaded();
			String expectedPage="https://administrationqa.ipas360.com/#/maintenance";
			String actualPage=driver.getCurrentUrl();
			if(expectedPage.contentEquals(actualPage))
			{
				report.reportPass("Page Navigation Successfull when user selects one of the menu items.");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}




	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}