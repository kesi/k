package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.FAQProgramsPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class FAQProgramsSteps {

	FAQProgramsPage programs=new FAQProgramsPage();

	@Then("go to the programs tab")
	public void go_to_the_programs_tab() {
		programs.goToProgramsTab();
	}

	@Then("Add the programs from add programs window as {string} and verify the programs list")
	public void add_the_programs_from_add_programs_window_as_and_verify_the_programs_list(String program) {
		programs.addPrograms(program);
	}
	@Then("Verify the forms and documents")
	public void verify_the_forms_and_documents(DataTable dataTable) {
		programs.verifyFormsDocs(dataTable);
	}

	@Then("Verify the added program start date and status")
	public void verify_the_added_program_start_date_and_status() {
		programs.verifyProgramStartDateAndStatus();
	}


	@Then("Verify the program forms and documents status as {string}")
	public void verify_the_program_forms_and_documents_status_as(String status) {
		programs.verifyProgramsStatus(status);
	}

	@Then("Verify the programs list from programs window as {string}")
	public void verify_the_programs_list_from_programs_window_as(String program) {
		programs.verifyProgramsAfterAdd(program);
	}
	@Then("Verify the results based on search criteria as {string} in program window")
	public void verify_the_results_based_on_search_criteria_as_in_program_window(String value) {
		programs.verifySearchCriteriaResults(value);
	}

	@Then("Click on cancel verify the added program start date and status")
	public void click_on_cancel_verify_the_added_program_start_date_and_status() {
		programs.clickCancelAndVerify();
	}

	@Then("Delete the added program as {string} and veirfy the programs list from window")
	public void delete_the_added_program_as_and_veirfy_the_programs_list_from_window(String program) {
		programs.verifyProgramsAfterDelete(program);
	}
	@Then("Change the program status as {string} 	and verify display of programs")
	public void change_the_program_status_as_and_verify_display_of_programs(String status) {
		programs.changeProgramsStatus(status);
		programs.verifyProgramfields();
	}

	@Then("Verify the FAQ module status as {string}")
	public void verify_the_FAQ_module_status_as(String status) {
		programs.verifyFAQModuleStatus(status);
	}
	@Then("Verify the Program status as {string}")
	public void verify_the_Program_status_as(String status) {
		programs.verifyProgramStatus(status);
	}
	@Then("Verify the display of programs on the short panel")
	public void verify_the_display_of_programs_on_the_short_panel(DataTable dataTable) {
		programs.verifyShortPanelPrograms(dataTable);
	}
	@Then("Click on forms or documents and verify the navigation")
	public void click_on_forms_or_documents_and_verify_the_navigation() {
		programs.verifyDDNavigation();
	}
	@Then("Change the FAQ forms status to complete")
	public void change_the_FAQ_forms_status_to_complete(DataTable testData) {
		programs.changeStatusOfFAQForms(testData);
	}

	@Then("Navigate back to the programs tab")
	public void navigate_back_to_the_programs_tab() {
		programs.backToProgramsTab();
	}

	@Then("Verify the members visit data")
	public void verify_the_members_visit_data() {
		programs.verifyMembersvisitsData();
		programs.verifyDefaultAddVisitLink();
	}
	@Then("Enter total charges as {string} and verify the patient responsibility value and program as {string}")
	public void enter_total_charges_as_and_verify_the_patient_responsibility_value_and_program_as(String value, String program) {
		programs.verifyChargesAndProgram(value, program);
	}
	@Then("Change the program status as {string}")
	public void change_the_program_status_as(String status) {
		programs.updateProgramsStatus(status);   
	}

	@Then("Add the additional visit as {string}")
	public void add_the_additional_visit_as(String value) {
		programs.addVisits(value);
	}

	@Then("Verify the additional visit data")
	public void verify_the_additional_visit_data(DataTable dataTable) {
		programs.verifyAddedvisitInfo(dataTable);
	}
	@Then("Delete the added visit and verify the default visit trash icon")
	public void delete_the_added_visit_and_verify_the_default_visit_trash_icon() {
		programs.deleteAddedVisitAndVerify();
	}
	@Then("Go to the Screening tab")
	public void go_to_the_Screening_tab() {
		programs.goToScreeningTab();
	}
	@Then("Submit the form from screening tab")
	public void submit_the_form_from_screening_tab() {
		programs.submitScreeningForm();
	}
	@Then("Back to programs tab")
	public void back_to_programs_tab() {
		programs.SwitchToProgramTab();
	}
	@Then("Change the program status and verify the data")
	public void change_the_program_status_and_verify_the_data(DataTable dataTable) {
		programs.changeStatusVerifyData(dataTable);
	}
	@Then("Change the program status as {string} and verify the discount popup")
	public void change_the_program_status_as_and_verify_the_discount_popup(String status) {
		programs.updateProgramsStatusAndVerifyDiscountPopup(status);
	}

	@Then("Select the option as {string} from discount popup and verify the program fields")
	public void select_the_option_as_from_discount_popup_and_verify_the_program_fields(String option) {
		programs.verifyProgramFieldsBasedOnDiscountPopUpOption(option);
	}
	@Then("Verify the display of send to payment button")
	public void verify_the_display_of_send_to_payment_button() {
		programs.verifyPaymentButton();
	}

}
