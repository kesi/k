package com.ipas.hf.web.steps;

import java.util.Properties;

import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.utilities.ConfigProperties;
import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	private ConfigProperties configProp = TestBase.prop;
	
	Login logIn = new Login();
	HomePage home = new HomePage();

	@Given("Open iPAS application home page")
	public void open_iPAS_application_home_page() {
		logIn.openIpasApp();
	}

	@Then("Verify User name, Password fields and Login button")
	public void verify_User_name_Password_fields_and_Login_button() {
		logIn.verifyFields();
	}

	@Then("Verify {string} text from home page")
	public void verify_text_from_home_page(String login) {
		logIn.verifyLoginText(login);
	}

	@Then("Verify {string} text from home page above the user name field")
	public void verify_text_from_home_page_above_the_user_name_field(String guideText) {
		logIn.VerifyGuideText(guideText);
	}

	@Then("Verify Forgot Password? link from home page")
	public void verify_Forgot_Password_link_from_home_page() {
		logIn.verifyPassWordLink();
	}

	@Then("Verify Having trouble Logging In text from home page at the end")
	public void verify_Having_trouble_Logging_In_text_from_home_page_at_the_end() {
		logIn.VerifyHavingTroubleLink();
	}

	@When("Click on Login button with out User Name and Password")
	public void click_on_Login_button_with_out_User_Name_and_Password() {
		logIn.clickLogin();
	}

	@Then("Validate error message as {string}")
	public void validate_error_message_as(String errorMessage) {
		logIn.validateErrorMessage(errorMessage);
	}

	@When("Enter User name as {string} and click on login button")
	public void enter_User_name_as_and_click_on_login_button(String userName) {
		logIn.enterUserName(userName);
		logIn.clickLogin();
	}

	@When("Enter password as {string} wiith out username and click on login button")
	public void enter_password_as_wiith_out_username_and_click_on_login_button(String passWord) {
		logIn.enterPassWord(passWord);
		logIn.clickLogin();
	}

	@Then("Enter valid user name as {string} and Password as {string} click on login button")
	public void enter_valid_user_name_as_and_Password_as_click_on_login_button(String userName, String passWord) {
		logIn.login(userName, passWord);
	}

	@Given("user logged into iPAS as {string} and {string}")
	public void user_logged_into_iPAS_as_and(String userName, String passWord) {
		logIn = logIn.openIpasApp();
		home = logIn.login(userName, passWord);
	}
	
	@Then("Click on Forgot Password? link from the home page")
	public void click_on_Forgot_Password_link_from_the_home_page() {
		logIn.clickForgotPassword();
	}

	@Then("Verify Forgot Password? header on the page")
	public void verify_Forgot_Password_header_on_the_page() {
		logIn.verifyHeader();
	}

	@Then("Verify {string} text message")
	public void verify_text_message(String text) {
		logIn.verifyResetPasswordText(text);
	}

	@Then("Verify User Id text field and Reset password button")
	public void verify_User_Id_text_field_and_Reset_password_button() {
		logIn.verifyTextButton();
	}

	@When("Click on Reset Password button with out user id")
	public void click_on_Reset_Password_button_with_out_user_id() {
		logIn.clickRestButton();
	}

	@Then("Verify {string} error message")
	public void verify_error_message(String errorMessage) {
		logIn.verifyResetError(errorMessage);
	}

	@When("Enter valid user id {string} and click on Rest Password button")
	public void enter_valid_user_id_and_click_on_Rest_Password_button(String userID) {
	    logIn.enterUserIdAndClick(userID);
	}

	@Then("Verify {string}")
	public void verify(String message) {
	   logIn.verifyEmailMessage(message);
	}
	
	@Then("Login to gmail and reset the password")
	public void Login_to_gmail_and_reset_the_password() {
	    logIn.resetPassword();
	}

	@Then("Verify Reset password success message")
	public void verify_Reset_password_success_message() {
	    logIn.verifySuccessResetMessage();
	}
	
	@Then("Login to the application with reset password")
	public void login_to_the_application_with_reset_password() {
	    logIn.loginResetPassword();
	}
	
	@Then("Login to gmail and go to reset password page")
	public void login_to_gmail_and_go_to_reset_password_page() {
	   logIn.goToResetPage();
	}

	@When("Click on Reset password with out new password and verify validation as {string}")
	public void click_on_Reset_password_with_out_new_password_and_verify_validation_as(String errorMessage) {
	    logIn.withOutPassword(errorMessage);
	}

	@Then("Enter {string} as new password and verify validation message as {string}")
	public void enter_as_new_password_and_verify_validation_message_as(String value, String errorMessage) {
	    logIn.minimumLength(value, errorMessage);
	}
	
	@Then("Enter with out uppercase {string} as new password and verify validation message as {string}")
	public void enter_with_out_uppercase_as_new_password_and_verify_validation_message_as(String value, String errorMessage) {
	    logIn.withOutUpperCase(value,errorMessage);
	}

	@Then("Enter with out special char {string} as new password and verify validation message as {string}")
	public void enter_with_out_special_char_as_new_password_and_verify_validation_message_as(String value, String errorMessage) {
	    logIn.withOutSpecialChar(value,errorMessage);
	}

	@Then("Enter last password and reset password and validate validation message as {string}")
	public void enter_last_password_and_reset_password_and_validate_validation_message_as(String errorMessage) {
	    logIn.lastPassword(errorMessage);
	}

	@Then("Enter password as {string} and confirm password as {string} and validate message as {string}")
	public void enter_password_as_and_confirm_password_as_and_validate_message_as(String value1, String value2, String errorMessage) {
	    logIn.passWordNotMatch(value1,value2,errorMessage);
	}
	
	@Then("Get the value from response body and get value of {string} and search")
	public void get_the_value_from_response_body_and_get_value_of_and_search(String patientId) {
		String visitIdvalue = logIn.getVisitIdFromResponse(patientId);
		logIn.simpleSearch(visitIdvalue);
	}

	@Given("Logged into the iPAS with tenant specific user credentials")
	public void logged_into_the_iPAS_with_tenant_specific_user_credentials() {
		logIn = logIn.openIpasApp();
		home = logIn.login(configProp.tenantUserName(),configProp.tenatPassword());
	}
	
	@Then("Verify the {string} link after login successfully")
	public void verify_the_link_after_login_successfully(String expLabelName) {
		logIn.verifyAccountSearchLink(expLabelName);
	   
	}	
	
	@Given("Logged into the {string} with tenant specific user credentials")
	public void logged_into_the_with_tenant_specific_user_credentials(String tenant) {
		logIn = logIn.openApplication(tenant);
		logIn.loginApplication(configProp.applicationLoginUserName(),configProp.applicationLoginPassword());
	}



}
