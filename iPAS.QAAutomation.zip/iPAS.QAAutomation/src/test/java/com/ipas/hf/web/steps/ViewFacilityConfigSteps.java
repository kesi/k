package com.ipas.hf.web.steps;
import java.io.IOException;
import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.ipasPages.AccountSearchFilteringPage;
import com.ipas.hf.web.pages.ipasPages.AddPatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.ModuleStatusServiceTrackerPage;
import com.ipas.hf.web.pages.ipasPages.PatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.SignalRPage;
import com.ipas.hf.web.pages.ipasPages.SimpleSearchPage;
import com.ipas.hf.web.pages.ipasPages.ViewFacilityConfigPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class ViewFacilityConfigSteps {

	ViewFacilityConfigPage viewfacility     =new ViewFacilityConfigPage();
	
	@Then("Verify the panel name and links under accuracy and accountability")
	public void verify_the_panel_name_and_links_under_accuracy_and_accountability(DataTable panelNames) {
	    viewfacility.verifyPanelAndLinks(panelNames);
	}
	
	@Then("Verify the Help Text")
	public void verify_the_Help_Text(DataTable label) {
	   viewfacility.verifyHelpText(label);
	}
	
	@Then("Verify the Rules configuration link")
	public void verify_the_Rules_configuration_link() {
		 viewfacility.clickRuleConfiguration();
	   	}

	@Then("Verify the breadcrumb when navigated to rules configuration")
	public void verify_the_breadcrumb_when_navigated_to_rules_configuration(DataTable breadcrumb) {
		viewfacility.verifyBreadcrumbRulesConfiguration(breadcrumb);
	}
	
	@Then("Verify add new rule button and the facility name")
	public void verify_add_new_rule_button_and_the_facility_name() {
		viewfacility.verifyAddNewRule();
	}
	
	@Then("Verify The Rule list will be displayed below the search bar in rules configuration")
	public void verify_the_rule_list_below_the_search_bar(DataTable rulelist) {
		viewfacility.verifyBreadcrumbRulesConfiguration(rulelist);
	}
	
	@Then("Verify the default value in rule category dropdown as {string}")
	public void verify_default_Value_in_rule_category_dropdown(String value) {
		viewfacility.verifyDefaultValue(value);
	}
	
	@Then("Verify the {string} checkbox will display to right of Rule Category filter")
	public void verify_the_inactive_checkbox(String value) {
		viewfacility.verifyInactiveCheckBox(value);
	}
	
	@Then("Verify the results displayed in rules configuration page")
	public void verify_results_displayed_in_rules_configuration() {
		viewfacility.verifyResultsDisplayed();
	}
	
	@Then("Verify the rules list displayed in rules configuration page")
	public void verify_rules_list_displayed_in_rules_configuration(DataTable rulelist) {
		viewfacility.verifyRuleListRulesConfiguration(rulelist);
	}
	
	@Then("Verify the search headers in rules configuration page")
	public void verify_the_search_headers_in_rules_configuration(DataTable labels) {
		viewfacility.verifySearchHeaders(labels);
	}

}
