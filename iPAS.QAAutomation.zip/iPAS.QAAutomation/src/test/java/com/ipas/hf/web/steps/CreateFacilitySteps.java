package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.AddPatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.CreateFacilityPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class CreateFacilitySteps {

	CreateFacilityPage facility=new CreateFacilityPage();
	AddPatientVisitPage addPatient=new AddPatientVisitPage();

	@Then("Click on organization maintenance")
	public void click_on_organization_maintenance() {
		facility.clickOrgMaintenance();
	}

	@Then("Click on tenant")
	public void click_on_tenant() {
		facility.clickOnTenantName();
	}

	@Then("Verify the display of breadcrumb")
	public void verify_the_display_of_breadcrumb(DataTable breadcrumb) {
		facility.verifyBreadcrumbinListOfFacilityPage(breadcrumb);
	}

	@Then("Navigate to admin Maintenance Page")
	public void navigate_to_admin_Maintenance_Page() {
		facility.navigateToMaintenance();
	}
	@Then("Verify the display of Add New Facility button")
	public void verify_the_display_of_Add_New_Facility_button() {
		facility.verifyfields();
	}

	@Then("Click on Add New Facilty button")
	public void click_on_Add_New_Facilty_button() {
		facility.clickOnAddNewFacility();
	}

	@Then("Verify the display of {string} in add new facility page")
	public void verify_the_display_of_in_add_new_facility_page(String fields,DataTable fieldNames) {
		facility.verifyfieldsAndSections(fields, fieldNames);
	}

	@Then("Verify the Save button mode")
	public void verify_the_Save_button_mode() {
		facility.verifySavebtnMode();
	}
	@Then("Send data as {string} to Facility Name field")
	public void send_data_as_to_Facility_Name_field(String data) {
		facility.enterData(data);
	}

	@Then("Verify the validation of {string} and enter data as {string}")
	public void verify_the_validation_of_and_enter_data_as(String expectedMsg, String inputData) {
		facility.verifyNPIValidations(expectedMsg, inputData);
	}
	@Then("Verify the validation of {string} field as {string} by entering the value as {string}")
	public void verify_the_validation_of_field_as_by_entering_the_value_as(String field, String expMsg, String input) {
		facility.verifyfieldValidations(field, expMsg, input);
	}
	@Then("Click on Cancel button and verify the page navigation")
	public void click_on_Cancel_button_and_verify_the_page_navigation() {
		facility.clickCancelAndVerify();
	}
	@Then("Enter data in create facility page")
	public void enter_data_in_create_facility_page(DataTable testData) {
		facility.enterDataInFacilityFields(testData);
	}
	@Then("Create new facility for tenant and Click on Save")
	public void create_new_facility_for_tenant_and_Click_on_Save(DataTable testData) {
		String facilityName=facility.createFacility(testData);
		facility.searchFacilityName(facilityName);
		facility.verifyCreatedFacilityNameFromGrid(facilityName);
	}
	@Then("Verify creating of duplicate facility code")
	public void verify_creating_of_duplicate_facility_code(DataTable testData) throws InterruptedException {
		facility.createFacility(testData);
		Thread.sleep(2000);
		facility.clickOnAddNewFacility();
		facility.verifyDuplicateFacilityCode(testData);
	}
	@Then("Click on tenant and verify the display of tenant name in view list of facility page")
	public void click_on_tenant_and_verify_the_display_of_tenant_name_in_view_list_of_facility_page() {
		facility.verifyTenantName();
	}
	@Then("Verify the display of view list of headers")
	public void verify_the_display_of_view_list_of_headers(DataTable testData) {
		facility.verifyViewListofFacilityHeaders(testData);
	}
	@Then("Verify the display of icons")
	public void verify_the_display_of_icons() {
		facility.verifyIcons();
	}
	@Then("Verify the display of tenant CRMID in view list of facility page")
	public void verify_the_display_of_tenant_CRMID_in_view_list_of_facility_page() {
		facility.verifyTenantCRMID();
	}
	@Then("Verify the redirecting of page on selecting the CRMID link")
	public void verify_the_redirecting_of_page_on_selecting_the_CRMID_link() {
		facility.verifyCRMIDLink();
	}
	@Then("Verify the result count from view list of facility page")
	public void verify_the_result_count_from_view_list_of_facility_page() {
		facility.verifyResultCountOfViewFacilityList();
	}
	@Then("Click on pencil icon")
	public void click_on_pencil_icon() {
		facility.clickOnPencilIcon();
	}
	@Then("Verify the Update button mode")
	public void verify_the_Update_button_mode() {
		facility.verifyUpdatebtnMode();
	}
	@Then("Update the facility details and verify from list of faility page")
	public void update_the_facility_details_and_verify_from_list_of_faility_page() {
		facility.updateAndVerifyFacilityName();
	}
	@Then("Clear the values from facility name and code and verify mandatory validation")
	public void clear_the_values_from_facility_name_and_code_and_verify_mandatory_validation(DataTable testData) {
		facility.clearValuesFromEditFacility(testData);
	}
	@Then("Click on update button with duplicate facility code")
	public void click_on_update_button_with_duplicate_facility_code() {
		facility.updateWithDuplicateFacilityCode();
	}
	@Then("Clear the value from facility name search")
	public void clear_the_value_from_facility_name_search() {
		facility.clearFacilityNameSearch();
	}
	@Then("Click  on facilities link and verif the navigation")
	public void click_on_facilities_link_and_verif_the_navigation() {
		facility.clickOnFacilitiesBreadCrumb();
	}
	@Then("Click  on tenants link and verif the navigation")
	public void click_on_tenants_link_and_verif_the_navigation() {
		facility.clickOnTenantsBreadCrumb();
	}

}
