package com.ipas.hf.web.pages.ipasPages;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class ChargeMasterPage extends BasePage{

	@FindBy(xpath="//a[contains(text(),'Charge Master Configuration')]")
	private WebElement panel_ChargeMaster;

	@FindBy(xpath="//div[contains(text(),'Configure facility charge master.')]")
	private WebElement txt_ChargeMasterDesc;

	@FindBy(linkText="Charge Master Configuration")
	private WebElement lnk_ChargeMaster;

	@FindBy(xpath="//tbody/tr/td[2]//a")
	private List<WebElement> lnk_ChargeCodes;

	@FindBy(xpath="//a[contains(text(),'Add New Line')]")
	private WebElement btn_AddNewLine;

	@FindBy(xpath="//a[contains(text(),'Cancel')]")
	private WebElement btn_Cancel;

	@FindBy(xpath="//a[contains(text(),'Add')]")
	private WebElement btn_Add;

	@FindBy(xpath="//div[contains(@class,'breadcrum-container')]/span")
	private List<WebElement> lbl_Breadcrumb;

	@FindBy(xpath="(//ipas-maintenance-manage-charge-master//ejs-textbox//span/input)[1]")
	private WebElement txt_ChargeCode;

	@FindBy(xpath="//ejs-numerictextbox//span/input[1]")
	private WebElement txt_ChargeAmount;

	@FindBy(xpath="//p[@class='error']")
	private List<WebElement> lbl_MandatoryMessages;

	@FindBy(xpath="//input[@formcontrolname='departmentName']")
	private WebElement txt_Department;

	@FindBy(xpath="//input[@formcontrolname='generalLedgerNumber']")
	private WebElement txt_GeneralLedger;

	@FindBy(xpath="//span//textarea[@formcontrolname='description']")
	private WebElement txt_Description;

	@FindBy(xpath="//ejs-textbox[@formcontrolname='cptCode']")
	private WebElement chk_CPTCode;

	@FindBy(xpath="(//div/img)[1]")
	private WebElement chk_CPTCodeImg;

	@FindBy(xpath="//input[@placeholder='Type Code or Key Word']")
	private WebElement txt_CPTCodeSearchBox;

	@FindBy(xpath="//td[contains(text(),'I&D p-spine c/t/cerv-thor')]")
	private WebElement txt_CPTCodeSearchResults;

	@FindBy(xpath="//ipas-medical-necessity-cpt-icd-footer//button[1]")
	private WebElement btn_CPTCodeWindowCancel;

	@FindBy(xpath="//ipas-medical-necessity-cpt-icd-footer//button[2]")
	private WebElement btn_CPTCodeWindowSave;

	@FindBy(xpath="//ejs-multiselect[@formcontrolname='modifiers']")
	private WebElement chk_Modifiers;

	@FindBy(xpath="(//div/img)[2]")
	private WebElement chk_RevCodeImg; 

	@FindBy(xpath="//input[@formcontrolname='revenueCode']")
	private WebElement chk_RevCode;

	@FindBy(xpath="//input[@placeholder='Type Code or Key Word']")
	private WebElement txt_RevCodeSearchBox;

	@FindBy(xpath="//td[contains(text(),'Very high rehabilitation-RUGS RVA/ADL index of 4-7')]")
	private WebElement txt_RevCodeSearchResults;

	@FindBy(xpath="//ipas-maintenance-rev-code-footer//ipas-button[1]")
	private WebElement btn_RevCodeWindowCancel;

	@FindBy(xpath="//ipas-maintenance-rev-code-footer//ipas-button[2]")
	private WebElement btn_RevCodeWindowSelect;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;

	@FindBy(xpath = "//input[@placeholder='Type Search Criteria']")
	private WebElement txt_ViewCptSearchtext;

	@FindBy(xpath = "//a[contains(text(),'Apply')]")
	private WebElement btn_Apply;

	@FindBy(xpath="(//tbody/tr/td[1])")
	private WebElement lnk_ChargeCodesResultsRow;

	@FindBy(xpath="//p[contains(text(),'Duplicate Charge Code')]")
	private WebElement lbl_DuplicateChargeCodeMsg;

	@FindBy(xpath="(//tbody/tr/td[2])[2]")
	private WebElement lnk_ChargeCode;

	@FindBy(xpath="(//tbody/tr/td[9])[2]")
	private WebElement lnk_ChargeAmount;

	@FindBy(xpath="//a[contains(text(),'Save')]")
	private WebElement btn_Save;

	@FindBy(xpath="//input[@aria-placeholder='MM/DD/YYYY']")
	private WebElement date_ChargeCode;

	@FindBy(xpath="(//ipas-maintenance-charge-master-price-history//tbody/tr/td[1])[2]")
	private WebElement lbl_CurrentPrice;

	@FindBy(xpath="(//ipas-maintenance-charge-master-price-history//tbody/tr/td[2])[2]")
	private WebElement lbl_CurrentEffectiveDate;

	public ChargeMasterPage() {
		PageFactory.initElements(driver, this);
	}


	public void verifyPanelInfo(DataTable testData){
		try {
			ArrayList<String>expData=new ArrayList<String>(testData.asList());
			ArrayList<String> actData=new ArrayList<String>();
			actData.add(webActions.waitAndGetText(panel_ChargeMaster, "panelName"));
			actData.add(webActions.waitAndGetText(txt_ChargeMasterDesc, "panelDescription"));

			ArrayList<String>unMatchPanelData=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unMatchPanelData.size()==0){
				report.reportPass("Successfully verified charge master panel info");
			}else{
				report.reportFail("Failed to verify the charge master panel information");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void waitForPageLoade(int seconds){
		try {
			Thread.sleep(seconds*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void verifyBreadCrumbAddNewLinePage(DataTable breadcrumb ){
		try {
			ArrayList<String> expectdBreadcrumb = new ArrayList<>(breadcrumb.asList());
			webActions.refreshPage();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_ChargeMaster, "ChargeMsterConfiguration");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lnk_ChargeCodes, "TotalChargeCodes");
			webActions.waitAndClick(btn_AddNewLine, "AddNewLine");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_Cancel, "CancelButton");
			ArrayList<String> actualBreadcrumb=webActions.getDatafromWebTable(lbl_Breadcrumb);
			report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumb);
			report.reportInfo("Expected Breadcrumb Titles "+expectdBreadcrumb);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumb, expectdBreadcrumb);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Breadcrumb Titles in Add New line page");
			}else{
				throw new Exception("Fail to verify the Breadcrumb Titles in Add New line page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifytheMandatoryFieldValidationsAndCancelButton(DataTable validationMessages){
		try {
			ArrayList<String> expectdValidationMessages = new ArrayList<>(validationMessages.asList());
			webActions.waitForPageLoaded();
			webActions.click(txt_ChargeCode, "Charge Code");
			webActions.pressTab();
			waitForPageLoade(1);
			webActions.click(txt_ChargeAmount, "Charge Amount");
			webActions.pressTab();
			waitForPageLoade(2);		
			ArrayList<String> actualValidationMessages=webActions.getDatafromWebTable(lbl_MandatoryMessages);
			report.reportInfo("Actual Validation Messages: "+actualValidationMessages);
			report.reportInfo("Expected Validation Messages: "+expectdValidationMessages);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualValidationMessages, expectdValidationMessages);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Mandatory Field Validation Messages in Add charge code page");
			}else{
				throw new Exception("Fail to verify the Mandatory Field Validation Messages in Add charge code page: "+unmatch);
			}
			webActions.click(btn_Cancel, "Cancel");
			webActions.waitForLoad();
			webActions.waitForVisibilityOfAllElements(lnk_ChargeCodes, "TotalChargeCodes");
			String expName=webActions.waitAndGetText(btn_AddNewLine, "AddNewLine");
			if("Add New Line".contains(expName)){
				report.reportPass("Successfully verified the Cancel button in Add Charge code page");
			}else{
				throw new Exception("Fail to verify the Cancel button in Add charge code page: "+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void goToAddChargeCodePage(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_ChargeMaster, "ChargeMsterConfiguration");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lnk_ChargeCodes, "TotalChargeCodes");
			webActions.waitAndClick(btn_AddNewLine, "AddNewLine");
			waitForPageLoade(1);
			webActions.waitForVisibility(btn_Cancel, "CancelButton");
			report.reportInfo("Successfully navigated to teh add charge code page");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void addChargeCode(DataTable testData){
		String chargeCode="";
		try {
			ArrayList<String> actCptData=new ArrayList<String>();
			ArrayList<String> expCptData=new ArrayList<String>();
			String amt=webActions.getDatafromMap(testData, "Amount");
			String dep=webActions.getDatafromMap(testData, "Department");
			String ledger= webActions.getDatafromMap(testData, "General Ledger");
			String desc= webActions.getDatafromMap(testData, "Description");
			String cpt=webActions.getDatafromMap(testData, "CPT Code");
			String modifiers= webActions.getDatafromMap(testData, "Modifiers");
			String revCode= webActions.getDatafromMap(testData, "Rev Code");
			webActions.waitForPageLoaded();
			chargeCode=webActions.getRandomString(4);
			chargeCode="A12-"+chargeCode;
			webActions.notepadWrite("hello", chargeCode);
			webActions.sendKeys(txt_ChargeCode, chargeCode, "Charge Code");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_Department,dep, "Department");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_GeneralLedger,ledger, "Department");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_Description,desc, "Department");
			webActions.waitForPageLoaded();
			webActions.click(chk_CPTCodeImg, "CPtCOdeImg");
			waitForPageLoade(5);
			webActions.sendKeys(txt_CPTCodeSearchBox,cpt, "CPT Code");
			webActions.waitForVisibility(txt_CPTCodeSearchResults, "CPTResults");
			waitForPageLoade(2);
			webActions.click(txt_CPTCodeSearchResults, "CPTResults");
			webActions.waitAndClick(btn_CPTCodeWindowSave, "Save");
			webActions.waitForPageLoaded();			
			selectDropdown(chk_Modifiers,modifiers, "Modifiers");
			webActions.waitForPageLoaded();
			webActions.click(chk_RevCodeImg, "RevCOdeImg");
			waitForPageLoade(5);
			webActions.sendKeys(txt_RevCodeSearchBox,revCode, "Rev Code");
			webActions.waitForVisibility(txt_RevCodeSearchResults, "RevCodeResults");
			waitForPageLoade(2);
			webActions.click(txt_RevCodeSearchResults, "RevResults");
			webActions.waitAndClick(btn_RevCodeWindowSelect, "Select");
			waitForPageLoade(2);
			webActions.sendKeys(txt_ChargeAmount,amt, "Amount");
			webActions.pressTab();
			waitForPageLoade(2);
			webActions.waitAndClick(btn_Add, "Add");
			/*	String actContent=getAlertMessage();
			if("Data saved successfully.".contentEquals(actContent)){
				report.reportPass("Successfully added the new charge code: "+actContent);
			}
			else{				
				report.reportFail("Failed to add the new charge code: "+actContent);
			}*/
			webActions.waitForVisibilityOfAllElements(lnk_ChargeCodes, "ChargeCodes");
			webActions.sendKeys(txt_ViewCptSearchtext, chargeCode, "ChargeCode");
			waitForPageLoade(2);
			webActions.click(btn_Apply, "Apply");
			waitForPageLoade(5);
			webActions.waitForVisibilityOfAllElements(lnk_ChargeCodes, "ChargeCodes");		
			expCptData.add("Active");
			expCptData.add(chargeCode);
			expCptData.add(desc);
			expCptData.add(dep);
			expCptData.add(cpt);
			expCptData.add(modifiers);
			expCptData.add(revCode);
			expCptData.add(ledger);
			String amt1="$"+amt;
			expCptData.add(amt1);
			expCptData.add(webActions.getSystemCurrentDate());
			String xpath1="(//tbody/tr/td[])[2]";
			waitForPageLoade(3);
			for (int i = 1; i <=10; i++) {
				actCptData.add(driver.findElement(By.xpath(("(//tbody/tr/td["+i+"])[2]"))).getText());
				waitForPageLoade(1);

			}
			report.reportInfo("Actual charge code information: "+actCptData);
			report.reportInfo("Expected charge code information "+expCptData);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actCptData, expCptData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the added charge code details from grid");
			}else{
				throw new Exception("Fail to verify the added charge code details from grid and unmatched data is: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void selectDropdown(WebElement element,String valuetoSelect,String elementName) throws Exception{
		try {
			if (!valuetoSelect.isEmpty()) {
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.click(element, elementName);
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				driver.findElement(By.xpath("//li[contains(.,'" + valuetoSelect + "')]")).click();
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
			}
		} catch (Exception e) {
			throw e;
		}
	}
	public String getAlertMessage(){
		String actContent="";
		try {
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Alert Message");
			String[] titleContent=msg.split("\\n");
			actContent=titleContent[1];
		} catch (Exception e) {
		}
		return actContent;
	}
	public void verifyDuplicateChargeCode(String expmsg){
		try {
			webActions.waitAndClick(btn_AddNewLine, "AddNewLine");
			waitForPageLoade(1);
			webActions.waitForVisibility(btn_Cancel, "CancelButton");
			report.reportInfo("Successfully navigated to teh add charge code page");
			String chargeCode=webActions.notepadRead("hello");
			webActions.sendKeys(txt_ChargeCode, chargeCode, "Charge Code");
			waitForPageLoade(1);
			webActions.sendKeys(txt_ChargeAmount,"120", "Amount");
			webActions.pressTab();
			waitForPageLoade(2);
			webActions.waitAndClick(btn_Add, "Add");
			waitForPageLoade(2);
			String actMsg=webActions.getText(lbl_DuplicateChargeCodeMsg, "ChargeCodeMsg");
			if(expmsg.contentEquals(actMsg)){
				report.reportPass("Successfully verified the duplicate charge code message");
			}
			else{
				report.reportFail("Fail to verify teh duplicate charge code message and actual is:"+actMsg);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyChargeCodeMode(){
		try {
			webActions.click(lnk_ChargeCode, "ChargeCode");
			waitForPageLoade(2);
			webActions.waitForVisibility(btn_Cancel, "CancelButton");
			report.reportInfo("Successfully navigated to teh add charge code page");
			String value=webActions.getAttributeValue(txt_ChargeCode, "aria-disabled", "chargecode");
			if(value.contentEquals("true")){
				report.reportPass("Charge Code is displayed in disabled mode");
			}else{
				report.reportFail("Fail to verify the charge code mode:"+value);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void editAndVerifyUpdatedDataFromGrid(DataTable testData){
		try {
			ArrayList<String> actCptData=new ArrayList<>();
			ArrayList<String> expCptData=new ArrayList<String>();
			String dep=webActions.getDatafromMap(testData, "Department");
			String Amount=webActions.getDatafromMap(testData, "Amount");
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_Department, "Department");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_Department,dep, "Department");
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_ChargeAmount, "Amount");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_ChargeAmount,Amount, "Amount");
			webActions.pressTab();
			/*SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy");
			Calendar calendar=Calendar.getInstance();
			calendar.add(Calendar.DATE,1);
			 String nextDate=sdf.format(calendar.getTime());
			 webActions.waitForPageLoaded();
			webActions.clearValue(date_ChargeCode, "Amount");
			webActions.waitForPageLoaded();
			webActions.sendKeys(date_ChargeCode,nextDate, "Amount");*/			
			waitForPageLoade(2);
			webActions.waitAndClick(btn_Save, "Save");
			webActions.waitForVisibilityOfAllElements(lnk_ChargeCodes, "ChargeCodes");
			for (int i = 2; i <=9; i++) {
				if(i==2|i==3|i==5|i==6|i==7|i==8){
					continue;
				}
				else{
					actCptData.add(driver.findElement(By.xpath(("(//tbody/tr/td["+i+"])[2]"))).getText());
					waitForPageLoade(1);
				}				

			}
			expCptData.add(dep);
			String amt1="$"+Amount;
			expCptData.add(amt1);
			//expCptData.add(nextDate);
			report.reportInfo("Actual charge code information: "+actCptData);
			report.reportInfo("Expected charge code information "+expCptData);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actCptData, expCptData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the updated charge code details from grid");
			}else{
				throw new Exception("Fail to verify the updated charge code details from grid and unmatched data is: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyPriceHistory(DataTable testData){
		try {
			ArrayList<String> actCptData=new ArrayList<>();
			ArrayList<String> expCptData=new ArrayList<String>();			
			String Amount=webActions.getDatafromMap(testData, "Amount");
			String amt1="$"+Amount;
			String date=webActions.getSystemCurrentDate();
			webActions.click(lnk_ChargeAmount, "Amount");
			waitForPageLoade(3);
			actCptData.add(webActions.getText(lbl_CurrentPrice, "Amount"));
			actCptData.add(webActions.getText(lbl_CurrentEffectiveDate, "Amount"));
			expCptData.add(amt1);
			expCptData.add(date);
			report.reportInfo("Actual price history information: "+actCptData);
			report.reportInfo("Expected price history information "+expCptData);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actCptData, expCptData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the price history details");
			}else{
				throw new Exception("Fail to verify the price history and unmatched data is: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
