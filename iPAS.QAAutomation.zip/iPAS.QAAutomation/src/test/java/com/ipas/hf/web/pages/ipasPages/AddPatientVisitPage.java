package com.ipas.hf.web.pages.ipasPages;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Sleeper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;


import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.ExtentSummary;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;
import io.cucumber.datatable.DataTable;

public class AddPatientVisitPage extends BasePage{

	private static final int WebElement = 0;
	private static final int Info = 0;
	RestActions rest=new RestActions();
	SimpleSearchPage search=new SimpleSearchPage();
	PatientVisitSummaryAllDataPanelPage mainPage=new PatientVisitSummaryAllDataPanelPage();

	Login logIn=new Login();


	@FindBy(xpath = "//i[contains(@class,'fa fa-ellipsis-v fa-')]")
	private WebElement btn_threedots;

	@FindBy(xpath = "//i[contains(@class,'fa fa-plus-circle fa-blue mr-')]")
	private WebElement btn_tools_AddPatient;

	@FindBy(xpath = "//span//a[text()='Account Search']/../..//span[text()='Add Patient']")
	private WebElement breadcrumb_addPatient_acctsearch;

	@FindBy(xpath = "//span//a[text()='Service Tracker']/../..//span[text()='Add Patient']")
	private WebElement breadcrumb_addPatient_ServiceTracker;

	@FindBy(xpath = "//ipas-autocomplete//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_acctSearch;

	@FindBy(xpath = "//service-tracker-searchbox//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_serviceTracker;

	@FindBy(xpath = "//span[text()='Patient Information']")
	private WebElement txt_PatientInformation;

	@FindBy(xpath = "//span[text()='Guarantor Information']")
	private WebElement txt_GuarantorInformation;

	@FindBy(xpath = "//span[text()='Visit Information']")
	private WebElement txt_VisitInformation;

	@FindBy(xpath = "//span[text()='Insurance Information']")
	private WebElement txt_InsuranceInformation;

	@FindBy(xpath = "//div[@formgroupname='Patient']//input[@id='lastname']")
	private WebElement txt_LastName;

	@FindBy(xpath = "//div[@formgroupname='Patient']//input[@id='firstname']")
	private WebElement txt_FirstName;

	@FindBy(xpath = "//div[@formgroupname='Patient']//input[@placeholder='Middle Name']")
	private WebElement txt_MiddleName;

	@FindBy(xpath = "//input[@id='PatientDateOfBirth_input']")
	private WebElement txt_DOB;

	@FindBy(xpath = "//input[@aria-placeholder='Select Gender']")
	private WebElement txt_Gender;

	@FindBy(xpath = "//input[@aria-placeholder='Select Language']")
	private WebElement txt_language;

	@FindBy(xpath = "//div[@formgroupname='Patient']//input[@id='contactsEmail']")
	private WebElement txt_contEmail;

	@FindBy(xpath = "//input[@formcontrolname='HomePhoneNumber']")
	private WebElement txt_homePhone;

	@FindBy(xpath = "//input[@formcontrolname='MobilePhoneNumber']")
	private WebElement txt_mobPhone;

	@FindBy(xpath = "//input[@formcontrolname='GuarantorLastName']")
	private WebElement txt_GuartLastname;

	@FindBy(xpath = "//input[@formcontrolname='GuarantorFirstName']")
	private WebElement txt_GuartFirstname;

	@FindBy(xpath = "//input[@formcontrolname='GuarantorMiddleInitial']")
	private WebElement txt_GuartMiddlename;

	@FindBy(xpath = "//input[@name='employeeSinceDate']")
	private WebElement txt_GuartDOB;

	@FindBy(xpath = "//input[@formcontrolname='GuarantorEmail']")
	private WebElement txt_GuartEmail;

	@FindBy(xpath = "//input[@formcontrolname='GuarantorPhoneNumber']")
	private WebElement txt_GuartHomePhone;

	@FindBy(xpath = "//input[@formcontrolname='GuarantorMobileNumber']")
	private WebElement txt_GuartMobPhone;

	@FindBy(xpath = "//input[@aria-placeholder='Select Physician']")
	private WebElement drpdwn_Physician;

	@FindBy(xpath = "//span[@formcontrolname='RelationshipTypeCode']")
	private WebElement drpdwn_relationToPatient;


	@FindBy(xpath = "//input[@aria-placeholder='Select Visit Status']")
	private WebElement txt_VisitStatus;

	@FindBy(xpath = "//input[@aria-placeholder='Select Payer']")
	private WebElement txt_Payer;

	@FindBy(xpath = "//input[@class='e-input' and @placeholder='Select Visit Status']")
	private WebElement drpdwn_visitStatus;

	@FindBy(xpath = "//input[@class='e-input' and @placeholder='Select Visit Status']/../span")
	private WebElement arrw_visitStatus;

	@FindBy(xpath = "//input[@class='e-input' and @placeholder='Select Location']")
	private WebElement drpdwn_location;

	@FindBy(xpath = "//input[@class='e-input' and @placeholder='Select Payer']")
	private WebElement drpdwn_payer;

	@FindBy(xpath = "//input[@class='e-input' and @placeholder='Select Location']/../span")
	private WebElement arrw_location;

	@FindBy(xpath = "//a[text()='All Data']")
	private WebElement lnk_AllData;

	@FindBy(xpath = "//input[@formcontrolname='DiagnosisName']")
	private WebElement txt_Diagnosis;

	@FindBy(xpath = "//input[@formcontrolname='InsurancePolicyNumber']")
	private WebElement txt_SubscriberID;

	@FindBy(xpath = "//span[@class='similaraccounttitle']//following::span[1]")
	private WebElement txt_simAcct;

	@FindBy(xpath = "//td[1]/div[1]/div[1]/div[1]")
	private WebElement txt_simAcctName;

	@FindBy(xpath = "//div[@class='similaraccount']//div[@class='boldtext']//following::div[1]")
	private WebElement txt_simAcctDate;

	@FindBy(xpath = "//button[contains(text(),'Submit')]")
	private WebElement btn_Submit;

	@FindBy(xpath = "//button[contains(text(),'Cancel')]")
	private WebElement btn_Cancel;

	@FindBy(xpath = "//button[contains(text(),'Clear')]")
	private WebElement btn_Clear;

	@FindBy(xpath = "//div[@formgroupname='Patient']/label[contains(text(),'Last Name')]/span[text()='*']")
	private WebElement lbl_mandLastName;

	@FindBy(xpath = "//span[@class='mandatory']/..")
	private List<WebElement> lst_mandatory_fields;

	@FindBy(xpath = "//div[@class='mandatory']")
	private List<WebElement> lst_MandatoryFieldMsg;

	@FindBy(xpath = "//div[contains(text(),'Maximum') or contains(text(),'Minimum') or contains(text(),'Invalid') or contains(text(),'Accepts')]")
	private List<WebElement> lst_MandatoryFieldValidationMessage;

	@FindBy(xpath = "(//div[@class='ng-star-inserted'])[1]")
	private WebElement txt_MandatoryFieldValidationMessage;

	@FindBy(xpath = "//span[@class='mandatory']/../..")
	private WebElement lst_txt_fields;

	@FindBy(xpath = "//div[@formgroupname='Patient']")
	private List<WebElement> lst_PatientInformation;

	@FindBy(xpath = "//div[@formgroupname='Guarantor']//label")
	private List<WebElement> lst_GuarantorInformation;

	@FindBy(xpath = "//div[@formgroupname='Insurance']//label")
	private List<WebElement> lst_InsuranceInformation;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;

	@FindBy(xpath = "//div[@class='p5 ng-star-inserted']/span[1]")
	private WebElement txt_AcctNo;

	@FindBy(xpath = "//div[@formgroupname='Patient']//input[1]")
	private List<WebElement> lbl_placeholder_PatientInformation;

	@FindBy(xpath = "//input[@class='form-control ng-pristine ng-valid ng-touched']")
	private List<WebElement> lbl_placeholder_GuarantorTxtBox;

	@FindBy(xpath = "//div[@class='form-group']//ejs-maskedtextbox")
	private List<WebElement> lbl_placeholder_GuarantorPhNum;

	@FindBy(xpath="//div[@id='three']//app-ipas-document-management-pannel/ejs-accordion/div/div[1]/div[1]/span/div/a")
	private WebElement lbl_DigitalDocMangerHeaderPanel;

	@FindBy(xpath = "//div[@class='formContainer']/div/div")
	private List<WebElement> lst_add_patient_visit;

	@FindBy(xpath="//img[@src='assets/images/more.png']")
	private WebElement btn_threedots_serviceTracker;

	@FindBy(xpath = "(//span[@class='similaraccounttitle']//following::span[1])[2]")
	private WebElement txt_simAccounts;

	@FindBy(xpath = "//td[1]/div[1]/div[1]/div[1]/span")
	private WebElement txt_simAcctNumber;

	//Digital Documents

	@FindBy(xpath="//div[@id='detail-document-table']/div/ejs-listview/div/div[2]/span")
	private List<WebElement> lbl_DigitalDocumentsMangerPage1;

	@FindBy(xpath="//div[@id='detail-document-table']/div/ejs-listview/div/ul/li/div/span")
	private List<WebElement> lbl_DigitalDocumentsMangerPage2;

	@FindBy(xpath="//div[@id='detail-document-table']/div/ejs-listview/div/div[2]/span")
	private WebElement tbl_DDMPage;

	@FindBy(xpath="//table[@class='e-table']//thead/tr/th")
	private WebElement lbl_Headers_AS;

	@FindBy(xpath = "//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_Search;

	@FindBy(xpath="//ul[contains(@class,'p-autocomplete-items')]/li[1]")
	private WebElement li_Search;

	@FindBy(xpath="//div[@class='allData-control-section']/ejs-dashboardlayout/div")
	private WebElement tbl_AllData;

	@FindBy(xpath="//div[@class='breadcrum-container noprint']/span[2]/a")
	private WebElement lnk_breadcrumb_acctNum;

	@FindBy(xpath="//a[contains(text(),'Payment Facilitator')]")
	private WebElement lnk_PaymentFacilitator;

	@FindBy(xpath="//span[text()='Payment Facilitator']/../img[@src='assets/images/success.png']")
	private WebElement icon_PaymentFacilitator_ModStatus;

	@FindBy(xpath ="//td[@class='e-rowcell e-templatecell']//input")
	private WebElement lst_payment_fields;

	@FindBy(xpath ="//div[@class='e-gridcontent']//tr[1]//td[2]/div/a")
	private WebElement lnk_AccountNumber;

	@FindBy(xpath = "(//span[@class='similaraccounttitle'])[2]")
	private WebElement lbl_similarAccountsTitle;

	AddPatientVisitPage addPatientVisit;
	public AddPatientVisitPage() {
		PageFactory.initElements(driver, this);
	}

	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}

	public void navigateToAddPatient() {
		try {
			webActions.waitForPageLoaded();
			webActions.waitUntilisDisplayed(btn_threedots,"Tools button");
			report.reportPass("Wait until Tools option is displayed");
			if(btn_threedots.isDisplayed())
			{
				webActions.click(btn_threedots, "Tools button");
				report.reportPass("Click on Three dots tools button");
				webActions.waitUntilisDisplayed(btn_tools_AddPatient, "Add Patient");
				webActions.click(btn_tools_AddPatient, "Add Patient");
				report.reportPass("Click on Add patient in Tools Menu");
				webActions.waitForPageLoaded();
			}
		} catch (Exception e) {
			report.reportFail("Failed to click on Tools button due to :" +e);
		}
	}

	public void verifyAccountSearchBreadCrumb1() {
		try {
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(breadcrumb_addPatient_acctsearch, "BreadCrumb");	
			if(breadcrumb_addPatient_acctsearch.isDisplayed())
			{
				report.reportPass("Add Patient BreadCrumb displayed Successfully");
			}	
		}

		catch (Exception e) {
			report.reportFail("Failed to display BreadCrumb due to :"+e);
		}
	}

	public void verifyServiceTrackerBreadCrumb() {
		try {
			webActions.waitForVisibility(breadcrumb_addPatient_ServiceTracker, "BreadCrumb");	
			if(breadcrumb_addPatient_ServiceTracker.isDisplayed())
			{
				report.reportPass("Add Patient BreadCrumb displayed Successfully");
			}	
		}

		catch (Exception e) {
			report.reportFail("Failed to display BreadCrumb due to :"+e);
		}
	}

	public void VerifyfieldsPatientVisitInfo(DataTable fieldNames) {
		try {
			List<String> expFields = fieldNames.asList(String.class);
			report.reportInfo("Field Names to be displayed in Patient Info are : "+expFields);
			webActions.waitForVisibility(txt_PatientInformation, "PatientInformation Section");	
			ArrayList<String> actFields=getMandatoryDatafromWebTable(lst_PatientInformation);
			webActions.waitForVisibility(lbl_mandLastName,"fields in Patient Info");
			report.reportInfo("Actual Mandatory fields displayed are : "+actFields);
			ArrayList<String>unmatchedfields=webActions.getUmatchedInArrayComparision(actFields,expFields);
			if(unmatchedfields.size()==0){
				report.reportPass("Verified the fields displayed in Add Patient >> Patient Info successfully");
			}
			else{
				throw new Exception("Fail to verify fields displayed in Add Patient >> Patient Info and mismatched values are: "+unmatchedfields);
			}
		}

		catch (Exception e) {
			report.reportFail("Failed to display the fields in Patient Information in Add Patient due to :"+e);
		}
	}

	public void VerifyfieldsGuarantorInfo(DataTable fieldNames) {
		try {
			List<String> expFields = fieldNames.asList(String.class);
			report.reportInfo("Field Names to be displayed in Patient Info are : "+expFields);
			webActions.waitForVisibility(txt_GuarantorInformation, "Guarantor Information Section");	
			ArrayList<String> actFields=getMandatoryDatafromWebTable(lst_GuarantorInformation);
			report.reportInfo("Actual Mandatory fields displayed are : "+actFields);
			ArrayList<String>unmatchedfields=webActions.getUmatchedInArrayComparision(actFields,expFields);
			if(unmatchedfields.size()==0){
				report.reportPass("Verified the fields displayed in Add Patient >> Guarantor Info successfully");
			}
			else{
				throw new Exception("Fail to verify fields displayed in Add Patient >> Guarantor Info and mismatched values are: "+unmatchedfields);
			}
		}

		catch (Exception e) {
			report.reportFail("Failed to display the fields in Patient Information in Add Patient due to :"+e);
		}
	}

	public void VerifyfieldsInsuranceInfo(DataTable fieldNames) {
		try {
			List<String> expFields = fieldNames.asList(String.class);
			report.reportInfo("Field Names to be displayed in Insurance Info are : "+expFields);
			webActions.waitForVisibility(txt_InsuranceInformation, "Insurance Information Section");	
			ArrayList<String> actFields=getMandatoryDatafromWebTable(lst_InsuranceInformation);
			report.reportInfo("Actual fields in Insurance info are : "+actFields);
			ArrayList<String>unmatchedfields=webActions.getUmatchedInArrayComparision(actFields,expFields);
			if(unmatchedfields.size()==0){
				report.reportPass("Verified the fields displayed in Add Patient >> Insurance Info successfully");
			}
			else{
				throw new Exception("Fail to verify fields displayed in Add Patient >> Insurance Info and mismatched values are: "+unmatchedfields);
			}
		}

		catch (Exception e) {
			report.reportFail("Failed to display the fields in Insurance Information in Add Patient due to :"+e);
		}
	}

	public ArrayList<String> getMandatoryDatafromWebTable(List<WebElement> elements){
		ArrayList<String> data= new ArrayList<String>();
		List<WebElement> allElement = elements;
		for (WebElement we: allElement) { 
			String[] txt=we.getText().split("\\*");
			data.add(txt[0].trim());
		}
		return data;
	}

	public void VerifyMandatoryfieldsPatientInfo(DataTable fieldNames) {

		try {

			webActions.waitForVisibility(txt_PatientInformation, "PatientInformation Section");	
			webActions.click(btn_Submit,"Submit Button");
			report.reportPass("Should click on Submit button -->Clicked on Submit Button Successfully");
			List<String> expMandFields = fieldNames.asList(String.class);
			report.reportInfo("Field Names to be displayed as Mandatory are : "+expMandFields);
			ArrayList<String> actMandFields=getMandatoryDatafromWebTable(lst_mandatory_fields);
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_mandLastName,"Mandatory fields");
			report.reportInfo("Actual Mandatory fields displayed are : "+actMandFields);
			ArrayList<String>unmatchedfields=webActions.getUmatchedInArrayComparision(actMandFields,expMandFields);
			if(unmatchedfields.size()==0){
				report.reportPass("Verified Mandatory fields in Add Patient successfully");
			}
			else{
				throw new Exception("Fail to verify Mandatory fields in Add Patient and mismatched values are: "+unmatchedfields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void VerifyMandatoryValidationMsg() {

		try {

			webActions.waitForVisibility(txt_PatientInformation, "PatientInformation Section");
			List<WebElement> fieldnames=lst_txt_fields.findElements(By.tagName("input"));
			report.reportInfo("size of fields :"+fieldnames.size());
			for(int i=0;i<fieldnames.size();i++)
			{
				webActions.pressTab();
				webActions.waitForPageLoaded();
				report.reportInfo("Should press tab " +i);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyValidationMessageMinimumAndMaximum(String length,String testData,DataTable validationMessages){
		try {
			webActions.waitForVisibility(txt_LastName,"Last Name");
			ArrayList<String> expectdValidationMessages = new ArrayList<>(validationMessages.asList());
			webActions.sendKeys(txt_LastName, testData, "Last Name");
			webActions.sendKeys(txt_FirstName, testData, "First Name");
			if(Integer.parseInt(length)>1)
				webActions.sendKeys(txt_MiddleName, testData, "MiddleName");
			webActions.sendKeys(txt_contEmail,testData, "Contacts Email");
			webActions.sendKeys(txt_GuartLastname, testData, "Guarantor Lastname");
			webActions.sendKeys(txt_GuartFirstname, testData, "Guarantor Firstname");
			webActions.sendKeys(txt_GuartMiddlename, testData, "Guarantor Middlename");
			webActions.sendKeys(txt_GuartEmail,testData, "Guarantor Email");
			webActions.sendKeys(txt_Diagnosis,testData, "Guarantor Email");
			webActions.sendKeys(txt_SubscriberID,testData, "Guarantor Email");
			webActions.pressTab();
			webActions.waitForLoad();
			webActions.waitForVisibility(txt_MandatoryFieldValidationMessage,"MandatoryFieldValidationMessage");
			ArrayList<String> actualValidationMessages=webActions.getDatafromWebTable(lst_MandatoryFieldValidationMessage);
			report.reportInfo("Actual Validation Messages: "+actualValidationMessages);
			report.reportInfo("Expected Validation Messages: "+expectdValidationMessages);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualValidationMessages, expectdValidationMessages);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Validation Messages if enter less than minimum characters length of "+testData+" in First Name, Last Name,MiddleName,Guarantor Lastname,Guarantor Firstname,Guarantor Middlename and Guarantor Email fields in the Add New Patient Visit page");
			}else{
				throw new Exception("Fail to verify the Validation Messages if enter less than minimum characters"+testData+" due to" +unmatch);

			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyValidationMessageNumerics(String length,String testData,DataTable validationMessages){
		try {
			webActions.waitForVisibility(txt_LastName,"Last Name");
			ArrayList<String> expectdValidationMessages = new ArrayList<>(validationMessages.asList());
			webActions.sendKeys(txt_LastName, testData, "Last Name");
			webActions.sendKeys(txt_FirstName, testData, "First Name");
			webActions.sendKeys(txt_MiddleName, testData, "MiddleName");
			webActions.sendKeys(txt_contEmail,testData, "Contacts Email");
			webActions.sendKeys(txt_GuartLastname, testData, "Guarantor Lastname");
			webActions.sendKeys(txt_GuartFirstname, testData, "Guarantor Firstname");
			webActions.sendKeys(txt_GuartMiddlename, testData, "Guarantor Middlename");
			webActions.sendKeys(txt_GuartEmail,testData, "Guarantor Email");
			webActions.sendKeys(txt_Diagnosis,testData, "Dignosis");
			webActions.sendKeys(txt_SubscriberID,testData, "Subscriber ID");
			webActions.pressTab();
			webActions.waitForLoad();
			webActions.waitForVisibility(txt_MandatoryFieldValidationMessage,"MandatoryFieldValidationMessage");
			ArrayList<String> actualValidationMessages=webActions.getDatafromWebTable(lst_MandatoryFieldValidationMessage);
			report.reportInfo("Actual Validation Messages: "+actualValidationMessages);
			report.reportInfo("Expected Validation Messages: "+expectdValidationMessages);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualValidationMessages, expectdValidationMessages);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Validation Messages if Numerics are entered in text fields "+testData+" in First Name, Last Name,MiddleName,Guarantor Lastname,Guarantor Firstname,Guarantor Middlename and Guarantor Email fields in the Add New Patient Visit page");
			}else{
				throw new Exception("Fail to verify the Validation Messages if if Numerics are entered in text fields "+testData+" due to" +unmatch);

			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyValidationMessagePhoneNumbers(String length,String testData,DataTable validationMessages){
		try {
			webActions.waitForVisibility(txt_LastName,"Last Name");
			ArrayList<String> expectdValidationMessages = new ArrayList<>(validationMessages.asList());
			webActions.click(txt_homePhone, "Home Phone");
			webActions.enterValuesfromKeyBoard(txt_homePhone,"333-333", "Home Phone Number");
			webActions.waitForPageLoaded();
			webActions.click(txt_mobPhone, "Mobile Phone");
			webActions.enterValuesfromKeyBoard(txt_mobPhone,"333-333", "Mobile Phone Number");
			webActions.waitForPageLoaded();
			webActions.click(txt_GuartHomePhone, "Guarantor Home Phone Number");
			webActions.enterValuesfromKeyBoard(txt_GuartHomePhone,"333-333", "Guarantor Home Phone Number");
			webActions.waitForPageLoaded();
			webActions.click(txt_GuartMobPhone, "Guarantor Mobile Phone Number");
			webActions.enterValuesfromKeyBoard(txt_GuartMobPhone,"333-333", "Guarantor Mobile Phone Number");
			webActions.waitForPageLoaded();
			webActions.pressTab();
			webActions.waitForLoad();
			webActions.waitForVisibility(txt_MandatoryFieldValidationMessage,"MandatoryFieldValidationMessage");
			ArrayList<String> actualValidationMessages=webActions.getDatafromWebTable(lst_MandatoryFieldValidationMessage);
			report.reportInfo("Actual Validation Messages: "+actualValidationMessages);
			report.reportInfo("Expected Validation Messages: "+expectdValidationMessages);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualValidationMessages, expectdValidationMessages);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Validation Messages if less than 10 digits are entered in phone number fields "+testData+" in Home Phone Number, Mobile Phone Number,Guarantor Home Phone Number,Guarantor Mobile Phone Number ");
			}else{
				throw new Exception("Fail to verify the Validation Messages if less than 10 digits are entered in phone number fields" +unmatch );

			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}




	public void verifyAddPatient(String lastname,String firstname){
		try {
			String messageTitle ="Success!";
			String messageContent="Data saved successfully.";
			StringBuilder unmatch=new StringBuilder();

			webActions.waitForPageLoaded();
			webActions.waitUntilListisDisplayed(lst_add_patient_visit,"Add Patient visit elements");
			if(txt_LastName.isDisplayed())
			{
				webActions.waitForVisibility(txt_LastName,"Last Name");
				webActions.sendKeys(txt_LastName, lastname , "Last Name");
				webActions.sendKeys(txt_FirstName, firstname , "First Name");
				webActions.sendKeys(txt_DOB, "01/01/1987","Date of Birth");
				webActions.sendKeys(txt_Gender, "Female","Gender");
				webActions.pressTab();
				webActions.waitForPageLoaded();
				webActions.click(arrw_location,"Location");
				webActions.sendKeys(drpdwn_location,"Maternal Fetal Medicine","Location");
				webActions.waitForPageLoaded();
				webActions.click(arrw_visitStatus,"Visit Status");
				webActions.sendKeys(drpdwn_visitStatus,"Scheduled","Visit Status");
				webActions.sendKeys(txt_SubscriberID,"TC001010","Subscriber ID");
				report.reportInfo("entered Subscriber ID");
				Thread.sleep(1000);
				try {
					if(btn_Submit.isEnabled())	
					{
						webActions.click(btn_Submit, "Submit Button");
						String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
						String[] titleContent=msg.split("\\n");
						String actTitle=titleContent[0];
						String actContent=titleContent[1];
						report.reportInfo("Actual alert message after user created: "+msg);
						if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent)))
						{
							report.reportPass("Successfully user is created and alert message is matched: "+msg);
						}
						else
						{
							unmatch.append("Alert message is not captured/matched after user is created: "+msg);
						}	
					}
					else
					{
						throw new Exception("Fail to enter all the mandatory fields in Add Patient Visit" );
					}	

				} catch (Exception e) {
					report.reportFail(e.getMessage());
				}
			}
			else
			{
				throw new Exception("Fail to navigate to Add Patient Visit Page" );
			}

		} catch (Exception e1) {
			report.reportFail(e1.getMessage());
		}
	}

	public void verifyAddPatientAllFields(String lastname,String firstname){
		try {
			String messageTitle ="Success!";
			String messageContent="Data saved successfully.";
			webActions.waitForPageLoaded();
			webActions.waitUntilListisDisplayed(lst_add_patient_visit,"Add Patient visit elements");
			webActions.waitForVisibility(txt_LastName,"Last Name");
			webActions.sendKeys(txt_LastName, lastname , "Last Name");
			webActions.sendKeys(txt_FirstName, firstname , "First Name");
			webActions.sendKeys(txt_DOB, "02/10/1990","Date of Birth");
			webActions.sendKeys(txt_Gender, "Female","Gender");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_language, "English","Language");
			webActions.click(txt_homePhone, "Home Phone");
			webActions.enterValuesfromKeyBoard(txt_homePhone,"999-999-9999","Home Phone");
			webActions.waitForPageLoaded();
			webActions.click(txt_mobPhone, "Mobile Phone");
			webActions.enterValuesfromKeyBoard(txt_mobPhone,"999-999-9999","Mobile Phone");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_contEmail, "xyz@gmail.com","Email");
			webActions.sendKeys(txt_GuartFirstname, "GuarantorOne", "Guarantor First Name");
			webActions.sendKeys(txt_GuartLastname, "Guarantor last name", "Guarantor Last Name");
			webActions.sendKeys(txt_GuartDOB, "02/10/1960", "Guarantor Date of Birth");
			webActions.click(txt_GuartHomePhone, "Guarantor Home Phone Number");
			webActions.enterValuesfromKeyBoard(txt_GuartHomePhone,"999-999-9999","Guarantor Home Phone Number");
			webActions.waitForPageLoaded();
			webActions.click(txt_GuartMobPhone, "Guarantor Mobile Phone Number");
			webActions.enterValuesfromKeyBoard(txt_GuartMobPhone,"999-999-9999","Guarantor Mobile Phone Number");
			webActions.click(txt_GuartEmail, "Email");
			webActions.sendKeys(txt_GuartEmail, "xyzad@gmail.com","Guarantor Email");
			webActions.pressTab();
			webActions.click(arrw_location,"Location");
			webActions.sendKeys(drpdwn_location,"Maternal Fetal Medicine","Location");
			webActions.waitForPageLoaded();
			webActions.click(arrw_visitStatus,"Visit Status");
			webActions.sendKeys(drpdwn_visitStatus,"Scheduled","Visit Status");
			webActions.waitForPageLoaded();		
			//webActions.sendKeys(txt_SubscriberID,"ramya","Subscriber ID");
			try {
				if(btn_Submit.isEnabled())
				{
					webActions.click(btn_Submit, "Submit Button");
					String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
					String[] titleContent=msg.split("\\n");
					String actTitle=titleContent[0];
					String actContent=titleContent[1];
					report.reportInfo("Actual alert message after user created: "+msg);
					if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent)))
					{
						report.reportPass("Successfully user is created and alert message is matched: "+msg);
					}
					else
					{
						report.reportFail("Failed to create new user and alert message is not matched: "+msg);
					}
				}	
			} catch (Exception e) {
				report.reportFail(e.getMessage());
			}
		} catch (Exception e1) {
			report.reportFail(e1.getMessage());
		}
	}

	public void addNewPatientManually(DataTable testData,String lastname,String firstname)
	{
		try {
			String messageTitle ="Success!";
			String messageContent="Data saved successfully.";
			StringBuilder unmatch=new StringBuilder();
			String Gender=getDatafromMap(testData,"Gender");
			String DOB=getDatafromMap(testData,"DOB");
			String Language=getDatafromMap(testData,"Language");
			String HomePhone=getDatafromMap(testData,"HomePhone");
			String MobPhone=getDatafromMap(testData,"MobPhone");
			String Email=getDatafromMap(testData,"Email");

			String GuartFirstname=getDatafromMap(testData,"GuarantFirstname");
			String GuartLastname=getDatafromMap(testData,"GuarantLastname");
			String GuartMiddlename=getDatafromMap(testData,"GuarantMiddlename");
			String RelationToPatient=getDatafromMap(testData,"RelationToPatient");
			String GuartDOB=getDatafromMap(testData,"GuarantDOB");
			String GuartEmail=getDatafromMap(testData,"GuartEmail");
			String GuartHomePhone=getDatafromMap(testData,"GuartHomePhone");
			String GuartMobPhone=getDatafromMap(testData,"GuartMobPhone");
			String VisitStatus=getDatafromMap(testData,"VisitStatus");
			String Location=getDatafromMap(testData,"Location");
			String Payer=getDatafromMap(testData,"Payer");
			String Diagnosis=getDatafromMap(testData,"Diagnosis");
			String SubscriberID =getDatafromMap(testData,"SubscriberID");

			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibility(txt_LastName,"Last Name");
			webActions.sendKeys(txt_LastName, lastname , "Last Name");
			webActions.sendKeys(txt_FirstName, firstname , "First Name");
			webActions.click(txt_DOB,"Date of Birth");
			webActions.sendKeys(txt_DOB,DOB,"Date of Birth");
			webActions.sendKeys(txt_Gender,Gender,"Gender");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_language,Language,"Language");
			webActions.click(txt_homePhone, "Home Phone");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.enterValuesfromKeyBoard(txt_homePhone,HomePhone,"Home Phone");
			webActions.click(txt_mobPhone, "Mobile Phone");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.enterValuesfromKeyBoard(txt_mobPhone,MobPhone,"Mobile Phone");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_contEmail,Email,"Email");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_GuartFirstname,GuartFirstname, "Guarantor First Name");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_GuartLastname,GuartLastname, "Guarantor Last Name");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_GuartMiddlename, GuartMiddlename,"GuartMiddlename");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_GuartDOB,GuartDOB, "GuartDOB");
			webActions.sendKeys(drpdwn_relationToPatient,RelationToPatient, "RelationToPatient");
			webActions.click(txt_GuartHomePhone, "Guarantor Home Phone Number");
			webActions.enterValuesfromKeyBoard(txt_GuartHomePhone,GuartHomePhone,"GuartHomePhone");
			webActions.waitForPageLoaded();
			webActions.click(txt_GuartMobPhone, "Guarantor Mobile Phone Number");
			webActions.enterValuesfromKeyBoard(txt_GuartMobPhone,GuartMobPhone,"GuaratMobPhone");
			webActions.click(txt_GuartEmail, "Email");
			webActions.sendKeys(txt_GuartEmail,GuartEmail,"GuarntEmail");
			webActions.click(arrw_location,"Location");
			webActions.sendKeys(drpdwn_location,Location,"Location");
			webActions.waitForPageLoaded();
			webActions.click(arrw_visitStatus,"Visit Status");
			webActions.sendKeys(drpdwn_visitStatus,VisitStatus,"Visit Status");
			webActions.waitForPageLoaded();
			webActions.sendKeys(drpdwn_payer,Payer,"Payer");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_Diagnosis,Diagnosis,"Diagnosis");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_SubscriberID,SubscriberID,"Subscriber ID");

			try {
				if(btn_Submit.isEnabled())
				{
					webActions.click(btn_Submit, "Submit Button");
					try {
						String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
						String[] titleContent=msg.split("\\n");
						String actTitle=titleContent[0];
						String actContent=titleContent[1];
						report.reportInfo("Actual alert message after user created: "+msg);
						if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent)))
						{
							report.reportPass("Successfully user is created and alert message is matched: "+msg);
						}
						else
						{
							unmatch.append("Alert message is not captured/matched after user is created: "+msg);
						}	
					} catch (Exception e) {
						unmatch.append("Alert message is not captured/matched after user is created ");
					}
				}	
				else
				{
					throw new Exception("Fail to enter all the mandatory fields in Add Patient Visit" );
				}	

			} catch (Exception e) {
				report.reportFail(e.getMessage());
			}
		} catch (Exception e1) {
			report.reportFail(e1.getMessage());
		}
	}

	public String verifyNavigationToAllDataPanel(String testData){
		String acctnumber=null;
		try {
			webActions.waitForPageLoaded();
			String xpath1 = "//div[text()=' ";
			String xpath2 = " ']/../a";
			String xpath=xpath1+testData+xpath2;
			WebElement visitcard = driver.findElement(By.xpath(xpath));
			acctnumber=webActions.getText(visitcard, "Account Number").trim();
			webActions.click(visitcard,"click on visit card with patientname :"+testData);
			mainPage.patientVisitMainPageWaiting();
			webActions.waitForPageLoaded();
			webActions.isDisplayed(lnk_AllData,"All Data Panel");
			report.reportPass("Should navigate to All Data Panel from Account Search");

		} catch (Exception e1) {
			report.reportFail(e1.getMessage());
		}
		return acctnumber;
	}


	public void AllDataPanel(String acctNo){
		try {
			webActions.waitForPageLoaded();
			String xpath1 = "//a[text()='";
			String xpath2 = " ']";
			String xpath=xpath1+acctNo+xpath2;
			webActions.waitForPageLoaded();
			Thread.sleep(3000);
			WebElement visitcard = driver.findElement(By.xpath(xpath));
			webActions.click(visitcard,"click on visit card with patientname :"+acctNo);
			webActions.waitForPageLoaded();
			webActions.isDisplayed(lnk_AllData,"All Data Panel");
			report.reportPass("Should navigate to All Data Panel from Account Search");

		} catch (Exception e1) {
			report.reportFail(e1.getMessage());
		}
	}

	public void verifyDefaultValues(){
		try {
			String expDOB="MM/DD/YYYY";
			String expGender="Select Gender";
			String expLang  ="Select Language";
			String expPhysician ="Select Physician";
			String expVisitStatus="Select Visit Status";
			String expPayer="Select Payer";
			String expLocation="Select Location";
			webActions.waitForVisibility(txt_LastName,"Last Name");
			String actDOB=webActions.getAttributeValue(txt_DOB, "placeholder", "DateOfBirth");
			String actGender=webActions.getAttributeValue(txt_Gender,"placeholder", "Gender");
			String actLang  =webActions.getAttributeValue(txt_language,"placeholder","Language");
			String actGuartDOB  =webActions.getAttributeValue(txt_GuartDOB,"placeholder","Gurantor Date of Birth");
			String actPhysician=webActions.getAttributeValue(drpdwn_Physician,"placeholder","Physician");
			String actLocation=webActions.getAttributeValue(drpdwn_location,"placeholder","Location");
			String actVisitStatus=webActions.getAttributeValue(txt_VisitStatus,"placeholder","Visit Status");
			String actPayer=webActions.getAttributeValue(txt_Payer,"placeholder","Payer");

			if(actDOB.contentEquals(expDOB))
			{
				report.reportPass("Placehoder of Date of birth format is as expected "+actDOB);
			}
			else
				report.reportFail("Placehoder of Date of birth format is not as expected "+actDOB);

			if(actGender.contentEquals(expGender))
			{
				report.reportPass("Default value of Gender dropdown is as expected "+actGender);
			}
			else
				report.reportFail("Default value of Gender dropdown is as expected "+actGender);

			if(actLang.contentEquals(expLang))
			{
				report.reportPass("Default value of Language dropdown is as expected "+actLang);
			}
			else
				report.reportFail("Default value of Language dropdown is as expected "+actLang);

			if(actGuartDOB.contentEquals(expDOB))
			{
				report.reportPass("Placeholder value of Guarantor DOB is as expected "+actGuartDOB);
			}
			else
				report.reportFail("Placeholder value of Guarantor DOB is as expected "+actGuartDOB);

			if(actPhysician.contentEquals(expPhysician))
			{
				report.reportPass("Default value of Physician dropdown is as expected "+actPhysician);
			}
			else
				report.reportFail("Default value of Physician dropdown is not as expected "+actPhysician);

			if(actVisitStatus.contentEquals(expVisitStatus))
			{
				report.reportPass("Default value of Visit Status dropdown is as expected "+actVisitStatus);
			}
			else
				report.reportFail("Default value of Visit Status dropdown is not  as expected "+actVisitStatus);

			if(actPayer.contentEquals(expPayer))
			{
				report.reportPass("Default value of Payer dropdown is as expected "+actPayer);
			}
			else
				report.reportFail("Default value of Visit Status dropdown is not as expected "+actPayer);

			if(actLocation.contentEquals(expLocation))
			{
				report.reportPass("Default value of Location dropdown is not as expected "+actLocation);
			}
			else
				report.reportFail("Default value of Location dropdown is not as expected "+actLocation);

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyPlaceholdersforPatientInfo(DataTable placeholders){
		try {
			ArrayList<String> expectdPlaceholders = new ArrayList<>(placeholders.asList());
			webActions.waitForVisibility(txt_LastName,"Last Name");
			webActions.click(btn_Clear, "Clear");
			ArrayList<String> actualPlaceholders =new ArrayList<String>();
			actualPlaceholders.addAll(webActions.getListofAttributeValuesfromWebPage(lbl_placeholder_PatientInformation, "placeholder"));
			report.reportInfo("Actual Placeholders: "+actualPlaceholders);
			report.reportInfo("Expected Placeholders: "+expectdPlaceholders);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualPlaceholders, expectdPlaceholders);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Placeholders for all fields in the Patient Information Section");
			}else{
				throw new Exception("Fail to verify the Placeholders for all fields in the Patient Information Section: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyPlaceholdersforGuarantor(DataTable placeholders){
		try {
			ArrayList<String> expectdPlaceholders = new ArrayList<>(placeholders.asList());
			webActions.waitForVisibility(txt_LastName,"Last Name");
			webActions.click(btn_Clear, "Clear");
			ArrayList<String> actualPlaceholders =new ArrayList<String>();
			actualPlaceholders.add(webActions.getAttributeValue(txt_GuartLastname, "placeholder","Lastname"));
			actualPlaceholders.add(webActions.getAttributeValue(txt_GuartFirstname, "placeholder","Firstname"));
			actualPlaceholders.add(webActions.getAttributeValue(txt_GuartMiddlename, "placeholder","Middlename"));
			actualPlaceholders.add(webActions.getAttributeValue(txt_GuartEmail, "placeholder","Email"));

			actualPlaceholders.addAll(webActions.getListofAttributeValuesfromWebPage(lbl_placeholder_GuarantorPhNum, "placeholder"));
			actualPlaceholders.add(webActions.getAttributeValue(txt_GuartDOB, "placeholder","Guarantor DateOfBirth"));
			report.reportInfo("Actual Placeholders: "+actualPlaceholders);
			report.reportInfo("Expected Placeholders: "+expectdPlaceholders);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualPlaceholders, expectdPlaceholders);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Placeholders for all fields in the Patient Information Section");
			}else{
				throw new Exception("Fail to verify the Placeholders for all fields in the Patient Information Section: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyPlaceholdersforRest(DataTable placeholders){
		try {
			ArrayList<String> expectdPlaceholders = new ArrayList<>(placeholders.asList());
			webActions.waitForVisibility(txt_LastName,"Last Name");
			webActions.click(btn_Clear, "Clear");
			ArrayList<String> actualPlaceholders =new ArrayList<String>();
			actualPlaceholders.add(webActions.getAttributeValue(drpdwn_Physician, "placeholder","Physician"));
			actualPlaceholders.add(webActions.getAttributeValue(drpdwn_location, "placeholder","Location"));
			actualPlaceholders.add(webActions.getAttributeValue(txt_VisitStatus, "placeholder","VisitStatus"));
			actualPlaceholders.add(webActions.getAttributeValue(txt_Diagnosis, "placeholder","Diagnosis"));
			actualPlaceholders.add(webActions.getAttributeValue(txt_Payer, "placeholder","Payer"));
			actualPlaceholders.add(webActions.getAttributeValue(txt_SubscriberID, "placeholder","SubscriberID"));
			report.reportInfo("Actual Placeholders: "+actualPlaceholders);
			report.reportInfo("Expected Placeholders: "+expectdPlaceholders);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualPlaceholders, expectdPlaceholders);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Placeholders for all fields in the Patient Information Section");
			}else{
				throw new Exception("Fail to verify the Placeholders for all fields in the Patient Information Section: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifySimilarAccounts(String length,String length1){
		try {

			int len1=Integer.parseInt(length1); 			
			String testData=rest.randomString(len1);			
			//String messageTitle ="Success!";
			//String messageContent="Data saved successfully.";
			String currentdate=webActions.getSystemCurrentDate();

			webActions.waitForVisibility(txt_LastName,"Last Name");
			webActions.sendKeys(txt_LastName, testData, "Last Name");
			webActions.sendKeys(txt_FirstName, testData, "First Name");
			webActions.sendKeys(txt_DOB, currentdate,"Date of Birth");
			webActions.sendKeys(txt_Gender,"Male","Gender");
			webActions.click(txt_homePhone, "Home Phone");
			webActions.enterValuesfromKeyBoard(txt_homePhone,"999-999-9999","Home Phone");
			webActions.waitForPageLoaded();
			webActions.click(txt_mobPhone, "Mobile Phone");
			webActions.enterValuesfromKeyBoard(txt_mobPhone,"999-999-9999","Mobile Phone");
			webActions.waitForPageLoaded();			
			webActions.sendKeys(drpdwn_relationToPatient,"Self", "RelationToPatient");
			webActions.waitForPageLoaded();		
			webActions.click(arrw_location,"Location");
			webActions.sendKeys(drpdwn_location,"Maternal Fetal Medicine","Location");
			webActions.waitForPageLoaded();
			webActions.click(arrw_visitStatus,"Visit Status");
			webActions.sendKeys(drpdwn_visitStatus,"Scheduled","Visit Status");
			Thread.sleep(2000);

			try {
				if(btn_Submit.isEnabled())
				{
					webActions.click(btn_Submit, "Submit Button");
					webActions.waitForPageLoaded();
					/*String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
					String[] titleContent=msg.split("\\n");
					String actTitle=titleContent[0];
					String actContent=titleContent[1];
					report.reportInfo("Actual alert message after user created: "+msg);*/
					//if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent)))

					//report.reportPass("Successfully user is created and alert message is matched: "+msg);
					//webActions.waitForPageLoaded();
					Thread.sleep(3000);
					logIn.simpleSearch(testData);
					String accountNumber=webActions.getText(lnk_AccountNumber, "Account Number");
					webActions.notepadWrite("hello", accountNumber);
					navigateToAddPatient();
					report.reportPass("Navigated to the Add patient visit Again");
					try {
						String expMessage="We found an existing Patient with similar patient data. Do you want to add a new Account to this Patient record?";
						String expMessageForNewVisit="To add a new Visit to an existing Account select the Patient record first.";
						String expName   =testData+" "+testData;
						webActions.waitForPageLoaded();
						webActions.waitForVisibility(txt_LastName,"Last Name");
						webActions.sendKeys(txt_LastName,testData, "Last Name");
						webActions.sendKeys(txt_FirstName,testData, "First Name");
						webActions.sendKeys(txt_DOB, currentdate,"Date of Birth");
						webActions.sendKeys(txt_Gender,"Male","Gender");
						webActions.pressTab();
						webActions.waitForPageLoaded();
						webActions.waitForVisibility(txt_simAcct,"Similar Account");
						webActions.waitForPageLoaded();
						String actMessage[]=txt_simAcct.getText().trim().split("\n");
						String actualmsg=actMessage[0];
						String actualmsgForNewVisit=actMessage[1];
						report.reportInfo("actual messge :"+actualmsg);
						report.reportInfo("actual messge for New Visit:"+actualmsgForNewVisit);
						report.reportInfo("expected message :"+expMessage);
						report.reportInfo("expected message for New Visit :"+expMessageForNewVisit);

						String actName=txt_simAcctName.getText().trim();
						String actDOB =txt_simAcctDate.getText().trim();	
						report.reportInfo("Actual gender and date of birth: " + actDOB);
						webActions.waitForPageLoaded();
						String dateGender="(M)"+" "+currentdate;
						report.reportInfo("Expected gender and date of birth: " + dateGender);
						report.reportInfo("Actual patient first and last names: " + actName);
						report.reportInfo("Expected patient first and last names: " + expName);
						if(expMessage.contentEquals(actualmsg) && expMessageForNewVisit.contentEquals(actualmsgForNewVisit) )
						{
							report.reportPass("Successfully Similar accounts are displayed");
							if(actName.contentEquals(expName) && actDOB.contentEquals(dateGender))
							{
								report.reportPass("Able to find matched account with the first name,last name, Date of Birth and Gender "+actName+ "and Date of Birth as "+actDOB);

							}
							else
								report.reportFail("Unable to find matched account with the first name,last name and Date of Birth :"+actName+" and Date of Birth as  "+actDOB);
						}
						else
						{
							report.reportFail("Unable to find similar Accounts :"+actMessage);
						}

					} catch (Exception e) {
						report.reportFail("Failed to find similar Accounts due to  :"+e);
						e.printStackTrace();
					}

				}					

			} catch (Exception e) {
				report.reportInfo("Submit button not enabled");
				e.printStackTrace();
			}


		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyCancelButton(String module){
		try
		{
			webActions.waitForVisibility(txt_LastName,"Last Name");
			webActions.click(btn_Cancel,"Cancel");
			if(module.contentEquals("AccountSearch"))
			{
				webActions.isDisplayed(txt_acctSearch,"Account search Module");
				report.reportPass("Navigated back to Account search Module");
			}

			else if(module.contentEquals("ServiceTracker"))
			{
				webActions.isDisplayed(txt_serviceTracker,"service Tracker Module");
				report.reportPass("Navigated back to Service Tracker Module");	
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyPaymentModule(String module){
		try
		{
			webActions.waitForVisibility(txt_LastName,"Last Name");
			webActions.click(btn_Cancel,"Cancel");
			if(module.contentEquals("AccountSearch"))
			{
				webActions.isDisplayed(txt_acctSearch,"Account search Module");
				report.reportPass("Navigated back to Account search Module");
			}

			else if(module.contentEquals("ServiceTracker"))
			{
				webActions.isDisplayed(txt_serviceTracker,"service Tracker Module");
				report.reportPass("Navigated back to Service Tracker Module");	
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}


	public void waitforSubmitButton(){
		try {
			webActions.waitUntilisDisplayed(btn_Submit, "Submit Button");
		} catch (Exception e) {
		}
	}

	public void verifyLabelNamesinDigitalDOcumentsMangerPage(DataTable labels,String Accountnumber) throws Exception{
		try {

			ArrayList<String> expLabelNames = new ArrayList<>(labels.asList());
			ArrayList<String> actualLableNames=new ArrayList<String>();
			webActions.waitAndClick(lbl_DigitalDocMangerHeaderPanel, "DDM Link");
			webActions.waitForVisibility(tbl_DDMPage, "DDMPage");
			actualLableNames.addAll(webActions.getDatafromWebTable(lbl_DigitalDocumentsMangerPage1));
			actualLableNames.addAll(webActions.getDatafromWebTable(lbl_DigitalDocumentsMangerPage2));
			report.reportInfo("Actual Label Names are: "+actualLableNames);
			report.reportInfo("Expected Label Names are: "+expLabelNames);
			ArrayList<String> unmatchData=webActions.getUmatchedInArrayComparision(actualLableNames, expLabelNames);
			if(unmatchData.size()==0){
				report.reportPass("Verified label names in the Digital Documents Manager panel successfully");
			}
			else{
				throw new Exception("Failed to verify the label names in the Digital Documents Manger page and unmatched Labels are: "+unmatchData);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyVisitCardPaymentModule(String AccountNumber) {
		try {
			String ExpectedAccountNumber=AccountNumber;
			webActions.waitAndClick(lnk_PaymentFacilitator, "Payment Facilitator");
			webActions.waitForPageLoaded();	
			Thread.sleep(3000);
			webActions.isDisplayed(icon_PaymentFacilitator_ModStatus,"Payment Facilitator Module with Clearance symbol");
			report.reportPass("Able to Verify the patient visit card in Payment Facilitator Module Successfully");
			String ActualAccountNumber=lnk_breadcrumb_acctNum.getText();
			if(ActualAccountNumber.contentEquals(ExpectedAccountNumber))
			{
				report.reportPass("Able to Verify the patient visit card successfully with Account Number :"+ActualAccountNumber);
			}
			webActions.waitForPageLoaded();
			webActions.click(lnk_breadcrumb_acctNum, "Breadcrumb Account Number");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}



	public void searchAccountNuberinAccountSearchPage(String accountNumber) throws Exception{
		try {
			webActions.waitForVisibility(lbl_Headers_AS, "Account Search Headers");
			webActions.sendKeys(txt_Search, accountNumber, "");
			webActions.waitForClickAbility(li_Search, "");
			webActions.click(li_Search, "");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_Headers_AS,"Account Search Headers");
			driver.findElement(By.partialLinkText(accountNumber)).click();
			webActions.waitForVisibility(tbl_AllData, "All Data Page");
		} catch (Exception e) {
			throw new Exception(e);
		}
	}

	public void verifyNavigationToServiceTrackerPanel(String acctnumber){
		try {
			webActions.waitForPageLoaded();
			String xpath1="//a[contains(text()='";
			String xpath2="']";
			String xpath4=xpath1+acctnumber+xpath2;
			WebElement visitcardbody = driver.findElement(By.xpath(xpath4));
			if(visitcardbody.isDisplayed())
			{
				webActions.click(visitcardbody,"Visit Card with Account Number :"+acctnumber);
				webActions.doubleClick(visitcardbody,"Visit Card with Account Number :"+acctnumber);
				report.reportPass("Should click on Visit Card with Account Number :"+acctnumber);

			}
		} catch (Exception e) {
			report.reportFail("Failed to display visit card due to: " + e,true);
		}
	}




	//Notepad Read

	public String notepadRead(String notepadname) throws IOException
	{
		String filename=System.getProperty("user.dir")+"\\ExternalTestData\\"+notepadname+".txt";
		BufferedReader br = new BufferedReader(new FileReader(filename));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append("\n");
				line = br.readLine();
			}
			return sb.toString();
		} finally {
			br.close();
		}
	}

	//Notepad Write

	public void notepadWrite(String filename,String subjectmessage) 
	{
		try
		{
			String verify, putData;
			String filepath=System.getProperty("user.dir")+"\\ExternalTestData\\"+filename+".txt";
			File file = new File(filepath);
			file.createNewFile();
			FileWriter fw = new FileWriter(file);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(subjectmessage);
			bw.flush();
			bw.close();
			FileReader fr         = new FileReader(file);
			BufferedReader br     = new BufferedReader(fr);
			while( br.readLine() != null )
			{
				verify = br.readLine();
				if(verify != null)
				{
					putData = verify.replaceAll("here", "there");
					bw.write(putData);
				}
			}
			br.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}

	}

	public void verifyGuaratorDetails(String relation, DataTable testData){
		try {

			ArrayList<String> expValues = new ArrayList<String>(testData.row(1));			
			ArrayList<String> actualValues=new ArrayList<String>();

			webActions.waitForPageLoaded();
			webActions.waitUntilListisDisplayed(lst_add_patient_visit,"Add Patient visit elements");		
			webActions.waitForVisibility(txt_LastName,"Last Name");

			webActions.sendKeys(txt_LastName, webActions.getDatafromMap(testData, "LastName"), "LastName");
			webActions.sendKeys(txt_FirstName, webActions.getDatafromMap(testData, "FirstName"), "First Name");
			webActions.sendKeys(txt_MiddleName, webActions.getDatafromMap(testData, "MiddleName"), "MiddleName");
			webActions.sendKeys(txt_DOB, webActions.getDatafromMap(testData, "DOB"),"Date of Birth");
			webActions.sendKeys(txt_Gender, webActions.getDatafromMap(testData, "Gender"),"Gender");
			webActions.pressTab();
			webActions.waitForPageLoaded();
			webActions.click(txt_homePhone, "Home Phone");
			webActions.enterValuesfromKeyBoard(txt_homePhone,webActions.getDatafromMap(testData, "HomePhone"),"Home Phone");
			webActions.waitForPageLoaded();
			webActions.click(txt_mobPhone, "Mobile Phone");
			webActions.enterValuesfromKeyBoard(txt_mobPhone,webActions.getDatafromMap(testData, "MobPhone"),"Mobile Phone");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_contEmail, webActions.getDatafromMap(testData, "Email"),"Email");
			webActions.waitForPageLoaded();
			webActions.sendKeys(drpdwn_relationToPatient,relation, "RelationToPatient");
			webActions.waitForPageLoaded();

			actualValues.add(webActions.getText(txt_GuartLastname, "LastName"));
			actualValues.add(webActions.getText(txt_GuartFirstname, "FirstName"));
			actualValues.add(webActions.getText(txt_GuartMiddlename, "Middle"));
			actualValues.add(webActions.getText(txt_GuartDOB, "DOB"));
			actualValues.add(webActions.getText(txt_GuartHomePhone, "homePhone"));
			actualValues.add(webActions.getText(txt_GuartMobPhone, "MobilePhone"));
			actualValues.add(webActions.getText(txt_GuartEmail, "Email"));

			report.reportInfo("Actual Guarantor values: "+actualValues);
			report.reportInfo("Expected guarantor values: "+expValues);
			ArrayList<String> unmatchData=webActions.getUmatchedInArrayComparision(actualValues, expValues);
			if(unmatchData.size()==0){
				report.reportPass("Verified Populating of guarantor values successfully");
			}
			else{
				throw new Exception("Failed to verify the guarantor values and unmatched values are: "+unmatchData);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifySimilarAccountsForExistingPatient(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(txt_simAcctName, "SimilarPatients");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_similarAccountsTitle, "SimilarAccounts");
			String expMessage="We found an existing account data.";
			String expMessageForAccount="Do you want to Add the Visit to this Account?";
			String expAccount   =webActions.notepadRead("hello");
			webActions.waitForPageLoaded();		
			String actMessage[]=txt_simAccounts.getText().trim().split("\n");
			String actualmsg=actMessage[0];
			String actualmsgForNewVisit=actMessage[1];
			report.reportInfo("actual messge :"+actualmsg);
			report.reportInfo("actual messge for New Visit:"+actualmsgForNewVisit);
			report.reportInfo("expected message :"+expMessage);
			report.reportInfo("expected message for New Visit :"+expMessageForAccount);

			String actAccountNumber=txt_simAcctNumber.getText().trim();		

			report.reportInfo("Actual Account number: " + actAccountNumber);
			report.reportInfo("Expected AccountNumber: " + expAccount);
			if(expMessage.trim().contentEquals(actualmsg.trim()) && expMessageForAccount.trim().contentEquals(actualmsgForNewVisit.trim()) )
			{
				report.reportPass("Successfully Similar accounts are displayed");
				if(actAccountNumber.trim().contentEquals(expAccount.trim()))
				{
					report.reportPass("Successfully verified similar accounts");

				}
				else
					report.reportFail("Fail to verify similar accounts and displayed account number is" +  actAccountNumber);
			}

		} catch (Exception e) {
			report.reportFail("Failed to find similar Accounts due to  :"+e);
			e.printStackTrace();
		}    
	}	
	
	//List to Notepad Write
		public void notepadWrite(String filename,ArrayList<String> appoint) 
		{
			try
			{				
				String filepath=System.getProperty("user.dir")+"\\ExternalTestData\\"+filename+".txt";
				File file = new File(filepath);
				file.createNewFile();
				FileWriter fw = new FileWriter(file);
				BufferedWriter writer = new BufferedWriter(fw);
				for(String str: appoint) {
					  writer.write(str + System.lineSeparator());
					}
			
				writer.flush();
				writer.close();				
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}

		}
		//Notepad Read to List

		public ArrayList<String> notepadReadToList(String notepadname) throws IOException
		{
			ArrayList<String> listOfLines = new ArrayList<>();
			String filename=System.getProperty("user.dir")+"\\ExternalTestData\\"+notepadname+".txt";
			BufferedReader bufReader = new BufferedReader(new FileReader(filename));
			try {
				
				 String line = bufReader.readLine();
				 while (line != null) 
				 {
					 listOfLines.add(line);
					 line = bufReader.readLine(); 
					 } 	 
		
			} finally {
				bufReader.close();
			}
			return listOfLines;
		}
		 

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}