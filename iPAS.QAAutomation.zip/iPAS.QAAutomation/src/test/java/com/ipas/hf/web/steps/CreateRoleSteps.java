package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.CreateRolePage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class CreateRoleSteps {

	CreateRolePage rolePage=new CreateRolePage();

	@Then("Veirfy system role configuration")
	public void veirfy_system_role_configuration(DataTable testData) {
		rolePage.verifyLabelNames(testData);
	}
	@Then("Click on System Role Configuration link")
	public void click_on_System_Role_Configuration_link() {
		rolePage.clickOnSystemRoleLink();
	}

	@Then("Click on Add New Role button")
	public void click_on_Add_New_Role_button() {
		rolePage.clickOnAddNewRole();
	}

	@Then("Verify the dsiplay of labels and buttons")
	public void verify_the_dsiplay_of_labels_and_buttons(DataTable testData) {
		rolePage.verifyFields(testData);
	}
	@Then("Verify the mandatory validation as {string}")
	public void verify_the_mandatory_validation_as(String validation) {
		rolePage.verifyMandatoryField(validation);
	}

	@Then("Verify the Add button modes behavior")
	public void verify_the_Add_button_modes_behavior() {
		rolePage.verifyAddbtnMode();
	}
	@Then("Click on Cance button or Cross option and verify navigation")
	public void click_on_Cance_button_or_Cross_option_and_verify_navigation() {
		rolePage.closeAddNewRolePopUp();
	}
	@Then("Click on Cance button or Cross option and verify navigation after entering the data in role name field")
	public void click_on_Cance_button_or_Cross_option_and_verify_navigation_after_entering_the_data_in_role_name_field() {
		rolePage.closeAddNewRolePopWithOutSaving();
	}	
	@Then("Create New Role")
	public void create_New_Role() {
		rolePage.createNewRole();
	}
	@Then("Verify the created role from system role configuration page")
	public void verify_the_created_role_from_system_role_configuration_page() {
		rolePage.verifyRoleFromSystemRolesView();
	}

	@Then("Verify the display of categories")
	public void verify_the_display_of_categories(DataTable catogeryList) {
		rolePage.verifyCatogeryName(catogeryList);
	}
	@Then("Verify the display of buttons")
	public void verify_the_display_of_buttons() {
		rolePage.verifySystemConfigPageButtons();
	}

	@Then("Create New Role with already created role name")
	public void create_New_Role_with_already_created_role_name() {
		rolePage.verifyDuplicateRole();
	}
	@Then("Click on cancel button")
	public void click_on_cancel_button() {
		rolePage.clickOnCancel();
	}
	@Then("Click on Account search header check box")
	public void click_on_Account_search_header_check_box() {
		rolePage.clickOnAccountSearchHeaderCheckBox();
	}
	@Then("Verify the display of title and content of the Unsaved popUp")
	public void verify_the_display_of_title_and_content_of_the_Unsaved_popUp(DataTable testData) {
		rolePage.verifyUnSavedPopUp(testData);
	}
	@Then("Click on Discrad from PopUp")
	public void click_on_Discrad_from_PopUp() {
		rolePage.clickOnDiscardFromPopUp();
	}
	@Then("Click on cross option from PopUp and verify page")
	public void click_on_cross_option_from_PopUp_and_verify_page() {
		rolePage.clickOnCrossAndVerify();
	}

	@Then("Click on Save from Unsaved popup and verify the changes from view system configuration")
	public void click_on_Save_from_Unsaved_popup_and_verify_the_changes_from_view_system_configuration() {
		rolePage.clickOnSaveAndVerify();
	}
	@Then("Verify the sorting order of system roles")
	public void verify_the_sorting_order_of_system_roles() {
		rolePage.verifyRolesOrder();
	}
	@Then("Open the created role from system role configuration page")
	public void open_the_created_role_from_system_role_configuration_page() {
		rolePage.editRoleFromSystemRolesView();
	}
	@Then("Verify the title and fileds")
	public void verify_the_title_and_fileds(DataTable testData) {
		rolePage.verifyEditRoleFields(testData);
	}
	@Then("Delete the created Role from System role view configuration")
	public void delete_the_created_Role_from_System_role_view_configuration() {
		rolePage.deleteRoleFromSystemRolesView();
	}
	@Then("Verify the name displayed from role name field")
	public void verify_the_name_displayed_from_role_name_field() {
		rolePage.verifyPopulatedRoleName();
	}
	@Then("Clear the name from role name field and verify")
	public void clear_the_name_from_role_name_field_and_verify() {
		rolePage.clearAndVerifyRoleName();
	}
	@Then("Verify the default button mode for update")
	public void verify_the_default_button_mode_for_update() {
		rolePage.verifyUpdatebtnMode();
	}
	@Then("Click on cancel and verify the navigation")
	public void click_on_cancel_and_verify_the_navigation() {
		rolePage.verifyNavigation();
	}	
	@Then("Update the role name as {string} and verify from view system role")
	public void update_the_role_name_as_and_verify_from_view_system_role(String roleName) {
		rolePage.updateRoleName(roleName);
	}
	@Then("Verify the deleted role from System role view configuration")
	public void verify_the_deleted_role_from_System_role_view_configuration() {
		rolePage.verifyDeletedRoleFromSystemRolesView();
	}
}
