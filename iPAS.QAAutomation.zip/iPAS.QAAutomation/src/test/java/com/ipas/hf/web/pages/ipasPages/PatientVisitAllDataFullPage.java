package com.ipas.hf.web.pages.ipasPages;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class PatientVisitAllDataFullPage extends BasePage{
	Login logIn=new Login();
	private RestActions rest = new RestActions();
	PatientVisitSummaryAllDataPanelPage summaryPage=new PatientVisitSummaryAllDataPanelPage();
	private JSONObject jsonObject;
	private static final String SIUJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\SIUEventBasedData.json";
	private static final String ADTJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\ADTEventBasedData.json";

	@FindBy(xpath = "//a[contains(text(),'All Data')]")
	private WebElement lbl_AllDataPanelTitle;

	@FindBy(xpath = "//span[@class='ng-star-inserted']/a")
	private WebElement lnk_BreadcrumbName;

	@FindBy(xpath="//span[@class='breadcrum-active ng-star-inserted']")
	private WebElement lbl_AccountNumber;

	@FindBy(xpath="//a[@class='breadcrum']")
	private WebElement lbl_Breadcrum_Service;

	@FindBy(xpath="//span[@class='breadcrum-active']")
	private WebElement lbl_Breadcrum_ServiceVisitNumber;

	@FindBy(xpath="//div[@class='breadcrum-container']/span")
	private List<WebElement> lbl_AllDataFullPage;

	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[1]")
	private List<WebElement> lbl_VisitSummaryFields;

	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[2]")
	private List<WebElement> lbl_VisitSummaryData;

	@FindBy(xpath="//div[@id='fullPageAllData-control-section']")
	private WebElement lbl_AllPanelsData;

	@FindBy(xpath="//div[@id='three']//app-ipas-document-management-pannel/ejs-accordion/div/div[2]/div/div/ul/li/div[1]")
	private WebElement lbl_AllDataPanelsData;

	@FindBy(xpath="//div[@class='pasentNameContainer ng-star-inserted']")
	private WebElement lbl_AllDataPatientName; 

	@FindBy(xpath="//div[@class='e-acrdn-header-content']/span")
	private List<WebElement> lbl_AllDataPanels;

	@FindBy(xpath="//table/tr/td[1]/ejs-accordion[1]/div[1]/div[1]/div[2]/span[1]")
	private WebElement icon_PatientPanelExpandCollapse;

	@FindBy(xpath="//table/tr/td[1]/ejs-accordion[2]/div[1]/div[1]/div[2]/span[1]")
	private WebElement icon_VisitPanelExpandCollapse;

	@FindBy(xpath="//table/tr/td[1]/ejs-accordion[3]/div[1]/div[1]/div[2]/span[1]")
	private WebElement icon_GuarantorPanelExpandCollapse;

	@FindBy(xpath="//table/tr/td[2]/ejs-accordion[1]/div[1]/div[1]/div[2]/span[1]")
	private WebElement icon_InsurancePanelExpandCollapse;

	@FindBy(xpath="//table/tr/td[2]/ejs-accordion[2]/div[1]/div[1]/div[2]/span[1]")
	private WebElement icon_PatientContactPanelExpandCollapse;

	@FindBy(xpath="//table[1]/tr[1]/td[1]/ejs-accordion[1]/div/div[2]/div/div/table[1]/tr[2]/td[1]/span")
	private WebElement lbl_PatientMRNValue;

	@FindBy(xpath="//table[1]/tr[1]/td[1]/ejs-accordion[1]/div/div[2]/div/div/table[1]/tr[2]/td[2]/span")
	private WebElement lbl_PatientSSNValue;

	@FindBy(xpath="//table[1]/tr[1]/td[1]/ejs-accordion[2]/div/div[2]/div/div/table[6]/tr[2]/td[2]/span")
	private WebElement lbl_VisitDiagnosisValue;

	@FindBy(xpath="//table[1]/tr[1]/td[1]/ejs-accordion[3]/div/div[2]/div/div/table[1]/tr[2]/td[3]/span")
	private WebElement lbl_GuarantorSpouseValue; 

	@FindBy(xpath="//table[1]/tr[1]/td[2]/ejs-accordion[1]/div/div[2]/div/div/table[2]/tr[2]/td[4]/span")
	private WebElement lbl_PrimaryIsurancePolicyNumber; 

	@FindBy(xpath="//table[1]/tr[1]/td[2]/ejs-accordion[2]/div/div[2]/div/div/div[1]/span")
	private WebElement lbl_PatinetContactName;

	@FindBy(xpath="//ejs-accordion/div[1]/div[2]/div/div/ul/li/div[2]")
	private WebElement lbl_DataInAllDataPanel;

	@FindBy(xpath="//div[@class='panel-containArea']/ul/li")
	private WebElement lbl_DataInAllDataPanel_ServiceTracker;

	public PatientVisitAllDataFullPage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyAllDataPanelTitle(String PanelTitle) {
		try {
			String ActualTitle = webActions.getText(lbl_AllDataPanelTitle, "Panel Title");
			if (ActualTitle.contentEquals(PanelTitle)){
				report.reportPass("Verified All Data Panel title successfully");
				report.reportInfo("Actual Panel title: "+ActualTitle);
			}
			else{
				throw new Exception("Actual Columns title did not match with Expected and Actual title is: "+ActualTitle);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());

		}

	}

	public void clickOnAllDataLink(){
		try {
			webActions.waitForVisibility(lbl_DataInAllDataPanel, "AllData");
			webActions.click(lbl_AllDataPanelTitle, "AllData");
			webActions.waitUntilisDisplayed(lbl_AllPanelsData, "AllPanels");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_VisitSummaryData, "VisitSummary");
			report.reportInfo("Clicked on All Data link");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyDisplayedBreadcrumbFollowedbyAllData(String visitId,String pageName,String menuName) throws Exception{
		String accountNumber = logIn.getVisitIdFromResponse(visitId);
		ArrayList<String> expectedBreadcrumbTitles=new ArrayList<String>();
		expectedBreadcrumbTitles.add(pageName);
		expectedBreadcrumbTitles.add(accountNumber);
		expectedBreadcrumbTitles.add(menuName);
		report.reportInfo("Expected Breadcrumb Titles "+expectedBreadcrumbTitles);
		ArrayList<String> actualBreadcrumbTitles = new ArrayList<String>();

		if ("Account Search".contentEquals(pageName)) {
			logIn.simpleSearch(accountNumber);
			summaryPage.clickOnAccountLinkNumber();
			clickOnAllDataLink();
			actualBreadcrumbTitles = webActions.getDatafromWebTable(lbl_AllDataFullPage);
		}else if("Service Tracker".contentEquals(pageName)){
			summaryPage.searchAccountNumberinServiceTracker(accountNumber);			
			webActions.waitForVisibility(lbl_DataInAllDataPanel_ServiceTracker, "AllData");
			webActions.click(lbl_AllDataPanelTitle, "AllData");
			webActions.waitUntilisDisplayed(lbl_AllPanelsData, "AllPanels");
			actualBreadcrumbTitles = webActions.getDatafromWebTable(lbl_AllDataFullPage);
		}
		report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumbTitles);
		ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles, expectedBreadcrumbTitles);
		if(unmatch.size()==0){
			report.reportPass("AllData Page Breadcrumb Titles verified successfully, when user navigate from: "+pageName);
		}else{
			report.reportFail("Failed to verify the AllData Page Breadcrumb Titles, when user navigate from: "+pageName+" : and unmatched data: "+unmatch);
		}
	}

	/** To Verify the visit summary labels on All Data Full Page**/
	public void verifyVisitSUmmaryFields(DataTable summaryfields){
		try {
			ArrayList<String> expectedSummaryInfoFields = new ArrayList<>(summaryfields.asList());
			report.reportInfo("Expected Summary Info Fields: "+expectedSummaryInfoFields);
			webActions.waitUntilisDisplayed(lbl_AllPanelsData, "AllPanels");
			ArrayList<String> actualSummaryInfoFields=webActions.getDatafromWebTable(lbl_VisitSummaryFields);
			report.reportInfo("Displayed Summary Fields in Application: "+actualSummaryInfoFields);
			ArrayList<String>unmatchedSummarFields=webActions.getUmatchedInArrayComparision(actualSummaryInfoFields, expectedSummaryInfoFields);
			if(unmatchedSummarFields.size()==0){
				report.reportPass("Verified visit summary Info fields from All Data Full page");
			}
			else{
				throw new Exception("Fail to verify visit summary Info fields from All Data Full page and unmatched fields are: "+unmatchedSummarFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	/** To Verify the visit summary data on All Data Full Page**/
	public void verifyVisitSummaryInfo(String scenarioName){
		try {
			ArrayList<String> expSummaryInfoFields=summaryPage.getSummaryInfoDataFromJSONFile(scenarioName);			
			report.reportInfo("Expected Summary Info Fields data: "+expSummaryInfoFields);
			webActions.waitForVisibility(lbl_AllPanelsData, "AllPanels");			
			ArrayList<String> actualSummaryInfoFields=webActions.getDatafromWebTable(lbl_VisitSummaryData);
			report.reportInfo("Displayed Summary Fields data in Application: "+actualSummaryInfoFields);
			ArrayList<String>unmatchedSummarFields=webActions.getUmatchedInArrayComparision(actualSummaryInfoFields, expSummaryInfoFields);
			if(unmatchedSummarFields.size()==0){
				report.reportPass("Verified visit summary Info from All Data Full page");
			}
			else{
				throw new Exception("Fail to verify visit summary Info from All Data Full page and unmatched data is: "+unmatchedSummarFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	public void verifyPatientName(String data){
		try {
			String expPatientName=getdataFromJSON(data);
			webActions.waitForVisibility(lbl_AllDataPatientName, "PatientName");
			String actualPatientName = webActions.getText(lbl_AllDataPatientName, "PatientName");
			actualPatientName=actualPatientName.replace("\n"," ");			
			if (actualPatientName.contentEquals(expPatientName)){
				report.reportPass("Verified patient name in All Data page successfully");
				report.reportInfo("Actual Patient Name: "+actualPatientName);
			}
			else{
				throw new Exception("Actual Patient Name did not match with Expected and Actual Name is: "+actualPatientName);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public String getdataFromJSON(String data){
		String expectedResponseValue=null;
		try {
			FileReader reader = new FileReader(ADTJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");

			switch(data){
			case "patientName":
				String firstName=(String) patientObject.get("PatientFirstName");
				String lastName=(String) patientObject.get("PatientLastName");
				expectedResponseValue=firstName+" "+lastName;
				break;
			}
		} catch (Exception e) {

		}
		return expectedResponseValue;
	}

	/** To Verify the display of panels on All Data Full Page**/
	public void verifyPanelsTitle(DataTable panelsTitle){
		try {
			ArrayList<String> expectedPanelsTitle = new ArrayList<>(panelsTitle.asList());
			report.reportInfo("Expected PanelsTitle: "+expectedPanelsTitle);
			webActions.waitUntilisDisplayed(lbl_AllPanelsData, "AllPanels");
			ArrayList<String> actualPanelsTitles=webActions.getDatafromWebTable(lbl_AllDataPanels);
			report.reportInfo("Displayed Panels: "+actualPanelsTitles);
			ArrayList<String>unmatchedPanles=webActions.getUmatchedInArrayComparision(actualPanelsTitles, expectedPanelsTitle);
			if(unmatchedPanles.size()==0){
				report.reportPass("Verified panels title from All Data Full page");
			}
			else{
				throw new Exception("Fail to verify panels title from All Data Full page and unmatched panel titles are: "+unmatchedPanles);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}
	/** To verify the all panels expand and collapse mode in full page**/
	public void verifyExpandandCollapseOfthePanel(String panelName) throws Exception{
		StringBuilder unmatch=new StringBuilder();
		String actualExpandStatus="";
		String actualCollapseStatus="";
		try{
			webActions.waitForVisibility(lbl_AllPanelsData, "AllPanels");
			if("Patient Information Panel".contentEquals(panelName)){							
				actualExpandStatus=webActions.getAttributeValue(icon_PatientPanelExpandCollapse, "class", "ExpandandCollapse");			
			}
			else if("Visit Form & Service Information".contentEquals(panelName)){						
				actualExpandStatus=webActions.getAttributeValue(icon_VisitPanelExpandCollapse, "class", "ExpandandCollapse");
			}
			else if("Guarantor Information".contentEquals(panelName)){							
				actualExpandStatus=webActions.getAttributeValue(icon_GuarantorPanelExpandCollapse, "class", "ExpandandCollapse");			
			}
			else if("Insurance Information".contentEquals(panelName)){							
				actualExpandStatus=webActions.getAttributeValue(icon_InsurancePanelExpandCollapse, "class", "ExpandandCollapse");
			}
			else if("Patient Contact Information".contentEquals(panelName)){						
				actualExpandStatus=webActions.getAttributeValue(icon_PatientContactPanelExpandCollapse, "class", "ExpandandCollapse");
			}

			if("e-tgl-collapse-icon e-icons e-expand-icon".contentEquals(actualExpandStatus)){
				report.reportPass("By default " + panelName + " Panel is displayed in Expand mode");
			}else{
				unmatch.append(panelName + " Panel is not dispalyed in Expand mode by default");
				report.reportFail(panelName + " Panel is not dispalyed in Expand mode by default");
			}

			if("Patient Information Panel".contentEquals(panelName)){
				webActions.waitAndClick(icon_PatientPanelExpandCollapse, "ExpandandCollapse");
				webActions.waitForPageLoaded();
				actualCollapseStatus=webActions.getAttributeValue(icon_PatientPanelExpandCollapse, "class", "ExpandandCollapse");
			}
			else if("Visit Form & Service Information".contentEquals(panelName)){			
				webActions.waitAndClick(icon_VisitPanelExpandCollapse, "ExpandandCollapse");
				webActions.waitForPageLoaded();
				actualCollapseStatus=webActions.getAttributeValue(icon_VisitPanelExpandCollapse, "class", "ExpandandCollapse");
			}
			else if("Guarantor Information".contentEquals(panelName)){
				webActions.waitAndClick(icon_GuarantorPanelExpandCollapse, "ExpandandCollapse");
				webActions.waitForPageLoaded();
				actualCollapseStatus=webActions.getAttributeValue(icon_GuarantorPanelExpandCollapse, "class", "ExpandandCollapse");
			}
			else if("Insurance Information".contentEquals(panelName)){
				webActions.waitAndClick(icon_InsurancePanelExpandCollapse, "ExpandandCollapse");
				webActions.waitForPageLoaded();
				actualCollapseStatus=webActions.getAttributeValue(icon_InsurancePanelExpandCollapse, "class", "ExpandandCollapse");
			}
			else if("Patient Contact Information".contentEquals(panelName)){
				webActions.waitAndClick(icon_PatientContactPanelExpandCollapse, "ExpandandCollapse");
				webActions.waitForPageLoaded();
				actualCollapseStatus=webActions.getAttributeValue(icon_PatientContactPanelExpandCollapse, "class", "ExpandandCollapse");
			}

			if("e-tgl-collapse-icon e-icons".contentEquals(actualCollapseStatus)){
				report.reportPass(panelName + " Panel Successfully Collapsed");
			}
			else{
				unmatch.append(panelName + " Panel is not Collapsed");
				report.reportFail(panelName + " Panel is not Collapsed");
			}

			if(unmatch.length()==0){
				report.reportPass(panelName + " Successfully Expanded and Collapsed");
			}else{
				report.reportFail("Failed to verify the Expand and Collapse of the" + panelName + unmatch);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}

	}

	public void verifyFullPagePanelValues(String responseValue,String panelName){
		String expectedValue="";
		String ActualValue="";
		try {
			webActions.waitForVisibility(lbl_AllPanelsData, "AllPanels");
			if("Patient Information Panel".contentEquals(panelName)){
				expectedValue=rest.getValueFromResponseandCompWithExpected(responseValue);			
				ActualValue = webActions.getText(lbl_PatientMRNValue, "MRN");			
			}
			else if("Visit Information Panel".contentEquals(panelName)){
				expectedValue=getValuefromJSONresponseBasedOnObject(responseValue);			
				ActualValue = webActions.getText(lbl_VisitDiagnosisValue, "Diagnosis");		
			}
			else if("Gurantor Information Panel".contentEquals(panelName)){
				expectedValue=getValuefromJSONresponseBasedOnObject(responseValue);			
				ActualValue = webActions.getText(lbl_GuarantorSpouseValue, "Guarantor");		
			}
			else if("Insurance Information Panel".contentEquals(panelName)){
				expectedValue=getValuefromJSONresponseBasedOnObject(responseValue);			
				ActualValue = webActions.getText(lbl_PrimaryIsurancePolicyNumber, "PrimaryPolicy");		
			}			
			else if("Patient Contact Information Panel".contentEquals(panelName)){
				expectedValue=getValuefromJSONresponseBasedOnObject(responseValue);			
				ActualValue = webActions.getText(lbl_PatinetContactName, "PatientContactName");				
			}
			if (ActualValue.contentEquals(expectedValue)){
				report.reportPass(" Verified " + responseValue + " value successfully from " + panelName + "Panel");
				report.reportInfo(" Actual " + responseValue + " value: "+ ActualValue);
				report.reportInfo(" expectedValue " + responseValue + " value: "+ expectedValue);
			}
			else{
				report.reportFail("Actual" + responseValue + "value did not match with Expected value " + expectedValue + " and Actual value is: "+ ActualValue);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	public String getValuefromJSONresponseBasedOnObject(String fieldName){
		String expectedResponseValue=null;
		try {

			FileReader reader = new FileReader(ADTJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");		
			JSONArray patientContactObject = (JSONArray) jsonObject.get("PatientContact");

			if(fieldName.contentEquals("Diagnosis")){							
				JSONArray diag = (JSONArray) jsonObject.get("Diagnosis");							
				JSONObject diagnosis=(JSONObject) diag.get(0);
				JSONObject diagnosisDescription=(JSONObject)diagnosis.get("DiagnosisDescription");
				expectedResponseValue=(String) diagnosisDescription.get("DiagnosisCode");							
			}
			else if (fieldName.contentEquals("Guarantor")){
				JSONArray garan = (JSONArray) jsonObject.get("Guarantor");
				JSONObject garantor=(JSONObject) garan.get(0);
				String firstName=(String) garantor.get("GuarantorSpouseFirstName");
				String lasstName=(String) garantor.get("GuarantorSpouseLastName");
				expectedResponseValue=firstName+" "+lasstName;
			}
			else if((fieldName.contentEquals("Primary Insurance"))||(fieldName.contentEquals("Secondary Insurance"))||(fieldName.contentEquals("Tertiary Insurance"))){
				JSONArray insu=(JSONArray) jsonObject.get("Insurance");
				JSONObject insurance = null;
				if(fieldName.contentEquals("Primary Insurance")){
					insurance = (JSONObject)insu.get(0);
				}
				else if(fieldName.contentEquals("Secondary Insurance")){
					insurance = (JSONObject)insu.get(1);
				}
				else{
					insurance = (JSONObject)insu.get(2);
				}
				expectedResponseValue=(String) insurance.get("InsurancePolicyNumber");				

			}
			else if (fieldName.contentEquals("Patient Contact")){

				JSONObject patientContact = (JSONObject) patientContactObject.get(0);			
				JSONObject ContactType = (JSONObject) patientContact.get("ContactType");

				String firstName= (String) patientContact.get("ContactFirstName");
				String lasstName= (String) patientContact.get("ContactLastName");
				String contactDescription=(String) ContactType.get("ContactDescription");				
				expectedResponseValue=lasstName +"  "+'('+contactDescription+')';
			}
		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return expectedResponseValue;

	}	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
