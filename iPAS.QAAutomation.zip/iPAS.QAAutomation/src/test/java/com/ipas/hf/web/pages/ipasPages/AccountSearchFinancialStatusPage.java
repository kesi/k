package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class AccountSearchFinancialStatusPage extends BasePage {
	SpecialAssistancePage special=new SpecialAssistancePage();

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr/td/span/financial-clearance-status/img")
	private WebElement lbl_AccountFinance;

	//@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr/td[9]/div/div/financial-clearance-status/img")
	//private WebElement lbl_DigitalStatusInNeedsAtten; 

	@FindBy(xpath = "(//table[@id='asgrid_content_table']/tbody/tr/td[9]/div/div/financial-clearance-status/img)[1]")
	private WebElement lbl_DigitalStatusInNeedsAtten; 

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr/td[9]/div/div/span/a")
	private WebElement lbl_ModuleLinkInNeedsAtten;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr/td[10]/div/a")
	private WebElement lbl_AllModuleWindowOption;

	@FindBy(xpath = "//h5[@id='allsectionsModalLabel']")
	private WebElement lbl_AllModuleWindowTitle;

	@FindBy(xpath = "//div/ul/li[2]/div//financial-clearance-status/img")
	private WebElement lbl_DigitalStatusInAllModuleWindow;	

	@FindBy(xpath = "//div/ul/li[3]/div//financial-clearance-status/img")
	private WebElement lbl_EligibilityStatusInAllModuleWindow;

	@FindBy(xpath = "//div/ul/li[5]/div//financial-clearance-status/img")
	private WebElement lbl_IdentityStatusInAllModuleWindow;		

	@FindBy(xpath = "//div/ul/li[6]/div//financial-clearance-status/img")
	private WebElement 	lbl_MedicalStatusInAllModuleWindow;

	@FindBy(xpath = "//div/ul/li[7]/div//financial-clearance-status/img")
	private WebElement 	lbl_EstimatorInAllModuleWindow;	

	@FindBy(xpath = "//div/ul/li[8]/div//financial-clearance-status/img")
	private WebElement lbl_PaymentStatusInAllModuleWindow;

	@FindBy(xpath = "//div/ul/li[9]/div//financial-clearance-status/img")
	private WebElement lbl_PostalStatusInAllModuleWindow;

	@FindBy(xpath = "//div/ul/li[11]/div//financial-clearance-status/img")
	private WebElement lbl_ServiceStatusInAllModuleWindow;


	@FindBy(xpath = "//div[@id='detail-document-table']/div/ejs-listview/div/ul/li/div")
	private WebElement tbl_DDMPage ; 

	@FindBy(xpath = "//ejs-listview[@id='document-list']/div/ul/li/div/ejs-checkbox/label")
	private List<WebElement> chk_DocumentsList;

	@FindBy(xpath = "//*[@id='document-list']//ul/li")
	private List<WebElement> chk_DocumentsList1;

	@FindBy(xpath="//button[text()='Change Status']")
	private WebElement btn_ChangeStatus;

	@FindBy(xpath="//select[@id='status']")
	private WebElement dd_Status;

	@FindBy(xpath="//button[@class='btn btn-light btn-xs'][(text()='Change Status')]")
	private WebElement btn_ChangeStatus_Popup;

	@FindBy(xpath="//ejs-listview[@id='document-list']")
	private WebElement lbl_DocumentList;

	@FindBy(xpath="//div[@id='allDataPasentDetails']/div/financial-clearance-status/img")
	private WebElement lbl_SummaryFinance;

	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[2]")
	private WebElement lbl_VisitSummaryData;

	@FindBy(xpath="//ejs-listview[@id='form-list']//ul/li/div/ejs-checkbox/label")
	private List<WebElement> chk_FormList;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody/tr/td")
	private WebElement lbl_GridRecords; 

	@FindBy(xpath = "//div[@class='breadcrum-container noprint']/span[1]/a")
	private WebElement lbl_AccountLink;

	@FindBy(xpath = "//div[@class='breadcrum-container noprint']/span[2]/a")
	private WebElement lbl_AccountNumberLink; 

	@FindBy(xpath = "//div[@class='panel-title']/a[contains(text(),'Service Tracker')]")
	private WebElement lbl_ServiceLinkInPanel; 

	@FindBy(xpath = "//a[contains(text(),'Payment Facilitator')]")
	private WebElement lbl_PaymentLinkInAllModule; 

	@FindBy(xpath = "//div[@class='page-css']/div")
	private WebElement lbl_ServiceTrackerPageStatus;

	@FindBy(xpath = "//div[@class='page-css']/span/img")
	private WebElement lbl_ServiceTrackerPageStatusImg; 

	@FindBy(xpath = "//div[@class='st modal-content']")
	private WebElement lbl_ServiceTrackerPageStatusImgPriority;

	@FindBy(xpath = "//span[contains(text(),'High Priority')]")
	private WebElement lbl_ServiceTrackerPageStatusPriority;

	@FindBy(xpath = "//ejs-checkbox/label/span[@class='e-icons e-frame']")
	private WebElement lbl_ServiceTrackerPageStatusPriorityChkBox; 

	@FindBy(xpath = "//ejs-checkbox/label/span[@class='e-icons e-frame e-check']")
	private WebElement lbl_ServiceTrackerPageStatusPriorityUnChkBox;

	@FindBy(xpath = "//button[contains(text(),'Submit')]")
	private WebElement lbl_ServiceTrackerPageStatusSubmitbtn;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;

	@FindBy(xpath = "//div[@class='st modal-header']/button[@class='close']")
	private WebElement btn_ServiceTrackerPageStatusClose;  

	@FindBy(xpath = "//div[@class='table-wrapper']/div")
	private WebElement lbl_PaymentsWindow;

	@FindBy(xpath = "//ejs-dropdownlist[@id='payment-type-dropdown']/span/input")
	private WebElement ddl_PaymentType;

	@FindBy(xpath = "//table[@id='discount-grid_content_table']/tbody/tr/td[3]/ejs-numerictextbox/span/input")
	private WebElement txt_TotalAmount;

	@FindBy(xpath = "//ejs-dropdownlist[contains(@id,'ej2_dropdownlist')]/span")
	private WebElement ddl_Discount; 

	@FindBy(xpath = "//button[(text()='Calculate')]")
	private WebElement btn_Calculate; 

	@FindBy(xpath = "//button[(text()='Save')]")
	private WebElement btn_Save;

	@FindBy(xpath="//div[@id='three']//app-ipas-document-management-pannel/div/ejs-accordion/div/div[2]/div/div/ul/li/div[2]")
	private WebElement lbl_DigitalDocMangerPanelDocs; 

	@FindBy(xpath="//a[contains(text(),'Digital Documents Manager')]")
	private WebElement lbl_DigitalDocLink;

	@FindBy(xpath="//div[@class='st modal-body']/div/div[1]/financial-clearance-status/img")
	private WebElement lbl_ServiceTrackerWindowFinance;

	@FindBy(xpath = "//div[@class='modal-content modal-lg']/div[1]/a/span")
	private WebElement lbl_AllModuleWindowClose;

	@FindBy(xpath = "//table[@id='discount-grid_content_table']/tbody/tr/td/div")
	private WebElement lbl_AmountFields;

	@FindBy(xpath = "//table[@id='discount-grid_content_table']/tbody/tr/td/ejs-dropdownlist")
	private List<WebElement> tbl_CurrentVisitDropdownlist;

	@FindBy(xpath="//table[@class='e-table']//thead/tr")
	private WebElement lbl_Headers;
	@FindBy(xpath ="//div[@class='e-gridcontent']//tr[1]//td[2]/div/a")
	private WebElement lnk_AccountNumber;
	@FindBy(xpath="//ejs-accordion/div[1]/div[2]/div/div/ul/li/div[2]")
	private WebElement lbl_DataInAllDataPanel;

	@FindBy(xpath = "//div[@class='modal-body row']/div/ul/li[1]/div/financial-clearance-status/img")
	private WebElement lbl_ManualPatientDigitalStatusInAllModuleWindow;

	@FindBy(xpath = "//div[@class='modal-body row']/div/ul/li[3]/div/financial-clearance-status/img")
	private WebElement lbl_ManualPatientServiceStatusInAllModuleWindow;

	@FindBy(xpath = "//div[@class='modal-body row']/div/ul/li[4]/div/financial-clearance-status/img")
	private WebElement lbl_ManualPatientPaymentStatusInAllModuleWindow;

	@FindBy(xpath = "//div[@class='modal-body row']/div/ul/li[2]/div/financial-clearance-status/img")
	private WebElement lbl_ManualPatientEligibilityStatusInAllModuleWindow;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr/td[9]/div/div")
	private List<WebElement> li_AllModules;

	@FindBy(xpath="//div[@id='three']//app-ipas-document-management-pannel/div/ejs-accordion/div/div[2]/div/div/ul/li/div[1]")
	private List<WebElement> lbl_DigitalDocMangerPanel;

	@FindBy(xpath="//span[contains(text(),'No payment has been created yet')]")
	private WebElement lbl_NoPayments;

	@FindBy(xpath="//ipas-payment-facilitator-pannel/ejs-accordion/div")
	private WebElement tbl_PaymentFacilitatorPanel;

	@FindBy(xpath="//app-ipas-postal-short-pannel//ejs-accordion//div[@class='e-acrdn-header-content']/span/div/a")
	private WebElement lbl_PostalShortPanel;

	@FindBy(xpath="//a[contains(text(),'New Request')]")
	private WebElement lbl_PostalNewRequestBtn; 

	@FindBy(xpath="//div[@class='header']/div[1]/div")
	private WebElement lbl_PostaFullPanelHeader;

	@FindBy(xpath="//button[contains(text(),'Send Request')]")
	private WebElement btn_PostaFullPanelSendRequest;

	@FindBy(xpath="(//ejs-textbox/span/input)[4]")
	private WebElement txt_PostalStreetAddress;

	@FindBy(xpath="(//ejs-textbox/span/input)[6]")
	private WebElement txt_PostalCity;

	@FindBy(xpath="(//ejs-textbox/span/input)[7]")
	private WebElement txt_PostalState;

	@FindBy(xpath="(//ejs-textbox/span/input)[8]")
	private WebElement txt_PostalZipCode;

	@FindBy(xpath="(//financial-clearance-status/img)")
	private WebElement img_moduleStatus;

	@FindBy(xpath="//a[contains(text(),'Admit Notifier')]")
	public WebElement txt_AdmitShortPanelTitle;

	@FindBy(xpath="//a[contains(text(),'Add New CPT')]")
	public WebElement lnk_AddCPT;

	@FindBy(xpath="//ipas-admit-notifier-an-add-check-config//financial-clearance-status/img")
	public WebElement txt_AdmitFullPageModule;

	@FindBy(xpath="//ejs-dropdownlist[@id='status']/span/input")
	public WebElement ddl_AdmitFullPageModule;

	@FindBy(xpath="//ipas-self-pay-admit-notifier-presenter//img")
	public WebElement img_AdmitFullPageGoToEligibility;

	@FindBy(xpath="//ejs-dropdownlist[@id='status']/span/input")
	private WebElement ddl_AdmitStatusValue;

	@FindBy(xpath="(//ipas-medical-necessity-add-check-config//div/img)[2]")
	private WebElement img_MedicalCPTTrash;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_FilterMsgs;

	@FindBy(xpath="//a[contains(text(),'New Medical Necessity Check')]")
	private WebElement Btn_MedicalFullPanelNewMedicalNecessityCheck;

	@FindBy(xpath="//ipas-medical-necessity-add-check-config//a")
	private List<WebElement> lbl_MedicalFullPanelLinks;


	public AccountSearchFinancialStatusPage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyDefaultStatus(){
		try {
			webActions.waitForVisibility(lbl_AccountFinance, "AccountFinance");
			String actdefaultFinanceStatus=webActions.getAttributeValue(lbl_AccountFinance, "src", "AccountFinance");
			if(actdefaultFinanceStatus.contains("error")){
				report.reportPass("Default Financial Clearance status is displayed as Needs Attention mode");
			}
			else{
				report.reportFail("Default Financial Clearance status is not displayed as Needs Attention mode and actual displayed image is : " + actdefaultFinanceStatus);
			}
			/*webActions.waitForVisibility(lbl_DigitalStatusInNeedsAtten, "DigitalStatus");
			String actdefaultDigitalStatus=webActions.getAttributeValue(lbl_DigitalStatusInNeedsAtten, "src", "AccountFinance");

			if(actdefaultDigitalStatus.contains("error_sm")){
				report.reportPass("Default Financial Clearance status is displayed as Review mode");
			}
			else{
				report.reportFail("Default Financial Clearance status is not displayed as Review mode and actual displayed image is : " + actdefaultDigitalStatus);
			}*/
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	/**To verify the all module status in AllModuel window**/
	public void verifyAllModuleStatus(String status){
		try {
			webActions.waitForVisibility(lbl_AccountFinance, "AccountFinance");
			webActions.click(lbl_AllModuleWindowOption, "AllModuleWindowOption");
			webActions.waitForVisibility(lbl_AllModuleWindowTitle, "AllModuleWindowTitle");
			ArrayList<String> actualModulestatus=new ArrayList<String>();

			if("default".contentEquals(status)){								
				actualModulestatus.add(webActions.getAttributeValue(lbl_EligibilityStatusInAllModuleWindow, "src", "EligibilityStatus"));
				actualModulestatus.add(webActions.getAttributeValue(lbl_IdentityStatusInAllModuleWindow, "src", "IdentityStatus"));
				actualModulestatus.add(webActions.getAttributeValue(lbl_MedicalStatusInAllModuleWindow, "src", "MedicalStatus"));
				actualModulestatus.add(webActions.getAttributeValue(lbl_EstimatorInAllModuleWindow, "src", "EstimatorStatus"));
				actualModulestatus.add(webActions.getAttributeValue(lbl_PaymentStatusInAllModuleWindow, "src", "PaymentStatus"));
				actualModulestatus.add(webActions.getAttributeValue(lbl_ServiceStatusInAllModuleWindow, "src", "ServiceStatus"));		
				ArrayList<String> unmatched=webActions.isFullArrayMatchWithData(actualModulestatus, "success_sm");
				if(unmatched.size()==0){
					report.reportPass("Verified default module statuses successfully in All modules window");
				}
				else{
					throw new Exception("Fail to verify default module status from All modules and unmatched are: "+unmatched);
				}		
			}
			else if("clear".contentEquals(status)){
				actualModulestatus.add(webActions.getAttributeValue(lbl_DigitalStatusInAllModuleWindow, "src", "DigitalStatus"));
				actualModulestatus.add(webActions.getAttributeValue(lbl_EligibilityStatusInAllModuleWindow, "src", "EligibilityStatus"));
				actualModulestatus.add(webActions.getAttributeValue(lbl_IdentityStatusInAllModuleWindow, "src", "IdentityStatus"));
				actualModulestatus.add(webActions.getAttributeValue(lbl_MedicalStatusInAllModuleWindow, "src", "MedicalStatus"));
				actualModulestatus.add(webActions.getAttributeValue(lbl_EstimatorInAllModuleWindow, "src", "EstimatorStatus"));
				actualModulestatus.add(webActions.getAttributeValue(lbl_PaymentStatusInAllModuleWindow, "src", "PaymentStatus"));
				actualModulestatus.add(webActions.getAttributeValue(lbl_PostalStatusInAllModuleWindow, "src", "PostalStatus"));
				actualModulestatus.add(webActions.getAttributeValue(lbl_ServiceStatusInAllModuleWindow, "src", "ServiceStatus"));		
				ArrayList<String> unmatched=webActions.isFullArrayMatchWithData(actualModulestatus, "success_sm");
				if(unmatched.size()==0){
					report.reportPass("Verified default module statuses successfully in All modules window");
				}
				else{
					throw new Exception("Fail to verify default module status from All modules and unmatched are: "+unmatched);
				}	
			}
			else if("manual".contentEquals(status)){
				String actdefaulDigitalStatus=webActions.getAttributeValue(lbl_ManualPatientDigitalStatusInAllModuleWindow, "src", "Digital");
				if(actdefaulDigitalStatus.contains("error_sm")){
					report.reportPass("Verified digital docuemnt status mode in AllModule window");
				}
				else{
					report.reportFail("Fail to verify digital document mode in AllModule window and actual displayed image is : " + actdefaulDigitalStatus);
				}
				String actdefaultServiceStatus=webActions.getAttributeValue(lbl_ManualPatientServiceStatusInAllModuleWindow, "src", "ServiceStatus");
				if(actdefaultServiceStatus.contains("success_sm")){
					report.reportPass("Service tracker status is displayed as cleared mode in AllModule window");
				}
				else{
					report.reportFail("Service tracker status is not displayed as cleared mode in AllModule window and actual displayed image is : " + actdefaultServiceStatus);
				}

				String actdefaultPaymentStatus=webActions.getAttributeValue(lbl_ManualPatientPaymentStatusInAllModuleWindow, "src", "PaymentStatus");
				if(actdefaultPaymentStatus.contains("success_sm")){
					report.reportPass("Payment facilitator status is displayed as cleared mode in AllModule window");
				}
				else{
					report.reportFail("Payment facilitator status is not displayed as cleared mode in AllModule window and actual displayed image is : " + actdefaultPaymentStatus);
				}
				String actdefaultEligibilityStatus=webActions.getAttributeValue(lbl_ManualPatientEligibilityStatusInAllModuleWindow, "src", "Eligibility");
				if(actdefaultEligibilityStatus.contains("success_sm")){
					report.reportPass("Eligibility status is displayed as cleared mode in AllModule window");
				}
				else{
					report.reportFail("Eligibility status is not displayed as cleared mode in AllModule window and actual displayed image is : " + actdefaultEligibilityStatus);
				}
			}

			webActions.click(lbl_AllModuleWindowClose, "AllModuleWindowCloseOption");
		}

		catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyAllModuleTitle(String title){
		try {
			webActions.waitForVisibility(lbl_AccountFinance, "AccountFinance");
			webActions.click(lbl_AllModuleWindowOption, "AllModuleWindowOption");
			webActions.waitForVisibility(lbl_AllModuleWindowTitle, "AllModuleWindowTitle");
			String moduleTitle=webActions.getText(lbl_AllModuleWindowTitle, "AllModuleWindowTitle");
			if(title.contentEquals(moduleTitle)){
				report.reportPass("Verified the AllModuel Window title successfully");
			}
			else{
				report.reportFail("Failed to verify the module window title and actual displayed title: " + moduleTitle );
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickOndigitaldocumentLink_AccountSearch(){
		try {
			webActions.waitForVisibility(lbl_ModuleLinkInNeedsAtten, "DigitalLink");
			webActions.click(lbl_ModuleLinkInNeedsAtten, "DigitalLink");
			webActions.waitForVisibility(tbl_DDMPage, "DDMWindow");
			webActions.waitForVisibility(lbl_VisitSummaryData, "VisitSummary");
			report.reportPass("Navigated to the digital document page from account search");
		} catch (Exception e) {
			report.reportFail("Unable to navigated to the digital dcouemnt page from account search");
		}
	}
	public void verifyModuleStatusinDigitalDocumentsMangerPage() throws Exception{
		try {

			webActions.waitForVisibility(tbl_DDMPage, "DDMPage");				
			for (int i =1; i <=5; i++) {
				if(i==2||i==4||i==5){				
					String xpath1="//*[@id='document-list']//ul/li";
					String xpath2="/div/ejs-checkbox";			
					webActions.clickAction(driver.findElement(By.xpath(xpath1+"["+i+"]"+xpath2)), "documents");
					webActions.waitForVisibility(btn_ChangeStatus, "ChangeStatus");
					webActions.waitForPageLoaded();
					webActions.waitForPageLoaded();
					webActions.waitAndClick(btn_ChangeStatus, "ChangeStatus");
					Thread.sleep(5000);
					webActions.selectByVisibleText(dd_Status, "Complete", "Status Dropdown");
					Thread.sleep(5000);
					webActions.waitAndClick(btn_ChangeStatus_Popup, "Change Status Popup");
					Thread.sleep(10000);
				}

			}			
			for (int i =1; i <=11; i++) {
				if(i==2||i==3||i==4||i==5||i==6||i==8||i==9||i==10||i==11){				
					String xpath1="//*[@id='form-list']//ul/li";
					String xpath2="/div/ejs-checkbox";			
					webActions.clickAction(driver.findElement(By.xpath(xpath1+"["+i+"]"+xpath2)), "documents");
					webActions.waitForVisibility(btn_ChangeStatus, "ChangeStatus");
					webActions.waitForPageLoaded();
					webActions.waitForPageLoaded();
					webActions.waitAndClick(btn_ChangeStatus, "Change Status");
					Thread.sleep(5000);
					webActions.selectByVisibleText(dd_Status, "Complete", "Status Dropdown");
					Thread.sleep(5000);
					webActions.waitAndClick(btn_ChangeStatus_Popup, "Change Status Popup");
					Thread.sleep(10000);
				}

			}		
		} catch (Exception e) {	
			report.reportFail(e.getMessage());			
		}
	}
	public void verifyFinanceStatusInDigitalDocPage(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();	
			String actFinanceStatus=webActions.getAttributeValue(lbl_SummaryFinance, "src", "FinanceStatus");
			if(actFinanceStatus.contains("error")){
				report.reportPass("Finance clearance status is displayed as needs attention mode in digital docuemnt page after clear the documents and forms");
			}
			else{
				report.reportFail("Finance clearance status is not displayed as needs attention mode in digital document page and actual displayed image is : " + actFinanceStatus);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void navigateAccountFromBreadcrum(){
		try {			
			webActions.click(lbl_AccountLink, "AccountSearch");
			Thread.sleep(5000);
			webActions.waitForVisibility(lbl_GridRecords, "gridResults");
			report.reportPass("Successfully clicked on account Search");


		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyFinanceClearanceStatus(String status){
		try {
			webActions.waitForVisibility(lbl_AccountFinance, "AccountFinance");
			String actFinanceStatus=webActions.getAttributeValue(lbl_AccountFinance, "src", "AccountFinance");
			if("clear".contentEquals(status)){
				if(actFinanceStatus.contains("success")){
					report.reportPass("Financial Clearance status is displayed as clear mode");
				}
				else{
					report.reportFail("Financial Clearance status is not displayed as clear mode and actual displayed image is : " + actFinanceStatus);
				}
			}
			else if("review".contentEquals(status)){
				if(actFinanceStatus.contains("error")){
					report.reportPass("Financial Clearance status is displayed as needs attention mode");
				}
				else{
					report.reportFail("Financial Clearance status is not displayed as needs attention mode and actual displayed image is : " + actFinanceStatus);
				}
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void changeServiceTrackerToReview(){
		try {
			webActions.waitForVisibility(lbl_VisitSummaryData, "VisitSummary");			
			webActions.clickAction(lbl_ServiceLinkInPanel, "ServicetRacker");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_ServiceTrackerPageStatus, "ServiceStatusPage");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.clickAction(lbl_ServiceTrackerPageStatusImg, "StatusImg");
			webActions.waitForPageLoaded();
			Thread.sleep(5000);
			//webActions.waitForVisibility(lbl_ServiceTrackerPageStatusImgPriority, "HighPriorityWindow");
			webActions.clickAction(lbl_ServiceTrackerPageStatusPriorityChkBox, "HighPriorityChkBox");
			webActions.waitForPageLoaded();
			webActions.clickAction(lbl_ServiceTrackerPageStatusSubmitbtn, "SubmitBtn");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txt_ToastMsgs, "toastmessages");
			webActions.waitForPageLoaded();
			Thread.sleep(3000);
			report.reportPass("Service tracker module status saved successfully");


		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyFinanceStatusInSummaryPage(String status){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			String actFinanceStatus=webActions.getAttributeValue(lbl_SummaryFinance, "src", "FinanceStatus");
			if("Clear".contentEquals(status)){
				if(actFinanceStatus.contains("success")){
					report.reportPass("Finance clearance status is displayed as clear mode in summary page");
				}
				else{
					report.reportFail("Finance clearance status is not displayed as clear mode in summary page and actual displayed image is : " + actFinanceStatus);
				}
			}
			else if("Review".contentEquals(status)){
				if(actFinanceStatus.contains("alert")){

					report.reportPass("Finance clearance status is displayed as review mode in summary page");
				}
				else{
					report.reportFail("Finance clearance status is not displayed as review mode in summary page and actual displayed image is : " + actFinanceStatus);
				}
			}
			else if("NeedsAttention".contentEquals(status)){
				if(actFinanceStatus.contains("error")){

					report.reportPass("Finance clearance status is displayed as NeedsAttention mode in summary page");
				}
				else{
					report.reportFail("Finance clearance status is not displayed as NeedsAttention mode in summary page and actual displayed image is : " + actFinanceStatus);
				}
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickOnServiceTrackerLink_NeedsAttention(){
		try {
			webActions.waitForVisibility(lbl_ModuleLinkInNeedsAtten, "ServiceLink");
			webActions.click(lbl_ModuleLinkInNeedsAtten, "ServiceLink");
			webActions.waitForVisibility(lbl_ServiceTrackerPageStatus, "ServiceStatusPage");
			webActions.waitForVisibility(lbl_VisitSummaryData, "VisitSummary");
			report.reportPass("Navigated to the service tracker page from account search");
		} catch (Exception e) {
			report.reportFail("Unable to navigated to the service tracker page from account search");
		}
	}

	public void changeServiceTrackerToClear(){
		try {		
			webActions.waitForVisibility(lbl_ServiceTrackerPageStatus, "ServiceStatusPage");			
			webActions.click(lbl_ServiceTrackerPageStatusImg, "StatusImg");
			webActions.waitForVisibility(lbl_ServiceTrackerPageStatusImgPriority, "HighPriorityWindow");
			webActions.waitForVisibility(lbl_ServiceTrackerPageStatusPriorityUnChkBox, "HighPriorityCheck");
			webActions.click(lbl_ServiceTrackerPageStatusPriorityUnChkBox, "HighPriorityUnChkBox");
			webActions.click(lbl_ServiceTrackerPageStatusSubmitbtn, "SubmitBtn");
			webActions.waitForVisibility(txt_ToastMsgs, "toastmessages");
			webActions.click(btn_ServiceTrackerPageStatusClose, "HighPriorityWindowClose");
			Thread.sleep(5000);
			report.reportPass("Service tracker module changed to clear mode");


		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void changePaymentFacilitatorToPending(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();			
			webActions.click(lbl_AllModuleWindowOption, "AllModuleWindowOption");
			webActions.waitForVisibility(lbl_AllModuleWindowTitle, "AllModuleWindowTitle");
			webActions.click(lbl_PaymentLinkInAllModule, "Payment");			
			webActions.waitForVisibility(lbl_PaymentsWindow, "PaymentsWindow");
			webActions.waitForVisibility(lbl_VisitSummaryData, "VisitSummary");
			webActions.waitForPageLoaded();
			waitforPage();
			webActions.sendKeys(ddl_PaymentType, "Co-Pay", "PaymentType");
			webActions.waitForPageLoaded();
			webActions.click(txt_TotalAmount, "Amount");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_TotalAmount, "100", "Amount");			
			webActions.waitForPageLoaded();
			//webActions.sendKeys(ddl_Discount, "18% Cardio", "Discount");
			webActions.click(btn_Calculate, "CalculateButton");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_Save, "Savebtn");
			webActions.click(btn_Save, "Savebtn");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txt_ToastMsgs, "toastmessages");
			webActions.waitForPageLoaded();
			report.reportPass("Payment Facilitator module changed to needs attention mode");			

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void waitforPage() throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibilityOfAllElements(lbl_AmountFields, "Amount Field");
			webActions.waitForVisibilityOfAllElements(tbl_CurrentVisitDropdownlist, "CurrentVisitDropdownlist");
		} catch (Exception e) {
		}	
	}
	public void clickOnDigitalLink_VisitSummaryPage(){
		try {
			webActions.waitForVisibility(lbl_DigitalDocMangerPanelDocs, "DigitalDocs");
			webActions.click(lbl_DigitalDocLink, "DDMLink");
			webActions.waitForVisibility(tbl_DDMPage, "DDMWindow");
			webActions.waitForVisibility(lbl_VisitSummaryData, "VisitSummary");
			report.reportPass("Navigated to the digital document manager page from account search");
		} catch (Exception e) {
			report.reportFail("Unable to navigated to the digital document manager page from account search");
		}
	}
	public void verifyFinanceStatusInServiceTrackerWindow(String status){
		try {
			webActions.waitForVisibility(lbl_ServiceTrackerWindowFinance, "FinanceStatus");		
			String actFinanceStatus=webActions.getAttributeValue(lbl_ServiceTrackerWindowFinance, "src", "FinanceStatus");
			if("NeedsAttention".contentEquals(status)){
				if(actFinanceStatus.contains("error")){
					report.reportPass("Finance clearance status is displayed as needs attention mode in service tracker window");
				}
				else{
					report.reportFail("Finance clearance status is not displayed as needs attention mode in service tracker window and actual displayed image is : " + actFinanceStatus);
				}
			}
			webActions.click(btn_ServiceTrackerPageStatusClose, "HighPriorityWindowClose");
			Thread.sleep(5000);
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickOnAccountLinkNumber() throws Exception{
		try {			
			webActions.waitForVisibility(lbl_Headers, "Account Number");
			String accountNumber=webActions.getText(lnk_AccountNumber, "Account Number");
			report.reportInfo("Account Number is: "+accountNumber);
			webActions.click(lnk_AccountNumber, "Account Number");
			report.reportInfo("Navigated to the Patient Visit Summary page");			
			webActions.waitForVisibility(lbl_DataInAllDataPanel, "DataInAllData");
			webActions.waitForVisibilityOfAllElements(lbl_VisitSummaryData, "SummaryData");
		} catch (Exception e) {
			throw e;
		}

	}
	public void waitforPaymentFacilitatorPanel() throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(lbl_NoPayments, "No Payments Error Message");
		} catch (Exception e) {
			webActions.waitForVisibility(tbl_PaymentFacilitatorPanel, "Payment Facilitator Panel");
		}
	}
	public void clickOnPostalPanel(){
		try {
			webActions.waitForVisibility(lbl_PostalShortPanel, "PostalShortPanel");
			webActions.click(lbl_PostalShortPanel, "PostalLink");
			webActions.waitForVisibility(lbl_PostalNewRequestBtn, "Requestbutton");
			webActions.waitForVisibility(lbl_PostaFullPanelHeader, "FullPanel");
			report.reportPass("Navigated to the Postal full panel");
		} catch (Exception e) {
			report.reportFail("Unable to navigated to the postal full panel");
		}
	}
	public void navigateViistMainPageFromBreadcrum(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lbl_AccountNumberLink, "AccountNumber");			
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_DigitalDocMangerPanel, "DigitalDocs");			
			waitforPaymentFacilitatorPanel();					
			webActions.waitForVisibilityOfAllElements(lbl_DataInAllDataPanel, "DataInAllData");
			webActions.waitForVisibilityOfAllElements(lbl_VisitSummaryData, "SummaryData");
			Thread.sleep(2000);
			report.reportInfo("Navigated to the Patient Visit Summary page");	

		} catch (Exception e) {
			report.reportFail(e.getMessage());

		}
	}
	public void enterPostalAddress(DataTable testData){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lbl_PostalShortPanel, "PostalShortPanel");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_PostalNewRequestBtn, "Requestbutton");
			webActions.click(lbl_PostalNewRequestBtn, "Requestbutton");
			webActions.waitForPageLoaded();
			webActions.waitUntilEnabled(btn_PostaFullPanelSendRequest, "SendRequest");
			webActions.clearValue(txt_PostalStreetAddress, "Street Address");
			webActions.sendKeys(txt_PostalStreetAddress, webActions.getDatafromMap(testData,"Street Address"), "Street Address");
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_PostalCity, "City");
			webActions.sendKeys(txt_PostalCity, webActions.getDatafromMap(testData,"City"), "City");
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_PostalState, "State");
			webActions.sendKeys(txt_PostalState, webActions.getDatafromMap(testData,"State"), "State");
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_PostalZipCode, "ZipCode");
			webActions.sendKeys(txt_PostalZipCode, webActions.getDatafromMap(testData,"Zip Code"), "Zip Code");
			webActions.waitForPageLoaded();
			webActions.click(btn_PostaFullPanelSendRequest, "Requestbutton");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnAdmitNotifierShortPanel(){
		try {
			webActions.waitForVisibility(txt_AdmitShortPanelTitle, "TitleLink");
			webActions.clickAction(txt_AdmitShortPanelTitle, "TitleLink");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txt_AdmitFullPageModule, "ModuleStatus");
			webActions.waitForVisibility(lnk_AddCPT, "AddCPT");
			webActions.waitForVisibility(img_AdmitFullPageGoToEligibility, "Icon");
			webActions.waitForPageLoaded();
			report.reportInfo("Successfully navigated to the Admit notifer full page");

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void changeAdmitNotifierStatus(String status){
		try {
			webActions.waitForPageLoaded();
			webActions.clickAction(ddl_AdmitStatusValue, "Status");
			waitForPageLoade(1);
			try{
				webActions.sendKeys(ddl_AdmitStatusValue, status, "Status");
				waitForPageLoade(2);
			}
			catch (Exception e){
				report.reportFail(e.getMessage());
			}			
			waitForPageLoade(5);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void waitForPageLoade(int seconds){
		try {
			Thread.sleep(seconds*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public void verifyFinancialStatus(String status){
		try {		
			String expStatus="";
			webActions.waitForVisibility(lbl_AccountFinance, "AccountFinance");
			String actFinanceStatus=webActions.getAttributeValue(lbl_AccountFinance, "src", "AccountFinance");

			if(status.contentEquals("NeedsAttention")){
				expStatus="error.png";
			}
			else if(status.contentEquals("Clear")){
				expStatus="success.png";
			}
			else if(status.contentEquals("Review")){
				expStatus="alert.png";
			}
			if(actFinanceStatus.contains(expStatus)){
				report.reportPass("Financial Clearance status is verified successfully");
			}
			else{
				report.reportFail("Fail to verify the financial clearance status and actual displayed image is : " + actFinanceStatus);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void changeServiceTrackerModuleStatusToReview(){
		try {
			webActions.waitForVisibility(lbl_VisitSummaryData, "VisitSummary");			
			webActions.clickAction(lbl_ServiceLinkInPanel, "ServicetRacker");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_ServiceTrackerPageStatus, "ServiceStatusPage");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.clickAction(lbl_ServiceTrackerPageStatusImg, "StatusImg");
			webActions.waitForPageLoaded();
			Thread.sleep(5000);
			special.navigateToSpecialAssistance();
			special.selectWheelChair("Enabled");
			webActions.waitForPageLoaded();
			webActions.clickAction(lbl_ServiceTrackerPageStatusSubmitbtn, "SubmitBtn");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txt_ToastMsgs, "toastmessages");
			webActions.waitForPageLoaded();
			Thread.sleep(3000);
			report.reportPass("Service tracker module status saved successfully");

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void deleteMedicalNecessityCPTcodes(String type){
		try {
			webActions.waitForPageLoaded();			
			webActions.click(img_MedicalCPTTrash, "CPTDeletion");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txt_FilterMsgs, "toasterMsg");
			if(type.contentEquals("multiple")){
				webActions.click(img_MedicalCPTTrash, "CPTDeletion");
				webActions.waitForVisibility(txt_FilterMsgs, "toasterMsg");
			}
			else{

			}
			String msg=webActions.waitAndGetText(txt_FilterMsgs, "FilterMsgs");
			String[] titleContent=msg.split("\\n");
			String actTitle=titleContent[0];
			String actContent=titleContent[1];
			if(("Success!".contentEquals(actTitle)) && ("CPT deleted successfully.".contentEquals(actContent))){
				report.reportPass("Both title and content displayed properly");
			}
			else{
				throw new Exception("Both title and content are not displayed properly actual Title: " +actTitle+ " and actual content: "+ actContent);
			}
			webActions.waitForPageLoaded();

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnMedicalCheck(){
		try {
			webActions.click(Btn_MedicalFullPanelNewMedicalNecessityCheck, "Button");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_MedicalFullPanelLinks, "fields");
			Thread.sleep(1000);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return ExpectedConditions.visibilityOf(lbl_AccountFinance);
	}
}