package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class EligibilityPayerMaintenancePage extends BasePage{

	RestActions rest=new RestActions();

	@FindBy(xpath="//span[contains(text(),'Data Configuration')]")
	private WebElement lbl_PayerMaintenancePanel;

	@FindBy(linkText="Payer Maintenance Configuration")
	private WebElement lnk_PayerMaintenance;

	@FindBy(xpath="//div[contains(text(),'Configure Payer Codes, setup Connection Methods an')]")
	private WebElement lbl_PayerMaintenanceContext;

	@FindBy(xpath="//ipas-button/a[@class='btn btn--white']")
	private WebElement btn_AddNewPlan;

	@FindBy(xpath="//ipas-breadcrumb/div/span")
	private List<WebElement> lbl_PayerMaintenanceBreadCrumb;

	@FindBy(xpath="//ul[@class='navbar-nav']/li/a")
	private List<WebElement> lbl_NavigationMenuBarList;

	@FindBy(xpath="//a[@class='navbar-brand']/img")
	private WebElement icon_iPASImg;

	@FindBy(xpath="//div[@id='notificationBell']/div")
	private WebElement icon_Notification;

	@FindBy(xpath="//div[@class='menubar']/nav")
	private List<WebElement> lbl_NavigationMenuBarListWithIcons;

	@FindBy(xpath="//div[@class='navbar-nav ml-auto']/a[1]/img")
	private WebElement icon_userImg;

	@FindBy(xpath="//div[@class='navbar-nav ml-auto']/a[2]/img")
	private WebElement icon_settings;

	@FindBy(xpath="//form[@class='ng-pristine ng-invalid ng-touched']/h3")
	private WebElement lbl_AddNewPlanWindowTitle;

	@FindBy(xpath="//form[@class='ng-invalid ng-touched ng-dirty']/div")
	private List<WebElement> lbl_AddNewPlanWindowFields;

	@FindBy(xpath="//div[@id='addPlanCode']/form/div//h6")
	private List<WebElement> lbl_PlanCodeNames;

	@FindBy(xpath="//div[@id='addPlanCode']/form//label")
	private WebElement lbl_FacilityField;

	@FindBy(xpath="//h6[contains(text(),'Plan Code')]")
	private WebElement lbl_PlanCode;

	@FindBy(xpath="//h6[contains(text(),'Plan Name')]")
	private WebElement lbl_PlanName;

	@FindBy(xpath="//input[@name='planCode']")
	private WebElement txt_PlanCode;

	@FindBy(xpath="//input[@name='planName']")
	private WebElement txt_PlanName;

	@FindBy(xpath="//h6[contains(text(),'Payer Code')]")
	private WebElement lbl_PayerCode;

	@FindBy(xpath="//div[@class='general-info selfpay-label']")
	private WebElement lbl_SelfPayPlan;

	@FindBy(xpath="//div[@id='addPlanCode']/form/div/ejs-switch")
	private WebElement lbl_SliderToggleButton;

	@FindBy(xpath="//a[contains(text(),'Cancel')]")
	private WebElement btn_Cancel;

	@FindBy(xpath="//a[contains(text(),'Save')]")
	private WebElement btn_Save;

	@FindBy(xpath="//span[@class='mandatory ng-star-inserted']")
	private List<WebElement> lbl_MandatoryFields;

	@FindBy(xpath="//ejs-multiselect[@filterbarplaceholder='Search Facilities']/div/div")
	private WebElement ddl_Facility;

	@FindBy(xpath="//input[@placeholder='Please Select']")
	private WebElement ddl_PayerCode;

	@FindBy(xpath="//div[@class='code-dropdown']/span")
	private WebElement txt_PlanCodeValidation;

	@FindBy(xpath="//div[@class='plan-dropdown']/span")
	private WebElement txt_PlanNameValidation;

	@FindBy(xpath="//ejs-textbox[@id='search_text']/span/input")
	private WebElement lbl_SearchFile;

	@FindBy(xpath="//div[@class='payer-code-dropdown']//ejs-dropdownlist/span")
	private WebElement lbl_PayerCodeField;

	@FindBy(xpath="//div[@class='facility-dropdown']//ejs-dropdownlist/span/input")
	private WebElement lbl_FacilityFieldName;

	@FindBy(xpath="//div[@class='facility-dropdown']//ejs-dropdownlist/span")
	private WebElement lbl_FacilityFieldName1;

	@FindBy(xpath="//div[@class='d-flex align-items-center justify-content-start']/div[5]//label/span[1]")
	private WebElement lbl_UnmappedChkBox;

	@FindBy(xpath="//ipas-button/a[@class='btn btn--blue']")
	private WebElement btn_Apply;

	@FindBy(xpath="//div[@class='emptyinfo template-noReuslt']/img")
	private WebElement img_noResults;

	@FindBy(xpath="//div[@class='emptyinfo template-noReuslt']")
	private WebElement lbl_noResultsMsg;

	@FindBy(xpath="//div[@class='d-flex result-val']")
	private WebElement lbl_Results;

	@FindBy(xpath="//div[@class='e-gridcontent']/div/table/tbody/tr/td")
	private List<WebElement> lbl_GridData;

	@FindBy(xpath="//div[@class='e-gridcontent']//child::tr[1]/td[1]//span[1]")//div[@class='e-gridcontent']//child::td/span[1]
	private WebElement lbl_PlanCodeData;

	@FindBy(xpath="//table[@class='e-table']/thead/tr")
	private WebElement lbl_GridHeader;

	@FindBy(xpath="//div[@class='e-gridcontent']/div/table/tbody")
	private WebElement lbl_GridResults;

	@FindBy(xpath="//span[@class='e-headertext']")
	private List<WebElement> lbl_GridHeaderNames;

	@FindBy(xpath="//div[@class='e-gridcontent']//child::tr/td[1]//span[1]")
	private List<WebElement> lbl_GridPlanCodes;

	@FindBy(xpath="//div[@class='e-gridcontent']//child::tr/td[1]//span[2]")
	private List<WebElement> lbl_GridPlanNames;

	@FindBy(xpath="//div[@class='e-gridcontent']//child::tr/td[1]//span[1]")
	private List<WebElement> lbl_GridPayerCodes;

	@FindBy(xpath="//div[@class='e-gridcontent']//child::tr/td[2]")
	private List<WebElement> lbl_GridFacilityName;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_FilterMsgs; 
	
	@FindBy(xpath = "//label[text()='What do you want to configure?']/../ejs-dropdownlist/span/input")
	private WebElement dd_SelectModule; 
	
	@FindBy(xpath = "//ejs-switch[@formcontrolname='selfPay']")
	private WebElement switch_SelfPay; 
	
	String lbl_Department="//div[@class='card']//div[contains(text(),'";
	String lbl_Department1="')]";

	public void verifyLabelNames(DataTable label) {
		try {
			ArrayList<String> expLabels = new ArrayList<>(label.asList());
			report.reportInfo("Expected Label Names in Payer Maintenance panel: "+expLabels);
			webActions.waitUntilisDisplayed(lbl_PayerMaintenanceContext, "PayerMaintenanceText");
			ArrayList<String> actLabels = new ArrayList<String>();
			actLabels.add(webActions.getText(lbl_PayerMaintenancePanel, "PayerMaintenance Panel"));
			actLabels.add(webActions.getText(lnk_PayerMaintenance, "PayerMaintenance Link"));
			actLabels.add(webActions.getText(lbl_PayerMaintenanceContext, "Context in PayerMaintenance Panel"));			
			report.reportInfo("Expected Label Names PayerMaintenance panel: "+expLabels);
			report.reportInfo("Displayed Lable Names in PayerMaintenance panel: "+actLabels);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actLabels, expLabels);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Label Names in PayerMaintenance panel successfully");
			}
			else{
				throw new Exception("Fail to verify Label Names in PayerMaintenance panel and unmatched label Names are: "+unmatchedLabelNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyfields(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_AddNewPlan, "AddNewPlan");
			webActions.assertDisplayed(btn_AddNewPlan, "AddNewPlan");			
			report.reportPass("Verified Add New Plan button from payer maintenance page successfully");
		} catch (Exception e) {
			report.reportFail("Fail to verify Add New Plan button from payer maintenance page");
		}
	}

	public void verifyBreadcrumbinPayerMaintenance(DataTable breadcrumb ){
		try {
			webActions.waitForPageLoaded();
			ArrayList<String> expectdBreadcrumb = new ArrayList<>(breadcrumb.asList());				
			ArrayList<String> actualBreadcrumb=webActions.getDatafromWebTable(lbl_PayerMaintenanceBreadCrumb);
			report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumb);
			report.reportInfo("Expected Breadcrumb Titles "+expectdBreadcrumb);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumb, expectdBreadcrumb);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Breadcrumb in payer maintenance page");
			}else{
				throw new Exception("Fail to verify the Breadcrumb in payer maintenance page page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickPayerMaintenanceLink(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lnk_PayerMaintenance, "PayerMaintenance");
			webActions.waitAndClick(lnk_PayerMaintenance, "PayerMaintenance");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibility(btn_AddNewPlan, "AddNewPlan");
			report.reportPass("Navigated to the payer maintenance page successfully");
		} catch (Exception e) {
			report.reportFail("Fail to navigate to the payer maintenance page");
		}
	}
	public void verifyNavigationBarList(DataTable navigationMenu){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_NavigationMenuBarList, "MenuList");
			webActions.assertDisplayed(icon_iPASImg, "iPASimg");			
			report.reportPass("Verified iPAS image from navigation menu bar successfully");
			ArrayList<String> expectdBreadcrumb = new ArrayList<>(navigationMenu.asList());				
			ArrayList<String> actualBreadcrumb=webActions.getDatafromWebTable(lbl_NavigationMenuBarList);
			report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumb);
			report.reportInfo("Expected Breadcrumb Titles "+expectdBreadcrumb);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumb, expectdBreadcrumb);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the navigation menu list");
			}else{
				throw new Exception("Fail to verify the navigation menu list: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyIcons(){
		try {
			webActions.waitForPageLoaded();
			String actSettingIcon=webActions.getAttributeValue(icon_settings, "src", "SettingsIcon");
			if(actSettingIcon.contains("cog")){
				report.reportPass("Verified the cog wheel on the navigation menu bard list successfully");
			}
			else{
				report.reportFail("Fail to verify the cog wheel on the navigation menu bar list and actual displayed image is : " + actSettingIcon);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnAddNewPlan(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_AddNewPlan, "AddNewPlanBtn");
			webActions.click(btn_AddNewPlan, "AddNewPlanBtn");
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_PlanCode, "PlanCode");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			//webActions.waitForVisibilityOfAllElements(lbl_AddNewPlanWindowFields, "AddNewPlanfields");			
			report.reportPass("Successfully navigated to the Add New Plan window");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyAddNewPlanPage(String expTitle){
		try {
			webActions.waitForPageLoaded();			
			String actualTitle=webActions.getText(lbl_AddNewPlanWindowTitle, "AddNewPlanWindowTitle");
			if(expTitle.contentEquals(actualTitle)){
				report.reportPass("Verified Add New Plan window title successfully");
			}
			else{
				report.reportFail("Fail to verify Add New Plan window title");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyAddNewPlanLabelNames(String scenario,DataTable testData) {
		try {
			ArrayList<String> actualData =new ArrayList<String>();;
			ArrayList<String> expectedData = new ArrayList<>(testData.asList());
			if(scenario.contentEquals("fields")){
				report.reportInfo("Expected Label Names in Add New Plan code window: "+expectedData);
				webActions.waitForPageLoaded();
				actualData.add(webActions.getText(lbl_FacilityField, "Facility"));				
				actualData.add(webActions.getText(lbl_PlanCode, "PlanCode"));
				actualData.add(webActions.getText(lbl_PlanName, "PlanName"));
				actualData.add(webActions.getText(lbl_SelfPayPlan, "SelfpayPlan"));
				report.reportInfo("Displayed fields in aAdd New Plan code window: "+actualData);
			}
			else if (scenario.contentEquals("mandatory")){
				report.reportInfo("Expected mandatory fields from add new facility page "+expectedData);
				webActions.waitForPageLoaded();	
				webActions.waitAndClick(txt_PlanName, "Plan Name");
				webActions.pressTab();
				webActions.waitForPageLoaded();	
				actualData=webActions.getDatafromWebTable(lbl_MandatoryFields);
				report.reportInfo("Displayed mandatory fields from add new plan code window: "+actualData);
			}
			ArrayList<String>unmatchedFields=webActions.getUmatchedInArrayComparision(actualData, expectedData);
			if(unmatchedFields.size()==0){
				report.reportPass("Verified fields "+scenario+" from Add New Plan window successfully");
			}
			else{
				report.reportFail("Fail to verify "+scenario+" from Add New Plan window and unmatched "+scenario+" are: "+unmatchedFields);
			}
			webActions.assertDisplayed(lbl_SliderToggleButton, "Toggle");			
			report.reportPass("Verified slider toggle button from add new plan window successfully");
			webActions.assertDisplayed(btn_Cancel, "Cancel");			
			report.reportPass("Verified cancel button from add new plan window successfully");
			webActions.assertDisplayed(btn_Save, "Save");			
			report.reportPass("Verified Save button from add new plan window successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifySaveSliderbtnMode(){
		try {
			webActions.waitForPageLoaded();							
			webActions.waitForPageLoaded();			
			String toggleModeValue= webActions.getAttributeValue(lbl_SliderToggleButton, "aria-checked", "toggle");
			String savebuttonModeValue= webActions.getAttributeValue(btn_Save, "class", "Savebutton");			
			if((toggleModeValue.contentEquals("false")) && (savebuttonModeValue.contentEquals("btn disabled btn--blue"))){
				report.reportPass("Verified Save and Slider toggle buttons mode successfully");
			}
			else{
				report.reportFail("Fail to verify the Save and toggle modes");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickCancleAndVerify(){
		try {

			webActions.waitForPageLoaded();
			webActions.clickAction(btn_Cancel, "Cancel");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_AddNewPlan, "AddNewPlan");
			webActions.isDisplayed(btn_AddNewPlan, "AddNewPlan");
			report.reportPass("Verified page navigation successfully");
		} catch (Exception e) {
			report.reportFail("Fail to verify page navigation");
		}
	}

	public void enterNewPlanCode(DataTable testData){
		try {	
			String facility=webActions.getDatafromMap(testData,"Facility");			
			selectDropdown(ddl_Facility, facility, "Facility");
			webActions.pressTab();
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_PlanCode, "PlanCode");			
			webActions.sendKeys(txt_PlanCode,webActions.getDatafromMap(testData,"Plan Code"), "Plan Code");
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_PlanName, "PlanName");			
			webActions.sendKeys(txt_PlanName,webActions.getDatafromMap(testData,"Plan Name"), "Plan Name");
			webActions.waitForPageLoaded();
			//webActions.sendKeys(ddl_PayerCode,webActions.getDatafromMap(testData,"Payer Code"), "Payer Code");
			webActions.waitForPageLoaded();
			webActions.pressTab();
			webActions.waitForPageLoaded();
			report.reportPass("Entered data in add new plan code window successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}
	public void selectDropdown(WebElement element,String valuetoSelect,String elementName) throws Exception{
		try {
			if (!valuetoSelect.isEmpty()) {
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.click(element, elementName);
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				driver.findElement(By.xpath("//ul[@id='multiselect-checkbox_options']/li[contains(.,'" + valuetoSelect + "')]")).click();
				//driver.findElement(By.xpath("//ul[@id='dropdownFacility_options']/li[contains(.,'" + valuetoSelect + "')]")).click();
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
			}
		} catch (Exception e) {
			throw e;
		}
	}
	public void verifyPlanCodePlanNameValidation(String field,String expMsg,String input){		
		try {
			webActions.waitForPageLoaded();
			String actaulMessage="";
			if(field.contentEquals("Plan Code")){
				webActions.sendKeys(txt_PlanCode, input, "PlanCode");
				webActions.pressTab();
				webActions.waitForPageLoaded();
				actaulMessage=webActions.getText(txt_PlanCodeValidation, "PlanCodevalidation");
			}					
			else if(field.contentEquals("Plan Name")) {
				webActions.sendKeys(txt_PlanName, input, "PlanName");
				webActions.pressTab();
				webActions.waitForPageLoaded();
				actaulMessage=webActions.getText(txt_PlanNameValidation, "PlanNamevalidation");
			}
			report.reportInfo("Expected validation message is : " + expMsg);
			report.reportInfo("Actual validation message is : " + actaulMessage);

			if(actaulMessage.contentEquals(expMsg)){
				report.reportPass("Verified "+field+" validation message successfully");
			}
			else{
				report.reportFail("Fail to verify "+field+" validation message");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public String createNewPlanCode(DataTable testData){
		String planCode="";
		try {	
			String facility=webActions.getDatafromMap(testData,"Facility");			
			selectDropdown(ddl_Facility, facility, "Facility");
			webActions.pressTab();
			webActions.waitForPageLoaded();
			String code=rest.randomNumber(4);
			planCode="V"+code;
			webActions.clickAction(txt_PlanCode, "PlanCode");			
			webActions.sendKeys(txt_PlanCode,planCode,"Plan Code");
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_PlanName, "PlanName");			
			webActions.sendKeys(txt_PlanName,webActions.getDatafromMap(testData,"Plan Name"), "Plan Name");
			webActions.waitForPageLoaded();
			webActions.pressTab();
			webActions.waitForPageLoaded();
			String payerType=webActions.getDatafromMap(testData,"Payer Type");
			if ("Self Pay".contentEquals(payerType)) {
				webActions.click(switch_SelfPay, "SelfPay Plan");
				webActions.waitForPageLoaded();
			}
			report.reportPass("Entered data in add new plan code window successfully");
			webActions.click(btn_Save, "Save Button");
			String msg=webActions.waitAndGetText(txt_FilterMsgs, "Alert Message");
			String[] titleContent=msg.split("\\n");
			String actTitle=titleContent[0];
			String actContent=titleContent[1];
			if("Data saved successfully.".contentEquals(actContent)){
				report.reportPass("Successfully added new plan code and verified success message: "+actContent);
			}
			else{
				throw new Exception("Failed to add new plan code and fail to verify success message: "+actContent);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
		return planCode;

	}
	public String getRandomString(int length){
		String alphabet = "";
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		for(int i = 0; i < length; i++) {
			int index = random.nextInt(alphabet.length());
			char randomChar = alphabet.charAt(index);
			sb.append(randomChar);
		}
		String randomString = sb.toString();
		return randomString;
	}
	public EligibilityPayerMaintenancePage() {
		PageFactory.initElements(driver, this);
	}
	public void createDuplicateNewPlanCode(DataTable testData,String planCode){
		try {	
			String facility=webActions.getDatafromMap(testData,"Facility");			
			selectDropdown(ddl_Facility, facility, "Facility");
			webActions.pressTab();
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_PlanCode, "PlanCode");			
			webActions.sendKeys(txt_PlanCode,planCode,"Plan Code");
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_PlanName, "PlanName");			
			webActions.sendKeys(txt_PlanName,webActions.getDatafromMap(testData,"Plan Name"), "Plan Name");
			webActions.waitForPageLoaded();
			webActions.pressTab();
			webActions.waitForPageLoaded();
			report.reportPass("Entered data in add new plan code window successfully");
			webActions.clickAction(btn_Save, "SaveButton");			
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}		

	}
	public void onePlanCodeToAnotherFacility(DataTable testData,String planCode){
		try {	
			String facility=webActions.getDatafromMap(testData,"Another Facility");			
			selectDropdown(ddl_Facility, facility, "Another Facility");
			webActions.pressTab();
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_PlanCode, "PlanCode");			
			webActions.sendKeys(txt_PlanCode,planCode,"Plan Code");
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_PlanName, "PlanName");			
			webActions.sendKeys(txt_PlanName,webActions.getDatafromMap(testData,"Plan Name"), "Plan Name");
			webActions.waitForPageLoaded();
			webActions.pressTab();
			webActions.waitForPageLoaded();
			report.reportPass("Entered data in add new plan code window successfully");
			webActions.click(btn_Save, "Save Button");
			String msg=webActions.waitAndGetText(txt_FilterMsgs, "Alert Message");
			String[] titleContent=msg.split("\\n");
			String actTitle=titleContent[0];
			String actContent=titleContent[1];
			if(actContent.contentEquals(actContent)){
				report.reportPass("Successfully added new plan code and verified success message");
			}
			else{
				throw new Exception("Failed to add new plan code and fail to verify success message");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}		

	}
	public void verifySearchFieldsAndButtons(DataTable testData){
		try {
			ArrayList<String> expectedData = new ArrayList<>(testData.asList());
			ArrayList<String> actualData = new ArrayList<>();
			for (int i =1; i <=5; i++) {
				if(i==1||i==3||i==4||i==5){				
					String xpath1="//div[@class='d-flex align-items-center justify-content-start']/div";
					String xpath2="//label";			
					String fieldName=webActions.getText(driver.findElement(By.xpath(xpath1+"["+i+"]"+xpath2)), "fields");					
					actualData.add(fieldName);				
				}
			}
			ArrayList<String>unmatchedFieldNames=webActions.getUmatchedInArrayComparision(actualData, expectedData);
			if(unmatchedFieldNames.size()==0){
				report.reportInfo("Expected fields from search payer page : " + expectedData );
				report.reportInfo("Displayed fields from search payer page : " + actualData );
				report.reportPass("Verified field Names from search payer successfully");
			}
			else{
				throw new Exception("Fail to verify field Names from search payer and unmatched fields Names are: "+unmatchedFieldNames);
			}
			webActions.assertDisplayed(btn_Apply, "Apply");			
			report.reportPass("Verified Apply button from search payer on payer maintenance page successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyDefaultValuesOfSearchPayerbar(DataTable testData){
		try {
			ArrayList<String> expectedData = new ArrayList<>(testData.asList());
			ArrayList<String> actualData = new ArrayList<>();
			actualData.add(webActions.getAttributeValue(lbl_SearchFile, "placeholder", "SearchBox"));
			actualData.add(webActions.getAttributeValue(lbl_PayerCodeField, "placeholder", "PayerCode"));
			actualData.add(webActions.getAttributeValue(lbl_FacilityFieldName, "aria-label", "Facility"));		
			actualData.add(webActions.getAttributeValue(lbl_UnmappedChkBox, "class", "UnmappedCheckBox"));
			ArrayList<String>unmatchedFieldNames=webActions.getUmatchedInArrayComparision(actualData, expectedData);
			if(unmatchedFieldNames.size()==0){
				report.reportInfo("Expected default values from search payer page : " + expectedData );
				report.reportInfo("Displayed default values from search payer page : " + actualData );
				report.reportPass("Verified default values from search payer successfully");
			}
			else{
				throw new Exception("Fail to verify default values from search payer and unmatched values are: "+unmatchedFieldNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}		
	}
	public void veriyDefaultResultGridValues(DataTable testData){
		try {
			ArrayList<String> expectedData = new ArrayList<>(testData.asList());
			ArrayList<String> actualData = new ArrayList<>();
			actualData.add(webActions.getText(lbl_Results, "ResultsLabel"));
			actualData.add(webActions.getText(lbl_noResultsMsg, "GridResultsMsg"));
			ArrayList<String>unmatchedFieldNames=webActions.getUmatchedInArrayComparision(actualData, expectedData);
			if(unmatchedFieldNames.size()==0){
				report.reportInfo("Expected default result grid values from search payer page : " + expectedData );
				report.reportInfo("Displayed default result grid values from search payer page : " + actualData );
				report.reportPass("Verified default values from search payer successfully");
			}
			else{
				report.reportFail("Fail to verify default values from search payer and unmatched values are: "+unmatchedFieldNames, true);
			}
			String actdefaultResultsImg=webActions.getAttributeValue(img_noResults, "src", "NoResultsImg");
			if(actdefaultResultsImg.contains("error")){
				report.reportPass("Verified default result grid display image");
			}
			else{
				report.reportFail("Fail to verify default result grid display image and actual displayed image is : " + actdefaultResultsImg);
			}
		} catch (Exception e) {

		}
	}
	public void verifyCreatedPlanCodeFromGrid(String planCode){
		try {
			selectModule("Eligibility");
			searchPlanCodeName(planCode);
			webActions.waitForPageLoaded();
			String actualplanCode=webActions.waitAndGetText(lbl_PlanCodeData, "PlanCode");
			report.reportInfo("Expected planCode : " + planCode);
			report.reportInfo("Displayed planCode : " + actualplanCode);			
			if(actualplanCode.trim().contentEquals(planCode.trim())){
				report.reportPass("Verified plan code successfully from grid");
			}
			else{
				report.reportFail("Fail to verify plan code from result grid and actual displayed plan code : " + actualplanCode);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void searchPlanCodeName(String input){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(lbl_SearchFile, "SearchField");
			webActions.waitForPageLoaded();		
			webActions.enterValuesfromKeyBoard(lbl_SearchFile, input, "SearchField");
			webActions.waitForPageLoaded();
			webActions.clickAction(btn_Apply, "ApplyButton");
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibilityOfAllElements(lbl_GridData, "GridData");
			} catch (Exception e) {
			}
			report.reportPass("Performed search successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnApplyButton(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibility(btn_Apply, "ApplyBtn");
			webActions.click(btn_Apply, "ApplyBtn");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_GridData, "GridData");
			report.reportPass("Successfully performed click operation");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifysearchPayerGridHeaders(DataTable testData){
		try {
			ArrayList<String> expectedData = new ArrayList<>(testData.asList());
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibilityOfAllElements(lbl_GridData, "GridData");
			} catch (Exception e) {
			}
			ArrayList<String> actualData =webActions.getDatafromWebTable(lbl_GridHeaderNames);		
			report.reportInfo("Expected default values from search payer page : " + expectedData );
			report.reportInfo("Displayed default values from search payer page : " + actualData );
			
			ArrayList<String>unmatchedFieldNames=webActions.getUmatchedInArrayComparision(actualData, expectedData);
			
			if(unmatchedFieldNames.size()==0){				
				report.reportPass("Verified default values from search payer successfully");
			}
			else{
				throw new Exception("Fail to verify default values from search payer and unmatched values are: "+unmatchedFieldNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}		
	}
	public void verifyPlanNameFormGrid(String column,String input){
		try {
			webActions.waitForPageLoaded();
			ArrayList<String> displayedNames =null;
			if("PlanName".contentEquals(column)){
				displayedNames =webActions.getDatafromWebTable(lbl_GridPlanNames);
			}
			else if("PlanCode".contentEquals(column)){
				displayedNames =webActions.getDatafromWebTable(lbl_GridPlanCodes);
			}
			else if("PayerCode".contentEquals(column)){
				displayedNames =webActions.getDatafromWebTable(lbl_GridPayerCodes);
			}
			else if("Facility".contentEquals(column)){
				displayedNames =webActions.getDatafromWebTable(lbl_GridFacilityName);
			}
			ArrayList<String>unmatchedFieldNames=webActions.isFullArrayMatchWithData(displayedNames,input.trim());
			report.reportInfo("Expected plan Name from grid :"+input );
			report.reportInfo("Displayed plan Names from search grid :"+displayedNames);
			if(unmatchedFieldNames.size()==0){				
				report.reportPass("Verified plan names from search payer grid successfully");
			}
			else{
				throw new Exception("Fail to verify plan names from search payer grid and unmatched values are: "+unmatchedFieldNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void selectPayerCode(String input){
		try {
			webActions.sendKeys(lbl_PayerCodeField, input, "PayerCode");			
			webActions.waitForPageLoaded();
			report.reportPass("Selected payer code from Payer Code drop down");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void selectFacility(String input){
		try {
			webActions.waitForPageLoaded();
			webActions.sendKeys(lbl_FacilityFieldName, input, "Facility");
			//webActions.selectByVisibleText(lbl_FacilityFieldName, input, "Facility");
			webActions.waitForPageLoaded();
			report.reportPass("Selected facility from facility drop down");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void enterDatainSearchField(String input){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(lbl_SearchFile, "SearchField");
			webActions.waitForPageLoaded();		
			webActions.enterValuesfromKeyBoard(lbl_SearchFile, input, "SearchField");
			webActions.waitForPageLoaded();
			webActions.clickAction(btn_Apply, "ApplyButton");
			webActions.waitForPageLoaded();			
			report.reportPass("Performed search successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	/**Verify alert message when create duplicate plan code  */
	public void verifyAlertMessagesWhenCreateDuplicatePlanCode(DataTable testData, String planCode){
		try {
			//webActions.waitForVisibility(txt_FilterMsgs, "messages");
			String msg=webActions.waitAndGetText(txt_FilterMsgs, "FilterMsgs");
			String[] titleContent=msg.split("\\n");
			String actTitle=titleContent[0];
			String actContent=titleContent[1];
			String title=webActions.getDatafromMap(testData,"Alert Tilte");	
			String expContent=webActions.getDatafromMap(testData,"Alert Content");
			String facility=webActions.getDatafromMap(testData,"Facility");
			expContent="Plan Code "+planCode+" "+expContent+" "+facility+".";
			report.reportInfo("Expected validation message: "+expContent);
			report.reportInfo("Actual validation message: "+actContent);
			if(actContent.contentEquals(expContent)){
				report.reportPass("Successfully verified the validation message");
			}
			else{
				throw new Exception("Fail to verify the validation message");
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void selectModule(String moduleName){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(dd_SelectModule, "Select Module", 10);
			webActions.sendKeys(dd_SelectModule, moduleName, "Select Module");
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
		} catch (Exception e) {
		}
	}
	
	public void selectDepartment(String department ){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			driver.findElement(By.xpath(lbl_Department+department+lbl_Department1)).click();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		} catch (Exception e) {
		}
	}
	
	public void refreshPage(){
		try {
			webActions.refreshPage();webActions.waitForPageLoaded();
		} catch (Exception e) {
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
