package com.ipas.hf.web.pages.ipasPages;

import java.awt.HeadlessException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Sleeper;

import com.ipas.hf.dbutilities.SqlQueries;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;


public class VIMPaymentPage extends BasePage {

	String resetPassword="";
	private RestActions rest = new RestActions();


	@FindBy(xpath = "//input[@formcontrolname='firstName']")
	private WebElement txt_FirstName; 

	@FindBy(xpath = "//p[contains(text(),'Make a payment')]")
	private WebElement lbl_Payment;

	@FindBy(xpath = "(//div[@class='summary-grid']/img)[2]")
	private WebElement img_PaymentStatus;

	@FindBy(xpath = "(//p[contains(@class,'paragraph-progress u-font-robo')])[2]")
	private WebElement lbl_PaymentCount;

	@FindBy(xpath = "//mat-checkbox/label/div")
	private WebElement chk_Payment;

	@FindBy(xpath = "//img[@src='/assets/svg/arrow_right.svg']")
	private WebElement btn_PaymentArrow;

	@FindBy(xpath = "//span[@class='balance-style']")
	private WebElement lbl_TotalBalance;

	@FindBy(xpath = "(//div[@class='button-box']//a)[2]")
	private WebElement btn_Pay;

	@FindBy(xpath = "//mat-label[contains(text(),'Use another card')]")
	private WebElement btn_UseAnotherCard;

	@FindBy(id="nameOnCard")
	private WebElement txt_NameonCard;

	@FindBy(id="cardNumber")
	private WebElement txt_CardNumber;

	@FindBy(id="cardExpiration")
	private WebElement txt_CardExpiration;

	@FindBy(name="CardCvv")
	private WebElement txt_CardCvv;

	@FindBy(id="billingZip")
	private WebElement txt_BillingZip;

	@FindBy(name="SaveCard")
	private WebElement chk_SaveCard;

	@FindBy(id="submitButton")
	private WebElement btn_SubmitButton;

	@FindBy(xpath="//div[@class='status-card']/div[2]")
	private WebElement lbl_SuccessMessage;

	@FindBy(xpath="//a[contains(text(),'Main Page')]")
	private WebElement btn_MainPage;

	@FindBy(xpath="//a[contains(text(),'Receipt')]")
	private WebElement btn_Receipt;

	@FindBy(xpath="//span[@class='content']")
	private WebElement lbl_PayStatus;

	@FindBy(xpath="//div[@class='amount balance-style']/mat-label")
	private WebElement lbl_PaidAmount;

	@FindBy(xpath="//button[@id='download']")
	private WebElement btn_DownloadReceipt;
	
	@FindBy(xpath="//a[contains(text(),'Partial Payment')]")
	private WebElement btn_PartialPayment;
	
	@FindBy(xpath="//input[@formcontrolname='initiatedAmount']")
	private WebElement txt_PartialPayment;
	
	@FindBy(xpath="//div[contains(text(),'Total Payment')]")
	private WebElement lbl_TotalPayment;
	
	@FindBy(xpath="(//div[contains(text(),'Select Card')]/..//p)[1]")
	private WebElement btn_SelectCard;	
	
	@FindBy(xpath="//table[@id='transaction-table_content_table']/tbody/tr/td[3]")
	private List<WebElement> lbl_TransactionAmounts;
	
	@FindBy(xpath="//mat-error[@role='alert']")
	private WebElement lbl_ErrorMessage;
	
	@FindBy(xpath="//div[@class='textLayer']/span")
	private List<WebElement> lbl_PDFReportData;

	VIMLoginPage vim=new VIMLoginPage();
	PaymentFacilitatorPage payment=new PaymentFacilitatorPage();
	Login logIn=new Login();
	ExportExcelPage file=new ExportExcelPage();

	public VIMPaymentPage() {
		PageFactory.initElements(driver, this);
	}


	public void verifyPaymentStatusandPaymentCountIfNoPayment(){
		try {
			StringBuilder verify=new StringBuilder();
			String actCount=getPaymentCount();
			if(actCount.contentEquals("0/0")){
				report.reportPass("Payment count is matched if No pending Payment: "+actCount);
			}else{
				verify.append("Payment count is not matched if No pending Payment:");
				report.reportFail("Payment count is not matched if No pending Payment: "+actCount,true);
			}
			String actPaymentLable=getPaymentLable();
			if(actPaymentLable.contentEquals("Make a payment")){
				report.reportPass("Payment lable name is matched: "+actPaymentLable);
			}else{
				verify.append("Payment lable name is not matched");
				report.reportFail("Payment lable name is not matched: "+actPaymentLable,true);
			}
			String actStatus=getPaymentStatus();
			if(actStatus.contains("success-filled")){
				report.reportPass("Successfully verified payment status if no pending payments");
			}else{
				verify.append("Fail to verify the payment status if no pending payments");
				report.reportFail("Fail to verify the payment status if no pending payments",true);
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyPaymentPanelInVIMHomePage(DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String actCount=getPaymentCount();
			if(actCount.contentEquals(webActions.getDatafromMap(testData, "Payment Count"))){
				report.reportPass("Payment count is matched if No pending Payment: "+actCount);
			}else{
				verify.append("Payment count is not matched if No pending Payment:");
				report.reportFail("Payment count is not matched if No pending Payment: "+actCount,true);
			}
			String actPaymentLable=getPaymentLable();
			if(actPaymentLable.contentEquals(webActions.getDatafromMap(testData, "Title"))){
				report.reportPass("Payment lable name is matched: "+actPaymentLable);
			}else{
				verify.append("Payment lable name is not matched");
				report.reportFail("Payment lable name is not matched: "+actPaymentLable,true);
			}
			String actStatus=getPaymentStatus();
			if(actStatus.contains(webActions.getDatafromMap(testData, "Status"))){
				report.reportPass("Successfully verified payment status if no pending payments");
			}else{
				verify.append("Fail to verify the payment status if no pending payments");
				report.reportFail("Fail to verify the payment status if no pending payments",true);
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String getPaymentCount(){
		return webActions.waitAndGetText(lbl_PaymentCount, "Payment Count");
	}

	public String getPaymentLable(){
		return webActions.waitAndGetText(lbl_Payment, "Payment");
	}

	public String getPaymentStatus(){
		return webActions.getAttributeValue(img_PaymentStatus, "src", "Payment Status");
	}


	public void verifyPaymentStatusandPaymentCountIfHavingPayment(){
		try {
			StringBuilder verify=new StringBuilder();
			String actCount=getPaymentCount();
			if(actCount.contentEquals("0/1")){
				report.reportPass("Payment count is matched when having pending Payment: "+actCount);
			}else{
				verify.append("Payment count is not matched when having pending Payment:");
				report.reportFail("Payment count is not matched when having pending Payment: "+actCount,true);
			}

			String actStatus=getPaymentStatus();
			if(actStatus.contains("card")){
				report.reportPass("Successfully verified payment status when having pending Payments");
			}else{
				verify.append("Fail to verify the payment status when having pending payments");
				report.reportFail("Fail to verify the payment status when having pending payments",true);
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void makeaPayment(DataTable testData){
		try {
			ArrayList<String>expData=new ArrayList<String>(testData.row(1));
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(lbl_Payment, "Payment");
			try {
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.waitAndGetText(btn_Pay, "pay");
			} catch (Exception e) {
			}
			webActions.click(btn_PaymentArrow, "PaymentArrow");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_UseAnotherCard, "UseAnotherCard");
			enterCardDetails("");
			ArrayList<String> actData=new ArrayList<>();
			String actMessage=webActions.waitAndGetText(lbl_SuccessMessage, "Success Message");
			String actPayStatus=webActions.waitAndGetText(lbl_PayStatus, "Pay Status");
			String actPaidAmount=webActions.waitAndGetText(lbl_PaidAmount, "PaidAmount");
			actData.add(actMessage);
			actData.add(actPayStatus);
			actData.add(actPaidAmount);
			report.reportInfo("Expected Payment deatils: "+expData);
			report.reportInfo("Actual Payment deatils: "+actData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully made a full payment");
			}else{
				report.reportFail("Fail to make a full payment: "+unmatch);
			}
			webActions.click(btn_MainPage, "MainPage");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void enterCardDetails(String payType){
		try {
			Thread.sleep(5000);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.switchToiFrame(0);
			webActions.sendKeys(txt_NameonCard, "Jamesh", "Name on Card");
			webActions.sendKeys(txt_CardNumber, "4242424242424242", "CardNumber");
			webActions.sendKeys(txt_CardExpiration, "0125", "CardExpiration");
			webActions.sendKeys(txt_CardCvv, "123", "CardCvv");
			webActions.sendKeys(txt_BillingZip, "00001", "Zip");
			if("Partial".contentEquals(payType)){
				webActions.click(chk_SaveCard, "Save Card");
			}
			webActions.click(btn_SubmitButton, "Submit");
			webActions.switchTodefaultContent();
		} catch (Exception e) {

		}
	}
	
	public void makeAPartialPayment(DataTable testData){
		try {
			ArrayList<String>expData=new ArrayList<String>(testData.row(1));
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(lbl_Payment, "Payment");
			try {
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.waitAndGetText(btn_Pay, "pay");
			} catch (Exception e) {
			}
			webActions.click(btn_PaymentArrow, "PaymentArrow");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_PartialPayment, "Partial Payment button");
			webActions.waitAndClick(txt_PartialPayment, "Partial Payment" );
			webActions.clearValueAndSendKeys(txt_PartialPayment, webActions.getDatafromMap(testData, "Paid Amount"), "Partial Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(lbl_TotalPayment, "Total Payment Label");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_Pay, "pay");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_UseAnotherCard, "UseAnotherCard");
			enterCardDetails("Partial");
			ArrayList<String> actData=new ArrayList<>();
			String actMessage=webActions.waitAndGetText(lbl_SuccessMessage, "Success Message");
			String actPayStatus=webActions.waitAndGetText(lbl_PayStatus, "Pay Status");
			String actPaidAmount=webActions.waitAndGetText(lbl_PaidAmount, "PaidAmount");
			actData.add(actMessage);
			actData.add(actPayStatus);
			actData.add(actPaidAmount);
			report.reportInfo("Expected Payment deatils: "+expData);
			report.reportInfo("Actual Payment deatils: "+actData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully made a partial payment");
			}else{
				report.reportFail("Fail to make a partial payment: "+unmatch);
			}
			webActions.click(btn_MainPage, "MainPage");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void makeAPaymentWithSavedCard(DataTable testData){
		try {
			ArrayList<String>expData=new ArrayList<String>(testData.row(1));
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(lbl_Payment, "Payment");
			try {
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.waitAndGetText(btn_Pay, "pay");
			} catch (Exception e) {
			}
			webActions.click(btn_PaymentArrow, "PaymentArrow");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			
			webActions.waitAndClick(btn_SelectCard, "Select Card");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_Pay, "pay");
			try {
				webActions.waitAndClick(btn_Pay, "pay");
			} catch (Exception e) {
			}
			ArrayList<String> actData=new ArrayList<>();
			String actMessage=webActions.waitAndGetText(lbl_SuccessMessage, "Success Message");
			String actPayStatus=webActions.waitAndGetText(lbl_PayStatus, "Pay Status");
			String actPaidAmount=webActions.waitAndGetText(lbl_PaidAmount, "PaidAmount");
			actData.add(actMessage);
			actData.add(actPayStatus);
			actData.add(actPaidAmount);
			report.reportInfo("Expected Payment deatils: "+expData);
			report.reportInfo("Actual Payment deatils: "+actData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully made a payment with saved card");
			}else{
				report.reportFail("Fail to make a payment with saved card: "+unmatch);
			}
			webActions.click(btn_MainPage, "MainPage");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void navigatePaymentFacilitator(){
		try {
			webActions.waitAndClick(payment.lnk_PaymentFacilitator, "Payment Facilitator");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			//payment.waitforPaymentFacilitatorPage();
			payment.waitforPage();
		} catch (Exception e) {
		}
	}

	public void savePaymentiPAS(DataTable testData){
		payment.savePaymentWithoutValidations(testData);
	}


	public void verifyPaymentDetailsInPaymentFacilitator(DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			ArrayList<String> actLabelNames=payment.getActualLabelNamesinPanel();
			ArrayList<String>expLabelNames=payment.getExpectedLabelNamesinPanel(testData);

			ArrayList<String> unmatchLabels=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchLabels.size()==0){
				report.reportPass("Label names matched successfully in Short Panel: "+actLabelNames);
			}else{
				report.reportFail("Label names are not matched in Short Panel: "+unmatchLabels,true);
				verify.append("Label names are not matched in Short Panel:");
			}
			ArrayList<String> actAmounts=webActions.getDatafromWebTable(payment.lbl_PaymentFacilitator_Amounts_Panel);
			ArrayList<String>expAmounts=payment.getExpectedAmountsinPanelandPage(testData);
			report.reportInfo("Expected Payment Amounts in Short panel: "+expAmounts);
			report.reportInfo("Actual Payment Amounts in Short panel: "+actAmounts);
			ArrayList<String> unmatchAmountsPanel=webActions.getUmatchedInArrayComparision(actAmounts, expAmounts);
			if(unmatchAmountsPanel.size()==0){
				report.reportPass("Payment Amounts matched successfully in Short Panel: "+actAmounts);
			}else{
				report.reportFail("Payment Amounts not matched in Short Panel: "+unmatchAmountsPanel,true);
				verify.append("Payment Amounts not matched in Short Panel");
			}

			String actFCStatusPFPanel=webActions.getAttributeValue(payment.img_FinancialClearanceStatus_PaymentFacilitatorPanel, "src", "Payment Facilitator Panel");
			String expFCStatusPaymentFacilitatorPage=payment.getFinancialClearanceStatus(testData);
			if(actFCStatusPFPanel.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Short Panel");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Short Panel",true);
				verify.append("Failed to verify the Financial Clearance Status in Short Panel");
			}

			navigatePaymentFacilitator();

			ArrayList<String> actPaymentTransactionData=payment.getPaymentTransactionData();

			ArrayList<String> expPaymentTransactionData=getExpectedPaymentTransactionData(testData);

			ArrayList<String> unmatchTransactionData=webActions.getUmatchedInArrayComparision(actPaymentTransactionData, expPaymentTransactionData);
			if(unmatchTransactionData.size()==0){
				report.reportPass("Payment Transaction data is matched: "+actPaymentTransactionData);
			}else{
				report.reportFail("Payment Transaction data is not matched and unmatched data is: "+unmatchTransactionData,true);
				verify.append("Payment Transaction data is not matched");
			}
			ArrayList<String> actPaymentAmountsinPage=payment.getActualAmountsAfterSavePayment();
			ArrayList<String>expAmountsinPage=payment.getExpectedAmountsinPanelandPage(testData);
			report.reportInfo("Expected Payment Amounts after payment is done in the page: "+expAmountsinPage);
			report.reportInfo("Actual Payment Amounts after payment is done in page: "+actPaymentAmountsinPage);
			ArrayList<String> unmatchAmounts=webActions.getUmatchedInArrayComparision(actPaymentAmountsinPage, expAmountsinPage);
			if(unmatchAmounts.size()==0){
				report.reportPass("Payment Amounts matched successfully after payment is done in page: "+actPaymentAmountsinPage);
			}else{
				report.reportFail("Payment Amounts not matched after payment is done in page: "+unmatchAmounts,true);
				verify.append("Payment Amounts not matched after payment is done in page");
			}

			String actFCStatusPaymentFacilitatorPage=payment.getFinClearStatusinPaymentFacilitatorPage();
			if(actFCStatusPaymentFacilitatorPage.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Page");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Page",true);
				verify.append("Failed to verify the Financial Clearance Status in Payment Facilitator Page");
			}

			if(verify.length()!=0){
				report.reportFail(""+verify);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void verifyPaymentDetailsInPaymentFacilitatorForMultipleTransactions(DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			ArrayList<String> actLabelNames=payment.getActualLabelNamesinPanel();
			ArrayList<String>expLabelNames=payment.getExpectedLabelNamesinPanel(testData);

			ArrayList<String> unmatchLabels=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchLabels.size()==0){
				report.reportPass("Label names matched successfully in Short Panel: "+actLabelNames);
			}else{
				report.reportFail("Label names are not matched in Short Panel: "+unmatchLabels,true);
				verify.append("Label names are not matched in Short Panel:");
			}
			ArrayList<String> actAmounts=webActions.getDatafromWebTable(payment.lbl_PaymentFacilitator_Amounts_Panel);
			ArrayList<String>expAmounts=payment.getExpectedAmountsinPanelandPage(testData);
			report.reportInfo("Expected Payment Amounts in Short panel: "+expAmounts);
			report.reportInfo("Actual Payment Amounts in Short panel: "+actAmounts);
			ArrayList<String> unmatchAmountsPanel=webActions.getUmatchedInArrayComparision(actAmounts, expAmounts);
			if(unmatchAmountsPanel.size()==0){
				report.reportPass("Payment Amounts matched successfully in Short Panel: "+actAmounts);
			}else{
				report.reportFail("Payment Amounts not matched in Short Panel: "+unmatchAmountsPanel,true);
				verify.append("Payment Amounts not matched in Short Panel");
			}

			String actFCStatusPFPanel=webActions.getAttributeValue(payment.img_FinancialClearanceStatus_PaymentFacilitatorPanel, "src", "Payment Facilitator Panel");
			String expFCStatusPaymentFacilitatorPage=payment.getFinancialClearanceStatus(testData);
			if(actFCStatusPFPanel.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Short Panel");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Short Panel",true);
				verify.append("Failed to verify the Financial Clearance Status in Short Panel");
			}

			navigatePaymentFacilitator();

			ArrayList<String> actPaymentTransactionData=getPaymentTransactionAmounts();

			ArrayList<String> expPaymentTransactionData=getExpectedPaymentTransactionAmounts(testData);

			ArrayList<String> unmatchTransactionData=webActions.getUmatchedInArrayComparision(actPaymentTransactionData, expPaymentTransactionData);
			if(unmatchTransactionData.size()==0){
				report.reportPass("Payment Transaction Amounts are matched: "+actPaymentTransactionData);
			}else{
				report.reportFail("Payment Transaction Amounts are not matched and unmatched data is: "+unmatchTransactionData,true);
				verify.append("Payment Transaction Amounts are not matched");
			}
			ArrayList<String> actPaymentAmountsinPage=payment.getActualAmountsAfterSavePayment();
			ArrayList<String>expAmountsinPage=payment.getExpectedAmountsinPanelandPage(testData);
			report.reportInfo("Expected Payment Amounts after payment is done in the page: "+expAmountsinPage);
			report.reportInfo("Actual Payment Amounts after payment is done in page: "+actPaymentAmountsinPage);
			ArrayList<String> unmatchAmounts=webActions.getUmatchedInArrayComparision(actPaymentAmountsinPage, expAmountsinPage);
			if(unmatchAmounts.size()==0){
				report.reportPass("Payment Amounts matched successfully after payment is done in page: "+actPaymentAmountsinPage);
			}else{
				report.reportFail("Payment Amounts not matched after payment is done in page: "+unmatchAmounts,true);
				verify.append("Payment Amounts not matched after payment is done in page");
			}

			String actFCStatusPaymentFacilitatorPage=payment.getFinClearStatusinPaymentFacilitatorPage();
			if(actFCStatusPaymentFacilitatorPage.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Page");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Page",true);
				verify.append("Failed to verify the Financial Clearance Status in Payment Facilitator Page");
			}

			if(verify.length()!=0){
				report.reportFail(""+verify);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public ArrayList<String> getExpectedPaymentTransactionData(DataTable testData){
		ArrayList<String> expPaymentTransactionData=new ArrayList<String>();
		expPaymentTransactionData.add("Sale");
		expPaymentTransactionData.add(webActions.getDatafromMap(testData,"Payment"));
		expPaymentTransactionData.add("Approved");
		expPaymentTransactionData.add("Visa XXXXXXXXXXXX4242 Jamesh");
		expPaymentTransactionData.add(payment.getCurrentDateandTime());
		expPaymentTransactionData.add("Receipt");
		expPaymentTransactionData.add("Reversal");
		report.reportInfo("Expected Payment Transaction data is "+expPaymentTransactionData);
		return expPaymentTransactionData;
	}

	public ArrayList<String> getPaymentTransactionAmounts() throws Exception{
		ArrayList<String> actPaymentTransactionData=new ArrayList<String>();
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			payment.waitforPaymentTransactionData();
			List<WebElement>row=lbl_TransactionAmounts;
			for (WebElement webElement : row) {
				String text=webElement.getText();
				if(!text.isEmpty()){
					actPaymentTransactionData.add(text);
				}
			}
			report.reportInfo("Actaul Payment Transaction Amounts: "+actPaymentTransactionData);
		} catch (Exception e) {
			throw e;
		}
		return actPaymentTransactionData;
	}
	
	public void verifyVIMPaymentValidationMessages(DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(lbl_Payment, "Payment");
			try {
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.waitAndGetText(btn_Pay, "pay");
			} catch (Exception e) {
			}
			webActions.click(btn_PaymentArrow, "PaymentArrow");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_PartialPayment, "Partial Payment button");
			webActions.waitAndClick(txt_PartialPayment, "Partial Payment" );
			String amount=webActions.getDatafromMap(testData, "Amount");
			int amt=Integer.parseInt(amount);
			amt=amt+10;
			String paidAmount=String.valueOf(amt);
			webActions.clearValueAndSendKeys(txt_PartialPayment,paidAmount, "Partial Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(lbl_TotalPayment, "Total Payment Label");
			String actMessageGreaterAmount=webActions.waitAndGetText(lbl_ErrorMessage, "lbl_ErrorMessage");
			String expMessageGreaterAmount=webActions.getDatafromMap(testData, "Message1");
			
			expMessageGreaterAmount=expMessageGreaterAmount+amount;
			report.reportInfo("Actual message when Pay the greater than current balance: "+actMessageGreaterAmount);
			report.reportInfo("Expected message when Pay the greater than current balance: "+expMessageGreaterAmount);
			if(actMessageGreaterAmount.contentEquals(expMessageGreaterAmount)){
				report.reportPass("Successfully verified message when Pay the greater than current balance");
			}else{
				report.reportFail("Failed to verify the message when Pay the greater than current balance",true);
				unmatch.append("Failed to verify the message when Pay the greater than current balance");
			}
			
			webActions.waitAndClick(txt_PartialPayment, "Partial Payment" );
			webActions.clearValueAndSendKeys(txt_PartialPayment, "0", "Partial Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(lbl_TotalPayment, "Total Payment Label");
			String actMessageZeroAmount=webActions.waitAndGetText(lbl_ErrorMessage, "lbl_ErrorMessage");
			report.reportInfo("Actual message when Pay with Zero amount value: "+actMessageZeroAmount);
			String expMessageZeroAmount=webActions.getDatafromMap(testData, "Message2");
			report.reportInfo("Expected message when Pay with Zero amount value: "+expMessageZeroAmount);
			if(actMessageZeroAmount.contentEquals(expMessageZeroAmount)){
				report.reportPass("Successfully verified message when Pay with Zero amount value");
			}else{
				report.reportFail("Failed to verify the message when Pay with Zero amount value",true);
				unmatch.append("Failed to verify the message when Pay with Zero amount value");
			}
			
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
			
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void downloadPaymentReceipt (DataTable testData){
		try {
			ArrayList<String>expData=new ArrayList<String>(testData.row(1));
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(lbl_Payment, "Payment");
			try {
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.waitAndGetText(btn_Pay, "pay");
			} catch (Exception e) {
			}
			webActions.click(btn_PaymentArrow, "PaymentArrow");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_UseAnotherCard, "UseAnotherCard");
			enterCardDetails("");
			ArrayList<String> actData=new ArrayList<>();
			String actMessage=webActions.waitAndGetText(lbl_SuccessMessage, "Success Message");
			String actPayStatus=webActions.waitAndGetText(lbl_PayStatus, "Pay Status");
			String actPaidAmount=webActions.waitAndGetText(lbl_PaidAmount, "Paid Amount");
			actData.add(actMessage);
			actData.add(actPayStatus);
			actData.add(actPaidAmount);
			report.reportInfo("Expected Payment deatils: "+expData);
			report.reportInfo("Actual Payment deatils: "+actData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully made a full payment");
			}else{
				report.reportFail("Fail to make a full payment: "+unmatch);
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_Receipt, "Receipt");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			Thread.sleep(5000);
			ArrayList<String>actPDFData=webActions.getDatafromWebTable(lbl_PDFReportData);
			ArrayList<String>data=new ArrayList<String>();
			report.reportInfo("Data in Payment Receipt: "+actPDFData);
			for (int i = 0; i < actPDFData.size(); i++) {
				if(i==9||i==10||i==11){
					String txt=actPDFData.get(i);
					System.out.println(txt+" = in If Con and Row No: "+i);
					data.add(txt);
				}
			}
			report.reportInfo("Paid Amount in the Receipt: "+data);
			String expPaidAmount=webActions.getDatafromMap(testData,"Paid Amount");
			ArrayList<String>unmatchData=webActions.isFullArrayMatchWithData(data, expPaidAmount);
			if(unmatchData.size()==0){
				report.reportPass("Data is matched in the Receipt");
			}else{
				report.reportFail("Data is not matched in the Receipt: "+unmatchData);
			}
			String actCurrentUrl=driver.getCurrentUrl();
			report.reportInfo("Receipt Current URL is: "+actCurrentUrl);
			if(actCurrentUrl.contains("https://qa.myvim.com/payment-facilitator/receipt/d")){
				report.reportPass("Receipt URL is matched");
			}else{
				report.reportFail("Receipt URL is not matched");
			}
			webActions.click(btn_DownloadReceipt, "Download Receipt");
			file.verifyExportExcelDownload("document.pdf");
			
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public ArrayList<String> getExpectedPaymentTransactionAmounts(DataTable testData){
		ArrayList<String> expPaymentTransactionData=new ArrayList<String>();
		expPaymentTransactionData.add(webActions.getDatafromMap(testData,"Paid Amount2"));
		expPaymentTransactionData.add(webActions.getDatafromMap(testData,"Paid Amount1"));
		report.reportInfo("Expected Payment Transaction Amounts: "+expPaymentTransactionData);
		return expPaymentTransactionData;
	}

	public void navigatePatientVisitAllDataPage(){
		try {
			String accountNumber = logIn.getVisitIdFromResponse("$..displayPatientAccountId");
			payment.searchAccountNuberinAccountSearchPage(accountNumber);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}


	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_FirstName);
	}

}
