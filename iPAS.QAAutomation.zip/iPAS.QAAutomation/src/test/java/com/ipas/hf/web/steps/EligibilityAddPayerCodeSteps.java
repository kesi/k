package com.ipas.hf.web.steps;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.ipasPages.AddPatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.EditUserPage;
import com.ipas.hf.web.pages.ipasPages.EligibilityAddPayerCodePage;
import com.ipas.hf.web.pages.ipasPages.SearchPayerPage;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;
public class EligibilityAddPayerCodeSteps {

	EligibilityAddPayerCodePage addPayerCode = new EligibilityAddPayerCodePage();
	RestActions rest=new RestActions();
	AddPatientVisitPage addpatient=new AddPatientVisitPage();
	SearchPayerPage searchpayer = new SearchPayerPage();

	
	@Then("verify Add Payer Code button")
	public void Verify_Add_Payer_Code_button() {
		addPayerCode.verifyAddPayerCodeButton();
	}
	
	@Then("verify when user clicks in Add payer button")
	public void Verify_when_user_clicks_Add_Payer_Code_button() {
		addPayerCode.clickAddPayerCode();
	}
	
	@Then("verify the navigation to maintainance page")
	public void verify_the_navigation_to_maintainance_page() {
		addPayerCode.verifyNavigationToMaintainancePage();
	}
	
	@Then("verify the breadCrumbs in Add Payer")
	public void verify_the_breadCrumbs_in_Add_Payer(DataTable breadcrumb) {
		addPayerCode.verifyBreadCrumbsAddPayer(breadcrumb);
	}
	
	@Then("verify sections under Add Payer Code screen")
	public void verify_the_Sections_under_Add_Payer_Screen(DataTable sections) {
		addPayerCode.verifytheSections(sections);
	}
	
	@Then("verify the Payer Information section in Add Payer")
	public void verify_the_Payer_Information_section_in_Add_Payer(DataTable sections) {
		addPayerCode.verifyPayerInformationSection(sections);
	}
	
	@Then("verify the payer information fields")
	public void verify_the_payer_information_fields() {
		addPayerCode.verifyPayerInformationFields();
	}
	
	@Then("verify the Mandatory fields in Add Payer")
	public void verify_the_Mandatory_fields_in_Add_Payer(DataTable mandatory) {
		addPayerCode.verifyMandatoryFieldValidationMessage(mandatory);
	}
	
	@Then("verify the validation messages when user enters less than minimum characters allowed as {string}")
	public void verify_the_validation_messages_when_user_enters_less_than_minimum_characters_allowed(String length,DataTable mandatory) {
		int len=Integer.parseInt(length);
		String testData=rest.randomString(len);
		addPayerCode.verifyValidationMessageMinimumMaximum(length,testData,mandatory);
	}
	
	@Then("verify the validation messages when user enters more than maximum characters allowed as {string}")
	public void verify_the_validation_messages_when_user_enters_more_than_maximum_characters_allowed(String length,DataTable mandatory) {
		int len=Integer.parseInt(length);
		String testData=rest.randomString(len);
		addPayerCode.verifyValidationMessageMinimumMaximum(length,testData,mandatory);
	}
	
	@Then("verify the connection type section and fields under it")
	public void verify_the_connection_type_section_and_fields_under_it(DataTable sections) {
	    addPayerCode.verifyConnectionTypeSection(sections);
	}
	
	@Then("verify the trash icon,Add new connection button,save and cancel buttons")
	public void verify_the_trash_icon_Add_new_connection_button_save_and_cancel_buttons() {
	   addPayerCode.verifyButtons(); 
	}
	
	@Then("verify if Add New connection is selected and save button is enabled")
	public void verify_if_Add_New_connection_is_selected_and_save_button_is_enabled() {
	   addPayerCode.verifyAddNewConnection();
	}
	
	@Then("verify if user selects Add New connection button multiple times")
	public void verify_if_user_selects_Add_New_connection_button_multiple_times(DataTable messages) {
		addPayerCode.clickAddNewConnectionMultipleTimes(messages);
	}
	
	@Then("verify adding of new payer code with connection as {string}")
	public void verify_adding_of_New_Payer(String connection) {
		String payerDesc=rest.randomString(5);
		addpatient.notepadWrite("hello",payerDesc);
		addpatient.notepadWrite("Connection",connection);
		addPayerCode.AddNewPayerCode(payerDesc,connection);
	}
	
	@Then("verify searching of new payer code added")
	public void verify_searching_of_New_payerCode() throws IOException {
		String payerDesc=addpatient.notepadRead("hello");
		String connection=addpatient.notepadRead("Connection");
		searchpayer.verifySearchFunctionality(payerDesc,connection);
	}
	
	@Then("verify the Active or InActive Toggle")
	public void verify_the_Active_or_InActive_Toggle() throws IOException {
		searchpayer.verifyToggle();
	}
	
	@Then("verify able to toggle the switch to {string}")
	public void verify_able_to_toggle_the_switch(String toggle) throws IOException {
		searchpayer.verifySwitchToggle(toggle);
	}
}