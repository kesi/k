package com.ipas.hf.web.pages.ipasPages;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class ViewMedicalNecessityCustomResponsePage extends BasePage {

	@FindBy(xpath="//span[(text()='Medical Necessity Check')]")
	private WebElement lbl_MedicalNecessityCheckPanel;

	@FindBy(linkText="Medical Necessity Response Configuration")
	private WebElement lnk_MedicalNecessityResponseConfiguration;
	

	@FindBy(xpath="//div[@class='breadcrum-container']")
	private List<WebElement> lbl_Breadcrum_All;

	@FindBy(xpath="//div[@class='search-bar']//child::label")
	private List<WebElement> lbl_FieldNames;

	@FindBy(xpath="//div[@class='search-result']//child::th//div//span")
	private List<WebElement> lbl_HeaderNames;

	@FindBy(xpath="//ejs-dropdownlist[contains(@id,'ej2_dropdownlist')]/span/input")
	private WebElement dd_ResponseType;
	
	@FindBy(xpath="//div[@class='e-gridcontent']/div/table/tbody/tr")
	private List<WebElement> tr_Results;
	
	@FindBy(xpath="//div[@class='e-gridcontent']/div/table/tbody/tr/td[7]/div")
	private List<WebElement> icon_DeleteAll;
	
	@FindBy(xpath="//div[@class='e-gridcontent']/div/table/tbody/tr/td[2]/div/a")
	private List<WebElement> lnk_CPTCodes;
	
	public ViewMedicalNecessityCustomResponsePage() {
		PageFactory.initElements(driver, this);
	}

	
	public void changeResponseType(String responseType){
		try {
			webActions.sendKeys(dd_ResponseType, responseType, "Response Type");
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyGridHeaderNamesForCustomResponseType(DataTable headerNames){
		try {
			ArrayList<String> expHeaderNames=new ArrayList<>(headerNames.asList());
			ArrayList<String> actHeaderNames=webActions.getDatafromWebTable(lbl_HeaderNames);
			report.reportInfo("Actual Header Names: "+actHeaderNames);
			report.reportInfo("Expected Header Names: "+expHeaderNames);
			ArrayList<String>unmatcHeaderNames=webActions.getUmatchedInArrayComparision(actHeaderNames, expHeaderNames);
			if(unmatcHeaderNames.size()==0){
				report.reportPass("Verified Result Grid Header Names for Custom Response Type");
			}
			else{
				report.reportFail("Fail to verify Result Grid Header Names for Custom Response Type"+unmatcHeaderNames);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyTrashIconForCustomResponseCodes(String iconName){
		try {
			webActions.waitForVisibilityOfAllElements(icon_DeleteAll, "Delete Icons");
			ArrayList<String> actTrashIcons=webActions.getListofAttributeValuesfromWebPage(icon_DeleteAll, "class");
			report.reportInfo("Actual Trash Icons: "+actTrashIcons);
			report.reportInfo("Expected Trash Icon: "+iconName);
			ArrayList<String>unmatcTrashIcons=webActions.isFullArrayMatchWithData(actTrashIcons, iconName);
			if(unmatcTrashIcons.size()==0){
				report.reportPass("Verified Trash Icon for all Custom Response Type Codes");
			}
			else{
				report.reportFail("Fail to verify Trash Icon for all Custom Response Type Codes"+unmatcTrashIcons);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void verifyCPTCodeasHyperlinkForCustomResponseCodes(){
		try {
			webActions.waitForVisibilityOfAllElements(lnk_CPTCodes, "CPT Codes");
			ArrayList<String> actTrashIcons=webActions.getListofAttributeValuesfromWebPage(lnk_CPTCodes, "href");
			ArrayList<String>unmatcTrashIcons=webActions.isFullArrayMatchWithData(actTrashIcons, "edit");
			if(unmatcTrashIcons.size()==0){
				report.reportPass("Verified all CPT Codes as Hyperlink for Custom Response Type Codes");
			}
			else{
				report.reportFail("Fail to verify CPT Codes as Hyperlinks for all Custom Response Type Codes"+unmatcTrashIcons);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}


	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(lnk_MedicalNecessityResponseConfiguration);
	}

}
