package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.PatientVisitCardFinancialStatusPage;

import cucumber.api.java.en.Then;

public class PatientVisitCardFinancialStatusSteps {
	
	PatientVisitCardFinancialStatusPage pVCFStatus=new PatientVisitCardFinancialStatusPage();
	
	@Then("Verify the visit card financial clearance status")
	public void verify_the_visit_card_financial_clearance_status() {
		pVCFStatus.verifyVisitCardFinancialStatus();
	}
	
	@Then("Change the Service tracker status to review from visit card")
	public void change_the_Service_tracker_status_to_review_from_visit_card() {
		pVCFStatus.changeServiceTrackerToReviewFromVisitCard();
	}

	@Then("Verify the visit card financial clearance status after other module status changed")
	public void verify_the_visit_card_financial_clearance_status_after_other_module_status_changed() {
		pVCFStatus.verifyVisitCardFinanceClearanceStatus();
	}
	
	}
