package com.ipas.hf.web.steps;

import java.util.Properties;

import org.json.simple.parser.ParseException;

import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.utilities.ConfigProperties;
import com.ipas.hf.web.pages.ipasPages.DisplayMessageNotificationAlertPage;
import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DisplayMessageNotificationAlertSteps {
	private ConfigProperties configProp = TestBase.prop;
	DisplayMessageNotificationAlertPage notificationAlert = new DisplayMessageNotificationAlertPage();
	HomePage page=new HomePage();

	@Then("Get PhoneNumber from JSON and Update in MessageAlert Json File")
	public void get_PhoneNumber_from_JSON_and_Update_in_MessageAlert_Json_File() throws ParseException {
		String phoneNumber = notificationAlert.getPhoneNumberfromJSONresponse();
		notificationAlert.updateAddressInMsgAlert(phoneNumber);
	}

	@Then("Verify display of MessageCount on VisitCard as {string}")
	public void verify_display_of_MessageCount_on_VisitCard(String count) throws Exception {
		notificationAlert.msgCountOnVisitCard(count);
	}

	@Then("Open Message Icon verify label PATIENT")
	public void open_Message_Icon_verify_label_PATIENT() throws Exception {
		notificationAlert.clickAndOpenMsgHub();
	}

	@Then("Verify message Count on Visit Card and Message Hub")
	public void verify_message_Count_on_Visit_Card_and_Message_Hub(String count) throws Exception {
		notificationAlert.compareMsgCount(count);
	}

	@Then("Verify message text in Message Hub on Visit Card: {string}")
	public void verify_message_text_in_Message_Hub_on_Visit_Card(String count) throws Exception {
		notificationAlert.verifyMSgTextinMsgHub(count);
	}


	@Then("Verify Posted Msg Count on MessageHub on ST Panel as {string}")
	public void verify_Posted_Msg_Count_on_MessageHub_on_ST_Panel_as(String count) throws Exception {
		notificationAlert.verifyMsgCountFromVisitCard(count);
	}

	@Then("Verify Message Hub beside Service Trakcer Panel")
	public void verify_Message_Hub_beside_Service_Trakcer_Panel() {
		notificationAlert.verifyMessageHubBesideServiceTrakcer();
	}

	@Then("Verify Close button and close Message Hub window")
	public void verify_Close_button_and_close_Message_Hib_window() throws Exception {
		notificationAlert.clickCloseButtonInMessageHub();
	}

	@Then("Send Message from Message Hub to Patient as {string}")
	public void send_Message_from_Message_Hub(String text) throws Exception {
		notificationAlert.sendMessagefromMessageHubOnVisitCard(text);
	}

	@Then("Wait for Service Tracker Page loaded")
	public void wait_for_Service_Tracker_Page_loaded() throws Exception {
		notificationAlert.waitforServiceTrackerPageLoad();
	}
	@Then("Verify the display of {string} on message hub")
	public void verify_the_display_of_on_message_hub(String data) {
		notificationAlert.verifyPatientName(data);
	}
	@Then("Verify the display of Opted out message hub icon on patient visit")
	public void verify_the_display_of_Opted_out_message_hub_icon_on_patient_visit() {
		notificationAlert.verifyOptOutLcokIcon();
	}
	@Then("Navigate to the Account Search from other pages")
	public void navigate_to_the_Account_Search_from_other_pages() {
		page.navigateToAccountSearchFromOtherPages();
	}
	@Then("Verify the display of Opted out message hub icon from message hub")
	public void verify_the_display_of_Opted_out_message_hub_icon_from_message_hub() {
		notificationAlert.verifyOptOutLcokIconFromMesgHubAndTracker();

	}
	@Then("Verify the lock icon on patient visit card")
	public void verify_the_lock_icon_on_patient_visit_card() {
		notificationAlert.verifyNoteLock();
	}

	@Then("Verify the display of unlock info from message hub")
	public void verify_the_display_of_unlock_info_from_message_hub() {
		notificationAlert.verifyOptOutUnLcokIconFromMesgHub();
	}

	@Then("Verify the display of unlock info from visit card message hub")
	public void verify_the_display_of_unlock_info_from_visit_card_message_hub() {
		notificationAlert.verifyOptOutUnLcokIconFromTracker();
	}
}
