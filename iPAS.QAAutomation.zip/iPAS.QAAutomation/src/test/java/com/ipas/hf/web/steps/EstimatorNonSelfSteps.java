package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.EstimatorNonSelfPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class EstimatorNonSelfSteps {

	EstimatorNonSelfPage nonSelf=new EstimatorNonSelfPage();

	@Then("Verify the display of estimator short panel status as {string}")
	public void verify_the_display_of_estimator_short_panel_status_as(String status) {
		nonSelf.verifyEstimatorShortPanelStatus(status);
	}

	@Then("Verify the display of message on short panel as {string}")
	public void verify_the_display_of_message_on_short_panel_as(String msg) {
		nonSelf.verifyEstimatorShortPanelMsg(msg);
	}

	@Then("Verify expand and collapse of the estimator Panel")
	public void verify_expand_and_collapse_of_the_estimator_Panel() throws Exception {
		nonSelf.verifyExpandandCollapsePanel();
	}

	@Then("Verify the short panel title as {string}")
	public void verify_the_short_panel_title_as(String title) {
		nonSelf.verifyEstimatorShortPanelTitle(title);
	}

	@Then("Click on search icon and verify navigation")
	public void click_on_search_icon_and_verify_navigation() {
		nonSelf.clickSearchIconOnShortPanel();
	}
	@Then("Click on Estimator short panel link")
	public void click_on_Estimator_short_panel_link() {
		nonSelf.clickOnEstimatorShortPanel();
	}
	@Then("Verify the display of estimator full panel status as {string}")
	public void verify_the_display_of_estimator_full_panel_status_as(String status) {
		nonSelf.verifyEstimatorFullPanelStatus(status);
	}

	@Then("Verify the display of message on full panel as {string}")
	public void verify_the_display_of_message_on_full_panel_as(String msg) {
		nonSelf.verifyEstimatorFullPanelMsg(msg);
	}
	@Then("Verify the display of fileds and lables")
	public void verify_the_display_of_fileds_and_lables(DataTable dataTable) {
		nonSelf.verifyEstimatorFullPage(dataTable);
	}

	@Then("Verify the provider information from estimator full page")
	public void verify_the_provider_information_from_estimator_full_page() {
		nonSelf.verifyProviderName();
	}
	@Then("Verify the insuarance plan name on estimator summary section")
	public void verify_the_insuarance_plan_name_on_estimator_summary_section() {
		nonSelf.verifyPlanName();
	}
	@Then("Verify the Eligibility run time on estimator summary section")
	public void verify_the_Eligibility_run_time_on_estimator_summary_section() {
		nonSelf.verifyEligibilityRunTime();
	}
	@Then("Verify the cpt code from estimate full page")
	public void verify_the_cpt_code_from_estimate_full_page() {
		nonSelf.verifyEMRCptCodeInfo();
	}
	/*@Then("Add the new cpt code as {string} to the estimate")
	public void add_the_new_cpt_code_as_to_the_estimate(String cptCode) {
	   nonSelf.addCPTCode(cptCode);
	}*/
	@Then("Add the new cpt code as {string} to the estimate as {string}")
	public void add_the_new_cpt_code_as_to_the_estimate_as(String cptCode, String condition) {
		nonSelf.addCPTCode(cptCode,condition);
	}

	@Then("Delete the EMR CPT")
	public void delete_the_EMR_CPT() {
		nonSelf.deleteEMRCPTCode();
	}

	@Then("Click on Estimate Save")
	public void click_on_Estimate_Save() {
		nonSelf.clickEstimateSave();
	}

	@Then("Navigate back to the visit main page")
	public void navigate_back_to_the_visit_main_page() {
		nonSelf.goToVisitMainPageFromEstimatorFullPage();
	}
	@Then("Verify the display of procedure codes from visit information panel")
	public void verify_the_display_of_procedure_codes_from_visit_information_panel(DataTable dataTable) {
		nonSelf.verifyProcedureCodesFromAllData(dataTable);
	}	

	@Then("Select the Save button from add cpt window")
	public void select_the_Save_button_from_add_cpt_window() {
		nonSelf.CptWindowSave();
	}
	@Then("Enter invalid data as {string} in searchbox and verify the message as {string} and close the window as {string}")
	public void enter_invalid_data_as_in_searchbox_and_verify_the_message_as_and_close_the_window_as(String cptCode, String msg, String window) {
		nonSelf.verifyValidationMsgInCptAndChargeMaster(cptCode, msg, window);
	}

	@Then("Verify the message for added rev codes as {string}")
	public void verify_the_message_for_added_rev_codes_as(String msg) {
		nonSelf.verifyRevCodeMsg(msg);
	}
	@Then("Add the new Rev codes from charge master window as {string}")
	public void add_the_new_Rev_codes_from_charge_master_window_as(String type,DataTable testData) {
		//	nonSelf.addRevCodes(type, testData);
	}

	/*@Then("Add the new Rev codes from charge master window as {string} and type as {string}")
	public void add_the_new_Rev_codes_from_charge_master_window_as_and_type_as(String window, String type,DataTable testData) {
		nonSelf.addRevCodes(window,type, testData);
	}*/

	@Then("Add the new Rev codes from charge master window as {string} and type as {string} and units as {string}")
	public void add_the_new_Rev_codes_from_charge_master_window_as_and_type_as_and_units_as(String window, String type, String unit,DataTable testData) {
		nonSelf.addRevCodes(window,type,unit, testData);
	}
	@Then("Verify the added cpt information")
	public void verify_the_added_cpt_information(DataTable dataTable) {
		nonSelf.verifyAddedCptCodeInfo(dataTable);
	}

	@Then("Verify the added revenue code information")
	public void verify_the_added_revenue_code_information(DataTable dataTable) {
		nonSelf.verifyRevenueCodeInfo(dataTable);

	}
	@Then("Go to the edit cpt window and cpts as {string}")
	public void go_to_the_edit_cpt_window_and_cpts_as(String condition) {
		nonSelf.EditCPTCode(condition);
	}

	@Then("Expand the CPT code")
	public void expand_the_CPT_code() {
		nonSelf.expandCPTBundle();
	}
	@Then("Uncheck the previously added revenue code")
	public void uncheck_the_previously_added_revenue_code() {
		nonSelf.unCheckTheFirstRevCode();
	}
	@Then("calculate the CPT and RevCode amounts as {string}")
	public void calculate_the_CPT_and_RevCode_amounts_as(String unit) {
		nonSelf.cptRevAmountsCalculations(unit);
	}
	@Then("Click on the Benefist icon")
	public void click_on_the_Benefist_icon() {
		nonSelf.clickBenefitsIcon();
	}

	@Then("Verify the default benefits display")
	public void verify_the_default_benefits_display(DataTable dataTable) {
		nonSelf.verifyDefaultBenefits(dataTable);
	}

	@Then("Verify the default servcie name as {string}")
	public void verify_the_default_servcie_name_as(String expData) {
		nonSelf.verifyBenefitsServcieName(expData);
	}

	@Then("Verify the default benefist amounts")
	public void verify_the_default_benefist_amounts(io.cucumber.datatable.DataTable dataTable) {
		nonSelf.verifyDefaultBenefitsAmounts(dataTable);
	}
	@Then("Verify the Estimate charge amount")
	public void verify_the_Estimate_charge_amount() {
		nonSelf.calculateEstimateChargeAmt();
	}

	@Then("Enter estimate allowable amount manually as {string}")
	public void enter_estimate_allowable_amount_manually_as(String amt) {
		nonSelf.enterAllowableAmount(amt);
	}

	@Then("Verify the copay deductible coinsurance values")
	public void verify_the_copay_deductible_coinsurance_values(DataTable dataTable) {
		nonSelf.verifyCoPayCoInsuranceDeductible(dataTable);
	}

	@Then("Verify the Estimate before discount amount")
	public void verify_the_Estimate_before_discount_amount() {
		nonSelf.verifyEstimateBeforeDiscount();
	}

	@Then("Verify the estimate patient total and total patient responsibility")
	public void verify_the_estimate_patient_total_and_total_patient_responsibility() {
		nonSelf.VerifyTotalPatientResponsibility();
	}
	@Then("Select the benefits")
	public void select_the_benefits() {
		nonSelf.selectBenefits();
	}

	@Then("Verify the display of servcie name")
	public void verify_the_display_of_servcie_name(DataTable dataTable) {
		nonSelf.verifyServcieName(dataTable);
	}
	@Then("Click on benefits Save")
	public void click_on_benefits_Save() {
		nonSelf.clickBenefitsSave();
	}
	@Then("Update the copay deductible coinsurance values")
	public void update_the_copay_deductible_coinsurance_values(DataTable dataTable) {
		nonSelf.enterValuesInCoPayDeductibleCoInsurance(dataTable);
	}
	@Then("Cancel the Benefits window")
	public void cancel_the_Benefits_window() {
		nonSelf.cancleBenefitsWindow();
	}
	@Then("Click on the Review Benefist icon")
	public void click_on_the_Review_Benefist_icon() {
		nonSelf.clickReviewBenefitsIcon();
	}
	@Then("Click on Send To Digital Document")
	public void click_on_Send_To_Digital_Document() {
		nonSelf.clickSendToDigitalDocument();
	}

	@Then("Submit the form and verify")
	public void submit_the_form_and_verify() {
		nonSelf.submitEstimatorForm();
	}
	@Then("Submit the estimate form")
	public void submit_the_estimate_form() {
		nonSelf.submitEstimateFormFromDD();
	}
	@Then("Verify the display of digital document status of {string} after estimate form submitted")
	public void verify_the_display_of_digital_document_status_of_after_estimate_form_submitted(String panel) {
		nonSelf.verifyDDModuleStatus(panel);
	}



}