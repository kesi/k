package com.ipas.hf.web.steps;


import org.json.simple.parser.ParseException;

import com.ipas.hf.web.pages.ipasPages.EstimatorSelfPayPage;
import com.ipas.hf.web.pages.ipasPages.FinancialAssistanceQualifierPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class FinancialAssistanceQualifierSteps {

	FinancialAssistanceQualifierPage faq=new FinancialAssistanceQualifierPage();



	@Then("Update FAQ JSON file")
	public void update_FAQ_JSON_file() throws ParseException {
		faq.updateFAQJSON();
	}

	@Then("Verify FAQ default short panel")
	public void verify_FAQ_default_short_panel(DataTable testData) {
		faq.verifyDefaultDatainFAQShortPanel(testData);
	}

	@Then("Verify FAQ default full page")
	public void verify_FAQ_default_full_page(DataTable testData) {
		faq.verifyDefaultDatainFAQFullPage(testData);
	}

	@Then("Navigate to FAQ full page")
	public void navigate_to_FAQ_full_page() {
		faq.navigateFAQFullpage();
	}

	@Then("Create New Case")
	public void create_New_Case() {
		faq.createNewCase();
	}

	@Then("Verify the page navigation to Eligibility")
	public void verify_the_page_navigation_to_Eligibility(DataTable testData) {
		faq.navigationtoEligibilityFromEvaluationTab(testData);
	}

	@Then("Navigate to Estimate")
	public void navigate_to_Estimate() {
		faq.navigateEstimate();
	}

	@Then("Verify the Estimated Id and Estimated Amount and Validate Go To Estimator link")
	public void verify_the_Estimated_Id_and_Estimated_Amount_and_Validate_Go_To_Estimator_link(DataTable testData) {
		faq.navigateFAQfromEstimateAndVerifyEstimatedAmount(testData);
	}

	@Then("Verify Propensity to Pay Credit Score and Breadcrumb")
	public void verify_Propensity_to_Pay_Credit_Score_and_Breadcrumb(DataTable testData) {
		faq.verifyP2P(testData);
	}
	
	@Then("Verify the Add and View Note for Case")
	public void verify_the_Add_and_View_Note_for_Case(DataTable testData) {
	   faq.AddViewCaseNote(testData);
	}
	
	@Then("Change the Case status and verify the data")
	public void change_the_Case_status_and_verify_the_data(DataTable testData) {
	   faq.changeStatusVerifyData(testData);
	}
	
	@Then("Navigate and Add Program {string}")
	public void navigate_and_Add_Program(String program) {
	   faq.addPrograms(program);
	}

	@Then("Approve Program with Discount")
	public void approve_Program_with_Discount(DataTable testData) {
	   faq.approveProgramWithDiscount(testData);
	}

	@Then("Veirfy the Patient Responsibility Estimate Amount in Payment Facilitator")
	public void veirfy_the_Patient_Responsibility_Estimate_Amount_in_Payment_Facilitator() {
	    faq.VerifyEstimateAmountinPaymentFacilitator();
	}
	
	@Then("Approve Program with Discount and Send To Payement Facilitator")
	public void approve_Program_with_Discount_and_Send_To_Payement_Facilitator(DataTable testData) {
	    faq.navigateFAQfromEstimateandSendToPaymentFacilitator(testData);
	}

	@Then("Verify Account in FAQ if Case is not created {string}")
	public void verify_Account_in_FAQ_if_Case_is_not_created(String expMessage) {
	   faq.verifyNoMatchesFound(expMessage);
	}

	@Then("Verify the FAQ data in Worklist")
	public void verify_the_FAQ_data_in_Worklist(DataTable testData) {
	  faq.getFAQDataAndVerifyInWorkilits(testData);
	}
	
	@Then("Navigate to {string} full page from Need Attention in Account Search")
	public void navigate_to_full_page_from_Need_Attention_in_Account_Search(String moduleName) {
		faq.navigateFullPageNeedAttentioninAccountSearch(moduleName);
	}


}