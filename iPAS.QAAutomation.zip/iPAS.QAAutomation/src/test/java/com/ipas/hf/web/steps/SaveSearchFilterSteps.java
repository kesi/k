package com.ipas.hf.web.steps;


import com.ipas.hf.web.pages.ipasPages.SaveSearchFilterPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class SaveSearchFilterSteps {

	SaveSearchFilterPage saveFilter=new SaveSearchFilterPage();


	@Then("Verify the display of tools icon on the top right side of Columns button")
	public void verify_the_display_of_tools_icon_on_the_top_right_side_of_Columns_button() {
		saveFilter.verifyfields();
	}

	@Then("Click on tools menu and verify the list of options")
	public void click_on_tools_menu_and_verify_the_list_of_options(DataTable options) {
		saveFilter.verifyToolsOptions(options);
	}

	@Then("Click on tools menu and verify the menu name as {string}")
	public void click_on_tools_menu_and_verify_the_menu_name_as(String menuName) {
		saveFilter.verifyToolsMenuTitle(menuName);
	}

	@Then("Click on tools menu and select the required option from tools menu list as {string}")
	public void click_on_tools_menu_and_select_the_required_option_from_tools_menu_list_as(String optionToSelect) throws Exception {
		saveFilter.clickOnRequiredOptionFromToolsMenu(optionToSelect);
	}

	@Then("Verify the display of save filter model window title as {string}")
	public void verify_the_display_of_save_filter_model_window_title_as(String windowTitle) {
		saveFilter.verifySaveFilterModelWindowTitle(windowTitle);
	}

	@Then("Verify the display of fields on the Save Filter Model window")
	public void verify_the_display_of_fields_on_the_Save_Filter_Model_window(DataTable fields) {
		saveFilter.verifyFieldsInSaveFilterWindow(fields);
	}
	@Then("Verify the display of Save button on the Save Filter Model window")
	public void verify_the_display_of_Save_button_on_the_Save_Filter_Model_window() {
		saveFilter.verifySaveButton();
	}
	@Then("Click on save button without entering the filterName and verfiy message as {string}")
	public void click_on_save_button_without_entering_the_filterName_and_verfiy_message_as(String errormsg) {
		saveFilter.verifyFilterErrorMsg(errormsg);
	}

	@Then("Verify the default display mode with disabled as {string}")
	public void verify_the_default_display_mode_with_disabled_as(String value) {
		saveFilter.verifyOverWriteExistingMode(value);
	}

	@Then("Click on filter toggle")
	public void click_on_filter_toggle() throws InterruptedException {
		saveFilter.clickOnToggle();
	}	

	@Then("Enter filter name in Filter Name field and click on Save button")
	public void enter_filter_name_in_Filter_Name_field_and_click_on_Save_button() {
		saveFilter.enterDataInFilterNameField();
	}

	@Then("Verify the filter message title as {string} and content as {string}")
	public void verify_the_filter_message_title_as_and_content_as(String title, String content) {
		saveFilter.getfilterMessages(title,content);
	}

	@Then("Select the filter as {string}")
	public void select_the_filter_as(String filterName) {
		saveFilter.selectFilterName(filterName);
	}
	@Then("Create a filter with existing filter name")
	public void create_a_filter_with_existing_filter_name() {
		saveFilter.verifySaveFilterUnique();
	}

	@Then("Enter filter name as more than {int} characters in Filter Name field and click on Save button")
	public void enter_filter_name_as_more_than_characters_in_Filter_Name_field_and_click_on_Save_button(Integer int1) {
		saveFilter.enterFilterNameMoreThan25();
	}

	@Then("Verify the error message as {string}")
	public void verify_the_error_message_as(String errorMsg) {
		saveFilter.verifyFilterMaxErrorMsg(errorMsg);
	}
	@Then("Enter filter name with special characters and click on save button")
	public void enter_filter_name_with_special_characters_and_click_on_save_button() {
		saveFilter.enterFilterNameWithSpecialChar();
	}
	@Then("Create new filter and verify the same in filter drop dwon")
	public void create_new_filter_and_verify_the_same_in_filter_drop_dwon() {
		saveFilter.verifyFilterinFilterDropDown();
	}
	@Then("Select filter as {string} and enter data as {string}")
	public void select_filter_as_and_enter_data_as(String filterName, String filterData) {
		saveFilter.selectFilterAndEnterData(filterName, filterData);
	}

	@Then("Verify the filter {string} value as {string} and verify the results in Column as {string}")
	public void verify_the_filter_value_as_and_verify_the_results_in_Column_as(String filterName, String filterData, String columnName) throws Exception {
		saveFilter.verifyDatainResultsGrid(filterName, filterData, columnName);
	}

	@Then("Create new filter and select the same from filter drop down after unselecting the filter as {string}")
	public void create_new_filter_and_select_the_same_from_filter_drop_down_after_unselecting_the_filter_as(String filterName) {
		saveFilter.createAndSelectFilterFromFilterDropDown(filterName);
	}

	@Then("Verify the filterName field mode")
	public void verify_the_filterName_field_mode() {
		saveFilter.verifyFilterNameMode();
	}

	@Then("Click on cross option and verify the closing of model window")
	public void click_on_cross_option_and_verify_the_closing_of_model_window() {
		saveFilter.closeSaveFilterWindow();
	}

	@Then("Create new filter and select the filter as {string} change the value as {string} and overwrite with created filter from tools menu as {string}")
	public void create_new_filter_and_select_the_filter_as_change_the_value_as_and_overwrite_with_created_filter_from_tools_menu_as(String filterName, String gendertype, String optionToSelect) {
		saveFilter.verifyOvwriteFilterinOverwriteExisting(filterName,gendertype,optionToSelect);
	}

	@Then("Verify the display of Filter Settings model window title as {string}")
	public void verify_the_display_of_Filter_Settings_model_window_title_as(String title) {
		saveFilter.verifyFilterSettingsModelWindowTitle(title);
	}

	@Then("Verify the display of fields as {string} on the Filter Settings Model window")
	public void verify_the_display_of_fields_as_on_the_Filter_Settings_Model_window(String fields) {
		saveFilter.verifyFilterSettingsModelWindowFields(fields);
	}

	@Then("Verify the display of Save button on the Filter Settings Model window")
	public void verify_the_display_of_Save_button_on_the_Filter_Settings_Model_window() {
		saveFilter.verifyFilterSettingsSaveButton();
	}

	@Then("Click on cross option and verify the closing of filter setting model window")
	public void click_on_cross_option_and_verify_the_closing_of_filter_setting_model_window() {
		saveFilter.closeFilterSettingsWindow();
	}	

	@Then("Create new filter and delete the same filter from as {string} and verify filter message title as {string} and content as {string}")
	public void create_new_filter_and_delete_the_same_filter_from_as_and_verify_filter_message_title_as_and_content_as(String option, String title, String content) throws Exception {
		saveFilter.createAndDeleteFilterFromFilterSettings(option,title,content);
	}
	@Then("Verify the default display sorting order of saved filters")
	public void verify_the_default_display_sorting_order_of_saved_filters() {
		saveFilter.verifyFilterSortOrder();
	}	
	@Then("Create a filter from list as {string} with deleted filter from as {string} and verify filter message title as {string} and content as {string}")
	public void create_a_filter_from_list_as_with_deleted_filter_from_as_and_verify_filter_message_title_as_and_content_as(String option1, String option2, String title, String content) throws Exception {
		saveFilter.createFilterWithDeletedFilterName(option1,option2,title,content);
	}
}