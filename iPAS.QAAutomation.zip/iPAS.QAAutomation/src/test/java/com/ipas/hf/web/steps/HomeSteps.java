package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.HomePage;

import cucumber.api.java.en.Then;

public class HomeSteps {

	HomePage homePage=new HomePage();
	
	
	@Then("Navigate to Account Search Page")
	public void navigate_to_Account_Search_Page() {
		homePage.navigateToAccountSearch();
	}
	
	@Then("Navigate to Service Tracker Page")
	public void navigate_to_Service_Tracker_Page() {
		homePage.navigateToServiceTracker();
	}
	
	@Then("Navigate to Maintenance Page")
	public void navigate_to_Maintenance_Page() {
		homePage.navigateToMaintenance();
	}
	@Then("Navigate to WorkList Page")
	public void navigate_to_WorkList_Page() {
	  homePage.navigateToWorList();
	}

	
}	


