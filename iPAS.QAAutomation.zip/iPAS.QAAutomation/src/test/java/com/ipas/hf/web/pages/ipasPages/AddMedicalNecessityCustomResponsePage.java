package com.ipas.hf.web.pages.ipasPages;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class AddMedicalNecessityCustomResponsePage extends BasePage {

	@FindBy(xpath="//span[(text()='Medical Necessity Check')]")
	private WebElement lbl_MedicalNecessityCheckPanel;

	@FindBy(linkText="Medical Necessity Response Configuration")
	private WebElement lnk_MedicalNecessityResponseConfiguration;

	@FindBy(xpath="//span[@class='breadcrum-active']")
	private WebElement lbl_Breadcrum;

	@FindBy(xpath="//span[(text()='Medical Necessity Check')]/../../..")
	private WebElement atr_MedicalNecessityCheck;

	@FindBy(xpath="//a[(text()='Medical Necessity Response Configuration')]/../../div[2]")
	private WebElement lbl_MedicalNecessityCheckPanelHelpText;

	@FindBy(xpath="//div[contains(@class,'breadcrum-container')]/span")
	private List<WebElement> lbl_Breadcrum_All;

	@FindBy(xpath="//div[@class='header']/p")
	private List<WebElement> lbl_HeaderFieldNames;

	@FindBy(xpath="//div[@class='content']//child::label")
	private List<WebElement> lbl_FieldNames;

	@FindBy(xpath="//div[@class='payers-wrapper']//child::p")
	private List<WebElement> lbl_FieldNames1;

	@FindBy(xpath="//div[@class='footer']//child::button")
	private List<WebElement> lbl_ButtonNames;

	@FindBy(xpath="//div[@class='search-result']//child::th//div//span")
	private List<WebElement> lbl_HeaderNames;

	@FindBy(xpath="//ejs-dropdownlist[contains(@id,'ej2_dropdownlist')]/span/input")
	private WebElement dd_ResponseType;

	@FindBy(xpath="//ejs-dropdownlist[@id='ddlelement']//span//input")
	private WebElement dd_Facility;

	@FindBy(linkText="Add New Response")
	private WebElement btn_AddNewResponse;

	@FindBy(xpath="//ul[@role='presentation']/li/div/span")
	private List<WebElement> li_AllPayers;

	@FindBy(xpath="//p[@class='error']")
	private List<WebElement> lbl_ErrorMessages;

	@FindBy(xpath="//button[text()='Cancel']")
	private WebElement btn_Cancel;

	@FindBy(xpath="//button[text()='Save']")
	private WebElement btn_Save;

	@FindBy(xpath="//textarea[@formcontrolname='customResponse']")
	private WebElement txt_CPTCustomResponse;

	@FindBy(xpath="//img[@alt='iPAS Logo']")
	private WebElement img_iPASLogo;

	@FindBy(xpath="//div[@id='_title']")
	private WebElement lbl_DialogTitle;

	@FindBy(xpath="//div[@role='dialog']//div[@id='_dialog-content']")
	private WebElement lbl_DialogContent;

	@FindBy(xpath="//button[@title='Close']/span")
	private WebElement btn_CloseX;

	@FindBy(xpath="//button[(text()='Discard')]")
	private WebElement btn_Discard;

	@FindBy(xpath="//button[@type='button'][text()='Save']")
	private WebElement btn_Save_AlertPopup;

	@FindBy(xpath="//ejs-dropdownlist[@id='ddlelement']/span/span[2]")
	private WebElement dd_ResponseStatus;

	@FindBy(xpath="//div[@class='content']/form/div[2]/div/div/input")
	private WebElement txt_CPT_Code;

	@FindBy(xpath="//input[@placeholder='Type Code or Key Word']")
	private WebElement txt_Code;

	@FindBy(xpath="//tr[@role='row']/td")
	private List<WebElement> li_CodeList_All;

	@FindBy(xpath="//tr[@role='row'][1]/td[1]")
	private WebElement li_CodeList;

	@FindBy(xpath="//div[@class='action-buttons']/button[2]")
	private WebElement btn_Select;

	@FindBy(xpath="//div[@class='content']/form/div[3]/div/div/input")
	private WebElement txt_ICD_Code;

	@FindBy(id="search_text")
	private WebElement txt_AssignedPayers;

	@FindBy(xpath="//ul[@role='presentation']/li[1]/div/span")
	private WebElement li_Payers;

	@FindBy(id="firstBtn")
	private WebElement btn_First;

	@FindBy(id="secondBtn")
	private WebElement btn_Second;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;
	
	@FindBy(xpath = "//input[@placeholder='Type CPT/ICD Code/Description']")
	private WebElement txt_Search;
	
	@FindBy(xpath = "//tr[@role='row'][1]/td")
	private List<WebElement> tr_FirstRowData;
	
	@FindBy(xpath = "//tr[@role='row'][1]/td[1]//child::img")
	private WebElement atr_FinClrStatus;
	
	@FindBy(xpath = "//tr[@role='row'][1]/td[6]")
	private WebElement lbl_CustomResponce;
	

	public AddMedicalNecessityCustomResponsePage() {
		PageFactory.initElements(driver, this);
	}

	public String navigateToAddCustomResponsePage(){
		String facilityName="";
		try {
			webActions.sendKeys(dd_ResponseType, "Custom", "Response Type");
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
			facilityName=webActions.getValue(dd_Facility, "Facility");
			webActions.waitForClickAbilityAndClick(btn_AddNewResponse, "Add New Response");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(li_AllPayers, "All Payers");
			report.reportPass("Successfully Navigate to Add Custom Response Page");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
		return facilityName;
	}



	public void verifyTheFieldNames(DataTable fieldNames){
		try {
			ArrayList<String>expFieldNames=new ArrayList<String>(fieldNames.asList());
			ArrayList<String> actFieldNames=new ArrayList<String>();
			actFieldNames.addAll(webActions.getDatafromWebTable(lbl_HeaderFieldNames));
			actFieldNames.addAll(webActions.getDatafromWebTable(lbl_FieldNames));
			actFieldNames.addAll(webActions.getDatafromWebTable(lbl_FieldNames1));
			actFieldNames.addAll(webActions.getDatafromWebTable(lbl_ButtonNames));
			report.reportInfo("Actual Field Names in Medical Necessity Response page: "+actFieldNames);
			report.reportInfo("Expected Field Names in Medical Necessity Response page: "+expFieldNames);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actFieldNames, expFieldNames);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Field Names in Add Custom Response page");
			}
			else{
				report.reportFail("Fail to verify Field Names in Add Custom Response page: "+unmatchedLabelNames);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyBreadcrumb(DataTable breadcrumb){
		try {
			ArrayList<String>expBreadcrumb=new ArrayList<String>(breadcrumb.asList());
			ArrayList<String> actBreadcrumb=webActions.getDatafromWebTable(lbl_Breadcrum_All);
			report.reportInfo("Actual Breadcrumb: "+actBreadcrumb);
			report.reportInfo("Expected Breadcrumb: "+expBreadcrumb);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actBreadcrumb, expBreadcrumb);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Breadcrumb in Add Custom Response page");
			}
			else{
				report.reportFail("Fail to verify Breadcrumb in Add Custom Response page: "+unmatchedLabelNames);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyMandatoryFieldValidationMessages(DataTable errorMessages){
		try {
			ArrayList<String>expErrorMessages=new ArrayList<String>(errorMessages.asList());
			for (int i = 0; i < 5; i++) {
				webActions.pressTab();
			}
			webActions.waitForVisibilityOfAllElements(lbl_ErrorMessages, "Error Meesgaes");
			ArrayList<String>actErrorMessages=webActions.getDatafromWebTable(lbl_ErrorMessages);
			report.reportInfo("Actual error messages : "+actErrorMessages);
			report.reportInfo("Expected error messages: "+expErrorMessages);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actErrorMessages, expErrorMessages);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Breadcrumb in Add Custom Response page");
			}
			else{
				report.reportFail("Fail to verify Breadcrumb in Add Custom Response page");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyCancelButtonFunctionality(){
		try {
			webActions.waitAndClick(btn_Cancel, "Cancel");
			String buttonName=webActions.waitAndGetText(btn_AddNewResponse, "Add New Response");
			if("Add New Response".contentEquals(buttonName)){
				report.reportPass("Successfully verified Cancel button functionality");
			}else{
				report.reportFail("Failed to verify the Cancel button functionality");	
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyTheUnsavedChangesDiscardPopup(String alertTitle,String alertMessage){
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.sendKeys(txt_CPTCustomResponse, "Testing", "CPTCustomResponse");
			webActions.click(img_iPASLogo, "iPASLogo");
			String actMessage=webActions.waitAndGetText(lbl_DialogContent, "Dialog Content");
			report.reportInfo("Actual alert messages : "+actMessage);
			report.reportInfo("Expected alert messages: "+alertMessage);
			if(alertMessage.contentEquals(actMessage)){
				report.reportPass("Successfully verified alert message");
			}else{
				report.reportFail("Failed to verify the alert message: "+actMessage,true);
				unmatch.append("Failed to verify the alert message");
			}
			webActions.click(btn_CloseX, "CloseX");
			webActions.click(img_iPASLogo, "iPASLogo");
			String actAlertTitle=webActions.waitAndGetText(lbl_DialogTitle, "Dialog Title");
			if(actAlertTitle.contentEquals(alertTitle)){
				report.reportPass("Successfully verified alert title");
			}else{
				report.reportFail("Failed to verify the alert title "+actAlertTitle,true);
				unmatch.append("Failed to verify the alert title");
			}
			webActions.click(btn_Save_AlertPopup, "Save");
			webActions.click(lnk_MedicalNecessityResponseConfiguration, "MedicalNecessityResponseConfiguration");
			webActions.click(btn_Discard, "Discard");
			webActions.waitForPageLoaded();
			String buttonName=webActions.waitAndGetText(btn_AddNewResponse, "Add New Response");
			if("Add New Response".contentEquals(buttonName)){
				report.reportPass("Successfully Discard saving changes");
			}else{
				report.reportFail("Failed to verify the Discard saving changes",true);	
				unmatch.append("Failed to verify the Discard saving changes");
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void AddCustomResponse(DataTable testData){
		String CPTCustomResponse=getDatafromMap(testData,"CPT Custom Response");
		CPTCustomResponse=CPTCustomResponse+"_"+webActions.getRandomString(6);
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.waitForPageLoaded();
			selectResponseStatusDropDown(testData);
			webActions.waitForPageLoaded();
			webActions.click(txt_CPT_Code, "CPTCode");
			webActions.waitForPageLoaded();
			webActions.click(txt_Code, "Code");
			String CPTCode=getDatafromMap(testData,"CPT Code");
			webActions.sendKeys(txt_Code, CPTCode, "CPT Code");
			webActions.waitForVisibilityOfAllElements(li_CodeList_All, "CodeList_All");
			webActions.click(li_CodeList, "CPTCodeList");
			webActions.click(btn_Select, "Select");
			webActions.waitForPageLoaded();
			webActions.click(txt_ICD_Code, "ICD Code");
			webActions.waitForPageLoaded();
			webActions.click(txt_Code, "Code");
			String ICDCode=getDatafromMap(testData,"ICD Code");
			webActions.sendKeys(txt_Code, ICDCode, "ICD");
			webActions.waitForVisibilityOfAllElements(li_CodeList_All, "CodeList_All");
			webActions.click(li_CodeList, "CPTCodeList");
			webActions.click(btn_Select, "Select");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_CPTCustomResponse, CPTCustomResponse, "CPTCustomResponse");
			String assignedPayers=getDatafromMap(testData,"Assigned Payers");
			webActions.sendKeys(txt_AssignedPayers, assignedPayers, "Assigned Payers");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(li_Payers, "Payers List");
			webActions.click(li_Payers, "Payers List");
			webActions.waitForVisibility(btn_Second, "Move Payers");
			webActions.click(btn_Second, "Move Payers");
			webActions.waitForVisibility(btn_Save, "Save");
			webActions.click(btn_Save, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle = titleContent[0];
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			String expMessage=getDatafromMap(testData,"Message");
			report.reportInfo("Expected alert message: "+expMessage);
			if(expMessage.contains(actContent)){
				report.reportPass("Successfully created Custom Response and Verified alert message");
			}else{
				report.reportFail("Failed to create Custom Response and alert message is not matched: "+actContent,true);
				unmatch.append("Failed to create Custom Response and alert message is not matched");
			}
			webActions.waitForPageLoaded();
			webActions.click(txt_Search, "Search");
			webActions.sendKeys(txt_Search, CPTCustomResponse, "Search");
			webActions.waitForPageLoaded();
			ArrayList<String>data=webActions.getDatafromWebTable(tr_FirstRowData);
			ArrayList<String>actData=new ArrayList<String>();
			String staus=webActions.getAttributeValue(atr_FinClrStatus, "src", "FinClrStatus");
			actData.add(staus);
			actData.add(data.get(1));
			actData.add(data.get(3));
			actData.add(data.get(4));
			actData.add(data.get(5));
			report.reportInfo("Actual Data: "+actData);
			String expFinClrStatus=getFinClrStatus(testData);
			ArrayList<String>expData=new ArrayList<String>();
			expData.add(expFinClrStatus);
			expData.add(CPTCode);
			expData.add(ICDCode);
			expData.add(assignedPayers);
			expData.add(CPTCustomResponse);
			report.reportInfo("Expected Data: "+expData);
			ArrayList<String>unmatchData=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatchData.size()==0){
				report.reportPass("Successfully Verified the data in the results grid");
			}else{
				report.reportFail("Failed to verify the data in the results grid: "+unmatchData,true);
				unmatch.append("Failed to verify the data in the results grid");
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void AddCustomResponseWithAllPayers(DataTable testData){
		String CPTCustomResponse=getDatafromMap(testData,"CPT Custom Response");
		CPTCustomResponse=CPTCustomResponse+"_"+webActions.getRandomString(6);
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.waitForPageLoaded();
			selectResponseStatusDropDown(testData);
			webActions.waitForPageLoaded();
			webActions.click(txt_CPT_Code, "CPTCode");
			webActions.waitForPageLoaded();
			webActions.click(txt_Code, "Code");
			String CPTCode=getDatafromMap(testData,"CPT Code");
			webActions.sendKeys(txt_Code, CPTCode, "CPT Code");
			webActions.waitForVisibilityOfAllElements(li_CodeList_All, "CodeList_All");
			webActions.click(li_CodeList, "CPTCodeList");
			webActions.click(btn_Select, "Select");
			webActions.waitForPageLoaded();
			webActions.click(txt_ICD_Code, "ICD Code");
			webActions.waitForPageLoaded();
			webActions.click(txt_Code, "Code");
			String ICDCode=getDatafromMap(testData,"ICD Code");
			webActions.sendKeys(txt_Code, ICDCode, "ICD");
			webActions.waitForVisibilityOfAllElements(li_CodeList_All, "CodeList_All");
			webActions.click(li_CodeList, "CPTCodeList");
			webActions.click(btn_Select, "Select");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_CPTCustomResponse, CPTCustomResponse, "CPTCustomResponse");
			
			webActions.click(btn_First, "Move All Payers");
			webActions.waitForVisibility(btn_Save, "Save");
			webActions.click(btn_Save, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle = titleContent[0];
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			String expMessage=getDatafromMap(testData,"Message");
			report.reportInfo("Expected alert message: "+expMessage);
			if(expMessage.contains(actContent)){
				report.reportPass("Successfully created Custom Response and Verified alert message");
			}else{
				report.reportFail("Failed to create Custom Response and alert message is not matched: "+actContent,true);
				unmatch.append("Failed to create Custom Response and alert message is not matched");
			}
			webActions.waitForPageLoaded();
			webActions.click(txt_Search, "Search");
			webActions.sendKeys(txt_Search, CPTCustomResponse, "Search");
			webActions.waitForPageLoaded();
			String actCustomResponce=webActions.getText(lbl_CustomResponce, "Custom Responce");
			
			report.reportInfo("Actual Data: "+actCustomResponce);
			
			report.reportInfo("Expected Data: "+CPTCustomResponse);
			
			if(CPTCustomResponse.contentEquals(actCustomResponce)){
				report.reportPass("Successfully Verified the data in the results grid");
			}else{
				report.reportFail("Failed to verify the data in the results grid: "+actCustomResponce,true);
				unmatch.append("Failed to verify the data in the results grid");
			}
			
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void selectResponseStatusDropDown(DataTable testData){
		try {
			String responseStatus=getDatafromMap(testData,"Response Status");
			int row = 0;
			switch (responseStatus) {
			case "Clear":
				row=1;
				break;
			case "Review":
				row=2;
				break;
			case "Needs Attention":
				row=3;
				break;
			}
			webActions.click(dd_ResponseStatus, "Response Status");
			webActions.waitForPageLoaded();
			driver.findElement(By.xpath("//ul[@id='ddlelement_options']/li["+row+"]")).click();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public String getFinClrStatus(DataTable testData){
		String responseStatus=getDatafromMap(testData,"Response Status");
		String status = null;
		switch (responseStatus) {
		case "Clear":
			status="success";
			break;
		case "Review":
			status="alert";
			break;
		case "Needs Attention":
			status="error";
			break;
		}
		return status;
	}


	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(lnk_MedicalNecessityResponseConfiguration);
	}

}
