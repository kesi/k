package com.ipas.hf.web.pages.ipasPages;

import org.openqa.selenium.support.ui.ExpectedCondition;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.dbutilities.SqlQueries;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

import com.ipas.hf.web.pages.BasePage;

public class CreateABNFormPage extends BasePage{

	private JSONObject jsonObject;
	private static final String MEDNEC = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\CreateABNForm.json";
	private StepLogging log = StepLogging.getLoggingObject();

	@FindBy(linkText="Payer Maintenance Configuration")
	private WebElement lnk_PayerMintenace;

	@FindBy(xpath="//select[@name='payerCode']/../input")
	private WebElement dd_PayerConfigure;

	@FindBy(xpath="//ejs-textbox[@id='search_text']//input")
	private WebElement txt_Search;

	@FindBy(xpath="//ejs-dropdownlist[@id='ddlelement']//input")
	private WebElement dd_Facility;

	@FindBy(linkText="Apply")
	private WebElement btn_Apply;

	@FindBy(xpath="//div[@class='e-gridcontent']//tbody/tr/td[1]//span[1]")
	public List<WebElement> tr_Rows;

	@FindBy(xpath="//ejs-switch[@role='switch']")
	private WebElement chk_AutoRun;

	@FindBy(xpath="//a[contains(text(),'Save')]")
	private WebElement btn_Save_MedNec;

	@FindBy(linkText="Medical Necessity")
	private WebElement lnk_MedicalNecessity;

	@FindBy(xpath="//div[@hideauthorize='ViewAlerts']/ul/li[1]")
	private WebElement lbl_RuleAlert;

	@FindBy(xpath="//ejs-checkbox[@disablelink='RunManualMedicalNecessityCheck']//input")
	private List<WebElement> chk_MedNecResults;

	@FindBy(xpath="//a[contains(text(),'Create ABN')]")
	private WebElement btn_CreateABN;

	@FindBy(xpath="//div[@class='grid-items']/div[2]/div[4]")
	private WebElement lbl_Price;

	@FindBy(xpath="//button[contains(text(),'Add')]")
	private WebElement btn_Add;

	@FindBy(xpath="(.//*[normalize-space(text()) and normalize-space(.)='ABN English'])[3]/following::span[1]")
	private WebElement btn_StartFilling;	

	@FindBy(xpath="//button[@type='submit']")
	private WebElement btn_Submit;

	@FindBy(linkText="Digital Documents Manager")
	private WebElement lbl_DigitalDocMangerHeaderPanel;

	@FindBy(xpath = "//span[@class='item-title']")
	private WebElement lbl_AllFormsAndDocuments;

	String form="//span[text()='";
	String form1="']";

	@FindBy(xpath = "//div[@id='document-viewer-section']//h2")
	private WebElement lbl_ABNFormHeaderName;

	@FindBy(xpath="//a[contains(text(),'History')]")
	private WebElement btn_History;

	@FindBy(xpath="//tr[@class='e-emptyrow']/td")
	private WebElement lbl_NoRecords;

	@FindBy(xpath="//span[@class='float-right']/button")
	private WebElement btn_CloseX;

	@FindBy(xpath="//a[contains(text(),'New Medical Necessity Check')]")
	private WebElement btn_NewMedicalNecessityCheck;

	@FindBy(xpath="//a[contains(text(),'Run')]")
	private WebElement btn_Run;

	@FindBy(xpath="(//div[@class='modal-content']//tr/td/span)[2]")
	private WebElement lbl_HistoryData;

	@FindBy(xpath="//div[@class='last-run-info']/p/span")
	private WebElement lbl_LastRanBy;

	@FindBy(xpath="//a[contains(text(),'Current Request')]")
	private WebElement btn_CurrentRequest;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs; 

	@FindBy(xpath="//img[@alt='iPAS Logo']")
	private WebElement img_Home;

	@FindBy(linkText="Account Search")
	private WebElement lnk_AccountSearch;

	@FindBy(xpath="//table[@id='asgrid_content_table']/tbody/tr[1]/td[10]/div/a")
	private WebElement lnk_NeedsAttention;

	@FindBy(xpath="//div[@class='modal-body row']/div/ul/li")
	private WebElement tbl_AllModules;

	@FindBy(xpath="//a[contains(text(),'Medical Necessity Check')]")
	private WebElement lnk_MedNec;

	@FindBy(xpath="(//span[text()='Medical Necessity'])[2]")
	private WebElement lbl_HeaderName;

	@FindBy(xpath="(//a[text()='Account Search'])[2]")
	private WebElement lnk_AccountSearch1;

	@FindBy(linkText="Medical Necessity Check")
	private WebElement lnk_MedicalNecessityCheck;


	private RestActions rest = new RestActions();
	PaymentFacilitatorPage payment=new PaymentFacilitatorPage();
	Login login=new Login();

	public CreateABNFormPage() {
		PageFactory.initElements(driver, this);
	}


	public void clickPayerMintenace() throws Exception{
		webActions.waitAndClick(lnk_PayerMintenace, "Payer Mintenace");
		webActions.waitForPageLoaded();
		webActions.waitForJSandJQueryToLoad();
		webActions.waitForVisibility(dd_PayerConfigure, "Payer Configure");
	}

	public void navigateFacilityConfig(String moduleName,String plan_Name_Code,String facility) throws Exception{
		webActions.sendKeys(dd_PayerConfigure, moduleName, "Payer Configure");
		webActions.waitForPageLoaded();
		webActions.clearValue(txt_Search, "Search");
		webActions.sendKeys(txt_Search, plan_Name_Code, "Search");
		webActions.waitForPageLoaded();
		webActions.sendKeys(dd_Facility, facility, "Facility");
		webActions.waitForPageLoaded();
		webActions.waitAndClick(btn_Apply, "Apply");
		try {
			webActions.waitForVisibilityOfAllElements(tr_Rows, "Facility Names");
		} catch (Exception e) {
		}
	}

	public void medNecAutoRunTurnOnAndTrunOff(String moduleName,String plan_Name_Code,String facility,String runStatus) throws Exception{
		try {
			clickPayerMintenace();
			navigateFacilityConfig(moduleName,plan_Name_Code,facility);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			for (WebElement webElement : tr_Rows) {
				String txt=webElement.getText();
				if(plan_Name_Code.contentEquals(txt)){					
					webElement.click();
					webActions.waitForPageLoaded();
					break;
				}
			}

			String actAutoRunStatus=webActions.getAttributeValue(chk_AutoRun, "aria-checked", "Auto Run");
			if("AutoRunYes".contentEquals(runStatus)){
				if(!actAutoRunStatus.contentEquals("true")){
					webActions.waitForVisibility(chk_AutoRun, "Auto Run");
					webActions.click(chk_AutoRun, "Auto Run");

					webActions.click(btn_Save_MedNec, "Save");
					String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
					String[] titleContent=msg.split("\\n");
					String actContent=titleContent[1];
					if("Updated successfully.".contentEquals(actContent)){
						report.reportPass("Successfully saved the settings: "+msg);
					}else{
						report.reportFail("Failed to save the settings", true);
					}
				}
				report.reportPass("Auto Run already in On");
			}else if("AutoRunNo".contentEquals(runStatus)){
				if(actAutoRunStatus.contentEquals("true")){
					webActions.waitForVisibility(chk_AutoRun, "Auto Run");
					webActions.click(chk_AutoRun, "Auto Run");

					webActions.click(btn_Save_MedNec, "Save");
					String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
					String[] titleContent=msg.split("\\n");
					String actContent=titleContent[1];
					if("Updated successfully.".contentEquals(actContent)){
						report.reportPass("Successfully saved the settings: "+msg);
					}else{
						report.reportFail("Failed to save the settings", true);
					}
				}
				report.reportPass("Auto Run already in Off");
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage(), true);
		}
	}

	public void navigateAccountSearch() throws Exception{
		webActions.waitForPageLoaded();
		webActions.waitAndClick(img_Home, "Home");
		webActions.waitForPageLoaded();
		webActions.waitAndClick(lnk_AccountSearch, "Account Search");
		webActions.waitForPageLoaded();
		webActions.waitForJSandJQueryToLoad();
	}

	public void navigateAllDataPage(){
		try {
			String accountNumber=getDataFromJSONFile("AccountNumber");
			payment.searchAccountNuberinAccountSearchPage(accountNumber);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			try {
				webActions.waitForVisibility(lbl_RuleAlert, "Rule Alert", 15);
			} catch (Exception e) {
			}
		} catch (Exception e) {

		}
	}



	public void navigateMedicalNecessityPage(){
		try {
			navigateAllDataPage();
			webActions.waitAndClick(lnk_MedicalNecessity, "MedicalNecessity");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void createABNForm(){
		try {
			try {
				webActions.waitForVisibility(btn_NewMedicalNecessityCheck, "NewMedicalNecessityCheck",10);
			} catch (Exception e) {
			}

			for (WebElement webElement : chk_MedNecResults) {
				webActions.scrollBarHandle(webElement, "Check box");
				webActions.waitForPageLoaded();
				webActions.click(webElement, "Check box");
				break;
			}
			webActions.waitForPageLoaded();
			webActions.click(btn_CreateABN, "Create ABN");
			webActions.waitAndGetText(lbl_Price, "Price");
			webActions.click(btn_Add, "Add");

			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent=titleContent[1];
			if("ABN Created successfully.".contentEquals(actContent)){
				report.reportPass("Successfully created ABN form: "+msg);
			}else{
				report.reportFail("Failed to create ABN form: "+msg, true);
			}
			waitForFormLoad(5);
			webActions.switchToiFrame(0);
			webActions.waitForPageLoaded();
			waitForFormLoad(2);
			//webActions.scrollBarHandle(btn_StartFilling, "btn_StartFilling");
			report.reportPass("ABN Form created successfully and Start Filling");
			//webActions.waitForClickAbilityAndClick(btn_StartFilling, "btn_StartFilling");
			waitForFormLoad(2);
			report.reportPass("ABN Form loaded successfully");
			webActions.waitForClickAbilityAndClick(btn_Submit, "Submit");
			waitForFormLoad(2);
			report.reportPass("ABN Form submited successfully");
			webActions.switchTodefaultContent();
			String accountNumber=getDataFromJSONFile("AccountNumber");
			driver.findElement(By.linkText(accountNumber)).click();
			webActions.waitForPageLoaded();
			waitForFormLoad(2);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void navigateDigitalDocumentsManagerFullPage(){
		try {
			webActions.waitForVisibility(lbl_DigitalDocMangerHeaderPanel, "DDM Link",15);
			webActions.waitAndClick(lbl_DigitalDocMangerHeaderPanel, "DDM Link");
			webActions.waitForClickAbility(lbl_AllFormsAndDocuments, "Forms And Documents");
			webActions.waitAndGetText(lbl_AllFormsAndDocuments, "Forms And Documents");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyABNForminDigitalDocuments(String formName){
		try {
			navigateDigitalDocumentsManagerFullPage();
			webActions.waitForClickAbility(lbl_AllFormsAndDocuments, "Forms And Documents");
			webActions.waitAndGetText(lbl_AllFormsAndDocuments, "Forms And Documents");
			WebElement elementForme=driver.findElement(By.xpath(form+formName+form1));
			webActions.click(elementForme, "Form Name");
			webActions.waitForPageLoaded();
			String actHeaderName=webActions.waitAndGetText(lbl_ABNFormHeaderName, "Header Name");
			report.reportPass("Form Header Name: "+actHeaderName);
			if(formName.contains(actHeaderName)){
				report.reportPass("Successfully verified the ABN form in Digital Documents");
			}
			else{
				report.reportFail("Failed to verify the ABN form in Digital Documents: "+actHeaderName);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyNoRecordsMessage(String expMessage){
		try {
			webActions.waitAndClick(btn_History, "History");
			String actMessage=webActions.waitAndGetText(lbl_NoRecords, "No Records");
			if("No records to display".contains(actMessage)){
				report.reportPass("Successfully verified the No Records message");
				webActions.click(btn_CloseX, "Close");
			}else{
				webActions.click(btn_CloseX, "Close");
				report.reportFail("Failed to verify the No Records message");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyMedicalNecessityHistory (){
		StringBuilder unmatch=new StringBuilder();

		try {
			webActions.waitAndClick(btn_History, "History");
			String actMessage=webActions.waitAndGetText(lbl_NoRecords, "No Records");
			if("No records to display".contains(actMessage)){
				report.reportPass("Successfully verified the No Records message");
				webActions.click(btn_CloseX, "Close");
			}else{
				webActions.click(btn_CloseX, "Close");
				report.reportFail("Failed to verify the No Records message: "+actMessage,true);
				unmatch.append("Failed to verify the No Records message");
			}

			webActions.waitAndClick(btn_NewMedicalNecessityCheck, "NewMedicalNecessityCheck");
			webActions.waitAndClick(btn_Run, "Run");
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent=titleContent[1];
			if("Updated successfully.".contentEquals(actContent)){
				report.reportPass("Successfully ran the New Medical Necessity: "+msg);
			}else{
				report.reportFail("Failed to ran the New Medical Necessity: "+msg,true);
				unmatch.append("Failed to ran the New Medical Necessity");
			}
			webActions.waitAndClick(btn_History, "History");
			String actData=webActions.waitAndGetText(lbl_HistoryData, "Last Ran Data");
			if("Auto Run".contains(actData)){
				report.reportPass("Successfully verified the last ran by information in history popup");
			}else{
				report.reportFail("Failed to verify the last ran by information in history popup: "+actData,true);
				unmatch.append("Failed to verify the last ran by information in history popup");
			}
			webActions.waitAndClick(lbl_HistoryData, "Last Ran Record");
			webActions.waitForPageLoaded();
			String actDatainPage=webActions.waitAndGetText(lbl_LastRanBy, "Last Ran Data");
			if("Auto".contains(actDatainPage)){
				report.reportPass("Successfully verified the last ran by information in Medical Necessity History page");
			}else{
				report.reportFail("Failed to verify the last ran by information in Medical Necessity History page: "+actDatainPage,true);
				unmatch.append("Failed to verify the last ran by information in Medical Necessity History page");
			}
			webActions.waitAndClick(btn_CurrentRequest, "Current Request");
			webActions.waitAndGetText(lbl_LastRanBy, "Last Ran Data");
			webActions.waitForVisibility(btn_History, "History");
			boolean historyButton=webActions.isDisplayed(btn_History, "History");
			if(historyButton==true){
				report.reportPass("Successfully History button in the Current ran");
			}
			else{
				report.reportFail("Failed to verify the History button in the Current ran",true);
				unmatch.append("Failed to verify the History button in the Current ran");	
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void navigateMedicalNecessityLongPanelFromAllModulesPopup (){
		try {
			StringBuffer unmatch=new StringBuffer();
			String accountNumber=getDataFromJSONFile("AccountNumber");
			login.simpleSearch(accountNumber);
			webActions.waitForPageLoaded();
			/*webActions.waitAndClick(lnk_NeedsAttention, "Needs Attention");
			webActions.waitForVisibility(lnk_MedNec, "Medical Necessity");
			webActions.waitAndClick(lnk_MedNec, "Medical Necessity");
			webActions.waitForPageLoaded();
			String actName=webActions.waitAndGetText(lbl_HeaderName, "Header Name");
			if("Medical Necessity".contentEquals(actName)){
				report.reportPass("Successfully navigated to Medical Necessity long panel from All Modules popup in Account Search");
			}else{
				report.reportFail("Failed to navigate to Medical Necessity long panel from All Modules popup in Account Search",true);
				unmatch.append("Failed to navigate to Medical Necessity long panel from All Modules popup in Account Search");
			}

			webActions.click(lnk_AccountSearch1, "Account Search");*/
			webActions.waitAndClick(lnk_MedicalNecessityCheck, "Medical Necessity");
			String actName2=webActions.waitAndGetText(lbl_HeaderName, "Header Name");
			if("Medical Necessity".contentEquals(actName2)){
				report.reportPass("Successfully navigated to Medical Necessity long panel from Needs Attention in Account Search");
			}else{
				report.reportFail("Failed to navigate to Medical Necessity long panel from Needs Attention in Account Search");
				unmatch.append("Failed to navigate to Medical Necessity long panel from Needs Attention in Account Search");
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}


	public String getTestData(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}



	@SuppressWarnings("unchecked")
	public void updateMedNecJSON() throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(MEDNEC);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			try {
				String number = rest.getUniqueNumber();
				newNum = "A" + number;
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(0);
				tenantPatient.put("TenantPatientId", newNum);

				tenantPatient = (JSONObject) msg.get(3);
				tenantPatient.put("TenantPatientId", newNum);

				String test = (String) tenantPatient.get("TenantPatientId");	
			} catch (Exception e) {
				log.error("Failed to update tenant patiend id", e);
				e.printStackTrace();
			}
			try {
				visitObject.put("AccountNumber", newNum);
				visitObject.put("VisitNumber", newNum);
				Object tt = visitObject.get("VisitDate");
				String updatedDate = rest.updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);

			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}

			FileWriter file = new FileWriter(MEDNEC);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}
	
	public  File createFolder(){
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy") ;
		String curDate =dateFormat.format(date);
		String dest=System.getProperty("user.dir")+"\\Data\\";
		File Path = new File(dest+curDate);
		Path.mkdir();
		return Path;	
	}


	public String getDataFromJSONFile(String fieldName){
		String expectedResponseValue=null;
		try {
			FileReader reader = new FileReader(MEDNEC);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");

			if(fieldName.contentEquals("AccountNumber")){
				expectedResponseValue = (String) visitObject.get("AccountNumber");	
			}
		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return expectedResponseValue;
	}





	public void waitForFormLoad(int seconds){
		try {
			Thread.sleep(seconds*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public String getPatientVisitId(){
		String patientVisitId = rest.getStringValueFromResponse("$..patientVisitId");
		patientVisitId=replaceAll(patientVisitId);
		return patientVisitId;
	}
	public String replaceAll(String input){
		return input.replaceAll("[\\[\\]\"]", "");
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}