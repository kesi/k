package com.ipas.hf.web.pages.ipasPages;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class AddNewRulePage extends BasePage {

	@FindBy(linkText="Rules Configuration")
	private WebElement lnk_RulesConfiguration;

	@FindBy(xpath="//span[@class='breadcrum-active']")
	private WebElement lbl_Breadcrum;

	@FindBy(xpath="//ejs-dropdownlist[@id='facilityLookup']/span/input")
	private WebElement dd_Facility;

	@FindBy(xpath="//button[(text()='Apply')]")
	private WebElement btn_Apply;

	@FindBy(xpath="//button[(text()='Add New Rule')]")
	private WebElement btn_AddNewRule;

	@FindBy(xpath="//div[@class='breadcrum-container noprint']/span")
	private List<WebElement> lbl_Breadcrum_All;

	@FindBy(xpath="//div[@class='table-wrapper']//child::label")
	private List<WebElement> lbl_FieldNames;

	@FindBy(xpath="//div[@class='table-wrapper']/section[1]/div[1]/span")
	private WebElement lbl_Active;

	@FindBy(xpath="//div[@class='row mr']/div/div/div[1]")
	private WebElement lbl_Facility;

	@FindBy(xpath="//div[@class='row mr']/div/div/div[2]")
	private WebElement lbl_FacilityName;

	@FindBy(xpath="//div[@class='search-result']//child::th//div//span")
	private List<WebElement> lbl_HeaderNames;

	@FindBy(xpath="//div[@class='table-wrapper']/section[2]/div[6]/div/div/button")
	private List<WebElement> lbl_Buttons;

	@FindBy(xpath="//input[@placeholder='Enter Rule Id']")
	private WebElement txt_DisplayRuleId;

	@FindBy(xpath="//div[@class='e-gridcontent']/div/table/tbody/tr")
	private List<WebElement> tr_Results;

	@FindBy(xpath="//div[@class='error']/div")
	private List<WebElement> lbl_ErrorMessages;

	@FindBy(xpath="//button[(text()='Discard')]")
	private WebElement btn_Discard;

	@FindBy(xpath="//button[(text()='Save')]")
	private WebElement btn_Save;

	@FindBy(xpath="//button[@title='Close']")
	private WebElement btn_Close;

	@FindBy(linkText="Rule Configuration")
	private WebElement lnk_RuleConfiguration;

	@FindBy(xpath="//div[@class='modal-header']/h4/span")
	private WebElement lbl_ModelHeader;

	@FindBy(xpath="//div[@role='dialog']/div[2]")
	private WebElement lbl_PopupMessage;

	@FindBy(xpath="//button[@routerlink='/maintenance/rule-configuration']")
	private WebElement btn_Cancel;

	@FindBy(xpath="//ejs-dropdownlist[@id='ddlelement']/span/span[2]")
	private WebElement dd_ResponseStatus;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;

	@FindBy(xpath = "//ejs-switch[@role='switch']")
	private WebElement atr_SwitchActive;

	@FindBy(xpath = "//ejs-dropdownlist[@formcontrolname='moduleRefId']/span")
	private WebElement dd_Module;

	@FindBy(xpath = "//label[(text()='Data Elements')]/../div/button")
	private WebElement btn_Add_DataElement;

	@FindBy(xpath="//ul[@role='presentation']/li/div/span")
	private List<WebElement> li_ElementNames;

	@FindBy(xpath = "//input[@placeholder='Type Element Name']")
	private WebElement txt_ElementName;

	@FindBy(id = "firstBtn")
	private WebElement btn_FirstBtn;

	@FindBy(xpath = "//button[contains(text(),'Assign')]")
	private WebElement btn_Assign;

	@FindBy(xpath = "//ejs-dropdownlist[@formcontrolname='errorCategoryId']/span")
	private WebElement dd_ErrorCategory;

	@FindBy(name = "ruleTitle")
	private WebElement txt_RuleTitle;

	@FindBy(xpath = "//ejs-dropdownlist[@formcontrolname='ruleCategoryId']/span")
	private WebElement dd_RuleCategoryId;

	@FindBy(xpath = "//textarea[@formcontrolname='errorDescription']")
	private WebElement txt_ErrorDescription;

	@FindBy(xpath = "//div[@class='table-wrapper']//child::button[2]")
	private WebElement btn_Add;

	@FindBy(xpath="//div[@class='e-gridcontent']/div/table/tbody/tr[1]/td/div")
	private List<WebElement> tr_RowData;

	@FindBy(xpath="//input[@placeholder='Type Rule Title / Rule ID']")
	private WebElement txt_Seach;

	@FindBy(xpath="//ejs-checkbox[@role='checkbox']")
	private WebElement chk_InActive;

	@FindBy(xpath="//div[@class='e-gridcontent']/div/table/tbody/tr[1]/td[2]/div/a")
	private WebElement lnk_RuleTitle;

	@FindBy(xpath="//input[@id='displyRuleId']")
	private WebElement txt_DisplyRuleId;

	String tbl_RowData="//div[@class='e-gridcontent']/div/table/tbody/tr[";
	String tbl_RowData1="]/td[8]/div[1]/div";
	
	@FindBy(xpath="//div[@class='e-gridcontent']/div/table/tbody/tr[1]/td[8]/div[1]/div")
	private WebElement lbl_StatusFirstRow;
	
	@FindBy(xpath = "//button[contains(text(),'Edit Data Elements')]")
	private WebElement btn_EditDataElements;
	
	@FindBy(xpath = "//ejs-listview[@id='list-1']//ul[@role='presentation']/li[1]/div/span")
	private WebElement li_AllElement;
	
	@FindBy(xpath = "//ejs-listview[@id='list-2']//ul[@role='presentation']/li[1]/div/span")
	private WebElement li_SelectedElement;

	@FindBy(id = "secondBtn")
	private WebElement btn_SecondBtn;
	
	@FindBy(id = "thirdBtn")
	private WebElement btn_ThirdBtn;
	
	@FindBy(id = "fourthBtn")
	private WebElement btn_FourthBtn;

	public AddNewRulePage() {
		PageFactory.initElements(driver, this);
	}

	public void clickRulesConfiguration() throws InterruptedException{
		webActions.click(lnk_RulesConfiguration, "Rules Configuration");
		Thread.sleep(3000);
		webActions.waitForVisibilityOfAllElements(tr_Results, "Grid Results");
	}

	public void verifyBreadcrumb(DataTable breadcrumb){
		try {
			webActions.click(btn_AddNewRule, "Add New Rule");
			webActions.waitForVisibilityOfAllElements(lbl_FieldNames, "Field Names");			
			ArrayList<String>expBreadcrumb=new ArrayList<String>(breadcrumb.asList());
			webActions.refreshPage();
			webActions.waitForPageLoaded();
			ArrayList<String> actBreadcrumb=webActions.getDatafromWebTable(lbl_Breadcrum_All);
			report.reportInfo("Actual Breadcrumb: "+actBreadcrumb);
			report.reportInfo("Expected Breadcrumb: "+expBreadcrumb);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actBreadcrumb, expBreadcrumb);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Breadcrumb in Add New Rule page");
			}
			else{
				report.reportFail("Fail to verify Breadcrumb in Add New Rule page");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void clickAddNewRuleButton() throws InterruptedException{
		webActions.click(btn_AddNewRule, "Add New Rule");
		Thread.sleep(3000);
		webActions.waitForVisibilityOfAllElements(lbl_FieldNames, "Field Names");
	}

	public void verifyFieldNames(DataTable fieldNames){
		try {
			StringBuilder unmatch=new StringBuilder();
			ArrayList<String>expData=new ArrayList<String>(fieldNames.asList());
			webActions.waitForPageLoaded();
			String facilityName=webActions.getValue(dd_Facility,"Facility");
			clickAddNewRuleButton();
			ArrayList<String>actData=new ArrayList<String>();
			actData.add(webActions.getText(lbl_Facility, "Facility"));
			actData.add(webActions.getText(lbl_Active, "Active"));
			actData.addAll(webActions.getDatafromWebTable(lbl_FieldNames));
			actData.addAll(webActions.getDatafromWebTable(lbl_Buttons));
			report.reportInfo("Displayed Field Names in Add New Rule page: "+actData);
			report.reportInfo("Expected Field Names in Add New Rule page: "+expData);
			ArrayList<String>unmatchFields=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatchFields.size()==0){
				report.reportPass("Verified Field Names in Add New Rule page successfully");
			}
			else{
				report.reportFail("Fail to verify Field Names in Add New Rule page:"+unmatchFields, true);
				unmatch.append("Fail to verify Field Names in Add New Rule page: "+unmatchFields);
			}
			String actFacilityName=webActions.getText(lbl_FacilityName, "Facility Name");
			report.reportInfo("Displayed Facility Name in Add New Rule page: "+actFacilityName);
			report.reportInfo("Expected Facility Name in Add New Rule page: "+facilityName);
			if(facilityName.contains(actFacilityName)){
				report.reportPass("Successfully verified the Facility name in Add New Rule Page");
			}else{
				report.reportFail("Fail to verify Facility Name in Add New Rule page ", true);
				unmatch.append("Fail to verify Facility Name in Add New Rule page");
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyMandatoryFieldValidationMessages(DataTable errorMessages){
		ArrayList<String>expData=new ArrayList<String>(errorMessages.asList());
		try {
			clickAddNewRuleButton();
			webActions.click(txt_DisplayRuleId, "EnterRuleId");
			for (int i = 0; i < 7; i++) {
				webActions.pressTab();
			}
			webActions.waitForPageLoaded();
			ArrayList<String> actData=webActions.getDatafromWebTable(lbl_ErrorMessages);
			report.reportInfo("Displayed messages in Add New Rule page: "+actData);
			report.reportInfo("Expected messages in Add New Rule page: "+expData);
			ArrayList<String>unmatchMessages=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatchMessages.size()==0){
				report.reportPass("Verified Mandatory Field Validation Messages successfully");
			}
			else{
				report.reportFail("Fail to verify Mandatory Field Validation Messages:"+unmatchMessages);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}

	public void verifyUnsavedChangesPopupAndCancelButton(String message){
		try {
			clickAddNewRuleButton();
			webActions.sendKeys(txt_DisplayRuleId,"1234", "EnterRuleId");
			webActions.waitForPageLoaded();
			webActions.click(lnk_RuleConfiguration, "RuleConfiguration");
			webActions.waitForPageLoaded();
			String actMessage=webActions.waitAndGetText(lbl_PopupMessage, "PopupMessage");
			if(message.contentEquals(actMessage)){
				report.reportPass("Successfully verified the Unsaved Changes Discard popup message");
			}
			else{
				report.reportFail("Failed to verify the Unsaved Changes Discard popup message");
			}
			webActions.click(btn_Close, "Close X");
			webActions.waitForPageLoaded();
			webActions.click(lnk_RuleConfiguration, "RuleConfiguration");
			actMessage=webActions.waitAndGetText(lbl_PopupMessage, "PopupMessage");
			webActions.click(btn_Save, "Save");
			webActions.waitForPageLoaded();
			webActions.click(lnk_RuleConfiguration, "RuleConfiguration");
			webActions.waitForPageLoaded();
			webActions.click(btn_Discard, "Discard");
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_AddNewRule, "AddNewRule");
			webActions.click(btn_Cancel, "Cancel");
			webActions.waitForPageLoaded();
			boolean addButton=webActions.isDisplayed(btn_AddNewRule, "Add New Rule");
			if(addButton==true){
				report.reportPass("Successfully verified cancel button functionality in Add New Rule");
			}else{
				report.reportFail("Failed to verify cancel button functionality in Add New Rule");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyFacilityNameAndDefaultStatusofActiveToggle(String facility){
		try {
			webActions.sendKeys(dd_Facility, facility, "Facility");
			webActions.waitForPageLoaded();
			webActions.click(btn_Apply, "Apply");
			clickAddNewRuleButton();
			String expFacilityName=webActions.getText(lbl_FacilityName, "Facility Name");
			if(facility.contentEquals(expFacilityName)){
				report.reportPass("Successfully verified the selected Facility name in Add New Rule: "+expFacilityName);
			}else{
				report.reportFail("Failed to verify the selected Facility name in Add New Rule: "+expFacilityName);
			}

			String actSwitchStatus=webActions.getAttributeValue(atr_SwitchActive, "aria-checked", "SwitchActive");
			if("true".contentEquals(actSwitchStatus)){
				report.reportPass("Successfully verified the default status of Active toggle");
			}
			else{
				report.reportFail("Failed to verify the default status of Active toggle");
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void AddNewRule(DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			clickAddNewRuleButton();
			String status=getDatafromMap(testData,"Status");
			if("InActive".contentEquals(status)){
				webActions.click(atr_SwitchActive, "SwitchActive");
			}
			/*String displayRuleId=getUniqueNumber(5);
			webActions.sendKeys(txt_DisplayRuleId, displayRuleId, "DisplayRuleId");*/

			String module=getDatafromMap(testData,"Module");
			selectDropdown(dd_Module,module,"Module");

			String elementName=getDatafromMap(testData,"ElementName");
			webActions.click(btn_Add_DataElement, "Add");
			webActions.waitForVisibilityOfAllElements(li_ElementNames, "Element Names");
			webActions.sendKeys(txt_ElementName, elementName, "ElementName");
			webActions.click(btn_FirstBtn,  "FirstBtn");
			webActions.click(btn_Assign,  "btn_Assign");
			webActions.waitForPageLoaded();

			String errorCategory=getDatafromMap(testData,"ErrorCategory");

			selectDropdown(dd_ErrorCategory,errorCategory,"ErrorCategory");

			String ruleTitle=getDatafromMap(testData,"RuleTitle");
			ruleTitle=ruleTitle+"_"+webActions.getRandomString(6);
			webActions.sendKeys(txt_RuleTitle, ruleTitle, "RuleTitle");

			webActions.scrollBarHandle(txt_ErrorDescription, "ErrorDescription");
			String ruleCategory=getDatafromMap(testData,"RuleCategory");
			selectDropdown(dd_RuleCategoryId,ruleCategory,"RuleCategory");

			String errorDescription=getDatafromMap(testData,"ErrorDescription");
			webActions.sendKeys(txt_ErrorDescription, errorDescription, "ErrorDescription");

			webActions.click(btn_Add, "Add");
			ArrayList<String>expData=new ArrayList<String>();
			/*expData.add(displayRuleId+" "+ruleTitle);*/
			expData.add(ruleTitle);
			expData.add(module);
			expData.add(errorDescription);
			expData.add(elementName);
			expData.add(ruleCategory);
			expData.add(status);
			expData.add(webActions.getSystemCurrentDate());
			report.reportInfo("Expected Data is: "+expData);
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle = titleContent[0];
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			String expMessage=getDatafromMap(testData,"Message");
			report.reportInfo("Expected alert message: "+expMessage);
			if(expMessage.contains(actContent)){
				report.reportPass("Successfully Added new rule and Verified alert message");
			}else{
				report.reportFail("Failed to Add new rule and alert message is not matched: "+actContent,true);
				unmatch.append("Failed to Add new rule and alert message is not matched: ");
			}
			webActions.waitForPageLoaded();
			if("InActive".contentEquals(status)){
				webActions.click(chk_InActive, "InActive");
				webActions.click(btn_Apply, "Apply");
				webActions.waitForPageLoaded();
			}
			webActions.click(txt_Seach, "Search");
			webActions.sendKeys(txt_Seach, ruleTitle, "Searcch");
			webActions.waitForPageLoaded();
			ArrayList<String> actData=new ArrayList<>();
			List<WebElement>data=tr_RowData;
			for (WebElement webElement : data) {
				String rowData=webElement.getText();
				if(!rowData.isEmpty()){
					actData.add(rowData);
				}
			}
			report.reportInfo("Actual Data is: "+actData);
			ArrayList<String> umantchData=webActions.getUmatchedInArrayComparision(actData, expData);
			if(umantchData.size()==0){
				report.reportPass("Successfully verified the data after added new rule");
			}else{
				report.reportFail("Failed to verify the data after added new rule: "+actContent);
				unmatch.append("Failed to verify the data after added new rule:");
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void AddNewRulewithAllElementNames(DataTable testData){
		try {
			clickAddNewRuleButton();
			/*String displayRuleId=getUniqueNumber(5);
			webActions.sendKeys(txt_DisplayRuleId, displayRuleId, "DisplayRuleId");*/

			String module=getDatafromMap(testData,"Module");
			selectDropdown(dd_Module,module,"Module");

			//String elementName=getDatafromMap(testData,"ElementName");
			webActions.click(btn_Add_DataElement, "Add");
			webActions.waitForVisibilityOfAllElements(li_ElementNames, "Element Names");
			//webActions.sendKeys(txt_ElementName, elementName, "ElementName");
			webActions.click(btn_FirstBtn,  "FirstBtn");
			webActions.click(btn_Assign,  "btn_Assign");
			webActions.waitForPageLoaded();

			String errorCategory=getDatafromMap(testData,"ErrorCategory");

			selectDropdown(dd_ErrorCategory,errorCategory,"ErrorCategory");

			String ruleTitle=getDatafromMap(testData,"RuleTitle");
			ruleTitle=ruleTitle+"_"+webActions.getRandomString(6);
			webActions.sendKeys(txt_RuleTitle, ruleTitle, "RuleTitle");

			webActions.scrollBarHandle(txt_ErrorDescription, "ErrorDescription");
			String ruleCategory=getDatafromMap(testData,"RuleCategory");
			selectDropdown(dd_RuleCategoryId,ruleCategory,"RuleCategory");

			String errorDescription=getDatafromMap(testData,"ErrorDescription");
			webActions.sendKeys(txt_ErrorDescription, errorDescription, "ErrorDescription");

			webActions.click(btn_Add, "Add");

			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle = titleContent[0];
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			String expMessage=getDatafromMap(testData,"Message");
			report.reportInfo("Expected alert message: "+expMessage);
			if(expMessage.contains(actContent)){
				report.reportPass("Successfully Added new rule with all Element names and Verified alert message");
			}else{
				report.reportFail("Failed to Add new rule with all Element names and alert message is not matched: "+actContent);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void  verifyBreadcrumbForEditRule(DataTable breadcrumb){
		try {
			webActions.click(lnk_RuleTitle, "RuleTitle");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_FieldNames, "Field Names");
			ArrayList<String>expBreadcrumb=new ArrayList<String>(breadcrumb.asList());
			ArrayList<String> actBreadcrumb=webActions.getDatafromWebTable(lbl_Breadcrum_All);
			report.reportInfo("Actual Breadcrumb: "+actBreadcrumb);
			report.reportInfo("Expected Breadcrumb: "+expBreadcrumb);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actBreadcrumb, expBreadcrumb);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Breadcrumb in Edit Rule page");
			}
			else{
				report.reportFail("Fail to verify Breadcrumb in Edit Rule page");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyUnsavedChangesPopupEditRuleAndCancelButton(String message){
		try {
			webActions.sendKeys(txt_Seach, "Automation_", "Searcch");
			webActions.waitForPageLoaded();
			webActions.click(lnk_RuleTitle, "RuleTitle");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_FieldNames, "Field Names");
			webActions.waitForPageLoaded();
			webActions.click(txt_DisplyRuleId, "DisplyRuleId");
			webActions.sendKeys(txt_DisplyRuleId,"1234", "DisplyRuleId");
			webActions.click(lnk_RuleConfiguration, "RuleConfiguration");
			String actMessage=webActions.waitAndGetText(lbl_PopupMessage, "PopupMessage");
			if(message.contentEquals(actMessage)){
				report.reportPass("Successfully verified the Unsaved Changes Discard popup message");
			}
			else{
				report.reportFail("Failed to verify the Unsaved Changes Discard popup message");
			}
			webActions.click(btn_Close, "Close X");
			webActions.click(lnk_RuleConfiguration, "RuleConfiguration");
			actMessage=webActions.waitAndGetText(lbl_PopupMessage, "PopupMessage");
			webActions.waitForPageLoaded();
			webActions.click(btn_Discard, "Discard");
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_AddNewRule, "AddNewRule");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_FieldNames, "Field Names");
			webActions.click(btn_Cancel, "Cancel");
			boolean addButton=webActions.isDisplayed(btn_AddNewRule, "Add New Rule");
			if(addButton==true){
				report.reportPass("Successfully verified cancel button functionality in Add New Rule");
			}else{
				report.reportFail("Failed to verify cancel button functionality in Add New Rule");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyToggleSwitchStatus(String status){
		try {
			/*if(status.contentEquals("Active")){
				webActions.waitAndClick(txt_Seach, "Searcch");
				webActions.sendKeys(txt_Seach, "Automation", "Searcch");
				webActions.click(lnk_RuleTitle, "RuleTitle");
			}else if(status.contentEquals("InActive")){
				clickonRoleTitleforGivenStatus(status);
			}*/
			clickonRoleTitleforGivenStatus(status);
			String expToggleStatus=getExpStatus(status);
			webActions.waitForVisibilityOfAllElements(lbl_FieldNames, "Field Names");
			webActions.waitForPageLoaded();
			String actSwitchStatus=webActions.getAttributeValue(atr_SwitchActive, "aria-checked", "SwitchActive");
			if(expToggleStatus.contentEquals(actSwitchStatus)){
				report.reportPass("Successfully verified Toggle Switch Status for "+status+" Rule");
			}
			else{
				report.reportFail("Failed to verify the Toggle Switch Status for "+status+" Rule");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String clickonRoleTitleforGivenStatus (String status){
		String ruleTitle=null;
		try {
			webActions.waitAndClick(txt_Seach, "Searcch");
			webActions.sendKeys(txt_Seach, "Automation_", "Searcch");
			webActions.click(chk_InActive, "In Active");
			webActions.click(btn_Apply, "Apply");
			webActions.waitForPageLoaded();
			int row=tr_Results.size();
			for (int i = 1; i <= row; i++) {
				String actStatus=driver.findElement(By.xpath(tbl_RowData+i+tbl_RowData1)).getText();
				if(status.contentEquals(actStatus)){
					ruleTitle=driver.findElement(By.xpath(tbl_RowData+i+"]/td[2]/div/a")).getText();
					driver.findElement(By.xpath(tbl_RowData+i+"]/td[2]/div/a")).click();
					webActions.waitForPageLoaded();
					break;
				}
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
		return ruleTitle;
	}

	public void changeRuleStatusAndVerify(DataTable testData ){
		try {
			StringBuilder unmatch=new StringBuilder();
			ArrayList<String> actData= new ArrayList<>(testData.asList());
			String status=actData.get(0);
			String ruleTitle=clickonRoleTitleforGivenStatus(status);
			webActions.waitForVisibilityOfAllElements(lbl_FieldNames, "Field Names");
			webActions.waitForPageLoaded();
			webActions.click(atr_SwitchActive, "SwitchActive");
			webActions.click(btn_Add, "Add");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle = titleContent[0];
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			String expMessage=actData.get(1);
			report.reportInfo("Expected alert message: "+expMessage);
			if(expMessage.contains(actContent)){
				report.reportPass("Successfully changed the status for "+status+" Rule and Verified alert message");
			}else{
				report.reportFail("Failed to change the status for "+status+" Rule and alert message is not matched: "+actContent,true);
				unmatch.append("Failed to change the status for "+status+" Rule and alert message is not matched");
			}

			webActions.waitForPageLoaded();
			if("InActive".contentEquals(status)){
				webActions.click(chk_InActive, "InActive");
				webActions.click(btn_Apply, "Apply");
				webActions.waitForPageLoaded();
			}
			webActions.click(txt_Seach, "Search");
			webActions.sendKeys(txt_Seach, ruleTitle, "Searcch");
			webActions.waitForPageLoaded();
			String actStausAfterUpdate=webActions.getText(lbl_StatusFirstRow, "Status");
			String expStausAfterUpdate=actData.get(2);
			if(expStausAfterUpdate.contentEquals(actStausAfterUpdate)){
				report.reportPass("Successfully verified Status after updated "+status+" Rule");
			}else{
				report.reportFail("Failed to verify the Status after updated for "+status+" Rule");
				unmatch.append("Failed to verify the Status after updated for "+status+" Rule");
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
			
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void UpdateRule(DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			String ruleTitle_old=webActions.getText(lnk_RuleTitle, "RuleTitle");
			webActions.click(lnk_RuleTitle, "RuleTitle");
			webActions.waitForPageLoaded();
			
			String module=getDatafromMap(testData,"Module");
			selectDropdown(dd_Module,module,"Module");

			
			String elementName=getDatafromMap(testData,"ElementName");
			webActions.click(btn_EditDataElements, "EditDataElements");
			webActions.waitForVisibilityOfAllElements(li_ElementNames, "Element Names");
			webActions.click(li_SelectedElement,  "SelectedElement Name");
			webActions.click(btn_ThirdBtn,  "ThirdBtn");
			webActions.waitAndClick(btn_FirstBtn,  "FirstBtn");
			webActions.click(btn_FourthBtn,  "FourthBtn");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_ElementName, elementName, "ElementName");
			webActions.click(li_AllElement,  "AllElement");
			webActions.click(btn_SecondBtn,  "SecondBtn");
			webActions.click(btn_Assign,  "btn_Assign");
			webActions.waitForPageLoaded();
			
			webActions.scrollBarHandle(txt_ErrorDescription, "ErrorDescription");
			String ruleTitle=getDatafromMap(testData,"RuleTitle");
			ruleTitle=ruleTitle+"_"+webActions.getRandomString(6);
			webActions.clearValue(txt_RuleTitle, "RuleTitle");
			webActions.sendKeys(txt_RuleTitle, ruleTitle, "RuleTitle");
			
			String ruleCategory=getDatafromMap(testData,"RuleCategory");
			
			String errorDescription=getDatafromMap(testData,"ErrorDescription");
			webActions.clearValue(txt_ErrorDescription, "Error Description");
			webActions.sendKeys(txt_ErrorDescription, errorDescription, "Error Description");
			
			String status=getDatafromMap(testData,"Status");

			webActions.click(btn_Add, "Add");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle = titleContent[0];
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			String expMessage=getDatafromMap(testData,"Message");
			report.reportInfo("Expected alert message: "+expMessage);
			if(expMessage.contains(actContent)){
				report.reportPass("Successfully Updated Rule and Verified alert message");
			}else{
				report.reportFail("Failed to update Rule and alert message is not matched: "+actContent,true);
				unmatch.append("Failed to update Rule and alert message is not matched: ");
			}
			webActions.waitForPageLoaded();
			webActions.click(txt_Seach, "Search");
			webActions.sendKeys(txt_Seach, ruleTitle, "Searcch");
			webActions.waitForPageLoaded();
			
			ArrayList<String> actData=new ArrayList<>();
			List<WebElement>data=tr_RowData;
			for (WebElement webElement : data) {
				String rowData=webElement.getText();
				if(!rowData.isEmpty()){
					actData.add(rowData);
				}
			}
			report.reportInfo("Actual Data is: "+actData);
			ArrayList<String>expData=new ArrayList<String>();
			/*expData.add(displayRuleId+" "+ruleTitle);*/
			expData.add(ruleTitle);
			expData.add(module);
			expData.add(errorDescription);
			expData.add(elementName);
			expData.add(ruleCategory);
			expData.add(status);
			expData.add(webActions.getSystemCurrentDate());
			report.reportInfo("Expected Data is: "+expData);
			ArrayList<String> umantchData=webActions.getUmatchedInArrayComparision(actData, expData);
			if(umantchData.size()==0){
				report.reportPass("Successfully verified the data after updated rule");
			}else{
				report.reportFail("Failed to verify the data after updated rule: "+umantchData);
				unmatch.append("Failed to verify the data after updated rule:");
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String getExpStatus(String status){
		if("Active".contentEquals(status)){
			status="true";
		}else if("InActive".contentEquals(status)){
			status="false";
		}
		return status;
	}






	public void selectDropdown(WebElement element,String valuetoSelect,String elementName) throws Exception{
		try {
			if (!valuetoSelect.isEmpty()) {
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.click(element, elementName);
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				driver.findElement(By.xpath("//li[contains(.,'" + valuetoSelect + "')]")).click();
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public String getResponseStatus(String status){
		switch (status) {
		case "Clear":
			status="success";
			break;
		case "Review":
			status="alert";
			break;
		case "Needs Attention":
			status="error";
			break;
		}
		return status;
	}

	public String getUniqueNumber(int length) {
		String uniqueNumber = "";
		try {
			Date dNow = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("DDYYHHssMs");
			String s = ft.format(dNow);
			uniqueNumber = s.substring(0, Math.min(s.length(), length));

		} catch (Exception e) {

		}
		return uniqueNumber;
	}


	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(lnk_RulesConfiguration);
	}

}
