package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class CreateFacilityPage extends BasePage {

	RestActions rest=new RestActions();
	AddPatientVisitPage addPatient=new AddPatientVisitPage();

	@FindBy(xpath="//a[contains(text(),'Organization Maintenance')]")
	private WebElement lnk_OrgMaintenance;

	@FindBy(xpath="//a[contains(text(),'Maintenance')]")
	private WebElement lnk_Maintenance;

	@FindBy(xpath="//ejs-dashboardlayout/div/lib-panel/div/ejs-accordion//ul/li/div")
	private List<WebElement> lbl_MaintenancePageSections;

	@FindBy(xpath="//table[@class='e-table']/tbody/tr/td")
	private List<WebElement> lbl_TenantsGridData;

	@FindBy(xpath="//table[@class='e-table']/tbody/tr[1]/td[1]/a")
	private WebElement lnk_TenantName;

	@FindBy(xpath="//thead/tr/th | //div[@class='emptyinfo']")
	private List<WebElement> lbl_FacilityHeaderNames;

	@FindBy(xpath="//ipas-breadcrumb/div/span")
	private List<WebElement> lbl_FacilityBreadCrumb;

	@FindBy(xpath="//button[contains(text(),'Add New Facility')]")
	private WebElement btn_AddNewFacility;

	@FindBy(xpath="//form[@id='facilityform']/div")
	private List<WebElement> lbl_AddFacilityFields;

	@FindBy(xpath="//form[@id='facilityform']/div/div/label")
	private List<WebElement> lbl_AddFacilityFieldNames;

	@FindBy(xpath="//form[@id='facilityform']/div/div/ejs-dropdownlist | //form[@id='facilityform']/div/div/ejs-textbox | //form[@id='facilityform']/div/div/ejs-multiselect")
	private List<WebElement> lbl_FacilityFieldsPlaceholders;

	@FindBy(xpath="//div[@id='addFacilitySection']//label[@class='sectiontitle'] | //div[@class='headtitle']/span")
	private List<WebElement> lbl_AddFacilitySections;

	@FindBy(xpath="//button[@class='btn btn-primary btn-blk ml_10']")
	private WebElement btn_Save;

	@FindBy(xpath="//div[@class='mandatory']/div")
	private List<WebElement> lbl_FacilityMandatoryFields;

	@FindBy(xpath="//ejs-textbox[@placeholder='Facility Name']/span/input")
	private WebElement txt_FacilityName;

	@FindBy(xpath="//ejs-textbox[@placeholder='Facility Code']/span/input")
	private WebElement txt_FacilityCode;

	@FindBy(xpath="//ejs-dropdownlist[@placeholder='Select Facility Time Zone']/span/input")
	private WebElement ddl_FacilityTimeZone;

	@FindBy(xpath="//ejs-dropdownlist[@placeholder='Select Facility Type']/span/input")
	private WebElement ddl_FacilityType;

	@FindBy(xpath="//ejs-multiselect[@placeholder='Select EHR/PMS']/div/div/span/input")
	private WebElement ddl_EHR;

	@FindBy(xpath="//ejs-textbox[@placeholder='NPI']/span/input")
	private WebElement txt_NPI;

	@FindBy(xpath="//ejs-textbox[@placeholder='Tax ID']/span/input")
	private WebElement txt_TaxID;

	@FindBy(xpath="//ejs-textbox[@placeholder='City']/span/input")
	private WebElement txt_City;

	@FindBy(xpath="//ejs-textbox[@placeholder='Zip Code']/span/input")
	private WebElement txt_Zip;

	@FindBy(xpath="//div[@class='mandatory']/div")
	private WebElement lbl_FacilityMandatoryField;

	@FindBy(xpath="//div[@class='mandatory']")
	private WebElement lbl_FacilityMandatoryField1;

	@FindBy(xpath="//button[contains(text(),'Cancel')]")
	private WebElement btn_Cancel;

	@FindBy(xpath="//ejs-dropdownlist[@placeholder='Select Identifier Type']/span/input")
	private WebElement ddl_Identifier;

	@FindBy(xpath="//ejs-dropdownlist[@placeholder='Select Account ID']/span/input")
	private WebElement ddl_AccountID;

	@FindBy(xpath="//ejs-dropdownlist[@placeholder='Select Visit ID']/span/input")
	private WebElement ddl_VisitID;

	@FindBy(xpath="//ejs-dropdownlist[@placeholder='Select Patient ID']/span/input")
	private WebElement ddl_PatientID;

	@FindBy(xpath="//input[@placeholder='Type Facility Name']")
	private WebElement lbl_SearchFile;

	@FindBy(xpath="//div[@id='panel']//tbody/tr/td[1]/div")
	private List<WebElement> lbl_GridData; 

	@FindBy(xpath="//div[@id='panel']//tbody/tr[1]/td[1]/div[1]")
	private WebElement lbl_FacilityName;

	@FindBy(xpath="//div[@class='col-md-6 col-lg-6 p0 col-sm-12 tenantName']")
	private WebElement lbl_TenantNameFromFacilityPage;

	@FindBy(xpath="//thead/tr/th/div[1]/span")
	private List<WebElement> lbl_FacilityGridHeaders;

	@FindBy(xpath="//tbody/tr[1]/td[6]/div/a[1]/img")
	private WebElement Img_Pencil;

	@FindBy(xpath="//tbody/tr[1]/td[6]/div/a[2]/img")
	private WebElement Img_Trash;

	@FindBy(xpath="//table[@class='e-table']/tbody/tr[1]/td[4]/div")
	private WebElement lbl_CRMID;

	@FindBy(xpath="//div[@class='col-md-6 col-lg-6 col-sm-12 crmid']")
	private WebElement lbl_CRMID_FacilityPage;

	@FindBy(xpath="//div[@class='col-md-6 col-lg-6 col-sm-12 crmid']/a")
	private WebElement lbl_CRMID_FacilityPageLink;

	@FindBy(xpath="//div[@id='panel']//tbody/tr")
	private String lbl_FacilityListCount;

	@FindBy(xpath="//div[@class='col-12']/div/span")
	private WebElement lbl_FacilityResultCount;

	@FindBy(xpath="//table[@class='e-table']/tbody/tr[2]/td[1]/div[2]")
	private WebElement lbl_FacilityCode_Line2;

	@FindBy(xpath="//a[contains(text(),'Facilities')]")
	private WebElement lnk_Facilities;

	@FindBy(xpath="//a[contains(text(),'Tenants')]")
	private WebElement lnk_Tenants;

	@FindBy(xpath="//button[contains(text(),'Add New Tenant')]")
	private WebElement btn_AddNewTenant;
	
	@FindBy(xpath="//div[@class='grid']/div")
	private WebElement lbl_NoResultsMsg;

	public CreateFacilityPage() {
		PageFactory.initElements(driver, this);
	}
	public void navigateToMaintenance(){
		try {
			webActions.waitForVisibility(lnk_Maintenance, "MaintenanceLink");			
			webActions.click(lnk_Maintenance, "Maintenance");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_MaintenancePageSections, "MaintenancePanels");
			report.reportPass("Clicked on Maintenance link and navigated to the Maintenance Page Successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());	
		}
	}
	public void clickOrgMaintenance(){
		try {
			webActions.click(lnk_OrgMaintenance, "OrganizationLink");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_TenantsGridData, "ListofTenants");
			report.reportPass("Clicked on organization link and navigated to the list of tenants Page Successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickOnTenantName(){
		try {
			webActions.click(lnk_TenantName, "TenantNameLink");
			webActions.waitForPageLoaded();
			//webActions.waitForVisibility(lbl_NoResultsMsg, "NoDataMsg");
			
			try{
			webActions.waitForVisibilityOfAllElements(lbl_FacilityHeaderNames, "FacilityHeaderNames");
			webActions.waitForVisibilityOfAllElements(lbl_GridData, "FacilityData");
			}
			catch (Exception e){
				webActions.waitForVisibility(lbl_NoResultsMsg, "NoDataMsg");
			}
			report.reportPass("Clicked on tenant name link and navigated to the list of facilities Page Successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyBreadcrumbinListOfFacilityPage(DataTable breadcrumb ){
		try {
			ArrayList<String> expectdBreadcrumb = new ArrayList<>(breadcrumb.asList());		
			ArrayList<String> actualBreadcrumb=webActions.getDatafromWebTable(lbl_FacilityBreadCrumb);
			report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumb);
			report.reportInfo("Expected Breadcrumb Titles "+expectdBreadcrumb);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumb, expectdBreadcrumb);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Breadcrumb Titles in list of facility/facility page");
			}else{
				throw new Exception("Fail to verify the Breadcrumb Titles in list of facility/facility page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyfields(){
		try {
			webActions.waitForVisibility(btn_AddNewFacility, "AddFacility");
			webActions.assertDisplayed(btn_AddNewFacility, "AddFacility");			
			report.reportPass("Add New Facility button is displayed on list of facilities search page");
		} catch (Exception e) {
			report.reportFail("Add New Facility button is displayed on list of facilities search page");
		}
	}

	public void clickOnAddNewFacility(){
		try {
			webActions.waitForVisibility(btn_AddNewFacility, "AddFacility");
			webActions.click(btn_AddNewFacility, "AddFacility");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibilityOfAllElements(lbl_AddFacilityFields, "FacilityPageFields");
			report.reportPass("Navigated to the Add facility page successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyfieldsAndSections(String scenario, DataTable testData) {
		try {
			ArrayList<String> actualData = null;
			ArrayList<String> expectedData = new ArrayList<>(testData.asList());
			if(scenario.contentEquals("fields")){
				report.reportInfo("Expected fields from add new facility page "+expectedData);
				webActions.waitForPageLoaded();
				actualData=webActions.getDatafromWebTable(lbl_AddFacilityFieldNames);
				report.reportInfo("Displayed fields in add new facility page: "+actualData);
			}
			else if (scenario.contentEquals("placeholders")){
				report.reportInfo("Expected placeholders in fields from add new facility page "+expectedData);
				webActions.waitForPageLoaded();
				actualData=webActions.getListofAttributeValuesfromWebPage(lbl_FacilityFieldsPlaceholders,"placeholder");
				report.reportInfo("Displayed placeholders in fields from add new facility page: "+actualData);
			}
			else if (scenario.contentEquals("sections")){
				report.reportInfo("Expected sections from add new facility page "+expectedData);
				webActions.waitForPageLoaded();
				actualData=webActions.getDatafromWebTable(lbl_AddFacilitySections);
				report.reportInfo("Displayed sections in from add new facility page: "+actualData);
			}
			else if (scenario.contentEquals("mandatory")){
				report.reportInfo("Expected mandatory fields from add new facility page "+expectedData);
				webActions.waitForPageLoaded();
				webActions.click(txt_FacilityName, "FacilityName");				
				int fieldsSize=lbl_FacilityFieldsPlaceholders.size();
				System.out.println("fieldsSize"+fieldsSize);			
				for( int i=1;i<=fieldsSize;i++){
					webActions.pressTab();
					webActions.waitForPageLoaded();
				}
				webActions.waitForPageLoaded();
				actualData=webActions.getDatafromWebTable(lbl_FacilityMandatoryFields);
				report.reportInfo("Displayed mandatory fields from add new facility page: "+actualData);
			}
			ArrayList<String>unmatchedFields=webActions.getUmatchedInArrayComparision(actualData, expectedData);
			if(unmatchedFields.size()==0){
				report.reportPass("Verified fields "+scenario+" from add new facility page successfully");
			}
			else{
				report.reportFail("Fail to verify "+scenario+" from add new facility page and unmatched "+scenario+" are: "+unmatchedFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifySavebtnMode(){
		try {
			webActions.waitForPageLoaded();
			webActions.scrollDownPage();
			webActions.waitForPageLoaded();
			boolean flag=btn_Save.isEnabled();
			if(flag){
				report.reportFail("Save button is displayed in enable mode by default");
			}
			else{
				report.reportPass("Verified Save button mode successfully");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	//***Sample**/
	public void enterData(String data){
		try {
			webActions.waitForPageLoaded();
			webActions.click(txt_FacilityName, "FacilityName");
			webActions.sendKeys(txt_FacilityName, data, "FacilityName");
			webActions.waitForPageLoaded();
			String text=webActions.getText(txt_FacilityName, "FacilityName");
			report.reportInfo(text);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyNPIValidations(String expMsg,String input){		
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(txt_NPI, "NPI");
			webActions.waitForPageLoaded();			
			webActions.clearValue(txt_NPI, "NPI");
			webActions.waitForPageLoaded();			
			webActions.sendKeys(txt_NPI, input, "NPI");
			webActions.pressTab();
			webActions.waitForPageLoaded();
			String actaulMessage="";
			if (expMsg.contentEquals("Maximum 10 digits Numeric Only")){
				String actaulMsg=webActions.getText(lbl_FacilityMandatoryField1, "NPIvalidation");
				actaulMessage=actaulMsg.replaceAll("\n", " ");				
			}			
			else{
				actaulMessage=webActions.getText(lbl_FacilityMandatoryField, "NPIvalidation");
			}

			report.reportInfo("Expected validation message is : " + expMsg);
			report.reportInfo("Actual validation message is : " + actaulMessage);

			if(actaulMessage.contentEquals(expMsg)){
				report.reportPass("Verified NPI validation message successfully");
			}
			else{
				report.reportFail("Fail to verify NPI validation message");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyfieldValidations(String field,String expMsg,String input){		
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String actaulMessage="";

			if("TaxID".contentEquals(field)){
				webActions.click(txt_TaxID, "TaxID");
				webActions.waitForPageLoaded();
				webActions.clearValue(txt_TaxID, "TaxID");
				webActions.waitForPageLoaded();
				webActions.sendKeys(txt_TaxID, input, "TaxID");
				webActions.pressTab();
				webActions.waitForPageLoaded();
			}
			else if("City".contentEquals(field)){
				webActions.click(txt_City, "City");
				webActions.waitForPageLoaded();
				webActions.clearValue(txt_City, "City");
				webActions.waitForPageLoaded();
				webActions.sendKeys(txt_City, input, "City");
				webActions.pressTab();
				webActions.waitForPageLoaded();
			}
			else if("ZipCode".contentEquals(field)){
				webActions.click(txt_Zip, "Zip");
				webActions.waitForPageLoaded();
				webActions.clearValue(txt_Zip, "Zip");
				webActions.waitForPageLoaded();
				webActions.sendKeys(txt_Zip, input, "Zip");
				webActions.pressTab();
				webActions.waitForPageLoaded();
			}
			if (expMsg.contentEquals("Maximum 5 digits Numeric Only")){
				String actaulMsg=webActions.getText(lbl_FacilityMandatoryField1, "Zipvalidation");
				actaulMessage=actaulMsg.replaceAll("\n", " ");				
			}			
			else{
				actaulMessage=webActions.getText(lbl_FacilityMandatoryField, "Validations");
			}
			//actaulMessage=webActions.getText(lbl_FacilityMandatoryField, "NPIvalidation");				
			report.reportInfo("Expected validation message is : " + expMsg);
			report.reportInfo("Actual validation message is : " + actaulMessage);

			if(actaulMessage.contentEquals(expMsg)){
				report.reportPass("Verified "+field+" validation message successfully");
			}
			else{
				report.reportFail("Fail to verify "+field+" validation message");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickCancelAndVerify(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_Cancel, "Cancel");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_FacilityHeaderNames, "FacilityHeaderNames");
			webActions.waitForVisibility(btn_AddNewFacility, "AddFacility");
			webActions.assertDisplayed(btn_AddNewFacility, "AddFacility");			
			report.reportPass("Add New Facility button is displayed on list of facilities search page");

		} catch (Exception e) {
			report.reportFail("Failed to verify the Add New Facility button from list of facilities page");
		}
	}

	public void enterDataInFacilityFields(DataTable testData){
		try {	
			webActions.waitForPageLoaded();
			webActions.click(txt_FacilityName, "FacilityName");			
			webActions.sendKeys(txt_FacilityName,webActions.getDatafromMap(testData,"Facility Name"), "Facility Name");
			webActions.waitForPageLoaded();
			webActions.click(txt_FacilityCode, "FacilityCode");			
			webActions.sendKeys(txt_FacilityCode,webActions.getDatafromMap(testData,"Facility Code"), "Facility Code");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_FacilityTimeZone, "FacilityZone");	
			webActions.sendKeys(ddl_FacilityTimeZone,webActions.getDatafromMap(testData,"Facility Time Zone"), "Facility Time Zone");			
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_FacilityType, "FacilityType");
			webActions.sendKeys(ddl_FacilityType,webActions.getDatafromMap(testData,"Facility Type"), "Facility Type");			
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();			
			selectDropdown(ddl_EHR, webActions.getDatafromMap(testData,"EHRPMS"), "EHRPMS");				
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_Identifier, "Identifier");
			webActions.sendKeys(ddl_Identifier,webActions.getDatafromMap(testData,"Identifier Type"), "Identifier Type");			
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_AccountID, "AccountID");
			webActions.sendKeys(ddl_AccountID,webActions.getDatafromMap(testData,"Account ID"), "Account ID");		
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_VisitID, "VisitID");
			webActions.sendKeys(ddl_VisitID,webActions.getDatafromMap(testData,"Visit ID"), "Visit ID");			
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_PatientID, "PatientID");
			webActions.sendKeys(ddl_PatientID,webActions.getDatafromMap(testData,"Patient ID"), "Patient ID");			
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();

			report.reportPass("Entered data in add new facility window successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	public void selectDropdown(WebElement element,String valuetoSelect,String elementName) throws Exception{
		try {
			if (!valuetoSelect.isEmpty()) {
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.clickAction(element, elementName);
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				driver.findElement(By.xpath("//li[contains(.,'" + valuetoSelect + "')]")).click();				
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public String createFacility(DataTable testData){

		String facilityName="";
		try {
			webActions.waitForPageLoaded();
			webActions.click(txt_FacilityName, "FacilityName");
			String name=webActions.getRandomString(5);
			facilityName="V"+name;
			webActions.sendKeys(txt_FacilityName,facilityName,"Facility Name");
			webActions.waitForPageLoaded();
			webActions.click(txt_FacilityCode, "FacilityCode");	
			String code=rest.randomNumber(6);
			String facilityCode="V"+code;
			addPatient.notepadWrite("hello",facilityCode);
			webActions.sendKeys(txt_FacilityCode,facilityCode, "Facility Code");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_FacilityTimeZone, "FacilityZone");	
			webActions.sendKeys(ddl_FacilityTimeZone,webActions.getDatafromMap(testData,"Facility Time Zone"), "Facility Time Zone");			
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_FacilityType, "FacilityType");
			webActions.sendKeys(ddl_FacilityType,webActions.getDatafromMap(testData,"Facility Type"), "Facility Type");			
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();			
			selectDropdown(ddl_EHR, webActions.getDatafromMap(testData,"EHRPMS"), "EHRPMS");				
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_Identifier, "Identifier");
			webActions.sendKeys(ddl_Identifier,webActions.getDatafromMap(testData,"Identifier Type"), "Identifier Type");			
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_AccountID, "AccountID");
			webActions.sendKeys(ddl_AccountID,webActions.getDatafromMap(testData,"Account ID"), "Account ID");		
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_VisitID, "VisitID");
			webActions.sendKeys(ddl_VisitID,webActions.getDatafromMap(testData,"Visit ID"), "Visit ID");			
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_PatientID, "PatientID");
			webActions.sendKeys(ddl_PatientID,webActions.getDatafromMap(testData,"Patient ID"), "Patient ID");			
			webActions.waitForPageLoaded();
			webActions.pressTab();
			webActions.waitForPageLoaded();
			report.reportPass("Entered data in facility window successfully");
			webActions.clickAction(btn_Save, "Save");
			report.reportPass("Selected Save button successfully");			
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
		return facilityName;
	}
	public void verifyCreatedFacilityNameFromGrid(String facilityName){
		try {							
			String actualFacilityName=webActions.getText(lbl_FacilityName, "FacilityName");
			report.reportInfo("Expected facilityName : " + facilityName);
			report.reportInfo("Displayed facilityName : " + actualFacilityName);			
			if(actualFacilityName.trim().contentEquals(facilityName.trim())){
				report.reportPass("Verified facility name successfully from grid");
			}
			else{
				report.reportFail("Fail to verify facility name from result grid and actual displayed facility name : " + actualFacilityName);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void searchFacilityName(String input){
		try {
			webActions.waitForPageLoaded();
			//webActions.waitForVisibilityOfAllElements(lbl_GridData, "GridData");
			webActions.clickAction(lbl_SearchFile, "SearchField");
			webActions.waitForPageLoaded();		
			webActions.enterValuesfromKeyBoard(lbl_SearchFile, input, "SearchField");
			webActions.waitForPageLoaded();				
			webActions.waitForVisibilityOfAllElements(lbl_GridData, "GridData");
			report.reportPass("Performed search successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDuplicateFacilityCode(DataTable testData){
		try {
			webActions.waitForPageLoaded();
			webActions.click(txt_FacilityName, "FacilityName");
			String name=webActions.getRandomString(5);
			String facilityName="V"+name;
			webActions.sendKeys(txt_FacilityName,facilityName,"Facility Name");
			webActions.waitForPageLoaded();
			webActions.click(txt_FacilityCode, "FacilityCode");	
			String facilityCode=addPatient.notepadRead("hello");
			webActions.sendKeys(txt_FacilityCode,facilityCode, "Facility Code");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_FacilityTimeZone, "FacilityZone");	
			webActions.sendKeys(ddl_FacilityTimeZone,webActions.getDatafromMap(testData,"Facility Time Zone"), "Facility Time Zone");			
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_FacilityType, "FacilityType");
			webActions.sendKeys(ddl_FacilityType,webActions.getDatafromMap(testData,"Facility Type"), "Facility Type");			
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();			
			selectDropdown(ddl_EHR, webActions.getDatafromMap(testData,"EHRPMS"), "EHRPMS");				
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_Identifier, "Identifier");
			webActions.sendKeys(ddl_Identifier,webActions.getDatafromMap(testData,"Identifier Type"), "Identifier Type");			
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_AccountID, "AccountID");
			webActions.sendKeys(ddl_AccountID,webActions.getDatafromMap(testData,"Account ID"), "Account ID");		
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_VisitID, "VisitID");
			webActions.sendKeys(ddl_VisitID,webActions.getDatafromMap(testData,"Visit ID"), "Visit ID");			
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clickAction(ddl_PatientID, "PatientID");
			webActions.sendKeys(ddl_PatientID,webActions.getDatafromMap(testData,"Patient ID"), "Patient ID");			
			webActions.waitForPageLoaded();
			webActions.pressTab();
			webActions.waitForPageLoaded();
			report.reportPass("Entered data in facility window successfully");
			webActions.clickAction(btn_Save, "Save");
			report.reportPass("Selected Save button successfully");		
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyTenantName(){
		try {
			webActions.waitForPageLoaded();
			String expectedTenantName=webActions.getText(lnk_TenantName, "FirstDisplayTenantNameFromGrid");
			clickOnTenantName();
			webActions.waitForPageLoaded();
			String displayedTenantName=webActions.getText(lbl_TenantNameFromFacilityPage, "DisplayedTenantName");
			report.reportInfo("Expected Tenant Name: " +expectedTenantName);
			report.reportInfo("Displayed Tenant Name: " +displayedTenantName);
			if(expectedTenantName.contentEquals(displayedTenantName)){
				report.reportPass("Verified tenant name successfully");
			}
			else{
				report.reportFail("Fail to verify tenant name");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyViewListofFacilityHeaders(DataTable testData){
		try {
			ArrayList<String> expectdHeaders = new ArrayList<>(testData.asList());		
			ArrayList<String> actualHeaders=webActions.getDatafromWebTable(lbl_FacilityGridHeaders);
			report.reportInfo("Actual header names: "+actualHeaders);
			report.reportInfo("Expected header names "+expectdHeaders);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualHeaders, expectdHeaders);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the view list of facility headers");
			}else{
				throw new Exception("Fail to verify the view list of facility headers: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyIcons(){
		try {
			webActions.waitForPageLoaded();

			String displayedEditImg=webActions.getAttributeValue(Img_Pencil, "src", "EditImage");
			if(displayedEditImg.contains("edit")){
				report.reportPass("Pencil icon is displayed");
			}
			else{
				report.reportFail("Pencil icon is not displayed and actual displayed image is : " + displayedEditImg,true);
			}
			String displayedTrashImg=webActions.getAttributeValue(Img_Trash, "src", "DeleteImage");
			if(displayedTrashImg.contains("delete")){
				report.reportPass("Delete icon is displayed");
			}
			else{
				report.reportFail("Delete icon is not displayed and actual displayed image is : " + displayedTrashImg);
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyTenantCRMID(){
		try {
			webActions.waitForPageLoaded();
			String expectedID=webActions.getText(lbl_CRMID, "CRMID");
			String expectedCRMID="CRM ID: "+expectedID;
			clickOnTenantName();
			webActions.waitForPageLoaded();
			String displayedCRMID=webActions.getText(lbl_CRMID_FacilityPage, "DisplayedCRMIDFromFacilityPage");
			report.reportInfo("Expected Tenant CRMID: " +expectedCRMID);
			report.reportInfo("Displayed Tenant CRMID: " +displayedCRMID);
			if(expectedCRMID.trim().contentEquals(displayedCRMID.trim())){
				report.reportPass("Verified tenant CRMID successfully");
			}
			else{
				report.reportFail("Fail to verify tenant CRMID");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyCRMIDLink(){
		try {
			webActions.click(lbl_CRMID_FacilityPageLink, "CRM ID");
			webActions.waitForPageLoaded();
			webActions.switchToOtherOpenedWindow();
			webActions.waitForPageLoaded();
			Thread.sleep(2000);
			String actPageTitle=webActions.getPageTitle();
			if("Checking browser".contentEquals(actPageTitle)){
				report.reportPass("Successfully verified CRMID as Hyperlink");
			}else{
				report.reportFail("Failed to verify CRMID as Hyperlink");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyResultCountOfViewFacilityList(){
		try {
			webActions.waitForPageLoaded();
			List<WebElement> resultsCount=driver.findElements(By.xpath("//div[@id='panel']//tbody/tr"));
			int expResultsCount=resultsCount.size()-1;
			report.reportInfo("Epected Result Count: "+expResultsCount);
			String actResults=webActions.getText(lbl_FacilityResultCount, "ResultCount");
			String[] actRes=actResults.split(":");
			String actResultsCou=actRes[1];
			int actResultsCount=Integer.parseInt(actResultsCou);
			report.reportInfo("Actual Result Count: "+actResultsCount);
			if(actResultsCount==expResultsCount){
				report.reportPass("Verified result count successfully");
			}
			else{
				report.reportFail("Fail to verify result count");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnPencilIcon(){
		try {
			webActions.click(Img_Pencil, "EditFacilityLink");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibilityOfAllElements(lbl_AddFacilityFields, "FacilityFields");
			webActions.waitForJSandJQueryToLoad();
			Thread.sleep(2000);
			report.reportPass("Clicked on pencil icon and navigated to the edit facility Page Successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyUpdatebtnMode(){
		try {
			webActions.waitForPageLoaded();
			webActions.scrollDownPage();
			webActions.waitForPageLoaded();
			boolean flag=btn_Save.isEnabled();
			if(flag){
				report.reportPass("Update button is displayed in enable mode by default");
			}
			else{
				report.reportFail("Fail to verify update button mode successfully",true);
			}
			webActions.click(txt_FacilityName, "FacilityName");
			webActions.clearValue(txt_FacilityName, "FacilityName");
			webActions.waitForPageLoaded();
			webActions.scrollDownPage();
			webActions.waitForPageLoaded();
			boolean flag1=btn_Save.isEnabled();
			if(flag1){
				report.reportFail("Fail to verify update button mode");
			}
			else{
				report.reportPass("Verify update button mode successfully");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void updateAndVerifyFacilityName(){
		try {
			webActions.click(txt_FacilityName, "FacilityName");
			webActions.clearValue(txt_FacilityName, "FacilityName");
			webActions.waitForPageLoaded();			
			String name=webActions.getRandomString(5);
			String expFacilityName="V"+name;
			webActions.sendKeys(txt_FacilityName,expFacilityName,"Facility Name");
			webActions.waitForPageLoaded();
			webActions.scrollDownPage();
			webActions.waitForPageLoaded();
			webActions.clickAction(btn_Save, "Save");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_FacilityHeaderNames, "FacilityHeaderNames");
			webActions.waitForVisibilityOfAllElements(lbl_GridData, "FacilityData");
			searchFacilityName(expFacilityName);
			verifyCreatedFacilityNameFromGrid(expFacilityName);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clearValuesFromEditFacility(DataTable testData){
		try {
			webActions.click(txt_FacilityName, "FacilityName");
			webActions.clearValue(txt_FacilityName, "FacilityName");
			webActions.waitForPageLoaded();
			webActions.pressTab();
			webActions.clearValue(txt_FacilityCode, "FacilityCode");
			webActions.waitForPageLoaded();
			ArrayList<String> actualData =webActions.getDatafromWebTable(lbl_FacilityMandatoryFields);
			ArrayList<String> expectedData = new ArrayList<>(testData.asList());			
			report.reportInfo("Displayed mandatory fields from Edit facility page: "+actualData);
			report.reportInfo("Expected mandatory fields from Edit facility page: "+expectedData);
			ArrayList<String>unmatchedFields=webActions.getUmatchedInArrayComparision(actualData, expectedData);
			if(unmatchedFields.size()==0){
				report.reportPass("Verified mandatory fields from edit facility page successfully");
			}
			else{
				report.reportFail("Fail to verify mandatory fields from edit facility page and unmatched fields are: "+unmatchedFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void updateWithDuplicateFacilityCode(){
		try {
			String facilityCode=webActions.getText(lbl_FacilityCode_Line2, "FacilityCode");
			webActions.waitForPageLoaded();
			clickOnPencilIcon();
			webActions.waitForPageLoaded();
			webActions.click(txt_FacilityCode, "FacilityCode");
			webActions.clearValue(txt_FacilityCode, "FacilityCode");
			webActions.waitForPageLoaded();			
			webActions.sendKeys(txt_FacilityCode,facilityCode, "Facility Code");
			webActions.waitForPageLoaded();
			webActions.clickAction(btn_Save, "Save");
			webActions.waitForPageLoaded();
			report.reportInfo("Selected Save button successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clearFacilityNameSearch(){
		try {
			webActions.waitForPageLoaded();			
			webActions.clearValue(lbl_SearchFile, "SearchField");
			webActions.refreshPage();
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_FacilityHeaderNames, "FacilityHeaderNames");
			webActions.waitForVisibilityOfAllElements(lbl_GridData, "FacilityData");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnFacilitiesBreadCrumb(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lnk_Facilities, "FacilitiesBreadCrumb");
			webActions.waitForVisibilityOfAllElements(lbl_FacilityHeaderNames, "FacilityHeaderNames");
			webActions.waitForVisibilityOfAllElements(lbl_GridData, "FacilityData");
			webActions.assertDisplayed(btn_AddNewFacility, "AddFacility");
			report.reportPass("Verified page navigation from facility breadcrumb");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnTenantsBreadCrumb(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lnk_Tenants, "TenantsBreadCrumb");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_TenantsGridData, "ListofTenants");
			webActions.assertDisplayed(btn_AddNewTenant, "AddTenant");
			report.reportPass("Verified page navigation from tenant breadcrumb");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
