package com.ipas.hf.web.steps;

import java.util.ArrayList;

import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.STFullPagePage;
import com.ipas.hf.web.pages.ipasPages.ServiceTrackerPage;
import com.ipas.hf.web.pages.ipasPages.UpdateVisitPage;
import com.ipas.hf.web.pages.ipasPages.VPVServiceTrackerPanelPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class STFullPageSteps {

	STFullPagePage stfullpage = new STFullPagePage();
	VPVServiceTrackerPanelPage vsrvcPanel = new VPVServiceTrackerPanelPage();
	UpdateVisitPage updateVisit = new UpdateVisitPage();
	ServiceTrackerPage srvTracker = new ServiceTrackerPage();
	Login logIn = new Login();
	
	@Then("Navigate to Service Tracker FullPage")
	public void navigate_to_Service_Tracker_FullPage() throws Exception {
		String visitID= updateVisit.getValuefromJSONresponseBasedOnObject();
		stfullpage.navigateToSTFullPageFromSTPage(visitID);
	}

	@Then("Verify Service Tracker is highlighted")
	public void verify_Service_Tracker_highlighted() throws Exception {
		stfullpage.verifySTPageHighlighted();
	}

	@Then("Verfiy Account Search is highlighted")
	public void verfiy_Account_Search_is_highlighted() throws Exception {
		stfullpage.verifyASPageHighlighted();
	}

	@Then("Get AccountID from response body as {string} and verify displayed breadcrumb based on followed by Patient Visit number as {string} and as {string}")
	public void get_AccountID_from_response_body_as_and_verify_displayed_breadcrumb_based_on_followed_by_Patient_Visit_number_as_and_as(String visitId, String pageName, String menuName) throws Exception {
		stfullpage.verifyDisplayedBreadcrumbFollowedbyAllData(visitId, pageName, menuName);
	}

	@Then("Verify ServiceDepartment, Destination and Registrar for VisitID as {string}")
	public void verify_ServiceDepartment_Destination_and_Registrar(String responseValue) throws Exception {
		Thread.sleep(20000);
		ArrayList<String> actList = updateVisit.verifyDestinationRegistrarOnCard();		
		String visitID= logIn.getVisitIdFromResponse(responseValue);
		stfullpage.navigateToSTFullPageFromSTPage(visitID);
		ArrayList<String> expList = stfullpage.readDataOnSTFPage();
		stfullpage.compareDataonVisitCardAndSTFPage(actList,expList);
	}

	@Then("Get Current Status of Visit Card")
	public void get_Current_Status_of_Visit_Card() throws Exception {
		stfullpage.getIntakeStatusFromModelWindow();
	}

	@Then("Verify Status of Visit Card on Service Tracker Full Page")
	public void verify_Status_of_Visit_Card_on_Service_Tracker_Full_Page() throws Exception {
		stfullpage.compareStatus();

	}

	@Then("Open Model Window on Service Tracker Full Page")
	public void open_Model_Window_on_Service_Tracker_Full_Page() throws Exception {
		stfullpage.openModelWindowOnSTFPage();
	}

	@Then("Verify Service Tracker Title and Module Status")
	public void verify_Service_Tracker_Title_and_Module_Status() throws Exception {
		stfullpage.verifyTitleModuleStatusonSTFPage();
	}

	@Then("Select Priority indicator and verify on STFPage and Visit Card")
	public void select_Priority_indicator_and_verify() throws Exception {
		String visitID= updateVisit.getValuefromJSONresponseBasedOnObject();
		stfullpage.openModelWindowOnSTFPage();
		updateVisit.selectPriority();
		updateVisit.clickSubmit();
		updateVisit.getfilterMessages();
		stfullpage.closeModelWindowOnSTFPage();
		stfullpage.priorityDisplayedOnSTFPage();

	}

	@Then("Verify Priority indicator is not displayed on STFPage and Visit Card")
	public void verify_Priority_indicator_is_not_displayed_on_STFPage_and_Visit_Card() throws Exception {
		stfullpage.priorityNotDisplayedOnSTFPage();
	}

	@Then("Verify D before Service Department in Service Tracker FullPage")
	public void verify_D_before_Service_Department_in_Service_Tracker_FullPage() throws Exception {
		stfullpage.verifyDbfrSDInSTFPage();
	}

	@Then("Verify No WheelChair Icon on Service Tracker FullPage")
	public void verify_No_WheelChair_Icon_on_Service_Tracker_FullPage() throws Exception {
		stfullpage.wheelChairNotDisplayedOnSTFPage();
	}

	@Then("Verify comma is displayed between Registrar and Destionation of STFull Page")
	public void verify_comma_is_displayed_between_Registrar_and_Destionation_of_STFull_Page() throws Exception {
		stfullpage.verifyComma();
	}

	@Then("Verify Current Status on Visit Card and STFull Page")
	public void verify_Current_Status_on_Visit_Card_and_STFull_Page() throws Exception {
		stfullpage.compareStatus();	
	}

	@Then("Verify Tracking History Text on Service Tracker FullPage")
	public void verify_Tracking_History_Text_on_Service_Tracker_FullPage() throws Exception {
		stfullpage.verifyTrackingHistoryTextOnSTFullPage();
	}

	@Then("Verify Visit Status on Visit Card and Service Tracker FullPage")
	public void verify_Visit_Status_on_Visit_Card_and_Service_Tracker_FullPage() throws Exception {
		stfullpage.verifyStatusInGrid();
	}

	@Then("Verify ServiceDepartment, Destination and Registrar on STFullPage and VisitCard")
	public void verify_ServiceDepartment_Destination_and_Registrar_on_STFullPage_and_VisitCard() throws Exception {
		Thread.sleep(10000);
		String visitID= updateVisit.getValuefromJSONresponseBasedOnObject();
		ArrayList<String> expList = stfullpage.readDataOnSTFPage();
		vsrvcPanel.clickVisitID(visitID);
		stfullpage.clickOnServiceTrackerBreadCrumb();
		Thread.sleep(15000);
		updateVisit.simpleSearch(visitID);
		ArrayList<String> actList = updateVisit.verifyDestinationRegistrarOnCard();		
		stfullpage.compareDataonVisitCardAndSTFPage(actList,expList);
	}

	@Then("click on Submit button and close the Model Window on STFPage")
	public void click_on_Submit_button_and_close_the_Model_Window() throws Exception {
		updateVisit.clickSubmit();
		updateVisit.getfilterMessages();
		stfullpage.closeModelWindowOnSTFPage();
	}

	@Then("Navigate to AccountSearch Page")
	public void navigate_to_the_Account_Search_page() {
		stfullpage.navigateToAccountSearchPage();
	}

	@Then("Navigate to ServiceTracker FullPage From STPanel")
	public void navigate_to_ServiceTracker_FullPage_From_STPanel() throws Exception {
		stfullpage.navigateToSTFullPageFromPanel();
	}

	@Then("Verify ServiceDepartment, Destination and Registrar on STFullPage and VisitCard through AccountSearch")
	public void verify_ServiceDepartment_Destination_and_Registrar_on_STFullPage_and_VisitCard_through_AccountSearch() throws Exception {
		Thread.sleep(10000);
		String visitID= updateVisit.getValuefromJSONresponseBasedOnObject();
		ArrayList<String> expList = stfullpage.readDataOnSTFPage();
		vsrvcPanel.clickVisitID(visitID);
		srvTracker.navigatetoServiceTrackerPage("iPAS");
		updateVisit.simpleSearch(visitID);
		ArrayList<String> actList = updateVisit.verifyDestinationRegistrarOnCard();		
		stfullpage.compareDataonVisitCardAndSTFPage(actList,expList);
	}

	@Then("Refresh the Current Page")
	public void refresh_the_Current_Page() throws Exception {
		stfullpage.pageRefresh();
	}

	@Then("Get value from response body and get value of {string} and click on visit number")
	public void get_value_from_response_body_and_get_value_of_and_click_on_visit_number(String responseValue) throws Exception {
		stfullpage.getVisitNumFrmResponseAndClickOnAccountNumber(responseValue);
	}


}
