package com.ipas.hf.web.pages.ipasPages;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

public class ServiceTrackerSimpleSearchPage extends BasePage {
	UpdateVisitPage updateVisit = new UpdateVisitPage();
	String resetPassword="";
	private RestActions rest = new RestActions();
	private StepLogging log = StepLogging.getLoggingObject();
	@FindBy(xpath = "//input[@id='username']")
	private WebElement txt_UserName;
	private static final String UPDATEPATIENTVISITJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\UpdatePatientVisit.json";
	private JSONObject jsonObject;
	@FindBy(xpath = "//div[@class='card-header']/div")
	private List<WebElement> txt_PatientName;

	@FindBy(xpath = "//div[@class='card-body']/div/div[2]/a")
	private List<WebElement> txt_VisitID;

	@FindBy(xpath = "//service-tracker-taskboard[1]/div[1]/div[1]/div[2]/div[1]/img")
	private WebElement img_NoRecordsFound;
	
	@FindBy(xpath = "//img[@src='assets/images/reset-red.svg']")
	private WebElement img_LockedIcon;
	
	@FindBy(xpath = "//img[@class='reset-validation-tries ng-star-inserted']")
	private WebElement img_LockedIconServiceTrackerFullPage;
	
	@FindBy(xpath = "//div[@class='service-tracker-panel']//child::a")
	private WebElement lnk_ServiceTrackerPanel;
	
	@FindBy(xpath = "//h5[contains(text(),'Reset Validation Tries')]")
	private WebElement lbl_HeaderPopup;
	
	@FindBy(xpath = "//span[(text()='Patient')]")
	private WebElement lbl_Patient;
	
	@FindBy(xpath = "//img[@src='assets/images/reset.svg']")
	private WebElement btn_Reset;
	
	@FindBy(xpath = "//img[@src='assets/images/check.svg']")
	private WebElement atr_CheckMark;
	
	@FindBy(xpath = "//img[@src='assets/images/close.svg']")
	private WebElement img_Close;
	
	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs; 
	
	Login logIn = new Login();
	VPVServiceTrackerPanelPage vsrvcPanel = new VPVServiceTrackerPanelPage();
	
	public ServiceTrackerSimpleSearchPage() {
		PageFactory.initElements(driver, this);
	}

	public void comparePatientNameOnVisitCard(String patientName) throws Exception{
		try{
			Thread.sleep(10000);
			List<String> ptName= webActions.getDatafromWebTable(txt_PatientName);
			int count = ptName.size();
			for(int i=0;i<count;i++){
				if(ptName.get(i).contains(patientName)){
					report.reportPass("Patient Name is displayed properly");
				}
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public String getVisitIdFromResponse(String visitId){
		String displayVisitId = "";
		try {
			String visitIdValue = rest.getStringValueFromResponse(visitId);
			displayVisitId = visitIdValue.replaceAll("\\W", "");
			report.logPass("Validate Response Body Content Matches the Expected Value: " + visitId
					+ " Actual value: " + displayVisitId);
		} catch (AssertionError e) {
			report.logHardFail("Validate Response Body Content Matches the Request Failed ", e);
		}
		return displayVisitId;
	}

	public void srchWithVisitIDAndVerifyVCardCount(String responseValue) throws Exception{
		try{
			webActions.waitForPageLoaded();
			String visitID=getVisitIdFromResponse(responseValue);
			report.reportInfo("VisitID value is :"+visitID);
			String partialVisitId=visitID.substring(0,10);
			report.reportInfo("Partial VisitID value is :"+partialVisitId);
			updateVisit.simpleSearch(partialVisitId);
			List<String> list = webActions.getDatafromWebTable(txt_VisitID);
			int totalCards= list.size();
			report.reportInfo("Total visit cards count when searched with matched VisitID are :"+totalCards);
			for(int i=0;i<totalCards;i++){
				if(list.get(i).contains(partialVisitId)){
					report.reportPass("VisitiD is matched");
				}else{
					throw new Exception("unable to read VisitID");
				}
			}		
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyNoRecordsFoundMsg(String expNoRecordsFoundMsg) throws Exception{
		String actNoRecordsMsg = null;
		try{
			webActions.waitForPageLoaded();
			if(img_NoRecordsFound.isDisplayed()){
				actNoRecordsMsg = webActions.getText(img_NoRecordsFound, "SearchResultText");
				if (actNoRecordsMsg.contentEquals(expNoRecordsFoundMsg)){
					report.reportPass("Your search did not have any results msg is displayed successfully");
				}else{
					report.reportFail("Failed to read the message when there are no records in ST Page");
				}
			}else{
				throw new Exception("Unable to find Search did not have any results");
			}

		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}


	public void verifyDisplayOfVisitCard(String visitId)  {
		try {
			webActions.waitForPageLoaded();
			report.reportInfo("VisitID value is :"+visitId);
			String xpath1="//a[text()=' ";
			String xpath2=" ']/../../../..";
			String xpath=xpath1+visitId+xpath2;
			report.reportInfo("visitid value is "+visitId);
			if(xpath.contains(visitId)){
				report.reportPass("Visit Card is displayed with VisitID :"+visitId, true);
			}else{
				report.reportFail("Patient Visit Card is not displayed on the Service Tracker board with visit id");
			}
		}
		catch (Exception e1) {
			report.reportFail("Patient Visit Card is not displayed on the board with visit id :"+visitId ); 
		}
	}

	public static String getUniqueNumber() {
		String uniqueNumber = "";
		try {
			Date dNow = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("YYMMddHHss");
			String s = ft.format(dNow);
			uniqueNumber = s.substring(0, Math.min(s.length(), 10));

		} catch (Exception e) {

		}
		return uniqueNumber;
	}

	@SuppressWarnings("unchecked")
	public void updatePatientVisitJsonFile(String eventType) throws ParseException {
		//ServiceTrackerJSON
		String newNum = "";
		try {
			// read the json file
			FileReader reader = new FileReader(UPDATEPATIENTVISITJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject visitlocationObject = (JSONObject) visitObject.get("VisitLocation");
			JSONObject LocationObject = (JSONObject) visitlocationObject.get("LocationPointOfCare");
			JSONObject appointmentObject = (JSONObject) jsonObject.get("Appointment");

			// Update tenantPatientId
			try {
				String number = getUniqueNumber();
				newNum = "VN" + number;
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(0);
				tenantPatient.put("TenantPatientId", newNum);
				String test = (String) tenantPatient.get("TenantPatientId");	

				JSONObject tenantPatientPI = (JSONObject) msg.get(3);
				tenantPatientPI.put("TenantPatientId", newNum);
			} catch (Exception e) {
				log.error("Failed to update tenant patiend id", e);
				e.printStackTrace();
			}
			try {
				// update AccountNumber, VisitNumber and visitDate					
				visitObject.put("AccountNumber", newNum);
				visitObject.put("VisitNumber", newNum);
				Object tt = visitObject.get("VisitDate");
				String updatedDate = rest.updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);


			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}

			try{

				JSONArray patientPhonenum = (JSONArray) patientObject.get("PatientPhoneNumber");
				JSONObject pnum = (JSONObject) patientPhonenum.get(0);
				pnum.put("PhoneNumber", rest.getUniqueNumber());

			}catch(Exception e){
				log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
			}

			if (eventType.equals("S12")) {
				try {
					// update appointmentStartDate and appointmentEndDate
					Object appointment = appointmentObject.get("AppointmentStartDate");
					String updatedDates = rest.updatedDateAppointment(appointment);
					appointmentObject.put("AppointmentStartDate", updatedDates);
					appointmentObject.put("AppointmentEndDate", updatedDates);
					String appointmentId = rest.getUniqueAppointmentNumber();				
					appointmentObject.put("AppointmentId", appointmentId);
				} catch (Exception e) {
					log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
					e.printStackTrace();
				}

				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S12");
					eventObject.put("EventTypeDescription", "New Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			} 
			else if ("A04".contentEquals(eventType)) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");                    
					eventObject.put("EventTypeCode", eventType);
					eventObject.put("EventTypeDescription", "Registered");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if ("A08".contentEquals(eventType)) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");                    
					eventObject.put("EventTypeCode", eventType);
					eventObject.put("EventTypeDescription", "Update patient information");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if ("A11".contentEquals(eventType)) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");                    
					eventObject.put("EventTypeCode", eventType);
					eventObject.put("EventTypeDescription", "Cancel admit/visit");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}

			FileWriter file = new FileWriter(UPDATEPATIENTVISITJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}

	}

	public ServiceTrackerSimpleSearchPage openIpasApp() {
		try {
			String URL = TestBase.prop.ipasURL();
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to Open iPAS application");
		}
		return (ServiceTrackerSimpleSearchPage) base(ServiceTrackerSimpleSearchPage.class);
	}
	
	public void verifyLockedIconinServiceTarcker(){
		try {
			StringBuilder unmatch=new StringBuilder();
			String expStatus="reset-red";
			webActions.waitForPageLoaded();
			String actLockedIconStatus=webActions.getAttributeValue(img_LockedIcon, "src", "Locked Icon");
			if(actLockedIconStatus.contains(expStatus)){
				report.reportPass("Successfully verified the locked account icon on service tracker card");
			}else{
				unmatch.append("Failed to verify the locked account icon on service tracker card");
				report.reportFail("Failed to verify the locked account icon on service tracker card",true);
			}
			String visitID= logIn.getVisitIdFromResponse("$..displayPatientAccountId");
			vsrvcPanel.clickVisitID(visitID);
			Thread.sleep(5000);
			webActions.waitForPageLoaded();
			String actLockedIconStatusinAllData=webActions.getAttributeValue(img_LockedIcon, "src", "Locked Icon");
			if(actLockedIconStatusinAllData.contains(expStatus)){
				report.reportPass("Successfully verified the locked account icon on service tracker short pane");
			}else{
				unmatch.append("Failed to verify the locked account icon on service tracker short pane");
				report.reportFail("Failed to verify the locked account icon on service tracker short pane",true);
			}
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_ServiceTrackerPanel, "Service Tracker Panel");
			webActions.waitForPageLoaded();
			String actLockedIconStatusinFullPage=webActions.getAttributeValue(img_LockedIconServiceTrackerFullPage, "src", "Locked Icon");
			if(actLockedIconStatusinFullPage.contains(expStatus)){
				report.reportPass("Successfully verified the locked account icon on service tracker full pane");
			}else{
				unmatch.append("Failed to verify the locked account icon on service tracker full pane");
				report.reportFail("Failed to verify the locked account icon on service tracker full pane",true);
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void unlockTheLockedAccount(){
		try {
			
			webActions.waitForPageLoaded();
			webActions.waitAndClick(img_LockedIcon, "Locked Icon");
			webActions.waitForVisibility(lbl_HeaderPopup, "Header Popup");
			webActions.waitForVisibility(lbl_Patient, "Patient");	
			webActions.click(btn_Reset, "Reset");
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle=titleContent[0];
			String actContent=titleContent[1];
			report.reportInfo("Actual alert message after reset: "+msg);			
			String actStatus=webActions.getAttributeValue(atr_CheckMark, "src", "Check Mark");
			if(actStatus.contains("check.svg")){
				report.reportPass("Successfully unlock the locked account");
			}
			else{
				report.reportFail("Fail to unlock the locked account");
			}			
			
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_UserName);
	}

}
