package com.ipas.hf.web.steps;

import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.ipasPages.AddPatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.EditUserPage;
import com.ipas.hf.web.pages.ipasPages.EligibilityEditPage;
import com.ipas.hf.web.pages.ipasPages.EligibilityFullPanelNavigationPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class EligibilityFullPanelNavigationSteps {

	EligibilityFullPanelNavigationPage fullpanel=new EligibilityFullPanelNavigationPage();
	
	@Then("Verify the Eligibility verification panel")
	public void Verify_the_Eligibility_verification_panel() throws InterruptedException {
		fullpanel.verifyEligibilityVerificationPanel();
	}
	
	@Then("Click on Eligibility verification panel")
	public void click_on_Eligibility_verification_panel_Link() {
		fullpanel.clickEligibilityVerificationPanel();
	}
	
	@Then("Verify the BreadCrumb for Eligibility verification panel")
	public void Verify_the_BreadCrumb_for_Eligibility_verification_panel(DataTable breadcrumb) throws InterruptedException {
		fullpanel.verifyBreadcrumbinEligibilityVerificationPanel(breadcrumb);
	}

	@Then("Verify the page title for Eligibility verification")
	public void Verify_the_page_title_for_Eligibility_verification(DataTable pagetitle) throws InterruptedException {
		fullpanel.verifyPageTitle(pagetitle);
	}
	
	@Then("Verify the tabs across the eligibility page")
	public void verify_the_tabs_across_the_eligibility_page(DataTable tabs) {
		fullpanel.verifyTabsAcross(tabs);
	}
	
	@Then("Verify the patient Info fields on eligibility Page")
	public void verify_the_patient_Info_fields_on_eligibility_Page(DataTable fields) {
	   fullpanel.verifyPatientInfoFields(fields);
	}

	@Then("Verify the selected tab is underlined as indicator tab")
	public void verify_the_selected_tab_is_underlined_as_indicator_tab() {
	    fullpanel.verifyTabSelectedasIndicatorTab();
	}

	
}