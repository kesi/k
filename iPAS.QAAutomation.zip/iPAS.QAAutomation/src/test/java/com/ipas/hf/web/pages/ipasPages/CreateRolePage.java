package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class CreateRolePage extends BasePage {	

	@FindBy(linkText="System Role Configuration")
	private WebElement lnk_SystemRole;

	@FindBy(xpath="//div[contains(text(),'Add new role for iPAS users and manage role option')]")
	private WebElement msg_SystemRole;

	@FindBy(xpath="//tbody/tr/td[1]/div")
	private List<WebElement> lbl_SystemRolePremissionsList;

	@FindBy(xpath="//span[contains(text(),'Add New Role')]")
	private WebElement lbl_NewRolePopUpTitle;

	@FindBy(xpath="//label[contains(text(),'Role Name')]")
	private WebElement lbl_NewRoleField;

	@FindBy(xpath="//button[contains(text(),'Add New Role')]")
	private WebElement btn_AddNewRole;

	@FindBy(xpath="//div[contains(text(),'Role Name required')]")
	private WebElement lbl_MandatoryField;

	@FindBy(xpath="(//input[@placeholder='Role Name'])[1]")
	private WebElement lbl_RoleNameField;

	@FindBy(xpath="(//button[@type='submit'])[3]")
	private WebElement btn_Add;

	@FindBy(xpath="(//button[@type='button'])[9]")
	private WebElement btn_Cancel;

	@FindBy(xpath="(//button[@type='button' and @class='close'])[3]")
	private WebElement btn_Cross;

	@FindBy(xpath="//th/a")
	private List<WebElement> lbl_SystemConfigHeaders;

	@FindBy(xpath="//tr[1]/td[1]")
	private List<WebElement> lbl_SystemConfigCatogeries;

	@FindBy(xpath="(//button[contains(text(),'Cancel')])[1]")
	private WebElement btn_CancelConfigPage;

	@FindBy(xpath="//button[contains(text(),'Save')]")
	private WebElement btn_SaveConfigPage;

	@FindBy(xpath="//button[contains(text(),'Delete')]")
	private WebElement btn_DeleteRole;

	@FindBy(xpath="//table[@class='table table-bordered']/tbody[1]/tr[1]/td[2]/ejs-checkbox")
	private WebElement chk_AccountSearchChk;

	@FindBy(xpath="//div[@id='_title']")
	private WebElement lbl_PopUpTitle;
	@FindBy(xpath="//div[contains(text(),'There are unsaved changes , do you want to save or')]")
	private WebElement lbl_PopUpContent;

	@FindBy(xpath="//button[contains(text(),'Discard')]")
	private WebElement btn_Discard;

	@FindBy(xpath="//div[@id='_dialog-header']/button/span")
	private WebElement btn_UnsavedCross;

	@FindBy(xpath="(//button[contains(text(),'Save')])[2]")
	private WebElement btn_Save;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_FilterMsgs;

	@FindBy(xpath="//table[@class='table table-bordered']/tbody[1]/tr[3]/td[2]/ejs-checkbox")
	private WebElement chk_AddPatientChkBox;
	
	@FindBy(xpath="//span[contains(text(),'Edit Role')]")
	private WebElement lbl_EditRolePopUpTitle;
	
	@FindBy(xpath="(//label[contains(text(),'Role Name')])[2]")
	private WebElement lbl_EditRoleField;
	
	@FindBy(xpath="(//input[@type='text'])[2]")
	private WebElement lbl_RoleName;
	
	@FindBy(xpath="(//button[@type='button'])[12]")
	private WebElement btn_EditCancel;
	
	@FindBy(xpath="//button[contains(text(),'Update')]")
	private WebElement btn_Update;
	
	@FindBy(xpath="(//button[@type='button' and @class='close'])[4]")
	private WebElement btn_EditRoleCross;
	
	@FindBy(xpath="(//input[@placeholder='Role Name'])[2]")
	private WebElement lbl_EditRoleNameField;

	public CreateRolePage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyLabelNames(DataTable label) {
		try {
			ArrayList<String> expFilterNames = new ArrayList<>(label.asList());
			report.reportInfo("Expected Label Names in system role section: "+expFilterNames);
			webActions.waitUntilisDisplayed(lnk_SystemRole, "System Role Link");
			ArrayList<String> actLabelNames = new ArrayList<String>();
			actLabelNames.add(webActions.getText(lnk_SystemRole, "System Role Link"));			
			actLabelNames.add(webActions.getText(msg_SystemRole, "Message"));
			report.reportInfo("Displayed Lable Names in system role section: "+actLabelNames);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actLabelNames, expFilterNames);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Label Names in system role section successfully");
			}
			else{
				throw new Exception("Fail to verify Label Names in system role section and unmatched label Names are: "+unmatchedLabelNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}


	public void clickOnSystemRoleLink(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lnk_SystemRole, "SystemRoleLink");
			webActions.waitForVisibilityOfAllElements(lbl_SystemRolePremissionsList, "Permissions");
			report.reportInfo("Navigated to the system configuration page");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void clickOnAddNewRole(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_AddNewRole, "AddNewRoleBtn");
			webActions.waitForVisibility(lbl_NewRolePopUpTitle, "Title");			
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyFields(DataTable testData){
		try {
			ArrayList<String> expFields = new ArrayList<>(testData.asList());
			report.reportInfo("Expected fields in Add new role pop-up: "+expFields);			
			ArrayList<String> actLabelNames = new ArrayList<String>();
			actLabelNames.add(webActions.getText(lbl_NewRolePopUpTitle, "AddNewRoleTitle"));			
			actLabelNames.add(webActions.getText(lbl_NewRoleField, "RoleNameField"));
			report.reportInfo("Displayed fields in Add New Role pop-up: "+actLabelNames);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actLabelNames,expFields);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified fields in Add new role window successfully");
			}
			else{
				throw new Exception("Fail to verify fields in Add new role pop-up and unmatched label Names are: "+unmatchedLabelNames);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}

	public void verifyMandatoryField(String validation){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lbl_RoleNameField,"RoleNameField");
			webActions.pressTab();
			webActions.waitForPageLoaded();
			String displayedMsg=webActions.getText(lbl_MandatoryField,"MandatoryField");
			if(displayedMsg.contentEquals(validation)){
				report.reportPass("Verified mandatory validation successfully");
			}
			else{
				report.reportFail("Fail to verify mandatory validdation: "+ displayedMsg);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}	
	public void verifyAddbtnMode(){
		try {
			webActions.waitForPageLoaded();			
			boolean flag=btn_Add.isEnabled();
			if(flag){
				report.reportFail("Add button is displayed in enable mode by default");
			}
			else{
				report.reportPass("Verified Add button mode successfully");
			}
			webActions.click(lbl_RoleNameField,"RoleNameField");
			webActions.sendKeys(lbl_RoleNameField, "123", "RoleNameField");
			webActions.pressTab();
			webActions.waitForPageLoaded();
			boolean flag1=btn_Add.isEnabled();
			if(flag1){
				report.reportPass("Verified Add button mode successfully");

			}
			else{
				report.reportFail("Add button is displayed in enable mode by default");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void closeAddNewRolePopUp(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_Cancel, "CancelBtn");
			webActions.waitForPageLoaded();
			webActions.assertDisplayed(btn_AddNewRole, "AddNewRoleBtn");
			report.reportPass("Verifed Add New Role button successfully");
			clickOnAddNewRole();
			webActions.click(btn_Cross, "CrossIcon");
			webActions.waitForPageLoaded();
			webActions.assertDisplayed(btn_AddNewRole, "AddNewRoleBtn");
			report.reportPass("Verifed Add New Role button successfully");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void createNewRole(){
		try {
			webActions.waitForPageLoaded();
			String role=webActions.getRandomString(4);
			String roleName="V1@"+role;
			webActions.notepadWrite("hello", roleName);
			webActions.click(lbl_RoleNameField,"RoleNameField");
			webActions.sendKeys(lbl_RoleNameField, roleName, "RoleNameField");
			webActions.waitForPageLoaded();
			webActions.click(btn_Add, "AddButton");

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void closeAddNewRolePopWithOutSaving(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lbl_RoleNameField,"RoleNameField");
			webActions.sendKeys(lbl_RoleNameField, "v123", "RoleNameField");
			webActions.waitForPageLoaded();
			webActions.click(btn_Cancel, "CancelBtn");
			webActions.waitForPageLoaded();
			webActions.assertDisplayed(btn_AddNewRole, "AddNewRoleBtn");
			report.reportPass("Verifed Add New Role button successfully");
			clickOnAddNewRole();
			webActions.click(lbl_RoleNameField,"RoleNameField");
			webActions.sendKeys(lbl_RoleNameField, "v123", "RoleNameField");
			webActions.waitForPageLoaded();
			webActions.click(btn_Cross, "CrossIcon");
			webActions.waitForPageLoaded();
			webActions.assertDisplayed(btn_AddNewRole, "AddNewRoleBtn");
			report.reportPass("Verifed Add New Role button successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyRoleFromSystemRolesView(){
		try {
			Thread.sleep(3000);
			String expHeader=webActions.notepadRead("hello");
			String expRoleName=expHeader.trim();
			WebElement addedRoleName=driver.findElement(By.xpath("//thead/tr[1]/th/a[contains(text(),'"+expRoleName+"')]"));	
			webActions.waitForVisibility(addedRoleName, "AddedRole");
			webActions.waitForPageLoaded();
			List<WebElement> actualHeaders = lbl_SystemConfigHeaders;			
			for (int i = 1; i <actualHeaders.size(); i++) {
				String roleName=actualHeaders.get(i).getText();				
				if(roleName.trim().contentEquals(expRoleName)){									
					addedRoleName.click();
					webActions.waitForPageLoaded();
					webActions.waitForVisibility(btn_DeleteRole, "DeleteRoleButton");
					webActions.waitForPageLoaded();
					webActions.click(btn_DeleteRole, "DeleteRoleButton");
					webActions.waitForPageLoaded();
					Thread.sleep(2000);
					report.reportInfo("Role is deleted Successfully : "+expRoleName);					
					break;			

				}

			}
			report.reportPass("Verified added role from view system roles configuration page successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyCatogeryName(DataTable testData){
		try {
			webActions.waitForPageLoaded();
			ArrayList<String> expFields = new ArrayList<>(testData.asList());
			report.reportInfo("Expected system role configuration catogeries: "+expFields);
			ArrayList<String> displayedCatogeries=webActions.getDatafromWebTable(lbl_SystemConfigCatogeries);
			report.reportInfo("Displayed system role configuration catogeries: "+displayedCatogeries);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(displayedCatogeries,expFields);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified catogeries in system role configuration page successfully");
			}
			else{
				throw new Exception("Fail to verify catogeries in system role configuration page and unmatched catogeries are: "+unmatchedLabelNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifySystemConfigPageButtons(){
		try {
			webActions.waitForPageLoaded();
			webActions.assertDisplayed(btn_CancelConfigPage, "CancelBtn");
			report.reportPass("Verified cancel button in system configuration page successfully");
			webActions.assertDisplayed(btn_SaveConfigPage, "SaveBtn");
			report.reportPass("Verified save button in system configuration page successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyDuplicateRole(){
		try {
			webActions.waitForPageLoaded();
			clickOnAddNewRole();
			webActions.waitForPageLoaded();	
			Thread.sleep(2000);
			String roleName=webActions.notepadRead("hello");
			//webActions.click(lbl_RoleNameField,"RoleNameField");
			webActions.sendKeys(lbl_RoleNameField, roleName, "RoleNameField");
			Thread.sleep(5000);
			//webActions.click(btn_Add, "AddButton");

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnCancel(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_CancelConfigPage, "CancelBtn");
			webActions.waitForVisibility(msg_SystemRole, "SystemRoleContent");

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickOnAccountSearchHeaderCheckBox(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(chk_AccountSearchChk, "AccountSearchCheckBox");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyUnSavedPopUp(DataTable testData){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_CancelConfigPage, "CancelBtn");			
			webActions.waitForVisibility(lbl_PopUpContent, "UnsavedPopup");
			ArrayList<String> expFields = new ArrayList<>(testData.asList());
			report.reportInfo("Expected unsaved popup content : "+expFields);
			ArrayList<String> displayedContent=new ArrayList<>();
			displayedContent.add(webActions.getText(lbl_PopUpTitle, "PopUpTitle"));
			displayedContent.add(webActions.getText(lbl_PopUpContent, "PopUpContent"));
			report.reportInfo("Displayed title and content: "+displayedContent);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(displayedContent,expFields);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Title and content in Unsaved popup successfully");
			}
			else{
				throw new Exception("Fail to verify Title and content in Unsaved popup and unmatched data is: "+unmatchedLabelNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnDiscardFromPopUp(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_CancelConfigPage, "CancelBtn");
			Thread.sleep(1000);
			webActions.waitForVisibility(lbl_PopUpContent, "UnsavedPopup");
			webActions.click(btn_Discard, "DiscardBtn");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnCrossAndVerify(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_CancelConfigPage, "CancelBtn");
			Thread.sleep(1000);
			webActions.waitForVisibility(lbl_PopUpContent, "UnsavedPopup");
			webActions.click(btn_UnsavedCross, "CrossBtn");
			webActions.waitForPageLoaded();
			webActions.assertDisplayed(btn_AddNewRole, "AddNewRoleBtn");
			report.reportPass("Verifed Add New Role button successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnAddPatientCheckBox(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(chk_AddPatientChkBox, "AddPatientcheckBox");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnSaveAndVerify(){
		try {
			String defaultChkDisplay=webActions.getAttributeValue(chk_AddPatientChkBox, "aria-checked", "AddPatientcheckBox");
			webActions.waitForPageLoaded();
			clickOnAddPatientCheckBox();
			webActions.waitForPageLoaded();
			webActions.click(btn_CancelConfigPage, "CancelBtn");
			Thread.sleep(1000);
			webActions.waitForVisibility(lbl_PopUpContent, "UnsavedPopup");
			webActions.click(btn_Save, "SaveBtn");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txt_FilterMsgs, "messages");
			webActions.waitForPageLoaded();
			String displayedChkDisplay=webActions.getAttributeValue(chk_AddPatientChkBox, "aria-checked", "AccountSearchHeaderBox");
			if (defaultChkDisplay.contentEquals(displayedChkDisplay)){
				report.reportInfo("Actual displayed check box display: "+defaultChkDisplay);
				report.reportInfo("Expected check box display: "+displayedChkDisplay);
				report.reportFail("Fail to verify the check box selection successfully");				
			}
			else{
				report.reportInfo("Actual displayed check box display: "+defaultChkDisplay);
				report.reportInfo("Expected check box display: "+displayedChkDisplay);
				report.reportPass("Verified check box display successfully");				
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyRolesOrder(){
		try {
			webActions.waitForPageLoaded();
			ArrayList<String> displayedRoleOrder=webActions.getDatafromWebTable(lbl_SystemConfigHeaders);			
			ArrayList<String> expectedRoleOrder=new ArrayList<>();
			expectedRoleOrder.addAll(displayedRoleOrder);
			Collections.sort(expectedRoleOrder);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(displayedRoleOrder,expectedRoleOrder);
			report.reportInfo("Displayed role order: "+displayedRoleOrder);
			report.reportInfo("Expected role order: "+expectedRoleOrder);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified roles order successfully");
			}
			else{
				throw new Exception("Fail to verify roles order and unmatched data is: "+unmatchedLabelNames);
			}	
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void editRoleFromSystemRolesView(){
		try {
			Thread.sleep(3000);
			String expHeader=webActions.notepadRead("hello");
			String expRoleName=expHeader.trim();
			WebElement addedRoleName=driver.findElement(By.xpath("//thead/tr[1]/th/a[contains(text(),'"+expRoleName+"')]"));	
			webActions.waitForVisibility(addedRoleName, "AddedRole");
			webActions.waitForPageLoaded();
			List<WebElement> actualHeaders = lbl_SystemConfigHeaders;			
			for (int i = 1; i <actualHeaders.size(); i++) {
				String roleName=actualHeaders.get(i).getText();				
				if(roleName.trim().contentEquals(expRoleName)){									
					addedRoleName.click();
					webActions.waitForPageLoaded();
					webActions.waitForVisibility(btn_DeleteRole, "DeleteRoleButton");
					webActions.waitForPageLoaded();					
					report.reportInfo("Created role is opened successfully : "+expRoleName);					
					break;

				}

			}
			report.reportPass("Verified added role from view system roles configuration page successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyEditRoleFields(DataTable testData){
		try {
			ArrayList<String> expFields = new ArrayList<>(testData.asList());
			report.reportInfo("Expected fields in Add new role pop-up: "+expFields);			
			ArrayList<String> actLabelNames = new ArrayList<String>();
			actLabelNames.add(webActions.getText(lbl_EditRolePopUpTitle, "EditRoleTitle"));			
			actLabelNames.add(webActions.getText(lbl_EditRoleField, "RoleNameField"));
			report.reportInfo("Displayed fields in Add New Role pop-up: "+actLabelNames);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actLabelNames,expFields);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified fields in edit role window successfully");
			}
			else{
				throw new Exception("Fail to verify fields in edit role pop-up and unmatched label Names are: "+unmatchedLabelNames);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}
	public void deleteRoleFromSystemRolesView(){
		try {			
					webActions.waitForPageLoaded();
					webActions.waitForVisibility(btn_DeleteRole, "DeleteRoleButton");
					webActions.waitForPageLoaded();
					webActions.click(btn_DeleteRole, "DeleteRoleButton");
					webActions.waitForPageLoaded();
					Thread.sleep(2000);			
					report.reportPass("Created role is deleted from view system roles configuration page successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyPopulatedRoleName(){
		try {
			webActions.waitForPageLoaded();
			String expRoleName=webActions.notepadRead("hello");			
			String actRoleName=webActions.getText(lbl_RoleName, "RoleNameField");
			report.reportInfo("Expected Role Name: "+ expRoleName);
			report.reportInfo("Displayed Role Name: "+ actRoleName);
			if(actRoleName.contentEquals(expRoleName)){
				report.reportPass("Verified Role Name successfully");
			}
			else{
				report.reportFail("Fail to verify the Role Name and displayed role name is : "+actRoleName);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clearAndVerifyRoleName(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lbl_RoleName, "RoleNameField");
			webActions.clearValue(lbl_RoleName, "RoleNameField");
			webActions.pressTab();
			webActions.waitForPageLoaded();
			String displayedMsg=webActions.getText(lbl_MandatoryField,"MandatoryField");
			
			if(displayedMsg.contentEquals("Role Name required")){
				report.reportPass("Verified mandatory validation successfully");
			}
			else{
				report.reportFail("Fail to verify mandatory validdation: "+ displayedMsg);
			}
			webActions.click(btn_EditCancel,"EditRoleCancel");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyUpdatebtnMode(){
		try {
			webActions.waitForPageLoaded();			
			boolean flag=btn_Update.isEnabled();
			report.reportInfo("Flag value is : "+ flag);
			if(flag){
				report.reportFail("Update button is displayed in enable mode by default");
			}
			else{
				report.reportPass("Verified Update button mode successfully");
			}			
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyNavigation(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_EditCancel, "EditRoleCancel");
			webActions.waitForVisibility(btn_AddNewRole, "AddRoleButton");
			webActions.assertDisplayed(btn_AddNewRole, "AddRoleButton");
			report.reportPass("Verified Add New Role button successfully");
			editRoleFromSystemRolesView();
			webActions.click(btn_EditRoleCross, "EditRoleCross");
			webActions.waitForVisibility(btn_AddNewRole, "AddRoleButton");
			webActions.assertDisplayed(btn_AddNewRole, "AddRoleButton");
			report.reportPass("Verified Add New Role button successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void updateRoleName(String roleName){
		try {
			webActions.waitForPageLoaded();
			webActions.notepadWrite("hello", roleName);
			webActions.clickAction(lbl_EditRoleNameField,"RoleNameField");
			webActions.clearValue(lbl_EditRoleNameField, "RoleNameField");
			webActions.sendKeys(lbl_EditRoleNameField, roleName, "RoleNameField");
			webActions.waitForPageLoaded();
			webActions.click(btn_Update, "UpdateButton");
			webActions.waitForPageLoaded();
			WebElement updatedRoleName=driver.findElement(By.xpath("//thead/tr[1]/th/a[contains(text(),'"+roleName+"')]"));	
			webActions.waitForVisibility(updatedRoleName, "AddedRole");
			webActions.waitForPageLoaded();
			List<WebElement> actualHeaders = lbl_SystemConfigHeaders;			
			for (int i = 1; i <actualHeaders.size(); i++) {
				String roleNameUpdated=actualHeaders.get(i).getText();				
				if(roleNameUpdated.trim().contentEquals(roleName)){									
					updatedRoleName.click();
					webActions.waitForPageLoaded();
					webActions.waitForVisibility(btn_DeleteRole, "DeleteRoleButton");					
					webActions.waitForPageLoaded();					
					report.reportInfo("Role name updated successfully : "+roleName);
					break;

				}

			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyDeletedRoleFromSystemRolesView(){
		try {			
			String expHeader=webActions.notepadRead("hello");
			String expRoleName=expHeader.trim();			
			webActions.waitForPageLoaded();
			List<WebElement> actualHeaders = lbl_SystemConfigHeaders;
			ArrayList<String> displayedRoles=new ArrayList<>();
			
			for (int i = 1; i <actualHeaders.size(); i++) {
				String roleName=actualHeaders.get(i).getText();
				displayedRoles.add(roleName);				
				if(roleName.trim().contentEquals(expRoleName)){			
				report.reportFail("Created Role is not deleted from system role view :"+expRoleName);							
					break;
				}				
			}
			report.reportInfo("Displayed roles from view system roles: "+displayedRoles);
			report.reportInfo("Deleted Role: "+expRoleName);
			report.reportPass("Verified added role from view system roles configuration page successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
