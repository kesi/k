package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.ViewStandardMedicalNecessityResponseCodesPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class ViewStandardMedicalNecessityResponseCodesSteps {

	ViewStandardMedicalNecessityResponseCodesPage viewStandardMNR=new ViewStandardMedicalNecessityResponseCodesPage();
	
	@Then("Verify Medical Necessity Check Panel and help Text and Expand and Collapse")
	public void verify_Medical_Necessity_Check_Panel_and_help_Text_and_Expand_and_Collapse(DataTable testData) {
		viewStandardMNR.verifyMedicalNecessityCheckPanelAndHelpText(testData);
	}
	
	@Then("Navigate to Medical Necessity Response page")
	public void navigate_to_Medical_Necessity_Response_page() {
		viewStandardMNR.navigateMedicalNecessityResponsePage();
	}

	@Then("Verify Field Names and Response Type as {string}")
	public void verify_Field_Names_and_Response_Type_as(String responseType, DataTable fieldNames) {
		viewStandardMNR.verifyDefaultResponseTypeValueAndFieldNames(fieldNames, responseType);
	}
	
	@Then("verify Breadcrumb")
	public void verify_Breadcrumb(DataTable breadcrumb) {
		viewStandardMNR.verifyBreadcrumb(breadcrumb);
	}
	
	@Then("Verify Result Grid Header Names for Standard Response Type")
	public void verify_Result_Grid_Header_Names_for_Standard_Response_Type(DataTable headerNames) {
		viewStandardMNR.verifyGridHeaderNamesForStandardResponseType(headerNames);
	}
	
	@Then("{string} toggle switch and verify the status")
	public void toggle_switch_and_verify_the_status(String responseCodeStatus) {
		viewStandardMNR.enableResponseCode(responseCodeStatus);
	}

	@Then("Verify Field Names in Response Status model window and Validate the Cancel button")
	public void verify_Field_Names_in_Response_Status_model_window_and_Validate_the_Cancel_button(DataTable names) {
		viewStandardMNR.verifyFieldNamesinResponseStatusodelWindow(names);
	}
	
	@Then("Change Response status as {string} and verify success toaster message as {string}")
	public void change_Response_status_as_and_verify_success_toaster_message_as(String changeStatus, String message) {
		viewStandardMNR.changeResponseStatus(changeStatus,message);
	}

}
