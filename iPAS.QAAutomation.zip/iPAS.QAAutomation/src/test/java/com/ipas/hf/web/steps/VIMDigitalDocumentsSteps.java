package com.ipas.hf.web.steps;

import java.util.ArrayList;

import com.ipas.hf.web.pages.ipasPages.VIMDigitalDocumentsPage;
import com.ipas.hf.web.pages.ipasPages.VIMLoginPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class VIMDigitalDocumentsSteps {

	VIMDigitalDocumentsPage vdd=new VIMDigitalDocumentsPage();
	VIMLoginPage vlogin=new VIMLoginPage();
	

	@Then("Submit the form as {string} and verify the status and count")
	public void submit_the_form_as_and_verify_the_status_and_count(String form) {
		vdd.submitFormAndVerify(form);
	}
	@Then("Verify the complete document count as {string}")
	public void verify_the_complete_document_count_as(String count) {
		vdd.verifyCompleteDocumentsCount(count);
	}

	@Then("Verify the submitted form {string} status")
	public void verify_the_submitted_form_status(String form) {
		vdd.verifyFormStatusHome(form);
	}
	@Then("Verify the completed document count from short panel as {string}")
	public void verify_the_completed_document_count_from_short_panel_as(String count) {
		vdd.verifyCountFromDDShortPanel(count);
	}
	@Then("Verify the completed form count from short panel as {string}")
	public void verify_the_completed_form_count_from_short_panel_as(String count) {
	  vdd.verifyDocumentCountFromDDShortPanel(count);
	}

	@Then("Verify the {string} form status")
	public void verify_the_form_status(String form) {
		vdd.verifyStatusFromDDPanel(form);
	}
	@Then("Go to the form page and verify UnsavedPop")
	public void go_to_the_form_page_and_verify_UnsavedPop() {
		vdd.verifyUnsavedPopUp();
	}

	@Then("Edit the submitted form {string} and submit again")
	public void edit_the_submitted_form_and_submit_again(String form) {
		vdd.editAndSubmitTheForm(form);
	}
	@Then("Verify the updated data from {string} form")
	public void verify_the_updated_data_from_form(String form) {
		vdd.verifyUpdatedDataFromForm(form);
	}
	@Then("Click on complete documents link")
	public void click_on_complete_documents_link() {
		vdd.clickOnCompleteDocLink();
	}
	@Then("Change the {string} form status to complete")
	public void change_the_form_status_to_complete(String form) {
		vdd.changeFormStatus(form);
	}
	@Then("Click on Complete Document link")
	public void click_on_Complete_Document_link() {
	  vdd.clickOnCompleteDocLink();
	}
	@Then("Verify the uploaded documents status from iPAS")
	public void verify_the_uploaded_documents_status_from_iPAS() {
vdd.verifyUploadedDocumentsStatusiPAS();
	}
	@Then("Upload not supported Documents and verify the validation")
	public void upload_not_supported_Documents_and_verify_the_validation(DataTable dataTable) {
		vdd.uploadUnsupportedDocuments(dataTable);
	}
	@Then("Confirm the document and verify the status as {string} and count as {string}")
	public void confirm_the_document_and_verify_the_status_as_and_count_as(String status, String count) {
		vdd.confirmDocuemntsWithoutUpload(status,count);
	}
	@Then("Upload the physician document and verify the status")
	public void upload_the_physician_document_and_verify_the_status(DataTable dataTable) throws Exception {
		ArrayList<String>data=new ArrayList<>(dataTable.asList());
	 vlogin.uploadPhysiciansOrder(data.get(0),data.get(1),data.get(2));
	}
	@Then("Delete the uploaded {string} document from VIM")
	public void delete_the_uploaded_document_from_VIM(String document) {
	   vdd.deleteUploadDocumentAndVerify(document);
	}

	@Then("verify the status as {string} and count as {string}")
	public void verify_the_status_as_and_count_as(String status, String count) {
	   vdd.verifyDocumentStatusAndCount(status, count);
	}
	@Then("Verify the deleted {string} document status from iPAS")
	public void verify_the_deleted_document_status_from_iPAS(String document) {
	  vdd.verifyDeletedDocumentsStatusiPAS(document);
	}



}
