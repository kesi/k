package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.VIMLoginPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class VIMLoginSteps {
	
	VIMLoginPage vim=new VIMLoginPage();

	
	
	@Then("Open VIM application")
	public void open_VIM_application() throws Throwable {
		vim.openVIMApplication();
	}

	@Then("Login VIM application")
	public void login_VIM_application() throws Exception {
		vim.loginVIM();
	}
	
	@Then("Upload Documents and verify the status")
	public void upload_Documents_and_verify_the_status(DataTable testData) {
		vim.uploadDocuments(testData);
	}
	
	@Then("Verify the uploaded documents count")
	public void verify_the_uploaded_documents_count() {
		vim.verifyDocumentsCount();
	}

	@Then("Try to login multiple attempts for unsuccessful and verify message {string}")
	public void try_to_login_multiple_attempts_for_unsuccessful_and_verify_message(String message) {
		vim.unsuccessfulVIMLogin(message);
	}


}
