package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.EditDeleteMedicalNecessityCustomResponsePage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class EditDeleteMedicalNecessityCustomResponseSteps {

	EditDeleteMedicalNecessityCustomResponsePage editDeleteResponce=new EditDeleteMedicalNecessityCustomResponsePage();
	
	@Then("Verify Add Custom Response Code")
	public void verify_Add_Custom_Response_Code(DataTable testData) {
		editDeleteResponce.AddCustomResponse(testData);
	}
	
	@Then("Click on CPT Code")
	public void click_on_CPT_Code() {
		editDeleteResponce.clickonCPTCode();
	}
	
	@Then("Click on CPT Code Custom Descrption as {string}")
	public void click_on_CPT_Code_Custom_Descrption_as(String CPTCustomResponse) {
		editDeleteResponce.clickonCPTCode(CPTCustomResponse);
	}
	
	@Then("Unselect the payer from Assigned Payers Section and click on Cancel button")
	public void unselect_the_payer_from_Assigned_Payers_Section_and_click_on_Cancel_button() {
		editDeleteResponce.unSelectPayerandClickCancelButton();
	}
	
	@Then("Verify the Unsaved Changes Discard popup title as {string} and message as {string} in Edit page")
	public void verify_the_Unsaved_Changes_Discard_popup_title_as_and_message_as_in_Edit_page(String alertTitle, String alertMessage) {
		editDeleteResponce.verifyTheUnsavedChangesDiscardPopup(alertTitle, alertMessage);
	}
	
	@Then("Verify the Update Custom Response Code")
	public void verify_the_Update_Custom_Response_Code(DataTable testData) {
		editDeleteResponce.updateCustomResponse(testData);
	}
	
	@Then("Verify the delete custom response code as {string} alert message as {string}")
	public void verify_the_delete_custom_response_code_as_alert_message_as(String customResponse , String message) {
		editDeleteResponce.deleteCustomResponse(customResponse,message);
	}
	
}
