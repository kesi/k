package com.ipas.hf.web.steps;

import java.util.Properties;

import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.utilities.ConfigProperties;
import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.UserProfilePage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class UserProfileSteps {
	private ConfigProperties configProp = TestBase.prop;
	UserProfilePage usrProfile = new UserProfilePage();
	
	Login logIn = new Login();
	HomePage home = new HomePage();

	@Then("Verify OperatorID, FirstName, LastName, EmailAddress and PhoneNumber fields in User Profile")
	public void verify_OperatorID_FirstName_LastName_EmailAddress_and_PhoneNumber_fields(DataTable options) throws Exception {
		usrProfile.verifyUserProfileElements(options);
	}

	@Then("Verify the Edit and ChangePassword buttons in User Profile")
	public void verify_the_Edit_and_ChangePassword_buttons_in_User_Profile() throws Exception {
		usrProfile.verifyUserProfileButtons();
	}
	
	@Then("Verify the display of buttons in Edit Profile")
	public void verify_the_display_of_buttons_in_Edit_Profile() throws Exception {
		usrProfile.verifyEditProfileButtons();
	}
	
	@Then("Verify OperatorID, FirstName, LastName, EmailAddress and PhoneNumber fields in Edit Profile")
	public void verify_OperatorID_FirstName_LastName_EmailAddress_and_PhoneNumber_fields_in_Edit_Profile(DataTable options) throws Exception {
		usrProfile.verifyEditProfileElements(options);
	}
	
	@Then("Verify X button in User Profile Window")
	public void verify_X_button_in_User_Profile_Window() throws Exception {
		usrProfile.verifyUserProfileXButton();
	}

	@Then("Verify X button in Edit Profile Window")
	public void verify_X_button_in_Edit_Profile_Window() throws Exception {
		usrProfile.verifyUserProfileXButton();
	}
	
	@Then("Update User Details in Edit Profile and verify alert message as title {string} and content as {string}")
	public void update_User_Details_in_Edit_Profile_and_verify_alert_message_as_title_and_content_as(String messageTitle,String messageContent,DataTable testData) throws Exception {	   
		usrProfile.editUserProfile(testData, messageTitle, messageContent);   
	}

	@Then("Verify fields data in User Profile")
	public void verify_fields_data_in_User_Profile(DataTable testData) throws Exception {
		usrProfile.verifyDataOfUserProfileFields(testData);
	}

	@Then("Navigate to User Profile Window")
	public void navigate_to_User_Profile_Window() throws Exception {
		usrProfile.navigateToUserProfile();
	}
	
	@Then("Navigate to Edit Profile Window")
	public void navigate_to_Edit_Profile_Window() {
		
	}
	
	@Then("Verify {string} and {string} messages")
	public void verify_and_and_messages(String fnMandatory, String snMandatory) throws Exception {
		usrProfile.verifyMandatoryMessages(fnMandatory,snMandatory);
	}
	
	@Then("Verify EmailAddress Field is in Disabled Mode")
	public void verify_EmailAddress_Field_is_in_Disabled_Mode() throws Exception {
		usrProfile.verifyEmailAddressFieldMode();
	}
	
	@Then("Verify {string} and {string}")
	public void verify_and(String fnMandatory, String snMandatory) throws Exception {
		usrProfile.verifyMinLengthmessages(fnMandatory,snMandatory);
	}
	
	@Then("Verify {string} when entered {string} in MobileNumber")
	public void verify_when_entered_in_MobileNumber(String errMsg, String value) throws Exception {
		usrProfile.verifyPhoneNumberValidationMsg(errMsg,value);
	}
	
	@Then("Verify DashBoard is displayed by default")
	public void verify_DashBoard_is_displayed_by_default() throws Exception {
		usrProfile.verifyDashBoard();
	}
	
	@Then("Navigate to change password window")
	public void navigate_to_change_password_window() throws Exception {
	  usrProfile.goToChangePswdWindow();
	}
	
	@Then("Verify the lables")
	public void verify_the_lables(DataTable options) throws Exception {
	   usrProfile.verifyChangePswdElements(options);
	}

	@Then("Verify the default change password button mode")
	public void verify_the_default_change_password_button_mode() {
	  usrProfile.verifyChangePswdMode();
	}
	@Then("Verify the display of password instructions")
	public void verify_the_display_of_password_instructions(DataTable options) throws Exception {
	  usrProfile.verifyChangePswdInstructions(options);
	}
	@Then("Verify the mandatory validations")
	public void verify_the_mandatory_validations(DataTable options) {
	   usrProfile.verifymandatoryValidations(options);
	}
	@Then("Verify the password instruction as {string} with password as {string}")
	public void verify_the_password_instruction_as_with_password_as(String expMsg, String input) {
	   usrProfile.verifyChangePaswdInstructions(expMsg, input);
	}


}

