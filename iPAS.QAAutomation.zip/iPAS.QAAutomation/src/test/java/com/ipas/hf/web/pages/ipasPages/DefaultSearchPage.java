package com.ipas.hf.web.pages.ipasPages;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class DefaultSearchPage extends BasePage {


	@FindBy(xpath = "//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_Search;

	@FindBy(xpath = "//ejs-dropdownlist[@id='VisitDate']")
	private WebElement drp_Filters;

	@FindBy(xpath = "//ejs-dropdownlist[@id='VisitDate']//select//option")
	private WebElement drp_Filters1;


	@FindBy(id = "reportrange")
	private WebElement date_VisitDate;

	@FindBy(xpath = "//div[@class='ranges']//ul/li")
	private List<WebElement> li_VisitDate;


	@FindBy(xpath = "//ejs-dropdownlist[@id='ddloFacility']")
	private WebElement drp_Facility;

	@FindBy(xpath = "//ejs-dropdownlist[@id='ddloFacility']//input")
	private WebElement drp_Facility1;

	@FindBy(xpath = "//table[@class='e-table']//thead/tr/th")//th[@class='e-headercell e-leftalign']/div/span
	private List<WebElement> header_AccountSearch;
	
	String lbl_HeaderNames="//table[@class='e-table']//thead/tr/th";

	@FindBy(xpath = "//button[@class='btn btn-primary btn-md'][contains(text(),'Apply')]")
	private WebElement btn_Apply;

	@FindBy(xpath = "//button[@id='e-dropdown-btn_3']")
	private WebElement btn_Filter;

	@FindBy(xpath = "//button[text()='Columns']")
	private WebElement btn_Columns;

	@FindBy(xpath = "//button[@class='btn btn-light w-md']")
	private WebElement btn_Tools;

	@FindBy(xpath = "//div[@class='e-gridcontent']//tr[1]//td[2]/div/a")
	private WebElement lnk_AccountNumber;

	@FindBy(xpath="//div[@class='emptyinfo']")
	private WebElement lbl_NoResultsarefound;


	@FindBy(xpath = "//table[@class='e-table']//thead/tr/th")
	private WebElement lbl_Headers;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody/tr/td")
	private WebElement tbl_AllRecord;

	@FindBy(xpath = "//span[@class='text-muted pr-1']")
	private WebElement lbl_ResultsCount;

	@FindBy(xpath = "//div[@class='e-gridcontent']//tr//td[3]/div[1]")
	private List<WebElement> tbl_VistDate;


	@FindBy(xpath = "//li[contains(text(),'Today')]")
	private WebElement li_Today;

	@FindBy(xpath = "//li[(text()='Previous 3 Days')]")
	private WebElement li_Previous3Days;

	@FindBy(xpath = "//li[(text()='Next 3 Days')]")
	private WebElement li_Next3Days;

	@FindBy(xpath = "//li[(text()='Custom Range')]")
	private WebElement li_CustomRange;

	@FindBy(xpath = "//div[@class='drp-calendar left']//select[@class='monthselect']")
	private WebElement drp_LeftMonth;

	@FindBy(xpath = "//div[@class='drp-calendar left']//select[@class='yearselect']")
	private WebElement drp_LeftYear;

	@FindBy(xpath = "//div[@class='drp-calendar left']//tbody/tr[2]/td[4]")
	private WebElement lbl_Date;

	@FindBy(xpath = "//div[@class='drp-calendar right']//select[@class='monthselect']")
	private WebElement drp_RightMonth;

	@FindBy(xpath = "//div[@class='drp-calendar right']//select[@class='yearselect']")
	private WebElement drp_RightYear;

	@FindBy(xpath = "//div[@id='panel']")
	private WebElement grid_Header;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody")
	private WebElement grid_Results;


	public DefaultSearchPage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyFields(String pageTitle) {
		try {
			webActions.waitForVisibility(lbl_Headers,"Headers");
			webActions.assertDisplayed(txt_Search, "Search Field");
			report.reportInfo("Verified the 'Search Field'");
			webActions.assertDisplayed(drp_Filters, "Filters");
			report.reportInfo("Verified the 'Filters' Dropdown");
			webActions.assertDisplayed(date_VisitDate, "Date of Service");
			report.reportInfo("Verified the 'Visit Date'");
			webActions.assertDisplayed(drp_Facility, "Facility");
			report.reportInfo("Verified the 'Facility' Dropdown");
			webActions.assertDisplayed(btn_Apply, "Apply Button");
			report.reportInfo("Verified the 'Apply' Button");
			webActions.assertDisplayed(btn_Filter, "Filters Dropdown Button");
			report.reportInfo("Verified the 'Filters Dropdown Button'");
			webActions.assertDisplayed(btn_Columns, "Columns Dropdown Button");
			report.reportInfo("Verified the 'Columns Dropdown Button'");
			webActions.assertDisplayed(btn_Tools, "Tools Dropdown Button");
			report.reportInfo("Verified the 'Tools Dropdown Button'");
			String actPageTitle=webActions.getPageTitle();
			if(pageTitle.contentEquals(actPageTitle)){
				report.reportPass("Verified all fields in default search successfully");	
			}else{
				throw new Exception("Fail to verify the default Fields and page title and actual displayed page title is: "+actPageTitle);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDefaultValues(DataTable testData) throws Exception{
		try {
			List<String> expData = testData.asList(String.class);
			List<String> actData = new ArrayList<>(); 
			webActions.waitForVisibility(lbl_Headers,"Headers");
			webActions.waitForClickAbility(date_VisitDate, "Visit Date");
			actData.add(webActions.getAttributeValue(txt_Search, "placeholder", "Search Box"));
			actData.add(webActions.getValue(drp_Filters1, ""));
			actData.add(webActions.getValue(date_VisitDate, ""));
			actData.add(webActions.getAttributeValue(drp_Facility1, "aria-label",""));
			report.reportInfo("Actual Default Values in Default Search: "+actData);
			report.reportInfo("Expected Default Values in Default Search: "+expData);
			ArrayList<String> unmatchedData=webActions.getUmatchedInArrayComparision(actData,expData);
			if(unmatchedData.size()==0){
				report.reportPass("Verified Default Values in Default Search page successfully");
			}
			else{
				throw new Exception("Fail to verify Default Values in Default Search page and unmatched data is: "+unmatchedData);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}


	public void verifyHeaderNames(DataTable headerNames){
		try {
			List<String> expHeaders = headerNames.asList(String.class);
			report.reportInfo("Expected Header Names in Default Search: "+expHeaders);
			webActions.waitForVisibility(tbl_AllRecord,"All Records");
			ArrayList<String> actHeaders = new ArrayList<String>();
			List<WebElement> webHeaders = grid_Header.findElements(By.tagName("tr"));
			List<WebElement> columns=webHeaders.get(0).findElements(By.tagName("th"));
			for (WebElement header : columns) {
				String name=header.getText();
				if(!name.isEmpty()){
					actHeaders.add(name);
				}
			}
			report.reportInfo("Actual Header Names in Default Search: "+actHeaders);
			ArrayList<String> unmatchedHeaderNames=webActions.getUmatchedInArrayComparision(actHeaders,expHeaders);
			if(unmatchedHeaderNames.size()==0){
				report.reportPass("Verified Header Names in Default Search page successfully");
			}
			else{
				throw new Exception("Fail to verify Header Names in Default Search page and unmatched Names are: "+unmatchedHeaderNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	public void verifyAccountNumberHyperLink(String pageTitle){
		try {
			webActions.waitForClickAbility(lnk_AccountNumber, "Account Number");
			String accountNumber=webActions.getText(lnk_AccountNumber, "Account Number");
			report.reportInfo("Account Number is: "+accountNumber);
			webActions.click(lnk_AccountNumber, "Account Number");
			String actPageTitle=webActions.getPageTitle();
			if(pageTitle.contentEquals(actPageTitle)){
				report.reportPass("Verified Account Number HyperLink successfully");
			}else{
				throw new Exception("Failed to verify the Account Number HyperLink and Incorrect page title is displayed: "+actPageTitle);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}


	public void selectVisitDateType(String visitDateType) throws Exception{
		webActions.waitForClickAbilityAndClick(date_VisitDate, "Visit Date");	

		if("Next3Days".contentEquals(visitDateType)){	
			webActions.waitForVisibility(li_Next3Days,"Next 3 Days");
			webActions.waitForClickAbilityAndClick(li_Next3Days, "Next 3 Days");
		}else if("Previous3Days".contentEquals(visitDateType)){
			webActions.waitForVisibility(li_Previous3Days,"Next 3 Days");
			webActions.waitForClickAbilityAndClick(li_Previous3Days, "Next 3 Days");	
		}
		webActions.waitForVisibility(btn_Apply,"Apply");
		webActions.waitForClickAbilityAndClick(btn_Apply, "Apply");
	}

	public int getResultsCount(){
		return Integer.valueOf(webActions.getText(lbl_ResultsCount, "Results count").replaceAll("\\D", ""));
	}

	public void verifytheDateofService(String fieldName,String visitDateType,String columnName) throws InterruptedException{
		try {
			ArrayList<String> actualDates = new ArrayList<String>();
			ArrayList<String> unmatchdata=new ArrayList<String>();
			String todayDate=webActions.getSystemCurrentDate();
			if("Today".contentEquals(visitDateType)){
				webActions.waitForPageLoaded();
				waitforAllRows();
				actualDates=webActions.getGridData(grid_Header,grid_Results,columnName,fieldName);
				unmatchdata=webActions.isFullArrayMatchWithData(actualDates,todayDate);
			}
			else if("Next3Days".contentEquals(visitDateType)){
				selectVisitDateType(visitDateType);
				String next3DaysDate=webActions.getNextDate(2);
				webActions.waitForVisibility(tbl_AllRecord,"All Records");
				actualDates=webActions.getVistDates(tbl_VistDate,"Total Rows");
				report.reportInfo("Results count when select Visit Date as "+visitDateType+": "+actualDates.size());
				report.reportInfo("Displyed dates are when select Visit Date as "+visitDateType+": "+actualDates);
				report.reportInfo("Expected dates is when select Visit Date as "+visitDateType+": "+todayDate+" to "+next3DaysDate);
				unmatchdata=webActions.getUnmatchedDatesFromResult(todayDate,next3DaysDate,actualDates);
			}
			else if("Previous3Days".contentEquals(visitDateType)){
				selectVisitDateType(visitDateType);
				String previous3DaysDate=webActions.getPreviousDate(2);
				webActions.waitForVisibility(tbl_AllRecord,"All Records");
				actualDates=webActions.getVistDates(tbl_VistDate,"Total Rows");
				report.reportInfo("Results count when select Visit Date as "+visitDateType+": "+actualDates.size());
				report.reportInfo("Displyed dates are when select Visit Date as: "+visitDateType+": "+actualDates);
				report.reportInfo("Expected dates is when select Visit Date as "+visitDateType+": "+previous3DaysDate+" to "+todayDate);				
				unmatchdata=webActions.getUnmatchedDatesFromResult(previous3DaysDate,todayDate,actualDates);
			}
			else if("CustomRange".contentEquals(visitDateType)){
				webActions.waitForClickAbilityAndClick(date_VisitDate, "Visit Date");
				webActions.waitForClickAbilityAndClick(li_CustomRange, "Custom Range");
				webActions.selectByVisibleText(drp_LeftMonth, "Jan", "Month");
				webActions.selectByVisibleText(drp_LeftYear, "2019", "Year");
				webActions.click(lbl_Date, "Date in Calender");
				webActions.waitForClickAbilityAndClick(btn_Apply, "Apply");
			}		
			report.reportInfo("Expected Data is: "+todayDate);
			if(unmatchdata.size()==0){
				report.reportPass("All Data verified successfully and displayed data is: " + actualDates);
			}else{
				throw new Exception("Data verification failed, and unmatched data is: "+unmatchdata);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyResultsCount(){
		try {
			waitforAllRows();
			ArrayList<String> resultsCount=webActions.getVistDates(tbl_VistDate,"Total Rows");
			int expResultsCount=resultsCount.size();
			int actResultsCount=getResultsCount();
			if(actResultsCount==expResultsCount){
				report.reportPass("Results count is verified successfully and  result count is: "+expResultsCount);
			}
			else{
				throw new Exception("Results count verification is failed and displyed results count is: "+actResultsCount);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyVisitDateTypes(DataTable visitDateTypes){
		try {
			ArrayList<String> expVisitDateTypes = new ArrayList<>(visitDateTypes.asList());
			report.reportInfo("Expected Visit Date Types in Default Search: "+expVisitDateTypes);
			webActions.waitForClickAbilityAndClick(date_VisitDate, "Visit Date");
			ArrayList<String> actVisitDateTypes=webActions.getDatafromWebTable(li_VisitDate);
			report.reportInfo("Actual Visit Date Types in Default Search: "+actVisitDateTypes);
			ArrayList<String> unmatchedVisitDateTypes=webActions.getUmatchedInArrayComparision(actVisitDateTypes,expVisitDateTypes);
			if(unmatchedVisitDateTypes.size()==0){
				report.reportPass("Verified 'Visit Date Types' from 'Visit Date' field in Default Search page successfully");
			}
			else{
				throw new Exception("Fail to verify Visit Date Types in Default Search page and unmatched Types are:"+unmatchedVisitDateTypes);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifytheValidationMessageNoResults(String validationMessage){
		try {
			StringBuffer unmatched=new StringBuffer();
			webActions.waitAndClick(date_VisitDate, "Visit Date");
			webActions.waitAndClick(li_CustomRange, "Custom Range");
			webActions.selectByVisibleText(drp_LeftMonth, "Jan", "Month");
			webActions.selectByVisibleText(drp_LeftYear, "2019", "Year");
			webActions.click(lbl_Date, "Date in Calender");
			webActions.click(lbl_Date, "Date in Calender");
			webActions.waitAndClick(btn_Apply, "Apply");
			webActions.waitForVisibility(lbl_NoResultsarefound, "No Results");
			String actValidationMessage=webActions.getText(lbl_NoResultsarefound, "No results");
			if(validationMessage.contentEquals(actValidationMessage)){
				report.reportPass("Displayed validation message if there are no records: "+actValidationMessage);
			}else{
				unmatched.append("Fail to verify the validation message in Account Search default grid when there are no records and actual displayed message is: "+actValidationMessage);
			}
			webActions.waitAndClick(date_VisitDate, "Visit Date");
			webActions.waitAndClick(li_Today, "Today");
			webActions.waitAndClick(btn_Apply, "Apply");
			webActions.waitForVisibility(tbl_AllRecord,"All Records");
			ArrayList<String> resultsCount=webActions.getVistDates(tbl_VistDate,"Total Rows");
			int expResultsCount=resultsCount.size();
			int actResultsCount=getResultsCount();
			if(expResultsCount!=actResultsCount){
				unmatched.append("Records are not matched with visit date as Today after clear the validation");
			}
			if(unmatched.length()==0){
				report.reportPass("Verified validation message when there are no records in Default Search page successfully");
			}else{
				throw new Exception("Fail to verify the validation message if there are no records and actual displayed message: "+unmatched);
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDefaultSearchData(String facilityName) throws Exception{
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.waitForPageLoaded();
			waitforAllRows();
			String todayDate=webActions.getSystemCurrentDate();
			ArrayList<String> actualDates=webActions.getGridData(grid_Header,grid_Results,"Visit","Date of Service");
			ArrayList<String> unmatchdates=webActions.isFullArrayMatchWithData(actualDates,todayDate);
			if(unmatchdates.size()==0){
				report.reportPass("Successfully verified the displayed visit dates and dates are: " + actualDates);
			}else{
				unmatch.append("Failed to verify the displayed visit dates and unmatched date's are: "+unmatchdates);
			}

			ArrayList<String> actualFacility=webActions.getGridData(grid_Header,grid_Results,"Visit","Facility");
			ArrayList<String> unmatchedFacility=webActions.isFullArrayMatchWithData(actualFacility,facilityName=facilityName.replaceAll("\\s(?=[A-Z])|(?<=\\s)\\s+", ""));
			if(unmatchedFacility.size()==0){
				report.reportPass("Successfully verified the displayed Facility's and data is: " + actualFacility);
			}else{
				unmatch.append("Failed to verify the displayed Facility's and unmatched data is: "+unmatchedFacility);
			}
			if(unmatch.length()==0){
				report.reportPass("Successfully verified the displayed default data with Date of Service and Facility");
			}else{
				throw new Exception("Failed to verify the displayed default data with Date of Service and Facility and unmatch data is:"+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void waitforAllRows(){
		try {
			webActions.waitForVisibility(tbl_AllRecord, "All Rows");
		} catch (Exception e1) {
		}
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(tbl_AllRecord);
	}

}