package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.azureutilities.TodoDaoFactory;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class MaintenancePage extends BasePage {


	@FindBy(xpath = "//span[@class='panel-title']")
	private List<WebElement> lbl_PanelNames;

	@FindBy(xpath = "//div[@class='contain-text']/a")
	private List<WebElement> lbl_PanelSectionNames;

	@FindBy(xpath = "//div[@class='contain-value']")
	private List<WebElement> lbl_PanelSectionData;

	@FindBy(xpath = "//div[@class='items']/div[2]/div[1]/form/div/div/div")
	private List<WebElement> lbl_CustomFields;
	
	@FindBy(xpath = "//td[1]//a")
	private List<WebElement> lbl_NewsTitle;

	@FindBy(xpath = "//div[@class='document-section mt-3']/div[2]/a")
	private WebElement lbl_AddNewDocument;

	@FindBy(xpath = "//div[@class='add-new-message']/p")
	private WebElement lbl_AddNewMessage;

	@FindBy(xpath = "//div[contains(text(),'Forms and Documents')]")
	private WebElement lbl_DocsForms;

	@FindBy(xpath = "//a[contains(text(),'Custom labels')]")
	private WebElement lnk_CustomFields;
	
	@FindBy(xpath = "//a[contains(text(),'News')]")
	private WebElement lnk_News;

	@FindBy(xpath = "//ejs-dashboardlayout[@id='defaultLayout']/div[1]/ipas-maintenance-panel[2]//div/div[2]/div/div/div[1]/ul/li/div/a")
	private WebElement lnk_MsgHub;

	@FindBy(xpath = "//ejs-dashboardlayout[@id='defaultLayout']/div[1]/ipas-maintenance-panel[2]//div/div[2]/div/div/div[2]/ul/li/div/a")
	private WebElement lnk_ArrivalInstr;

	@FindBy(xpath = "//ejs-dashboardlayout[@id='defaultLayout']/div[2]/ipas-maintenance-panel[1]//div/div[2]/div/div/div[1]/ul/li/div/a")
	private WebElement lnk_DigitalDocsForms;

	@FindBy(xpath = "//ejs-dashboardlayout[@id='defaultLayout']/div[2]/ipas-maintenance-panel[2]//div/div[2]/div/div/div[1]/ul/li/div/a")
	private WebElement lnk_ServiceTrackerConfig;

	@FindBy(xpath = "//ejs-dashboardlayout[@id='defaultLayout']/div[3]/ipas-maintenance-panel[2]//div/div[2]/div/div/div[1]/ul/li/div/a")
	private WebElement lnk_PaymentsDiscounts;

	@FindBy(xpath="//a[contains(text(),'Automated Transaction Configuration')]")
	private WebElement lnl_AutomatedTransaction;

	@FindBy(xpath="//a[contains(text(),'Propensity to Pay Configuration')]")
	private WebElement lnl_P2P;

	@FindBy(xpath="(//button[contains(text(),'Cancel')])[1]")
	private WebElement btn_Cancel;
	

	@FindBy(xpath="//button[contains(text(),'Add News')]")
	private WebElement btn_AddNews;

	@FindBy(xpath="//p[contains(text(),'Propensity Statuses')]")
	private WebElement lbl_PropensityStatus;

	@FindBy(xpath="(//ipas-maintenance-identity-propensity-configuration//tbody/tr[1])[2]/td[3]/div/ejs-switch")
	private WebElement btn_PostalToggleSwitchPRMH;

	@FindBy(xpath = "//button[@class='btn btn-light btn-md btn-medium']")
	private WebElement Btn_Cancel;
	
	@FindBy(xpath = "//a[contains(text(),'System Configuration')]")
	private WebElement Lnk_SystemConfig;

	@FindBy(xpath = "//ipas-button/a[@class='btn btn--white']")
	private WebElement Btn_MsgCancel;

	@FindBy(xpath = "//div[@class='no-content']/h1")
	private WebElement lbl_ApplyFilterMessage;

	@FindBy(xpath = "//div[@class='no-content']/h2")
	private WebElement lbl_Message;

	@FindBy(xpath = "//h6[contains(text(),'Lobby')]")
	private WebElement lbl_gridHeaderName;

	@FindBy(xpath = "//div[@class='gridBody']/div/form/div/div/div")
	private List<WebElement> lbl_ServiceTrackergridData;

	@FindBy(xpath = "//button[@class='btn btn-light btn-md btn-medium mr-10']")
	private WebElement Btn_ServiceTrackerCancel;

	@FindBy(xpath = "//a[contains(text(),'Add New Discount')]")
	private WebElement lbl_AddNewDiscounts;

	@FindBy(xpath = "//span[contains(text(),'Department')]")
	private WebElement lbl_gridHeaderNameServiceTracker;

	@FindBy(xpath = "//span[contains(text(),'Automated Identity Verifier')]")
	private WebElement lbl_gridHeaderNameIentifier;

	@FindBy(xpath = "//img[@src='assets/images/cog.png']")
	private WebElement img_Settings;

	@FindBy(xpath ="//span[contains(text(),'User Profile')]")
	private WebElement img_UserProfile;

	@FindBy(xpath = "//ipas-app-navigations[1]//nav[1]//div[1]/a[@class='dropdown-item']/span")
	private List<WebElement> lst_Settings;

	@FindBy(xpath ="//form[1]/div[1]/div[1]/div[2]/div[1]")
	private WebElement txt_UsrPrflFirstName;

	@FindBy(xpath ="//form[1]/div[1]/div[1]/div[3]/div[1]")
	private WebElement txt_UsrPrflLastName;

	@FindBy(xpath ="//body/ejs-dialog[3]/div[1]/div[1]/div[1]/div[1]/div[1]/button[1]")
	private WebElement btn_UsrProfileClose;

	@FindBy(xpath ="//tbody/tr[1]/td[6]/div[1]")
	private WebElement txt_lastUpdatedName;

	@FindBy(xpath ="//tbody/tr[1]/td[6]/div[2]")
	private WebElement txt_lastUpdatedDateTime;

	@FindBy(xpath ="//th/div[1]/span")
	private List<WebElement> lbl_TransactionHeaders;

	@FindBy(xpath="(//ipas-maintenance-identity-propensity-configuration//tbody/tr[1])[2]/td[3]/div/ejs-switch/span[1]")
	private WebElement btn_PostalToggleSwitch;

	public MaintenancePage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyPanelSectionData(String section,DataTable panelNames) {
		try {
			ArrayList<String> expectedData = new ArrayList<>(panelNames.asList());

			if(section.contentEquals("panels")){
				report.reportInfo("Expected Panel Names: "+expectedData);			
				webActions.waitForPageLoaded();
				webActions.waitForVisibilityOfAllElements(lbl_PanelNames, "PanelNames");
				ArrayList<String> actualPanelNames=webActions.getDatafromWebTable(lbl_PanelNames);
				report.reportInfo("Displayed Panel Names in Maintenance Page: "+actualPanelNames);
				ArrayList<String>unmatchedPanelNames=webActions.getUmatchedInArrayComparision(actualPanelNames, expectedData);
				if(unmatchedPanelNames.size()==0){
					report.reportPass("Verified panel Names from miantenance page successfully");
				}
				else{
					throw new Exception("Fail to verify panel names from maintenance page and unmatched panel names are: "+unmatchedPanelNames);
				}
			}
			else if(section.contentEquals("sections")){
				report.reportInfo("Expected Section Names: "+expectedData);			
				webActions.waitForPageLoaded();
				webActions.waitForVisibilityOfAllElements(lbl_PanelSectionNames, "SectionInPanels");
				ArrayList<String> actualPanelSectionNames=webActions.getDatafromWebTable(lbl_PanelSectionNames);
				report.reportInfo("Displayed Section Names under each panel from Maintenance Page: "+actualPanelSectionNames);
				ArrayList<String>unmatchedPanelSectionNames=webActions.getUmatchedInArrayComparision(actualPanelSectionNames, expectedData);
				if(unmatchedPanelSectionNames.size()==0){
					report.reportPass("Verified panel section Names from miantenance page successfully");
				}
				else{
					throw new Exception("Fail to verify panel section names from maintenance page and unmatched panel section names are: "+unmatchedPanelSectionNames);
				}
			}
			else if(section.contentEquals("data")){
				report.reportInfo("Expected Sections data: "+expectedData);			
				webActions.waitForPageLoaded();
				webActions.waitForVisibilityOfAllElements(lbl_PanelSectionData, "SectionsData");
				ArrayList<String> actualSectionData=webActions.getDatafromWebTable(lbl_PanelSectionData);
				report.reportInfo("Displayed data under each section of panel from Maintenance Page: "+actualSectionData);
				ArrayList<String>unmatchedPanelSectionData=webActions.getUmatchedInArrayComparision(actualSectionData, expectedData);
				if(unmatchedPanelSectionData.size()==0){
					report.reportPass("Verified panel section data from miantenance page successfully");
				}
				else{
					throw new Exception("Fail to verify panel section data from maintenance page and unmatched panel section data is: "+unmatchedPanelSectionData);
				}
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyPageNavigation(String page){
		try {
			if ("custom".contentEquals(page)) {				
				webActions.waitForPageLoaded();
				webActions.click(lnk_CustomFields, "CustomLabelsLink");
				webActions.waitForVisibilityOfAllElements(lbl_CustomFields, "CustomFields");
				webActions.scrollDownPage();
				webActions.waitForPageLoaded();
				webActions.assertDisplayed(Btn_Cancel, "Cancelbtn");
				report.reportPass("Successfully verify the page navigation of custom lables");
			}
			else if ("news".contentEquals(page)){
				//webActions.refreshPage();
				webActions.waitForPageLoaded();
				//webActions.click(Lnk_SystemConfig, "SystemConfig");
				webActions.waitForPageLoaded();
				//webActions.waitForVisibilityOfAllElements(lbl_PanelNames, "PanelNames");
				webActions.click(lnk_News, "NewsLink");
				webActions.waitForVisibilityOfAllElements(lbl_NewsTitle, "NewsTitle");				
				webActions.assertDisplayed(btn_AddNews, "AddNewsbtn");
				report.reportPass("Successfully verify the news page navigation");
			}
			else if("digital".contentEquals(page)){
				webActions.waitForPageLoaded();
				webActions.click(lnk_DigitalDocsForms, "DigitalDocsForms");
				webActions.waitForVisibilityOfAllElements(lbl_AddNewDocument, "AddDocument");			
				String actualtext=webActions.getText(lbl_DocsForms, "DocsFormsColumnName");
				report.reportInfo("Actual displayed column name : " + actualtext);
				if(actualtext.contentEquals("FORMS AND DOCUMENTS")){
					report.reportPass("Verified column name successfully");
				}
				else{
					report.reportFail("Failed to verify column name from documents and forms page");
				}

			} 
			else if("messageHub".contentEquals(page)){
				webActions.waitForPageLoaded();
				webActions.click(lnk_MsgHub, "MessageHub");
				webActions.waitForVisibilityOfAllElements(lbl_AddNewMessage, "AddNewMsg");
				webActions.scrollDownPage();
				webActions.waitForPageLoaded();
				webActions.assertDisplayed(Btn_MsgCancel, "Cancelbtn");
				report.reportPass("Cancel button is displayed on message hub configuration page");
			}
			else if("arrivalInstructions".contentEquals(page)){
				webActions.waitForPageLoaded();
				webActions.click(lnk_ArrivalInstr, "Arrival");
				webActions.waitForVisibilityOfAllElements(lbl_ApplyFilterMessage, "ApplyFilters");
				webActions.waitForVisibilityOfAllElements(lbl_Message, "BottomMsg");				
				webActions.waitForPageLoaded();
				String actualtext=webActions.getText(lbl_gridHeaderName, "GirdHeaderName");
				report.reportInfo("Actual displayed column name : " + actualtext);
				if(actualtext.contentEquals("Lobby")){
					report.reportPass("Verified column name successfully");
				}
				else{
					report.reportFail("Failed to verify column name from Arrival Instruction page");
				}
			}
			else if("serviceTrackerConfig".contentEquals(page)){
				webActions.waitForPageLoaded();
				webActions.click(lnk_ServiceTrackerConfig, "ServiceTracker");
				webActions.waitForVisibilityOfAllElements(lbl_ServiceTrackergridData, "AddNewMsg");
				webActions.scrollDownPage();
				webActions.waitForPageLoaded();
				webActions.assertDisplayed(Btn_ServiceTrackerCancel, "Cancelbtn");
				report.reportPass("Cancel button is displayed on service tracker configuration page");
			}
			else if("paymentDiscounts".contentEquals(page)){
				webActions.waitForPageLoaded();
				webActions.click(lnk_PaymentsDiscounts, "PaymentsDiscounts");
				webActions.waitForVisibilityOfAllElements(lbl_AddNewDiscounts, "AddNewDiscounts");
				webActions.waitForPageLoaded();
				String actualtext=webActions.getText(lbl_gridHeaderNameServiceTracker, "GirdHeaderName");
				report.reportInfo("Actual displayed column name : " + actualtext);
				if(actualtext.contentEquals("Department")){
					report.reportPass("Verified column name successfully");
				}
				else{
					report.reportFail("Failed to verify column name from service tracker configuration page");
				}
			}
			else if("AutomatedTransactionConfiguration".contentEquals(page)){
				webActions.waitForPageLoaded();
				webActions.click(lnl_AutomatedTransaction, "AutomatedTransactionLink");
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(btn_PostalToggleSwitchPRMH, "PostalToggleSwitch");
				webActions.waitForPageLoaded();
				String actualtext=webActions.getText(lbl_gridHeaderNameIentifier, "GirdHeaderName");
				report.reportInfo("Actual displayed column name : " + actualtext);
				if(actualtext.contentEquals("Automated Identity Verifier")){
					report.reportPass("Verified column name successfully");
				}
				else{
					report.reportFail("Failed to verify column name from transactions configuration page");
				}
			}
			else if("P2P".contentEquals(page)){
				webActions.waitForPageLoaded();
				webActions.click(lnl_P2P, "P2P");
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(btn_Cancel, "Cancel");
				webActions.waitForPageLoaded();
				String actualtext=webActions.getText(lbl_PropensityStatus, "SectionName");
				report.reportInfo("Actual displayed section name : " + actualtext);
				if(actualtext.contentEquals("Propensity Statuses")){
					report.reportPass("Verified page navigation successfully");
				}
				else{
					report.reportFail("Failed to verify page navigation");
				}
			}
			else{
				report.reportFail("Failed to verify the page navigation from miantenance page");
			}
		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}
	public void verifyLastUpdatedDetails(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitUntilEnabledAndClick(img_Settings, "Settings Icon");			
			webActions.waitUntilListisDisplayed(lst_Settings, "SettingsMenu");		
			webActions.waitForPageLoaded();
			webActions.clickBYJS(img_UserProfile, "UserProfile");
			String firstName=webActions.getText(txt_UsrPrflFirstName, "FirstName");
			String lastName=webActions.getText(txt_UsrPrflLastName, "LastName");
			String userName=firstName+" "+lastName;
			closeUserProfileWindow();
			webActions.waitForPageLoaded();
			String expUserName=webActions.getText(txt_lastUpdatedName, "LastedUpdatedName");
			String dateTime=webActions.getText(txt_lastUpdatedDateTime, "DateTime");
			String systemTime=webActions.getCurrentSystemDateTime();
			report.reportInfo("LastUpdated userName: "+ expUserName);
			report.reportInfo("Logged In userName: "+ userName);
			report.reportInfo("LastUpdatedTime: "+ dateTime);
			report.reportInfo("SystemTime: "+ systemTime);
			if(expUserName.contentEquals(userName)  && dateTime.contentEquals(systemTime)){
				report.reportPass("Verified last updated user name and time successfully");
			}
			else{
				report.reportFail("Failed to verify the last updated user name and time");
			}

			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void closeUserProfileWindow() throws Exception {
		try{
			webActions.waitForPageLoaded();
			if(webActions.isDisplayed(btn_UsrProfileClose, "X button")){
				webActions.click(btn_UsrProfileClose, "Close Button");
				webActions.waitForPageLoaded();
			}else{
				throw new Exception("Unable to find Close button in User Profile Window");
			}		
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyColumnHeaders(DataTable transaction){
		try {
			ArrayList<String> expectedtransactionNames = new ArrayList<>(transaction.asList());
			report.reportInfo("Expected transaction: "+expectedtransactionNames);		
			ArrayList<String> actualtransaction=webActions.getDatafromWebTable(lbl_TransactionHeaders);
			report.reportInfo("Displayed transaction headers: "+actualtransaction);
			ArrayList<String>unmatchedSections=webActions.getUmatchedInArrayComparision(actualtransaction, expectedtransactionNames);
			if(unmatchedSections.size()==0){
				report.reportPass("Verified transaction headers successfully");
			}
			else{
				throw new Exception("Fail to transaction headers and unmatched sections are: "+unmatchedSections);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}
	public boolean clickToggleSwitch(String toggle){
		Boolean flag=false;
		try {
			if(toggle.contentEquals("Postal")){
				webActions.waitForPageLoaded();				
				String togle=webActions.getAttributeValue(btn_PostalToggleSwitch, "class", "postalToggle");
				if(togle.contentEquals("e-switch-inner e-switch-active")){
					flag=true;
				}
				else{
					flag=false;
				}
			}else{
				throw new Exception("Fail to click on toggle switch");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}		
		return flag;
	}
	public void verifyAutoRunFlag(String dataBase,String containerName,String id, String toggle){
		try {			
			boolean flag=clickToggleSwitch(toggle);			
			webActions.waitForPageLoaded();
			org.json.JSONArray modules =TodoDaoFactory.getDao().getDocByVisitId(dataBase,containerName,id).getJSONArray("ModuleConfiguration");
			org.json.JSONObject moduesConfig=(JSONObject) modules.get(1);
			boolean AutoRunflag= (Boolean) moduesConfig.get("AutoRunFlag");
			report.reportInfo("Flag from iPAS: "+flag);
			report.reportInfo("Flag from cosmosDB: "+AutoRunflag);
			int value=Boolean.compare(flag,AutoRunflag );
			if(value==0){
				report.reportPass("Verified auto run flag successfully",false);
			}
			else{
				report.reportFail("Fail to verify auto run flag",false);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
