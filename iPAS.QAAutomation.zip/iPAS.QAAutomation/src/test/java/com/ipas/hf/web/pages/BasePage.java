package com.ipas.hf.web.pages;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.github.javafaker.Faker;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.engine.ConcurrentEngine;
import com.ipas.hf.reporting.ReportLibrary;
import com.ipas.hf.testbase.TestBase;

public abstract class BasePage<T> {

	private static ConcurrentHashMap<Long, Map<String, String>> testDataMap = new ConcurrentHashMap<Long, Map<String, String>>();

	protected WebDriver driver;

	protected WebActions webActions = ConcurrentEngine.getEngine().getWebActions();

	protected ReportLibrary report = ConcurrentEngine.getEngine().getReportLibrary();

	private final long PAGELOADTIMEOUT = Long.parseLong(TestBase.prop.pageLoadTimeout());

	protected Faker faker = new Faker();

	public BasePage() {
		this.driver = ConcurrentEngine.getEngine().getWebDriver();
	}

	public T base(Class<T> pageClass) {
		T page = null;
		try {
			page = PageFactory.initElements(ConcurrentEngine.getEngine().getWebDriver(), pageClass);
			ExpectedCondition pageLoadCondition = ((BasePage) page).getPageLoadCondition();
			waitForPageToLoad(pageLoadCondition);
		} catch (TimeoutException e) {
			// To Shorten the Message in the Summary Report
			report.reportHardFail(e, "Scenario Failed on Page : " + pageClass.getName());
		}
		return page;
	}

	private void waitForPageToLoad(ExpectedCondition<?> pageLoadCondition) {
		WebDriverWait wait = new WebDriverWait(driver, PAGELOADTIMEOUT);
		wait.until(pageLoadCondition);
	}

	/**
	 * Returns the Map Associated with the Current Thread for Main Applicant or
	 * Loan Company and to Store the Data for the test Associated
	 * 
	 * @return dataMap<String,String>
	 */
	public Map<String, String> getTestDataMap() {
		return testDataMap.get(Thread.currentThread().getId());
	}

	public void setTestDataMap(Map<String, String> map) {
		testDataMap.put(Thread.currentThread().getId(), map);
	}

	protected abstract ExpectedCondition getPageLoadCondition();

}