package com.ipas.hf.web.pages.ipasPages;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.SimpleTimeZone;
import java.util.Spliterator;

import org.apache.commons.lang.time.DateUtils;
//import org.bouncycastle.asn1.cms.Time;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;
import junit.framework.Assert;

public class UpdateVisitPage extends BasePage {
	private StepLogging log = StepLogging.getLoggingObject();
	private JSONObject jsonObject;
	ServiceTrackerPage srvTracker = new ServiceTrackerPage();
	private static final String UPDATEPATIENTVISITJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\UpdatePatientVisit.json";
	ServiceTrackerPage srvc = new ServiceTrackerPage();
	String resetPassword="";
	private RestActions rest = new RestActions();
	Login logIn = new Login();
	IdentityVerifierPage identity=new IdentityVerifierPage();
	ServiceTrackerPage servie=new ServiceTrackerPage();

	@FindBy(xpath = "//input[@id='username']")
	private WebElement txt_UserName;

	@FindBy(xpath = "//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_SimpleSearch;

	@FindBy(xpath = "//div[@class='card-body']//button[1]/img")
	private WebElement btn_ThreeDots;

	@FindBy(xpath ="//*[@id='updatepatientvisit']/div/div/div[2]/div/div[2]/span[1]")
	private WebElement lnk_VisitID;

	/*@FindBy(xpath ="//form[@id='EditForm']//div[1]/div[@class='st modal-header']/h4")
	private List<WebElement> lbl_header;*/

	@FindBy(xpath ="//form[@id='EditForm']//div[1]/div[@class='st modal-header']/h4")
	private WebElement lbl_header;

	@FindBy(xpath ="//form[@id='EditForm']//div[1]/div[@class='st modal-body']/div/div[2]/span")
	private List<WebElement> lbl_body;

	@FindBy(xpath="//form[@id='EditForm']//div[1]/div[@class='st modal-header']/button[@class='close']")
	private WebElement btn_MWindowClose;

	@FindBy(xpath ="//button[contains(text(),'Submit')]")
	private WebElement btn_MWindowSubmit;

	@FindBy(xpath= "//div[@class='st modal-footer mt-10']//button[contains(text(),'Cancel')]")
	private WebElement btn_MWindowCancel;

	@FindBy(xpath ="//div[@class='e-toolbar-item e-template e-active']")
	private WebElement tab_Assignment;

	@FindBy(xpath="//form/div[1]/div[4]/div/ejs-checkbox/label/span[2]")
	private WebElement chkbox_Priority;

	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@placeholder ='Select Destination']/span/span")
	private WebElement drpdwn_Destination;

	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@placeholder ='Select Destination']/span//input")
	private WebElement drpvalue_Destination;

	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@placeholder ='Select Registrar']/span/span")
	private WebElement drpdwn_Registrar;

	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@placeholder ='Select Registrar']/span//input")
	private WebElement drpvalue_Registrar;
	
	@FindBy(xpath = "//ejs-dropdownlist[@placeholder ='Select Registrar']/span")
	private WebElement dd_Registrar;
	
	@FindBy(xpath = "(//ejs-dropdownlist[@placeholder ='Select Registrar']//span)[2]")
	private WebElement dd_RegistrarArrow;

	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@formcontrolname='serviceTrackerStatusId']/span/span")
	private WebElement drpdwn_IntakeStatus;

	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@formcontrolname='serviceTrackerStatusId']/span//input")
	private WebElement drpvalue_IntakeStatus;

	@FindBy(xpath = "//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']")
	private List<WebElement> li_DefaultGridStatusNames;

	@FindBy(xpath = "//table/tbody/tr/td/div/div/div/div")
	private List<WebElement> li_VisitCardParts;

	@FindBy(xpath = "//div/div/div/div[2]/span[6]")
	private WebElement txt_DestinationOnVisitCard;


	@FindBy(xpath = "//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']")
	private By li_DefaultGridStatusNames1;

	String li_GridColumns = "//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']";

	@FindBy(xpath = "//table[@class='e-kanban-table e-content-table']//td")
	private WebElement lst_visitCardCount;

	@FindBy(xpath = "//div[@class='e-header-text']")
	private List<WebElement> lst_headerCardCount;

	String li_MWindTabsCountOne="//div[@class='e-toolbar-items']/div/div/div/div[@class='e-tab-text']";

	@FindBy(xpath = "//div[@class='e-toolbar-items']/div/div/div/div[@class='e-tab-text']")
	private List<WebElement> li_MWindTabsCount;

	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@placeholder ='Select Destination']/span/select/option")
	private WebElement default_Destination;

	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@placeholder ='Select Registrar']/span/select/option")
	private WebElement default_Registrar;

	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@placeholder ='Select Destination']/span/input")
	private WebElement default_MWDestination;

	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@placeholder ='Select Registrar']/span/input")
	private WebElement default_MWRegistrar;

	@FindBy(xpath="//table[1]/tbody//label[1]/span[2]")
	private WebElement default_waitTime;

	@FindBy(xpath = "//div/div/div/div[2]/span[4]")
	private WebElement txt_PointOfCare;

	@FindBy(xpath ="//div[1]/div[1]/div[1]/div[2]/span[3]")
	private WebElement txt_VCardStatus;

	@FindBy(xpath="//img[@src='assets/images/high_priority.png']")
	private WebElement img_ChkPriority;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_FilterMsgs; 

	@FindBy(xpath = "//div[1]/div[1]/div[1]/div[2]/div[1]/div[3]/span[1]")
	private WebElement txt_SrvDeptOnModelWindow;

	@FindBy(xpath="//ejs-accordion/div[1]/div[2]/div/div/ul/li/div[2]")
	private WebElement lbl_DataInAllDataPanel;

	@FindBy(xpath="//app-ipas-service-tracker-panel[1]/div[2]/ejs-accordion[1]/div[1]/div[1]/div[2]/span[1]")
	private WebElement icon_ServiceTrackerPanelCollapse; 

	@FindBy(xpath="//td/div[1]/div[1]/div[1]/div[1]/label[1]")
	private WebElement txt_VisitTimeOnCard; 

	@FindBy(xpath="//form[1]/div[1]/div[1]/div[1]/div[1]/h4[1]/span[1]")
	private WebElement txt_VisitTimeOnModalWindow; 

	@FindBy(xpath="//body/ejs-dialog[4]/div[1]/div[1]/div[1]/div[1]/div[1]/h4[1]/span")
	private WebElement txt_VisitTimeOnModalWindowOfSTFPage; 

	@FindBy(xpath="//div[@class='pasentDetails']//ul/li[4]/div[2]")
	private WebElement txt_VisitTimeOnVisitSummary;


	@FindBy(xpath="(//div/button[@class='close'])[3]")
	private WebElement btn_ModelWindowCross;

	@FindBy(xpath="//app-ipas-service-tracker-panel//a")
	private WebElement lnk_SeriveTrackerPanel;

	@FindBy(xpath="//span[contains(text(),'Wait Time')]")
	private WebElement lbl_WaitTimeHeader;

	@FindBy(xpath="//tbody/tr[2]/td[3]/div")
	private WebElement lbl_StartDateTime;

	@FindBy(xpath="//tbody/tr[2]/td[5]/div/span")
	private WebElement lbl_WaitTime;

	@FindBy(xpath="//app-ipas-service-tracker-panel//p[2]")
	private WebElement lbl_ServiceTrackerPanelWaitTime;

	@FindBy(xpath="//label/span[2]")
	private WebElement lbl_VisitCardWaitTime;

	@FindBy(xpath="//div[contains(text(),'AUTHORIZED USERS')]")
	private WebElement lbl_AuthorizedUsers; 

	@FindBy(xpath="//service-tracker-taskboard-authorized-users/div/div/div")
	private WebElement lbl_AuthorizedUsersDefaultMsg;

	@FindBy(xpath="//p[contains(text(),'Share My Visit')]")
	private WebElement lbl_VimShareMyVisit;

	@FindBy(xpath="//a[contains(text(),'Cancel')]")
	private WebElement btn_Cancel;

	@FindBy(xpath="(//mat-form-field/div/div[1])[1]")
	private WebElement txt_FirstName;

	@FindBy(xpath="(//mat-form-field/div/div[1])[2]")
	private WebElement txt_LastName;

	@FindBy(xpath="(//mat-form-field/div/div[1])[3]")
	private WebElement txt_Cell;

	@FindBy(xpath="//mat-radio-button[6]/label/div[1]")
	private WebElement btn_RelationshipToPatient;

	@FindBy(xpath="//a[contains(text(),'Confirm')]")
	private WebElement btn_Confirm;

	@FindBy(xpath = "//p[normalize-space()='Share My Visit']")
	private WebElement lnk_ShareMyVisits;

	@FindBy(xpath = "//p[contains(text(),'Relationship to Patient')]")
	private WebElement lbl_RelationShip;

	@FindBy(xpath = "//input[@formcontrolname='firstName']")
	private WebElement txt_UserFirstName;

	@FindBy(xpath = "//input[@formcontrolname='lastName']")
	private WebElement txt_UserLastName;

	@FindBy(xpath = "//input[@formcontrolname='phoneNumber']")
	private WebElement txt_UserCell;

	@FindBy(xpath = "//mat-radio-button[4]/label/div[1]")
	private WebElement btn_Parent;

	@FindBy(xpath = "//a[contains(text(),'Confirm')]")
	private WebElement btn_UserConfirm;

	@FindBy(xpath = "//mat-checkbox")
	private WebElement chk_UserTerms;

	@FindBy(xpath = "(//app-button/a)[4]")
	private WebElement btn_UserTermsConfirm;

	@FindBy(xpath = "//p[contains(text(),'User must be validated to be added to the list.')]")
	private WebElement lbl_UserValidation;

	@FindBy(xpath = "//ejs-grid//tbody/tr[1]/td/span")
	private List<WebElement> lbl_UserDetails;


	public UpdateVisitPage() {
		PageFactory.initElements(driver, this);
	}

	public UpdateVisitPage openIpasApp() {
		try {
			String URL = TestBase.prop.ipasURL();
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to Open iPAS application");
		}
		return (UpdateVisitPage) base(UpdateVisitPage.class);
	}

	public void simpleSearch(String value){
		try{	
			webActions.waitUntilListisDisplayed(li_DefaultGridStatusNames, "List");
			report.reportInfo("List is displayed on Service Tracker Board Page");
			//webActions.waitUntilListisDisplayed(li_VisitCardParts, "VisitCard Parts");
			waitForVisitCardLoade();
			report.reportInfo("Visit Card is displayed");
			webActions.waitForVisibility(txt_DestinationOnVisitCard, "DestinationVisibility",5);
			report.reportInfo("Destination value is displayed on Visit Card");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lst_visitCardCount, "visit",10);
			webActions.waitForVisibility(txt_SimpleSearch, "Simple search",120);
			webActions.clearValue(txt_SimpleSearch, "Simple search");
			webActions.waitForClickAbility(txt_SimpleSearch, "Simple search");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_SimpleSearch, value, "Visit id");
			webActions.waitForPageLoaded();
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void waitForVisitCardLoade(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(li_VisitCardParts, "VisitCard Parts");
		} catch (Exception e) {
		}
	}

	public String getVisitIdFromResponse(String visitId){
		String displayPatientAccountId = "";
		try {
			String visitIdValue = rest.getStringValueFromResponse(visitId);
			displayPatientAccountId = visitIdValue.replaceAll("\\W", "");
			report.logPass("Validate Response Body Content Matches the Expected Value: " + visitId
					+ " Actual value: " + displayPatientAccountId);
		} catch (AssertionError e) {
			report.logHardFail("Validate Response Body Content Matches the Request Failed ", e);
		}
		return displayPatientAccountId;
	}

	public String getValuefromJSONresponseBasedOnObject(){
		String expectedResponseValue=null;
		try {
			// read the json file

			FileReader reader = new FileReader(UPDATEPATIENTVISITJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON

			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");				
			expectedResponseValue= (String) visitObject.get("AccountNumber");
			System.out.println("expected AccountNumber value is :"+expectedResponseValue);

		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return expectedResponseValue;

	}

	public String verifyPatientVisitCard(String visitID) throws Exception{	 
		try{
			String xpath1="//a[text()=' ";
			String xpath2=" ']/../../../..";
			String xpath=xpath1+visitID+xpath2;
			WebElement visitCard = driver.findElement(By.xpath(xpath));
			if(visitCard.isDisplayed()){
				report.reportPass("Card is displayed successfully");
			}else{
				throw new Exception("unable to read VisitID");
			}			
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
		return visitID;
	}

	public void compareVisitID(String visitId) throws Exception{
		try{
			String expVisitID =getVisitIdFromResponse(visitId);
			report.reportInfo("Expected Visit ID :"+expVisitID);
			simpleSearch(expVisitID);
			String actVisitID = verifyPatientVisitCard(expVisitID);
			if(expVisitID.contentEquals(actVisitID)){
				report.reportPass("Visit ID compared successfully :"+actVisitID);
			}else{
				throw new Exception("unable to compare Visitid");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void openModelWindow(String visitID) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_ThreeDots, "Three Dots", 1);
			webActions.clickBYJS(btn_ThreeDots, "Three Dots");
			report.reportPass("Clicked on Three Dots");	
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lnk_VisitID, "Visit ID");
			report.reportInfo("Visit ID is displayed in the Model Window");
			webActions.waitForPageLoaded();
			String text = webActions.getText(lnk_VisitID, "Visit ID");
			webActions.waitForPageLoaded();
			report.reportInfo("Visit ID value on model window is :"+text);
			if(text.contentEquals(visitID)){
				report.reportPass("Verified VisitID in model window"+text+"    "+visitID);
			}else{
				throw new Exception("Failed to read VisitID"+text+"    "+visitID);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void closeModelWindow() throws Exception{
		try{	
			webActions.assertDisplayed(btn_MWindowClose, "Search Field");
			report.reportInfo("Close button is displayed");
			webActions.waitForClickAbilityAndClick(btn_MWindowClose, "X Buton");
			report.reportPass("Clicked on X button in Model Window");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_ThreeDots, "Three Dots");
			report.reportInfo("Three Dots is displayed on Visit Card");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public ArrayList<String> verifyDestinationRegistrarOnCard() throws Exception{
		ArrayList<String> data = new ArrayList<>();
		try{	
			report.reportPass("Visit card with Three Dots is displayed");
			List<WebElement> patientDetails = driver.findElements(By.xpath("//div/div/div/div[2]/span"));
			report.reportPass("List of all Elements are :"+patientDetails.size());
			for(int expData =1;expData<=patientDetails.size();expData++){
				if(expData==4){
					String xpath1 = "//div/div/div/div[2]/span[";
					String xpath2 ="]";
					String xpath3 =xpath1+expData+xpath2;
					WebElement valuesss = driver.findElement(By.xpath(xpath3));
					String txt = webActions.getText(valuesss, "elements");
					String[] text =txt.split(":\\s");
					txt = text[1];
					data.add(txt);
				}			
				else if(expData==5||expData==6){
					String xpath1 = "//div/div/div/div[2]/span[";
					String xpath2 ="]";
					String xpath3 =xpath1+expData+xpath2;
					WebElement valuesss = driver.findElement(By.xpath(xpath3));
					String txt = webActions.getText(valuesss, "elements");
					String[] text =txt.split(",");
					txt =text[1].trim();		
					data.add(txt);
				}
			}
		} catch(Exception e){
			report.reportFail(e.getMessage());
		}
		return data;
	}

	public void verifyModelWindowButtons() throws Exception{
		try{
			webActions.assertDisplayed(btn_MWindowClose, "X button");
			report.reportInfo("Verified the 'X Button'");
			webActions.assertDisplayed(btn_MWindowCancel, "Cancel button");
			report.reportInfo("Verified the 'Cancel Button'");
			webActions.assertDisplayed(btn_MWindowCancel, "Submit button");
			report.reportInfo("Verified the 'Submit Button'");
			webActions.assertDisplayed(chkbox_Priority, "Priority");
			report.reportInfo("Verified the 'Priority Check Box'");
			if(webActions.getText(tab_Assignment, "Assignment").contentEquals("ASSIGNMENT")){
				report.reportPass("All buttons are displayed properly");
			}else{
				report.reportFail("All buttons are not displayed properly");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyPatientDetails(String visitID) throws Exception{
		try{
			StringBuilder verify=new StringBuilder();
			webActions.waitForVisibility(tab_Assignment, "Assignment Tab");
			report.reportPass("Assignement Tab is displayed");
			String actPName = webActions.waitAndGetText(lbl_header, "PName");
			String[] aName = actPName.split(",");
			actPName = aName[0];
			report.reportInfo("Actual Patient Name from application is :"+actPName);			

			ArrayList<String> jsonValue = readPatientDetailsFromJson();
			report.reportInfo("Expected Patient Name from json file is :"+readPatientDetailsFromJson());
			String jsonPName = jsonValue.get(0);
			report.reportInfo("Expected name from json is :"+jsonPName);

			if(actPName.contentEquals(jsonPName)){
				report.reportPass("Patient Name matched :"+actPName);
			}else{
				report.reportFail("Failed to read Patient Name", true);
				verify.append("Failed to read Patient Name");
			}

			ArrayList<String> actPatientDetails = webActions.getDatafromWebTable(lbl_body);
			report.reportInfo("Actual Body Detils in Model Window :"+actPatientDetails.size()+" values are "+actPatientDetails);

			ArrayList<String> expPatientDetails =readPatientDOBDetailsFromJson();
			report.reportInfo("data from json file :"+expPatientDetails);

			ArrayList<String>unmatchedDetails=webActions.getUmatchedInArrayComparision(actPatientDetails, expPatientDetails);
			if(unmatchedDetails.size()==0){
				report.reportPass("Patient details are matched successlly :"+actPatientDetails);
			}
			else{
				report.reportFail("Failed to read Patient Details :"+unmatchedDetails, true);
				verify.append("Failed to read Patient Details");
			}

			if(verify.length()!=0){
				report.reportFail(""+verify);
			}

		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public ArrayList<String>  readPatientDetailsFromJson() throws Exception{
		ArrayList<String> updatedJSONdata = new ArrayList<String>();
		try {
			// read the json file
			FileReader reader = new FileReader(UPDATEPATIENTVISITJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject visitlocationObject = (JSONObject) visitObject.get("VisitLocation");
			JSONObject LocationObject = (JSONObject) visitlocationObject.get("LocationPointOfCare");
			JSONObject patientGenderObject = (JSONObject) patientObject.get("PatientGender");
			SimpleDateFormat jsonDate = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat appDate = new SimpleDateFormat("MM/dd/yyyy");

			try {

				updatedJSONdata.add((String)patientObject.get("PatientFirstName") +" "+((String)patientObject.get("PatientLastName")));
				/*Date expDate;
				Time expTime;
				String inputdate=(String)visitObject.get("VisitDate");
				String[] result = inputdate.split("T");
				String splitedDate=result[1];
				String splitTime = splitedDate.substring(0, 5);
				updatedJSONdata.add(splitedDate);*/

			} catch (Exception e) {
				log.error("Failed to update visitDate and fetch facilitycode and poc code ", e);
				e.printStackTrace();
			}
			FileWriter file = new FileWriter(UPDATEPATIENTVISITJSONFILE);

			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();
		} 
		catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
		catch (Exception e) {
			report.reportFail(e.getMessage());
		}	
		return updatedJSONdata;

	}

	public ArrayList<String>  readPatientDOBDetailsFromJson() throws Exception{
		ArrayList<String> updatedJSONdata = new ArrayList<String>();
		try {
			// read the json file
			FileReader reader = new FileReader(UPDATEPATIENTVISITJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject visitlocationObject = (JSONObject) visitObject.get("VisitLocation");
			JSONObject LocationObject = (JSONObject) visitlocationObject.get("LocationPointOfCare");
			JSONObject patientGenderObject = (JSONObject) patientObject.get("PatientGender");
			SimpleDateFormat jsonDate = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat appDate = new SimpleDateFormat("MM/dd/yyyy");
			try {

				String pointOfCareCode=(String) LocationObject.get("pointofCareCode");
				String firstName1=(String)patientObject.get("PatientFirstName");
				String lastName1 =(String)patientObject.get("PatientLastName");
				//String DOB1 =(String)patientObject.get("PatientDateOfBirth");//1956-09-29
				String Gender1 =(String) patientGenderObject.get("GenderCode");

				updatedJSONdata.add((String)visitObject.get("AccountNumber"));

				String dob=(String)patientObject.get("PatientDateOfBirth");
				Date expDate;
				expDate = jsonDate.parse(dob);
				updatedJSONdata.add("("+Gender1+")"+" "+appDate.format(expDate));

			} catch (Exception e) {
				log.error("Failed to update visitDate and fetch facilitycode and poc code ", e);
				e.printStackTrace();
			}
			FileWriter file = new FileWriter(UPDATEPATIENTVISITJSONFILE);

			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();
		} 
		catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
		catch (Exception e) {
			report.reportFail(e.getMessage());
		}	
		return updatedJSONdata;

	}



	public void selectDestination(String value) throws Exception{
		try{
			webActions.waitForClickAbility(drpdwn_Destination, "Destionation Drop Down");
			webActions.clickBYJS(drpdwn_Destination, "Destionation Drop Down");
			report.reportPass("Clicked on Destionation drop down");
			webActions.waitForClickAbility(drpvalue_Destination, "Destination");
			webActions.sendKeys(drpvalue_Destination, value, "Destination");
			report.reportPass("Destination value is selected :"+value);
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void selectRegistration(String value) throws Exception{
		try{
			/*webActions.waitForVisibility(drpdwn_Registrar, "Registrar Drop Down");
			webActions.clickBYJS(drpdwn_Registrar, "Registrar Drop Down");
			report.reportPass("Clicked on Registrar drop down");
			Thread.sleep(2000);
			webActions.waitForVisibility(drpvalue_Registrar, "Registrar");
			webActions.sendKeys(drpvalue_Registrar, value, "Registrar");*/
			webActions.waitForPageLoaded();
			webActions.sendKeys(dd_Registrar, value, "Registrar");
			webActions.waitForPageLoaded();
			webActions.click(dd_RegistrarArrow, "Registrar");
			report.reportPass("Registrar value is selected :"+value);
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void selectIntakeStatus(String value) throws Exception{
		try{
			webActions.waitForVisibility(drpdwn_IntakeStatus, "Intake Status Drop Down");
			webActions.clickBYJS(drpdwn_IntakeStatus, "Intake Status Drop Down");
			report.reportPass("Clicked on Registrar drop down");
			webActions.waitForVisibility(drpvalue_IntakeStatus, "Intake Status");
			Thread.sleep(10000);
			webActions.sendKeys(drpvalue_IntakeStatus, value, "Intake Status");
			report.reportPass("Intake Status value is selected :"+value);
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void selectPriority(){
		try{
			webActions.waitForClickAbility(chkbox_Priority, "Priority Check Box");
			if(chkbox_Priority.isEnabled()){
				webActions.clickBYJS(chkbox_Priority, "Priority");
				report.reportPass("Priority check box is selected ");
			}else{
				throw new Exception("Priority check box is already enabled");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void clickSubmit() {
		try{
			webActions.waitForPageLoaded();
			webActions.assertDisplayed(btn_MWindowSubmit, "Submit");
			report.reportInfo("Submit button is displayed");
			if(btn_MWindowSubmit.isEnabled()){
				webActions.clickBYJS(btn_MWindowSubmit, "Submit Buton");
				report.reportPass("Clicked on Submit button in Model Window");
			}else{
				throw new Exception("unable to click on submit button as it is not enabled");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void clickCancel() throws Exception{
		try{
			webActions.assertDisplayed(btn_MWindowCancel, "Cancel");
			report.reportInfo("Cancel button is displayed");
			if(btn_MWindowCancel.isEnabled()){
				webActions.click(btn_MWindowCancel, "Cancel Buton");
				report.reportPass("Clicked on Cancel button in Model Window");
			}else{
				throw new Exception("unable to click on Cancel button");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyVisitCardsCount(String expStatusName) {
		webActions.waitForVisibility(txt_SimpleSearch, "Search Text Box");
		report.reportPass("Search Text Box is displayed properly");
		List<WebElement> actGridStatus=driver.findElements(By.xpath(li_GridColumns));
		report.reportInfo("Actual Default Status Columns in Service Tracker Page : "+actGridStatus.size());
		for(int gridc=0;gridc<actGridStatus.size();gridc++){
			String txt1=actGridStatus.get(gridc).getText();
			String[] splited = txt1.split("\\s[-(]");
			txt1=splited[0];
			if(txt1.contentEquals(expStatusName)){	
				String xpath1="//td[";
				String xpath2= "]//div[@class='card-body']";
				String xpath =xpath1+(gridc+1)+xpath2;
				List<WebElement> totalCards = driver.findElements(By.xpath(xpath));
				report.reportPass("total cards count in :"+txt1+" Status Column are :"+ totalCards.size());				
			}
		}
	}

	@SuppressWarnings("unused")
	public void verifyCardAgainstStatusColumn(String expStatusName, String visitID) throws Exception{
		//webActions.refreshPage();
		srvTracker.navigatetoServiceTrackerPage("iPAS");
		List<WebElement> gridHeaders = driver.findElements(By.xpath(li_GridColumns));
		report.reportPass("total columns displayed in the grid are :"+gridHeaders.size());		
		for(int gridc=0;gridc<gridHeaders.size();gridc++){
			String txt1=gridHeaders.get(gridc).getText();
			String[] splited = txt1.split("\\s[-(]");
			txt1=splited[0];
			if(txt1.contentEquals(expStatusName)){	
				report.reportPass("status is displayed");
				String xpath1="//td[";
				String xpath2= "]//div[@class='card-body']";
				String xpath =xpath1+(gridc+1)+xpath2;
				List<WebElement> totalCards = driver.findElements(By.xpath(xpath));
				int cardinGrid = totalCards.size();
				report.reportPass("total cards count in :"+gridHeaders.get(gridc).getText()+" Status Column are :"+cardinGrid);		
				for(int j=0;j<cardinGrid;j++){
					String txt=totalCards.get(j).getText();
					String[] splited1 = txt.split("\\s");
					txt =splited1[0];	
					if(visitID.contentEquals(txt)){
						report.reportPass("visit id value is :"+txt+" is displayed under the status :"+txt1);
						break;
					}					

				}
			}
		}
	}


	public ArrayList<String> gridColumnNames(List<WebElement> elements){
		ArrayList<String> data= new ArrayList<String>();
		List<WebElement> allElement = elements;
		for (WebElement we: allElement) { 		
			String txt=we.getText();
			String[] splited = txt.split("\\s[(]");
			txt=splited[0];
			data.add(txt);
		}
		return data;
	}

	public void verifyTabsNamesInModelWindow(DataTable expTabs){
		try{
			webActions.waitForVisibility(btn_MWindowSubmit, "Submit Button");
			report.reportPass("Submit button in Model Window is displayed");
			ArrayList<String> expTabsCount = new ArrayList<>(expTabs.asList());
			report.reportInfo("Expected Tabs Names in Model Window : "+expTabsCount);		
			ArrayList<String> actTabsCount= webActions.getDatafromWebTable(li_MWindTabsCount);
			report.reportPass("Total actual tabs Names in model window are :"+actTabsCount.size());
			ArrayList<String> unmatchedTabNames=getUmatchedInArrayComparision(expTabsCount,actTabsCount);
			if(unmatchedTabNames.size()==0){
				report.reportPass("Verified Tabs Names Successfully");
			}
			else{
				throw new Exception("Fail to verify Tab Names in Model Window and unmatched Types are:"+unmatchedTabNames);
			}

		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void defaultVaulesofDestinationRegistrar(){
		try{
			String destination = webActions.getAttributeValue(default_MWDestination, "aria-placeholder", "Destination");
			String registrar = webActions.getAttributeValue(default_MWRegistrar, "aria-placeholder", "Registrar");
			report.reportPass("Destination default value is :"+destination);
			report.reportPass("Registrar default value is :"+registrar);
			if(destination.contentEquals("Select Destination")&&registrar.contentEquals("Select Registrar")){
				report.reportPass("default values of Destination and Registrar are displayed properly");
			}else{
				throw new Exception("default values of Destination and Registrar are not displayed properly");
			}		
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public ArrayList<String> getUmatchedInArrayComparision(List<String> actData, List<String> expData) throws Exception
	{
		ArrayList<String> UnmatchedArray = new ArrayList<String>();
		if(actData!=null && expData!=null &&actData.size()>0&&expData.size()>0 && actData.size()==expData.size()){
			for(int data=0;data<actData.size();data++)
			{
				if(!((actData.get(data)).contentEquals(expData.get(data))))
					UnmatchedArray.add(actData.get(data));	
			}
		}
		else{
			throw new Exception("Arrya Sizes are not matched");
		}
		return UnmatchedArray;			
	}

	public void verifyWaitTime() throws Exception{
		boolean flag = false;
		try{
			flag = webActions.isDisplayed(default_waitTime, "Waittime");
			if(flag == true){
				report.reportInfo("Wait Time is displayed on the Visit Card");
			}else if(flag == false){
				report.reportPass("Wait Time is not displayed on the Visit Card");
			}

		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public static String getUniqueNumber() {
		String uniqueNumber = "";
		try {
			Date dNow = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("ddYYHHmmMs");
			String s = ft.format(dNow);
			uniqueNumber = s.substring(0, Math.min(s.length(), 10));

		} catch (Exception e) {

		}
		return uniqueNumber;
	}

	@SuppressWarnings("unchecked")
	public void updatePatientVisitADTJsonFile(String eventType) throws ParseException {
		//ServiceTrackerJSON
		String newNum = "";
		try {
			// read the json file
			FileReader reader = new FileReader(UPDATEPATIENTVISITJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject visitlocationObject = (JSONObject) visitObject.get("VisitLocation");
			JSONObject LocationObject = (JSONObject) visitlocationObject.get("LocationPointOfCare");
			JSONObject appointmentObject = (JSONObject) jsonObject.get("Appointment");
			//JSONObject PointOfCareObject = (JSONObject) LocationObject.get("pointofCareCode");

			// Update tenantPatientId
			try {
				String number = getUniqueNumber();
				newNum = "VN" + number;
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(0);
				tenantPatient.put("TenantPatientId", newNum);
				String test = (String) tenantPatient.get("TenantPatientId");	

				JSONObject tenantPatientPI = (JSONObject) msg.get(3);
				tenantPatientPI.put("TenantPatientId", newNum);
			} catch (Exception e) {
				log.error("Failed to update tenant patiend id", e);
				e.printStackTrace();
			}
			try {
				// update AccountNumber, VisitNumber and visitDate					
				visitObject.put("AccountNumber", newNum);
				visitObject.put("VisitNumber", newNum);
				Object tt = visitObject.get("VisitDate");
				String updatedDate = rest.updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);


			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}

			try{

				JSONArray patientPhonenum = (JSONArray) patientObject.get("PatientPhoneNumber");
				JSONObject pnum = (JSONObject) patientPhonenum.get(0);
				pnum.put("PhoneNumber", rest.getUniqueNumber());

			}catch(Exception e){
				log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
			}

			if (eventType.equals("S12")) {
				try {
					// update appointmentStartDate and appointmentEndDate
					Object appointment = appointmentObject.get("AppointmentStartDate");
					String updatedDates = rest.updatedDateAppointment(appointment);
					appointmentObject.put("AppointmentStartDate", updatedDates);
					appointmentObject.put("AppointmentEndDate", updatedDates);
					String appointmentId = rest.getUniqueAppointmentNumber();				
					appointmentObject.put("AppointmentId", appointmentId);
				} catch (Exception e) {
					log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
					e.printStackTrace();
				}

				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", "S12");
					eventObject.put("EventTypeDescription", "New Appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			} 
			else if ("A04".contentEquals(eventType)) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");                    
					eventObject.put("EventTypeCode", eventType);
					eventObject.put("EventTypeDescription", "Registered");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if ("A08".contentEquals(eventType)) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");                    
					eventObject.put("EventTypeCode", eventType);
					eventObject.put("EventTypeDescription", "Update patient information");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if ("A11".contentEquals(eventType)) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");                    
					eventObject.put("EventTypeCode", eventType);
					eventObject.put("EventTypeDescription", "Cancel admit/visit");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}

			FileWriter file = new FileWriter(UPDATEPATIENTVISITJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}

	}

	public void selectDepartment() throws Exception{
		try{
			webActions.waitUntilListisDisplayed(lst_headerCardCount, "Columns list in Grid");
			webActions.waitForClickAbilityAndClick(drpdwn_Destination, "Destinaton");
			webActions.sendKeysByJS(drpvalue_Destination, "TestDepartment4", "Department");
			report.reportPass("Department is selected");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void getPOFCareOnCard(String pocCode,String visitID) throws Exception{
		String pocOnCard=null; String jsonPOC= null;
		try{
			jsonPOC= logIn.getVisitIdFromResponse(pocCode);
			if(jsonPOC.contentEquals("MFM")){
				pocOnCard="Maternal Fetal Medicine";
			}else if(jsonPOC.contentEquals("UCC")){
				pocOnCard="Urgent Care Center";
			}
			String actTextOnVisitCard = webActions.getText(txt_PointOfCare, "PointOFCare");
			String[] text =actTextOnVisitCard.split(":\\s");
			actTextOnVisitCard = text[1];
			report.reportInfo("Service Department on Visit Card is :"+actTextOnVisitCard);
			openModelWindow(visitID);
			String actTextonModelWindow = webActions.getText(txt_SrvDeptOnModelWindow, "SRV Dept on MW");
			report.reportInfo("Service Department on Model window is :"+actTextonModelWindow);
			//closeModelWindow();
			if(actTextOnVisitCard.contentEquals(pocOnCard)&&actTextonModelWindow.contentEquals(pocOnCard)){
				report.reportPass("Service Department value is displayed properly");
			}else{
				throw new Exception("Service Department value is not matched");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void getStatusOnCard() throws Exception{
		try{
			String actStatus = webActions.getText(txt_VCardStatus, "Status on Card");
			report.reportPass("Status on Vist Card is :"+actStatus);
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void priorityDisplayedOnCard() throws Exception{
		try{
			if(webActions.isDisplayed(img_ChkPriority, "Priority")){
				report.reportPass("Priority icon is displayed on the visit card");
			}else{
				throw new Exception("Failed to identify Priority on visit card");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void priorityNotDisplayedOnCard() throws Exception{
		try{webActions.waitForPageLoaded();
		webActions.isDisplayed(img_ChkPriority, "Priority");
		report.reportFail("Priority Image is displayed");
		}catch(Exception e){
			report.reportPass("Priority icon is not displayed on the visit card");
		}
	}

	/**To verify the filter messages*/
	public void getfilterMessages(){
		String title = "Success!"; String content ="Data saved successfully.";
		try {
			String msg=webActions.waitAndGetText(txt_FilterMsgs, "FilterMsgs");
			String[] titleContent=msg.split("\\n");
			String actTitle=titleContent[0];
			String actContent=titleContent[1];
			if((title.contentEquals(actTitle)) && (content.contentEquals(actContent))){
				report.reportPass("Both title and content displayed properly");
			}
			else{
				throw new Exception("Both title and content are not displayed properly actual Title: "+actTitle+ "and actual content: "+actContent);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDestinationRegistrarOnVisitCard(DataTable options) throws Exception{
		try{
			ArrayList<String> expectedOptions = new ArrayList<>(options.asList());
			report.reportInfo("Expected option Names: "+expectedOptions);
			ArrayList<String> actualOptions=verifyDestinationRegistrarOnCard();
			report.reportInfo("Displayed tools options Names in Application: "+actualOptions);
			ArrayList<String>unmatchedOptionNames=webActions.getUmatchedInArrayComparision(actualOptions, expectedOptions);
			if(unmatchedOptionNames.size()==0){
				report.reportPass("Verified tool options in tool icon list of Account Search page successfully");
			}
			else{
				throw new Exception("Fail to verify list of options in column tools menu of Account Search page and unmatched options are: "+unmatchedOptionNames);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyVisitNumberColor() throws Exception{
		try{
			webActions.waitForPageLoaded();
			String actValue = webActions.getAttributeValue(lnk_VisitID, "class", "VisitNumber");
			if(actValue.contentEquals("textblue")){
				report.reportPass("Visit Number is displayed in Blue Color");
			}else{
				throw new Exception("Unable to find the color of Visit Number on Model Window");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyExpandandCollapseServiceTrackerPanel() throws Exception{
		StringBuilder unmatch=new StringBuilder();		
		webActions.waitForVisibility(lbl_DataInAllDataPanel, "DataInPanel",30);		
		String actualExpandStatus=webActions.getAttributeValue(icon_ServiceTrackerPanelCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons e-expand-icon".contentEquals(actualExpandStatus)){
			report.reportPass("By default All Data Panel is displayed in Expand mode");
		}else{
			unmatch.append("Panle is not dispalyed in Expand mode by default");
			report.reportFail("Panle is not dispalyed in Expand mode by default");
		}
		webActions.waitAndClick(icon_ServiceTrackerPanelCollapse, "ExpandandCollapse");
		webActions.waitForVisibility(icon_ServiceTrackerPanelCollapse, "ExpandandCollapse",30);
		webActions.waitForPageLoaded();
		String actualCollapseStatus=webActions.getAttributeValue(icon_ServiceTrackerPanelCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons".contentEquals(actualCollapseStatus)){
			report.reportPass("Service Tracker Panel Successfully Collapsed");
		}
		else{
			unmatch.append("Service Tracker Panel  is not Collapsed");
			report.reportFail("Service Tracker Panel  is not Collapsed");
		}		
		if(unmatch.length()==0){
			report.reportPass("Service Tracker Panel  Successfully Expanded and Collapsed");
		}else{
			report.reportFail("Failed to verify the Expand and Collapse of the Service Tracker Panel  Panel"+unmatch);
		}

	}

	public void verifyVistTime(String pageName, String hrTime, String minTime,String visitDate) throws Exception{
		String actText = null;
		try{

			report.reportInfo("pageName is :"+pageName);
			report.reportInfo("hours is :"+hrTime);
			report.reportInfo("min is :"+minTime);
			report.reportInfo("visitDate is :"+visitDate);
			webActions.waitForPageLoaded();
			String expVisitTime = getVisitandDischargeDate(visitDate, hrTime, minTime);
			//String expVisitTimee = webActions.getCurrentSystemTime();
			report.reportInfo("Expected Visit Time is :"+expVisitTime);
			if(pageName.contentEquals("VisitCard")||pageName.contentEquals("ModalWindow")||pageName.contentEquals("VisitInformation")){
				if(pageName.contentEquals("VisitCard")){
					actText = webActions.getText(txt_VisitTimeOnCard, "VisitTime");
					report.reportInfo("Visit Time on Visit Card is :"+actText);
					if(actText.contentEquals(expVisitTime)){
						report.reportPass("Visit Time is displayed properly on Visit Card");
					}else{
						report.reportFail("Failed to read Visit Time on Visit Card");
						throw new Exception("Failed to read Visit Time on Visit Card");
					}
				}else if(pageName.contentEquals("ModalWindow")){
					actText = webActions.getText(txt_VisitTimeOnCard, "VisitTime");
					report.reportInfo("Visit Time on Visit Card is :"+actText);
					if(actText.contentEquals(expVisitTime)){
						report.reportPass("Visit Time is displayed properly on Modal Window");
					}else{
						report.reportFail("Failed to read Visit Time on Modal Window");
						throw new Exception("Failed to read Visit Time on Modal Window");
					}
				}else if(pageName.contentEquals("VisitInformation")){
					String actTotalText = webActions.getText(txt_VisitTimeOnVisitSummary, "VisitTime");
					actText = actTotalText.substring(12, 19);
					report.reportInfo("Visit Time on Visit Card is :"+actText);
					if(actText.contentEquals(expVisitTime)){
						report.reportPass("Visit Time is displayed properly on Visit Information");
					}else{
						report.reportFail("Failed to read Visit Time on Visit Information");
						throw new Exception("Failed to read Visit Time on Visit Information");
					}
				}
			}else{
				report.reportFail("Failed to read page name ");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public String getVisitDatefromJSONresponseBasedOnObject(){
		String expectedResponseValue=null;
		try {
			// read the json file

			FileReader reader = new FileReader(UPDATEPATIENTVISITJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON

			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");				
			expectedResponseValue= (String) visitObject.get("VisitDate");		


		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return expectedResponseValue;

	}


	public String getVisitandDischargeDate(String actDate,String hours,String minutes) throws Exception{
		SimpleDateFormat inputDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		SimpleDateFormat outputDate = new SimpleDateFormat("MM/dd/yyy h:mm a");
		Date date = inputDate.parse(actDate);
		int hoursTime = Integer.parseInt(hours);
		int minutesTime = Integer.parseInt(minutes);
		Date newDate = DateUtils.addHours(date, hoursTime);
		newDate = DateUtils.addMinutes(newDate, minutesTime);
		String expDate = outputDate.format(newDate);		
		String expSplitTime = expDate.substring(11, 18);
		return expSplitTime;
	}

	public void clickOnServiceTracerPanelLnk(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lnk_SeriveTrackerPanel, "ServiceTrackerPanel");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_WaitTimeHeader, "WaitTime");
			report.reportInfo("Navigated to the service tracker full page");

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyDisplayWaitTime(){
		try {
			webActions.waitForPageLoaded();
			Thread.sleep(1000);
			String startDateTime=webActions.getText(lbl_StartDateTime, "StartDateTime");
			String[] dateTime=startDateTime.split(" ");
			String time=dateTime[1];
			String[] timeSplit=time.split(":");
			String hours=timeSplit[0];
			String mins=timeSplit[1];	
			int disphr=Integer.parseInt(hours);
			int dispmin=Integer.parseInt(mins);
			long differenceTime=timedifferenceInHM(disphr,dispmin);
			report.reportInfo("long time : " + differenceTime);
			String diffTime=Long.toString(differenceTime)+"M";
			String actTime=webActions.getText(lbl_WaitTime, "ActWaitTime");
			report.reportInfo("Difference time : " + diffTime);
			report.reportInfo("Actual wait time : " + actTime);
			if(actTime.contentEquals(diffTime)){
				report.reportInfo("Difference time : " + diffTime);
				report.reportInfo("Actual wait time : " + actTime);
				report.reportPass("Verified wait time successfully");
			}
			else{
				report.reportFail("Fail to verify wait time and displayed time is :" + actTime,true);
			}
			identity.navigateToVisitMainPage();
			String panelWaitTime=webActions.getText(lbl_ServiceTrackerPanelWaitTime, "PanelWaitTime");
			String panelTime=panelWaitTime.substring(12, 14);
			report.reportInfo("Panel time is : " + panelTime);
			if(panelTime.contentEquals(diffTime)){
				report.reportInfo("Difference time : " + diffTime);
				report.reportInfo("Panel wait time : " + actTime);
				report.reportPass("Verified wait time successfully");
			}
			else{
				report.reportFail("Fail to verify wait time and displayed time on panel is :" + panelTime,true);
			}	
			webActions.notepadWrite("hellow", diffTime);
			Thread.sleep(2000);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void waitTimeOnCard(){
		try {
			String diffTime=webActions.notepadRead("hellow");			
			String cardWaitTime=webActions.getText(lbl_VisitCardWaitTime, "CardWaitTime");
			if(diffTime.contentEquals(cardWaitTime)||cardWaitTime.contentEquals("2M")){
				report.reportInfo("Difference time : " + diffTime);
				report.reportInfo("Visit Card wait time : " + cardWaitTime);
				report.reportPass("Verified wait time successfully");
			}
			else{
				report.reportFail("Fail to verify wait time and displayed time on panel is :" + cardWaitTime);
			}	
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public long timedifferenceInHM(int hr,int min){
		long minutes=0;
		try {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("hh:mm");
			LocalTime now = LocalTime.now();
			String dateTime  = dtf.format(now);
			String[] str=dateTime.split(":");
			String hour=str[0];
			String minute=str[1];
			int sysHr=Integer.parseInt(hour);
			int sysMin=Integer.parseInt(minute);	

			System.out.println("systemhours: " + sysHr);
			System.out.println("systemhours: " + sysMin);
			System.out.println("hours: " + hr);
			System.out.println("hours: " + min);
			// Parsing Time Period in the format HH:MM:SS
			LocalTime time1 = LocalTime.of(sysHr,sysMin);
			LocalTime time2 = LocalTime.of(hr,min);

			// Calculating the difference in Hours
			long hours = ChronoUnit.HOURS.between(time1, time2);

			// Calculating the difference in Minutes
			minutes  = ChronoUnit.MINUTES.between(time2, time1) % 60;

			// Calculating the difference in Seconds
			long seconds = ChronoUnit.SECONDS.between(time1, time2) % 60;

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
		return minutes;
	}

	public void authorizedUsersTab(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lbl_AuthorizedUsers, "AuthorizedUsersTab");
			webActions.waitForPageLoaded();
			Thread.sleep(2000);
			report.reportPass("Navigated to the AuthorizedUsersTab");			

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyAuthorizedUsersTabMsg(String expMsg){
		try {
			webActions.waitForPageLoaded();
			String actMsg=webActions.getText(lbl_AuthorizedUsersDefaultMsg, "AuthorizedUsersTab");
			if(actMsg.contentEquals(expMsg)){
				report.reportPass("Verified default success message successfully in AuthorizedUsersTab");
			}
			else{
				report.reportFail("Fail to verify default message in AuthorizedUsersTab");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void addAuthorizedUserInVim(DataTable testData){
		try {
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_ShareMyVisits, "ShareMyVisits");
			webActions.waitForVisibility(lbl_RelationShip, "RelationShip");
			webActions.sendKeys(txt_UserFirstName, webActions.getDatafromMap(testData, "FirstName"), "FirstName");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_UserLastName, webActions.getDatafromMap(testData, "LastName"), "LastName");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_UserCell, webActions.getDatafromMap(testData, "Cell"), "CellPhone");
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_Parent, "Parent");
			webActions.waitForClickAbilityAndClick(btn_UserConfirm, "Confirm");
			webActions.waitForVisibility(chk_UserTerms, "TermsChkBox");
			webActions.waitAndClick(chk_UserTerms, "TermsChkBox");
			webActions.waitForClickAbilityAndClick(btn_UserTermsConfirm, "Confirm");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_UserValidation, "UserValidation");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyAuthorizedUsersInTab(DataTable testData){
		try {
			webActions.waitForPageLoaded();
			ArrayList<String> expectedUserDetails = new ArrayList<>(testData.asList());
			report.reportInfo("Expected User details: "+expectedUserDetails);
			ArrayList<String> displayedDetails=webActions.getDatafromWebTable(lbl_UserDetails);
			report.reportInfo("Displayed user details on authorized tab: "+displayedDetails);
			ArrayList<String>unmatchedUserDetails=webActions.getUmatchedInArrayComparision(displayedDetails, expectedUserDetails);
			if(unmatchedUserDetails.size()==0){
				report.reportPass("Verified Authorized user details successfully");
			}
			else{
				throw new Exception("Fail to verify Authorized user details from Authoried tab and unmatched details are: "+unmatchedUserDetails);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_UserName);
	}

}
