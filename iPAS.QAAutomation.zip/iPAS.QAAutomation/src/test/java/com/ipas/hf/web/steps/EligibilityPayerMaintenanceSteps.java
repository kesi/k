package com.ipas.hf.web.steps;

import java.io.IOException;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.web.pages.ipasPages.AddPatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.EligibilityPayerMaintenancePage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class EligibilityPayerMaintenanceSteps {

	EligibilityPayerMaintenancePage eligiPayerMain=new EligibilityPayerMaintenancePage();
	AddPatientVisitPage addPatient=new AddPatientVisitPage();

	@Then("Verify the display of panel name and content text")
	public void verify_the_display_of_panel_name_and_content_text(DataTable panelData) {
		eligiPayerMain.verifyLabelNames(panelData);
	}

	@Then("Verify the page navigation")
	public void verify_the_page_navigation() {
		eligiPayerMain.verifyfields();
	}

	@Then("Verify the Breadcrumb for payer maintenance")
	public void verify_the_Breadcrumb_for_payer_maintenance(DataTable breadcrumb) {
		eligiPayerMain.verifyBreadcrumbinPayerMaintenance(breadcrumb);
	}
	@Then("Click on Payer Maintenance link")
	public void click_on_Payer_Maintenance_link() {
		eligiPayerMain.clickPayerMaintenanceLink();
	}
	@Then("Verify the navigation bar menu list")
	public void verify_the_navigation_bar_menu_list(DataTable navigationMenu) {
		eligiPayerMain.verifyNavigationBarList(navigationMenu);
	}
	@Then("Verify display of icons")
	public void verify_display_of_icons() {
		eligiPayerMain.verifyIcons();
	}
	@Then("Click on Add New Plan button")
	public void click_on_Add_New_Plan_button() {
		eligiPayerMain.clickOnAddNewPlan();
	}

	@Then("Verify the title of page navigation as {string}")
	public void verify_the_title_of_page_navigation_as(String title) {
		eligiPayerMain.verifyAddNewPlanPage(title);
	}
	@Then("Verify the display of {string} in add new plan code window")
	public void verify_the_display_of_in_add_new_plan_code_window(String scenario,DataTable testData) {
		eligiPayerMain.verifyAddNewPlanLabelNames(scenario, testData);
	}

	@Then("Verify the display mode for Save and Slider toggle buttons")
	public void verify_the_display_mode_for_Save_and_Slider_toggle_buttons() {
		eligiPayerMain.verifySaveSliderbtnMode();
	}
	@Then("Click on cancel button and verify page navigation")
	public void click_on_cancel_button_and_verify_page_navigation() {
		eligiPayerMain.clickCancleAndVerify();
	}


	@Then("Enter the data in Add New Plan Code")
	public void enter_the_data_in_Add_New_Plan_Code(DataTable testData) {
		eligiPayerMain.enterNewPlanCode(testData);
	}
	@Then("Verify the validation of {string} as {string} and enter data as {string}")
	public void verify_the_validation_of_as_and_enter_data_as(String field,String expMsg,String input) {
		eligiPayerMain.verifyPlanCodePlanNameValidation(field, expMsg, input);
	}
	@Then("Create the add new plan code and click on save button")
	public void create_the_add_new_plan_code_and_click_on_save_button(DataTable testData) {
		String planCode=eligiPayerMain.createNewPlanCode(testData);
		addPatient.notepadWrite("hello",planCode);
	}

	@Then("Try to add the duplicate new plan code")
	public void try_to_add_the_duplicate_new_plan_code(DataTable testData) {
		String planCode=eligiPayerMain.createNewPlanCode(testData);
		eligiPayerMain.clickOnAddNewPlan();		
		eligiPayerMain.createDuplicateNewPlanCode(testData,planCode);
		eligiPayerMain.verifyAlertMessagesWhenCreateDuplicatePlanCode(testData,planCode);
	}
	@Then("One Facility plan code to another facility")
	public void one_Facility_plan_code_to_another_facility(DataTable testData) {
		String planCode=eligiPayerMain.createNewPlanCode(testData);
		eligiPayerMain.clickOnAddNewPlan();
		eligiPayerMain.onePlanCodeToAnotherFacility(testData,planCode);
	}
	@Then("Verify the display of fields and buttons")
	public void verify_the_display_of_fields_and_buttons(DataTable testData) {
		eligiPayerMain.verifySearchFieldsAndButtons(testData);
	}
	@Then("Verify the default values")
	public void verify_the_default_values(DataTable testData) {
		eligiPayerMain.verifyDefaultValuesOfSearchPayerbar(testData);
	}
	@Then("Verify the default result value and results message")
	public void verify_the_default_result_value_and_results_message(DataTable testData) {
		eligiPayerMain.veriyDefaultResultGridValues(testData);
	}
	@Then("Verify the created plan code data from result grid")
	public void verify_the_created_plan_code_data_from_result_grid() throws IOException {
		String planCode=addPatient.notepadRead("hello");
		eligiPayerMain.verifyCreatedPlanCodeFromGrid(planCode);
	}
	@Then("Click on Apply button")
	public void click_on_Apply_button() {
		eligiPayerMain.clickOnApplyButton();
	}

	@Then("Verify the display of grid header names")
	public void verify_the_display_of_grid_header_names(DataTable testData) {
		eligiPayerMain.verifysearchPayerGridHeaders(testData);
	}
	@Then("Enter search data as {string} in search text field")
	public void enter_search_data_as_in_search_text_field(String input) {
		eligiPayerMain.searchPlanCodeName(input);
		addPatient.notepadWrite("hello",input);
	}
	@Then("Select the payer code as {string} from payer code drop down")
	public void select_the_payer_code_as_from_payer_code_drop_down(String input) {
		eligiPayerMain.selectPayerCode(input);
		addPatient.notepadWrite("hello",input);
	}		

	@Then("Verify the display of {string} result grid")
	public void verify_the_display_of_result_grid(String column) throws IOException {
		String planName=addPatient.notepadRead("hello");
		eligiPayerMain.verifyPlanNameFormGrid(column,planName);
	}
	@Then("Select the facility as {string} from facility drop down")
	public void select_the_facility_as_from_facility_drop_down(String input) {
		eligiPayerMain.selectFacility(input);
		addPatient.notepadWrite("hello",input);
	}
	@Then("Enter invalid search data as {string} in search text field")
	public void enter_invalid_search_data_as_in_search_text_field(String input) {
		eligiPayerMain.enterDatainSearchField(input);
	}
	
	@Then("Select module {string} from Payer Configuration page")
	public void select_module_from_Payer_Configuration_page(String moduleName) {
		eligiPayerMain.selectModule(moduleName);
	}
	
	@Then("Refresh the page")
	public void refresh_the_page() {
		eligiPayerMain.refreshPage();
	}
	
	@Then("Select the Department {string}")
	public void select_the_Department(String department) {
	    eligiPayerMain.selectDepartment(department);
	}



}
