package com.ipas.hf.web.pages.ipasPages;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class AdministrativeDepartmentsPage extends BasePage {

	@FindBy(linkText="Administrative Departments")
	private WebElement lnk_AdministrativeDepartments;

	/*@FindBy(xpath="//table[@role='grid']//thead/tr/th")
	private List<WebElement> lbl_HeaderNames;*/

	@FindBy(xpath="//span[@class='breadcrum-active']")
	private WebElement lbl_Breadcrum;

	@FindBy(xpath="//span[(text()='Organization Levels')]")
	private WebElement lbl_PanelHeader;

	@FindBy(xpath="//a[(text()='Administrative Departments')]/../../div[2]")
	private WebElement lbl_PanelText;

	@FindBy(xpath="//span[(text()='Organization Levels')]/../../..")
	private WebElement atr_PanelExpandCollapse;

	@FindBy(linkText="Add New Administrative Department")
	private WebElement btn_AddNewAdministrativeDepartment;

	@FindBy(xpath="//span[normalize-space()='Active']")
	private WebElement chk_Active;

	@FindBy(xpath="//ejs-switch[@role='switch']")
	private WebElement chk_ActiveSwitch;

	@FindBy(xpath="//div[@id='addDeptSection']//child::label")
	private List<WebElement> lbl_FeildNames;

	@FindBy(xpath="//div[@class='dual-list-wrapper']//p")
	private List<WebElement> lbl_ListBoxNames;

	@FindBy(xpath="//div[contains(@class,'addDepartment footer')]//child::button")
	private List<WebElement> lbl_ButtonNames;

	@FindBy(xpath="//label[(text()='Effective Date')]/../div")
	private WebElement lbl_EffectiveDate;

	@FindBy(xpath="//li[@class='e-list-nrt']")
	private WebElement lbl_AssignedFacilities_NoRecordsFound;

	@FindBy(xpath="//div[@class='mandatory']/div")
	private List<WebElement> lbl_MandatoryMessages;

	@FindBy(xpath="//label[@class='mandatory']")
	private WebElement lbl_MandatoryAssignedFacilities;

	@FindBy(xpath="//ejs-textbox[@placeholder='Name']/span/input")
	private WebElement txt_Name;

	@FindBy(xpath="//ejs-dropdownlist[@placeholder='Select Type']/span/input")
	private WebElement dd_Type;

	@FindBy(xpath="//input[@id='search_text']")
	private WebElement searchtxt_AssignedFacilities;

	@FindBy(xpath="//ejs-listview/div//span")
	private WebElement li_FacilitiesList;

	@FindBy(xpath="//button[@id='secondBtn']")
	private WebElement btn_MoveTo;

	@FindBy(xpath="//button[@id='firstBtn']")
	private WebElement btn_MoveAllTo;

	@FindBy(xpath="//button[@id='fourthBtn']")
	private WebElement btn_MoveAllFrom;

	@FindBy(xpath="//ejs-listview/div//span")
	private List<WebElement> li_AllFacilities;

	@FindBy(xpath="//button[text()='Cancel']")
	private WebElement btn_Cancel;

	@FindBy(xpath="//div[contains(@class,'addDepartment footer')]/div/button[2]")
	private WebElement btn_Save;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs; 

	@FindBy(xpath = "//ejs-textbox[@id='search_text']/span/input")
	private WebElement txt_Search;

	@FindBy(xpath="//table[@id='asgrid_content_table']/tbody")
	public WebElement grid_Results;

	@FindBy(xpath="//div[@id='panel']")
	public WebElement grid_Header;

	@FindBy(xpath="//tr[@class='e-columnheader']//child::span")
	private List<WebElement> lbl_HeaderNames;

	@FindBy(xpath="//table[@id='asgrid_content_table']/tbody/tr/td[4]/div[1]")
	private List<WebElement> lbl_Status;

	String expirDates="//table[@id='asgrid_content_table']/tbody/tr[";

	public AdministrativeDepartmentsPage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyOrganizationLevelsPanel(DataTable testData){
		try {
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			StringBuilder unmatch=new StringBuilder();
			ArrayList<String> actData=new ArrayList<String>();
			actData.add(webActions.waitAndGetText(lbl_PanelHeader, "Panel Header"));
			actData.add(webActions.waitAndGetText(lnk_AdministrativeDepartments, "Admin Depart Link"));
			actData.add(webActions.waitAndGetText(lbl_PanelText, "Panel Text"));
			actData.add(webActions.waitAndGetText(lbl_Breadcrum, "Breadcrum"));
			report.reportInfo("Actual Data: "+actData);
			report.reportInfo("Expected Data: "+expData);

			ArrayList<String> unmatchPanelData=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatchPanelData.size()==0){
				report.reportPass("Successfully verified the Panel data");
			}else{
				report.reportFail("Failed to verify the Panel data: "+unmatchPanelData, true);
				unmatch.append("Failed to verify the Panel data");
			}

			webActions.click(lbl_PanelHeader, "Panel Header");
			String actCollapse=webActions.getAttributeValue(atr_PanelExpandCollapse, "aria-expanded", "PanelExpandCollapse");

			if("true".contentEquals(actCollapse)){
				report.reportPass("Successfully Collapsed the Organization Levels panel");
			}else{
				report.reportFail("Failed to Collapse the Organization Levels panel", true);
				unmatch.append("Failed to Collapse the Organization Levels panel");
			}

			webActions.click(lbl_PanelHeader, "Panel Header");
			String actExpand=webActions.getAttributeValue(atr_PanelExpandCollapse, "aria-expanded", "PanelExpandCollapse");
			if("false".contentEquals(actExpand)){
				report.reportPass("Successfully Expanded the Organization Levels panel");
			}else{
				report.reportFail("Failed to Expand the Organization Levels panel", true);
				unmatch.append("Failed to Expanded the Organization Levels panel");
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyFieldsInAddAdministrativeDepartmentsPage(DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_AdministrativeDepartments, "Administrative Departments");
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_AddNewAdministrativeDepartment, "Add New Administrative Department");
			ArrayList<String>actData=new ArrayList<>();
			webActions.waitForVisibility(chk_Active,"Active", 10);
			actData.add(webActions.getText(chk_Active,"Active"));
			actData.addAll(webActions.getDatafromWebTable(lbl_FeildNames));
			actData.addAll(webActions.getDatafromWebTable(lbl_ListBoxNames));
			actData.addAll(webActions.getDatafromWebTable(lbl_ButtonNames));
			report.reportInfo("Actual Field  names: "+actData);
			report.reportInfo("Expected Field  names: "+expData);
			ArrayList<String> unmatchFeilds=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatchFeilds.size()==0){
				report.reportPass("Successfully verified the Field names");
			}else{
				report.reportFail("Failed to verify the Field names: "+unmatchFeilds, true);
				unmatch.append("Failed to verify the Field names");
			}

			String actStatus=webActions.getAttributeValue(chk_ActiveSwitch, "aria-checked", "ActiveSwitch");
			if("true".contentEquals(actStatus)){
				report.reportPass("Active toggle by Default is ON");
			}else{
				report.reportFail("Failed to verify Active toggle by Default is ON", true);
				unmatch.append("Failed to verify Active toggle by Default is ON");
			}

			String actEffectiveDate=webActions.getText(lbl_EffectiveDate, "EffectiveDate");
			String expEffectiveDate=webActions.getSystemCurrentDate();
			report.reportInfo("Actual Effective Date is: "+actEffectiveDate);
			if(expEffectiveDate.contentEquals(actEffectiveDate)){
				report.reportPass("Successfully verified the display by default Effective Date");
			}
			else{
				report.reportFail("Failed to verify  the display by default Effective Date", true);
				unmatch.append("Failed to verify  the display by default Effective Date");
			}

			/*String actNoRecordsFound=webActions.getText(lbl_AssignedFacilities_NoRecordsFound, "AssignedFacilities_NoRecordsFound");
			report.reportInfo("By default display message in Assigned Facilities list box: "+actNoRecordsFound);
			if("No records found".contentEquals(actNoRecordsFound)){
				report.reportPass("Successfully verified By default display message in Assigned Facilities list box");
			}
			else{
				report.reportFail("Failed to verify by default display message in Assigned Facilities list box", true);
				unmatch.append("Failed to verify by default display message in Assigned Facilities list box");
			}*/

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyMandatoryFieldValidationMessages(DataTable testData){
		try {
			ArrayList<String> expMessages=new ArrayList<String>(testData.asList());
			navigateAddAdministrativeDepartmentPage();
			webActions.click(txt_Name, "Name");
			webActions.pressTab();
			webActions.pressTab();
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			ArrayList<String> actMessages=webActions.getDatafromWebTable(lbl_MandatoryMessages);
			//actMessages.add(webActions.getText(lbl_MandatoryAssignedFacilities, "Mandatory message AssignedFacilities"));
			report.reportInfo("Actual Mandatory messages: "+actMessages);
			report.reportInfo("Expected Mandatory messages: "+expMessages);
			ArrayList<String> unmatchMessages=webActions.getUmatchedInArrayComparision(actMessages, expMessages);
			if(unmatchMessages.size()==0){
				report.reportPass("Successfully verified the Mandatory messages");
			}else{
				report.reportFail("Failed to verify the Mandatory messages: "+unmatchMessages, true);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyCancelButton(){
		try {
			navigateAddAdministrativeDepartmentPage();
			webActions.sendKeys(txt_Name, "Testing","Name");
			webActions.sendKeys(dd_Type, "Administration","Type");
			webActions.waitForPageLoaded();
			webActions.click(btn_MoveAllTo, "Move All To");
			webActions.waitForPageLoaded();
			webActions.click(btn_Cancel, "Cancel");
			webActions.waitForPageLoaded();
			String actButtonText=webActions.waitAndGetText(btn_AddNewAdministrativeDepartment, "Add New Administrative Department");
			if("Add New Administrative Department".contentEquals(actButtonText)){
				report.reportPass("Successfully verified Cancel button functionality");
			}else{
				report.reportFail("Failed to verify the Cancel button functionality");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String addAdministrativeDepartments(DataTable testData){
		String name=getDatafromMap(testData,"Name");
		name=name+"_"+webActions.getRandomString(5);
		try {
			navigateAddAdministrativeDepartmentPage();
			String status=getDatafromMap(testData,"Status");
			if("Inactive".contentEquals(status)){
				webActions.click(chk_ActiveSwitch, "Active Switch");
				webActions.waitForPageLoaded();
			}
			webActions.sendKeys(txt_Name, name,"Name");
			webActions.sendKeys(dd_Type, getDatafromMap(testData,"Type"),"Type");
			webActions.waitForPageLoaded();
			webActions.sendKeys(searchtxt_AssignedFacilities, getDatafromMap(testData,"Facility"),"Assigned Facilities");
			webActions.click(li_FacilitiesList, "Facilities List");
			webActions.click(btn_MoveTo, "Move To");
			webActions.waitForPageLoaded();
			webActions.click(btn_Save, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle = titleContent[0];
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			String expMessage=getDatafromMap(testData,"Message");
			report.reportInfo("Expected alert message: "+expMessage);
			report.reportInfo("Newly created Administrative Department: "+name);
			if(expMessage.contains(actContent)){
				report.reportPass("Successfully created Administrative Department");
			}else{
				report.reportFail("Failed to create Administrative Department: "+actContent);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
		return name;
	}

	public void searchAdministrativeDepartments(String adminDepName){
		try {
			webActions.waitForPageLoaded();
			webActions.click(txt_Search, "Search");
			webActions.sendKeys(txt_Search, adminDepName,"Search");
			ArrayList<String> actData=webActions.getDataFromResultsGrid(grid_Header,grid_Results,"Name","div");
			report.reportInfo("Actual Data: "+actData);
			report.reportInfo("Expected Data: "+adminDepName);
			ArrayList<String>unMatchData=webActions.isFullArrayMatchWithData(actData,adminDepName);
			if(unMatchData.size()==0){
				report.reportPass("Successfully verified the data");
			}else{
				report.reportFail("Failed to verify the data: "+unMatchData);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void addAdministrativeDepartmentandVerifytheData(DataTable testData){
		try {
			String name=addAdministrativeDepartments(testData);
			searchAdministrativeDepartments(name);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String addAdministrativeDepartmentswithAllFacilities(DataTable testData){
		String name=getDatafromMap(testData,"Name");
		name=name+"_"+webActions.getRandomString(5);
		try {
			navigateAddAdministrativeDepartmentPage();
			String status=getDatafromMap(testData,"Status");
			if("Inactive".contentEquals(status)){
				webActions.click(chk_ActiveSwitch, "Active Switch");
			}
			webActions.sendKeys(txt_Name, name,"Name");
			webActions.sendKeys(dd_Type, getDatafromMap(testData,"Type"),"Type");
			webActions.waitForPageLoaded();
			webActions.click(btn_MoveAllTo, "Move All To");
			webActions.waitForPageLoaded();
			webActions.click(btn_Save, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle = titleContent[0];
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			String expMessage=getDatafromMap(testData,"Message");
			report.reportInfo("Expected alert message: "+expMessage);
			report.reportInfo("Newly created Administrative Department: "+name);
			if(expMessage.contains(actContent)){
				report.reportPass("Successfully created Administrative Department");
			}else{
				report.reportFail("Failed to create Administrative Department: "+actContent);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
		return name;
	}

	public void addAdministrativeDepartmentwithAllFacilitiesandVerifytheData(DataTable testData){
		try {
			String name=addAdministrativeDepartmentswithAllFacilities(testData);
			searchAdministrativeDepartments(name);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void navigateAddAdministrativeDepartmentPage(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_AdministrativeDepartments, "Administrative Departments");
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_AddNewAdministrativeDepartment, "Add New Administrative Department");
			webActions.waitForVisibilityOfAllElements(li_AllFacilities, "All Facilities");
		} catch (Exception e) {
		}
	}

	public void navigateAdministrativeDepartmentPage(){
		try {
			webActions.waitAndClick(lnk_AdministrativeDepartments, "Administrative Departments");
			webActions.waitForVisibilityOfAllElements(lbl_HeaderNames, "HeaderNames");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
		}
	}

	public void verifyHeaderNames(DataTable headerNames){
		try {
			ArrayList<String>expHeaderNames=new ArrayList<String>(headerNames.asList());
			ArrayList<String>actHeaderNames=webActions.getDatafromWebTable(lbl_HeaderNames);
			report.reportInfo("Actual Header Names in Default Search: "+actHeaderNames);
			ArrayList<String> unmatchedHeaderNames=webActions.getUmatchedInArrayComparision(actHeaderNames,expHeaderNames);
			if(unmatchedHeaderNames.size()==0){
				report.reportPass("Verified Header Names in Administrative Departments page successfully");
			}
			else{
				report.reportFail("Fail to verify Header Names in Administrative Departments page and unmatched Names are: "+unmatchedHeaderNames);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void searchAdministrativeDepartmentsGridData(String status){
		try {
			webActions.waitForPageLoaded();
			List<WebElement> allElement = lbl_Status;
			if ("Active".contentEquals(status)) {
				for (WebElement we : allElement) {
					String statusName = we.getText();
					String statusColour = we.getAttribute("class");
					if ("Active".contentEquals(statusName)) {
						report.reportInfo("Administrative Department status is: "+statusName);
						report.reportInfo("Administrative Department status colouris : "+statusColour);
						if (!statusColour.contains("green")) {
							report.reportFail("Active status verification failed");
						}
					} 
				} 
			}else if("Inactive".contentEquals(status)){
				for (WebElement we : allElement) {
					String statusName = we.getText();
					String statusColour = we.getAttribute("class");
					if ("Inactive".contentEquals(statusName)) {
						report.reportInfo("Administrative Department status is: "+statusName);
						report.reportInfo("Administrative Department status colouris : "+statusColour);
						if (!statusColour.contains("red")) {
							report.reportFail("Inactive status verification failed");
						}
					}
				}
			}
			report.reportPass("Successfully verified the "+status+" Administrative Departments");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyEffectiveAndExpirationDates(String status){
		try {
			webActions.waitForPageLoaded();
			List<WebElement> allElement = lbl_Status;
			int rows=allElement.size();
			for (int i = 1; i <=rows; i++) {
				String stausName=driver.findElement(By.xpath(expirDates+i+"]/td[4]/div[1]")).getText();
				if(stausName.contentEquals(status)){
					String dates=driver.findElement(By.xpath(expirDates+i+"]/td[4]/div[2]")).getText();
					String[] dateText;
					String effectiveDate;
					String expirationDate;
					try {
						dateText = dates.split("-");
						effectiveDate=dateText[0].trim();
						expirationDate=dateText[1].trim();
					} catch (Exception e) {
						report.reportFail("Expiration Date is not available for Inactive records");
						throw new Exception("Expiration Date is not available for Inactive records");
					}

					report.reportInfo("Dates are: "+dates);
					if(!effectiveDate.contains(expirationDate)){
						report.reportFail("Effective and Expiration Dates is not matched for Inactive Administrative Departments");
					}
				}
			}
			report.reportPass("Successfully verified Effective and Expiration Dates for "+status+" Administrative Departments");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}



	public String getTagName(String columnName){
		String tagName="";
		if("Tenant Name".contentEquals(columnName)){
			tagName="a";
		}
		else {
			tagName="div";
		}
		return tagName;
	}




	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(lnk_AdministrativeDepartments);
	}

}
