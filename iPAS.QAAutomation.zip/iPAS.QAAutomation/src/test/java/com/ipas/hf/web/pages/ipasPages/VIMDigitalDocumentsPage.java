package com.ipas.hf.web.pages.ipasPages;

import java.awt.HeadlessException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class VIMDigitalDocumentsPage extends BasePage{	


	@FindBy(xpath = "//p[contains(text(),'Complete documents')]")
	private WebElement lnk_CompleteDocuments;

	@FindBy(xpath = "//p[contains(text(),'Complete documents')]/../p[2]")
	private WebElement lbl_CompleteDocumentsCountMainPage;

	@FindBy(xpath = "//span[contains(text(),'Complete Forms')]")
	private WebElement lnk_CompleteForms;

	@FindBy(xpath = "//div[contains(text(),'Patient Bill of Rights')]")
	private WebElement lnk_PatientBillofRights;

	@FindBy(xpath = "//div[contains(text(),'Patient Bill of Rights')]/img")
	private WebElement img_PatientBillofRights;

	@FindBy(xpath = "//div[text()=' iPAS Patient Visit Form ']")
	private WebElement lnk_iPASPatientVisitForm;

	@FindBy(xpath = "//div[text()=' iPAS Patient Visit Form ']/img")
	private WebElement img_iPASPatientVisitForm;

	@FindBy(xpath = "//div[contains(text(),'DEV TEST iPAS Patient Visit Form')]")
	private WebElement lnk_DEVTESTiPASPatientVisitForm;

	@FindBy(xpath = "(//div[contains(text(),'DEV TEST iPAS Patient Visit Form')]/img)[2]")
	private WebElement img_DEVTESTiPASPatientVisitForm;

	@FindBy(xpath = "//div[contains(text(),'Pre-Registration')]")
	private WebElement lnk_PreRegistration;

	@FindBy(xpath = "//div[contains(text(),'Pre-Registration')]/img")
	private WebElement img_PreRegistration;

	@FindBy(xpath = "//div[contains(text(),'General Pain and Medical History')]")
	private WebElement lnk_GeneralPainMedicalHistory;

	@FindBy(xpath = "//div[contains(text(),'General Pain and Medical History')]/img")
	private WebElement img_GeneralPainMedicalHistory;

	@FindBy(xpath = "//div[contains(text(),'Conditions of Admission')]")
	private WebElement lnk_ConditionsofAdmission;

	@FindBy(xpath = "//div[contains(text(),'Conditions of Admission')]/img")
	private WebElement img_ConditionsofAdmission;	

	@FindBy(xpath = "//div[text()=' iPAS Patient Form ']")
	private WebElement lnk_iPASPatientForm;

	@FindBy(xpath = "//div[text()=' iPAS Patient Form ']/img")
	private WebElement img_iPASPatientForm;

	@FindBy(xpath = "//div[contains(text(),'DEV TEST iPAS Patient Form')]")
	private WebElement lnk_DEVTESTiPASPatientForm;

	@FindBy(xpath = "//div[contains(text(),'DEV TEST iPAS Patient Form')]/img")
	private WebElement img_DEVTESTiPASPatientForm;

	@FindBy(xpath = "//div[contains(text(),'Patient Registration Test Form')]")
	private WebElement lnk_PatientRegistrationTestForm;

	@FindBy(xpath = "//div[contains(text(),'Patient Registration Test Form')]/img")
	private WebElement img_PatientRegistrationTestForm;

	@FindBy(xpath ="//button[@type='submit']")
	private WebElement btn_Submit;

	@FindBy(xpath = "//span[contains(text(),'Complete Documents')]")
	private WebElement lnk_CompleteDocumentsFromForms;

	@FindBy(xpath = "//p[contains(text(),'Complete documents')]/../p[2]")
	private WebElement lbl_CompleteDocumentsCount_Home;

	@FindBy(xpath = "//p[text()='iPAS Patient Visit Form']/../img")
	private WebElement img_iPASPatientVisitFormHome;

	@FindBy(xpath = "//p[text()='iPAS Patient Form']/../img")
	private WebElement img_iPASPatientFormHome;	

	@FindBy(xpath = "//span[text()='iPAS Patient Form']")
	private WebElement lnk_iPASPatientFormFromiPAS;

	@FindBy(xpath = "//span[text()='iPAS Patient Form']//following::img[1]")
	private WebElement img_iPASPatientFormStatusFromiPAS;

	@FindBy(xpath = "(//div[@id='three']//app-ipas-document-management-pannel/div/ejs-accordion/div/div[2]/div/div/ul/li/div[2])[2]")
	private WebElement lbl_DDShortPanelFormCount;

	@FindBy(xpath = "(//div[@id='three']//app-ipas-document-management-pannel/div/ejs-accordion/div/div[2]/div/div/ul/li/div[2])[1]")
	private WebElement lbl_DDShortPanelDocumentCount;

	@FindBy(xpath = "//h3[contains(text(),'Are you sure to stop completing the form?')]")
	private WebElement lbl_UnsavedPopUpMsgVIM;

	@FindBy(xpath = "//p[contains(text(),'Any unsaved progress will be lost.')]")
	private WebElement lbl_UnsavedPopUpMsg1VIM;

	@FindBy(xpath = "//a[contains(text(),'Back to form')]")
	private WebElement btn_UnsavedPopUpMsgVIMBack;

	@FindBy(xpath = "//a[contains(text(),'STOP')]")
	private WebElement btn_UnsavedPopUpMsgVIMStop;

	@FindBy(xpath = "//a[contains(text(),'Edit')]")
	private WebElement btn_FormEdit;

	@FindBy(xpath = "//input[@name='q12_PatEmail']")
	private WebElement txt_PatientEmail;

	@FindBy(xpath = "//span[contains(text(),'PatEmail')]/../span[contains(text(),'@gmail.com')]")
	private WebElement lbl_PatientEmailFromPDFiPAS;

	@FindBy(xpath="//button[text()='Change Status']")
	private WebElement btn_ChangeStatus;

	@FindBy(xpath="//div[@ id='document-viewer-section']/div[1]/span/img")
	private WebElement lbl_DocsAndFormsStatus;

	@FindBy(xpath="//div[@id='detail-document-table']/div[1]//div[@class='e-list-item-header']/span/img")
	private WebElement lbl_DocsAndFormsStatusInPage;

	@FindBy(xpath="//select[@id='status']")
	private WebElement dd_Status;

	@FindBy(xpath="//button[@class='btn btn-light btn-xs'][(text()='Change Status')]")
	private WebElement btn_ChangeStatus_Popup;

	@FindBy(xpath="//span[contains(text(),'Physicians Order')]//following::img[1]")
	private WebElement img_PhysicianOrder;

	@FindBy(xpath="//span[contains(text(),'Photo Id')]//following::img[1]")
	private WebElement img_PhotoId;

	@FindBy(xpath="//span[contains(text(),'Insurance Card')]//following::img[1]")
	private WebElement img_InsuranceCard;

	/*@FindBy(xpath = "//p[normalize-space()='Complete documents']")
	private WebElement lnk_CompleteDocuments;*/

	@FindBy(xpath = "//div[contains(text(),'Physicians Order')]")
	private WebElement lnk_PhysiciansOrder;

	@FindBy(xpath = "//p[contains(text(),'Click here to upload file')]")
	private WebElement btn_ClickHereToUploadFile;

	@FindBy(xpath ="//mat-dialog-container//app-information-dialog/h3")
	private WebElement lbl_SuccessMessage;

	@FindBy(xpath = "//a[contains(text(),'OK')]")
	private WebElement btn_OK;

	@FindBy(xpath = "//div[contains(text(),'Physicians Order')]/img")
	private WebElement img_PhysiciansOrderVIM;

	@FindBy(xpath ="//p[contains(text(),'Please upload PNG, JPG or JPEG format file.')]")
	private WebElement lbl_UnsupporttedErrorMessage;

	@FindBy(xpath ="//mat-checkbox//label/div")
	private WebElement chk_DOcument;
	@FindBy(xpath = "//a[contains(text(),'Confirm')]")
	private WebElement btn_Confirm; 	
	@FindBy(xpath = "//span[(text()='Upload Documents')]/../p[2]")
	private WebElement lbl_UploadDocumentsCount;

	@FindBy(xpath = "//span[contains(text(),'Complete Documents')]/../p")
	private WebElement lbl_CompleteDocumentsCount;

	@FindBy(xpath = "//a[contains(text(),'Delete')]")
	private WebElement btn_Delete;

	@FindBy(xpath = "//h3[contains(text(),'Are you sure you want to delete file.')]")
	private WebElement lbl_DeleteMsg;

	@FindBy(xpath = "//a[contains(text(),'Cancel')]")
	private WebElement btn_DeleteCancel;

	@FindBy(xpath = "//a[contains(text(),'OK')]")
	private WebElement btn_DeleteOk;



	public void submitFormAndVerify(String form){
		try {
			webActions.waitAndClick(lnk_CompleteDocuments, "completeDocuments");
			webActions.waitForPageLoaded();
			Thread.sleep(5000);
			if("iPASPatientForm".contentEquals(form)){
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(lnk_iPASPatientForm, "patientVisitForm");
				webActions.waitAndClick(lnk_iPASPatientForm, "patientVisitForm");
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				driver.switchTo().frame(0);
				webActions.waitForPageLoaded();
				webActions.scrollBarHandle(btn_Submit, "Submit");
				Thread.sleep(5000);
				webActions.waitAndClick(btn_Submit, "submit");
				webActions.waitForPageLoaded();
				Thread.sleep(15000);
				driver.switchTo().parentFrame();
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(lnk_iPASPatientForm, "patientVisitForm");
				webActions.waitForPageLoaded();
				String status=webActions.getAttributeValue(img_iPASPatientForm, "src", "VisitformStatus");
				if(status.contentEquals("https://qa.myvim.com/assets/svg/success-filled.svg")){
					report.reportPass("Successfully verified the iPAS Patient Visit Form status");
				}
				else{
					report.reportFail("Fail to verify the iPAS Patient Visit Form status and displayed status is : " + status);
				}
			}
			else {

			}			

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyCompleteDocumentsCount(String count){
		try {
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_CompleteDocumentsFromForms, "CompleteForms");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lnk_CompleteDocuments, "CompleteDocuments");
			Thread.sleep(5000);
			String actDocumentsCountinHome=webActions.waitAndGetText(lbl_CompleteDocumentsCount_Home, "Complete Documents Count_Home");
			report.reportInfo("Actual documents count in Complete Documents section in Home:"+actDocumentsCountinHome);
			if(actDocumentsCountinHome.contains(count)){
				report.reportPass("Successfully verified the Complete Documents count section in Home page");
			}else{
				report.reportFail("Fail to verify the Complete Documents count in Home page: "+actDocumentsCountinHome);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyFormStatusHome(String form){
		try {
			webActions.waitForPageLoaded();
			if("iPASPatientForm".contentEquals(form)){
				String status=webActions.getAttributeValue(img_iPASPatientFormHome, "src", "VisitformStatus");
				if(status.contentEquals("https://qa.myvim.com/assets/svg/success-filled.svg")){
					report.reportPass("Successfully verified the iPAS Patient Visit Form status");
				}
				else{
					report.reportFail("Fail to verify the iPAS Patient Visit Form status and displayed status is : " + status);
				}
			}
			else{

			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyCountFromDDShortPanel(String count){
		try {
			webActions.waitForPageLoaded();
			String actShortPanelFormCount=webActions.getText(lbl_DDShortPanelFormCount, "FormCOunt");
			if(actShortPanelFormCount.contentEquals(count)){
				report.reportPass("Successfully verified the completed form count from short panel");
			}
			else{
				report.reportFail("Fail to verify the completed form count and actual form count is : " +actShortPanelFormCount);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyStatusFromDDPanel(String form){
		try {
			String status="";
			webActions.waitForPageLoaded();
			if("iPASPatientForm".contentEquals(form)){
				status=webActions.getAttributeValue(img_iPASPatientFormStatusFromiPAS, "src", "status");
			}
			else{

			}
			if(status.contains("assets/images/success.png")){
				report.reportPass("successfully verified the submitted form status");
			}
			else{
				report.reportFail("Fail to verify the submitted form status and displayed is : " + status);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}
	public void verifyUnsavedPopUp(){
		try {
			webActions.waitAndClick(lnk_CompleteDocuments, "completeDocuments");
			webActions.waitForPageLoaded();
			Thread.sleep(5000);
			webActions.waitForVisibility(lnk_iPASPatientForm, "patientVisitForm");
			webActions.waitAndClick(lnk_iPASPatientForm, "patientVisitForm");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(lnk_CompleteDocumentsFromForms, "completeDocs");
			String msg=webActions.waitAndGetText(lbl_UnsavedPopUpMsgVIM, "MSG");
			String msg1=webActions.waitAndGetText(lbl_UnsavedPopUpMsg1VIM, "MSG");
			if("Are you sure to stop completing the form?".contentEquals(msg.trim())&& "Any unsaved progress will be lost.".contentEquals(msg1.trim())){
				report.reportPass("Successfully verified the unsaved popup");
			}
			else{
				report.reportFail("Fail to verify the unsaved popup message and displayed is :" + msg+" "+msg1,true);
			}
			webActions.clickAction(btn_UnsavedPopUpMsgVIMBack, "BackBtn");
			webActions.waitForPageLoaded();
			boolean flag=webActions.isDisplayed(lnk_CompleteDocumentsFromForms, "Forms");
			webActions.click(lnk_CompleteDocumentsFromForms, "completeDocs");
			webActions.clickAction(btn_UnsavedPopUpMsgVIMStop, "StopBtn");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lnk_iPASPatientForm, "patientVisitForm");
			boolean flag1=webActions.isDisplayed(lnk_CompleteForms, "completeForms");

			if(flag && flag1){
				report.reportPass("Successfully verified the popup Actions");
			}
			else{
				report.reportFail("Fail to verify unsaved popup actions");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void editAndSubmitTheForm(String form){
		try {
			String mail=webActions.getRandomString(6);
			String patientemail=mail+"@gmail.com";
			webActions.notepadWrite("hello", patientemail);
			webActions.waitForPageLoaded();
			if("iPASPatientForm".contentEquals(form)){
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(lnk_iPASPatientForm, "patientVisitForm");
				webActions.waitAndClick(lnk_iPASPatientForm, "patientVisitForm");
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.waitAndClick(btn_FormEdit, "editbtn");
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				Thread.sleep(5000);
				driver.switchTo().frame(0);
				webActions.waitForPageLoaded();
				webActions.clearValueAndSendKeys(txt_PatientEmail, patientemail, "patientemail");
				webActions.scrollBarHandle(btn_Submit, "Submit");
				Thread.sleep(5000);
				webActions.waitAndClick(btn_Submit, "submit");
				webActions.waitForPageLoaded();
				Thread.sleep(15000);
				driver.switchTo().parentFrame();
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(lnk_iPASPatientForm, "patientVisitForm");
				webActions.waitForPageLoaded();
				String status=webActions.getAttributeValue(img_iPASPatientForm, "src", "VisitformStatus");
				if(status.contentEquals("https://qa.myvim.com/assets/svg/success-filled.svg")){
					report.reportPass("Successfully verified the iPAS Patient Visit Form status");
				}
				else{
					report.reportFail("Fail to verify the iPAS Patient Visit Form status and displayed status is : " + status);
				}
			}
			else{

			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyUpdatedDataFromForm(String form){
		try {
			webActions.waitForPageLoaded();
			if("iPASPatientForm".contentEquals(form)){
				webActions.click(lnk_iPASPatientForm, "patientform");
				webActions.waitForPageLoaded();
				Thread.sleep(5000);
				driver.switchTo().frame(0);
				webActions.waitForPageLoaded();
				String actemail=webActions.getText(lbl_PatientEmailFromPDFiPAS, "email");
				String expEmail=webActions.notepadRead("hello").trim();
				if(expEmail.contentEquals(actemail)){
					report.reportPass("Successfully verified the iupdated data from form");
				}
				else{
					report.reportFail("Fail to verify the updated data from form and displayed data is : " + actemail);
				}
			}
			else{

			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void clickOnCompleteDocLink(){
		try {
			webActions.waitAndClick(lnk_CompleteDocuments, "completeDocuments");
			webActions.waitForPageLoaded();
			Thread.sleep(5000);			
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lnk_iPASPatientForm, "patientVisitForm");

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void changeFormStatus(String form){
		try {
			if("iPASPatientForm".contentEquals(form)){
				webActions.clickAction(lnk_iPASPatientFormFromiPAS, "Patientform");
			}
			else{

			}
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_ChangeStatus, "ChangeStatus");
			webActions.waitAndClick(btn_ChangeStatus, "ChangeStatus");
			Thread.sleep(5000);
			webActions.selectByVisibleText(dd_Status, "Complete", "Status Dropdown");
			Thread.sleep(5000);
			webActions.waitAndClick(btn_ChangeStatus_Popup, "Change Status Popup");
			Thread.sleep(10000);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyDocumentCountFromDDShortPanel(String count){
		try {
			webActions.waitForPageLoaded();
			String actShortPanelFormCount=webActions.getText(lbl_DDShortPanelDocumentCount, "DocuemntCOunt");
			if(actShortPanelFormCount.contentEquals(count)){
				report.reportPass("Successfully verified the completed document count from short panel");
			}
			else{
				report.reportFail("Fail to verify the completed document count and actual form count is : " +actShortPanelFormCount);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyUploadedDocumentsStatusiPAS(){
		try {
			ArrayList<String> status=new ArrayList<>();
			webActions.waitForPageLoaded();
			status.add(webActions.getAttributeValue(img_PhysicianOrder, "src", "physician"));
			status.add(webActions.getAttributeValue(img_PhotoId, "src", "photoId"));
			status.add(webActions.getAttributeValue(img_InsuranceCard, "src", "InsuarnceCard"));

			ArrayList<String> unmatchdata=webActions.isFullArrayMatchWithData(status, "assets/images/success.png");
			if(unmatchdata.size()==0){
				report.reportPass("Successfully verified the uploaded documents status from iPAS");
			}
			else{
				throw new Exception("Fail to verify uploaded documents status from iPAS and unmatched fields are: "+unmatchdata);
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void setClipboardData(String fileName) {
		try {
			fileName=System.getProperty("user.dir")+"\\UploadDocuments\\"+fileName;
			StringSelection fileSelection = new StringSelection(fileName);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(fileSelection, fileSelection);
		} catch (HeadlessException e) {
			e.printStackTrace();
		}
	}

	public void uploadFile(String fileName) {
		try {
			setClipboardData(fileName);
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			Thread.sleep(3000);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			Thread.sleep(3000);
			robot.keyRelease(KeyEvent.VK_ENTER);
		} catch (Exception exp) {
			exp.printStackTrace();
		}
	}
	public void uploadPhysiciansOrderUnsupportedFile(String fileName,String expErrorMessage) throws Exception{
		try {

			webActions.waitAndClick(lnk_CompleteDocuments, "Complete Documents");
			webActions.waitForVisibility(lnk_PhysiciansOrder, "Physicians Order");
			webActions.waitAndClick(lnk_PhysiciansOrder, "Physicians Order");
			webActions.waitAndClick(btn_ClickHereToUploadFile, "Click Here To Upload File");
			Thread.sleep(5000);
			uploadFile(fileName);		
			webActions.waitForVisibility(lbl_UnsupporttedErrorMessage, "Error Message");
			String actErrorMessage=webActions.waitAndGetText(lbl_UnsupporttedErrorMessage, "Error Message");
			if(expErrorMessage.contentEquals(actErrorMessage)){
				report.reportPass("Successfully verified the message when trying to upload the invalid format file Physicians Order: "+actErrorMessage);
			}else{
				report.reportFail("Fail to verify the message after upload the unsupportted format Physicians Order: "+actErrorMessage);
			}	

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void uploadUnsupportedDocuments(DataTable testData){
		try {
			ArrayList<String>data=new ArrayList<>(testData.asList());
			uploadPhysiciansOrderUnsupportedFile(data.get(0),data.get(1));			
		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}
	public void confirmDocuemntsWithoutUpload(String expStatus, String count){
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.waitAndClick(lnk_CompleteDocuments, "Complete Documents");
			webActions.waitForVisibility(lnk_PhysiciansOrder, "Physicians Order");
			webActions.waitAndClick(lnk_PhysiciansOrder, "Physicians Order");
			webActions.waitForPageLoaded();			
			webActions.waitAndClick(chk_DOcument, "chkBox");
			Thread.sleep(3000);
			webActions.waitAndClick(btn_Confirm, "confirm");
			webActions.waitForPageLoaded();
			Thread.sleep(5000);
			webActions.waitForVisibility(img_PhysiciansOrderVIM, "Physicians Order");
			String actStatus=webActions.getAttributeValue(img_PhysiciansOrderVIM, "src", "Physicians Order Status");
			if(actStatus.contains(expStatus)){
				report.reportPass("Successfully verified the status after confirm the Physicians Order");
			}else{				
				report.reportFail("Fail to verify the status after confirm the Physicians Order " +actStatus,true);
			}		
			String actCount=webActions.waitAndGetText(lbl_UploadDocumentsCount, "UploadDocumentsCount");
			Thread.sleep(3000);
			webActions.waitForPageLoaded();
			if(count.contentEquals(actCount)){
				report.reportPass("Successfully verified the Uploaded documents count: "+actCount);
			}else{
				unmatch.append("Fail to verify the Uploaded documents count: "+actCount);
				report.reportFail("Fail to verify the Uploaded documents count: "+actCount,true);
			}
			String actCompleteDocumentsCount=webActions.waitAndGetText(lbl_CompleteDocumentsCount, "Complete Documents Count");

			if(actCompleteDocumentsCount.contains("1")){
				report.reportPass("Successfully verified the Uploaded documents count in Complete Documents section: "+actCompleteDocumentsCount);
			}else{
				unmatch.append("Fail to verify the Uploaded documents count in Complete Documents section: "+actCompleteDocumentsCount);
				report.reportFail("Fail to verify the Uploaded documents count in Complete Documents section: "+actCompleteDocumentsCount,true);
			}

			webActions.click(lbl_CompleteDocumentsCount, "Complete Documents Count");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String actDocumentsCountinHome=webActions.waitAndGetText(lbl_CompleteDocumentsCount_Home, "Complete Documents Count_Home");
			report.reportInfo("Actual documents count in Complete Documents section in Home:"+actDocumentsCountinHome);
			if(actDocumentsCountinHome.contains("1")){
				report.reportPass("Successfully verified the Uploaded documents count in Complete Documents section in Home page: "+actCompleteDocumentsCount);
			}else{
				unmatch.append("Fail to verify the Uploaded documents count in Complete Documents section in Home page: "+actCompleteDocumentsCount);
				report.reportFail("Fail to verify the Uploaded documents count in Complete Documents section in Home page: "+actCompleteDocumentsCount);
			}
			if(unmatch.length()==0){
				report.reportPass("Successfully verified the Uploaded documents count in all sections");
			}else{
				throw new Exception("Fail to verify the Uploaded documents count in all sections: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void deleteUploadDocumentAndVerify(String document){
		try {
			if("physician".contentEquals(document)){
				webActions.waitForVisibility(lnk_PhysiciansOrder, "Physicians Order");
				webActions.waitAndClick(lnk_PhysiciansOrder, "Physicians Order");
				webActions.waitForPageLoaded();
			}
			else{

			}
			webActions.waitAndClick(btn_Delete, "deleteBtn");
			webActions.waitForPageLoaded();
			String actDelMsg=webActions.waitAndGetText(lbl_DeleteMsg, "DeleteMsg").trim();
			if(actDelMsg.contentEquals("Are you sure you want to delete file."))
			{
				report.reportPass("Successfully verify teh delete popup message");
			}
			else{
				report.reportFail("Fail to verify the delete pop-up message and actual msg : "+actDelMsg);
			}
			webActions.clickAction(btn_DeleteCancel, "cancel");
			webActions.waitForVisibility(btn_Delete, "delete");
			webActions.waitAndClick(btn_Delete, "deleteBtn");
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_DeleteOk, "OK");
			Thread.sleep(3000);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyDocumentStatusAndCount(String status, String count){
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(img_PhysiciansOrderVIM, "order");
			String actStatus=webActions.getAttributeValue(img_PhysiciansOrderVIM, "src", "physicianImg");
			if(status.contains(actStatus)){
				report.reportPass("Successfully verify the physicianorder status");
			}
			else{
				unmatch.append("Fail to verify the physicianorder status "+actStatus);
				report.reportFail("Fail to verify the physicianorder status"+actStatus,true);
			}
			String actCount=webActions.waitAndGetText(lbl_UploadDocumentsCount, "UploadDocumentsCount");
			if(actCount.contains(actCount)){
				report.reportPass("Successfully verify the document count");
			}
			else{
				unmatch.append("Fail to verify the upload  document count "+actCount);
				report.reportFail("Fail to verify the upload  document count"+actCount,true);
			}
			if(unmatch.length()==0){
				report.reportPass("Successfully verified the Uploaded documents status and count");
			}else{
				throw new Exception("Fail to verify the Uploaded documents status and count: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyDeletedDocumentsStatusiPAS(String document){
		try {
			String  status="";
			webActions.waitForPageLoaded();
			if("physician".contentEquals(document)){
				status=webActions.getAttributeValue(img_PhysicianOrder, "src", "physician");
			}		
			else{
				
			}
			if(status.contains("error")){
				report.reportPass("Successfully verified the deleted documents status from iPAS");
			}
			else{
				throw new Exception("Fail to verify deleted documents status from iPAS and unmatched status: "+status);
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public VIMDigitalDocumentsPage() {
		PageFactory.initElements(driver, this);
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
