package com.ipas.hf.web.pages.ipasPages;


import java.awt.AWTException;
import java.awt.HeadlessException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.time.DateUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.akiban.sql.parser.DDLStatementNode;
import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class PaymentFacilitatorPage extends BasePage {

	private JSONObject jsonObject;
	private static final String PAYMENTFACILITATOR = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\PaymentFacilitator.json";
	private StepLogging log = StepLogging.getLoggingObject();

	@FindBy(xpath = "//a[@class='breadcrum']")
	private WebElement lnk_AccountSearch;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr/td")
	private WebElement tbl_AccountSearchData;

	@FindBy(xpath = "//input[@placeholder='Type Account ID/Patient Name']")
	public WebElement txt_Search;

	@FindBy(xpath = "//ejs-textbox[@id='search_text']//input")
	private WebElement txt_Search_ST;

	//ul[@id='searchcomp_options']/li
	@FindBy(xpath="//li[@id='p-highlighted-option']")
	private WebElement li_Search;

	@FindBy(xpath="//div[@class='e-gridcontent']//td[2]/div/a")
	private WebElement lnk_AccountNumber;

	@FindBy(xpath="//span[@class='breadcrum-active ng-star-inserted']")
	private WebElement lbl_AccountNumber;

	@FindBy(xpath="//a[contains(text(),'Account Search')]")
	private WebElement lnk_AccountSearch_Home;

	@FindBy(xpath="//a[@class='breadcrum']")
	private WebElement lbl_Breadcrum_Service;

	@FindBy(xpath="//span[@class='breadcrum-active']")
	private WebElement lbl_Breadcrum_VisitNumber;

	@FindBy(xpath="//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']")
	private WebElement lbl_Headers;

	@FindBy(xpath="//table[@class='e-table']//thead/tr/th")
	private WebElement lbl_Headers_AS;

	@FindBy(xpath="//table[@id='asgrid_content_table']/tbody/tr[1]/td[10]/div/a")
	public WebElement lnk_NeedsAttention;

	@FindBy(xpath="//div[@class='modal-body row']/div/ul")
	private WebElement tbl_AllModules;
	
	@FindBy(xpath="//a[contains(text(),'Payment Facilitator')]")
	private WebElement lnk_PaymentFacilitator_AllModules;
	
	@FindBy(xpath="//all-data-panels/div[2]/ejs-dashboardlayout/div")
	private List<WebElement> tbl_AllPanel;

	@FindBy(xpath="//div[@class='pasentDetails']/ul")
	private WebElement tbl_PatientVisitSummary;

	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[2]")
	private List<WebElement> lbl_PatientVisitSummary;

	@FindBy(xpath="//div[@class='breadcrum-container noprint']/span")
	public List<WebElement> lbl_Breadcrum;

	@FindBy(xpath="//ipas-payment-facilitator-pannel/div/ejs-accordion/div")
	private WebElement tbl_PaymentFacilitatorPanel;

	@FindBy(xpath="//ipas-payment-facilitator-pannel/div/ejs-accordion/div/div[2]//span")
	private WebElement lbl_NoPayments;

	@FindBy(linkText="Payment Facilitator")
	public WebElement lnk_PaymentFacilitator;

	@FindBy(xpath="//div[@class='currentVisit-title']")
	private WebElement lbl_CurrentVisitTitle;

	@FindBy(xpath="//div[@class='historical-title']")
	private WebElement lbl_HistoricalBalanceTitle;

	@FindBy(xpath="//div[@class='currentVisit-title']/span/span[2]")
	private WebElement lbl_CurrentVisitAmount;

	@FindBy(xpath="//div[@class='historical-title']/span/span")
	private WebElement lbl_HistoricalBalanceAmount;

	@FindBy(xpath="//ejs-grid[@id='discount-grid']//child::th//span")
	private List<WebElement> lbl_CurrentVisitFeilds;

	@FindBy(xpath="//ejs-grid[@id='historical-visit-grid']//child::th//span")
	private List<WebElement> lbl_HistoricalBalanceFeilds;

	@FindBy(xpath="//ejs-dropdownlist[@id='payment-type-dropdown']/span/input")
	public WebElement dd_PaymentType;

	@FindBy(xpath="//img[@class='notify-img img-style']")
	private WebElement img_FinancialClearanceStatusPaymentFacilitatorPage;

	@FindBy(xpath="//table[@id='discount-grid_content_table']/tbody/tr/td[3]/ejs-numerictextbox/span/input")
	public WebElement txt_TotalAmount;

	@FindBy(xpath="//ejs-dropdownlist[contains(@id,'ej2_dropdownlist')]/span")
	private WebElement dd_Discount;

	@FindBy(xpath="//table[@id='discount-grid_content_table']/tbody/tr/td[5]/div")
	public WebElement txt_AdjustedAmount;

	@FindBy(xpath="//table[@id='discount-grid_content_table']/tbody/tr/td[6]/div")
	public WebElement txt_Paid;

	@FindBy(xpath="//table[@id='discount-grid_content_table']/tbody/tr/td[7]/div")
	public WebElement txt_RemainingBalance;

	@FindBy(xpath="//button[(text()='Calculate')]")
	private WebElement btn_Calculate;

	@FindBy(xpath="//button[(text()='Save')]")
	private WebElement btn_Save;

	@FindBy(xpath="//button[text()='Initiate Payment']")
	private WebElement btn_InitiatePayment;

	@FindBy(xpath="//ejs-dropdownlist[@id='paymentMethodLookup']/span/input")
	private WebElement dd_PaymentMethod;

	@FindBy(xpath="//div[@id='updatepatientvisit']/div/div/div[2]/form/div/div[2]/div/input")
	private WebElement txt_PaymentMemo;

	@FindBy(xpath="//div[@class='collectPaymentModal modal-header']/h4/span")
	private WebElement lbl_PaymentAmount_CollectPaymentModal;

	@FindBy(xpath="//td[@class='col-md-4']/div")
	private List<WebElement> lbl_AccountandPaymentCollectPaymentModal;

	String lbl_CollectPaymentModal="//div[@class='collectPaymentModal modal-dialog w-500']//child::form//child::";

	@FindBy(xpath="//button[contains(text(),'Collect Payment')]")
	private WebElement btn_CollectPayment;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;

	@FindBy(xpath = "//table[@id='discount-grid_content_table']//ejs-checkbox/label/span[2]")
	private WebElement chk_PaymentRecord;

	@FindBy(xpath = "//span[@class='e-icons e-frame e-check']")
	private WebElement chk_UnCheckPaymentRecord;

	@FindBy(xpath = "//ejs-numerictextbox[@id='numeric']/span/input")//ejs-numerictextbox[@id='numeric']/span/input
	private WebElement txt_Payment;

	@FindBy(xpath = "//span[@class='panel-title']")
	private WebElement lbl_PaymentFacilitatorTitle;

	@FindBy(xpath = "//div[@class='collectPaymentModal modal-header']/h4/span")
	private WebElement lbl_PaymentAmount_Popup;

	@FindBy(xpath = "//div[@class='label-style-cd']")
	private WebElement lbl_InitiatePayment_Popup;

	@FindBy(xpath = "//div[@class='label-style-success']")
	private WebElement lbl_PaymentSuccess_Popup;

	@FindBy(xpath = "//table[@id='transaction-table_content_table']/tbody/tr")
	private WebElement tr_PaymentTransaction;

	@FindBy(xpath = "//table[@id='transaction-table_content_table']/tbody/tr[1]/td")
	private List<WebElement> tr_PaymentTransactionRow;

	@FindBy(xpath = "//ipas-payment-facilitator-pannel//ejs-accordion/div/div[2]/div/div/span/ul/li/div[1]")//span[@class='ng-star-inserted']/ul/li/div[1]
	private List<WebElement> lbl_PaymentFacilitator_Panel;

	@FindBy(xpath = "//ipas-payment-facilitator-pannel//ejs-accordion/div/div[2]/div/div/span/ul/li/div[2]")//span[@class='ng-star-inserted']/ul/li/div[2]
	public List<WebElement> lbl_PaymentFacilitator_Amounts_Panel;

	@FindBy(xpath = "//span[@class='ng-star-inserted']/ul[3]/li/div[2]")
	private WebElement tr_PaymentFacilitator_Amounts_Panel;

	@FindBy(xpath = "//a[text()='Payment Facilitator']/../../../div/img")
	public WebElement img_FinancialClearanceStatus_PaymentFacilitatorPanel;

	@FindBy(xpath = "//div[@id='_title']")
	private WebElement lbl_WarningAlertHeader;

	@FindBy(xpath = "//div[@role='dialog']/div[2]")
	private WebElement lbl_WarningAlertMessage;

	@FindBy(xpath = "//button[(text()='Discard')]")
	private WebElement btn_Discard;

	@FindBy(xpath = "//div[@aria-describedby='_dialog-content']/div[3]/button[2]")
	private WebElement btn_Cancel_UnSave;

	@FindBy(xpath = "//span[@class='e-btn-icon e-icon-dlg-close e-icons']/..")
	private WebElement btn_CloseX_UnSave;

	@FindBy(xpath = "//div[contains(@class,'collectPaymentModal modal-footer')]//child::button[1]")
	private WebElement btn_Cancel;

	@FindBy(xpath = "//div[@class='collectPaymentModal modal-header']/button")
	private WebElement btn_CloseX;

	@FindBy(xpath = "//img[@alt='iPAS Logo']")
	private WebElement lnk_iPASLogo;

	@FindBy(xpath = "//a[@class='nav-link active']")
	private WebElement menu_ActiveMenu;

	@FindBy(xpath = "//span[contains(@id,'error-msg')]")
	private WebElement lbl_ErrorMessage;

	@FindBy(xpath = "//div[contains(@class,'error-msg')]")
	private WebElement lbl_ErrorMessage_LessThanRemainingAmount;

	@FindBy(xpath = "//table[@id='discount-grid_content_table']/tbody/tr/td/ejs-dropdownlist")
	private List<WebElement> tbl_CurrentVisitDropdownlist;

	@FindBy(xpath = "//table[@id='discount-grid_content_table']/tbody/tr/td/ejs-numerictextbox")
	private List<WebElement> tbl_CurrentVisitNumericTextBox;

	public String li_ModuleNameNeedsAttention="//table[@id='asgrid_content_table']/tbody/tr/td[9]/div[";
	public String li_ModuleNameNeedsAttention1="]/div/span";

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr/td[9]/div")
	private List<WebElement> li_AllModuleNameNeedsAttention;

	@FindBy(xpath = "//span[@class='itemCost-style']")
	private WebElement lbl_ItemSelected;

	@FindBy(xpath = "//span[@class='pt-2']")
	private WebElement lbl_ItemSelectedAmount;

	@FindBy(xpath = "//ipas-payment-facilitator-pannel//ejs-accordion/div/div[1]/div[2]/span")
	private WebElement icon_ExpandCollapse;

	@FindBy(xpath = "//table[@id='historical-visit-grid_content_table']//ejs-checkbox/label/span[2]")
	private WebElement chk_PaymentRecord_Historical;

	@FindBy(xpath = "//table[@id='historical-visit-grid_content_table']/tbody/tr/td[2]/div/a")
	private WebElement lnk_AccountNumber_Historical;

	@FindBy(xpath = "//table[@id='historical-visit-grid_content_table']/tbody/tr/td[8]/ejs-numerictextbox/span/input")
	private WebElement txt_Payment_Historical;

	@FindBy(xpath = "//table[@id='historical-visit-grid_content_table']/tbody/tr/td/div")
	private List<WebElement> lbl_AmountValues_HistoricalVisitSection;

	@FindBy(xpath = "//div[@class='pasentDetails']/ul/li[1]/div[2]")
	private WebElement lbl_AccountNumber_PasentDetails;

	@FindBy(xpath = "//table[@id='historical-visit-grid_content_table']/tbody/tr/td[10]/div/a")
	private WebElement lnk_HistoricalModalDialogOpen;

	@FindBy(xpath = "//div[@class='flex-container']/div/div[1]")
	private List<WebElement> lbl_HeaderNames_HistoricalVisitSectionPopup;

	@FindBy(xpath = "//div[@class='flex-container']/div/div[2]")
	private List<WebElement> lbl_AmountValues_HistoricalVisitSectionPopup;

	@FindBy(xpath = "//div[@class='historicalDialog modal-header']/h4")
	private WebElement lbl_AccountNumber_HistoricalVisitSectionPopup;

	@FindBy(xpath = "//div[@class='historicalDialog modal-header']/button")
	private WebElement btn_CloseX_HistoricalVisitSectionPopup;

	@FindBy(xpath = "//table[@id='discount-grid_content_table']/tbody/tr/td/div")
	private WebElement lbl_AmountFields;

	@FindBy(xpath = "//table[@id='discount-grid_content_table']/tbody/tr/td/div")
	private List<WebElement> lbl_AllAmountFields;

	/*
	 * ReversePayment
	 */
	@FindBy(xpath = "//button[(text()='Reversal')]")//button[@hideauthorize='VoidPayment']
	private WebElement btn_Reversal;

	@FindBy(xpath = "(//div[@id='reversePayment']/div/div/div/h4/span)[1]")
	private WebElement lbl_ReversePaymentTitle;

	@FindBy(xpath = "//input[@formcontrolname='refundAmount']")
	private WebElement txt_RefundAmount;

	@FindBy(xpath = "//input[@formcontrolname='paymentMemo']")
	private WebElement txt_PaymentMemo_Reversal;

	@FindBy(xpath = "//ejs-numerictextbox[@id='numeric']/span/span/input")
	private WebElement txt_RefundAmount_Historical;

	@FindBy(xpath = "(//input[@formcontrolname='paymentMemo'])[2]")
	private WebElement txt_PaymentMemo_Reversal_Historical;

	@FindBy(xpath = "(//div[@id='reversePayment'])[1]//child::label")
	private List<WebElement> lbl_ReversePaymentFeilds;

	@FindBy(xpath = "//div[@class='modal-body pt-0']/div[1]/div/span")
	private WebElement lbl_AmountValidation_Reversal;

	@FindBy(xpath = "//div[@class='modal-body pt-0']/div[2]/div/div")
	private WebElement lbl_PaymentMemoValidation_Reversal;

	@FindBy(xpath = "(//button[@class='btn refund-btn'])[1]")
	private WebElement btn_Submit_Reversal;

	@FindBy(xpath = "(//button[@type='submit'])[4]")
	private WebElement btn_Submit_Reversal_Historical;

	@FindBy(xpath = "(//button[@class='btn btn-light mr-4'])[1]")
	private WebElement btn_Cancel_Reversal;

	@FindBy(xpath = "//table[@id='transaction-table_content_table']/tbody/tr[2]/td[2]/div/div[3]/div/table/tbody/tr/td")
	private List<WebElement> tr_RefundTransactionRow;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr")
	public List<WebElement> tbl_AccountSearch_Results;
	
	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody")
	public WebElement tbl_AccountSearch_Results_Grid;

	@FindBy(xpath = "//table[@id='transaction-table_content_table']/tbody/tr[1]/td[2]")
	private WebElement lbl_TransactionNumber;

	@FindBy(xpath = "//div[@id='allDataPasentDetails']/div[2]/h2")
	private WebElement lbl_PatientName;

	@FindBy(xpath = "//button[(text()='Receipt')]")
	private WebElement btn_Receipt;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr/td[2]/div/a")
	private WebElement lbl_AccountNumber_AccountSearch;

	@FindBy(xpath = "//table[@id='discount-grid_content_table']/tbody/tr/td[4]/ejs-dropdownlist//span")
	private List<WebElement> lbl_DiscountPaymentFacilitatorPage;
	
	@FindBy(xpath = "//ejs-dashboardlayout[@id='defaultLayout']")
	private WebElement lbl_AllPanels;
	
	@FindBy(xpath = "//p[contains(text(),'0/160 characters')]")
	private WebElement lbl_MessageHub;
	
	@FindBy(xpath = "//div[@class='details']")
	public List<WebElement> lbl_AllAlerts;
	
	@FindBy(xpath = "(//span[contains(@class,'total-amt')])[1]")
	private WebElement lbl_CurrentVisitAmt;
	
	Login login=new Login();
	AddPatientVisitPage addPatient=new AddPatientVisitPage();
	private RestActions rest = new RestActions();
	public PaymentFacilitatorPage() {
		PageFactory.initElements(driver, this);
	}


	public void searchAccountNuberinAccountSearchPage(String accountNumber) throws Exception{
		try {
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibility(tbl_AccountSearch_Results_Grid, "Account Search Table",10);
			} catch (Exception e) {
			}
			/*try {
				webActions.waitForVisibilityOfAllElements(tbl_AccountSearch_Results, "Account Search Table");
			} catch (Exception e) {
			}*/
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_Search, accountNumber, "Simple Search");
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(li_Search, "Account Numnber list");
			webActions.waitForPageLoaded();
			webActions.click(li_Search, "Account Numnber list");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_Headers_AS,"Account Search Headers");
			driver.findElement(By.partialLinkText(accountNumber)).click();
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibility(tbl_PaymentFacilitatorPanel, "Payment Facilitator Panel",8);
			} catch (Exception e) {
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void searchAccountNumberinServiceTracker(String AccountNumber) throws Exception{
		try {
			webActions.waitForVisibility(lbl_Headers, "Service Tracker Headers");
			webActions.waitForPageLoaded();
			webActions.enterValuesfromKeyBoard(txt_Search_ST, AccountNumber, "");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			driver.findElement(By.linkText(AccountNumber)).click();
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(tbl_PaymentFacilitatorPanel, "PaymentFacilitatorPanel");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String navigatePatientVisitMainPage(String pageName){
		String accountNumber="";
		try {
			accountNumber = getDataFromJSONFile("AccountNumber");
			switch (pageName) {
			case "Account Search":
				searchAccountNuberinAccountSearchPage(accountNumber);
				break;
			case "Service Tracker":
				searchAccountNumberinServiceTracker(accountNumber);
				break;
			}
		} catch (Exception e) {
			report.reportFail("Failed to navigate Patient Visi tMain Page from "+pageName+" page");
		}
		return accountNumber;
	}

	public void verifytheErrorMessageifNoPaymentsinPanel(String errorMessage,String pageName) {
		String actualErrorMessage="";
		try {
			StringBuilder unmatch=new StringBuilder();
			navigatePatientVisitMainPage(pageName);
			waitforPaymentFacilitatorPanel();
			actualErrorMessage=webActions.waitAndGetText(lbl_NoPayments, "No Payments Error Message");
			report.reportInfo("Actual Error Message is: "+actualErrorMessage);
			report.reportInfo("Expected Error Message is: "+errorMessage);
			if(errorMessage.contentEquals(actualErrorMessage)){
				report.reportPass("Successfully verified the Error Message if no payments when navigate from "+pageName+" page");
			}else{
				report.reportFail("Failed to verify the Error Message if no payments when navigate from "+pageName+" page",true);
				unmatch.append("Failed to verify the Error Message if no payments when navigate from "+pageName+" page");
			}
			webActions.waitAndClick(icon_ExpandCollapse, "ExpandandCollapse");
			webActions.waitForPageLoaded();
			String actualCollapseStatus=webActions.getAttributeValue(icon_ExpandCollapse, "class", "ExpandandCollapse");
			if("e-tgl-collapse-icon e-icons".contentEquals(actualCollapseStatus)){
				report.reportPass("Payment Facilitator Panel Successfully Collapsed");
			}
			else{
				report.reportFail("Payment Facilitator Panle is not Collapsed",true);
				unmatch.append("Payment Facilitator Panle is not Collapsed");
			}
			webActions.waitAndClick(icon_ExpandCollapse, "ExpandandCollapse");
			webActions.waitForPageLoaded();
			String actualEpandStatus=webActions.getAttributeValue(icon_ExpandCollapse, "class", "ExpandandCollapse");
			if("e-tgl-collapse-icon e-icons e-expand-icon".contentEquals(actualEpandStatus)){
				report.reportPass("Payment Facilitator Panel Successfully Expanded");
			}else{
				report.reportFail("Payment Facilitator Panle is not Expanded",true);
				unmatch.append("Payment Facilitator Panle is not Expanded");
			}
			String actaulFCPFStatus=getActualFinancialClearanceStatusinPanel();
			if(actaulFCPFStatus.contains("success")){
				report.reportPass("Successfully verified by default Financial Clearance status in Panel");
			}else{
				report.reportFail("Failed to verify the default Financial Clearance status in Panel");
				unmatch.append("Failed to verify the default Financial Clearance status in Panel");
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void navigatetoPaymentFacilitatorPage(String pageName) {
		try {
			navigatePatientVisitMainPage(pageName);
			webActions.waitForPageLoaded();
			waitforPaymentFacilitatorPanel();
			webActions.waitForPageLoaded();
			waitforAllPanels();
			waitforAAARuleAlerts();
			webActions.waitForPageLoaded();
			/*try {
				webActions.waitAndGetText(lbl_MessageHub, "MessageHub");
			} catch (Exception e) {
				webActions.waitForPageLoaded();
			}*/
			webActions.waitAndClick(lnk_PaymentFacilitator, "Payment Facilitator");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			waitforPaymentFacilitatorPage();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void waitforAllPanels(){
		try {
			webActions.waitForVisibility(lbl_AllPanels, "All Panels",8);
		} catch (Exception e) {
		}
	}

	public void waitforPaymentFacilitatorPage() throws Exception{
		try {
			webActions.waitForVisibilityOfAllElements(lbl_DiscountPaymentFacilitatorPage, "Discount Feild");
		} catch (Exception e) {
			webActions.waitForPageLoaded();
		}
	}

	public void waitforPaymentFacilitatorPanel() throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(lbl_NoPayments, "No Payments Error Message");
		} catch (Exception e) {
			webActions.waitForVisibility(tbl_PaymentFacilitatorPanel, "Payment Facilitator Panel");
		}
	}

	public void clickModuleLinkFromNeedsAttentioninAccountSearchPage(String moduleName)  {
		try {
			String accountNumber = getDataFromJSONFile("AccountNumber");
			webActions.waitForVisibility(lbl_Headers_AS, "Account Search Headers");
			webActions.sendKeys(txt_Search, accountNumber, "Search Box");
			webActions.waitForClickAbility(li_Search, "");
			webActions.click(li_Search, "Rows");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_Headers_AS,"Account Search Headers");
			webActions.waitAndClick(lnk_NeedsAttention, "Needs Attention");
			webActions.waitForVisibility(lnk_PaymentFacilitator_AllModules, "PaymentFacilitator");
			webActions.waitAndClick(lnk_PaymentFacilitator_AllModules, "PaymentFacilitator");
			//driver.findElement(By.linkText(moduleName)).click();
			webActions.waitForPageLoaded();
			report.reportPass("Successfully navigated to: "+moduleName);
		} catch (Exception e) {
			report.reportFail("Failed to navigate to: "+moduleName +e);
		}
	}

	public void verifyCurrentVisitSectionFeildNames(DataTable fieldNames){
		try {
			ArrayList<String> expFieldNames = new ArrayList<>(fieldNames.asList());
			webActions.waitForVisibility(txt_RemainingBalance, "Remaining Balance");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			List<WebElement> row=lbl_CurrentVisitFeilds;
			ArrayList<String> actCurrentVist=new ArrayList<>();
			actCurrentVist.add(webActions.waitAndGetText(lbl_CurrentVisitTitle, "CurrentVisitTitle"));
			for (WebElement webElement : row) {
				String txt=webElement.getText();
				if(!txt.isEmpty()){
					actCurrentVist.add(txt);
				}
			}
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actCurrentVist, expFieldNames);
			if (unmatch.size()==0) {
				report.reportPass("Successfully verified the Current Visit Section Field Names: "+actCurrentVist);
			}
			else{
				report.reportFail("Failed to verify the Current Visit Section Field Names and unmatch names: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyHistoricalBalanceFeildNames(DataTable fieldNames){
		try {
			ArrayList<String> expFieldNames = new ArrayList<>(fieldNames.asList());
			List<WebElement> historicalVisitFeilds=lbl_HistoricalBalanceFeilds;
			ArrayList<String> actHistBalFeilds=new ArrayList<>();
			actHistBalFeilds.add(webActions.waitAndGetText(lbl_HistoricalBalanceTitle, "Historical Balance Title"));
			for (WebElement webElement : historicalVisitFeilds) {
				String txt=webElement.getText();
				if(!txt.isEmpty()){
					actHistBalFeilds.add(txt);
				}
			}
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actHistBalFeilds, expFieldNames);
			if (unmatch.size()==0) {
				report.reportPass("Successfully verified the Historical Balance Section Field Names: "+actHistBalFeilds);
			}
			else{
				report.reportFail("Failed to verify the Historical Balance Section Field Names and unmatch names: "+unmatch);
			}
		} catch (Exception e) {
		}
	}

	public void verifyWarningAlertMessageWhenUserLeavesPageWithoutSavingChanges(String alertTitle,String alertMessage ){
		try {
			String accountNumber = getDataFromJSONFile("AccountNumber");
			ArrayList<String>unmatch=new ArrayList<String>();
			waitforPage();
			webActions.sendKeys(dd_PaymentType, "Estimate", "Payment Type");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(txt_TotalAmount, "Total Amount");
			webActions.sendKeys(txt_TotalAmount, "20", "Total AMount");
			webActions.click(btn_Calculate, "Calculate");
			webActions.click(lnk_iPASLogo, "iPASLogo");
			String actTitle=webActions.waitAndGetText(lbl_WarningAlertHeader, "Warning Alert Header");
			String actMessage=webActions.waitAndGetText(lbl_WarningAlertMessage, "Warning Alert Message");
			if((alertTitle.contains(actTitle))&&(actMessage.contains(alertMessage))){
				report.reportPass("Verified warning alert title and message: "+actTitle+"\n"+actMessage);
			}else{
				unmatch.add("Failed to verify the warning alert title and message: "+actTitle+"\n"+actMessage);
				report.reportFail("Failed to verify the warning alert title and message: "+actTitle+"\n"+actMessage,true);
			}
			webActions.click(btn_Cancel_UnSave, "Cancel");
			webActions.waitForPageLoaded();
			webActions.waitAndClick(menu_ActiveMenu, "Active Menu");
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_CloseX_UnSave, "Close X");
			webActions.waitForPageLoaded();
			driver.findElement(By.linkText(accountNumber)).click();
			webActions.waitAndClick(btn_Discard, "Discard");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();

			ArrayList<String> actualBreadcrumbTitles = new ArrayList<String>();
			actualBreadcrumbTitles = webActions.getDatafromWebTable(lbl_Breadcrum);

			ArrayList<String>expectedBreadcrumbTitles=new ArrayList<String>();
			expectedBreadcrumbTitles.add("Account Search");
			expectedBreadcrumbTitles.add(accountNumber);
			ArrayList<String> unmatchBreadcrumb=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles, expectedBreadcrumbTitles);
			if(unmatchBreadcrumb.size()==0){
				report.reportPass("Successfully discard the save changes: "+actualBreadcrumbTitles);
			}else{
				report.reportFail("Failed to verify the discard the save changes: "+unmatchBreadcrumb);
			}
		} catch (Exception e) {
			report.reportFail("Failed to verify warning alert message when user leaves page without saving changes: "+e);
		}
	}

	public void verifyTheValidationErrorMessageIfValueIsEmpty(DataTable errorMessages){
		try {
			ArrayList<String> expErrorMessages = new ArrayList<>(errorMessages.asList());
			StringBuilder unmatch=new StringBuilder();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();	
			waitforPage();
			waitforPaymentTransactionData();
			webActions.waitAndClick(chk_PaymentRecord, "Payment Record Check Box");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();	
			webActions.click(btn_InitiatePayment, "Initiate Payment");
			String actPaymentErrorMessage=webActions.waitAndGetText(lbl_ErrorMessage, "Payment Error");
			String expPaymentErrorMessage=expErrorMessages.get(0);
			report.reportInfo("Expected Payment error message: "+expPaymentErrorMessage);
			report.reportInfo("Actual Payment error message: "+actPaymentErrorMessage);
			if(expPaymentErrorMessage.contains(actPaymentErrorMessage)){
				report.reportPass("Successfully verified validation error message if value is empty in Payment field");
			}else{
				report.reportFail("Failed to verify the validation error message if value is empty in Payment field",true);
				unmatch.append("Failed to verify the validation error message if value is empty in Payment field");
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(chk_UnCheckPaymentRecord, "Payment Record Check Box");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();	
			webActions.click(txt_TotalAmount, "Total Amount");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();	
			webActions.clearValue(txt_TotalAmount, "Total Amount");
			String actTotalAmountErrorMesssage=webActions.waitAndGetText(lbl_ErrorMessage, "Payment Error");
			String expTotalAmountErrorMesssage=expErrorMessages.get(1);
			report.reportInfo("Expected Total Amount error message: "+expTotalAmountErrorMesssage);
			report.reportInfo("Actual Total Amount error message: "+actTotalAmountErrorMesssage);
			if(expTotalAmountErrorMesssage.contains(actTotalAmountErrorMesssage)){
				report.reportPass("Successfully verified validation error message if value is empty in Total Amount field");
			}else{
				report.reportFail("Failed to verify the validation error message if value is empty in Total Amount field",true);
				unmatch.append("Failed to verify the validation error message if value is empty in Total Amount field");
			}
			webActions.click(txt_TotalAmount, "Total Amount");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_TotalAmount, "1", "Total Amount");
			webActions.waitForPageLoaded();
			webActions.click(btn_Calculate, "Calculate");
			webActions.waitForPageLoaded();
			String actLessThanRemainingAmountErrorMessage=webActions.waitAndGetText(lbl_ErrorMessage_LessThanRemainingAmount, "Total Amount");
			String expLessThanRemainingAmountErrorMessage=expErrorMessages.get(2);
			if(expLessThanRemainingAmountErrorMessage.contains(actLessThanRemainingAmountErrorMessage)){
				report.reportPass("Successfully verified validation error message if enter less than remaining amount in Total Amount field: "+actLessThanRemainingAmountErrorMessage);
			}else{
				report.reportFail("Failed to verify the validation error message if enter less than remaining amount in Total Amount field: "+actLessThanRemainingAmountErrorMessage,true);
				unmatch.append("Failed to verify the validation error message if enter less than remaining amount in Total Amount field");
			}
			
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
			
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyValidationMessageifTotalAmountLessThanDiscountAmount(DataTable testData){
		try {
			waitforPage();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_PaymentType, getDatafromMap(testData,"Payment Type"), "Payment Type");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(txt_TotalAmount, "Total Amount");
			webActions.sendKeys(txt_TotalAmount, getDatafromMap(testData,"Total Amount"), "Total Amount");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_Discount, getDatafromMap(testData,"Discount"), "Discount");
			webActions.click(btn_Calculate, "Calculate");
			webActions.waitForPageLoaded();
			String actTotalAmountLessThanDiscountAmountErrorMessage=webActions.waitAndGetText(lbl_ErrorMessage_LessThanRemainingAmount, "Total Amount");
			String expTotalAmountLessThanDiscountAmountErrorMessage=getDatafromMap(testData,"Message");
			if(expTotalAmountLessThanDiscountAmountErrorMessage.contains(actTotalAmountLessThanDiscountAmountErrorMessage)){
				report.reportPass("Successfully verified validation error message if enter Total Amount Less Than Discount Amount: "+actTotalAmountLessThanDiscountAmountErrorMessage);
			}else{
				report.reportFail("Failed to verify the validation error message if enter Total Amount Less Than Discount Amount: "+actTotalAmountLessThanDiscountAmountErrorMessage);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyTheFeildsInCollectPaymentWindow(DataTable fields){
		try {
			ArrayList<String> expFields = new ArrayList<>(fields.asList());
			waitforPaymentTransactionData();
			String accountNumber = getDataFromJSONFile("AccountNumber");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(chk_PaymentRecord, "Payment Record Check Box");
			webActions.waitAndClick(chk_PaymentRecord, "Payment Record Check Box");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();	
			webActions.click(txt_TotalAmount, "Total Amount");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String payment="2.52";
			webActions.sendKeys(txt_Payment, payment, "Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(lbl_PaymentFacilitatorTitle, "Payment Title");
			String ItemSelectedAmount=webActions.waitAndGetText(lbl_ItemSelectedAmount, "Item Selected Amount");
			if(ItemSelectedAmount.contains("1 Item Selected $"+payment)){
				report.reportPass("Successfully verified no of items selected and amount: "+ItemSelectedAmount);
			}
			else{
				report.reportFail("Failed to verify no of items selected and amount",true);
			}
			webActions.click(btn_InitiatePayment, "Initiate Payment");
			ArrayList<String> actPaymentModalData=getPaymentandAccountinCollectPaymentModal();
			ArrayList<String> expPaymentModalData=new  ArrayList<String>();
			expPaymentModalData.add(payment);
			expPaymentModalData.add(accountNumber);
			expPaymentModalData.add(payment);

			ArrayList<String> unmatchPaymentModalData=webActions.getUmatchedInArrayComparision(actPaymentModalData, expPaymentModalData);
			if(unmatchPaymentModalData.size()==0){
				report.reportPass("Successfully verified Payment Amount and Account Number in Collect Payment Modal: "+actPaymentModalData);	
			}else{
				report.reportFail("Failed to verify Payment Amount and Account Number in Collect Payment Modal: ",true);
			}
			ArrayList<String> actLabel=getFieldNamesinCollectPaymentWindow();
			report.reportInfo("Expected Fields in Collect Payment Window: "+expFields);
			ArrayList<String> unmatchFeilds=webActions.getUmatchedInArrayComparision(actLabel, expFields);
			if(unmatchFeilds.size()==0){
				report.reportPass("Successfully verified fields in Collect Payment Modal: "+actLabel);
			}else{
				report.reportFail("Failed to verify the fields in Collect Payment Modal: ", true);
			}
			webActions.click(btn_CloseX, "CloseX");
			webActions.waitForPageLoaded();
			webActions.click(btn_InitiatePayment, "Initiate Payment");
			webActions.waitForPageLoaded();
			webActions.click(btn_Cancel, "Cancel");
			String pageTitle=webActions.waitAndGetText(lbl_PaymentFacilitatorTitle, "Payment Title");
			if("Payment Facilitator".contains(pageTitle)){
				report.reportPass("Successfully Canceled the Payment and Collect Payment Modal is closed: "+pageTitle);
			}
			else{
				report.reportFail("Failed to verify the Canceled the Payment and Collect Payment Modal is not closed: ", true);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public ArrayList<String> getFieldNamesinCollectPaymentWindow(){
		ArrayList<String>actLabel=new ArrayList<String>();
		try {
			List<WebElement> textFields=driver.findElements(By.xpath(lbl_CollectPaymentModal+"label"));
			for (WebElement webElement : textFields) {
				String text=webElement.getText();
				actLabel.add(text);
			}
			List<WebElement> textFields1=driver.findElements(By.xpath(lbl_CollectPaymentModal+"th"));
			for (WebElement webElement : textFields1) {
				String text=webElement.getText();
				actLabel.add(text);
			}
			List<WebElement> buttons=driver.findElements(By.xpath(lbl_CollectPaymentModal+"button"));
			for (WebElement webElement : buttons) {
				String text=webElement.getText();
				actLabel.add(text);
			}
			report.reportInfo("Actual Fields in Collect Payment Window: "+actLabel);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return actLabel;
	}

	public ArrayList<String> getPaymentandAccountinCollectPaymentModal(){
		ArrayList<String> datainPaymentModal=new ArrayList<String>();
		datainPaymentModal.add(webActions.waitAndGetText(lbl_PaymentAmount_CollectPaymentModal, "Payment Amount Modal Window"));
		datainPaymentModal.addAll(webActions.getDatafromWebTable(lbl_AccountandPaymentCollectPaymentModal));
		return datainPaymentModal;
	}

	public void waitforPage() throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibilityOfAllElements(lbl_AmountFields, "Amount Field");
			webActions.waitForVisibilityOfAllElements(tbl_CurrentVisitDropdownlist, "CurrentVisitDropdownlist");
		} catch (Exception e) {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		}	
	}

	public void clickCalculateAndSaveButtons() {
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(btn_Calculate, "Calculate");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_Save, "Save");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		} catch (Exception e) {
		}
	}

	public void savePayment(DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			waitforPage();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_PaymentType, getDatafromMap(testData,"Payment Type"), "Payment Type");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(txt_TotalAmount, "Total Amount");
			webActions.sendKeys(txt_TotalAmount, getDatafromMap(testData,"Total Amount"), "Total AMount");
			clickCalculateAndSaveButtons();
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent=titleContent[1];
			report.reportInfo("Alret message for payment is saved successfully: "+msg);
			if("Data saved successfully.".contains(actContent)){
				report.reportPass("Successfully saved the payment");
			}else{
				report.reportFail("Failed to save the payment",true);
				verify.append("Failed to save the payment");
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			ArrayList<String>actSavedAmounts=getActualAmountsAfterSavePayment();
			ArrayList<String>expSavedAmounts=getExpectedAmountsAfterSavePayment(testData);
			report.reportInfo("Expected amounts 'Adjusted Amount' 'Paid' 'Remaining Balance' in the Payment Facilitator page: "+expSavedAmounts);
			report.reportInfo("Actual amounts 'Adjusted Amount' 'Paid' 'Remaining Balance' in the Payment Facilitator page: "+actSavedAmounts);
			ArrayList<String> unmatchAmounts=webActions.getUmatchedInArrayComparision(actSavedAmounts, expSavedAmounts);
			if(unmatchAmounts.size()==0){
				report.reportPass("Saved Payment Amounts matched successfully in Payment Facilitator page: "+actSavedAmounts);
			}else{
				report.reportFail("Saved Payment Amounts are not matched in Payment Facilitator page: "+unmatchAmounts,true);
				verify.append("Saved Payment Amounts are not matched in Payment Facilitator page:");
			}
			String actFinClearStatus=getFinClearStatusinPaymentFacilitatorPage();
			if(actFinClearStatus.contains("error")){
				report.reportPass("Successfully verifed the Financial Clearance Status after save in Payment Facilitator Page");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status after save in Payment Facilitator Page",true);
				verify.append("Failed to verify the Financial Clearance Status after save in Payment Facilitator Page");
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void initiatePayment(DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(chk_PaymentRecord, "Payment Record Check Box");
			webActions.waitAndClick(chk_PaymentRecord, "Payment Record Check Box");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(txt_Payment, "Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_Payment, getDatafromMap(testData,"Payment"), "Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(btn_InitiatePayment, "Initiate Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitUntilPresentAndDisplayed(dd_PaymentMethod, "Payment Method");
			webActions.sendKeys(dd_PaymentMethod, getDatafromMap(testData,"Payment Method"), "Payment Method");
			webActions.waitUntilPresentAndDisplayed(txt_PaymentMemo, "Payment Memo");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_PaymentMemo, getDatafromMap(testData,"Payment Memo"), "Payment Memo");
			webActions.click(btn_CollectPayment, "Collect Payment");

			// It will return the parent window name as a String
			String parent=driver.getWindowHandle();

			String InitiatePayment=webActions.waitAndGetText(lbl_InitiatePayment_Popup, "InitiatePayment");

			if("Initiate Payment".contains(InitiatePayment)){
				report.reportPass("Successfully Initiated the Payment: "+InitiatePayment);
			}else{
				report.reportFail("Failed to verify Initiate Payment and message is not matched: "+InitiatePayment,true);
				verify.append("Failed to verify Initiate Payment and message is not matched:");
			}

			String paymentSuccess=webActions.waitAndGetText(lbl_PaymentSuccess_Popup, "Success");

			if("Processing Complete".contains(paymentSuccess)){
				report.reportPass("Successfully collected the payment amount: "+paymentSuccess);
			}else{
				report.reportFail("Failed to verify the collect the payment amount and message: "+paymentSuccess,true);
				verify.append("Failed to verify the collect the payment amount and message:");
			}

			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			driver.switchTo().window(parent);

			ArrayList<String> actPaymentTransactionData=getPaymentTransactionData();

			ArrayList<String> expPaymentTransactionData=getExpectedPaymentTransactionData(testData);

			ArrayList<String> unmatchTransactionData=webActions.getUmatchedInArrayComparision(actPaymentTransactionData, expPaymentTransactionData);
			if(unmatchTransactionData.size()==0){
				report.reportPass("Payment Transaction data is matched: "+actPaymentTransactionData);
			}else{
				report.reportFail("Payment Transaction data is not matched and unmatched data is: "+unmatchTransactionData,true);
				verify.append("Payment Transaction data is not matched");
			}
			ArrayList<String> actPaymentAmountsinPage=getActualAmountsAfterSavePayment();
			ArrayList<String>expAmountsinPage=getExpectedAmountsinPanelandPage(testData);
			report.reportInfo("Expected Payment Amounts after payment is done in the page: "+expAmountsinPage);
			report.reportInfo("Actual Payment Amounts after payment is done in page: "+actPaymentAmountsinPage);
			ArrayList<String> unmatchAmounts=webActions.getUmatchedInArrayComparision(actPaymentAmountsinPage, expAmountsinPage);
			if(unmatchAmounts.size()==0){
				report.reportPass("Payment Amounts matched successfully after payment is done in page: "+actPaymentAmountsinPage);
			}else{
				report.reportFail("Payment Amounts not matched after payment is done in page: "+unmatchAmounts,true);
				verify.append("Payment Amounts not matched after payment is done in page");
			}

			String actFCStatusPaymentFacilitatorPage=getFinClearStatusinPaymentFacilitatorPage();
			String expFCStatusPaymentFacilitatorPage=getFinancialClearanceStatus(testData);
			if(actFCStatusPaymentFacilitatorPage.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Page");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Page",true);
				verify.append("Failed to verify the Financial Clearance Status in Payment Facilitator Page");
			}

			String accountNumber = getDataFromJSONFile("AccountNumber");
			driver.findElement(By.linkText(accountNumber)).click();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();

			ArrayList<String> actLabelNames=getActualLabelNamesinPanel();
			ArrayList<String>expLabelNames=getExpectedLabelNamesinPanel(testData);

			ArrayList<String> unmatchLabels=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchLabels.size()==0){
				report.reportPass("Label names matched successfully in Panel: "+actLabelNames);
			}else{
				report.reportFail("Label names are not matched in Panel: "+unmatchLabels,true);
				verify.append("Label names are not matched in Panel:");
			}

			ArrayList<String> actAmounts=webActions.getDatafromWebTable(lbl_PaymentFacilitator_Amounts_Panel);
			ArrayList<String>expAmounts=getExpectedAmountsinPanelandPage(testData);
			report.reportInfo("Expected Payment Amounts in panel: "+expAmounts);
			report.reportInfo("Actual Payment Amounts in panel: "+actAmounts);
			ArrayList<String> unmatchAmountsPanel=webActions.getUmatchedInArrayComparision(actAmounts, expAmounts);
			if(unmatchAmountsPanel.size()==0){
				report.reportPass("Payment Amounts matched successfully in Panel: "+actAmounts);
			}else{
				report.reportFail("Payment Amounts not matched in Panel: "+unmatchAmountsPanel,true);
				verify.append("Payment Amounts not matched in Panel");
			}

			String actFCStatusPFPanel=webActions.getAttributeValue(img_FinancialClearanceStatus_PaymentFacilitatorPanel, "src", "Payment Facilitator Panel");
			if(actFCStatusPFPanel.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Panel");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Panel",true);
				verify.append("Failed to verify the Financial Clearance Status in Payment Facilitator Panel");
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void savePaymentandInitiatePayment(DataTable testData){
		try {
			savePayment(testData);
			initiatePayment(testData);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void savePaymentandInitiatePartialPayment(DataTable testData){
		try {
			savePayment(testData);
			initiatePartialPayment(testData);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void initiatePartialPayment (DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(chk_PaymentRecord, "Payment Record Check Box");
			webActions.waitAndClick(chk_PaymentRecord, "Payment Record Check Box");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(txt_Payment, "Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_Payment, getDatafromMap(testData,"Payment"), "Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(btn_InitiatePayment, "Initiate Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitUntilPresentAndDisplayed(dd_PaymentMethod, "Payment Method");
			webActions.sendKeys(dd_PaymentMethod, getDatafromMap(testData,"Payment Method"), "Payment Method");
			webActions.waitUntilPresentAndDisplayed(txt_PaymentMemo, "Payment Memo");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_PaymentMemo, getDatafromMap(testData,"Payment Memo"), "Payment Memo");
			webActions.click(btn_CollectPayment, "Collect Payment");

			// It will return the parent window name as a String
			String parent=driver.getWindowHandle();

			String InitiatePayment=webActions.waitAndGetText(lbl_InitiatePayment_Popup, "InitiatePayment");

			if("Initiate Payment".contains(InitiatePayment)){
				report.reportPass("Successfully Initiated the Payment: "+InitiatePayment);
			}else{
				report.reportFail("Failed to verify Initiate Payment and message is not matched: "+InitiatePayment,true);
				verify.append("Failed to verify Initiate Payment and message is not matched");
			}

			String paymentSuccess=webActions.waitAndGetText(lbl_PaymentSuccess_Popup, "Success");

			if("Processing Complete".contains(paymentSuccess)){
				report.reportPass("Successfully collected the payment amount: "+paymentSuccess);
			}else{
				report.reportFail("Failed to collect the payment amount and message is not matched:  "+paymentSuccess,true);
				verify.append("Failed to collect the payment amount and message is not matched");
			}

			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			driver.switchTo().window(parent);

			ArrayList<String> actPaymentTransactionData=getPaymentTransactionData();

			ArrayList<String> expPaymentTransactionData=getExpectedPaymentTransactionData(testData);

			ArrayList<String> unmatchTransactionData=webActions.getUmatchedInArrayComparision(actPaymentTransactionData, expPaymentTransactionData);
			if(unmatchTransactionData.size()==0){
				report.reportPass("Payment Transaction data is matched: "+actPaymentTransactionData);
			}else{
				report.reportFail("Payment Transaction data is not matched and unmatched data is: "+unmatchTransactionData,true);
				verify.append("Payment Transaction data is not matched");
			}
			ArrayList<String> actPaymentAmountsinPage=getActualAmountsAfterSavePayment();
			ArrayList<String>expAmountsinPage=getExpectedAmountsinPanelandPage(testData);
			report.reportInfo("Expected Payment Amounts after payment is done in the page: "+expAmountsinPage);
			report.reportInfo("Actual Payment Amounts after payment is done in page: "+actPaymentAmountsinPage);
			ArrayList<String> unmatchAmounts=webActions.getUmatchedInArrayComparision(actPaymentAmountsinPage, expAmountsinPage);
			if(unmatchAmounts.size()==0){
				report.reportPass("Payment Amounts matched successfully after payment is done in page: "+actPaymentAmountsinPage);
			}else{
				report.reportFail("Payment Amounts not matched after payment is done in page: "+unmatchAmounts,true);
				verify.append("Payment Amounts not matched after payment is done in page");
			}

			String actFCStatusPaymentFacilitatorPage=getFinClearStatusinPaymentFacilitatorPage();
			String expFCStatusPaymentFacilitatorPage=getFinancialClearanceStatus(testData);
			if(actFCStatusPaymentFacilitatorPage.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Page");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Page",true);
				verify.append("Failed to verify the Financial Clearance Status in Payment Facilitator Page");
			}

			String accountNumber = getDataFromJSONFile("AccountNumber");
			driver.findElement(By.linkText(accountNumber)).click();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();

			ArrayList<String> actLabelNames=getActualLabelNamesinPanel();
			ArrayList<String>expLabelNames=getExpectedLabelNamesinPanel(testData);

			ArrayList<String> unmatchLabels=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchLabels.size()==0){
				report.reportPass("Label names matched successfully in Panel: "+actLabelNames);
			}else{
				report.reportFail("Label names are not matched in Panel: "+unmatchLabels,true);
				verify.append("Label names are not matched in Panel");
			}

			ArrayList<String> actAmounts=webActions.getDatafromWebTable(lbl_PaymentFacilitator_Amounts_Panel);
			ArrayList<String>expAmounts=getExpectedAmountsinPanelandPage(testData);
			report.reportInfo("Expected Payment Amounts in panel: "+expAmounts);
			report.reportInfo("Actual Payment Amounts in panel: "+actAmounts);
			ArrayList<String> unmatchAmountsPanel=webActions.getUmatchedInArrayComparision(actAmounts, expAmounts);
			if(unmatchAmountsPanel.size()==0){
				report.reportPass("Payment Amounts matched successfully in Panel: "+actAmounts);
			}else{
				report.reportFail("Payment Amounts not matched in Panel: "+unmatchAmountsPanel,true);
				verify.append("Payment Amounts not matched in Panel");
			}

			String actFCStatusPFPanel=webActions.getAttributeValue(img_FinancialClearanceStatus_PaymentFacilitatorPanel, "src", "Payment Facilitator Panel");
			if(actFCStatusPFPanel.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Panel");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Panel",true);
				verify.append("Failed to verify the Financial Clearance Status in Payment Facilitator Panel");
			}

			String actModuleStatus=getFinancialClearanceModuleStatusinNeedAttention(accountNumber,"Payment Facilitator");
			if(actModuleStatus.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verified the Financial Clearance Status in Needs Attention");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Needs Attention",true);
				verify.append("Failed to verify the Financial Clearance Status in Needs Attention");
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void savePaymentVerifytheAmountsinPaymentFacilitatorPanelandFinancialClearanceStatus (DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			savePayment(testData);
			String accountNumber = getDataFromJSONFile("AccountNumber");
			driver.findElement(By.linkText(accountNumber)).click();
			ArrayList<String> actLabelNames=getActualLabelNamesinPanel();
			ArrayList<String>expLabelNames=getExpectedLabelNamesinPanel(testData);
			ArrayList<String> unmatchLabels=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchLabels.size()==0){
				report.reportPass("Label names matched successfully in Panel: "+actLabelNames);
			}else{
				report.reportFail("Label names are not matched in Panel: "+unmatchLabels,true);
				verify.append("Label names are not matched in Panel");
			}
			ArrayList<String> actAmounts=getActualAmountsinPanel();
			ArrayList<String>expAmounts=new ArrayList<String>();
			expAmounts.add(getDatafromMap(testData,"Total Amount"));
			expAmounts.add("0.00");
			expAmounts.add(getDatafromMap(testData,"Total Amount"));
			report.reportInfo("Expected Payment Amounts in panel: "+expAmounts);
			report.reportInfo("Actual Payment Amounts in panel: "+actAmounts);
			ArrayList<String> unmatchAmounts=webActions.getUmatchedInArrayComparision(actAmounts, expAmounts);
			if(unmatchAmounts.size()==0){
				report.reportPass("Payment Amounts matched successfully in Panel: "+actAmounts);
			}else{
				report.reportFail("Payment Amounts not matched in Panel: "+unmatchAmounts,true);
				verify.append("Payment Amounts not matched in Panel");
			}
			String actaulFCPFStatus=getActualFinancialClearanceStatusinPanel();
			String expFCPFStatus=getFinancialClearanceStatus(testData);
			if(actaulFCPFStatus.contains(expFCPFStatus)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Panel");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Panel",true);
				verify.append("Failed to verify the Financial Clearance Status in Payment Facilitator Panel");
			}

			String actModuleStatus=getFinancialClearanceModuleStatusinNeedAttention(accountNumber,"Payment Facilitator");
			if(actModuleStatus.contains(expFCPFStatus)){
				report.reportPass("Successfully verified the Financial Clearance Status in Needs Attention");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Needs Attention",true);
				verify.append("Failed to verify the Financial Clearance Status in Needs Attention");
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String getFinancialClearanceModuleStatusinNeedAttention(String accountNumber,String expModuleName){
		String actModuleStatus="";
		try {
			webActions.click(lnk_AccountSearch_Home, "Account Search");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			try {
				webActions.waitForVisibilityOfAllElements(li_AllModuleNameNeedsAttention, "Module Names");
			} catch (Exception e) {
			}
			List<WebElement> moduleName=li_AllModuleNameNeedsAttention;
			for (WebElement webElement : moduleName) {
				String actModuleName=webElement.getText().trim();
				if(actModuleName.contentEquals(expModuleName)){
					actModuleStatus=webElement.findElement(By.tagName("financial-clearance-status")).findElement(By.tagName("img")).getAttribute("src");
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return actModuleStatus;
	}


	public void waitforFCStatusChange(){
		try {
			webActions.waitUntilPresentAndDisplayed(img_FinancialClearanceStatusPaymentFacilitatorPage, "Financial Clearance Status Payment Facilitator Page");
		} catch (Exception e) {
		}
	}

	public ArrayList<String> getActualAmountsAfterSavePayment(){
		ArrayList<String>actSavedAmounts=new ArrayList<String>();
		waitforFCStatusChange();
		actSavedAmounts.add(webActions.waitAndGetText(txt_AdjustedAmount, "Adjusted Amount"));
		actSavedAmounts.add(webActions.waitAndGetText(txt_Paid, "Paid"));
		actSavedAmounts.add(webActions.waitAndGetText(txt_RemainingBalance, "Remaining Balance"));
		return actSavedAmounts;
	}
	public ArrayList<String> getExpectedAmountsAfterSavePayment(DataTable testData){
		ArrayList<String>expSavedAmounts=new ArrayList<String>();
		expSavedAmounts.add(getDatafromMap(testData,"Total Amount"));
		expSavedAmounts.add("0.00");
		expSavedAmounts.add(getDatafromMap(testData,"Total Amount"));
		return expSavedAmounts;
	}

	public ArrayList<String> getExpectedAmountsAfterSavePaymentWithDiscount(DataTable testData){
		ArrayList<String>expSavedAmounts=new ArrayList<String>();
		String adjustedAmount_RemainingBalance=getDiscountAmount(testData);
		expSavedAmounts.add(adjustedAmount_RemainingBalance);
		expSavedAmounts.add("0.00");
		expSavedAmounts.add(adjustedAmount_RemainingBalance);
		return expSavedAmounts;
	}

	public String getFinClearStatusinPaymentFacilitatorPage(){
		String actFCStatusPFPage="";
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitUntilPresentAndDisplayed(img_FinancialClearanceStatusPaymentFacilitatorPage, "Financial Clearance Status Payment Facilitator Page");
			actFCStatusPFPage=webActions.getAttributeValue(img_FinancialClearanceStatusPaymentFacilitatorPage, "src", "Financial Clearance Status Payment Facilitator Page");
		} catch (Exception e) {
		}
		return actFCStatusPFPage;
	}

	public void waitForPanel(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibilityOfAllElements(lbl_PaymentFacilitator_Panel, "Payment Facilitator Panel");
		} catch (Exception e) {
			webActions.waitForVisibilityOfAllElements(tbl_AllPanel, "All Panels");
		}
	}
	public ArrayList<String> getActualLabelNamesinPanel(){
		ArrayList<String> actLabelNames = new ArrayList<String>();
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			waitForPanel();
			actLabelNames = webActions.getDatafromWebTable(lbl_PaymentFacilitator_Panel);
			report.reportInfo("Actual label names in panel: "+actLabelNames);
		} catch (Exception e) {
		}
		return actLabelNames;
	}

	public ArrayList<String> getExpectedLabelNamesinPanel(DataTable testData){
		ArrayList<String>expLabelNames=new ArrayList<String>();
		expLabelNames.add(getDatafromMap(testData,"Payment Type"));
		expLabelNames.add("Amount Collected");
		expLabelNames.add("Remaining Balance"); 
		report.reportInfo("Expected label names in panel: "+expLabelNames);
		return expLabelNames;
	}
	public ArrayList<String> getActualAmountsinPanel(){
		return webActions.getDatafromWebTable(lbl_PaymentFacilitator_Amounts_Panel);
	}
	public String getActualFinancialClearanceStatusinPanel(){
		return webActions.getAttributeValue(img_FinancialClearanceStatus_PaymentFacilitatorPanel, "src", "Payment Facilitator Panel");
	}

	public void waitforPaymentTransactionData(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();	
			webActions.waitForVisibilityOfAllElements(tr_PaymentTransactionRow, "Payment Transaction");
		} catch (Exception e) {
			webActions.waitUntilPresentAndDisplayed(tr_PaymentTransaction, "Payment Transaction");
		}
	}
	public ArrayList<String> getPaymentTransactionData1() throws Exception{
		ArrayList<String> actPaymentTransactionData=new ArrayList<String>();
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			waitforPaymentTransactionData();
			ArrayList<String> paymentTransactionData=webActions.getDatafromWebTable(tr_PaymentTransactionRow);
			report.reportInfo("Payment Transaction All data is: "+paymentTransactionData);
			actPaymentTransactionData.add(paymentTransactionData.get(3));
			actPaymentTransactionData.add(paymentTransactionData.get(5));
			actPaymentTransactionData.add("Approved");
			report.reportInfo("Actaul Payment Transaction data is: "+actPaymentTransactionData);
		} catch (Exception e) {
			throw e;
		}
		return actPaymentTransactionData;
	}

	public ArrayList<String> getPaymentTransactionData() throws Exception{
		ArrayList<String> actPaymentTransactionData=new ArrayList<String>();
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			waitforPaymentTransactionData();
			List<WebElement>row=tr_PaymentTransactionRow;
			for (WebElement webElement : row.subList(1, row.size())) {
				String text=webElement.getText();
				if(!text.isEmpty()){
					actPaymentTransactionData.add(text);
				}
			}
			report.reportInfo("Actaul Payment Transaction data is: "+actPaymentTransactionData);
		} catch (Exception e) {
			throw e;
		}
		return actPaymentTransactionData;
	}

	public ArrayList<String> getExpectedPaymentTransactionData_v1(DataTable testData){
		ArrayList<String> expPaymentTransactionData=new ArrayList<String>();
		expPaymentTransactionData.add("Sale");
		expPaymentTransactionData.add(getDatafromMap(testData,"Payment Memo"));
		expPaymentTransactionData.add(getCurrentDateandTime());
		expPaymentTransactionData.add(getDatafromMap(testData,"Payment"));
		expPaymentTransactionData.add("Approved");
		expPaymentTransactionData.add("Receipt");
		expPaymentTransactionData.add("Reversal");
		report.reportInfo("Expected Payment Transaction data is "+expPaymentTransactionData);
		return expPaymentTransactionData;
	}
	
	public ArrayList<String> getExpectedPaymentTransactionData(DataTable testData){
		ArrayList<String> expPaymentTransactionData=new ArrayList<String>();
		expPaymentTransactionData.add("Sale");
		expPaymentTransactionData.add(getDatafromMap(testData,"Payment"));
		expPaymentTransactionData.add("Approved");
		expPaymentTransactionData.add(getDatafromMap(testData,"Payment Memo"));
		expPaymentTransactionData.add(getCurrentDateandTime());
		expPaymentTransactionData.add("Receipt");
		expPaymentTransactionData.add("Reversal");
		report.reportInfo("Expected Payment Transaction data is "+expPaymentTransactionData);
		return expPaymentTransactionData;
	}

	public ArrayList<String> getExpectedPaymentTransactionData1(DataTable testData){
		ArrayList<String> expPaymentTransactionData=new ArrayList<String>();
		expPaymentTransactionData.add(getDatafromMap(testData,"Payment Memo"));
		expPaymentTransactionData.add(getDatafromMap(testData,"Payment"));
		expPaymentTransactionData.add("Approved");
		report.reportInfo("Expected Payment Transaction data is "+expPaymentTransactionData);
		return expPaymentTransactionData;
	}

	public ArrayList<String> getExpectedPaymentTransactionData_Discount1(DataTable testData){
		ArrayList<String> expPaymentTransactionData=new ArrayList<String>();
		expPaymentTransactionData.add(getDatafromMap(testData,"Payment Memo"));
		expPaymentTransactionData.add(getDiscountAmount(testData));
		expPaymentTransactionData.add("Approved");
		report.reportInfo("Expected Payment Transaction data is "+expPaymentTransactionData);
		return expPaymentTransactionData;
	}

	public ArrayList<String> getExpectedPaymentTransactionData_Discount_V1(DataTable testData){
		ArrayList<String> expPaymentTransactionData=new ArrayList<String>();
		expPaymentTransactionData.add("Sale");
		expPaymentTransactionData.add(getDatafromMap(testData,"Payment Memo"));
		expPaymentTransactionData.add(getCurrentDateandTime());
		//expPaymentTransactionData.add(getDatafromMap(testData,"Payment"));
		expPaymentTransactionData.add(getDiscountAmount(testData));
		expPaymentTransactionData.add("Approved");
		expPaymentTransactionData.add("Receipt");
		expPaymentTransactionData.add("Reversal");
		report.reportInfo("Expected Payment Transaction data is "+expPaymentTransactionData);
		return expPaymentTransactionData;
	}
	
	public ArrayList<String> getExpectedPaymentTransactionData_Discount(DataTable testData){
		ArrayList<String> expPaymentTransactionData=new ArrayList<String>();
		expPaymentTransactionData.add("Sale");
		expPaymentTransactionData.add(getDiscountAmount(testData));
		expPaymentTransactionData.add("Approved");
		expPaymentTransactionData.add(getDatafromMap(testData,"Payment Memo"));
		expPaymentTransactionData.add(getCurrentDateandTime());
		expPaymentTransactionData.add("Receipt");
		expPaymentTransactionData.add("Reversal");
		report.reportInfo("Expected Payment Transaction data is "+expPaymentTransactionData);
		return expPaymentTransactionData;
	}

	public ArrayList<String> getExpectedAmountsinPanel_Discount(DataTable testData){
		ArrayList<String>expAmounts_Panel=new ArrayList<String>();
		expAmounts_Panel.add(getDiscountAmount(testData));
		expAmounts_Panel.add(getDiscountAmount(testData));
		expAmounts_Panel.add("0.00");
		return expAmounts_Panel;
	}

	public ArrayList<String> getExpectedAmountsinPanelandPage(DataTable testData){
		ArrayList<String>expAmounts_Panel=new ArrayList<String>();
		expAmounts_Panel.add(getDatafromMap(testData,"Total Amount"));
		expAmounts_Panel.add(getDatafromMap(testData,"Payment"));
		expAmounts_Panel.add(getRemainingBalance(testData));
		return expAmounts_Panel;
	}
	public void savePaymentwithDiscount(DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			waitforPage();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_PaymentType, getDatafromMap(testData,"Payment Type"), "Payment Type");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(txt_TotalAmount, "Total Amount");
			webActions.sendKeys(txt_TotalAmount, getDatafromMap(testData,"Total Amount"), "Total Amount");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_Discount, getDatafromMap(testData,"Discount"), "Discount");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			clickCalculateAndSaveButtons();
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent=titleContent[1];
			report.reportInfo("Alret message for payment is saved successfully: "+msg);
			if("Data saved successfully.".contains(actContent)){
				report.reportPass("Successfully saved the payment");
			}else{
				report.reportFail("Failed to save the payment",true);
				verify.append("Failed to save the payment");
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			ArrayList<String> actSavedAmounts=getActualAmountsAfterSavePayment();
			ArrayList<String> expSavedAmounts=getExpectedAmountsAfterSavePaymentWithDiscount(testData);
			report.reportInfo("Expected 'Adjusted Amount' 'Paid' 'Remaining Balance' in the Payment Facilitator page: "+expSavedAmounts);
			report.reportInfo("Actual 'Adjusted Amount' 'Paid' 'Remaining Balance' in the Payment Facilitator page: "+actSavedAmounts);
			ArrayList<String> unmatchAmounts=webActions.getUmatchedInArrayComparision(actSavedAmounts, expSavedAmounts);
			if(unmatchAmounts.size()==0){
				report.reportPass("Saved Payment Amounts matched successfully in Payment Facilitator page: "+actSavedAmounts);
			}else{
				report.reportFail("Saved Payment Amounts are not matched in Payment Facilitator page: "+unmatchAmounts,true);
				verify.append("Saved Payment Amounts are not matched in Payment Facilitator page");
			}
			String actFinClearStatus=getFinClearStatusinPaymentFacilitatorPage();
			if(actFinClearStatus.contains("error")){
				report.reportPass("Successfully verified the Financial Clearance Status after save in Payment Facilitator Page");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status after save in Payment Facilitator Page",true);
				verify.append("Failed to verify the Financial Clearance Status after save in Payment Facilitator Page");
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void initiatePaymentwithDiscount(DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibility(chk_PaymentRecord, "Payment Record Check Box");
			webActions.waitAndClick(chk_PaymentRecord, "Payment Record Check Box");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(txt_Payment, "Payment");
			webActions.sendKeys(txt_Payment, getDiscountAmount(testData), "Payment");
			webActions.click(btn_InitiatePayment, "Initiate Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitUntilPresentAndDisplayed(dd_PaymentMethod, "Payment Method");
			webActions.sendKeys(dd_PaymentMethod, getDatafromMap(testData,"Payment Method"), "Payment Method");
			webActions.waitUntilPresentAndDisplayed(txt_PaymentMemo, "Payment Memo");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_PaymentMemo, getDatafromMap(testData,"Payment Memo"), "Payment Memo");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(btn_CollectPayment, "Collect Payment");

			// It will return the parent window name as a String
			String parent=driver.getWindowHandle();

			String InitiatePayment=webActions.waitAndGetText(lbl_InitiatePayment_Popup, "Initiate Payment");
			if("Initiate Payment".contains(InitiatePayment)){
				report.reportPass("Successfully Initiated the Payment: "+InitiatePayment);
			}else{
				report.reportFail("Failed to verify Initiate Payment and message is not matched: "+InitiatePayment,true);
				verify.append("Failed to verify Initiate Payment and message is not matched");
			}

			String paymentSuccess=webActions.waitAndGetText(lbl_PaymentSuccess_Popup, "Success");
			if("Processing Complete".contains(paymentSuccess)){
				report.reportPass("Successfully collected the payment amount: "+paymentSuccess);
			}else{
				report.reportFail("Failed to collect the payment amount and message is not matched:  "+paymentSuccess,true);
				verify.append("Failed to collect the payment amount and message is not matched");
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			driver.switchTo().window(parent);
			ArrayList<String> actPaymentTransactionData=getPaymentTransactionData();
			ArrayList<String> expPaymentTransactionData=getExpectedPaymentTransactionData_Discount(testData);

			ArrayList<String> unmatchTransactionData=webActions.getUmatchedInArrayComparision(actPaymentTransactionData, expPaymentTransactionData);
			if(unmatchTransactionData.size()==0){
				report.reportPass("Payment Transaction data is matched");
			}else{
				report.reportFail("Payment Transaction data is not matched and unmatched data is: "+unmatchTransactionData,true);
				verify.append("Payment Transaction data is not matched");
			}

			ArrayList<String> actPaymentAmountsinPage=getActualAmountsAfterSavePayment();
			ArrayList<String>expAmountsinPage=getExpectedAmountsinPanel_Discount(testData);
			report.reportInfo("Expected Payment Amounts after payment is done in the page: "+expAmountsinPage);
			report.reportInfo("Actual Payment Amounts after payment is done in page: "+actPaymentAmountsinPage);
			ArrayList<String> unmatchPaymentAmountsPage=webActions.getUmatchedInArrayComparision(actPaymentAmountsinPage, expAmountsinPage);
			if(unmatchPaymentAmountsPage.size()==0){
				report.reportPass("Payment Amounts matched successfully after payment is done in page: "+actPaymentAmountsinPage);
			}else{
				report.reportFail("Payment Amounts not matched after payment is done in page: "+unmatchPaymentAmountsPage,true);
				verify.append("Payment Amounts not matched after payment is done in page");
			}

			String actFCStatusPaymentFacilitatorPage=getFinClearStatusinPaymentFacilitatorPage();
			String expFCStatusPaymentFacilitatorPage=getFinancialClearanceStatus(testData);
			if(actFCStatusPaymentFacilitatorPage.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Page");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Page",true);
				verify.append("Failed to verify the Financial Clearance Status in Payment Facilitator Page");
			}

			String accountNumber = getDataFromJSONFile("AccountNumber");
			driver.findElement(By.linkText(accountNumber)).click();

			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			ArrayList<String> actLabelNames=getActualLabelNamesinPanel();

			ArrayList<String> expLabelNames=getExpectedLabelNamesinPanel(testData);

			ArrayList<String> unmatchLabels=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchLabels.size()==0){
				report.reportPass("Label names matched successfully in Panel: "+actLabelNames);
			}else{
				report.reportFail("Label names are not matched in Panel: "+unmatchLabels,true);
				verify.append("Label names are not matched in Panel");
			}

			ArrayList<String> actAmounts_Panel=webActions.getDatafromWebTable(lbl_PaymentFacilitator_Amounts_Panel);

			ArrayList<String>expAmounts_Panel=getExpectedAmountsinPanel_Discount(testData);

			report.reportInfo("Expected Payment Amounts in panel: "+expAmounts_Panel);
			report.reportInfo("Actual Payment Amounts in panel: "+actAmounts_Panel);
			ArrayList<String> unmatchAmounts=webActions.getUmatchedInArrayComparision(actAmounts_Panel, expAmounts_Panel);
			if(unmatchAmounts.size()==0){
				report.reportPass("Payment Amounts matched successfully in Panel: "+actAmounts_Panel);
			}else{
				report.reportFail("Payment Amounts not matched in Panel: "+unmatchAmounts,true);
				verify.append("Payment Amounts not matched in Panel");
			}
			webActions.waitForVisibility(img_FinancialClearanceStatus_PaymentFacilitatorPanel, "FC Payment Facilitator Panel");
			String actFCStatusPFPanel=webActions.getAttributeValue(img_FinancialClearanceStatus_PaymentFacilitatorPanel, "src", "FC Payment Facilitator Panel");
			if(actFCStatusPFPanel.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Panel");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Panel",true);
				verify.append("Failed to verify the Financial Clearance Status in Payment Facilitator Panel");
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void savePaymentwithDiscountandInitiatePayment(DataTable testData){
		try {
			savePaymentwithDiscount(testData);
			initiatePaymentwithDiscount(testData);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}

	public  String getFinancialClearanceStatus(DataTable testData){
		String expFCStatusPF=getDatafromMap(testData, "Financial Clearance Status");
		if(expFCStatusPF.contentEquals("Needs Attention")){
			expFCStatusPF="error";
		}else if(expFCStatusPF.contentEquals("Clear")){
			expFCStatusPF="success";
		}
		return expFCStatusPF;
	}


	public void verifyPatientVisitSummaryInformation(String scenarioName) {
		try {
			ArrayList<String> expData=getListDataFromJSONFile(scenarioName);
			webActions.waitForVisibility(tbl_PatientVisitSummary, "Patient Visit Summary");
			ArrayList<String> actData=webActions.getDatafromWebTable(lbl_PatientVisitSummary);
			report.reportInfo("Expected Patient Visit Summary Information: "+expData);
			report.reportInfo("Actual Patient Visit Summary Information: "+actData);
			ArrayList<String> unMatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unMatch.size()==0){
				report.reportPass("Patient Visit Summary Information verified successfully: "+actData);
			}
			else{
				report.reportFail("Failed to verify the Patient Visit Summary Information, and unmatched data is: "+unMatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyDisplayedBreadcrumb(String menuName,String pageName) {
		try {
			String accountNumber=getDataFromJSONFile("AccountNumber");
			ArrayList<String> expectedBreadcrumbTitles=new ArrayList<String>();
			expectedBreadcrumbTitles.add(pageName);
			expectedBreadcrumbTitles.add(accountNumber);
			expectedBreadcrumbTitles.add(menuName);
			report.reportInfo("Expected Breadcrumb Titles "+expectedBreadcrumbTitles);
			ArrayList<String> actualBreadcrumbTitles = new ArrayList<String>();
			if ("Account Search".contentEquals(pageName)) {
				actualBreadcrumbTitles = webActions.getDatafromWebTable(lbl_Breadcrum);
			}else if("Service Tracker".contentEquals(pageName)){
				actualBreadcrumbTitles = webActions.getDatafromWebTable(lbl_Breadcrum);
			}
			report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumbTitles);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles, expectedBreadcrumbTitles);
			if(unmatch.size()==0){
				report.reportPass("Payment Facilitator Breadcrumb Titles verified successfully, when user navigate from: "+pageName);
			}else{
				report.reportFail("Failed to verify the Payment Facilitator Breadcrumb Titles, when user navigate from: "+pageName+" : and unmatched data: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String getRemainingBalance(DataTable testData){
		String totalAmount=getDatafromMap(testData,"Total Amount");
		String payment=getDatafromMap(testData,"Payment");
		DecimalFormat df = new DecimalFormat("#,##0.00");
		String remainingBalance="";
		double Payment, TotalAmount;
		TotalAmount = Double.parseDouble(totalAmount);
		Payment = Double.parseDouble(payment);
		TotalAmount = TotalAmount - Payment;
		remainingBalance= df.format(TotalAmount);
		return remainingBalance;
	}

	public String getDiscountAmount(DataTable testData){
		String actTotalAmount=getDatafromMap(testData,"Total Amount");
		String actDiscount=getDatafromMap(testData,"Discount");
		String discountType=getDatafromMap(testData,"Discount Type");
		DecimalFormat df = new DecimalFormat("#,##0.00");
		String expDiscountAmount="";
		double discount, discountAmount, totalAmount;
		if (discountType.contentEquals("Percent")) {
			totalAmount = Double.parseDouble(actTotalAmount);
			discount = Double.parseDouble(actDiscount);
			discountAmount = 100 - discount;
			discountAmount = (discountAmount * totalAmount) / 100;
			expDiscountAmount= df.format(discountAmount);
		}
		else if(discountType.contentEquals("Dollar")){
			totalAmount = Double.parseDouble(actTotalAmount);
			actDiscount= actDiscount.replaceAll("\\$","");
			discount = Double.parseDouble(actDiscount);
			discountAmount = (totalAmount - discount);
			expDiscountAmount= df.format(discountAmount);
			return expDiscountAmount;
		}
		return expDiscountAmount;
	}

	public String calculateTwoPaymentAmounts(DataTable testData){
		String payment=getDatafromMap(testData,"Payment");
		String payment1=getDatafromMap(testData,"Payment1");
		DecimalFormat df = new DecimalFormat("#,##0.00");
		String calculatedAmount="";
		double Payment, Payment1;
		Payment = Double.parseDouble(payment);
		Payment1 = Double.parseDouble(payment1);
		Payment = Payment + Payment1;
		calculatedAmount= df.format(Payment);
		return calculatedAmount;
	}

	public String getPaidAmountAfterRefund(DataTable testData){
		String payment=getDatafromMap(testData,"Payment");
		String refundAmount=getDatafromMap(testData,"Refund Amount");
		DecimalFormat df = new DecimalFormat("#,##0.00");
		String paidAmount="";
		double Payment, RefundAmount;
		Payment = Double.parseDouble(payment);
		RefundAmount = Double.parseDouble(refundAmount);
		RefundAmount = Payment - RefundAmount;
		paidAmount= df.format(RefundAmount);
		return paidAmount;
	}
	public String getRemainingBalanceAfterRefund(DataTable testData){
		String totalAmount=getDatafromMap(testData,"Total Amount");
		String paidAmountAfterRefund=getPaidAmountAfterRefund(testData);
		DecimalFormat df = new DecimalFormat("#,##0.00");
		String remainingBalance="";
		double Payment, TotalAmount;
		TotalAmount = Double.parseDouble(totalAmount);
		Payment = Double.parseDouble(paidAmountAfterRefund);
		TotalAmount = TotalAmount - Payment;
		remainingBalance= df.format(TotalAmount);
		return remainingBalance;
	}

	public void multipleAccountPaymentsAndVerifytheDataifSwitchAntherAccount(DataTable testData){
		try {
			savePaymentforMultiple(testData);
			initiateMultiplePayments(testData);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void savePaymentforMultiple(DataTable testData){
		try {
			for (int i = 0; i <=1; i++) {
				waitforPage();
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				String paymentType;
				paymentType=getDatafromMap(testData, "Payment Type");
				if(i==1){
					paymentType=getDatafromMap(testData, "Payment Type1");	
				}
				webActions.sendKeys(dd_PaymentType, paymentType, "Payment Type");
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.click(txt_TotalAmount, "Total Amount");
				String totalAmount;
				totalAmount=getDatafromMap(testData, "Total Amount");
				if(i==1){
					totalAmount=getDatafromMap(testData, "Total Amount1");	
				}
				webActions.sendKeys(txt_TotalAmount,totalAmount, "Total Amount");
				clickCalculateAndSaveButtons();
				String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
				String[] titleContent = msg.split("\\n");
				String actContent = titleContent[1];
				report.reportInfo("Alret message for payment is saved successfully: " + msg);
				if ("Data saved successfully.".contains(actContent)) {
					report.reportPass("Successfully saved the payment");
				} else {
					report.reportFail("Failed to save the payment");
				}
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				if (i==0) {
					webActions.waitForPageLoaded();
					webActions.waitForPageLoaded();
					webActions.click(lnk_AccountNumber_Historical, "AccountNumber Historical");
					webActions.waitForPageLoaded();
					webActions.waitForJSandJQueryToLoad();
					webActions.waitForPageLoaded();
				}
				webActions.waitForPageLoaded();
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void initiateMultiplePayments (DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String accountNumberHistorical=webActions.waitAndGetText(lnk_AccountNumber_Historical, "AccountNumber Historical");
			webActions.click(lnk_AccountNumber_Historical, "AccountNumber Historical");
			webActions.waitForPageLoaded();
			String accountNumberPasentDetails=webActions.waitAndGetText(lbl_AccountNumber_PasentDetails, "AccountNumber PasentDetails");
			if(accountNumberHistorical.contains(accountNumberPasentDetails)){
				report.reportPass("Account Details are matched after switch to another account");	
			}
			else{
				report.reportFail("Account Details are not matched after switch to another account", true);
				verify.append("Account Details are not matched after switch to another account");
			}
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibility(chk_PaymentRecord, "Payment Record Check Box");
			webActions.waitAndClick(chk_PaymentRecord, "Payment Record Check Box");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(txt_Payment, "Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String payment=getDatafromMap(testData,"Payment");
			webActions.sendKeys(txt_Payment, payment, "Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String actCurrentVisitAmount=webActions.waitAndGetText(lbl_CurrentVisitAmount, "CurrentVisitAmount");
			if(actCurrentVisitAmount.contains(getDatafromMap(testData,"Total Amount"))){
				report.reportPass("Successfully verified Amount in Current Visit: "+actCurrentVisitAmount);
			}else{
				report.reportPass("Failed to verify Amount in Current Visit: "+actCurrentVisitAmount,true);
				verify.append("Failed to verify Amount in Current Visit");
			}
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(chk_PaymentRecord_Historical, "Payment Record Check Box Historical");
			webActions.waitAndClick(chk_PaymentRecord_Historical, "Payment Record Check Box Historical");
			webActions.click(txt_Payment_Historical, "Payment Historical");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String paymentHistorical=getDatafromMap(testData,"Payment1");
			String actHistoricalBalanceAmount=webActions.waitAndGetText(lbl_HistoricalBalanceAmount, "HistoricalBalanceAmount");
			if(actHistoricalBalanceAmount.contains(getDatafromMap(testData,"Total Amount1"))){
				report.reportPass("Successfully verified Amount in Historical Visit: "+actHistoricalBalanceAmount);
			}else{
				report.reportPass("Failed to verify Amount in Historical Visit: "+actHistoricalBalanceAmount,true);
				verify.append("Failed to verify Amount in Historical Visit");
			}
			webActions.sendKeys(txt_Payment_Historical, paymentHistorical, "Payment Historical");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String calculatedPayment=calculateTwoPaymentAmounts(testData);
			webActions.click(lbl_PaymentFacilitatorTitle, "Payment Title");
			String actItemSelectedAmount=webActions.waitAndGetText(lbl_ItemSelectedAmount, "Item Selected Amount");
			String expItemSelectedAmount="2 Item Selected $"+calculatedPayment;
			if(actItemSelectedAmount.contains(expItemSelectedAmount)){
				report.reportPass("Successfully verified no of items selected and amount: "+actItemSelectedAmount);
			}
			else{
				report.reportFail("Failed to verify no of items selected and amount: "+actItemSelectedAmount,true);
				verify.append("Failed to verify no of items selected and amount");
			}
			webActions.click(btn_InitiatePayment, "Initiate Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String actPaymentAmount=webActions.waitAndGetText(lbl_PaymentAmount_CollectPaymentModal, "Payment Amount in Collect Payment Modal");
			if(actPaymentAmount.contains("$"+calculatedPayment)){
				report.reportPass("Successfully verified the Payment amount in collect payment modal window"+actPaymentAmount);
			}else{
				report.reportFail("Failed to verify the Payment amount in collect payment modal window: "+actItemSelectedAmount,true);
				verify.append("Failed to verify the Payment amount in collect payment modal window");
			}
			webActions.waitUntilPresentAndDisplayed(dd_PaymentMethod, "Payment Method");
			webActions.sendKeys(dd_PaymentMethod, getDatafromMap(testData,"Payment Method"), "Payment Method");
			webActions.waitUntilPresentAndDisplayed(txt_PaymentMemo, "Payment Memo");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_PaymentMemo, getDatafromMap(testData,"Payment Memo"), "Payment Memo");

			webActions.click(btn_CollectPayment, "Collect Payment");

			// It will return the parent window name as a String
			String parent=driver.getWindowHandle();

			String InitiatePayment=webActions.waitAndGetText(lbl_InitiatePayment_Popup, "InitiatePayment");

			if("Initiate Payment".contains(InitiatePayment)){
				report.reportPass("Successfully Initiated the Payment: "+InitiatePayment);
			}else{
				report.reportFail("Failed to verify Initiate Payment and message is not matched: "+InitiatePayment,true);
				verify.append("Failed to verify Initiate Payment and message is not matched");
			}

			String paymentSuccess=webActions.waitAndGetText(lbl_PaymentSuccess_Popup, "Success");

			if("Processing Complete".contains(paymentSuccess)){
				report.reportPass("Successfully collected the payment amount: "+paymentSuccess);
			}else{
				report.reportFail("Failed to collect the payment amount and message is not matched:  "+paymentSuccess,true);
				verify.append("Failed to collect the payment amount and message is not matched"); 
			}

			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			driver.switchTo().window(parent);

			ArrayList<String> actPaymentTransactionData=getPaymentTransactionData();

			ArrayList<String> expPaymentTransactionData=getExpectedPaymentTransactionData(testData);

			ArrayList<String> unmatchTransactionData=webActions.getUmatchedInArrayComparision(actPaymentTransactionData, expPaymentTransactionData);
			if(unmatchTransactionData.size()==0){
				report.reportPass("Payment Transaction data is matched: "+actPaymentTransactionData);
			}else{
				report.reportFail("Payment Transaction data is not matched and unmatched data is: "+unmatchTransactionData,true);
				verify.append("Payment Transaction data is not matched"); 
			}
			String actFCStatusPaymentFacilitatorPage=getFinClearStatusinPaymentFacilitatorPage();
			String expFCStatusPaymentFacilitatorPage=getFinancialClearanceStatus(testData);
			if(actFCStatusPaymentFacilitatorPage.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Page");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Page",true);
				verify.append("Failed to verify the Financial Clearance Status in Payment Facilitator Page"); 
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void savePaymentWithoutValidations(DataTable testData){
		try {
			waitforPage();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_PaymentType, getDatafromMap(testData,"Payment Type"), "Payment Type");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(txt_TotalAmount, "Total Amount");
			webActions.sendKeys(txt_TotalAmount, getDatafromMap(testData,"Total Amount"), "Total AMount");
			clickCalculateAndSaveButtons();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			waitforFCStatusChange();
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void initiatePaymentWithoutValidations(DataTable testData){
		try {
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibility(chk_PaymentRecord, "Payment Record Check Box");
			webActions.waitAndClick(chk_PaymentRecord, "Payment Record Check Box");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(txt_Payment, "Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_Payment, getDatafromMap(testData,"Payment"), "Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(btn_InitiatePayment, "Initiate Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitUntilPresentAndDisplayed(dd_PaymentMethod, "Payment Method");
			webActions.sendKeys(dd_PaymentMethod, getDatafromMap(testData,"Payment Method"), "Payment Method");
			webActions.waitUntilPresentAndDisplayed(txt_PaymentMemo, "Payment Memo");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_PaymentMemo, getDatafromMap(testData,"Payment Memo"), "Payment Memo");
			webActions.click(btn_CollectPayment, "Collect Payment");

			// It will return the parent window name as a String
			String parent=driver.getWindowHandle();

			String InitiatePayment=webActions.waitAndGetText(lbl_InitiatePayment_Popup, "InitiatePayment");

			if("Initiate Payment".contains(InitiatePayment)){
				report.reportPass("Successfully Initiated the Payment: "+InitiatePayment);
			}else{
				report.reportFail("Failed to verify Initiate Payment and message is not matched: "+InitiatePayment,true);
			}

			String paymentSuccess=webActions.waitAndGetText(lbl_PaymentSuccess_Popup, "Success");
			webActions.waitForPageLoaded();
			if("Processing Complete".contains(paymentSuccess)){
				report.reportPass("Successfully collected the payment amount: "+paymentSuccess);
			}else{
				report.reportFail("Failed to collect the payment amount and message is not matched:  "+paymentSuccess,true);
			}
			webActions.waitForPageLoaded();
			driver.switchTo().window(parent);
			webActions.waitForPageLoaded();
			waitforPaymentTransactionData();
			webActions.waitAndClick(lbl_PaymentFacilitatorTitle, "PaymentFacilitatorTitle");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void savePaymentandInitiatePaymentWithoutValidations(DataTable testData){
		try {
			savePaymentWithoutValidations(testData);
			initiatePaymentWithoutValidations(testData);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyFieldsNamesinReversePayment(DataTable feilds){
		try {
			List<String> expFeilds = feilds.asList(String.class);
			ArrayList<String>actFeilds =new ArrayList<String>();
			webActions.waitAndClick(btn_Reversal, "Reversal");
			actFeilds.add(webActions.waitAndGetText(lbl_ReversePaymentTitle, "Reverse Payment Title"));
			List<WebElement>web=lbl_ReversePaymentFeilds;
			for (WebElement webElement : web) {
				String text=webElement.getText();
				if(!text.isEmpty()){
					actFeilds.add(text);
				}
			}
			actFeilds.add(webActions.getText(btn_Cancel_Reversal, "Cancel"));
			actFeilds.add(webActions.getText(btn_Submit_Reversal, "Submit"));
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actFeilds, expFeilds);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Fields in Reverse Payment window: "+actFeilds);
			}else{
				report.reportFail("Failed to verify the Fields in Reverse Payment window: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e,true);
		}
	}

	public void verifyValidationMessagesinReversePayment(DataTable messages){
		try {
			List<String> expMessages = messages.asList(String.class);
			webActions.click(btn_Submit_Reversal, "Submit");
			webActions.click(txt_PaymentMemo_Reversal, "Payment Memo");
			webActions.sendKeys(txt_PaymentMemo_Reversal,"@#$%^&*", "Payment Memo");
			ArrayList<String>actMessages=new ArrayList<String>();
			actMessages.add(webActions.waitAndGetText(lbl_AmountValidation_Reversal, "Amount Validation"));
			actMessages.add(webActions.waitAndGetText(lbl_PaymentMemoValidation_Reversal, "Payment Memo Validation"));
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actMessages, expMessages);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the validation messages in Reverse Payment window: "+actMessages);
			}else{
				report.reportFail("Failed to verify the validation messages in Reverse Payment window: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void reversePaymentandVerifyData(DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			savePaymentandInitiatePaymentWithoutValidations(testData);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_Reversal, "Reversal");
			webActions.waitAndClick(txt_RefundAmount, "Refund Amount");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_RefundAmount,getDatafromMap(testData,"Refund Amount"), "Refund Amount");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_PaymentMemo_Reversal,getDatafromMap(testData,"Reverse Payment Memo"), "Payment Memo");
			webActions.click(btn_Submit_Reversal, "Submit");
			String parent=driver.getWindowHandle();
			String actProcessingMessage=webActions.waitAndGetText(lbl_InitiatePayment_Popup, "Processing Reversal Payment");
			if("Processing Reversal...".contains(actProcessingMessage)){
				report.reportPass("Successfully Processing Reversal payment: "+actProcessingMessage);
			}else{
				report.reportFail("Failed to Processing Reversal payment: "+actProcessingMessage,true);
				verify.append("Failed to Processing Reversal payment");
			}

			String actCompletedMessage=webActions.waitAndGetText(lbl_PaymentSuccess_Popup, "Success Reversal Payment");

			if("Reversal Completed Successfully..".contains(actCompletedMessage)){
				report.reportPass(actCompletedMessage);
			}else{
				report.reportFail("Failed to the verify the Reversal Payment: "+actCompletedMessage,true);
				verify.append("Failed to the verify the Reversal Payment");
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			driver.switchTo().window(parent);
			waitforPaymentTransactionData();

			ArrayList<String> actAmounts=getActualAmountsAfterSavePayment();
			ArrayList<String> expAmounts=getExpectedAmountsAfterRefund(testData);
			report.reportInfo("Expected Payment Amounts after Refund the payment: "+expAmounts);
			report.reportInfo("Actual Payment Amounts after Refund the payment: "+actAmounts);
			ArrayList<String> unmatchAmounts=webActions.getUmatchedInArrayComparision(actAmounts, expAmounts);
			if(unmatchAmounts.size()==0){
				report.reportPass("Payment Amounts matched successfully after payment is done in page: "+actAmounts);
			}else{
				report.reportFail("Payment Amounts not matched after payment is done in page: "+unmatchAmounts,true);
				verify.append("Payment Amounts not matched after payment is done in page");
			}
			ArrayList<String>actRefundTransactionData=getActualRefundTransactionData();
			ArrayList<String>expRefundTransactionData=getExpectedRefundTransactionData(testData);
			ArrayList<String> unmatchTransactionData=webActions.getUmatchedInArrayComparision(actRefundTransactionData, expRefundTransactionData);
			if(unmatchTransactionData.size()==0){
				report.reportPass("Payment Refund Transaction data is matched: "+actRefundTransactionData);
			}else{
				report.reportFail("Payment Refund Transaction data is not matched and unmatched data is: "+unmatchTransactionData,true);
				verify.append("Payment Refund Transaction data is not matched");
			}
			String actFCStatusPaymentFacilitatorPage=getFinClearStatusinPaymentFacilitatorPage();
			String expFCStatusPaymentFacilitatorPage=getFinancialClearanceStatus(testData);
			if(actFCStatusPaymentFacilitatorPage.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Page after Refund the Amount");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Page after Refund the Amount",true);
				verify.append("Payment Refund Transaction data is not matched");
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void savePaymentinCurrentVistandClickNewAccountinHistoricalVisitSection(DataTable testData){
		try {
			waitforPage();
			String paymentType;
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			paymentType=getDatafromMap(testData, "Payment Type");
			webActions.sendKeys(dd_PaymentType, paymentType, "Payment Type");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(txt_TotalAmount, "Total Amount");
			String totalAmount;
			totalAmount=getDatafromMap(testData, "Total Amount");
			webActions.sendKeys(txt_TotalAmount,totalAmount, "Total Amount");
			clickCalculateAndSaveButtons();
			webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			waitforFCStatusChange();
			webActions.click(lnk_AccountNumber_Historical, "AccountNumber Historical");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void initiatePaymentfromHistoricalVisitSection (DataTable testData){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibility(chk_PaymentRecord_Historical, "Payment Record Check Box Historical");
			webActions.waitAndClick(chk_PaymentRecord_Historical, "Payment Record Check Box Historical");
			verifyAmountsandHeaderNamesinHistoricalVisitSectionandPopup(testData);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(txt_Payment_Historical, "Payment Historical");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_Payment_Historical, getDatafromMap(testData,"Payment"), "Payment Historical");
			webActions.waitForPageLoaded();
			webActions.click(btn_InitiatePayment, "Initiate Payment");
			webActions.waitForPageLoaded();
			webActions.waitUntilPresentAndDisplayed(dd_PaymentMethod, "Payment Method");
			webActions.sendKeys(dd_PaymentMethod, getDatafromMap(testData,"Payment Method"), "Payment Method");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitUntilPresentAndDisplayed(txt_PaymentMemo, "Payment Memo");
			webActions.sendKeys(txt_PaymentMemo, getDatafromMap(testData,"Payment Memo"), "Payment Memo");
			webActions.click(btn_CollectPayment, "Collect Payment");
			verifyInitiatePaymentProcess();
			verifyAmountsinHistoricalVisitSectionandPopupAfterPayment(testData);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyInitiatePaymentProcess(){
		try {
			// It will return the parent window name as a String
			String parent=driver.getWindowHandle();

			String InitiatePayment=webActions.waitAndGetText(lbl_InitiatePayment_Popup, "InitiatePayment");

			if("Initiate Payment".contains(InitiatePayment)){
				report.reportPass("Successfully Initiated the Payment: "+InitiatePayment);
			}else{
				report.reportFail("Failed to verify Initiate Payment and message is not matched: "+InitiatePayment,true);
			}

			String paymentSuccess=webActions.waitAndGetText(lbl_PaymentSuccess_Popup, "Success");

			if("Processing Complete".contains(paymentSuccess)){
				report.reportPass("Successfully collected the payment amount: "+paymentSuccess);
			}else{
				report.reportFail("Failed to collect the payment amount and message is not matched:  "+paymentSuccess,true);
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			driver.switchTo().window(parent);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyAmountsandHeaderNamesinHistoricalVisitSectionandPopup(DataTable testData){
		try {
			webActions.waitAndGetText(lnk_AccountNumber_Historical, "AccountNumber Historical");
			ArrayList<String> actualAmounts=getActualAmountValuesinHistoricalVisitSection();
			ArrayList<String> expectedAmounts=getExpectedAmountValuesinHistoricalVisitSection(testData);
			ArrayList<String>unmatchAmountsHistoricalVisitSection=webActions.getUmatchedInArrayComparision(actualAmounts, expectedAmounts);
			if(unmatchAmountsHistoricalVisitSection.size()==0){
				report.reportPass("Successfully verified saved amounts in Historical Visit Section:");
			}
			else{
				report.reportFail("Failed to verify the saved amounts in Historical Visit Section"+unmatchAmountsHistoricalVisitSection, true);
			}
			webActions.waitUntilPresentAndDisplayed(lnk_HistoricalModalDialogOpen, "Historical Modal Dialog Open link");
			webActions.click(lnk_HistoricalModalDialogOpen, "Historical Modal Dialog Open link");
			ArrayList<String> actualHeaderNames=getActualHeaderNamesHistoricalVisitPopup();
			ArrayList<String> expectedHeaderNames=getExpectedHeaderNamesHistoricalVisitPopup(testData);
			ArrayList<String>unMatchHeaderNamesHistoricalVisitPopup=webActions.getUmatchedInArrayComparision(actualHeaderNames, expectedHeaderNames);
			if(unMatchHeaderNamesHistoricalVisitPopup.size()==0){
				report.reportPass("Successfully verified Header Names in Historical Visit popup:");
			}else{
				report.reportFail("Failed to verify Header Names in Historical Visit popup: "+unMatchHeaderNamesHistoricalVisitPopup, true);
			}
			ArrayList<String> actualAmountValuesinHistoricalVisitPopup=getActualAmountValuesinHistoricalVisitPopup();
			ArrayList<String> expectedAmountValuesinHistoricalVisitPopup=getExpectedAmountValuesinHistoricalVisitPopup(testData);

			ArrayList<String>unMatchAmountValuesinHistoricalVisitPopup=webActions.getUmatchedInArrayComparision(actualAmountValuesinHistoricalVisitPopup, expectedAmountValuesinHistoricalVisitPopup);
			if(unMatchAmountValuesinHistoricalVisitPopup.size()==0){
				report.reportPass("Successfully verified Amount values in Historical Visit popup:");
			}else{
				report.reportFail("Failed to verify Amount values in Historical Visit popup: "+unMatchAmountValuesinHistoricalVisitPopup, true);
			}
			webActions.click(btn_CloseX_HistoricalVisitSectionPopup, "Close");
		} catch (Exception e) {
			webActions.click(btn_CloseX_HistoricalVisitSectionPopup, "Close");
			report.reportFail(""+e, true);
		}
	}

	public void verifyAmountsinHistoricalVisitSectionandPopupAfterPayment(DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			ArrayList<String> actualAmounts=getActualAmountValuesinHistoricalVisitSection();
			ArrayList<String> expectedAmounts=getExpectedAmountValuesinHistoricalVisitSectionAfterPayment(testData);
			ArrayList<String>unmatchAmountsHistoricalVisitSection=webActions.getUmatchedInArrayComparision(actualAmounts, expectedAmounts);
			if(unmatchAmountsHistoricalVisitSection.size()==0){
				report.reportPass("Successfully verified amounts in Historical Visit Section after payment:");
			}
			else{
				report.reportFail("Failed to verify the amounts in Historical Visit Section after payment: "+unmatchAmountsHistoricalVisitSection, true);
				unmatch.append("Failed to verify the amounts in Historical Visit Section after payment");
			}
			webActions.waitUntilPresentAndDisplayed(lnk_HistoricalModalDialogOpen, "Historical Modal Dialog Open link");
			webActions.click(lnk_HistoricalModalDialogOpen, "Historical Modal Dialog Open link");

			ArrayList<String> actualAmountsinHistoricalVisitPopup=getActualAmountValuesinHistoricalVisitPopup();
			ArrayList<String> expectedAmountsinHistoricalVisitPopup=getExpectedAmountValuesinHistoricalVisitPopupAfterPayment(testData);

			ArrayList<String>unMatchAmountinHistoricalVisitPopup=webActions.getUmatchedInArrayComparision(actualAmountsinHistoricalVisitPopup, expectedAmountsinHistoricalVisitPopup);
			if(unMatchAmountinHistoricalVisitPopup.size()==0){
				report.reportPass("Successfully verified Amounts in Historical Visit popup after payment:");
			}else{
				report.reportFail("Failed to verify Amount values in Historical Visit popup after payment: "+unMatchAmountinHistoricalVisitPopup, true);
				unmatch.append("Failed to verify Amount values in Historical Visit popup after payment");
			}
			ArrayList<String>actTransactionDatainHistoricalVisitPopup=getActualPaymentTransactionDatainHistoricalVisitPopup();
			ArrayList<String>expTransactionDatainHistoricalVisitPopup=getExpectedPaymentTransactionDatainHistoricalVisitPopup(testData);
			ArrayList<String>unMatchPaymentTransactionDatainHistoricalVisitPopup=webActions.getUmatchedInArrayComparision(actTransactionDatainHistoricalVisitPopup, expTransactionDatainHistoricalVisitPopup);
			if(unMatchPaymentTransactionDatainHistoricalVisitPopup.size()==0){
				report.reportPass("Successfully verified Payment transaction data in Historical Visit popup:");
			}else{
				report.reportFail("Failed to verify Payment transaction data in Historical Visit popup: "+unMatchPaymentTransactionDatainHistoricalVisitPopup, true);
				unmatch.append("Failed to verify Payment transaction data in Historical Visit popup");
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e, true);
		}
	}

	public void verifyAmountsAfterReversePaymentinHistoricalVistandPopup(DataTable testData){
		try {
			ArrayList<String> actualAmountValuesinHistoricalVisitPopup=getActualAmountValuesinHistoricalVisitPopup();
			ArrayList<String> expectedAmountValuesinHistoricalVisitPopup=getExpectedAmountsAfterRefundinHistoricalVisitPopup(testData);

			ArrayList<String>unMatchAmountValuesinHistoricalVisitPopup=webActions.getUmatchedInArrayComparision(actualAmountValuesinHistoricalVisitPopup, expectedAmountValuesinHistoricalVisitPopup);
			if(unMatchAmountValuesinHistoricalVisitPopup.size()==0){
				report.reportPass("Successfully verified Amount values in Historical Visit popup after Reverse Payment:");
			}else{
				report.reportFail("Failed to verify Amount values in Historical Visit popup Reverse Payment: "+unMatchAmountValuesinHistoricalVisitPopup, true);
			}

			ArrayList<String>actTransactionDatainHistoricalVisitPopup=getActualPaymentTransactionDatainHistoricalVisitPopup();
			ArrayList<String>expTransactionDatainHistoricalVisitPopup=getExpectedPaymentTransactionDatainHistoricalVisitPopupAfterRefund(testData);
			ArrayList<String>unMatchPaymentTransactionDatainHistoricalVisitPopup=webActions.getUmatchedInArrayComparision(actTransactionDatainHistoricalVisitPopup, expTransactionDatainHistoricalVisitPopup);
			if(unMatchPaymentTransactionDatainHistoricalVisitPopup.size()==0){
				report.reportPass("Successfully verified Payment transaction data in Historical Visit popup after Refund amount:");
			}else{
				report.reportFail("Failed to verify Payment transaction data in Historical Visit popup after Refund amount: "+unMatchPaymentTransactionDatainHistoricalVisitPopup, true);
			}

			ArrayList<String>actRefundTransactionData=getActualRefundTransactionData();
			ArrayList<String>expRefundTransactionData=getExpectedRefundTransactionData(testData);
			ArrayList<String> unmatchTransactionData=webActions.getUmatchedInArrayComparision(actRefundTransactionData, expRefundTransactionData);
			if(unmatchTransactionData.size()==0){
				report.reportPass("Payment Refund Transaction data is matched:");
			}else{
				report.reportFail("Payment Refund Transaction data is not matched and unmatched data is: "+unmatchTransactionData,true);
			}
			webActions.click(btn_CloseX_HistoricalVisitSectionPopup, "Close");
			ArrayList<String>actAmountsAfterRefundinHistoricalVisit=getActualAmountValuesinHistoricalVisitSection();
			ArrayList<String>expAmountsAfterRefundinHistoricalVisit=getExpectedAmountsAfterRefundinHistoricalVisitSection(testData);
			ArrayList<String>unmatchAmountsHistoricalVisitSection=webActions.getUmatchedInArrayComparision(actAmountsAfterRefundinHistoricalVisit, expAmountsAfterRefundinHistoricalVisit);
			if(unmatchAmountsHistoricalVisitSection.size()==0){
				report.reportPass("Successfully verified amounts in Historical Visit Section after Reverse Payment:");
			}
			else{
				report.reportFail("Failed to verify the amounts in Historical Visit Section after Reverse Payment: "+unmatchAmountsHistoricalVisitSection, true);
			}
		} catch (Exception e) {
			report.reportFail(""+e, true);
		}

	}

	public void reversePayment(DataTable testData){
		try {
			webActions.waitAndClick(btn_Reversal, "Reversal");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(txt_RefundAmount_Historical, "Refund Amount");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_RefundAmount_Historical,getDatafromMap(testData,"Refund Amount"), "Refund Amount");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			//webActions.waitForPageLoaded();
			//webActions.pressTab();
			webActions.waitAndClick(txt_PaymentMemo_Reversal_Historical, "Reverse Payment Memo");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_PaymentMemo_Reversal_Historical,getDatafromMap(testData,"Reverse Payment Memo"), "Payment Memo");
			webActions.waitForPageLoaded();
			webActions.click(btn_Submit_Reversal_Historical, "Submit");
			String parent=driver.getWindowHandle();
			webActions.waitForPageLoaded();
			driver.switchTo().window(parent);
			webActions.waitForPageLoaded();
			verifyAmountsAfterReversePaymentinHistoricalVistandPopup(testData);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(lnk_AccountNumber_Historical, "AccountNumber Historical");
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibility(lbl_CurrentVisitAmt, "CurrentVisitAmt", 10);
			} catch (Exception e) {
			}
			String actFinClearStatus=getFinClearStatusinPaymentFacilitatorPage();
			String expFinClearStatus=getFinancialClearanceStatus(testData);
			if(actFinClearStatus.contains(expFinClearStatus)){

				report.reportPass("Successfully verifed the Financial Clearance Status after refund in Payment Facilitator Page");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status after refund in Payment Facilitator Page");
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyReversePaymentfromHistoricalVisitSection(DataTable testData){
		try {
			savePaymentinCurrentVistandClickNewAccountinHistoricalVisitSection(testData);
			initiatePaymentfromHistoricalVisitSection(testData);
			reversePayment(testData);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ArrayList<String> getActualAmountValuesinHistoricalVisitSection() throws Exception{
		ArrayList<String> amountValues=new ArrayList<String>();
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibilityOfAllElements(lbl_AmountValues_HistoricalVisitSection, "Amount Values in History");
			List<WebElement>amounts=lbl_AmountValues_HistoricalVisitSection;
			for (WebElement webElement : amounts) {
				String amount=webElement.getText();
				if(!amount.isEmpty()){
					amountValues.add(amount);
				}
			}
			report.reportInfo("Actaul Amount Values in Historical Visit Section: "+amountValues);
		} catch (Exception e) {
			throw e;
		}
		return amountValues;
	}

	public ArrayList<String> getExpectedAmountValuesinHistoricalVisitSection(DataTable testData){
		ArrayList<String>expSavedAmounts=new ArrayList<String>();
		expSavedAmounts.add(webActions.waitAndGetText(lnk_AccountNumber_Historical, "AccountNumber Historical"));
		expSavedAmounts.add(getDatafromMap(testData,"Total Amount"));
		expSavedAmounts.add("0.00");
		expSavedAmounts.add(getDatafromMap(testData,"Total Amount"));
		expSavedAmounts.add("0.00");
		expSavedAmounts.add(getDatafromMap(testData,"Total Amount"));
		expSavedAmounts.add(getDatafromMap(testData,"Tenant"));
		expSavedAmounts.add(getCurrentDateandTime());
		report.reportInfo("Expected Amount Values in Historical Visit Section: "+expSavedAmounts);
		return expSavedAmounts;
	}

	public ArrayList<String> getExpectedAmountValuesinHistoricalVisitSectionAfterPayment(DataTable testData){
		ArrayList<String>expSavedAmounts=new ArrayList<String>();
		expSavedAmounts.add(webActions.waitAndGetText(lnk_AccountNumber_Historical, "AccountNumber Historical"));
		expSavedAmounts.add(getDatafromMap(testData,"Total Amount"));
		expSavedAmounts.add("0.00");
		expSavedAmounts.add(getDatafromMap(testData,"Total Amount"));
		expSavedAmounts.add(getDatafromMap(testData,"Payment"));
		expSavedAmounts.add(getRemainingBalance(testData));
		expSavedAmounts.add(getDatafromMap(testData,"Tenant"));
		expSavedAmounts.add(getCurrentDateandTime());
		report.reportInfo("Expected Amount Values in Historical Visit Section after payment: "+expSavedAmounts);
		return expSavedAmounts;
	}
	public ArrayList<String> getActualHeaderNamesHistoricalVisitPopup() throws Exception{
		ArrayList<String> headerNames=new ArrayList<String>();
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibilityOfAllElements(lbl_HeaderNames_HistoricalVisitSectionPopup, "Amounts in Popup");
			headerNames=webActions.getDatafromWebTable(lbl_HeaderNames_HistoricalVisitSectionPopup);
			report.reportInfo("Actaul Header names in Historical Visit Popup: "+headerNames);
		} catch (Exception e) {
			throw e;
		}
		return headerNames;
	}

	public ArrayList<String> getExpectedHeaderNamesHistoricalVisitPopup(DataTable testData){
		ArrayList<String>expHeaderNames=new ArrayList<String>();
		expHeaderNames.add(getDatafromMap(testData,"Tenant"));
		expHeaderNames.add(getDatafromMap(testData,"Payment Type"));
		expHeaderNames.add("Discount");
		expHeaderNames.add("Adjusted Amount");
		expHeaderNames.add("Paid");
		expHeaderNames.add("Remaining Balance");
		report.reportInfo("Expected Header Names Historical Visit Popup: "+expHeaderNames);
		return expHeaderNames;
	}

	public ArrayList<String> getActualAmountValuesinHistoricalVisitPopup() throws Exception{
		ArrayList<String> amountValues=new ArrayList<String>();
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibilityOfAllElements(lbl_AmountValues_HistoricalVisitSectionPopup, "Amounts in Popup");
			amountValues=webActions.getDatafromWebTable(lbl_AmountValues_HistoricalVisitSectionPopup);
			report.reportInfo("Actaul Amount Values in Historical Visit Popup: "+amountValues);
		} catch (Exception e) {
			throw e;
		}
		return amountValues;
	}

	public ArrayList<String> getExpectedAmountValuesinHistoricalVisitPopup(DataTable testData){
		ArrayList<String>expAmounts=new ArrayList<String>();
		expAmounts.add(getCurrentDateandTime());
		expAmounts.add(getDatafromMap(testData,"Total Amount"));
		expAmounts.add("0.00");
		expAmounts.add(getDatafromMap(testData,"Total Amount"));
		expAmounts.add("0.00");
		expAmounts.add(getDatafromMap(testData,"Total Amount"));
		report.reportInfo("Expected Amount Values in Historical Visit popup: "+expAmounts);
		return expAmounts;
	}

	public ArrayList<String> getExpectedAmountValuesinHistoricalVisitPopupAfterPayment(DataTable testData){
		ArrayList<String>expAmounts=new ArrayList<String>();
		expAmounts.add(getCurrentDateandTime());
		expAmounts.add(getDatafromMap(testData,"Total Amount"));
		expAmounts.add("0.00");
		expAmounts.add(getDatafromMap(testData,"Total Amount"));
		expAmounts.add(getDatafromMap(testData,"Payment"));
		expAmounts.add(getRemainingBalance(testData));
		report.reportInfo("Expected Amount Values in Historical Visit popup after payment: "+expAmounts);
		return expAmounts;
	}

	public ArrayList<String> getActualPaymentTransactionDatainHistoricalVisitPopup() throws Exception{
		ArrayList<String> actPaymentTransactionData=new ArrayList<String>();
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			waitforPaymentTransactionData();
			List<WebElement>row=tr_PaymentTransactionRow;
			for (WebElement webElement : row.subList(3, row.size())) {
				String text=webElement.getText();
				if(!text.isEmpty()){
					actPaymentTransactionData.add(text);
				}
			}
			report.reportInfo("Actaul Payment Transaction data in Historical Visit popup after payment: "+actPaymentTransactionData);
		} catch (Exception e) {
			throw e;
		}
		return actPaymentTransactionData;
	}

	public ArrayList<String> getExpectedPaymentTransactionDatainHistoricalVisitPopup(DataTable testData){
		ArrayList<String> expPaymentTransactionData=new ArrayList<String>();
		expPaymentTransactionData.add("Sale");
		expPaymentTransactionData.add(getDatafromMap(testData,"Payment Memo"));
		expPaymentTransactionData.add(getCurrentDateandTime());
		expPaymentTransactionData.add(getDatafromMap(testData,"Payment"));
		expPaymentTransactionData.add("Approved");
		expPaymentTransactionData.add("Receipt");
		expPaymentTransactionData.add("Reversal");
		report.reportInfo("Expected Payment Transaction data in Historical Visit popup after payment: "+expPaymentTransactionData);
		return expPaymentTransactionData;
	}

	public ArrayList<String> getExpectedPaymentTransactionDatainHistoricalVisitPopupAfterRefund(DataTable testData){
		ArrayList<String> expPaymentTransactionData=new ArrayList<String>();
		expPaymentTransactionData.add("Sale");
		expPaymentTransactionData.add(getDatafromMap(testData,"Payment Memo"));
		expPaymentTransactionData.add(getCurrentDateandTime());
		expPaymentTransactionData.add(getDatafromMap(testData,"Payment"));
		expPaymentTransactionData.add("Approved");
		expPaymentTransactionData.add("Receipt");
		String refundType=getDatafromMap(testData,"Refund Type");
		if("Partial".contentEquals(refundType)){
			expPaymentTransactionData.add("Reversal");
		}
		report.reportInfo("Expected Payment Transaction data in Historical Visit popup after refund: "+expPaymentTransactionData);
		return expPaymentTransactionData;
	}


	public ArrayList<String> getExpectedAmountsAfterRefund(DataTable testData){
		ArrayList<String>expAmounts_Panel=new ArrayList<String>();
		expAmounts_Panel.add(getDatafromMap(testData,"Total Amount"));
		expAmounts_Panel.add(getPaidAmountAfterRefund(testData));
		expAmounts_Panel.add(getRemainingBalanceAfterRefund(testData));
		return expAmounts_Panel;
	}
	public ArrayList<String> getExpectedAmountsAfterRefundinHistoricalVisitSection(DataTable testData){
		ArrayList<String>expSavedAmounts=new ArrayList<String>();
		expSavedAmounts.add(webActions.waitAndGetText(lnk_AccountNumber_Historical, "AccountNumber Historical"));
		expSavedAmounts.add(getDatafromMap(testData,"Total Amount"));
		expSavedAmounts.add("0.00");
		expSavedAmounts.add(getDatafromMap(testData,"Total Amount"));
		expSavedAmounts.add(getPaidAmountAfterRefund(testData));
		expSavedAmounts.add(getRemainingBalanceAfterRefund(testData));
		expSavedAmounts.add(getDatafromMap(testData,"Tenant"));
		expSavedAmounts.add(getCurrentDateandTime());
		report.reportInfo("Expected Amount Values in Historical Visit Section after refund: "+expSavedAmounts);
		return expSavedAmounts;
	}

	public ArrayList<String> getExpectedAmountsAfterRefundinHistoricalVisitPopup(DataTable testData){
		ArrayList<String>expSavedAmounts=new ArrayList<String>();
		expSavedAmounts.add(getCurrentDateandTime());
		expSavedAmounts.add(getDatafromMap(testData,"Total Amount"));
		expSavedAmounts.add("0.00");
		expSavedAmounts.add(getDatafromMap(testData,"Total Amount"));
		expSavedAmounts.add(getPaidAmountAfterRefund(testData));
		expSavedAmounts.add(getRemainingBalanceAfterRefund(testData));
		report.reportInfo("Expected Amount Values in Historical Visit Section after refund in Historical visit popup: "+expSavedAmounts);
		return expSavedAmounts;
	}

	public ArrayList<String> getActualRefundTransactionData() throws Exception{
		ArrayList<String> refundTransactionData=new ArrayList<String>();
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			List<WebElement>refundData=tr_RefundTransactionRow;
			for (WebElement webElement : refundData) {
				String refundrow=webElement.getText();
				if(!refundrow.isEmpty()){
					refundTransactionData.add(refundrow);
				}
			}
			report.reportInfo("Actaul Refund Transaction data is: "+refundTransactionData);
		} catch (Exception e) {
			throw e;
		}
		return refundTransactionData;
	}

	public ArrayList<String> getExpectedRefundTransactionData_V1(DataTable testData){
		ArrayList<String> refundTransactionData=new ArrayList<String>();
		refundTransactionData.add("Refund");
		refundTransactionData.add(getDatafromMap(testData,"Reverse Payment Memo"));
		refundTransactionData.add(getCurrentDateandTime());
		refundTransactionData.add(getDatafromMap(testData,"Refund Amount"));
		refundTransactionData.add("Approved");
		refundTransactionData.add("Receipt");
		report.reportInfo("Expected Refund Transaction data is: "+refundTransactionData);
		return refundTransactionData;
	}
	
	public ArrayList<String> getExpectedRefundTransactionData(DataTable testData){
		ArrayList<String> refundTransactionData=new ArrayList<String>();
		refundTransactionData.add("Refund");
		refundTransactionData.add(getDatafromMap(testData,"Refund Amount"));
		refundTransactionData.add("Approved");
		refundTransactionData.add(getDatafromMap(testData,"Reverse Payment Memo"));
		refundTransactionData.add(getCurrentDateandTime());
		refundTransactionData.add("Receipt");
		report.reportInfo("Expected Refund Transaction data is: "+refundTransactionData);
		return refundTransactionData;
	}

	public String  getCurrentDateandTime (){
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		return dateFormat.format(new Date()).toString();  
	}

	/* 
	 * Get Current Date and Time with AM/PM (Feb 04, 2021, 05:31 PM)
	 */
	public String getCurrentDateandTimewithAM_PM (){
		LocalDateTime myDateObj = LocalDateTime.now();  
		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("MMM dd, yyyy, hh:");  
		String formattedDate = myDateObj.format(myFormatObj); 
		return formattedDate;
	}

	public void verifyDatainPaymentReceipt(DataTable testData) throws Exception{
		try {
			String accountNumber = getDataFromJSONFile("AccountNumber");
			savePaymentWithoutValidations(testData);
			initiatePaymentWithoutValidations(testData);
			String transactionNumber=webActions.waitAndGetText(lbl_TransactionNumber, "Transaction Number");
			String patientName=webActions.waitAndGetText(lbl_PatientName, "Patient Name").replace("\n", " ");

			for(String winHandle : driver.getWindowHandles()){
				driver.switchTo().window(winHandle);
			}
			CreateFileNameandPath(accountNumber);		
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			robotAction();
			getDatafromPDFandVerify(accountNumber, patientName,transactionNumber, testData);
		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}

	public void verifyPaymentReceiptWhenClickonReceiptButton(DataTable testData) throws Exception{
		try {
			String accountNumber = getDataFromJSONFile("AccountNumber");
			savePaymentWithoutValidations(testData);
			initiatePaymentWithoutValidations(testData);
			String transactionNumber=webActions.waitAndGetText(lbl_TransactionNumber, "Transaction Number");
			String patientName=webActions.waitAndGetText(lbl_PatientName, "Patient Name").replace("\n", " ");
			String parent=driver.getWindowHandle();
			webActions.waitForPageLoaded();
			for(String winHandle : driver.getWindowHandles()){
				driver.switchTo().window(winHandle);
			}
			driver.close();
			driver.switchTo().window(parent);
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_Receipt, "Receipt");
			webActions.waitForPageLoaded();
			for(String winHandle : driver.getWindowHandles()){
				driver.switchTo().window(winHandle);
			}
			CreateFileNameandPath(accountNumber);		
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			robotAction();
			getDatafromPDFandVerify(accountNumber, patientName,transactionNumber, testData);
			report.reportPass("Successfully opened the Payment Receipt when click on Receipt button");
		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}

	public void robotAction() throws Exception{
		Robot robot = new Robot();
		/*robot.keyPress(KeyEvent.VK_TAB);	
		Thread.sleep(2000);	
		robot.keyPress(KeyEvent.VK_TAB);	
		Thread.sleep(2000);	
		robot.keyPress(KeyEvent.VK_TAB);	
		Thread.sleep(2000);	*/
		for (int i = 1; i <=8; i++) {
			robot.keyPress(KeyEvent.VK_TAB);	
			Thread.sleep(1000);	
		}
		robot.keyPress(KeyEvent.VK_ENTER);
		Thread.sleep(10000);
		try {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
		} catch (Exception e) {		
		}
		Thread.sleep(10000);
	}

	public static String  CreateFileNameandPath(String accountID) throws AWTException, HeadlessException, UnsupportedFlavorException, IOException{
		String fileName="";
		String downloadPath=System.getProperty("user.dir")+"\\Downloads\\";
		fileName=downloadPath+accountID+".pdf";
		StringSelection stringSelection = new StringSelection(fileName);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, stringSelection);
		String str=(String)Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);   
		return str;
	}

	public void getDatafromPDFandVerify(String accountID,String patientName,String transactionID,DataTable testData) throws IOException{
		String downloadPath=System.getProperty("user.dir")+"\\Downloads\\";
		String fileName=downloadPath+accountID+".pdf";
		StringBuilder unmatcData = new StringBuilder();
		PDDocument document = PDDocument.load(new File(fileName));
		PDFTextStripper pdfStripper = new PDFTextStripper();
		String datainPDF = pdfStripper.getText(document);
		report.reportInfo("Data in Payment Receipt:"+"\n"+datainPDF);
		String[] paymentData=datainPDF.split("\\n");
		String datainPaymentReceipt=paymentData[0];
		unmatcData.append(verifyDatainPDFFile(datainPaymentReceipt,patientName,"Patient Name"));
		unmatcData.append(verifyDatainPDFFile(datainPaymentReceipt,getDatafromMap(testData, "Facility Name"),"Facility Name"));
		datainPaymentReceipt=paymentData[1];
		unmatcData.append(verifyDatainPDFFile(datainPaymentReceipt,getDatafromMap(testData, "Status"),"Status"));
		unmatcData.append(verifyDatainPDFFile(datainPaymentReceipt,getDatafromMap(testData, "Facility Name"),"Facility Name"));
		datainPaymentReceipt=paymentData[2];
		unmatcData.append(verifyDatainPDFFile(datainPaymentReceipt,transactionID,"Receipt Number"));
		unmatcData.append(verifyDatainPDFFile(datainPaymentReceipt,getCurrentDateandTimewithAM_PM(),"Date and Time"));
		datainPaymentReceipt=paymentData[3];
		unmatcData.append(verifyDatainPDFFile(datainPaymentReceipt,getDatafromMap(testData, "Payment"),"Amount Paid"));
		datainPaymentReceipt=paymentData[4];
		unmatcData.append(verifyDatainPDFFile(datainPaymentReceipt,getDatafromMap(testData, "Payment"),"Amount Paid"));
		datainPaymentReceipt=paymentData[6];
		unmatcData.append(verifyDatainPDFFile(datainPaymentReceipt,accountID,"Account Number"));
		unmatcData.append(verifyDatainPDFFile(datainPaymentReceipt,transactionID,"Transaction Id"));
		unmatcData.append(verifyDatainPDFFile(datainPaymentReceipt,getCurrentDateandTime(),"Visit Date"));
		unmatcData.append(verifyDatainPDFFile(datainPaymentReceipt,getDatafromMap(testData, "Service Type"),"Service Type"));
		datainPaymentReceipt=paymentData[8];
		unmatcData.append(verifyDatainPDFFile(datainPaymentReceipt,getDatafromMap(testData, "Payment Method"),"Payment Method"));
		document.close();

		if(unmatcData.length()==0){
			report.reportPass("Successfully verified the data in Payment Receipt");
		}else{
			report.reportFail("Failed to very the data in Payment Receipt: "+unmatcData);
		}
	}

	public StringBuilder verifyDatainPDFFile(String actText,String expText,String verficationMessage){
		StringBuilder unmatch=new StringBuilder();
		if(actText.contains(expText)){
			report.reportPass(verficationMessage+": is matched");
		}
		else{
			unmatch.append(verficationMessage+": is not matched");
			report.reportFail(verficationMessage+": is not matched",true);
		}
		return unmatch;
	}

	public void addNewPatientandInitiatePayment(DataTable testData){
		try {
			addPatient.navigateToAddPatient();
			String lastName=rest.randomString(6);
			String firstName=rest.randomString(6);
			addPatient.verifyAddPatient(lastName, firstName);
			String patientName=firstName+" "+lastName;
			String accountNumber=searchPatientNameinAccountSearchPage(patientName);
			savePayment(testData);
			initiatePayment_ManualAddedPatient(testData,accountNumber);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public String searchPatientNameinAccountSearchPage(String patientName) throws Exception{
		String accountNumber;
		try {
			webActions.waitAndClick(lnk_AccountSearch_Home, "Account Search");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_Search, patientName, "");
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(li_Search, "Account Numnber list");
			webActions.waitForPageLoaded();
			webActions.click(li_Search, "Account Numnber list");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_Headers_AS,"Account Search Headers");
			webActions.waitForPageLoaded();
			accountNumber=webActions.waitAndGetText(lbl_AccountNumber_AccountSearch, "Account Number");
			webActions.click(lbl_AccountNumber_AccountSearch, "Account Numnber");
			webActions.waitForPageLoaded();
			waitforPaymentFacilitatorPanel();
			waitforAAARuleAlerts();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_PaymentFacilitator, "Payment Facilitator");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			throw new Exception(e);
		}
		return accountNumber;
	}

	public void initiatePayment_ManualAddedPatient(DataTable testData,String accountNumber){
		try {
			StringBuilder verify=new StringBuilder();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibility(chk_PaymentRecord, "Payment Record Check Box");
			webActions.waitAndClick(chk_PaymentRecord, "Payment Record Check Box");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(txt_Payment, "Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_Payment, getDatafromMap(testData,"Payment"), "Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(btn_InitiatePayment, "Initiate Payment");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitUntilPresentAndDisplayed(dd_PaymentMethod, "Payment Method");
			webActions.sendKeys(dd_PaymentMethod, getDatafromMap(testData,"Payment Method"), "Payment Method");
			webActions.waitUntilPresentAndDisplayed(txt_PaymentMemo, "Payment Memo");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_PaymentMemo, getDatafromMap(testData,"Payment Memo"), "Payment Memo");
			webActions.click(btn_CollectPayment, "Collect Payment");

			// It will return the parent window name as a String
			String parent=driver.getWindowHandle();

			String InitiatePayment=webActions.waitAndGetText(lbl_InitiatePayment_Popup, "InitiatePayment");

			if("Initiate Payment".contains(InitiatePayment)){
				report.reportPass("Successfully Initiated the Payment: "+InitiatePayment);
			}else{
				report.reportFail("Failed to verify Initiate Payment and message is not matched: "+InitiatePayment,true);
				verify.append("Failed to verify Initiate Payment and message is not matched:");
			}

			String paymentSuccess=webActions.waitAndGetText(lbl_PaymentSuccess_Popup, "Success");

			if("Processing Complete".contains(paymentSuccess)){
				report.reportPass("Successfully collected the payment amount: "+paymentSuccess);
			}else{
				report.reportFail("Failed to verify the collect the payment amount and message: "+paymentSuccess,true);
				verify.append("Failed to verify the collect the payment amount and message:");
			}

			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			driver.switchTo().window(parent);

			ArrayList<String> actPaymentTransactionData=getPaymentTransactionData();

			ArrayList<String> expPaymentTransactionData=getExpectedPaymentTransactionData(testData);

			ArrayList<String> unmatchTransactionData=webActions.getUmatchedInArrayComparision(actPaymentTransactionData, expPaymentTransactionData);
			if(unmatchTransactionData.size()==0){
				report.reportPass("Payment Transaction data is matched: "+actPaymentTransactionData);
			}else{
				report.reportFail("Payment Transaction data is not matched and unmatched data is: "+unmatchTransactionData,true);
				verify.append("Payment Transaction data is not matched");
			}
			ArrayList<String> actPaymentAmountsinPage=getActualAmountsAfterSavePayment();
			ArrayList<String>expAmountsinPage=getExpectedAmountsinPanelandPage(testData);
			report.reportInfo("Expected Payment Amounts after payment is done in the page: "+expAmountsinPage);
			report.reportInfo("Actual Payment Amounts after payment is done in page: "+actPaymentAmountsinPage);
			ArrayList<String> unmatchAmounts=webActions.getUmatchedInArrayComparision(actPaymentAmountsinPage, expAmountsinPage);
			if(unmatchAmounts.size()==0){
				report.reportPass("Payment Amounts matched successfully after payment is done in page: "+actPaymentAmountsinPage);
			}else{
				report.reportFail("Payment Amounts not matched after payment is done in page: "+unmatchAmounts,true);
				verify.append("Payment Amounts not matched after payment is done in page");
			}

			String actFCStatusPaymentFacilitatorPage=getFinClearStatusinPaymentFacilitatorPage();
			String expFCStatusPaymentFacilitatorPage=getFinancialClearanceStatus(testData);
			if(actFCStatusPaymentFacilitatorPage.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Page");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Page",true);
				verify.append("Failed to verify the Financial Clearance Status in Payment Facilitator Page");
			}

			//String accountNumber = getDataFromJSONFile("AccountNumber");
			driver.findElement(By.linkText(accountNumber)).click();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();

			ArrayList<String> actLabelNames=getActualLabelNamesinPanel();
			ArrayList<String>expLabelNames=getExpectedLabelNamesinPanel(testData);

			ArrayList<String> unmatchLabels=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchLabels.size()==0){
				report.reportPass("Label names matched successfully in Panel: "+actLabelNames);
			}else{
				report.reportFail("Label names are not matched in Panel: "+unmatchLabels,true);
				verify.append("Label names are not matched in Panel:");
			}

			ArrayList<String> actAmounts=webActions.getDatafromWebTable(lbl_PaymentFacilitator_Amounts_Panel);
			ArrayList<String>expAmounts=getExpectedAmountsinPanelandPage(testData);
			report.reportInfo("Expected Payment Amounts in panel: "+expAmounts);
			report.reportInfo("Actual Payment Amounts in panel: "+actAmounts);
			ArrayList<String> unmatchAmountsPanel=webActions.getUmatchedInArrayComparision(actAmounts, expAmounts);
			if(unmatchAmountsPanel.size()==0){
				report.reportPass("Payment Amounts matched successfully in Panel: "+actAmounts);
			}else{
				report.reportFail("Payment Amounts not matched in Panel: "+unmatchAmountsPanel,true);
				verify.append("Payment Amounts not matched in Panel");
			}

			String actFCStatusPFPanel=webActions.getAttributeValue(img_FinancialClearanceStatus_PaymentFacilitatorPanel, "src", "Payment Facilitator Panel");
			if(actFCStatusPFPanel.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Panel");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Panel",true);
				verify.append("Failed to verify the Financial Clearance Status in Payment Facilitator Panel");
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyPaymentTypeAndPaymentAmounts(DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			String accountNumber = getDataFromJSONFile("AccountNumber");
			String estimateAmount = getDataFromJSONFile("PatientResponsibilityEstimate");
			if(estimateAmount.isEmpty()){
				estimateAmount=getDatafromMap(testData, "Estimate Amount");
			}
			login.simpleSearch(accountNumber);
			String expFinClrStatus=getFinancialClearanceStatus(testData);
			String actFinClrStatusAccoutSearch=getFinancialClearanceStatusinAccountSearch("Payment Facilitator");
			if(actFinClrStatusAccoutSearch.contains(expFinClrStatus)){
				report.reportPass("Successfully verified Financial Clearance Status in Account Search page");	
			}else{
				report.reportFail("Failed to verified Financial Clearance Status in Account Search page",true);
				unmatch.append("Failed to verified Financial Clearance Status in Account Search page");
			}
			driver.findElement(By.partialLinkText(accountNumber)).click();
			ArrayList<String> actLabelNames=getActualLabelNamesinPanel();
			ArrayList<String>expLabelNames=getExpectedLabelNamesinPanel(testData);
			ArrayList<String> unmatchLabels=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchLabels.size()==0){
				report.reportPass("Successfully verified Payment Type in Payment Facilitator panel: "+actLabelNames);
			}else{
				report.reportFail("Failed to verify the Payment Type in Payment Facilitator panel: "+unmatchLabels,true);
				unmatch.append("Failed to verify the Payment Type in Payment Facilitator panel");
			}
			ArrayList<String> actAmounts=getActualAmountsinPanel();
			report.reportInfo("Actual Estimate Amounts in panel: "+actAmounts);
			ArrayList<String>expAmounts=getExpectedEstimateAmounts(estimateAmount);
			ArrayList<String> unmatchAmounts=webActions.getUmatchedInArrayComparision(actAmounts, expAmounts);
			if(unmatchAmounts.size()==0){
				report.reportPass("Payment Amounts verified successfully in Payment Facilitator panel: "+actAmounts);
			}else{
				report.reportFail("Failed to verify the Payment Amounts in Payment Facilitator panel: "+unmatchAmounts,true);
				unmatch.append("Failed to verify the Payment Amounts in Payment Facilitator panel");
			}

			String actaulFCPFStatus=getActualFinancialClearanceStatusinPanel();
			String expFCPFStatus=getFinancialClearanceStatus(testData);
			if(actaulFCPFStatus.contains(expFCPFStatus)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Panel");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Panel",true);
				unmatch.append("Failed to verify the Financial Clearance Status in Payment Facilitator Panel");
			}

			webActions.waitAndClick(lnk_PaymentFacilitator, "Payment Facilitator");
			webActions.waitForPageLoaded();

			ArrayList<String> actCurrentVisitData=getActualCurrentVisitData();
			ArrayList<String> expCurrentVisitData=getExpectedCurrentVisitData(testData,estimateAmount);
			ArrayList<String> unmatchCurrentVisitAmounts=webActions.getUmatchedInArrayComparision(actCurrentVisitData, expCurrentVisitData);
			if(unmatchAmounts.size()==0){
				report.reportPass("Payment Type and Estimate Amount verified successfully in Payment Facilitator page: "+actCurrentVisitData);
			}else{
				report.reportFail("Failed to verify the Payment Type and Estimate Amount in Payment Facilitator page: "+unmatchCurrentVisitAmounts,true);
				unmatch.append("Failed to verify the Payment Type and Estimate Amount in Payment Facilitator page");
			}

			String actFCStatusPaymentFacilitatorPage=getFinClearStatusinPaymentFacilitatorPage();
			String expFCStatusPaymentFacilitatorPage=getFinancialClearanceStatus(testData);
			if(actFCStatusPaymentFacilitatorPage.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Page");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Page",true);
				unmatch.append("Failed to verify the Financial Clearance Status in Payment Facilitator Page");
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyPaymentPanelifEstimateAmountisNULLandSavePayament(DataTable testData){
		try {
			navigatePatientVisitMainPage("Account Search");
			waitforAAARuleAlerts();
			waitforPaymentFacilitatorPanel();
			String actualErrorMessage=webActions.waitAndGetText(lbl_NoPayments, "No Payments Error Message");
			report.reportInfo("Actual Error Message is: "+actualErrorMessage);
			if("No payment has created yet".contentEquals(actualErrorMessage)){
				report.reportPass("Successfully verified the Error Message if Estimate Amount is null for the new visit");
			}else{
				report.reportFail("Failed to verify the Error Message if Estimate Amountis null for the new visit");
			}
			webActions.waitAndClick(lnk_PaymentFacilitator, "Payment Facilitator");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			waitforPaymentFacilitatorPage();
			savePayment(testData);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifythePatientVisitChargeisAlreadySavedwithCoPay(DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.click(lnk_AccountSearch_Home, "Account Search");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String accountNumber = getDataFromJSONFile("AccountNumber");
			driver.findElement(By.partialLinkText(accountNumber)).click();
			webActions.waitForPageLoaded();
			ArrayList<String> actLabelNames=getActualLabelNamesinPanel();
			ArrayList<String>expLabelNames=getExpectedLabelNamesinPanel(testData);
			ArrayList<String> unmatchLabels=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchLabels.size()==0){
				report.reportPass("Successfully verified Payment Type in Payment Facilitator panel: "+actLabelNames);
			}else{
				report.reportFail("Failed to verify the Payment Type in Payment Facilitator panel: "+unmatchLabels,true);
				unmatch.append("Failed to verify the Payment Type in Payment Facilitator panel");
			}
			ArrayList<String> actAmounts=getActualAmountsinPanel();
			report.reportInfo("Actual Estimate Amounts in panel: "+actAmounts);
			String estimateAmount=getDatafromMap(testData, "Total Amount");
			ArrayList<String>expAmounts=getExpectedEstimateAmounts(estimateAmount);
			ArrayList<String> unmatchAmounts=webActions.getUmatchedInArrayComparision(actAmounts, expAmounts);
			if(unmatchAmounts.size()==0){
				report.reportPass("Payment Amounts verified successfully in Payment Facilitator panel: "+actAmounts);
			}else{
				report.reportFail("Failed to verify the Payment Amounts in Payment Facilitator panel: "+unmatchAmounts,true);
				unmatch.append("Failed to verify the Payment Amounts in Payment Facilitator panel");
			}

			String actaulFCPFStatus=getActualFinancialClearanceStatusinPanel();
			String expFCPFStatus=getFinancialClearanceStatus(testData);
			if(actaulFCPFStatus.contains(expFCPFStatus)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Panel");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Panel",true);
				unmatch.append("Failed to verify the Financial Clearance Status in Payment Facilitator Panel");
			}

			webActions.waitAndClick(lnk_PaymentFacilitator, "Payment Facilitator");
			webActions.waitForPageLoaded();

			ArrayList<String> actCurrentVisitData=getActualCurrentVisitData();
			ArrayList<String> expCurrentVisitData=getExpectedCurrentVisitData(testData,estimateAmount);
			ArrayList<String> unmatchCurrentVisitAmounts=webActions.getUmatchedInArrayComparision(actCurrentVisitData, expCurrentVisitData);
			if(unmatchAmounts.size()==0){
				report.reportPass("Payment Type and Estimate Amount verified successfully in Payment Facilitator page: "+actCurrentVisitData);
			}else{
				report.reportFail("Failed to verify the Payment Type and Estimate Amount in Payment Facilitator page: "+unmatchCurrentVisitAmounts,true);
				unmatch.append("Failed to verify the Payment Type and Estimate Amount in Payment Facilitator page");
			}

			String actFCStatusPaymentFacilitatorPage=getFinClearStatusinPaymentFacilitatorPage();
			String expFCStatusPaymentFacilitatorPage=getFinancialClearanceStatus(testData);
			if(actFCStatusPaymentFacilitatorPage.contains(expFCStatusPaymentFacilitatorPage)){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Page");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Page",true);
				unmatch.append("Failed to verify the Financial Clearance Status in Payment Facilitator Page");
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getFinancialClearanceStatusinAccountSearch(String expModuleName) throws Exception{
		String actModuleStatus="";
		try {
			webActions.waitForPageLoaded();
			List<WebElement> moduleName=li_AllModuleNameNeedsAttention;
			for (WebElement webElement : moduleName) {
				String actModuleName=webElement.getText().trim();
				if(actModuleName.contentEquals(expModuleName)){
					actModuleStatus=webElement.findElement(By.tagName("financial-clearance-status")).findElement(By.tagName("img")).getAttribute("src");
					break;
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return actModuleStatus;
	}

	public ArrayList<String> getExpectedEstimateAmounts(String estimateAmount){
		ArrayList<String>expEstimateAmounts=new ArrayList<String>();
		expEstimateAmounts.add(estimateAmount);
		expEstimateAmounts.add("0.00");
		expEstimateAmounts.add(estimateAmount);
		report.reportInfo("Expected Estimate Amounts in panel: "+expEstimateAmounts);
		return expEstimateAmounts;
	}

	public ArrayList<String> getActualCurrentVisitData() throws Exception {
		ArrayList<String> currentVisitData=new ArrayList<String>();
		try {
			waitforPage();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibilityOfAllElements(lbl_AllAmountFields, "Amounts");
			webActions.waitForPageLoaded();
			webActions.waitUntilPresentAndDisplayed(txt_AdjustedAmount, "AdjustedAmount");
			currentVisitData.add(webActions.getAttributeValue(dd_PaymentType, "value", "dd_PaymentType"));
			currentVisitData.add(webActions.getAttributeValue(txt_TotalAmount,"value", "Total Amount"));
			List<WebElement>visitData=lbl_AllAmountFields;
			for (WebElement webElement : visitData) {
				String refundrow=webElement.getText();
				if(!refundrow.isEmpty()){
					currentVisitData.add(refundrow);
				}
			}
		} catch (Exception e) {
			throw e;
		}
		report.reportInfo("Actual Payment Type and Estimate Amounts in Page: "+currentVisitData);
		return currentVisitData;
	}

	public ArrayList<String> getExpectedCurrentVisitData(DataTable testData,String estimateAmount) throws Exception {
		ArrayList<String> expCurrentVisitData=new ArrayList<String>();
		expCurrentVisitData.add(getDatafromMap(testData,"Payment Type"));
		expCurrentVisitData.add(estimateAmount);
		expCurrentVisitData.add(estimateAmount);
		expCurrentVisitData.add("0.00");
		expCurrentVisitData.add(estimateAmount);
		report.reportInfo("Expected Payment Type and Estimate Amounts in Page: "+expCurrentVisitData);
		return expCurrentVisitData;
	}


	@SuppressWarnings("unchecked")
	public void updatePaymentFacilitatorJSON(String estimateAmount) throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(PAYMENTFACILITATOR);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject appointmentObject = (JSONObject) jsonObject.get("Appointment");
			try {
				String number = rest.getUniqueNumber();
				newNum = "A" + number;
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(0);
				tenantPatient.put("TenantPatientId", newNum);

				tenantPatient = (JSONObject) msg.get(2);
				tenantPatient.put("TenantPatientId", newNum);

				String test = (String) tenantPatient.get("TenantPatientId");	
			} catch (Exception e) {
				log.error("Failed to update tenant patiend id", e);
				e.printStackTrace();
			}
			try {
				// update tenantPatientVisitId and visitDate
				/*JSONArray visit = (JSONArray) visitObject.get("TenantPatientVisitIdentifier");
				JSONObject patientVisit = (JSONObject) visit.get(0);
				patientVisit.put("TenantPatientVisitId", newNum);*/
				visitObject.put("AccountNumber", newNum);
				visitObject.put("VisitNumber", newNum);
				Object tt = visitObject.get("VisitDate");
				String updatedDate = rest.updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);

			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}

			try {
				// update appointmentStartDate and appointmentEndDate
				Object appointment = appointmentObject.get("AppointmentStartDate");
				String updatedDates = rest.updatedDateAppointment(appointment);
				appointmentObject.put("AppointmentStartDate", updatedDates);
				appointmentObject.put("AppointmentEndDate", updatedDates);
				String appointmentId = rest.getUniqueAppointmentNumber();				
				appointmentObject.put("AppointmentId", appointmentId);
			} catch (Exception e) {
				log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
				e.printStackTrace();
			}

			try {
				visitObject.put("PatientResponsibilityEstimate",estimateAmount);
			} catch (Exception e) {
				log.error("Failed to update PatientResponsibilityEstimate", e);
				e.printStackTrace();
			}


			FileWriter file = new FileWriter(PAYMENTFACILITATOR);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void updateAccountNumber() throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(PAYMENTFACILITATOR);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject appointmentObject = (JSONObject) jsonObject.get("Appointment");
			try {
				String number = rest.getUniqueNumber();
				newNum = "A" + number;
				visitObject.put("AccountNumber", newNum);
				visitObject.put("VisitNumber", newNum);
				Object tt = visitObject.get("VisitDate");
				String updatedDate = rest.updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);

			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}

			FileWriter file = new FileWriter(PAYMENTFACILITATOR);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void updatePatientResponsiblityEstimate(String estimateAmount) throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(PAYMENTFACILITATOR);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject appointmentObject = (JSONObject) jsonObject.get("Appointment");

			try {
				visitObject.put("PatientResponsibilityEstimate",estimateAmount);
			} catch (Exception e) {
				log.error("Failed to update PatientResponsibilityEstimate", e);
				e.printStackTrace();
			}

			FileWriter file = new FileWriter(PAYMENTFACILITATOR);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}

	public String getCurrentDate() {
		String currentDate = "";
		try {
			Date date = new Date();
			date = DateUtils.addDays(date, -1);
			currentDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
		} catch (Exception e) {

		}
		return currentDate;

	}

	public String updatedDateAppointment(Object object) {
		String updatedDate = "";
		try {
			String date = object.toString();
			String currentDate = getCurrentDate();
			String array[] = date.split("T");
			updatedDate = currentDate + "T" + array[1];
			log.info("Updated appointment date: "+updatedDate);
		} catch (Exception e) {
			log.error("Failed to update appointment date", e);
		}

		return updatedDate;

	}

	public String getDataFromJSONFile(String fieldName){
		String expectedResponseValue=null;
		try {
			FileReader reader = new FileReader(PAYMENTFACILITATOR);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");

			if(fieldName.contentEquals("AccountNumber")){
				/*JSONArray data = (JSONArray) visitObject.get("TenantPatientVisitIdentifier");
				JSONObject tenantPatient = (JSONObject) data.get(0);							
				expectedResponseValue= (String) tenantPatient.get("TenantPatientVisitId");*/
				expectedResponseValue = (String) visitObject.get("AccountNumber");	
			}
			else if(fieldName.contentEquals("PatientResponsibilityEstimate")){
				/*JSONArray data = (JSONArray) visitObject.get("TenantPatientVisitIdentifier");
				JSONObject tenantPatient = (JSONObject) data.get(0);							
				expectedResponseValue= (String) tenantPatient.get("TenantPatientVisitId");*/
				expectedResponseValue = (String) visitObject.get("PatientResponsibilityEstimate");	
			}

		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return expectedResponseValue;

	}

	public ArrayList<String> getListDataFromJSONFile(String scenarioName){
		ArrayList<String> jsondata=new ArrayList<String>();
		try {
			FileReader reader = new FileReader(PAYMENTFACILITATOR);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");

			SimpleDateFormat jsonDate = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat appDate = new SimpleDateFormat("MM/dd/yyyy");
			switch (scenarioName) {

			case "VisitInformation":
				/*JSONArray data = (JSONArray) visitObject.get("TenantPatientVisitIdentifier");
				JSONObject tenantPatient = (JSONObject) data.get(0);							
				jsondata.add((String) tenantPatient.get("TenantPatientVisitId"));*/

				jsondata.add((String) visitObject.get("AccountNumber"));	

				JSONObject patientGenderObject = (JSONObject) patientObject.get("PatientGender");

				jsondata.add((String) patientGenderObject.get("GenderDescription"));


				String dob=(String)patientObject.get("PatientDateOfBirth");
				Date expDate;
				expDate = jsonDate.parse(dob);
				jsondata.add(appDate.format(expDate));

				String inputdate=(String)visitObject.get("VisitDate");
				String[] result = inputdate.split("T");
				String splitedDate=result[0];
				expDate = jsonDate.parse(splitedDate);
				jsondata.add(appDate.format(expDate));

				String status=rest.getValueFromResponseandCompWithExpected("$..currentVisitStatusDescription");
				status=status.replaceAll("(\\p{Ll})(\\p{Lu})","$1 $2");
				jsondata.add(status);
				break;
			}
		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return jsondata;
	}
	
	public void waitforAAARuleAlerts() throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_AllAlerts, "All Alerts");
		} catch (Exception e) {
			webActions.waitForPageLoaded();
		}
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(tbl_AccountSearchData);
	}

}
