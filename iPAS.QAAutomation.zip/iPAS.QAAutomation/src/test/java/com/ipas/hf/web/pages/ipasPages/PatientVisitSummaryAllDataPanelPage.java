package com.ipas.hf.web.pages.ipasPages;

import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class PatientVisitSummaryAllDataPanelPage extends BasePage {

	private JSONObject jsonObject;
	private static final String SIUJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\SIUEventBasedData.json";
	private static final String ADTJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\ADTEventBasedData.json";
	Login logIn=new Login();
	RestActions rest=new RestActions();

	@FindBy(xpath="//div[@class='imgSpec']/a")
	private WebElement lbl_AllData; 

	@FindBy(xpath ="//div[@class='e-gridcontent']//tr[1]//td[2]/div/a")
	private WebElement lnk_AccountNumber;

	@FindBy(xpath="//div[@class='e-acrdn-header-content']")
	private WebElement lbl_AllPanels;

	@FindBy(xpath="//table[@class='e-table']//thead/tr")
	private WebElement lbl_Headers;

	@FindBy(xpath = "//ipas-breadcrumb/div/span/a")
	private WebElement lnk_BreadcrumbName;

	@FindBy(xpath="//ipas-breadcrumb/div/span/span[@class='breadcrum-active ng-star-inserted']")
	private WebElement lbl_AccountNumber;

	@FindBy(xpath="//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']")
	private WebElement lbl_Headers_ServiceTracker;

	@FindBy(xpath = "//input[@class='form-control e-control e-textbox e-lib e-input']")
	private WebElement txt_Search_ServiceTracker;

	@FindBy(xpath="//a[@class='breadcrum']")
	private WebElement lbl_Breadcrum_Service;

	@FindBy(xpath="//span[@class='breadcrum-active']")
	private WebElement lbl_Breadcrum_ServiceVisitNumber;

	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[1]")
	private List<WebElement> lbl_VisitSummaryFields;

	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[2]")
	private List<WebElement> lbl_VisitSummaryData;

	@FindBy(xpath="//account-search-all-data-panel//p[@class='contain-title']")
	private List<WebElement> lbl_SectionNamesInAllDataPanel;

	@FindBy(xpath="//div[@id='acrdn_panel_7']/div/div/ul/li/div[1]")
	private List<WebElement> lbl_SectionLabelsInAllDataPanel;

	@FindBy(xpath="//div[@id='acrdn_panel_7']/div/div/ul/li/div[2]")
	private List<WebElement> lbl_SectionDataInAllDataPanel;

	@FindBy(xpath="//ejs-accordion/div[1]/div[2]/div/div/ul/li/div[2]")
	private WebElement lbl_DataInAllDataPanel;

	@FindBy(xpath="//account-search-all-data-panel/ejs-accordion/div/div[1]/div[2]/span")
	private WebElement icon_AllDataExpandCollapse; 

	@FindBy(xpath="//span[contains(text(),'Transactions')]")
	private WebElement btn_TransHistory;

	@FindBy(xpath="//h5[contains(text(),'Transactions')]")
	private WebElement txt_TransHistoryTitle;	

	@FindBy(xpath="//div[@class='grid-header']/h6")
	private List<WebElement> lbl_TransHistoryColumns;

	@FindBy(xpath="//div[@class='pasentNameContainer ng-star-inserted']")
	private WebElement lbl_AllDataPatientName;

	@FindBy(xpath="//img[@class='close-button']")
	private WebElement btn_TransHistoryCross;

	@FindBy(xpath="//div[@class='panel-containArea']/ul/li")
	private WebElement lbl_DataInAllDataPanel_ServiceTracker;

	@FindBy(xpath="//div[@class='grid']/div[2]")
	private WebElement txt_TransHistoryEventType;
	
	@FindBy(xpath="//span[contains(text(),'No payment has created yet')]")
	private WebElement lbl_NoPayments;
	
	@FindBy(xpath="//ipas-payment-facilitator-pannel/ejs-accordion/div")
	private WebElement tbl_PaymentFacilitatorPanel;
	

	@FindBy(xpath="//div[@id='three']//app-ipas-document-management-pannel/div/ejs-accordion/div/div[2]/div/div/ul/li/div[1]")
	private List<WebElement> lbl_DigitalDocMangerPanel;

	public PatientVisitSummaryAllDataPanelPage() {
		PageFactory.initElements(driver, this);
	}


	public void clickOnAccountLinkNumber() throws Exception{
		try {			
			webActions.waitForVisibility(lbl_Headers, "Account Number");
			String accountNumber=webActions.getText(lnk_AccountNumber, "Account Number");
			report.reportInfo("Account Number is: "+accountNumber);
			webActions.click(lnk_AccountNumber, "Account Number");			
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_DigitalDocMangerPanel, "DigitalDocs");
			Thread.sleep(2000);
			waitforPaymentFacilitatorPanel();
			report.reportInfo("Navigated to the Patient Visit Summary page");			
			webActions.waitForVisibilityOfAllElements(lbl_DataInAllDataPanel, "DataInAllData");
			webActions.waitForVisibilityOfAllElements(lbl_VisitSummaryData, "SummaryData");
			
		} catch (Exception e) {
			throw e;
		}

	}
	
	public void patientVisitMainPageWaiting() throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_DigitalDocMangerPanel, "DigitalDocs");			
			waitforPaymentFacilitatorPanel();
			report.reportInfo("Navigated to the Patient Visit Summary page");			
			webActions.waitForVisibilityOfAllElements(lbl_DataInAllDataPanel, "DataInAllData");
			webActions.waitForVisibilityOfAllElements(lbl_VisitSummaryData, "SummaryData");
		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyAllDataPanelTitle(String title){
		try {			
			String ActualTitle = webActions.getText(lbl_AllData, "Panel Title");
			if (ActualTitle.contentEquals(title)){
				report.reportPass("Verified Panel title successfully");
				report.reportInfo("Actual Panel title: "+ActualTitle);
			}
			else{
				throw new Exception("Actual Columns title did not match with Expected and Actual title is: "+ActualTitle);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());

		}
	}

	public void verifyPatientsummaryBreadcrumb(String visitId,String pageNavigation){
		String breadcrumb="";
		String breadcrumb_Visit="";
		try {
			String visitIdvalue = logIn.getVisitIdFromResponse(visitId);
			if(pageNavigation.contentEquals("Account Search")){			
				logIn.simpleSearch(visitIdvalue);
				clickOnAccountLinkNumber();
				webActions.waitForVisibility(lbl_DataInAllDataPanel, "VisitSummaryData");
				breadcrumb = webActions.waitAndGetText(lnk_BreadcrumbName, "Account Search BreadcrumbName");
				report.reportInfo("Level 1 Breadcrumb is:  "+breadcrumb);
				breadcrumb_Visit = webActions.waitAndGetText(lbl_AccountNumber, "Account Number");
				report.reportInfo("Level 2 Breadcrumb is:  "+breadcrumb_Visit);
			}else if(pageNavigation.contentEquals("Service Tracker")){
				searchAccountNumberinServiceTracker(visitIdvalue);
				webActions.waitForVisibility(lbl_DataInAllDataPanel_ServiceTracker, "AllData");
				breadcrumb = webActions.waitAndGetText(lbl_Breadcrum_Service, "");
				report.reportInfo("Level 1 Breadcrumb is:  "+breadcrumb);
				breadcrumb_Visit = webActions.waitAndGetText(lbl_Breadcrum_ServiceVisitNumber, "");
				report.reportInfo("Level 2 Breadcrumb is:  "+breadcrumb_Visit);
			}

			if((pageNavigation.contentEquals(breadcrumb)) && (visitIdvalue.contentEquals(breadcrumb_Visit))){
				report.reportPass("Breadcrumb is displayed based on '"+pageNavigation+"' followed by the display patient visit number: "+visitIdvalue+"");
			}
			else {
				throw new Exception("Failed to verify the displayed Breadcrumb based on '"+pageNavigation+"' followed by the display patient visit number: "+visitIdvalue+"");
			}
		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	public void searchAccountNumberinServiceTracker(String AccountNumber) throws Exception{
		try {
			webActions.waitForVisibility(lbl_Headers_ServiceTracker, "Service Tracker Headers");
			webActions.enterValuesfromKeyBoard(txt_Search_ServiceTracker, AccountNumber, "");
			Thread.sleep(2000);
			driver.findElement(By.linkText(AccountNumber)).click();
			report.reportPass("clicked on visit card account number");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void getVisitNumberFromResponseAndClickOnAccountNumber(String visitId){
		try {
			String visitIdvalue = logIn.getVisitIdFromResponse(visitId);
			//String visitIdvalue=visitId;
			logIn.simpleSearch(visitIdvalue);
			clickOnAccountLinkNumber();
		} catch (Exception e) {

		}
	}
	/** To Verify the visit summary labels**/
	public void verifyVisitSUmmaryFields(DataTable summaryfields){
		try {
			ArrayList<String> expectedSummaryInfoFields = new ArrayList<>(summaryfields.asList());
			report.reportInfo("Expected Summary Info Fields: "+expectedSummaryInfoFields);
			webActions.waitUntilisDisplayed(lbl_DataInAllDataPanel, "AllPanels");
			ArrayList<String> actualSummaryInfoFields=webActions.getDatafromWebTable(lbl_VisitSummaryFields);
			report.reportInfo("Displayed Summary Fields in Application: "+actualSummaryInfoFields);
			ArrayList<String>unmatchedSummarFields=webActions.getUmatchedInArrayComparision(actualSummaryInfoFields, expectedSummaryInfoFields);
			if(unmatchedSummarFields.size()==0){
				report.reportPass("Verified visit summary Info fields from summary page");
			}
			else{
				throw new Exception("Fail to verify visit summary Info fields from summary page and unmatched fields are: "+unmatchedSummarFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}	
	public void verifyVisitSummaryInfo(String scenarioName){
		try {
			ArrayList<String> expSummaryInfoFields=getSummaryInfoDataFromJSONFile(scenarioName);			
			report.reportInfo("Expected Summary Info Fields data: "+expSummaryInfoFields);
			webActions.waitForVisibility(lbl_DataInAllDataPanel, "AllPanels");
			ArrayList<String> actualSummaryInfoFields=webActions.getDatafromWebTable(lbl_VisitSummaryData);
			report.reportInfo("Displayed Summary Fields data in Application: "+actualSummaryInfoFields);
			ArrayList<String>unmatchedSummarFields=webActions.getUmatchedInArrayComparision(actualSummaryInfoFields, expSummaryInfoFields);
			if(unmatchedSummarFields.size()==0){
				report.reportPass("Verified visit summary Info from summary page");
			}
			else{
				throw new Exception("Fail to verify visit summary Info from summary page and unmatched data is: "+unmatchedSummarFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	public ArrayList<String> getSummaryInfoDataFromJSONFile(String scenarioName){
		ArrayList<String> jsondata=new ArrayList<String>();
		try {
			FileReader reader = new FileReader(ADTJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");

			SimpleDateFormat jsonDate = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat appDate = new SimpleDateFormat("MM/dd/yyyy");
			switch (scenarioName) {

			case "visitInformation":				

				jsondata.add((String)visitObject.get("AccountNumber"));

				JSONObject patientGenderObject = (JSONObject) patientObject.get("PatientGender");

				jsondata.add((String) patientGenderObject.get("GenderDescription"));

				String dob=(String)patientObject.get("PatientDateOfBirth");
				Date expDate;
				expDate = jsonDate.parse(dob);
				jsondata.add(appDate.format(expDate));

				String inputdate=(String)visitObject.get("VisitDate");
				String[] result = inputdate.split("T");
				String splitedDate=result[0];
				expDate = jsonDate.parse(splitedDate);
				jsondata.add(appDate.format(expDate));

				String status=rest.getValueFromResponseandCompWithExpected("$..currentVisitStatusDescription");				
				status=status.replaceAll("(\\p{Ll})(\\p{Lu})","$1 $2");			   	
				jsondata.add(status);
				break;

			case "PanelInformation":
				JSONArray patientIdetifier = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject mrnIdentifier = (JSONObject) patientIdetifier.get(0);					
				jsondata.add((String) mrnIdentifier.get("TenantPatientId"));

				JSONArray phoneNumberArray = (JSONArray) patientObject.get("PatientPhoneNumber");
				JSONObject mobileType = (JSONObject)phoneNumberArray.get(0);
				String phone=(String)mobileType.get("PhoneNumber");				

				phone=phone.substring(0, 3)+')'+phone.subSequence(3, 6)+'-'+phone.substring(5+1);

				String phoneType=(String)mobileType.get("PhoneNumberTypeCode");
				jsondata.add(phoneType+": "+"("+phone);

				jsondata.add((String) patientObject.get("PatientEmailAddress"));

				JSONObject	visitLocation=(JSONObject)visitObject.get("VisitLocation");
				JSONObject	poinofCare=(JSONObject)visitLocation.get("LocationPointOfCare");
				jsondata.add((String)poinofCare.get("PointofCareDescription"));

				JSONArray insurance=(JSONArray) jsonObject.get("Insurance");
				JSONObject primaryInsurance=(JSONObject)insurance.get(0);
				jsondata.add((String)primaryInsurance.get("InsurancePlanName"));

				JSONObject secondaryInsurance=(JSONObject)insurance.get(1);
				jsondata.add((String)secondaryInsurance.get("InsurancePlanName"));

				JSONObject tertiaryInsurance=(JSONObject)insurance.get(2);
				jsondata.add((String)tertiaryInsurance.get("InsurancePlanName"));

				JSONArray transcation=(JSONArray) jsonObject.get("Transaction");
				JSONObject transcationList=(JSONObject)transcation.get(0);
				JSONObject type=(JSONObject)transcationList.get("EventType");
				String typeCode=(String)type.get("EventTypeCode");
				String typeDesc=(String)type.get("EventTypeDescription");
				jsondata.add(typeCode+" - "+typeDesc);


				String lastName=(String) transcationList.get("EmployeeLastName");
				String firstName=(String) transcationList.get("EmployeeFirstName");
				String empCode=(String) transcationList.get("EmployeeId");
				jsondata.add(firstName+" "+lastName+" "+"("+empCode+")");

				String eventDateTime=(String) transcationList.get("EventDateTime");
				String[] splitTime = eventDateTime.split("T");
				String date=splitTime[0];
				expDate = jsonDate.parse(date);
				jsondata.add(appDate.format(expDate));

				break;
			}
		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return jsondata;

	}
	/** To Verify the section names in AllData Panel**/
	public void verifyPatinetInfoSectionInAllDataPanel(DataTable patinetSections){
		try {
			ArrayList<String> expectedPatientInfoSections = new ArrayList<>(patinetSections.asList());
			report.reportInfo("Expected Patinet Info Sections: "+expectedPatientInfoSections);
			webActions.waitUntilisDisplayed(lbl_DataInAllDataPanel, "AllPanels");
			ArrayList<String> actualPatientInfoSections=getDatafromAllDataPanel(lbl_SectionNamesInAllDataPanel);
			report.reportInfo("Displayed Patient Info Sections from AllData Panel: "+actualPatientInfoSections);
			ArrayList<String>unmatchedSections=webActions.getUmatchedInArrayComparision(actualPatientInfoSections, expectedPatientInfoSections);
			if(unmatchedSections.size()==0){
				report.reportPass("Verified Patient Info Sections from AllData Panel");
			}
			else{
				throw new Exception("Fail to Patient Info Sections from AllData Panel and unmatched sections are: "+unmatchedSections);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	/** To verify the labels in each section from AllData Panel**/
	public void verifySectionLabelsInAllDataPanel(DataTable patinetSectionLabels){
		try {
			ArrayList<String> expPatientInfoSectionLabels=new ArrayList<>(patinetSectionLabels.asList());		
			report.reportInfo("Expected Patient Info Section Labels: "+expPatientInfoSectionLabels);
			webActions.waitForVisibility(lbl_DataInAllDataPanel, "AllPanels");
			ArrayList<String> actualPatientInfoSectionLabels=webActions.getDatafromWebTable(lbl_SectionLabelsInAllDataPanel);
			report.reportInfo("Displayed Patient Info Sections in AllDataPanel: "+actualPatientInfoSectionLabels);
			ArrayList<String>unmatchedPatientInfoSectionLabels=webActions.getUmatchedInArrayComparision(actualPatientInfoSectionLabels, expPatientInfoSectionLabels);
			if(unmatchedPatientInfoSectionLabels.size()==0){
				report.reportPass("Verified patient Info sections from AllDataPanel");
			}
			else{
				throw new Exception("Fail to verify patient Info sections from AllDataPanel and unmatched data is: "+unmatchedPatientInfoSectionLabels);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}
	/** To verify the labels data from each section of AllData Panel**/
	public void verifyAllDataPanelInfo(String scenarioName){
		try {

			ArrayList<String> expPanelInfo=getSummaryInfoDataFromJSONFile(scenarioName);			
			report.reportInfo("Expected Panel Info data: "+expPanelInfo);
			webActions.waitForVisibility(lbl_DataInAllDataPanel, "AllPanels");
			ArrayList<String> actualPatientInfo=webActions.getDatafromWebTable(lbl_SectionDataInAllDataPanel);
			report.reportInfo("Displayed Summary Fields data in Application: "+actualPatientInfo);
			ArrayList<String>unmatchedPatientInfo=webActions.getUmatchedInArrayComparision(actualPatientInfo, expPanelInfo);
			if(unmatchedPatientInfo.size()==0){
				report.reportPass("Verified visit patient Info from All Data Panel");
			}
			else{
				throw new Exception("Fail to verify patient Info from All Data Panel and unmatched data is: "+unmatchedPatientInfo);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}
	/** To get the section names from AllData Panel**/
	public ArrayList<String> getDatafromAllDataPanel(List<WebElement> elements){
		ArrayList<String> data= new ArrayList<String>();
		List<WebElement> allElement = elements;
		int sectionsSize=allElement.size();
		int sectionsSize1=sectionsSize-1;
		for (int i = 0; i < sectionsSize1; i++) {
			String txt=allElement.get(i).getText();
			data.add(txt);			
		}		
		return data;
	}


	public void verifyExpandandCollapsethePanel() throws Exception{
		StringBuilder unmatch=new StringBuilder();		
		webActions.waitForVisibility(lbl_DataInAllDataPanel, "DataInPanel");		
		String actualExpandStatus=webActions.getAttributeValue(icon_AllDataExpandCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons e-expand-icon".contentEquals(actualExpandStatus)){
			report.reportPass("By default All Data Panel is displayed in Expand mode");
		}else{
			unmatch.append("Panle is not dispalyed in Expand mode by default");
			report.reportFail("Panle is not dispalyed in Expand mode by default");
		}
		webActions.waitAndClick(icon_AllDataExpandCollapse, "ExpandandCollapse");
		webActions.waitForPageLoaded();
		String actualCollapseStatus=webActions.getAttributeValue(icon_AllDataExpandCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons".contentEquals(actualCollapseStatus)){
			report.reportPass("All Data Panel Successfully Collapsed");
		}
		else{
			unmatch.append("All Data Panle is not Collapsed");
			report.reportFail("All Data Panle is not Collapsed");
		}		
		if(unmatch.length()==0){
			report.reportPass("All Data Panel Successfully Expanded and Collapsed");
		}else{
			report.reportFail("Failed to verify the Expand and Collapse of the All Data Panel"+unmatch);
		}

	}
	public void verifyfields(){
		try {
			webActions.waitForVisibility(btn_TransHistory, "TransactionHistory");
			webActions.assertDisplayed(btn_TransHistory, "TransactionHistory");			
			report.reportPass("Transactions  button is displayed on visit summary page");
		} catch (Exception e) {
			report.reportFail("Transactions  button is not displayed on visit summary page");
		}
	}
	public void clickOnTransHistory(){
		try {
			webActions.waitForVisibility(btn_TransHistory, "TransactionHistory");
			webActions.clickAction(btn_TransHistory, "TransactionHistory");
			report.reportPass("Successfully clicked on Transaction History button");
		} catch (Exception e) {
			report.reportFail("Failed to click on Transaction History button");
		}
	}

	public void verifyTransactionHistoryTitle(String title) {
		try {	
			clickOnTransHistory();			
			webActions.waitForVisibility(txt_TransHistoryTitle, "TransactionHistory Title");
			String ActualTitle = webActions.getText(txt_TransHistoryTitle, "TransactionHistory Title");
			if (ActualTitle.contentEquals(title)){
				report.reportPass("Verified TransactionHistory title successfully");
				report.reportInfo("Actual TransactionHistory title: "+ActualTitle);
			}
			else{
				throw new Exception("Actual Columns title did not match with Expected and Actual title is: "+ActualTitle);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());

		}
	}

	/** To verify the header columns from transaction history window**/
	public void verifyColumnsInTransHistory(DataTable tranHistoryColumns){
		try {
			webActions.waitUntilEnabledAndClick(btn_TransHistory, "TransactionHistory");
			ArrayList<String> expTransHistoryColumns=new ArrayList<>(tranHistoryColumns.asList());		
			report.reportInfo("Expected transaction history columns: "+expTransHistoryColumns);		
			ArrayList<String> actualTransHistoryColumns=webActions.getDatafromWebTable(lbl_TransHistoryColumns);
			report.reportInfo("Displayed transaction history columns in transaction window: "+actualTransHistoryColumns);
			ArrayList<String>unmatchedTransHistoryColumns=webActions.getUmatchedInArrayComparision(actualTransHistoryColumns, expTransHistoryColumns);
			if(unmatchedTransHistoryColumns.size()==0){
				report.reportPass("Verified transaction history columns from transaction window");
			}
			else{
				throw new Exception("Fail to verify transaction history columns from transaction window and unmatched data is: "+unmatchedTransHistoryColumns);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	public void clickCrossInTransWindow(){
		try {
			clickOnTransHistory();
			webActions.waitForVisibility(btn_TransHistoryCross, "TransactionHistoryClose");
			webActions.click(btn_TransHistoryCross, "TransactionHistoryClose");
			report.reportPass("Successfully closed Transaction History window");
		} catch (Exception e) {
			report.reportFail("Fail to close the transaction history window");
		}
	}
	public void verifyTransactionHistoryEventType(String data) {
		try {	
			clickOnTransHistory();			
			webActions.waitForVisibility(txt_TransHistoryEventType, "TransactionHistoryEventType");
			String actualEvent = webActions.getText(txt_TransHistoryEventType, "TransactionHistoryEventType");
			String expectedEvent=geDataFromJSONFile(data);
			if (actualEvent.contentEquals(expectedEvent)){
				report.reportPass("Verified TransactionHistory event type successfully");
				report.reportInfo("Actual TransactionHistory event: "+actualEvent);
			}
			else{
				throw new Exception("Actual event did not match with Expected and Actual event is: "+actualEvent);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());

		}
	}

	public String geDataFromJSONFile(String data){
		String jsondata=null;
		try {
			FileReader reader = new FileReader(ADTJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");				
			JSONArray transcation=(JSONArray) jsonObject.get("Transaction");

			if("EventTypeCode".contentEquals(data)){
				JSONObject transcationList=(JSONObject)transcation.get(0);
				JSONObject type=(JSONObject)transcationList.get("EventType");
				String typeCode=(String)type.get("EventTypeCode");
				String typeDesc=(String)type.get("EventTypeDescription");
				jsondata=typeCode+" - "+typeDesc;

			}
		}
		catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return jsondata;

	}
	
	public void waitforPaymentFacilitatorPanel() throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(lbl_NoPayments, "No Payments Error Message");
		} catch (Exception e) {
			webActions.waitForVisibility(tbl_PaymentFacilitatorPanel, "Payment Facilitator Panel");
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}