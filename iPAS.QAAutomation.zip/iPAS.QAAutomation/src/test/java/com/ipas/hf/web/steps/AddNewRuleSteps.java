package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.AddNewRulePage;
import com.ipas.hf.web.pages.ipasPages.ViewStandardMedicalNecessityResponseCodesPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class AddNewRuleSteps {

	AddNewRulePage addNewRule=new  AddNewRulePage();
	
	@Then("Navigate to Add New Rule page")
	public void navigate_to_Add_New_Rule_page() throws InterruptedException {
		addNewRule.clickRulesConfiguration();
	}

	@Then("verify Breadcrumb in Add New Rule page")
	public void verify_Breadcrumb_in_Add_New_Rule_page(DataTable breadcrumb) {
		addNewRule.verifyBreadcrumb(breadcrumb);
	}
	
	@Then("Verify the feilds in Add New Rule page")
	public void verify_the_feilds_in_Add_New_Rule_page(DataTable fieldNames) {
		addNewRule.verifyFieldNames(fieldNames);
	}
	
	@Then("Verify mandatory field validation messages in Add New Rules page")
	public void verify_mandatory_field_validation_messages_in_Add_New_Rules_page(DataTable errorMessages) {
		addNewRule.verifyMandatoryFieldValidationMessages(errorMessages);
	}
	
	@Then("Verify Unsaved Changes Discard popup message as {string} and Cancel button functionality")
	public void verify_Unsaved_Changes_Discard_popup_message_as_and_Cancel_button_functionality(String message) {
		addNewRule.verifyUnsavedChangesPopupAndCancelButton(message);
	}
	
	@Then("Change Facility name {string} and verify in Add New Rule page")
	public void change_Facility_name_and_verify_in_Add_New_Rule_page(String facility) {
		addNewRule.verifyFacilityNameAndDefaultStatusofActiveToggle(facility);
	}
	
	@Then("Add New Rule and verify the data")
	public void add_New_Rule_and_verify_the_data(DataTable testData) {
		addNewRule.AddNewRule(testData);
	}
	
	@Then("Add New Rule with all Element names")
	public void add_New_Rule_with_all_Element_names(DataTable testData) {
		addNewRule.AddNewRulewithAllElementNames(testData);
	}
	
	@Then("verify Breadcrumb in Edit Rule page")
	public void verify_Breadcrumb_in_Edit_Rule_page(DataTable breadcrumb) {
		addNewRule.verifyBreadcrumbForEditRule(breadcrumb);
	}
	
	@Then("Verify Unsaved Changes Discard popup message as {string} in Edit rule page")
	public void verify_Unsaved_Changes_Discard_popup_message_as_in_Edit_rule_page(String message) {
		addNewRule.verifyUnsavedChangesPopupEditRuleAndCancelButton(message);
	}

	@Then("Verified Toggle Switch Status for {string} Rule")
	public void verified_Toggle_Switch_Status_for_Rule(String status) {
		addNewRule.verifyToggleSwitchStatus(status);
	}

	@Then("Update status for Rule")
	public void update_status_for_Rule(DataTable testData) {
		addNewRule.changeRuleStatusAndVerify(testData);
	}
	
	@Then("Update Rule and verify the data")
	public void update_Rule_and_verify_the_data(DataTable testData) {
		addNewRule.UpdateRule(testData);
	}
}
