package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.ExportExcelPage;

import cucumber.api.java.en.Then;

public class ExportExcelSteps {

	ExportExcelPage eportpage=new ExportExcelPage();	

	@Then("Verify the downloading of excel file as {string}")
	public void verify_the_downloading_of_excel_file_as(String fileName) {
		eportpage.verifyExportExcelDownload(fileName);
	}

}
