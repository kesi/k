package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.CreateOrganizationandTenantPage;
import com.ipas.hf.web.pages.ipasPages.DefaultSearchPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class CreateOrganizationandTenantSteps {

	CreateOrganizationandTenantPage createOrgTenant=new CreateOrganizationandTenantPage();
	
	@Then("Verify the display of Organization Maintenance link and Text Message")
	public void verify_the_display_of_Organization_Maintenance_link_and_Text_Message(DataTable testData) {
		createOrgTenant.verifyLableNameandTextMessage(testData);
	}
	
	@Then("Verify feild names and validation messages and close the window")
	public void verify_feild_names_and_validation_messages_and_close_the_window(DataTable testData) {
		createOrgTenant.verifyAddNewOrganizationFieldNamesandValidationMessages(testData);
	}
	
	@Then("Verify the creation of New Organization as {string}")
	public void verify_the_creation_of_New_Organization_as(String orgName) {
		createOrgTenant.createNewOrganization(orgName);
	}

	
	@Then("Verify feild names in Add Tenant model window")
	public void verify_feild_names_in_Add_Tenant_model_window(DataTable feildNames) {
		createOrgTenant.verifyFieldNamesinAddTenantModelWindow(feildNames);
	}

	@Then("Verify placeholders in Add Tenant model window")
	public void verify_placeholders_in_Add_Tenant_model_window(DataTable placeholder) {
		createOrgTenant.verifyPlaceholderinAddTenantModelWindow(placeholder);
	}

	@Then("Verify mandatory field validation messages")
	public void verify_mandatory_field_validation_messages(DataTable messages) {
		createOrgTenant.verifyMandatoryvalidationMessages(messages);
	}
	
	@Then("Verify Validation Messages in the AddTenant Model Window")
	public void verify_Validation_Messages_in_the_AddTenant_Model_Window(DataTable messages) {
		createOrgTenant.verifyValidationMessagesinAddTenantModelWindow(messages);
	}
	
	@Then("Verify the Cancel button functionality in Add Tenant model window")
	public void verify_the_Cancel_button_functionality_in_Add_Tenant_model_window() {
		createOrgTenant.verifyCancelButton();
	}

	@Then("Verify the creation of Add New Tenant")
	public void verify_the_creation_of_Add_New_Tenant(DataTable testData) {
		createOrgTenant.addNewTenant(testData);
	}

}
