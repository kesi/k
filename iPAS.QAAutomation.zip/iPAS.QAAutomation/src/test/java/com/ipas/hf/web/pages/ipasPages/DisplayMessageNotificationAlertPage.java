package com.ipas.hf.web.pages.ipasPages;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.gargoylesoftware.htmlunit.WebClient;
import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

public class DisplayMessageNotificationAlertPage extends BasePage {

	@FindBy(xpath = "//input[@id='username']")
	private WebElement txt_UserName;

	private static final String UPDATEPATIENTVISITJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\UpdatePatientVisit.json";
	private static final String UPDATEMESSAGEJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\MessageAlert.json";	
	private JSONObject jsonObject;
	private RestActions rest = new RestActions();
	private StepLogging log = StepLogging.getLoggingObject();


	//@FindBy(xpath = "//button[2]/span[1]/div[2]/div[1]")
	//private WebElement txt_MsgCountOnVisitCard;

	@FindBy(xpath = "//div[@class = 'e-acrdn-panel']//div")
	private List<WebElement> lst_AllElementsOnVisitMainPage;

	@FindBy(xpath = "//div[@class='card-body']//div[2]//div[1]")
	private WebElement txt_MsgCountOnVisitCard;


	@FindBy(xpath = "//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']")
	private List<WebElement> li_DefaultGridStatusNames;

	@FindBy(xpath = "//button[2]/span[1]/img[1]")
	private WebElement msg_Box;

	@FindBy(xpath = "//p[contains(text(),'PATIENT')]")
	private WebElement lbl_PatientInMsgBox;

	@FindBy(xpath = "//ipas-service-tracker-messaging-content[1]/div[1]/div[2]/p[1]")
	private WebElement txt_FirstMsg;

	@FindBy(xpath = "//ipas-service-tracker-messaging-content[1]/div[1]/div[3]/p[1]")
	private WebElement txt_SecondMsg;

	@FindBy(xpath = "//ipas-service-tracker-messaging-content[1]/div[1]/div[4]/p[1]")
	private WebElement txt_ThirdMsg;

	@FindBy(xpath = "//ipas-service-tracker-messaging-content[1]/div[1]/div")
	private List<WebElement> li_MsgCount;

	@FindBy(xpath = "//app-ipas-messaging-hub[1]//div[1]/div/div/div/span[1]")
	private WebElement txt_MsgPanelheaderCount;

	@FindBy(xpath = "//div[2]/p[1]/span[1]")
	private WebElement txt_panelCount;

	@FindBy(xpath = "//ejs-dashboardlayout[1]//app-ipas-messaging-hub[1]//div[1]//div/div/div/p")
	private WebElement txt_MsgHubBesideSrvTrckPanel;

	@FindBy(xpath = "//app-ipas-messaging-panel-dialog[1]//img[1]")
	private WebElement btn_CloseMsgHub;

	@FindBy(xpath = "//app-ipas-messaging-panel[1]//textarea[1]")
	private WebElement txtbox_MessageHubTextBox;

	@FindBy(xpath = "//app-ipas-messaging-panel[1]//button[1]")
	private WebElement btn_MsgHubSendButton;

	/*@FindBy(xpath = "//div/p[@class='message__body message__body--system'][contains(text(),'Welcome to GRMC!')]")
	private WebElement lnk_MessageHubVimLink;*/
	
	@FindBy(xpath = "//p[contains(text(),'Welcome to GRMC')]")
	private WebElement lnk_MessageHubVimLink;
	
	@FindBy(xpath = "(//app-ipas-messaging-panel-dialog//span)[1]")
	private WebElement lbl_PatientName;

	@FindBy(xpath = "//label[contains(text(),'Settings')]")
	private WebElement lbl_Settings;

	@FindBy(xpath = "//p[contains(text(),'Manage Communication')]")
	private WebElement lbl_ManageCommunications;

	@FindBy(xpath = "//div[@id='_dialog-content']/div[3]/ejs-switch")
	private WebElement btn_ManageCommunicationsToggle;

	@FindBy(xpath = "(//img[@src='assets/images/close.svg'])[2]")
	private WebElement lbl_ManageCommunicationsClose;

	@FindBy(xpath = "(//img[@src='assets/images/close.svg'])[1]")
	private WebElement lbl_ManageHubClose;

	@FindBy(xpath = "(//app-ipas-visit-opt-in-out-history-item/div)[1]/img")
	private WebElement lbl_OptOutLockIcon;

	@FindBy(xpath = "(//app-ipas-visit-opt-in-out-history-item/div)[1]/p[1]")
	private WebElement lbl_OptOutLockUserName;

	@FindBy(xpath = "(//app-ipas-visit-opt-in-out-history-item/div)[1]/p[2]")
	private WebElement lbl_OptOutLockDesc1;	

	@FindBy(xpath = "(//app-ipas-visit-opt-in-out-history-item/div)[1]/p[3]")
	private WebElement lbl_OptOutLockDesc2;

	@FindBy(xpath = "(//app-ipas-visit-opt-in-out-history-item/div)[1]/p[4]")
	private WebElement lbl_OptOutLockDateTime;

	@FindBy(xpath = "(//app-ipas-visit-opt-in-out-history-item/div/img)[2]")
	private WebElement lbl_OptOutUnLockIcon;

	@FindBy(xpath = "//span/img")
	private WebElement lbl_OptNotesLockIcon;

	@FindBy(xpath = "(//app-ipas-visit-opt-in-out-history-item/div)[2]/p[2]")
	private WebElement lbl_OptOutUnLockDesc1;	

	@FindBy(xpath = "(//app-ipas-visit-opt-in-out-history-item/div)[2]/p[3]")
	private WebElement lbl_OptOutUnLockDesc2;

	@FindBy(xpath = "(//app-ipas-visit-opt-in-out-history-item/div)[2]/p[4]")
	private WebElement lbl_OptOutUnLockDateTime;

	@FindBy(xpath = "//img[@src='assets/images/close.svg']")
	private WebElement lbl_ManageHubCommunicationsClose;


	public DisplayMessageNotificationAlertPage() {
		PageFactory.initElements(driver, this);
	}


	public String getPhoneNumberfromJSONresponse(){
		String expectedResponseValue=null;
		try {
			// read the json file

			FileReader reader = new FileReader(UPDATEPATIENTVISITJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONArray patientPhonenum = (JSONArray) patientObject.get("PatientPhoneNumber");
			JSONObject pnum = (JSONObject) patientPhonenum.get(0);

			String expectedResponseValue1=  (String) pnum.get("PhoneNumber");
			expectedResponseValue=expectedResponseValue1.replaceAll("\\p{P}","");

		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return expectedResponseValue;

	}

	public void updateAddressInMsgAlert(String value ) throws ParseException {
		try{

			// read the json file

			FileReader reader = new FileReader(UPDATEMESSAGEJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject mobileObject = (JSONObject) jsonObject.get("mobileOriginate");
			JSONObject sourceObject =  (JSONObject) mobileObject.get("source");
			JSONObject messageObject =  (JSONObject) mobileObject.get("message");

			sourceObject.put("address", value);
			messageObject.put("content", rest.getUniqueNumber());

			FileWriter file = new FileWriter(UPDATEMESSAGEJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		}catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}


	public String getAddressFromJSONresponse(){
		String expectedResponseValue=null;
		try {
			// read the json file

			FileReader reader = new FileReader(UPDATEMESSAGEJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			JSONObject mobileObject = (JSONObject) jsonObject.get("mobileOriginate");
			JSONObject messageObject =  (JSONObject) mobileObject.get("message");

			expectedResponseValue=  (String)messageObject.get("content");
			System.out.println("Expected response value is :"+expectedResponseValue);
		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return expectedResponseValue;

	}

	public void waitForAllPanelsList(){
		try {
			Thread.sleep(3000);
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lst_AllElementsOnVisitMainPage, "AllPanel");
		} catch (Exception e) {
		}
	}

	public int msgCountOnVisitCard(String count) throws Exception{
		String text = null; int msgCountonVC = 0;
		try{
			webActions.waitForPageLoaded();
			waitForAllPanelsList();
			report.reportInfo("Grid column names are displayed");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txt_MsgCountOnVisitCard, "MsgCount",10);		
			report.reportPass("Message count is displayed on Visit Card");
			text = webActions.getText(txt_MsgCountOnVisitCard, "Msg Count");
			msgCountonVC = Integer.parseInt(text);
			report.reportInfo("Message count on Visit Card is :"+text);
			if(text.contentEquals(count)){
				report.reportPass("Message Count on Visit Card is :"+text);
			}else{
				throw new Exception("Unable to read message count on visit card");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}return msgCountonVC;
	}

	public void clickAndOpenMsgHub() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(msg_Box, "MessageBox");
			report.reportInfo("MessageGox is displayed");
			webActions.clickBYJS(msg_Box, "MessageBox");
			report.reportInfo("Clicked on MessageIcon on Visit Card");
			Thread.sleep(10000);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			try {
				webActions.waitAndGetText(lnk_MessageHubVimLink, "Patient Label");
			} catch (Exception e) {
			}
			report.reportPass("Message Hub is opened and PATIENT Label is displayed");	
			String actLinkText = webActions.waitAndGetText(lnk_MessageHubVimLink, "VimLink");	
			report.reportInfo("Actual Vim Link text is :"+actLinkText);
			if(actLinkText.contains("Welcome to GRMC! To expedite your Check-In")){
				report.reportPass("Vin Link is sent to Patient");
			}else{
				throw new Exception("Link is not displayed, failed to send Vim Link to Patient");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void compareMsgCount(String count) throws Exception{
		try{
			int msgCountOnVC = msgCountOnVisitCard(count);
			clickAndOpenMsgHub();
			int msgCountOnMsgHub = msgCountInMsgHub();
			if(msgCountOnVC==(msgCountOnMsgHub-1)){
				report.reportPass("Message count is matched");
			}else{
				report.reportFail("Message count is not matched");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public int msgCountInMsgHub() throws Exception{
		int msgPatientCount = 0;
		try{
			List<String> totalMsgCount = webActions.getDatafromWebTable(li_MsgCount);
			msgPatientCount = totalMsgCount.size();
			report.reportInfo("Total messages sent by Patient are :"+msgPatientCount);
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}return msgPatientCount;
	}


	public void verifyMSgTextinMsgHub(String count) throws Exception{
		String actText = null;String expText = null;
		try{
			webActions.waitForPageLoaded();
			actText = getAddressFromJSONresponse();
			report.reportInfo("Actual Text from Json is :"+actText);
			Thread.sleep(3000);
			webActions.waitForVisibility(txt_FirstMsg, "Msg in MSG Hub",25);
			if(count.contentEquals("1")){
				report.reportInfo("expected count is :"+count);
				expText = webActions.getText(txt_FirstMsg, "Msg in MSG Hub");
				if(actText.contentEquals(expText)){
					report.reportInfo("Expected Text is :"+actText);
					report.reportPass("First Msg is posted sucessfully");
				}
			}else if(count.contentEquals("2")){			
				report.reportInfo("expected count is :"+count);
				expText = webActions.getText(txt_SecondMsg, "Msg in MSG Hub");
				if(actText.contentEquals(expText)){
					report.reportInfo("Expected Text is :"+actText);
					report.reportPass("Second Msg is posted sucessfully");
				}
			}else if(count.contentEquals("3")){
				report.reportInfo("expected count is :"+count);
				expText = webActions.getText(txt_ThirdMsg, "Msg in MSG Hub");
				if(actText.contentEquals(expText)){
					report.reportInfo("Expected Text is :"+actText);
					report.reportPass("Third Msg is posted sucessfully");
				}
			}	
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyMsgCountFromVisitCard(String expCount) throws Exception{
		try{
			//waitForAllPanelsList();
			//clickAndOpenMsgHub();
			ArrayList<String> listCount = new ArrayList<String>();
			webActions.waitForVisibility(txt_MsgPanelheaderCount, "count on header",15);
			String txt1 = webActions.getText(txt_MsgPanelheaderCount, "count on header");
			report.reportInfo("txt1 value is :"+txt1);
			listCount.add(txt1);

			String txt2 = webActions.getText(txt_panelCount, "count on panel");
			String str = txt2;
			String panelCount = str.substring(str.indexOf("(")+1,str.indexOf(")"));
			report.reportInfo("panelCount value is :"+panelCount);
			listCount.add(panelCount);

			report.reportInfo("Array values are :"+listCount);
			ArrayList<String> unmatchedCount=webActions.isFullArrayMatchWithData(listCount, expCount);

			if(unmatchedCount.size()==0){
				report.reportPass("All counts verified successfully and displayed data is: " + listCount);
			}else{
				throw new Exception("Failed to verify the Counts, and unmatched data is: "+unmatchedCount);
			}

		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyMessageHubBesideServiceTrakcer(){
		try{
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String expPanelName = "Messaging Hub";
			try {
				webActions.waitForVisibility(txt_MsgHubBesideSrvTrckPanel, "Message Hub",60);
			} catch (Exception e) {
			}
			String actPanelName= webActions.waitAndGetText(txt_MsgHubBesideSrvTrckPanel, "Message Hub");
			report.reportInfo("Message Hub is displayed properly");
			if(expPanelName.contentEquals(actPanelName)){
				report.reportPass("Message Hub is displayed successfully");
			}else{
				throw new Exception("Failed to read Message Hub in Patient Visit Main Page");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void clickCloseButtonInMessageHub() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.isDisplayed(btn_CloseMsgHub, "Msg Hub Close Button");
			report.reportInfo("Close button is displayed in Message Hub");
			webActions.clickBYJS(btn_CloseMsgHub, "Msg Hub Close Button");
			report.reportInfo("Clicked on Close button is message button");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void sendMessagefromMessageHubOnVisitCard(String actText) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txtbox_MessageHubTextBox, "MsgHub TextBox");
			report.reportInfo("Text Box is displayed in Message Hub Panel");
			webActions.sendKeys(txtbox_MessageHubTextBox, actText, "TextBox");
			webActions.waitForClickAbility(btn_MsgHubSendButton, "Send Button");
			webActions.clickBYJS(btn_MsgHubSendButton, "Send Button");
			report.reportPass("Clicked on Send Button in Message Hub");
			webActions.waitForPageLoaded();
			String expText = webActions.getText(txt_FirstMsg, "First Msg");
			if(actText.contentEquals(expText)){
				report.reportPass("Successfully sent message");
			}else{
				throw new Exception("failed to read sent message in Message Hub");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void waitforServiceTrackerPageLoad() throws Exception{
		try{
			Thread.sleep(35000);
		}catch(Exception e){			
			report.reportFail(e.getMessage());
		}
	}



	public DisplayMessageNotificationAlertPage openIpasApp() {
		try {
			String URL = TestBase.prop.ipasURL();
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to Open iPAS application");
		}
		return (DisplayMessageNotificationAlertPage) base(DisplayMessageNotificationAlertPage.class);
	}

	public void verifyPatientName(String data){
		try {
			String expPatientName=getdataFromJSON(data);
			Thread.sleep(3000);
			webActions.waitForVisibility(lbl_PatientName, "PatientName");
			String actualPatientName = webActions.getText(lbl_PatientName, "PatientName");
			actualPatientName=actualPatientName.replace("\n"," ");			
			if (actualPatientName.contentEquals(expPatientName)){
				report.reportPass("Verified patient name in All Data page successfully");
				report.reportInfo("Actual Patient Name: "+actualPatientName);
				report.reportInfo("Actual Patient Name: "+expPatientName);
			}
			else{
				throw new Exception("Actual Patient Name did not match with Expected and Actual Name is: "+actualPatientName);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public String getdataFromJSON(String data){
		String expectedResponseValue=null;
		try {
			FileReader reader = new FileReader(UPDATEPATIENTVISITJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");

			switch(data){
			case "patientName":
				String firstName=(String) patientObject.get("PatientFirstName");
				String lastName=(String) patientObject.get("PatientLastName");
				expectedResponseValue=firstName+" "+lastName;
				break;
			}
		} catch (Exception e) {

		}
		return expectedResponseValue;
	}

	public String getSystemCurrentDate(){
		String sysDate=new SimpleDateFormat("MM/dd/yy").format(Calendar.getInstance().getTime());
		return sysDate;	
	}
	public void verifyOptOutLcokIcon(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lbl_Settings, "Settings");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_ManageCommunications, "ManageCommunications");
			webActions.click(lbl_ManageCommunications, "ManageCommunications");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_ManageCommunicationsToggle, "ManageCommunicationsToggle");
			webActions.click(btn_ManageCommunicationsToggle, "ManageCommunicationsToggle");
			webActions.waitForPageLoaded();
			Thread.sleep(5000);
			webActions.click(lbl_ManageCommunicationsClose, "ManageCommunicationsToggleClose");
			Thread.sleep(5000);
			String lokIcon=webActions.getAttributeValue(lbl_OptOutLockIcon, "src", "LockICon");
			ArrayList<String> expData=new ArrayList<>();
			expData.add("lock.svg");
			expData.add("opted out message communication");
			expData.add("for the patient");
			String date=getSystemCurrentDate();
			expData.add(date);
			ArrayList<String> actData=new ArrayList<>();
			actData.add(lokIcon);
			actData.add(webActions.getText(lbl_OptOutLockDesc1, "Desc1"));
			actData.add(webActions.getText(lbl_OptOutLockDesc2, "Desc2"));
			actData.add(webActions.getText(lbl_OptOutLockDateTime, "DateTime"));
			webActions.click(lbl_ManageHubClose, "ManageHubClose");
			webActions.waitForPageLoaded();
			ArrayList<String> unmatched=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatched.size()==0){
				report.reportPass("Verified opt out lock icon successfully");
			}
			else{
				throw new Exception("Fail to verify pot out lock icon and unmatched : "+unmatched);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyOptOutLcokIconFromMesgHubAndTracker(){
		try{
			webActions.waitForPageLoaded();
			String lokIcon=webActions.getAttributeValue(lbl_OptOutLockIcon, "src", "LockICon");
			ArrayList<String> expData=new ArrayList<>();
			expData.add("lock.svg");
			expData.add("opted out message communication");
			expData.add("for the patient");
			String date=getSystemCurrentDate();
			expData.add(date);
			ArrayList<String> actData=new ArrayList<>();
			actData.add(lokIcon);
			actData.add(webActions.getText(lbl_OptOutLockDesc1, "Desc1"));
			actData.add(webActions.getText(lbl_OptOutLockDesc2, "Desc2"));
			actData.add(webActions.getText(lbl_OptOutLockDateTime, "DateTime"));		
			webActions.waitForPageLoaded();
			ArrayList<String> unmatched=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatched.size()==0){
				report.reportPass("Verified opt out lock icon successfully");
			}
			else{
				throw new Exception("Fail to verify pot out lock icon and unmatched : "+unmatched);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyNoteLock(){
		try {
			webActions.waitForPageLoaded();
			String lokIcon=webActions.getAttributeValue(lbl_OptNotesLockIcon, "src", "LockICon");
			if(lokIcon.contains("notelock.png")){
				report.reportPass("Verified opt out lock icon on visit card successfully");
			}
			else{
				throw new Exception("Fail to verify pot out lock icon visit card and displayed : "+lokIcon);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyOptOutUnLcokIconFromMesgHub(){		
		try{
			webActions.waitForPageLoaded();
			webActions.click(lbl_Settings, "Settings");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_ManageCommunications, "ManageCommunications");
			webActions.click(lbl_ManageCommunications, "ManageCommunications");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_ManageCommunicationsToggle, "ManageCommunicationsToggle");
			webActions.click(btn_ManageCommunicationsToggle, "ManageCommunicationsToggle");
			webActions.waitForPageLoaded();
			Thread.sleep(5000);
			webActions.click(lbl_ManageHubCommunicationsClose, "ManageCommunicationsClose");
			Thread.sleep(5000);		
			String lokIcon=webActions.getAttributeValue(lbl_OptOutUnLockIcon, "src", "UnLockICon");
			ArrayList<String> expData=new ArrayList<>();
			expData.add("unlock.svg");
			expData.add("opted in message communication");
			expData.add("for the patient");
			String date=getSystemCurrentDate();
			expData.add(date);
			ArrayList<String> actData=new ArrayList<>();
			actData.add(lokIcon);
			actData.add(webActions.getText(lbl_OptOutUnLockDesc1, "Desc1"));
			actData.add(webActions.getText(lbl_OptOutUnLockDesc2, "Desc2"));
			actData.add(webActions.getText(lbl_OptOutUnLockDateTime, "DateTime"));		
			webActions.waitForPageLoaded();
			ArrayList<String> unmatched=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatched.size()==0){
				report.reportPass("Verified opt in lock icon successfully");
			}
			else{
				throw new Exception("Fail to verify opt in lock icon and unmatched : "+unmatched);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyOptOutUnLcokIconFromTracker(){		
		try{
			webActions.waitForPageLoaded();				
			String lokIcon=webActions.getAttributeValue(lbl_OptOutUnLockIcon, "src", "UnLockICon");
			ArrayList<String> expData=new ArrayList<>();
			expData.add("unlock.svg");
			expData.add("opted in message communication");
			expData.add("for the patient");
			String date=getSystemCurrentDate();
			expData.add(date);
			ArrayList<String> actData=new ArrayList<>();
			actData.add(lokIcon);
			actData.add(webActions.getText(lbl_OptOutUnLockDesc1, "Desc1"));
			actData.add(webActions.getText(lbl_OptOutUnLockDesc2, "Desc2"));
			actData.add(webActions.getText(lbl_OptOutUnLockDateTime, "DateTime"));		
			webActions.waitForPageLoaded();
			ArrayList<String> unmatched=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatched.size()==0){
				report.reportPass("Verified opt in lock icon successfully");
			}
			else{
				throw new Exception("Fail to verify opt in lock icon and unmatched : "+unmatched);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_UserName);
	}

}
