package com.ipas.hf.web.steps;

import org.json.simple.parser.ParseException;

import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.ipasPages.AddPatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.EditUserPage;
import com.ipas.hf.web.pages.ipasPages.EligibilityEditPage;
import com.ipas.hf.web.pages.ipasPages.EligibityPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class EligibilitySteps {
	
	EligibityPage eligibility=new EligibityPage();
	
	@Then("Update the Auto Run status for the facility {string} as {string}")
	public void update_the_Auto_Run_status_for_the_facility_as(String facilityName, String runStatus) throws Exception {
		eligibility.autoEligibilityTurnOnAndTrunOff(facilityName, runStatus);
	}
	
	@Then("Navigate to Account Search Page from Maintenance Page")
	public void navigate_to_Account_Search_Page_from_Maintenance_Page() throws Exception {
		eligibility.navigateAccountSearch();
	}
	
	
	@Then("Verify Eligibility Run Status if Auto Run is On {string}")
	public void verify_Eligibility_Run_Status_if_Auto_Run_is_On(String autoRunStatus) throws Exception {
		eligibility.verifyEligibilityRunStatusifAutoRunisOn(autoRunStatus);
		
	}
	
	@Then("Verify the Insurance Status in DataBase as the Insurance Sequence {int}")
	public void verify_the_Insurance_Status_in_DataBase_as_the_Insurance_Sequence(Integer sequenceNumber) {
		eligibility.verifyInsuranceStatusinDataBase(sequenceNumber);
	}

	@Then("Verify Eligibility Run Status if Auto Run is Off {string}")
	public void verify_Eligibility_Run_Status_if_Auto_Run_is_Off(String expAutoStatus) throws Exception {
		eligibility.verifyEligibilityRunStatusifAutoRunisOff(expAutoStatus);
	}
	
	@Then("Verify the Manual Run Eligibility process from Manual Tab")
	public void verify_the_Manual_Run_Eligibility_process_from_Manual_Tab(DataTable testData) throws Exception {
		eligibility.runManualEligibilityProcessinManualTab(testData);
	}
	
	@Then("Verify the Manual Run Eligibility process")
	public void verify_the_Manual_Run_Eligibility_process(DataTable testData) throws Exception {
		eligibility.runManualEligibilityProcessForAllInsurance(testData);
	}
	
	@Then("Verify Recheck Eligibility process")
	public void verify_Recheck_Eligibility_process(DataTable testData) throws Exception {
		eligibility.recheckEligibility(testData);
	}
	
	@Then("Verify the first visit insurance status as {string}")
	public void verify_the_first_visit_insurance_status_as(String expStatus) throws Exception {
		eligibility.verifyInsuranceStatus(expStatus);
	}

	@Then("Update Eligibility JSON file for Resue")
	public void update_Eligibility_JSON_file_for_Resue() throws Exception {
		eligibility.updateEligibilityJSONforReuse();
	}
	
	@Then("Verify the Reuse Eligibility Run Status {string}")
	public void verify_the_Reuse_Eligibility_Run_Status(String expStatus) throws Exception {
		eligibility.verifyReuseEligibilityRunStatus(expStatus);
	}
	
	@Then("Update Cascade Search for the facility {string} as {string}")
	public void update_Cascade_Search_for_the_facility_as(String facilityName, String cascadeSearchStatus) throws Exception {
		eligibility.cascadeSearchTurnOnAndTrunOff(facilityName, cascadeSearchStatus);
	}
	
	@Then("Update Eligibility JSON file {string}")
	public void update_Eligibility_JSON_file(String type) throws Exception {
		eligibility.updateEligibilityJSON(type);
	}
	
	@Then("Verify Auto Cascade search functionality")
	public void verify_Auto_Cascade_search_functionality() {
		eligibility.verifyAutoCasCadeSearch();
	}

	@Then("Verify Manual Cascade search functionality")
	public void verify_Manual_Cascade_search_functionality(DataTable testData) throws Exception {
		eligibility.verifyManualCasCadeSearch(testData);
	}
	
	@Then("Verify Recheck Eligibility functionality")
	public void verify_Recheck_Eligibility_functionality(DataTable testData) throws Exception {
		eligibility.recheckEligibilityinManualTab(testData);
	}
	
	@Then("Verify the navigation to Historical Eligibility Run and Most Recent Run")
	public void verify_the_navigation_to_Historical_Eligibility_Run_and_Most_Recent_Run(DataTable testData) {
	    eligibility.navigateHistoricalEligibilityRunandMostRecentRun(testData);
	}
	
	@Then("Verify the Associate Response to {string} Insurance")
	public void verify_the_Associate_Response_to_Insurance(String insuranceType) {
		eligibility.associateResponsetoInsurance(insuranceType);
	}

	@Then("Verify the Insurance Status in DataBase as the Insurance Sequence {int} and StatusId {string}")
	public void verify_the_Insurance_Status_in_DataBase_as_the_Insurance_Sequence_and_StatusId(Integer sequenceNumber, String expStatus) {
		eligibility.verifyInsuranceStatusinDataBase(sequenceNumber, expStatus);
	}
	
	@Then("Verify the Cascade search functionality in {string} tab")
	public void verify_the_Cascade_search_functionality_in_tab(String insuranceType) {
	    eligibility.verifyCascadeSearch(insuranceType);
	}
	
	@Then("Verify the Recheck Eligibility after Manual Run")
	public void verify_the_Recheck_Eligibility_after_Manual_Run(DataTable testData) throws Exception {
		eligibility.recheckEligibilityAfterManualRun(testData);
	}
	
	@Then("Verify the Module Status as {string}")
	public void verify_the_Module_Status_as(String expStatus) {
		eligibility.verifyModuleStatus(expStatus);
	}
	
	@Then("Manual Run Eligibility all Three Insurances")
	public void manual_Run_Eligibility_all_Three_Insurances(DataTable testData) throws Exception {
		eligibility.manualRunEligibilityThreeInsurances(testData);
	}

	@Then("Verify the Module Status in Eligibility Short panel and Account Search page {string}")
	public void verify_the_Module_Status_in_Eligibility_Short_panel_and_Account_Search_page(String expStatus) {
		eligibility.verifyEligibilityModuleStatusinPatientVistAllDataAndAccountSearch(expStatus);
	}
	@Then("Simple Search Account Number {string} in Account Search page")
	public void simple_Search_Account_Number_in_Account_Search_page(String accountNumber) {
		eligibility.simpleSearchInAccountSearch(accountNumber);
	}

	@Then("Verify Medicare Field Names in Short Panel")
	public void verify_Medicare_Field_Names_in_Short_Panel(DataTable testData) {
		eligibility.verifyMedicareFieldNamesInShortPanel(testData);
	}

	@Then("Verify Medicare Values in Short Panel")
	public void verify_Medicare_Values_in_Short_Panel(DataTable testData) {
		eligibility.verifyMedicareValuesInShortPanel(testData);
	}
	
	@Then("Verify Non-Medicare Field Names in Short Panel")
	public void verify_Non_Medicare_Field_Names_in_Short_Panel(DataTable testData) {
		eligibility.verifyNonMedicareFieldNamesInShortPanel(testData);
	}

	@Then("Verify Non-Medicare Values in Short Panel")
	public void verify_Non_Medicare_Values_in_Short_Panel(DataTable testData) {
		eligibility.verifyNonMedicareValuesInShortPanel(testData);
	}
	
	@Then("Click on Eligibility Verification link and navigate to {string} Insurance tab")
	public void click_on_Eligibility_Verification_link_and_navigate_to_Insurance_tab(String insuranceType) {
		eligibility.clickEligibilityVerificationLinkAndNavigateInsuranceTab(insuranceType);
	}

	@Then("Verify Payment type fields in {string} Insurance tab")
	public void verify_Payment_type_fields_in_Insurance_tab(String insuranceType, DataTable testData) {
		eligibility.verifyPaymentTypeFields(insuranceType,testData);
	}

	@Then("Verify Payment type values in {string} Insurance tab")
	public void verify_Payment_type_values_in_Insurance_tab(String insuranceType, DataTable testData) {
		eligibility.verifyPaymentTypeValues(insuranceType,testData);
	}
	
	@Then("Verify the panel header names for {string} plan from the long Panel")
	public void verify_the_panel_header_names_for_plan_from_the_long_Panel(String insuranceType,DataTable testData) {
		eligibility.verifyMedicarePanelHeaderNames(insuranceType,testData);
	}

	@Then("Verify the Medicare Benefits- Part A panel Names and Status")
	public void verify_the_Medicare_Benefits_Part_A_panel_Names_and_Status(DataTable testData) {
		eligibility.verifyMedicareBenefitsPartAPanelNamesAndStatus(testData);
	}

	@Then("Verify the Medicare Benefits- Part B panel Names and Status")
	public void verify_the_Medicare_Benefits_Part_B_panel_Names_and_Status(DataTable testData) {
		eligibility.verifyMedicareBenefitsPartBPanelNamesAndStatus(testData);
	}
	
	@Then("Verify the Non-Medicare Benefits panel Names and Status")
	public void verify_the_Non_Medicare_Benefits_panel_Names_and_Status(DataTable testData) {
		eligibility.verifyNonMedicareBenefitsPanelNamesAndStatus(testData);
	}
	
	@Then("Navigate to Account Search Page from Maintenance Page for Retry ran")
	public void navigate_to_Account_Search_Page_from_Maintenance_Page_for_Retry_ran() throws Exception {
		eligibility.navigateAccountSearchRetryRun();
	}

	@Then("Verify Failed Eligibility Retry Process {string}")
	public void verify_Failed_Eligibility_Retry_Process(String expStatus) throws Exception {
		eligibility.verifyEligibilityRetryRunStatus(expStatus);
	}
	
	@Then("Verify the Export Eligibility")
	public void verify_the_Export_Eligibility() {
		eligibility.verifyExportEligibility();
	}
	
	@Then("Navigate to Eligibility Verification long panel from All Modules popup in Account Search page")
	public void navigate_to_Eligibility_Verification_long_panel_from_All_Modules_popup_in_Account_Search_page() {
		eligibility.navigateEligibilityVerificationLongPanelFromAllModulesPopup();
	}
	
	@Then("Navgate to Patient Visit Full page")
	public void navgate_to_Patient_Visit_Full_page() {
		eligibility.navigateAllDataPage();
	}
	
	@Then("Verify the display of validation messages on Visit Date field if Payer not allowed Future and Past DateofService")
	public void verify_the_display_of_validation_messages_on_Visit_Date_field_if_Payer_not_allowed_Future_and_Past_DateofService(DataTable testData) {
		eligibility.verifyValidationMessagesInVisitDate(testData);
	}

	
	
}