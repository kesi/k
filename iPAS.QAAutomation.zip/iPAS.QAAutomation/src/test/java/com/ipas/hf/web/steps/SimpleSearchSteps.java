package com.ipas.hf.web.steps;
import java.util.List;

import com.ipas.hf.web.pages.ipasPages.AddPatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.PatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.PatientVisitSummaryAllDataPanelPage;
import com.ipas.hf.web.pages.ipasPages.SimpleSearchPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;
import net.sourceforge.htmlunit.corejs.javascript.regexp.SubString;

public class SimpleSearchSteps {

	Login logIn = new Login();
	SimpleSearchPage search=new SimpleSearchPage();
	PatientVisitSummaryAllDataPanelPage allData=new PatientVisitSummaryAllDataPanelPage();



	
	@Then("Navigate to Account Search")
	public void Navigate_to_Account_Search() {
		search.accountsearchtab();
	}
	
	@Then("Get the value from response body and get value of {string}")
	public void get_the_value_from_response_body_and_get_value_of(String patientId) {
		search.visitIdvalue = logIn.getVisitIdFromResponse(patientId);
	}
	
	@Then("Verify able to Enter the data and Clear the data as {string}")
	public void verify_able_to_Enter_the_data_and_Clear_the_data_as(String data) {
		search.enterclearDatainSearch(data);
	}
	
	@Then("Enter data less than three characters as {string} and verify the results")
	public void Enter_data_less_than_three_characters_and_verify_the_results(String patientId) {
		search.visitIdvalue = logIn.getVisitIdFromResponse(patientId);
		search.searchForLessThanThreeChar(search.visitIdvalue.substring(0,2));
	}

	@Then("Enter the search criteria as {string} and columnname as {string} and verify the search results")
	public void Enter_the_search_criteria_and_verify_the_search_results(String visitId,String columnname,DataTable columnNames)
    {
		search.visitIdvalue = logIn.getVisitIdFromResponse(visitId);
		search.columnSelection(columnNames,true);
		search.searchValidation(search.visitIdvalue,columnname);
    }
	
	@Then("Verify the maximum length of the search input box")
	public void Verify_the_maximum_length_of_the_search_input_box()
    {
		search.maxLengthOfSearchInput("25");
    }
	
	@Then("Verify the Hint text as {string} in Search field")
	public void verify_the_Hint_text_as_in_Search_field(String hintText) {
		search.verifyHintText(hintText);
	}

	@Then("Verify the No results are found validation message if user enter invalid data as {string} and validation message as {string}")
	public void verify_the_No_results_are_found_validation_message_if_user_enter_invalid_data_as_and_validation_message_as(String data, String validationMessage) {
		search.verifyNoResultsarefound(data, validationMessage);
	}
	
	@Then("enter data in Search TextBox as {string} and Verify the maximum number of auto suggestions")
	public void enter_data_in_Search_TextBox_as_and_Verify_the_maximum_number_of_auto_suggestions(String visitid){
		
		search.visitIdvalue = logIn.getVisitIdFromResponse(visitid);
		search.verifyMaxNumOFAutoSuggestion(search.visitIdvalue.substring(0,3));
	}
	
	@Then("Verify the search results are retained in search inputbox with search criteria as {string}")
	public void Verify_the_search_results_retained_in_search_input_box(String visitId) throws Exception
    {
		search.visitIdvalue = logIn.getVisitIdFromResponse(visitId);
	    search.verifySearchResultsRetained(search.visitIdvalue);
    }
	
	@Then("Verify the search results are retained in results grid with search criteria as {string} and columnname as {string}")
	public void Verify_the_search_results_retained_in_results_grid(String visitId,String columnname) throws Exception
    {
		search.visitIdvalue = logIn.getVisitIdFromResponse(visitId);
		search.verifyGridResultsRetained(search.visitIdvalue,columnname);
    }
	
	@Then("Enter the search criteria as {string} with columnname as {string} and click on account number")
	public void Enter_the_search_criteria_with_columnname_and_click_on_account_number(String visitId,String columnname,DataTable columnNames) throws Exception
    {
		search.searchValidation(visitId,columnname);
		allData.clickOnAccountLinkNumber();
    }
	
	
}