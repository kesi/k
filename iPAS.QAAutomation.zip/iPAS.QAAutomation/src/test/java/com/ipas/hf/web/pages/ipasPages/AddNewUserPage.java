package com.ipas.hf.web.pages.ipasPages;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.swing.text.html.HTML;

import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class AddNewUserPage extends BasePage {

	@FindBy(xpath="//span[text()='Users']")
	private WebElement lbl_UsersPanel;

	@FindBy(linkText="User Accounts")
	private WebElement lnk_UserAccounts;

	@FindBy(xpath="//div[contains(text(),'Add new users to iPAS, edit iPAS user profiles, ma')]")
	private WebElement msg_UserPanel;

	@FindBy(xpath="//span[@class='breadcrum-active']")
	private WebElement lbl_SystemConfiguration;


	@FindBy(xpath="//div[@id='six']/ipas-maintenance-panel[1]/ejs-accordion/div")
	private WebElement panel_Users;

	@FindBy(xpath="//input[@placeholder='Type Employee Name']")
	private WebElement txt_SearchEmployee;

	@FindBy(xpath="//button[text()='Add New User']")
	private WebElement btn_AddNewUser;

	@FindBy(xpath="//div[contains(@class,'breadcrum-container')]/span")
	private List<WebElement> lbl_Breadcrumb;

	@FindBy(xpath="//div[@class='form-group']/label")
	private List<WebElement> lbl_AllFeilds;

	@FindBy(xpath="//span[@class='mandatory']/../../label")
	private List<WebElement> lbl_MandatoryFeilds;

	@FindBy(xpath="//div[@class='mandatory']/div")
	private List<WebElement> lbl_MandatoryFieldValidationMessage;

	@FindBy(xpath="//div[@class='form-group']/div")
	private List<WebElement> lbl_MaximumLengthValidationMessage;

	@FindBy(xpath="//div[@class='form-group']/div/div")
	private WebElement lbl_PhoneValidationMessage;;

	@FindBy(xpath="//button[(text()='Submit')]")
	private WebElement btn_Submit;

	@FindBy(xpath="//button[text()='Clear']")
	private WebElement btn_Clear;

	@FindBy(xpath="//button[text()='Cancel']")
	private WebElement btn_Cancel;

	@FindBy(xpath="//input[@id='OperatorID']")
	private WebElement txt_OperatorID;

	@FindBy(id="lastname")
	private WebElement txt_LastName;

	@FindBy(id="firstname")
	private WebElement txt_FirstName;

	@FindBy(id="HireDate_input")
	private WebElement txt_EmployeeSince;

	@FindBy(xpath="//ejs-dropdownlist[@id='employeeroleId']//span/input")
	private WebElement dd_EmployeeroleId;

	@FindBy(xpath="//ejs-dropdownlist[@id='statusId']/span/span")
	private WebElement dd_StatusId;

	@FindBy(id="contactsEmail")
	private WebElement txt_Email;

	@FindBy(id="contactsPhone")
	private WebElement txt_ContactsPhone;

	@FindBy(xpath="//ejs-dropdownlist[@id='roleId']/span")
	private WebElement dd_RoleId;

	@FindBy(xpath="//ejs-dropdownlist[@id='roleId']/span/span")
	private WebElement dd_RoleId_Arrow;

	@FindBy(xpath="//ejs-dropdownlist[@id='facilityId']/span")
	private WebElement dd_FacilityId;

	@FindBy(xpath="//ejs-dropdownlist[@id='facilityId']/span/span")
	private WebElement dd_FacilityIdArrow;

	@FindBy(xpath="//div[@class='administrativeContainerWrapper']")
	private WebElement lbl_Administrative;

	@FindBy(xpath="//ejs-dropdownlist[@id='departmentId']/span")
	private WebElement dd_departmentId;

	@FindBy(xpath="//ejs-dropdownlist[@id='departmentId']/span/span")
	private WebElement dd_departmentIdArrow;

	@FindBy(xpath="//ejs-multiselect[@id='multiselect-checkbox']/div/div/span[5]")
	private WebElement chk_LobbyArrow;

	@FindBy(xpath="//ejs-multiselect[@id='multiselect-checkbox']/div/div")
	private WebElement dd_Lobby;

	@FindBy(xpath="//ejs-multiselect[@id='multiselectsupervisor-checkbox']/div/div")
	private WebElement dd_Supervisor;

	@FindBy(xpath="//ejs-multiselect[@id='multiselectsupervisor-checkbox']/div/div/span[5]")
	private WebElement chk_SupervisorArrow;


	@FindBy(xpath="//ejs-dropdownlist[@id='employeeroleId']/span/select/option")
	private WebElement li_EmployeeRole;

	@FindBy(xpath="//div[@class='form-group']/input")
	private List<WebElement> lbl_Placeholder_TextFeilds;

	@FindBy(xpath="//div[@class='form-group']/ejs-dropdownlist/span/input")
	private List<WebElement> lbl_Placeholder_DropdownlistFeilds;

	@FindBy(xpath="//div[@class='form-group']/ejs-maskedtextbox")
	private List<WebElement> lbl_Placeholder_MaskedtextboxFeilds;

	@FindBy(xpath="//div[@class='form-group']/ejs-multiselect")
	private List<WebElement> lbl_Placeholder_MultiselectFeilds;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs; 

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody//tr[1]//td[1]//div")
	private WebElement lbl_EmployeeName; 

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody/tr/td/div")
	private List<WebElement> tbl_AllEmployee; 

	@FindBy(xpath = "//div[contains(@class,'administrativeBtnArea')]/div/a")//i[@class='fa fa-plus-circle fa-blue mr-5']
	private WebElement btn_SupervisorIcon; 
	
	@FindBy(linkText = "System Configuration")
	private WebElement lnk_SystemConfiguration; 

	@FindBy(xpath = "(//ejs-checkbox/label/span)[1]")
	private WebElement chk_DefaultCheck;

	@FindBy(xpath = "//i[@class='fa fa-plus-circle fa-blue mr-3']")
	private WebElement icon_AddAdmin;

	@FindBy(xpath = "(//ejs-checkbox/label/span)[2]")
	private WebElement chk_DefaultCheckForNewAdmin;

	@FindBy(xpath = "//ejs-switch")
	private WebElement icon_ToggleSwitch;

	HomePage home =new HomePage();
	public AddNewUserPage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyLabelNames(DataTable label) {
		try {
			ArrayList<String> expFilterNames = new ArrayList<>(label.asList());
			report.reportInfo("Expected Label Names Users panel: "+expFilterNames);
			webActions.refreshPage();
			webActions.waitUntilisDisplayed(lnk_UserAccounts, "User Account Link");
			ArrayList<String> actFilterNames = new ArrayList<String>();
			actFilterNames.add(webActions.getText(lbl_UsersPanel, "User Panel"));
			actFilterNames.add(webActions.getText(lnk_UserAccounts, "User Account Link"));
			actFilterNames.add(webActions.getText(msg_UserPanel, "Text in Users Panel"));
			actFilterNames.add(webActions.getText(lbl_SystemConfiguration, "Breadcrumb"));
			report.reportInfo("Displayed Lable Names in Users panel: "+actFilterNames);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actFilterNames, expFilterNames);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Label Names in Users panel successfully");
			}
			else{
				throw new Exception("Fail to verify Label Names in Users panel and unmatched label Names are: "+unmatchedLabelNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyExpandCollapseUsersPanel() {
		try {
			StringBuffer unmatch=new StringBuffer();
			webActions.waitUntilisDisplayed(lnk_UserAccounts, "User Account Link");
			webActions.click(lbl_UsersPanel, "Users Panel");
			webActions.waitForLoad();
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(panel_Users, "Collapse Users Panel");
			String actCollapseStatus=webActions.getAttributeValue(panel_Users, "aria-expanded", "Users Panel");
			if("false".contentEquals(actCollapseStatus)){
				report.reportPass("Successfully Collapsed the of Users panel");
			}else{
				unmatch.append("Users panel is not Collapsed");
				report.reportFail("Users panel is not Collapsed");
			}

			webActions.click(lbl_UsersPanel, "Users Panel");
			webActions.waitForLoad();
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(panel_Users, "Expand Users Panel");
			String actExpandStatus=webActions.getAttributeValue(panel_Users, "aria-expanded", "Users Panel");
			if("true".contentEquals(actExpandStatus)){
				report.reportPass("Successfully Expanded the of Users panel");
			}else{
				unmatch.append("Users panel is not Expanded");
				report.reportFail("Users panel is not Expanded");
			}

			if(unmatch.length()==0){
				report.reportPass("Successfully verified the Expanded and Collapse of Users panel");
			}else{
				throw new Exception("Fail to verify the Expanded and Collapse of Users panel: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void navigatetoAddNewUserPage(){
		try {
			webActions.waitAndClick(lnk_UserAccounts, "User Accounts Link");
			webActions.waitAndClick(btn_AddNewUser, "Add New User");
			waitforSubmitButton();
			webActions.waitForPageLoaded();
		} catch (Exception e) {
		}
	}

	public void verifyBreadcrumbinAddNewUserPage(DataTable breadcrumb ){
		try {
			ArrayList<String> expectdBreadcrumb = new ArrayList<>(breadcrumb.asList());
			webActions.refreshPage();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_UserAccounts, "User Accounts Link");
			webActions.waitAndClick(btn_AddNewUser, "Add New User");
			ArrayList<String> actualBreadcrumb=webActions.getDatafromWebTable(lbl_Breadcrumb);
			report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumb);
			report.reportInfo("Expected Breadcrumb Titles "+expectdBreadcrumb);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumb, expectdBreadcrumb);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Breadcrumb Titles in Add New User page");
			}else{
				throw new Exception("Fail to verify the Breadcrumb Titles in Add New User page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyFieldNamesandButtonNames(DataTable fieldNames ){
		try {
			ArrayList<String> expectdFieldNames = new ArrayList<>(fieldNames.asList());
			webActions.waitAndClick(lnk_UserAccounts, "User Accounts Link");
			webActions.waitAndClick(btn_AddNewUser, "Add New User");
			waitforSubmitButton();
			ArrayList<String> actualFieldNames=webActions.getDatafromWebTable(lbl_AllFeilds);
			actualFieldNames.add(webActions.getText(btn_Clear, "Clear"));
			actualFieldNames.add(webActions.getText(btn_Cancel, "Cancel"));
			actualFieldNames.add(webActions.getText(btn_Submit, "Submit"));
			report.reportInfo("Actual Field Names: "+actualFieldNames);
			report.reportInfo("Expected Field Names: "+expectdFieldNames);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualFieldNames, expectdFieldNames);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Field names and Button names in Add New User page");
			}else{
				throw new Exception("Fail to verify the Field names and Button names in Add New User page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyMandatoryFields(DataTable mandatoryFields ){
		try {
			ArrayList<String> expectdmandatoryFields = new ArrayList<>(mandatoryFields.asList());
			webActions.waitAndClick(lnk_UserAccounts, "User Accounts Link");
			webActions.waitAndClick(btn_AddNewUser, "Add New User");
			waitforSubmitButton();
			ArrayList<String> actualmandatoryFields=webActions.getDatafromWebTable(lbl_MandatoryFeilds);
			report.reportInfo("Actual Mandatory Fields: "+actualmandatoryFields);
			report.reportInfo("Expected Mandatory Fields: "+expectdmandatoryFields);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualmandatoryFields, expectdmandatoryFields);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Mandatory Fields in Add New User page");
			}else{
				throw new Exception("Fail to verify the Mandatory Fields in Add New User page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifytheMandatoryFieldValidationMessage(DataTable validationMessages){
		try {
			ArrayList<String> expectdValidationMessages = new ArrayList<>(validationMessages.asList());
			webActions.waitAndClick(lnk_UserAccounts, "User Accounts Link");
			webActions.waitAndClick(btn_AddNewUser, "Add New User");
			waitforSubmitButton();
			webActions.click(txt_OperatorID, "Operator ID");
			webActions.click(txt_LastName, "Last Name");
			webActions.click(txt_FirstName, "First Name");
			webActions.click(txt_Email, "Email");
			webActions.click(txt_ContactsPhone, "Contacts Phone");
			webActions.waitForLoad();
			ArrayList<String> actualValidationMessages=webActions.getDatafromWebTable(lbl_MandatoryFieldValidationMessage);
			report.reportInfo("Actual Validation Messages: "+actualValidationMessages);
			report.reportInfo("Expected Validation Messages: "+expectdValidationMessages);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualValidationMessages, expectdValidationMessages);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Mandatory Field Validation Messages in Add New User page");
			}else{
				throw new Exception("Fail to verify the Mandatory Field Validation Messages in Add New User page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyValidationMessageifEnterLessThanMinimumCharacters(String testData,DataTable validationMessages){
		try {
			ArrayList<String> expectdValidationMessages = new ArrayList<>(validationMessages.asList());
			webActions.waitAndClick(lnk_UserAccounts, "User Accounts Link");
			webActions.waitAndClick(btn_AddNewUser, "Add New User");
			waitforSubmitButton();
			webActions.sendKeys(txt_LastName, testData, "Last Name");
			webActions.sendKeys(txt_FirstName, testData, "First Name");
			webActions.sendKeys(txt_Email, testData, "Email");
			webActions.click(txt_ContactsPhone, "Contacts Phone");
			webActions.waitForLoad();
			ArrayList<String> actualValidationMessages=webActions.getDatafromWebTable(lbl_MandatoryFieldValidationMessage);
			report.reportInfo("Actual Validation Messages: "+actualValidationMessages);
			report.reportInfo("Expected Validation Messages: "+expectdValidationMessages);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualValidationMessages, expectdValidationMessages);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Validation Messages if enter less than minimum characters in First Name, Last Name, and Email fields in the Add New User page");
			}else{
				throw new Exception("Fail to verify the Validation Messages if enter less than minimum characters in First Name, Last Name, and Email fields in the Add New User page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyValidationMessageifEnterGreaterThanMaximumLengthCharacters(String testData,DataTable validationMessages){
		try {
			ArrayList<String> expectdValidationMessages = new ArrayList<>(validationMessages.asList());
			webActions.waitAndClick(lnk_UserAccounts, "User Accounts Link");
			webActions.waitAndClick(btn_AddNewUser, "Add New User");
			waitforSubmitButton();
			webActions.sendKeys(txt_LastName, testData, "Last Name");
			webActions.sendKeys(txt_FirstName, testData, "First Name");
			webActions.sendKeys(txt_Email, testData, "Email");
			webActions.click(txt_ContactsPhone, "Contacts Phone");
			webActions.waitForLoad();
			ArrayList<String> actualValidationMessages = new  ArrayList<String>();
			List<WebElement> listMessage=lbl_MaximumLengthValidationMessage;
			for (WebElement element : listMessage) {
				String text=element.getText();
				actualValidationMessages.add(text.replace("\n", " "));
			}
			report.reportInfo("Actual Validation Messages: "+actualValidationMessages);
			report.reportInfo("Expected Validation Message: "+expectdValidationMessages);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualValidationMessages, expectdValidationMessages);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Validation Messages if enter greater than maximum length characters in First Name, Last Name, and Email fields in the Add New User page");
			}else{
				throw new Exception("Fail to verify the Validation Messages if enter greater than maximum length characters in First Name, Last Name, and Email fields in the Add New User page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyValidationMessageifNotEnteringAlphaCharacters (String validationMessage,String testData){
		try {
			navigatetoAddNewUserPage();
			waitforSubmitButton();
			webActions.sendKeys(txt_LastName, testData, "Last Name");
			webActions.sendKeys(txt_FirstName, testData, "First Name");
			webActions.click(txt_EmployeeSince, "Employee Since");

			ArrayList<String> actualValidationMessages=webActions.getDatafromWebTable(lbl_MandatoryFieldValidationMessage);
			report.reportInfo("Actual Validation Messages: "+actualValidationMessages);
			report.reportInfo("Expected Validation Message: "+validationMessage);

			ArrayList<String> unmatch=webActions.isFullArrayMatchWithData(actualValidationMessages, validationMessage);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the validation Messages if user is not entering Alpha Characters in First Name and Last Name fields in the Add New User page");
			}else{
				throw new Exception("Fail to verify the Validation Messages if user is not entering Alpha Characters in First Name and Last Name fields in the Add New User page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyValidationMessageifEnterLessThanMinimumNumericValues(String testData,DataTable validationMessages){
		try {
			ArrayList<String> expectdValidationMessages = new ArrayList<>(validationMessages.asList());
			navigatetoAddNewUserPage();
			waitforSubmitButton();
			webActions.sendKeys(txt_LastName, testData, "Last Name");
			webActions.sendKeys(txt_FirstName, testData, "First Name");
			webActions.click(txt_EmployeeSince, "Employee Since");
			webActions.waitForLoad();
			ArrayList<String> actualValidationMessages=webActions.getDatafromWebTable(lbl_MandatoryFieldValidationMessage);
			report.reportInfo("Actual Validation Messages: "+actualValidationMessages);
			report.reportInfo("Expected Validation Messages: "+expectdValidationMessages);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualValidationMessages, expectdValidationMessages);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Validation Messages if enter less than minimum length numeric values in First Name and Last Name fields in the Add New User page");
			}else{
				throw new Exception("Fail to verify the Validation Messages if enter less than minimum length numeric values in First Name and Last Name fields in the Add New User page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyValidationMessageifEnterInvalidPhoneNumber(String validationMessage,String phoneNumber){
		try {
			webActions.waitAndClick(lnk_UserAccounts, "User Accounts Link");
			webActions.waitAndClick(btn_AddNewUser, "Add New User");
			waitforSubmitButton();
			webActions.waitForLoad();
			webActions.click(txt_ContactsPhone, "Contacts Phone");
			webActions.waitForLoad();
			webActions.enterValuesfromKeyBoard(txt_ContactsPhone, phoneNumber,"Contacts Phone");
			webActions.waitForLoad();
			pressTab();
			String actualValidationMessages=webActions.waitAndGetText(lbl_PhoneValidationMessage, "Phone Number");
			report.reportInfo("Actual Validation Messages: "+actualValidationMessages);
			report.reportInfo("Expected Validation Message: "+validationMessage);
			if(validationMessage.contentEquals(actualValidationMessages)){
				report.reportPass("Successfully verified the Validation Messages if enter  invalid phone number in the Add New User page");
			}else{
				throw new Exception("Fail to verify the Validation Messages if enter invalid phone number in the Add New User page");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifythePlaceholdersforallFields(DataTable placeholders){
		try {
			ArrayList<String> expectdPlaceholders = new ArrayList<>(placeholders.asList());
			navigatetoAddNewUserPage();
			webActions.click(btn_Clear, "Clear");
			webActions.click(btn_Clear, "Clear");
			ArrayList<String> actualPlaceholders =new ArrayList<String>();
			actualPlaceholders.addAll(webActions.getListofAttributeValuesfromWebPage(lbl_Placeholder_TextFeilds, "placeholder"));
			actualPlaceholders.addAll(webActions.getListofAttributeValuesfromWebPage(lbl_Placeholder_DropdownlistFeilds, "placeholder"));
			actualPlaceholders.addAll(webActions.getListofAttributeValuesfromWebPage(lbl_Placeholder_MaskedtextboxFeilds, "placeholder"));
			actualPlaceholders.addAll(webActions.getListofAttributeValuesfromWebPage(lbl_Placeholder_MultiselectFeilds, "filterbarplaceholder"));
			report.reportInfo("Actual Placeholders: "+actualPlaceholders);
			report.reportInfo("Expected Placeholders: "+expectdPlaceholders);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualPlaceholders, expectdPlaceholders);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Placeholders for all fields in the Add New User page");
			}else{
				throw new Exception("Fail to verify the Placeholders for all fields in the Add New User page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyCancelButtonFunctionality(){
		try {
			navigatetoAddNewUserPage();
			webActions.waitAndClick(btn_Cancel, "Cancel");
			String addNewUserButtonName=webActions.waitAndGetText(btn_AddNewUser, "Add New User");
			if("Add New User".contentEquals(addNewUserButtonName)){
				report.reportInfo("User is navigated to User list page after click on Cancel button and verified Add New User Button: "+addNewUserButtonName);
				report.reportPass("Successfully verified the Cancel button functionality in the Add New User page");	
			}else{
				throw new Exception("Fail to verify the Cancel button functionality, Users is not navigated to User List page");
			}
		} catch (Exception e) {	
			report.reportFail(e.getMessage());
		}
	}

	public String createNewUser(DataTable testData,String messageTitle,String messageContent){
		String expEmployeName=null;
		try {
			StringBuilder unmatch=new StringBuilder();
			navigatetoAddNewUserPage();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
			webActions.waitUntilisDisplayed(btn_SupervisorIcon, "Supervisor");
			webActions.sendKeys(txt_OperatorID, getUniqueNumber(), "Operator ID");
			String lastName=getRandomString(8);
			webActions.sendKeys(txt_LastName, lastName, "Last Name");
			String firstName=getRandomString(6);
			webActions.sendKeys(txt_FirstName, firstName, "First Name");
			webActions.sendKeys(txt_EmployeeSince, getDatafromMap(testData,"Employee Since"), "Employee Since");
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_EmployeeroleId, getDatafromMap(testData,"Employee Role"), "Employee Role");
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
			webActions.click(dd_StatusId, "Status");
			String status=getDatafromMap(testData,"Status");
			String statusxptah="//li[";
			String statusxptah1="]/span/span";
			if("Active".contentEquals(status)){
				driver.findElement(By.xpath(statusxptah+"1"+statusxptah1)).click();
			}else{
				driver.findElement(By.xpath(statusxptah+"2"+statusxptah1)).click();
			}

			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
			String emailID=getRandomString(5)+getDatafromMap(testData,"Email");
			webActions.sendKeys(txt_Email, emailID, "Email");

			webActions.click(txt_ContactsPhone, "ContactsPhone");
			webActions.enterValuesfromKeyBoard(txt_ContactsPhone, getDatafromMap(testData,"Phone Number"), "Phone Number");

			String role=getDatafromMap(testData,"Role");
			selectDropdown(dd_RoleId, role, "Role");

			String facility=getDatafromMap(testData,"Facility");
			selectDropdown(dd_FacilityId, facility, "Facility");

			String lobby=getDatafromMap(testData,"Lobby");
			selectDropdown(dd_Lobby,lobby,"Lobby");

			String departmentId=getDatafromMap(testData,"Administrative Department");
			selectDropdown(dd_departmentId, departmentId, "Administrative Department");

			String supervisor=getDatafromMap(testData,"Supervisor");
			selectDropdown(dd_Supervisor,supervisor,"Supervisor");

			webActions.click(btn_Submit, "Submit");
			String msg="";
			String actTitle="";
			String actContent="";
			try {
				webActions.waitForVisibility(txt_ToastMsgs, "Messages");
				msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
				String[] titleContent=msg.split("\\n");
				actTitle = titleContent[0];
				actContent = titleContent[1];
				report.reportInfo("Actual alert message after user is created: "+msg);
				if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent))){
					report.reportPass("Successfully displayed the alert message after user is created: "+msg);
				}
				else{
					unmatch.append("Alert message is not displayed/matched after user is created: "+msg);
				}
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			try {
				webActions.waitForVisibilityOfAllElements(tbl_AllEmployee, "Employee Name Grid");
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(txt_SearchEmployee, "Search Employee");
			webActions.click(txt_SearchEmployee, "Search Employee");
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
			webActions.enterValuesfromKeyBoard(txt_SearchEmployee, lastName,"Search Employee");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibility(lbl_EmployeeName, "Employee Name");
			String actEmployeName=webActions.waitAndGetText(lbl_EmployeeName, "Employee Name");
			expEmployeName=lastName+" "+firstName;
			if(expEmployeName.contentEquals(actEmployeName)){
				webActions.notepadWrite("hellow", lastName);
				report.reportPass("Newly created user is displayed successfully in the user list page: "+actEmployeName);
				
			}else{
				unmatch.append("Incorrect username is displayed in the in the user list page after new user is created:"+actEmployeName);
			}
			if(unmatch.length()==0){
				report.reportPass("Successfully verified the new user creation functionality");
			}else{
				throw new Exception("Fail to verify the new user creation functionality: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
		return expEmployeName;
	}

	public void selectDropdown(WebElement element,String valuetoSelect,String elementName) throws Exception{
		try {
			if (!valuetoSelect.isEmpty()) {
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.click(element, elementName);
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				driver.findElement(By.xpath("//li[contains(.,'" + valuetoSelect + "')]")).click();
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public void createDuplicateUser(DataTable testData,String messageTitle,String messageContent){
		try {
			navigatetoAddNewUserPage();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_OperatorID, getUniqueNumber(), "Operator ID");
			webActions.sendKeys(txt_LastName, getDatafromMap(testData,"Last Name"), "Last Name");
			webActions.sendKeys(txt_FirstName, getDatafromMap(testData,"First Name"), "First Name");
			webActions.sendKeys(txt_EmployeeSince, getDatafromMap(testData,"Employee Since"), "Employee Since");
			webActions.sendKeys(dd_EmployeeroleId, getDatafromMap(testData,"Employee Role"), "Employee Role");
			webActions.sendKeysByJS(dd_StatusId, getDatafromMap(testData,"Status"), "Status");
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_Email, getDatafromMap(testData,"Email"), "Email");
			webActions.click(txt_ContactsPhone, "ContactsPhone");
			webActions.enterValuesfromKeyBoard(txt_ContactsPhone, getDatafromMap(testData,"Phone Number"), "Phone Number");
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_RoleId, getDatafromMap(testData,"Role"), "Role Arrow");
			webActions.waitForJSandJQueryToLoad();
			webActions.click(dd_RoleId_Arrow, "Role");
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(dd_FacilityId, "Facility");
			webActions.sendKeys(dd_FacilityId, getDatafromMap(testData,"Facility"), "Facility");
			webActions.waitForJSandJQueryToLoad();
			webActions.click(dd_FacilityIdArrow, "FacilityId Arrow");
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForClickAbility(dd_departmentId, "Administrative Department");
			webActions.waitForPageLoaded();
			webActions.sendKeys(dd_departmentId, getDatafromMap(testData,"Administrative Department"), "Administrative Department");
			webActions.click(dd_departmentIdArrow, "Administrative Department Arrow");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(btn_Submit, "Submit");
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle=titleContent[0];
			String actContent=titleContent[1];
			report.reportInfo("Actual alert message after user is created: "+msg);
			if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent))){
				report.reportPass("Alert message is displayed successfully when try to create duplicate user:"+msg);
			}
			else{
				throw new Exception("Failed to verify the Alert message when try to create duplicate user: "+msg);
			}
			report.reportPass("Successfully verified the validation error message when try to create duplicate user");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}

	public void waitforSubmitButton(){
		try {
			webActions.waitUntilisDisplayed(btn_Submit, "Submit Button");
		} catch (Exception e) {
		}
	}

	public void pressTab(){
		try{
			Actions act = new Actions(driver);
			act.sendKeys(Keys.TAB).build().perform();
		}catch(Exception e){
		}
	}

	public String getRandomString(int length){
		String alphabet = "abcdefghijklmnopqrstuvwxyz";
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		for(int i = 0; i < length; i++) {
			int index = random.nextInt(alphabet.length());
			char randomChar = alphabet.charAt(index);
			sb.append(randomChar);
		}
		String randomString = sb.toString();
		return randomString;
	}
	
	public String getUniqueNumber() {
		String uniqueNumber = "";
		try {
			Date dNow = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("DDYYHHssMs");
			String s = ft.format(dNow);
			uniqueNumber = s.substring(0, Math.min(s.length(), 10));

		} catch (Exception e) {

		}
		return uniqueNumber;
	}
	
	public void verifyDefaultRadio(){
		try {
			navigatetoAddNewUserPage();
			String displedDefaultChk=webActions.getAttributeValue(chk_DefaultCheck, "class", "DefaultCheckbox");
			if("e-icons e-frame e-check".contentEquals(displedDefaultChk)){			
				report.reportPass("Verified default display of radio button for first Admin Department");			
			}
			else{
				report.reportFail("Fail to verify default display of radio button for first Admin Department and Actual displayed is: "+displedDefaultChk);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDefaultRadioForSecondDepartment(){
		try {
			navigatetoAddNewUserPage();
			webActions.click(icon_AddAdmin, "AddAdminDepartment");
			webActions.waitForPageLoaded();
			String displedDefaultChk=webActions.getAttributeValue(chk_DefaultCheckForNewAdmin, "class", "DefaultCheckbox");
			if("e-icons e-frame".contentEquals(displedDefaultChk)){			
				report.reportPass("Verified default display of radio button for second Admin Department");			
			}
			else{
				report.reportFail("Fail to verify default display of radio button for second Admin Department and Actual displayed is: "+displedDefaultChk);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyToggleSwitch(){
		try {
			navigatetoAddNewUserPage();
			webActions.assertDisplayed(icon_ToggleSwitch, "ToggleSwitch");
			report.reportPass("Toggle switch is displayed");
		} catch (Exception e) {
			report.reportFail("Toggle switch is not displayed"+e.getMessage());
		}
	}

	public void verifyToggleSwitchMode(){
		try {
			navigatetoAddNewUserPage();
			String flag1=webActions.getAttributeValue(icon_ToggleSwitch, "aria-checked", "ToggleSwitch");		
			boolean flag=Boolean.parseBoolean(flag1);

			if(flag){
				report.reportFail("Fail to verify default mode for toggle switch "+flag);
			}
			else{
				report.reportPass("Verified default mode for toggle switch successfully "+flag);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyToggleSwitchModes(){
		try {
			navigatetoAddNewUserPage();
			webActions.click(icon_ToggleSwitch, "ToggleSwitch");
			webActions.waitForPageLoaded();
			String flag1=webActions.getAttributeValue(icon_ToggleSwitch, "aria-checked", "ToggleSwitch");		
			boolean flag2=Boolean.parseBoolean(flag1);
			if(flag2){
				report.reportPass("Verified toggle switch mode successfully "+flag2);
			}
			else{
				report.reportFail("Fail to verify toggle switch mode "+flag2,true);
			}
			webActions.click(icon_ToggleSwitch, "ToggleSwitch");
			webActions.waitForPageLoaded();
			String flag3=webActions.getAttributeValue(icon_ToggleSwitch, "aria-checked", "ToggleSwitch");		
			boolean flag4=Boolean.parseBoolean(flag3);
			if(flag4){
				report.reportFail("Fail to verify toggle switch mode "+flag4);
			}
			else{
				report.reportPass("Verified toggle switch mode successfully "+flag4);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(lnk_UserAccounts);
	}

}