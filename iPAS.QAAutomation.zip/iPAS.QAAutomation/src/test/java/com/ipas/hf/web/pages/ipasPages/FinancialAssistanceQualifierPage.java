package com.ipas.hf.web.pages.ipasPages;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.server.handler.GetAlertText;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class FinancialAssistanceQualifierPage extends BasePage {

	private JSONObject jsonObject;
	private static final String FAQ = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\FinancialAssistanceQualifier.json";
	private StepLogging log = StepLogging.getLoggingObject();

	@FindBy(xpath="//a[contains(text(),'Financial Assistance Qualifier')]")
	private WebElement lnk_FAQ;
	
	@FindBy(xpath="//span[contains(text(),'Not Evaluated')]")
	private WebElement lbl_StatusShortPanel;
	
	@FindBy(xpath="//div[@class='case-info']//span")
	private WebElement lbl_Status;

	@FindBy(xpath="//ipas-app-faq-short-panel/div/ejs-accordion/div/div[1]/div[2]")
	private WebElement icon_Expand;

	@FindBy(xpath="//ipas-app-faq-short-panel/div/ejs-accordion/div")
	private WebElement atr_ExpandStatus;

	@FindBy(xpath="//a[(text()='Create New Case')]")
	private WebElement btn_CreateNewCase;

	@FindBy(xpath="//ipas-app-faq-short-panel//financial-clearance-status/img")
	private WebElement atr_FCStatusShortPanel;

	@FindBy(xpath="(//financial-clearance-status)[2]/img")
	private WebElement atr_FCStatusFullPage;

	@FindBy(xpath="//ipas-faq-details//h2[1]")
	private WebElement lbl_HeaderMessage;

	@FindBy(xpath="(//ipas-faq-details//p)[1]")
	private WebElement lbl_NotRunDetails;

	@FindBy(xpath="//ejs-dropdownlist/span/input")
	private WebElement dd_CaseOwner;

	@FindBy(xpath="//p[contains(text(),'Go to Eligibility')]")
	private WebElement btn_GoToEligibility;

	@FindBy(xpath="//p[contains(text(),'Go to Estimator')]")
	private WebElement btn_GoToEstimator;

	@FindBy(xpath="//img[@src='assets/images/faq/p2p.png']") //p[(text()='Go to P2P')]
	private WebElement btn_GoToP2P;

	@FindBy(xpath="//img[@src='assets/images/note.png']")
	private WebElement btn_NoteIcon;

	@FindBy(xpath="//ejs-textbox//textarea")
	private WebElement txt_Note;

	@FindBy(xpath="//button[contains(text(),'Add Note')]")
	private WebElement btn_AddNote;

	@FindBy(xpath="(//table/tbody/tr)[2]/td")
	private List<WebElement> tr_NoteData;	

	@FindBy(xpath="//button[@title='Close']/span")
	private WebElement btn_CloseX;	

	@FindBy(xpath="//ejs-numerictextbox[@formcontrolname='estimateAmount']//input[1]")
	private WebElement txt_EstimateAmount;

	@FindBy(xpath="//ejs-numerictextbox[@formcontrolname='accountScore']//input[1]")
	private WebElement txt_AccountScore;

	@FindBy(xpath="//ejs-numerictextbox[@formcontrolname='percentFPL']//input[1]")
	private WebElement txt_PercentFPL;

	@FindBy(xpath="//a[contains(text(),'Save Changes')]")
	private WebElement btn_SaveChanges;

	@FindBy(xpath="//p[@class='title d-flex']")
	private WebElement lbl_Eligibility;

	@FindBy(xpath="//div[@class='viewText']")
	private WebElement lbl_EstimateId;

	@FindBy(xpath="//a[contains(text(),'Run Credit Check')]")
	private WebElement btn_RunCreditCheck;

	@FindBy(xpath="//button[contains(text(),'Send Request')]")
	private WebElement btn_SendRequest;

	@FindBy(xpath="//span[contains(text(),'Account Score')]/../span[2]")
	private WebElement lbl_AccountScore;

	@FindBy(xpath="//span[contains(text(),'Percent Federal Poverty Guideline')]/../span[2]")
	private WebElement lbl_FPL;

	@FindBy(xpath="//ejs-dropdownlist[@id='ddlelement']/span/input")
	private WebElement dd_Status;

	@FindBy(xpath="//h6[contains(text(),'Case ')]")
	private WebElement lbl_CaseNo;

	@FindBy(xpath="//p[contains(@class,'status-info')]")
	private WebElement lbl_RunInfo;

	@FindBy(xpath="(//div[@class='description'])[1]//p")
	private List<WebElement> lbl_ShortPanelData;

	@FindBy(xpath="//div[(text()='Programs')]")
	private WebElement tab_Programs;

	@FindBy(xpath="//a[@hideauthorize='AddEditFAQProg']")
	private WebElement lnk_AddPrograms;

	@FindBy(xpath="(//table[@class='e-table']/tbody)[2]/tr[1]/td[2]")
	private WebElement tr_FirstRow;

	@FindBy(xpath="//ejs-textbox[@placeholder='Type Program Name']")
	private WebElement txt_TypeProgramName;

	//td[(text()='Medicaid')]
	@FindBy(xpath="//a[normalize-space()='Save']")
	private WebElement btn_Save;

	@FindBy(xpath="//ejs-dropdownlist[@formcontrolname='programStatusId']/span/input")
	private WebElement dd_ProgramStatus;

	@FindBy(xpath="//ejs-dropdownlist[@formcontrolname='discountTypeId']/span/input")
	private WebElement dd_Discount;

	@FindBy(xpath="//ejs-numerictextbox[@formcontrolname='totalCharges']/span/input[1]")
	private WebElement txt_TotalCharges;

	@FindBy(xpath="(//div[@class='form-body']//p)[5]")
	private WebElement lbl_PatientResponsibility;		

	@FindBy(xpath="(//a[@hideauthorize='AddEditFAQMmbVst'])[1]")
	private WebElement btn_PayemntFacilitator;

	@FindBy(xpath="//div[contains(@class,'beforeDiscountArea')]/div[2]")
	private WebElement lbl_EstimateBeforeDiscount;

	@FindBy(xpath="//a[contains(text(),'Worklists')]")
	private WebElement lnk_WorkList;

	@FindBy(xpath="//tbody/tr/td/div/div")
	private List<WebElement> tr_WorkList;



	private RestActions rest = new RestActions();
	PaymentFacilitatorPage payment=new PaymentFacilitatorPage();
	Login login=new Login();
	PayerContractsPage pcp=new PayerContractsPage();
	EstimatorSelfPayPage self=new EstimatorSelfPayPage();
	AAARuleAlertsPage aaa=new AAARuleAlertsPage();
	WorkListPage work=new WorkListPage();

	public FinancialAssistanceQualifierPage() {
		PageFactory.initElements(driver, this);
	}

	public void navigateAllDataPage(){
		try {
			String accountNumber=getDataFromJSONFile("AccountNumber");
			payment.searchAccountNuberinAccountSearchPage(accountNumber);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			try {
				webActions.waitForVisibility(lnk_FAQ, "FAQ", 15);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
			}
		} catch (Exception e) {

		}
	}

	public void navigateFAQFullpage(){
		navigateAllDataPage();
		webActions.click(lnk_FAQ, "FAQ");
		try {
			webActions.waitForVisibility(btn_CreateNewCase, "CreateNewCase", 20);
			webActions.waitForPageLoaded();
		} catch (Exception e) {
		}
	}

	public void verifyDefaultDatainFAQShortPanel(DataTable testData){
		try {
			navigateAllDataPage();
			StringBuilder unmatch=new StringBuilder();
			webActions.waitForPageLoaded();
			String actStatus=webActions.waitAndGetText(lbl_StatusShortPanel, "Status");
			if(webActions.getDatafromMap(testData, "Status").contentEquals(actStatus)){
				report.reportPass("Successfully verified the default status in short panel: "+actStatus);
			}else{
				report.reportFail("Fail to verify the default status in short panel: "+actStatus,true);
				unmatch.append("Fail to verify the default status in short panel");
			}
			String actFCStatus=webActions.getAttributeValue(atr_FCStatusShortPanel, "src", "FCStatus");
			if(actFCStatus.contains(webActions.getDatafromMap(testData, "FCStatus"))){
				report.reportPass("Successfully verified the default financial clearance in short panel");
			}else{
				report.reportFail("Fail to verify the default financial clearance in short panel",true);
				unmatch.append("Fail to verify the default financial clearance in short panel");
			}
			webActions.click(icon_Expand, "Expand Icon");
			webActions.waitForPageLoaded();
			webActions.waitForLoad();
			String actCollapseStatus=webActions.getAttributeValue(atr_ExpandStatus, "aria-expanded", "Panel Expand");
			if(actCollapseStatus.contains("false")){
				report.reportPass("Successfully verified the collapse functionality");
			}else{
				report.reportFail("Fail to verify the collapse functionality",true);
				unmatch.append("Fail to verify the collapse functionality");
			}
			webActions.waitForPageLoaded();
			webActions.click(icon_Expand, "Expand Icon");
			webActions.waitForPageLoaded();
			webActions.waitForLoad();
			actCollapseStatus=webActions.getAttributeValue(atr_ExpandStatus, "aria-expanded", "Panel Expand");
			if(actCollapseStatus.contains("true")){
				report.reportPass("Successfully verified the expand functionality");
			}else{
				report.reportFail("Fail to verify the expand functionality",true);
				unmatch.append("Fail to verify the expand functionality");
			}
			webActions.waitForPageLoaded();
			webActions.waitForLoad();
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyDefaultDatainFAQFullPage (DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.click(lnk_FAQ, "FAQ");
			try {
				webActions.waitForVisibility(btn_CreateNewCase, "CreateNewCase", 20);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
			}

			String actStatus=webActions.waitAndGetText(lbl_Status, "Status");
			if(webActions.getDatafromMap(testData, "Status").contentEquals(actStatus)){
				report.reportPass("Successfully verified the default status in full page: "+actStatus);
			}else{
				report.reportFail("Fail to verify the default status in full page: "+actStatus,true);
				unmatch.append("Fail to verify the default status in full page");
			}

			String actFCStatus=webActions.getAttributeValue(atr_FCStatusFullPage, "src", "FCStatus");
			if(actFCStatus.contains(webActions.getDatafromMap(testData, "FCStatus"))){
				report.reportPass("Successfully verified the default financial clearance in full page: "+actFCStatus);
			}else{
				report.reportFail("Fail to verify the default financial clearance in full page: "+actFCStatus,true);
				unmatch.append("Fail to verify the default financial clearance in full page");
			}

			String actHeaderMessage=webActions.waitAndGetText(lbl_HeaderMessage, "HeaderMessage");
			if(webActions.getDatafromMap(testData, "HeaderMessage").contentEquals(actHeaderMessage)){
				report.reportPass("Successfully verified the header message: "+actHeaderMessage);
			}else{
				report.reportFail("Fail to verify the header message: "+actHeaderMessage,true);
				unmatch.append("Fail to verify the header message");
			}

			String actRunDetails=webActions.waitAndGetText(lbl_NotRunDetails, "RunDetails");
			if(webActions.getDatafromMap(testData, "RunDetails").contentEquals(actRunDetails)){
				report.reportPass("Successfully verified the Run Details: "+actRunDetails);
			}else{
				report.reportFail("Fail to verify the Run Details: "+actRunDetails,true);
				unmatch.append("Fail to verify the Run Details");
			}

			String actCaseOwner=webActions.getAttributeValue(dd_CaseOwner, "aria-label", "CaseOwner");
			if(webActions.getDatafromMap(testData, "CaseOwner").contains(actCaseOwner)){
				report.reportPass("Successfully verified the default dispaly of Case Owner: "+actCaseOwner);
			}else{
				report.reportFail("Fail to verify the default dispaly of Case Owner: "+actCaseOwner,true);
				unmatch.append("Fail to verify the default dispaly of Case Owner");
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void createNewCase (){
		webActions.click(btn_CreateNewCase, "CreateNewCase");
		String actAlert=pcp.getAlertMessage();
		if("Case created successfully.".contentEquals(actAlert)){
			report.reportPass("Successfully verified alert message after case is created: "+actAlert);
		}else{
			report.reportFail("Fail to verify the alert message after case is created: "+actAlert);
		}
	}

	public void navigationtoEligibilityFromEvaluationTab(DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			ArrayList<String> data=new ArrayList<String>(testData.asList());
			ArrayList<String> expectedBreadcrumbTitles=new ArrayList<String>();
			expectedBreadcrumbTitles.add(data.get(0));
			expectedBreadcrumbTitles.add(getDataFromJSONFile("AccountNumber"));
			expectedBreadcrumbTitles.add(data.get(1));
			expectedBreadcrumbTitles.add(data.get(2));
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_GoToEligibility, "Eligibility");
			String actEligibility=webActions.waitAndGetText(lbl_Eligibility, "Eligibility");
			if("Eligibility Verification".contains(actEligibility)){
				report.reportPass("Successfully verified the Eligibility page title: "+actEligibility);
			}else{
				report.reportFail("Fail to verify the Eligibility page title: "+actEligibility,true);
				unmatch.append("Fail to verify the Eligibility page title");
			}

			ArrayList<String> actualBreadcrumbTitles_Eligibility = webActions.getDatafromWebTable(payment.lbl_Breadcrum);
			ArrayList<String> unmatchBreadcrumb_Eligibility=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles_Eligibility, expectedBreadcrumbTitles);
			if(unmatchBreadcrumb_Eligibility.size()==0){
				report.reportPass("Successfully navigated to Eligibility from FAQ page: "+actualBreadcrumbTitles_Eligibility);
			}else{
				report.reportFail("Failed to navigate Eligibility from FAQ page: "+unmatchBreadcrumb_Eligibility,true);
				unmatch.append("Failed to navigate Eligibility from FAQ page");
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void navigateEstimate(){
		try {
			navigateAllDataPage();
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibility(self.lnk_Estimator, "Estimator", 15);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
			}
			webActions.click(self.lnk_Estimator, "Estimator");
			try {
				webActions.waitForVisibility(self.lnk_1stCPTCodeEdit, "CPT Code", 20);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
			}
		} catch (Exception e) {

		}
	}

	public void navigateFAQfromEstimateAndVerifyEstimatedAmount(DataTable testData){
		try {
			String accountNumber=getDataFromJSONFile("AccountNumber");
			ArrayList<String> data=new ArrayList<String>(testData.asList());
			ArrayList<String> expectedBreadcrumbTitles=new ArrayList<String>();
			expectedBreadcrumbTitles.add(data.get(0));
			expectedBreadcrumbTitles.add(accountNumber);
			expectedBreadcrumbTitles.add(data.get(1));
			expectedBreadcrumbTitles.add(data.get(2));

			ArrayList<String> expData=new ArrayList<String>();
			StringBuilder verify=new StringBuilder();
			String totalResponsibility=webActions.waitAndGetText(self.lbl_TotalResponsibility, "TotalResponsibility");
			totalResponsibility = totalResponsibility.replace("$", "").replace(",","");
			String id=webActions.waitAndGetText(self.lbl_EstimateID, "EstimateID");
			id=id.substring(0, id.length()-1).trim();
			expData.add(id);
			expData.add(totalResponsibility);


			driver.findElement(By.linkText(accountNumber)).click();
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibility(lnk_FAQ, "FAQ", 15);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
			}
			webActions.click(lnk_FAQ, "FAQ");
			try {
				webActions.waitForVisibility(btn_CreateNewCase, "CreateNewCase", 20);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
			}
			createNewCase();
			ArrayList<String>actData=new ArrayList<String>();
			String expEstimateId=webActions.waitAndGetText(lbl_EstimateId, "EstimateId").trim();
			actData.add(expEstimateId);
			String estimateAmount=webActions.getAttributeValue(txt_EstimateAmount, "aria-valuenow", "EstimateAmount");
			actData.add(estimateAmount);
			ArrayList<String>unMatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unMatch.size()!=0){
				report.reportPass("Successfully verified the Estimate Id and Estimated Amount in Evaluation tab: "+actData);
			}else{
				report.reportFail("Fail to verify the Estimate Id and Estimated Amount in Evaluation tab: "+actData,true);
				verify.append("Fail to verify the Estimate Id and Estimated Amount in Evaluation tab");
			}

			double amount=Double.parseDouble(estimateAmount);
			amount=amount+1000;
			//estimateAmount=String.valueOf(amount); 
			estimateAmount=Double.toString(amount);

			webActions.sendKeys(txt_EstimateAmount, estimateAmount, "EstimateAmount");
			webActions.click(btn_SaveChanges, "Save Changes");
			String actMessage=pcp.getAlertMessage();
			if(actMessage.contains("Data saved successfully.")){
				report.reportPass("Successfully verified the alert message after update the EstimateAmount: "+actMessage);
			}
			else{
				report.reportFail("Fail to verify the alert message after update the EstimateAmount: "+actMessage,true);
				verify.append("Fail to verify the alert message after update the EstimateAmount");
			}

			webActions.click(btn_GoToEstimator, "GoToEstimator");

			ArrayList<String> actualBreadcrumbTitles_Estimator = webActions.getDatafromWebTable(payment.lbl_Breadcrum);
			ArrayList<String> unmatchBreadcrumb_Estimator=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles_Estimator, expectedBreadcrumbTitles);
			if(unmatchBreadcrumb_Estimator.size()==0){
				report.reportPass("Successfully verified Breadcrumb when user navigated to Estimator from FAQ page: "+actualBreadcrumbTitles_Estimator);
			}else{
				report.reportFail("Fail to verify Breadcrumb when user navigated to Estimator from FAQ page: "+unmatchBreadcrumb_Estimator,true);
				verify.append("Fail to verify Breadcrumb when user navigated to Estimator from FAQ page");
			}

			String actEstimateId=webActions.waitAndGetText(self.lbl_EstimateID, "EstimateID");
			actEstimateId=actEstimateId.substring(0, id.length()-1).trim();
			if(expEstimateId.contains(actEstimateId)){
				report.reportPass("Successfully navigated to Estimator from FAQ page: "+actEstimateId);
			}else{
				report.reportFail("Failed to navigate Estimator from FAQ page: "+actEstimateId,true);
				verify.append("Failed to navigate Estimator from FAQ page");
			}
			waitForPageLoade(3);
			String totalResponsibilityUpdated=webActions.waitAndGetText(self.lbl_TotalResponsibility, "TotalResponsibility");
			totalResponsibilityUpdated = totalResponsibilityUpdated.replace("$", "").replace(",","");
			report.reportInfo("Updated Estimate Value in FAQ: "+estimateAmount);
			report.reportInfo("Total Patient Responsibility Value in Estimator page after update in FAQ page: "+totalResponsibilityUpdated);
			report.reportInfo("Total Patient Responsibility Value in Estimator page before update in FAQ page: "+totalResponsibility);
			if(totalResponsibility.contains(totalResponsibilityUpdated)){
				report.reportPass("Successfully verified the Estimated Amount in Estimator page after updated in FAQ");
			}else{
				report.reportFail("Fail to verify the Estimated Amount in Estimator page after updated in FAQ",true);
				verify.append("Fail to verify the Estimated Amount in Estimator page after updated in FAQ");
			}

			if(verify.length()!=0){
				report.reportFail(""+verify);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyP2P(DataTable testData){
		try {
			String accountNumber=getDataFromJSONFile("AccountNumber");
			ArrayList<String> data=new ArrayList<String>(testData.asList());
			ArrayList<String> expectedBreadcrumbTitles=new ArrayList<String>();
			expectedBreadcrumbTitles.add(data.get(0));
			expectedBreadcrumbTitles.add(accountNumber);
			expectedBreadcrumbTitles.add(data.get(1));
			expectedBreadcrumbTitles.add(data.get(2));

			StringBuilder verify=new StringBuilder();
			try {
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(btn_GoToP2P, "P2P", 10);
			} catch (Exception e) {
			}
			waitForPageLoade(5);
			webActions.click(btn_GoToP2P, "P2P");
			waitForPageLoade(5);
			ArrayList<String> actualBreadcrumbTitles_P2P = webActions.getDatafromWebTable(payment.lbl_Breadcrum);
			ArrayList<String> unmatchBreadcrumb_P2P=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles_P2P, expectedBreadcrumbTitles);
			if(unmatchBreadcrumb_P2P.size()==0){
				report.reportPass("Successfully verified Breadcrumb when user navigated to P2P from FAQ page: "+actualBreadcrumbTitles_P2P);
			}else{
				report.reportFail("Fail to verify Breadcrumb when user navigated to P2P from FAQ page: "+unmatchBreadcrumb_P2P,true);
				verify.append("Fail to verify Breadcrumb when user navigated to P2P from FAQ page");
			}

			webActions.waitAndClick(btn_RunCreditCheck, "Run Credi Check");

			webActions.waitAndClick(btn_SendRequest, "Send Request");
			String actMessage=pcp.getAlertMessage();
			if(actMessage.contains("Request Send Successfully")){
				report.reportPass("Successfully verified the alert message after ran the P2P: "+actMessage);
			}
			else{
				report.reportFail("Fail to verify the alert message after ran the P2P: "+actMessage,true);
			}
			ArrayList<String>expP2P=new ArrayList<String>();
			expP2P.add(webActions.waitAndGetText(lbl_AccountScore, "Account Score").trim());
			String fpl=webActions.waitAndGetText(lbl_FPL, "FPL").trim();
			fpl= fpl.replaceAll("[^a-zA-Z0-9]","");
			expP2P.add(fpl);
			webActions.click(lnk_FAQ, "FAQ");
			waitForPageLoade(10);

			ArrayList<String>actP2P=new ArrayList<String>();
			String accountScore=webActions.getAttributeValue(txt_AccountScore, "aria-valuenow", "Account Score_FAQ").trim();
			actP2P.add(accountScore);
			String FPL=webActions.getAttributeValue(txt_PercentFPL, "aria-valuenow", "FPL_FAQ").trim();
			actP2P.add(FPL);
			ArrayList<String>unMatchP2P=webActions.getUmatchedInArrayComparision(actP2P, expP2P);
			if(unMatchP2P.size()==0){
				report.reportPass("Successfully verified P2P Credit score in FAQ page: "+actP2P);
			}else{
				report.reportFail("Fail to verify the P2P Credit score in FAQ page: "+unMatchP2P,true);
				verify.append("Fail to verify the P2P Credit score in FAQ page");
			}

			double d_accountScore,d_fpl;
			d_accountScore=Double.parseDouble(accountScore);
			d_accountScore=d_accountScore+5;
			accountScore=String.valueOf(d_accountScore);
			webActions.clearValueAndSendKeys(txt_AccountScore, accountScore, "AccountScore");
			d_fpl=Double.valueOf(FPL);
			d_fpl=d_fpl-3;
			FPL=String.valueOf(d_fpl);
			webActions.clearValueAndSendKeys(txt_PercentFPL, FPL, "PercentFPL");
			webActions.click(btn_SaveChanges, "Save Changes");

			String actMessageP2PUpdate=pcp.getAlertMessage();
			webActions.waitForPageLoaded();
			if(actMessageP2PUpdate.contains("Data saved successfully.")){
				report.reportPass("Successfully verified the alert message after update the P2P Credit: "+actMessageP2PUpdate);
			}
			else{
				report.reportFail("Fail to verify the alert message after update the P2P Credit: "+actMessageP2PUpdate,true);
				verify.append("Fail to verify the alert message after update the P2P Credit");
			}

			webActions.click(btn_GoToP2P, "GoToP2P");
			webActions.waitForPageLoaded();
			ArrayList<String>actP2PAfterUpdate=new ArrayList<String>();
			actP2PAfterUpdate.add(webActions.waitAndGetText(lbl_AccountScore, "Account Score").trim());
			String fplUpdate=webActions.waitAndGetText(lbl_FPL, "FPL").trim();
			fplUpdate= fplUpdate.replaceAll("[^a-zA-Z0-9]","");
			actP2PAfterUpdate.add(fplUpdate);
			report.reportInfo("Updated P2P Credit values in FAQ: AccountScore: "+accountScore+" and PercentFPL: "+FPL);
			report.reportInfo("P2P Credit values in P2P page after update in FAQ page: "+actP2PAfterUpdate);
			report.reportInfo("P2P Credit values in P2P page before update in FAQ page: : "+expP2P);
			ArrayList<String>unMatchP2PUpdate=webActions.getUmatchedInArrayComparision(actP2PAfterUpdate, expP2P);
			if(unMatchP2PUpdate.size()==0){
				report.reportPass("Successfully verified P2P Credit score in P2P page after updated in FAQ"+actP2PAfterUpdate);
			}else{
				report.reportFail("Fail to verify P2P Credit score in P2P page after updated in FAQ: "+unMatchP2PUpdate,true);
				verify.append("Fail to verify P2P Credit score in P2P page after updated in FAQ");
			}

			if(verify.length()!=0){
				report.reportFail(""+verify);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void AddViewCaseNote(DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			waitForPageLoade(3);
			webActions.click(btn_NoteIcon, "btn_NoteIcon");
			String actMessage=webActions.waitAndGetText(self.lbl_NoRecords, "No Records");

			if("No records to display".contains(actMessage)){
				report.reportPass("Successfully verified the message when no records found: "+actMessage);
			}else{
				report.reportFail("Fail to verify the message when no records found: "+actMessage,true);
				verify.append("Fail to verify the message when no records found");
			}

			String note=webActions.getDatafromMap(testData, "Note");
			webActions.sendKeys(txt_Note, note, "Notes text");
			webActions.click(btn_AddNote, "Add Note");
			String actNoteAlertMsg=pcp.getAlertMessage();

			if("Note created successfully.".contains(actNoteAlertMsg)){
				report.reportPass("Alert message is matched when Note is added: "+actNoteAlertMsg);
				webActions.waitForLoad();
			}else{
				report.reportFail("Alert message is not matched when Note is added: "+actNoteAlertMsg,true);
				verify.append("Alert message is not matched when Note is added");
			}
			waitForPageLoade(2);
			ArrayList<String>expData=new ArrayList<>();
			expData.add(note);
			expData.add(webActions.getDatafromMap(testData, "Operator"));
			expData.add(webActions.getCurrentSystemDateTime());
			report.reportInfo("Expected note details: "+expData);

			ArrayList<String>actData=getNoteDetailsinFullPage();

			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the note details after is added: "+actData);
				webActions.click(btn_CloseX, "Close Note");
			}else{
				report.reportFail("Failed to verify the note details after is added: "+unmatch,true);
				webActions.click(btn_CloseX, "Close Note");
				verify.append("Failed to verify the note details after is added");
			}
			waitForPageLoade(1);
			webActions.click(btn_NoteIcon, "btn_NoteIcon");
			waitForPageLoade(2);
			ArrayList<String>actViewNoteData=getNoteDetailsinFullPage();

			ArrayList<String>unmatchViewNoteData=webActions.getUmatchedInArrayComparision(actViewNoteData, expData);
			if(unmatchViewNoteData.size()==0){
				report.reportPass("Successfully verified the view note details: "+actViewNoteData);
				webActions.click(btn_CloseX, "Close Note");
			}else{
				report.reportFail("Failed to verify the view note details: "+unmatchViewNoteData,true);
				webActions.click(btn_CloseX, "Close Note");
				verify.append("Failed to verify the view note details");
			}
			webActions.waitForPageLoaded();
			webActions.sendKeys(dd_CaseOwner, webActions.getDatafromMap(testData, "Case Owner"), "Case Owner");
			String actCaseOwnerAlertMsg=pcp.getAlertMessage();

			if("Case owner updated successfully.".contains(actCaseOwnerAlertMsg)){
				report.reportPass("Alert message is matched when Case owner updated: "+actCaseOwnerAlertMsg);
				webActions.waitForLoad();
			}else{
				report.reportFail("Alert message is not matched when Case owner updated: "+actCaseOwnerAlertMsg,true);
				verify.append("Alert message is not matched when Case owner updated");
			}

			if(verify.length()!=0){
				report.reportFail(""+verify);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void changeStatusVerifyData(DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			String status=webActions.getDatafromMap(testData, "Status");
			String date=webActions.getSystemCurrentDate();
			String tab=webActions.getDatafromMap(testData, "Tab Name");
			String operator=webActions.getDatafromMap(testData, "Operator");
			ArrayList<String> expData = new ArrayList<String>();
			expData.add(tab);
			expData.add(status);
			expData.add(date);
			expData.add(operator);

			if (!status.contentEquals("Not Started")) {
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				webActions.sendKeys(dd_Status, status, "Status");
				String actAlertMessage = pcp.getAlertMessage();
				if ("Data saved successfully.".contains(actAlertMessage)) {
					report.reportPass(
							"Successfully verified the alert message after change the status: " + actAlertMessage);
				} else {
					report.reportFail("Fail to verify the alert message after change the status: " + actAlertMessage,
							true);
					unmatch.append("Fail to verify the alert message after change the status");
				} 
			}
			String actRunInfo=webActions.waitAndGetText(lbl_RunInfo, "Ran Info");

			if(actRunInfo.contains(operator+" "+date)){
				report.reportPass("Successfully verified the last ran information: "+actRunInfo);	
			}else{
				report.reportFail("Fail to verify the last ran information: "+actRunInfo,true);
				unmatch.append("Fail to verify the last ran information");
			}

			String actStatus=webActions.waitAndGetText(lbl_Status, "Status");
			if(actStatus.contains("Evaluation - "+status)){
				report.reportPass("Successfully verified the Status in Full Page: "+actStatus);
			}else{
				report.reportFail("Fail to verify the Status in Full Page: "+actStatus,true);
				unmatch.append("Fail to verify the Status in Full Page");
			}

			String actFCStatusFullPage=webActions.getAttributeValue(atr_FCStatusFullPage, "src", "FCStatusFullPage");
			String expFCStatus=payment.getFinancialClearanceStatus(testData);
			if(actFCStatusFullPage.contains(expFCStatus)){
				report.reportPass("Successfully verified the Financial Clearance Status in Full Page: "+actFCStatusFullPage);
			}else{
				report.reportFail("Fail to verify the Financial Clearance Status in Full Page: "+actFCStatusFullPage);
				unmatch.append("Fail to verify the Financial Clearance Status in Full Page");
			}

			String expCaseNumber=webActions.waitAndGetText(lbl_HeaderMessage, "Case Number in Full Page");
			expCaseNumber=expCaseNumber.replaceAll("[^0-9]", "");

			if((status.contentEquals("Complete"))||(status.contentEquals("Does not Qualify"))){
				ArrayList<String> fieldStatus=new ArrayList<String>();
				fieldStatus.add(webActions.getAttributeValue(dd_Status, "disabled", "Status"));
				fieldStatus.add(webActions.getAttributeValue(txt_EstimateAmount, "disabled", "EstimateAmount"));
				fieldStatus.add(webActions.getAttributeValue(txt_AccountScore, "disabled", "AccountScore"));
				fieldStatus.add(webActions.getAttributeValue(txt_PercentFPL, "disabled", "FPL"));
				ArrayList<String>unmatchStatus=webActions.isFullArrayMatchWithData(fieldStatus, "true");
				if(unmatchStatus.size()==0){
					report.reportPass("Successfully verified the Status and Amounts fields are in disabled mode when the FAQ status is: "+status);
				}else{
					report.reportFail("Fail to verify the Status and Amounts fields are in disabled mode when the FAQ status is: "+status,true);
					unmatch.append("Fail to verify the Status and Amounts fields are in disabled mode when the FAQ status is");
				}
			}

			String accountNumber=getDataFromJSONFile("AccountNumber");
			driver.findElement(By.linkText(accountNumber)).click();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String actCaseNumber=webActions.waitAndGetText(lbl_CaseNo, "Case Number");
			if(actCaseNumber.contains(expCaseNumber)){
				report.reportPass("Successfully verified the Case Number in Short panel: "+actCaseNumber);	
			}else{
				report.reportFail("Fail to verify the Case Number Short panel: "+actCaseNumber,true);
				unmatch.append("Fail to verify the Case Number Short panel");
			}

			String actFCStatusShortPanel=webActions.getAttributeValue(atr_FCStatusShortPanel, "src", "FCStatusShortPanel");
			if(actFCStatusShortPanel.contains(expFCStatus)){
				report.reportPass("Successfully verified the Financial Clearance Status in Short panel: "+actFCStatusFullPage);
			}else{
				report.reportFail("Fail to verify the Financial Clearance Status in Short panel: "+actFCStatusFullPage);
				unmatch.append("Fail to verify the Financial Clearance Status in Short panel");
			}

			ArrayList<String> actData=webActions.getDatafromWebTable(lbl_ShortPanelData);
			report.reportInfo("Actual case data in short panel: "+actData);
			report.reportInfo("Expected case data in short panel: "+expData);
			ArrayList<String>unMatchData=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unMatchData.size()==0){
				report.reportPass("Successfully verified the case data in short panel: "+actData);
			}else{
				report.reportFail("Fail to verify the case data in short panel: "+unMatchData);
				unmatch.append("Fail to verify the case data in short panel");
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void addPrograms(String program){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(tab_Programs, "Programs");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(lnk_AddPrograms, "Add Programs");
			webActions.waitForVisibility(tr_FirstRow, "First Program", 20);
			driver.findElement(By.xpath("//td[(text()='"+program+"')]")).click();
			webActions.waitForPageLoaded();
			webActions.click(btn_Save, "Save");
			String actAlert=pcp.getAlertMessage();
			if("Data saved successfully.".contentEquals(actAlert)){
				report.reportPass("Successfully verified alert message after program is created: "+actAlert);
			}else{
				report.reportFail("Fail to verify the alert message after program is created: "+actAlert);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}

	public void approveProgramWithDiscount(DataTable testData){
		String expPatientResponsibility="";
		try {
			StringBuilder unmatch=new StringBuilder();
			String discount=webActions.getDatafromMap(testData, "Discount");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_Discount, discount, "Discount");
			String actAlert=pcp.getAlertMessage();
			if("Program updated successfully.".contentEquals(actAlert)){
				report.reportPass("Successfully verified alert message after discount applied: "+actAlert);
			}else{
				report.reportFail("Fail to verify the alert message after discount applied: "+actAlert,true);
				unmatch.append("Fail to verify the alert message after discount applied");
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String Status=webActions.getDatafromMap(testData, "Status");
			webActions.sendKeys(dd_ProgramStatus, Status, "ProgramStatus");
			String actAlertStatus=pcp.getAlertMessage();
			if("Data saved successfully.".contentEquals(actAlertStatus)){
				report.reportPass("Successfully verified alert message after program status changed: "+actAlertStatus);
			}else{
				report.reportFail("Fail to verify the alert message after program status changed: "+actAlertStatus,true);
				unmatch.append("Fail to verify the alert message after program status changed");
			}

			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String actTotalCharges=webActions.getDatafromMap(testData,"Total Charges");
			waitForPageLoade(3);
			webActions.click(txt_TotalCharges, "Total");
			webActions.sendKeys(txt_TotalCharges, actTotalCharges, "Total");
			webActions.pressTab();
			String actAlertTotalCharges=pcp.getAlertMessage();
			if("Visit updated successfully.".contentEquals(actAlertTotalCharges)){
				report.reportPass("Successfully verified alert message after enter Total Charges: "+actAlertTotalCharges);
			}else{
				report.reportFail("Fail to verify the alert message after enter Total Charges: "+actAlertTotalCharges,true);
				unmatch.append("Fail to verify the alert message after enter Total Charges");
			}

			expPatientResponsibility=calculatePatientResponsibility(testData);
			report.reportInfo("Expected Patient Responsibility after applied the discount: "+expPatientResponsibility);
			String actpatientResponsibility=webActions.waitAndGetText(lbl_PatientResponsibility, "Patient Responsibility");
			if(actpatientResponsibility.contains(expPatientResponsibility)){
				report.reportPass("Patient Responsibility Verified successfully after applied the discount");
			}else{
				report.reportFail("Fail to verify the Patient Responsibility after applied the discount: "+actpatientResponsibility,true);
				unmatch.append("Fail to verify the Patient Responsibility after applied the discount: ");
			}

			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(btn_PayemntFacilitator, "PayemntFacilitator");
			String actAlertPayemntFacilitator=pcp.getAlertMessage();
			if("Data sent successfully.".contentEquals(actAlertPayemntFacilitator)){
				report.reportPass("Successfully verified alert message after Send To Payemnt Facilitator: "+actAlertPayemntFacilitator);
			}else{
				report.reportFail("Fail to verify the alert message after Send To Payemnt Facilitator: "+actAlertPayemntFacilitator,true);
				unmatch.append("Fail to verify the alert message after Send To Payemnt Facilitator");
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String calculatePatientResponsibility(DataTable testData){
		String actTotalCharges=webActions.getDatafromMap(testData,"Total Charges");
		String discountType=webActions.getDatafromMap(testData,"Discount Type");
		String actDiscountValue=webActions.getDatafromMap(testData,"Discount Value");
		DecimalFormat df = new DecimalFormat("#,##0.00");
		String patientResponsibility="";
		double discount, discountAmount, totalAmount;
		if (discountType.contentEquals("Percent")) {
			totalAmount = Double.parseDouble(actTotalCharges);
			Integer percentValue=Integer.valueOf(actDiscountValue);
			discount = Double.parseDouble(actDiscountValue);
			discountAmount = totalAmount*percentValue/100;
			discountAmount=totalAmount-discountAmount;
			patientResponsibility= df.format(discountAmount);
		}
		else if(discountType.contentEquals("Dollar")){
			totalAmount = Double.parseDouble(actTotalCharges);
			discount = Double.parseDouble(actDiscountValue);
			discountAmount = (totalAmount - discount);
			patientResponsibility= df.format(discountAmount);
			return patientResponsibility;
		}
		return patientResponsibility;
	}

	public ArrayList<String> getNoteDetailsinFullPage(){
		ArrayList<String>data=new ArrayList<>();
		List<WebElement> list=tr_NoteData;
		for (int i = 0; i < list.size(); i++) {
			String txt=list.get(i).getText();
			if(i==2){
				String txt1=txt.substring(0, 16);
				String txt2=txt.substring(20, 22);
				txt=txt1+" "+txt2;
			}
			data.add(txt);
		}
		return data;
	}

	public void VerifyEstimateAmountinPaymentFacilitator(){
		try {
			StringBuilder verify=new StringBuilder();
			String accountNumber=getDataFromJSONFile("AccountNumber");
			String patientResponsibility=webActions.waitAndGetText(lbl_PatientResponsibility, "Patient Responsibility");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			driver.findElement(By.linkText(accountNumber)).click();

			ArrayList<String> actLabelNames=payment.getActualLabelNamesinPanel();
			ArrayList<String> expLabelNames=getExpectedLabelNamesinPanel();
			ArrayList<String> unmatchLabels=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchLabels.size()==0){
				report.reportPass("Label names matched successfully in Panel: "+actLabelNames);
			}else{
				report.reportFail("Label names are not matched in Panel: "+unmatchLabels,true);
				verify.append("Label names are not matched in Panel");
			}

			ArrayList<String> actAmounts=payment.getActualAmountsinPanel();
			ArrayList<String>expAmounts=getExpectedAmountsinPanel(patientResponsibility);
			report.reportInfo("Expected Payment Amounts in panel: "+expAmounts);
			report.reportInfo("Actual Payment Amounts in panel: "+actAmounts);
			ArrayList<String> unmatchAmounts=webActions.getUmatchedInArrayComparision(actAmounts, expAmounts);
			if(unmatchAmounts.size()==0){
				report.reportPass("Payment Amounts matched successfully in Short Panel: "+actAmounts);
			}else{
				report.reportFail("Payment Amounts not matched in Short Panel: "+unmatchAmounts,true);
				verify.append("Payment Amounts not matched in Short Panel");
			}

			String actaulFCPFStatus=payment.getActualFinancialClearanceStatusinPanel();
			if(actaulFCPFStatus.contains("error")){
				report.reportPass("Successfully verifed the Financial Clearance Status in Payment Facilitator Short Panel");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status in Payment Facilitator Short Panel",true);
				verify.append("Failed to verify the Financial Clearance Status in Payment Facilitator Short Panel");
			}

			webActions.waitAndClick(payment.lnk_PaymentFacilitator, "Payment Facilitator");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			payment.waitforPaymentFacilitatorPage();
			ArrayList<String> actAmountsPaymentFacilitator=getActualAmountsAfterSavePayment();
			ArrayList<String> expAmountsPaymentFacilitator=getExpectedAmountsAfterSavePayment(patientResponsibility);
			report.reportInfo("Expected amounts 'Adjusted Amount' 'Paid' 'Remaining Balance' in the Payment Facilitator page: "+expAmountsPaymentFacilitator);
			report.reportInfo("Actual amounts 'Adjusted Amount' 'Paid' 'Remaining Balance' in the Payment Facilitator page: "+actAmountsPaymentFacilitator);
			ArrayList<String> unmatchAmountsPaymentFacilitatorPage=webActions.getUmatchedInArrayComparision(actAmountsPaymentFacilitator, expAmountsPaymentFacilitator);
			if(unmatchAmounts.size()==0){
				report.reportPass("Saved Payment Amounts matched successfully in Payment Facilitator page: "+actAmountsPaymentFacilitator);
			}else{
				report.reportFail("Saved Payment Amounts are not matched in Payment Facilitator page: "+unmatchAmountsPaymentFacilitatorPage,true);
				verify.append("Saved Payment Amounts are not matched in Payment Facilitator page:");
			}

			String actFinClearStatus=payment.getFinClearStatusinPaymentFacilitatorPage();
			if(actFinClearStatus.contains("error")){
				report.reportPass("Successfully verifed the Financial Clearance Status after save in Payment Facilitator Page");
			}else{
				report.reportFail("Failed to verify the Financial Clearance Status after save in Payment Facilitator Page",true);
				verify.append("Failed to verify the Financial Clearance Status after save in Payment Facilitator Page");
			}

			if(verify.length()!=0){
				report.reportFail(""+verify);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public ArrayList<String> getExpectedLabelNamesinPanel(){
		ArrayList<String>expLabelNames=new ArrayList<String>();
		expLabelNames.add("Estimate");
		expLabelNames.add("Amount Collected");
		expLabelNames.add("Remaining Balance"); 
		report.reportInfo("Expected label names in panel: "+expLabelNames);
		return expLabelNames;
	}

	public ArrayList<String> getExpectedAmountsinPanel(String totalResponsibility){
		ArrayList<String>expAmounts=new ArrayList<String>();
		expAmounts.add(totalResponsibility);
		expAmounts.add("0.00");
		expAmounts.add(totalResponsibility);
		report.reportInfo("Expected Amounts in panel: "+expAmounts);
		return expAmounts;
	}

	public ArrayList<String> getActualAmountsAfterSavePayment(){
		ArrayList<String>actSavedAmounts=new ArrayList<String>();
		payment.waitforFCStatusChange();
		actSavedAmounts.add(webActions.getAttributeValue(payment.dd_PaymentType,"value", "Adjusted Amount"));
		actSavedAmounts.add(webActions.getAttributeValue(payment.txt_TotalAmount,"value","Adjusted Amount"));
		actSavedAmounts.add(webActions.waitAndGetText(payment.txt_AdjustedAmount, "Adjusted Amount"));
		actSavedAmounts.add(webActions.waitAndGetText(payment.txt_Paid, "Paid"));
		actSavedAmounts.add(webActions.waitAndGetText(payment.txt_RemainingBalance, "Remaining Balance"));
		return actSavedAmounts;
	}

	public ArrayList<String> getExpectedAmountsAfterSavePayment(String totalResponsibility){
		ArrayList<String>expSavedAmounts=new ArrayList<String>();
		expSavedAmounts.add("Estimate");
		expSavedAmounts.add(totalResponsibility);
		expSavedAmounts.add(totalResponsibility);
		expSavedAmounts.add("0.00");
		expSavedAmounts.add(totalResponsibility);
		return expSavedAmounts;
	}

	public void navigateFAQfromEstimateandSendToPaymentFacilitator(DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			String accountNumber=getDataFromJSONFile("AccountNumber");
			String estimateBeforeDiscount=webActions.waitAndGetText(lbl_EstimateBeforeDiscount, "EstimateBeforeDiscount");
			//estimateBeforeDiscount = estimateBeforeDiscount.replace("$", "").replace(",","");

			driver.findElement(By.linkText(accountNumber)).click();
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibility(lnk_FAQ, "FAQ", 15);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
			}
			webActions.click(lnk_FAQ, "FAQ");
			try {
				webActions.waitForVisibility(btn_CreateNewCase, "CreateNewCase", 20);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
			}

			createNewCase();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String program=webActions.getDatafromMap(testData, "Program");
			addPrograms(program);

			String discount=webActions.getDatafromMap(testData, "Discount");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_Discount, discount, "Discount");
			String actAlert=pcp.getAlertMessage();
			if("Program updated successfully.".contentEquals(actAlert)){
				report.reportPass("Successfully verified alert message after discount applied: "+actAlert);
			}else{
				report.reportFail("Fail to verify the alert message after discount applied: "+actAlert,true);
				unmatch.append("Fail to verify the alert message after discount applied");
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			String Status=webActions.getDatafromMap(testData, "Status");
			webActions.sendKeys(dd_ProgramStatus, Status, "ProgramStatus");
			String actAlertStatus=pcp.getAlertMessage();
			if("Data saved successfully.".contentEquals(actAlertStatus)){
				report.reportPass("Successfully verified alert message after program status changed: "+actAlertStatus);
			}else{
				report.reportFail("Fail to verify the alert message after program status changed: "+actAlertStatus,true);
				unmatch.append("Fail to verify the alert message after program status changed");
			}

			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			waitForPageLoade(3);
			String totalCharges=webActions.getAttributeValue(txt_TotalCharges, "value", "TotalCharges");
			report.reportInfo("Estimate Before Discount value from Estimator: "+estimateBeforeDiscount);
			report.reportInfo("Total Charges value from FAQ Programs: "+totalCharges);
			if(totalCharges.contentEquals(estimateBeforeDiscount)){
				report.reportPass("Successfully verified the Estimate Amount");
				if((totalCharges.contentEquals("$0.00"))&&(totalCharges.contentEquals("$0.00"))){
					webActions.waitAndClick(txt_TotalCharges, "TotalCharges");
					webActions.sendKeys(txt_TotalCharges, "150", "TotalCharges");
					webActions.pressTab();
					pcp.getAlertMessage();
				}
			}else{
				report.reportFail("Fail to verify the Estimated Amount",true);
				unmatch.append("Fail to verify the Estimated Amount");
			}
			

			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_PayemntFacilitator, "PayemntFacilitator");
			String actAlertPayemntFacilitator=pcp.getAlertMessage();
			if("Data sent successfully.".contentEquals(actAlertPayemntFacilitator)){
				report.reportPass("Successfully verified alert message after Send To Payemnt Facilitator: "+actAlertPayemntFacilitator);
			}else{
				report.reportFail("Fail to verify the alert message after Send To Payemnt Facilitator: "+actAlertPayemntFacilitator,true);
				unmatch.append("Fail to verify the alert message after Send To Payemnt Facilitator");
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyNoMatchesFound(String expMessage){
		try {
			String accountNumber=getDataFromJSONFile("AccountNumber");
			webActions.waitAndClick(aaa.btn_AccountNumberFilter, "AccountNumberFilter");
			webActions.sendKeys(aaa.txt_AccountSearchBox, accountNumber, "Search");
			webActions.waitForVisibility(aaa.lbl_NoMatchMsg, "Message");
			String actMsg=webActions.getText(aaa.lbl_NoMatchMsg, "Message");
			if(actMsg.contentEquals(expMessage)){
				report.reportPass("Verified validation message successfully: "+actMsg);
			}else{
				report.reportFail("Fail to Verify validation message: "+actMsg);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void getFAQDataAndVerifyInWorkilits(DataTable testData){
		try {
			String accountNumber=getDataFromJSONFile("AccountNumber");
			ArrayList<String>faqData=new ArrayList<String>();
			String expCaseNumber=webActions.waitAndGetText(lbl_HeaderMessage, "Case Number in Full Page");
			expCaseNumber=expCaseNumber.replaceAll("[^0-9]", "");
			faqData.add(expCaseNumber);
			String actCaseOwner=webActions.getAttributeValue(dd_CaseOwner, "aria-label", "CaseOwner");
			String program=webActions.getDatafromMap(testData, "Program");
			faqData.add(actCaseOwner);
			faqData.add(program);
			faqData.add(webActions.getCurrentSystemDate());
			faqData.add(webActions.getCurrentSystemDate());
			String Status=webActions.getDatafromMap(testData, "Status");
			faqData.add(Status);
			addPrograms(program);
			report.reportInfo("FAQ Data is: "+faqData);
			webActions.click(lnk_WorkList, "Worklists");
			try {
				webActions.waitForVisibility(work.btn_FAQ, "Worklists", 60);
			} catch (Exception e1) {
			}
			webActions.click(work.btn_FAQ, "Worklists");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			try {
				webActions.waitForVisibility(work.lnk_AccountNo_FAQ, "AccountNumber", 30);
			} catch (Exception e) {
			}
			filterWithAccountNumber(accountNumber);
			List<WebElement>data=tr_WorkList;
			ArrayList<String> worklistData=new ArrayList<String>();
			int list=tr_WorkList.size();
			String text;
			for (int i = 0; i <list; i++) {
				if(i>3){
					text=data.get(i).getText();
					worklistData.add(text);
				}
			}
			report.reportInfo("Worklist Data is: "+worklistData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(faqData, worklistData);
			if(unmatch.size()!=0){
				report.reportPass("Successfully verified the FAQ data in Worklists ");
			}else{
				report.reportFail("Fail to verify the FAQ data in Worklists: "+unmatch);
			}

			webActions.click(work.lnk_AccountNo_FAQ, "Account Number");
			ArrayList<String> expBreadcrumbTitles =new ArrayList<String>();
			expBreadcrumbTitles.add("Worklist");
			expBreadcrumbTitles.add(accountNumber);

			ArrayList<String> actualBreadcrumbTitles = webActions.getDatafromWebTable(payment.lbl_Breadcrum);
			ArrayList<String> unmatchBreadcrumb=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles, expBreadcrumbTitles);
			if(unmatchBreadcrumb.size()==0){
				report.reportPass("Successfully navigated to Patient Visit main page from Worklist FAQ page: "+actualBreadcrumbTitles);
			}else{
				report.reportFail("Failed to navigate Patient Visit main page from Worklist FAQ page:"+unmatchBreadcrumb);
			}


		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}

	public void filterWithAccountNumber(String accountNumber){
		try {
			webActions.waitForPageLoaded();
			webActions.waitAndClick(aaa.btn_AccountNumberFilter, "AccountNumberFilter");
			webActions.sendKeys(aaa.txt_AccountSearchBox, accountNumber, "Search");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(aaa.btn_Filter, "Filter");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void navigateFullPageNeedAttentioninAccountSearch(String moduleName){
		try {
			ArrayList<String>expBreadcrumbTitles=new ArrayList<String>();
			expBreadcrumbTitles.add("Account Search");
			expBreadcrumbTitles.add(moduleName);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			driver.findElement(By.linkText(moduleName)).click();
			ArrayList<String> actualBreadcrumbTitles = webActions.getDatafromWebTable(payment.lbl_Breadcrum);
			ArrayList<String> unmatchBreadcrumb=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles, expBreadcrumbTitles);
			if(unmatchBreadcrumb.size()==0){
				report.reportPass("Successfully navigated to "+moduleName+" full page from Need Attention in Account Search: "+actualBreadcrumbTitles);
			}else{
				report.reportFail("Failed to navigate to "+moduleName+" full page from Need Attention in Account Search: "+actualBreadcrumbTitles);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}



	public double getDoubleValue(String amount){
		return Double.parseDouble(amount);
	}


	@SuppressWarnings("unchecked")
	public void updateFAQJSON() throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(FAQ);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			try {
				String number = rest.getUniqueNumber();
				newNum = "A" + number;
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(0);
				tenantPatient.put("TenantPatientId", newNum);

				tenantPatient = (JSONObject) msg.get(3);
				tenantPatient.put("TenantPatientId", newNum);

				String test = (String) tenantPatient.get("TenantPatientId");	
			} catch (Exception e) {
				log.error("Failed to update tenant patiend id", e);
				e.printStackTrace();
			}
			try {
				visitObject.put("AccountNumber", newNum);
				visitObject.put("VisitNumber", newNum);
				Object tt = visitObject.get("VisitDate");
				String updatedDate = rest.updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);

			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}

			FileWriter file = new FileWriter(FAQ);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}


	public String getDataFromJSONFile(String fieldName){
		String expectedResponseValue=null;
		try {
			FileReader reader = new FileReader(FAQ);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");

			if(fieldName.contentEquals("AccountNumber")){
				expectedResponseValue = (String) visitObject.get("AccountNumber");	
			}
		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return expectedResponseValue;
	}

	public void waitForPageLoade(int seconds){
		try {
			Thread.sleep(seconds*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<String> getListData(DataTable testData,int rowNum){
		return new ArrayList<String>(testData.row(rowNum));
	}


	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
