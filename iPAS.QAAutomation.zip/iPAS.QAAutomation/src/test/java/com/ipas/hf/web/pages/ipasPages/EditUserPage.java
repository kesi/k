package com.ipas.hf.web.pages.ipasPages;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class EditUserPage extends BasePage{
	
	@FindBy(xpath="//input[@aria-placeholder='Type Employee Name']")
	private WebElement txt_searchbox;

	@FindBy(xpath="//ipas-breadcrumb//div/span")
	private List<WebElement> lbl_Breadcrumb;
	
	@FindBy(xpath="//tbody/tr[1]/td/div")
	private List<WebElement> lbl_UsersList;
	@FindBy(linkText="User Accounts")
	private WebElement lnk_UserAccounts;
	
	@FindBy(xpath="//button[text()='Add New User']")
	private WebElement btn_AddNewUser;
	
	@FindBy(xpath="//tbody/tr[1]/td[1]//a")
	private WebElement lnk_user;
	
	@FindBy(xpath="//button[contains(text(),'Submit')]")
	private WebElement btn_SubmitInUserCreation;
	
	@FindBy(xpath="//input[@formcontrolname='LastName']")
	private WebElement txt_lastname;
	
	@FindBy(xpath="//input[@formcontrolname='FirstName']")
	private WebElement txt_firstname;
	
	@FindBy(xpath="//input[@id='OperatorID']")
	private WebElement txt_operatorID;
	
	@FindBy(xpath="//input[@id='contactsEmail']")
	private WebElement txt_EmailID;
	
	@FindBy(xpath="//input[@formcontrolname='PhoneNumber']")
	private WebElement txt_phone;
	
	@FindBy(xpath="//div[@class='maintenance-section']//div[2]/h4")
	private WebElement lbl_heading;
	
	@FindBy(xpath="//div[@class='headtitle']/span")
	private List<WebElement> lbl_sections;
	
	@FindBy(xpath="//button[text()='Clear']")
	private WebElement btn_Clear;
	
	@FindBy(xpath="//div[@class='form-group']/input")
	private List<WebElement> lbl_Placeholder_TextFeilds;

	@FindBy(xpath="//div[@class='form-group']/ejs-dropdownlist/span/input")
	private List<WebElement> lbl_Placeholder_DropdownlistFeilds;

	@FindBy(xpath="//div[@class='form-group']/ejs-maskedtextbox")
	private List<WebElement> lbl_Placeholder_MaskedtextboxFeilds;

	@FindBy(xpath="//div[@class='form-group']/ejs-multiselect//following::input[@class='e-dropdownbase']")
	private List<WebElement> lbl_Placeholder_MultiselectFeilds;
	
	@FindBy(xpath="//button[text()='Cancel']")
	private WebElement btn_Cancel;
	
	@FindBy(xpath="//button[(text()='Submit')]")
	private WebElement btn_Submit;
	
	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;
	
	@FindBy(xpath = "//a[@class='breadcrum' and text()='User Maintenance']")
	private WebElement brdcrum_UserMaintenance;
	
	@FindBy(xpath = "//a[@class='breadcrum' and text()='System Configuration']")
	private WebElement brdcrum_SystemConfiguration;
	
	@FindBy(linkText = "Maintenance")
	private WebElement lnk_Maintenance;
	
	@FindBy(xpath = "//div[@class='mandatory']")
	private List<WebElement> lst_MandatoryFieldValidationMessage;
	
	
	
	@FindBy(xpath="//span[@class='mandatory']/../../label")
	private List<WebElement> lbl_MandatoryFeilds;
	
	RestActions rest=new RestActions();
	HomePage homePage=new HomePage();

	
	public EditUserPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void navigateToEditUser(){
		try {
			webActions.waitAndClick(lnk_UserAccounts, "User Accounts Link");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_UsersList, "UsersList");
			String userLastName=webActions.notepadRead("hellow");
			webActions.sendKeys(txt_searchbox,userLastName,"Search Input");
			Thread.sleep(1000);
			webActions.click(lnk_user,"User Added");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_SubmitInUserCreation, "SubmitBtn");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	

	public void verifyBreadcrumbinEditUserPage(DataTable breadcrumb ){
		try {
			ArrayList<String> expectdBreadcrumb = new ArrayList<>(breadcrumb.asList());			
			webActions.clearValue(txt_searchbox, "Search Input");
			webActions.waitForPageLoaded();			
			navigateToEditUser();
			ArrayList<String> actualBreadcrumb=webActions.getDatafromWebTable(lbl_Breadcrumb);
			report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumb);
			report.reportInfo("Expected Breadcrumb Titles "+expectdBreadcrumb);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumb, expectdBreadcrumb);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Breadcrumb Titles in Edit User page");
			}else{
				throw new Exception("Fail to verify the Breadcrumb Titles in Edit User page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyEditUserHeading(){
		try {
			navigateToEditUser();
			String expectedHeading=webActions.getValue(txt_operatorID,"Attribute");
			String actualHeading=webActions.getText(lbl_heading, "Actual Heading");
			if(expectedHeading.contentEquals(actualHeading))
			{
				report.reportPass("Operator ID is displayed as Edit User Page Title as :"+actualHeading);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifytheSections(DataTable sections){
		try {
			ArrayList<String> expectdSections = new ArrayList<>(sections.asList());
			navigateToEditUser();
			ArrayList<String> actualSections =new ArrayList<String>();
			actualSections.addAll(webActions.getDatafromWebTable(lbl_sections));
			report.reportInfo("Actual Sections in Edit User page: "+actualSections);
			report.reportInfo("Expected Sections in Edit User page: "+expectdSections);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualSections, expectdSections);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Sections in the Edit User page");
			}else{
				throw new Exception("Fail to verify the the Sections in the Edit User page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifythePlaceholdersforallFields(DataTable placeholders){
		try {
			ArrayList<String> expectdPlaceholders = new ArrayList<>(placeholders.asList());
			navigateToEditUser();
			webActions.click(btn_Clear, "Clear");
			//webActions.click(btn_Clear, "Clear");
			ArrayList<String> actualPlaceholders =new ArrayList<String>();
			actualPlaceholders.addAll(webActions.getListofAttributeValuesfromWebPage(lbl_Placeholder_TextFeilds,"placeholder"));
			actualPlaceholders.addAll(webActions.getListofAttributeValuesfromWebPage(lbl_Placeholder_DropdownlistFeilds, "placeholder"));
			actualPlaceholders.addAll(webActions.getListofAttributeValuesfromWebPage(lbl_Placeholder_MaskedtextboxFeilds, "placeholder"));
			actualPlaceholders.addAll(webActions.getListofAttributeValuesfromWebPage(lbl_Placeholder_MultiselectFeilds, "placeholder"));
			report.reportInfo("Actual Placeholders: "+actualPlaceholders);
			report.reportInfo("Expected Placeholders: "+expectdPlaceholders);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualPlaceholders, expectdPlaceholders);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Placeholders for all fields in the edit user");
			}else{
				throw new Exception("Fail to verify the Placeholders for all fields in edit user page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyCancelButtonFunctionalityEditUser(){
		try {
			navigateToEditUser();
			webActions.waitAndClick(btn_Cancel, "Cancel");
			String addNewUserButtonName=webActions.waitAndGetText(btn_AddNewUser, "Add New User");
			if("Add New User".contentEquals(addNewUserButtonName)){
				report.reportInfo("User is navigated to User list page after click on Cancel button and verified Add New User Button: "+addNewUserButtonName);
				report.reportPass("Successfully verified the Cancel button functionality in the Add New User page");	
			}else{
				throw new Exception("Fail to verify the Cancel button functionality, Users is not navigated to User List page");
			}
		} catch (Exception e) {	
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifytheFieldsDisabledEditUser(){
		try {
			navigateToEditUser();
			if(!(txt_operatorID).isEnabled()&&!(txt_EmailID).isEnabled())
			{
				report.reportPass("Operator Id field and Email Fields are disabled in Edit User Page");	
			}
		} catch (Exception e) {	
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyMandatoryFields(DataTable mandatoryFields ){
		try {
			ArrayList<String> expectdmandatoryFields = new ArrayList<>(mandatoryFields.asList());
			navigateToEditUser();
			waitforSubmitButton();
			ArrayList<String> actualmandatoryFields=webActions.getListofAttributeValuesfromWebPage(lbl_MandatoryFeilds,"for");
			report.reportInfo("Actual Mandatory Fields: "+actualmandatoryFields);
			report.reportInfo("Expected Mandatory Fields: "+expectdmandatoryFields);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualmandatoryFields, expectdmandatoryFields);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Mandatory Fields in Add New User page");
			}else{
				throw new Exception("Fail to verify the Mandatory Fields in Add New User page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void waitforSubmitButton(){
		try {
			webActions.waitUntilisDisplayed(btn_Submit, "Submit Button");
		} catch (Exception e) {
		}
	}
	
	public void verifyChangesSaved(){
		try {
			String messageTitle ="Success!";
			String messageContent="Data updated successfully.";
			String testNumber=rest.randomNumber(10);
			navigateToEditUser();
			waitforSubmitButton();
			webActions.clearValue(txt_phone, "Phone Number");
			webActions.click(txt_phone, "Phone Number");
			webActions.enterValuesfromKeyBoard(txt_phone,testNumber, "Phone Number");
			try {
				if(btn_Submit.isEnabled())
				{
					webActions.click(btn_Submit, "Submit Button");
					 String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			            String[] titleContent=msg.split("\\n");
			            String actTitle=titleContent[0];
			            String actContent=titleContent[1];
			            report.reportInfo("Actual alert message after user created: "+msg);
			            if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent)))
			            	{
				            report.reportPass("Successfully user is updated and alert message is matched: "+msg);
				            try {
								webActions.waitForPageLoaded();
								webActions.click(lnk_Maintenance, "Maintenance");
					            report.reportPass("Should click on maintainance tab");
								navigateToEditUser();
								webActions.waitForPageLoaded();
								String UpdatedValue=webActions.getAttributeValue(txt_phone, "value","PhoneNumber");
								report.reportInfo("Updated value :"+UpdatedValue);
								UpdatedValue=UpdatedValue.replaceAll("[()+^-]*","");
								UpdatedValue=UpdatedValue.replaceAll("-","");
								report.reportInfo("New Updated value :"+UpdatedValue);
								report.reportInfo("Actual value :"+testNumber);
								if(UpdatedValue.trim().contentEquals(testNumber.trim()))
								{
						            report.reportPass("Edit User Updation Successful ");
								}
								else
								{
									throw new Exception("Fail to update in Edit User page");
								}
							} catch (Exception e) {
					            report.reportFail("Failed to update the values in Edit User" +e);
							}
							
			            	}
			            else
			            {
				            report.reportFail("Failed to edit user user and alert message is not matched: "+msg);
			            }
				}	
			} catch (Exception e) {
				report.reportFail(e.getMessage());
             }
			
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyChangesNotSaved(){
		try {
			String testNumber=rest.randomNumber(10);
			navigateToEditUser();
			waitforSubmitButton();
			String actualPhoneNumber=webActions.getAttributeValue(txt_phone,"value","Phone Number");
			webActions.clearValue(txt_phone, "Phone Number");
			webActions.click(txt_phone, "Phone Number");
			webActions.enterValuesfromKeyBoard(txt_phone,testNumber, "Phone Number");
			webActions.click(btn_Cancel, "Cancel Button");
			try {
				webActions.waitForPageLoaded();
				webActions.click(lnk_Maintenance, "Maintenance");
				report.reportPass("Should click on maintainance tab");
				navigateToEditUser();
				webActions.waitForPageLoaded();
				String UpdatedValue=webActions.getAttributeValue(txt_phone, "value","PhoneNumber");
				report.reportInfo("Updated value :"+UpdatedValue);
				report.reportInfo("Actual value :"+actualPhoneNumber);
				if(actualPhoneNumber.trim().contentEquals(UpdatedValue))
				{
					report.reportPass("Edit User should not be updated until user clicked on submit ");
				}
				else
				{
					throw new Exception("Fail to update in Edit User page");
				}
			} catch (Exception e) {
				report.reportFail("Failed to update the values in Edit User" +e);
			}


		}	
		catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyValidationMessageMinimumAndMaximum(String length,String testData,DataTable validationMessages){
		try {
			navigateToEditUser();
			webActions.waitForVisibility(txt_lastname,"Last Name");
			ArrayList<String> expectdValidationMessages = new ArrayList<>(validationMessages.asList());
			webActions.clearValue(txt_lastname, "Last Name");
			webActions.clearValue(txt_firstname,"First Name");
			webActions.sendKeys(txt_lastname, testData, "Last Name");
			webActions.pressTab();
			webActions.sendKeys(txt_firstname, testData, "First Name");
			webActions.pressTab();
			webActions.waitForPageLoaded();
			ArrayList<String> actualValidationMessages=webActions.getDatafromWebTable(lst_MandatoryFieldValidationMessage);
			report.reportInfo("Actual Validation Messages: "+actualValidationMessages);
			report.reportInfo("Expected Validation Messages: "+expectdValidationMessages);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualValidationMessages, expectdValidationMessages);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Validation Messages if enter less than minimum characters length of "+testData+" in First Name, Last Name  in edit user");
			}else{
				throw new Exception("Fail to verify the Validation Messages if enter less than minimum characters"+testData+" due to" +unmatch);

			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyMessageNumericsValidation(String length,String testData,DataTable validationMessages){
		try {
			navigateToEditUser();
			webActions.waitForVisibility(txt_lastname,"Last Name");
			ArrayList<String> expectdValidationMessages = new ArrayList<>(validationMessages.asList());
			webActions.sendKeys(txt_lastname, testData, "Last Name");
			webActions.sendKeys(txt_firstname, testData, "First Name");
			webActions.pressTab();
			webActions.waitForPageLoaded();
			ArrayList<String> actualValidationMessages=webActions.getDatafromWebTable(lst_MandatoryFieldValidationMessage);
			report.reportInfo("Actual Validation Messages: "+actualValidationMessages);
			report.reportInfo("Expected Validation Messages: "+expectdValidationMessages);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualValidationMessages, expectdValidationMessages);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Validation Messages if Numerics are entered in text fields "+testData+" in First Name, Last Name in edit user");
			}else{
				throw new Exception("Fail to verify the Validation Messages if if Numerics are entered in text fields "+testData+" due to" +unmatch);

			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}


	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
