package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.AdministrativeDepartmentsPage;
import com.ipas.hf.web.pages.ipasPages.ViewTenantsPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class AdministrativeDepartmentsSteps {

	AdministrativeDepartmentsPage adminDepart=new AdministrativeDepartmentsPage();
	
	@Then("Verify the Organization Levels panel and Text Message")
	public void verify_the_Organization_Levels_panel_and_Text_Message(DataTable testData) {
		adminDepart.verifyOrganizationLevelsPanel(testData);
	}
	
	@Then("Verify fields in Add Administrative Departments page")
	public void verify_fields_in_Add_Administrative_Departments_page(DataTable testData) {
		adminDepart.verifyFieldsInAddAdministrativeDepartmentsPage(testData);
	}
	
	@Then("Verify the mandatory validation messages")
	public void verify_the_mandatory_validation_messages(DataTable testData) {
		adminDepart.verifyMandatoryFieldValidationMessages(testData);
	}
	
	@Then("Verify the Cancel button")
	public void verify_the_Cancel_button() {
		adminDepart.verifyCancelButton();
	}
	
	@Then("Verify Add Administrative Departments")
	public void verify_Add_Administrative_Departments(DataTable testData) {
		adminDepart.addAdministrativeDepartmentandVerifytheData(testData);
	}
	
	@Then("Verify Add Administrative Departments with All Facilities")
	public void verify_Add_Administrative_Departments_with_All_Facilities(DataTable testData) {
		adminDepart.addAdministrativeDepartmentwithAllFacilitiesandVerifytheData(testData);
	}
	
	@Then("Verify the Header Names")
	public void verify_the_Header_Names(DataTable headerNames) {
		adminDepart.verifyHeaderNames(headerNames);
	}
	
	@Then("Verify the Administrative Departments search functionality with {string}")
	public void verify_the_Administrative_Departments_search_functionality_with(String adminDepName) {
		adminDepart.searchAdministrativeDepartments(adminDepName);
	}

	@Then("Navigate to Administrative Departments page")
	public void navigate_to_Administrative_Departments_page() {
		adminDepart.navigateAdministrativeDepartmentPage();
	}
	
	@Then("Verify the Administrative Departments Status as {string}")
	public void verify_the_Administrative_Departments_Status_as(String status) {
		adminDepart.searchAdministrativeDepartmentsGridData(status);
	}
	
	@Then("Verify Effective and Expiration Date for {string} Administrative Departments")
	public void verify_Effective_and_Expiration_Date_for_Administrative_Departments(String status) {
		adminDepart.verifyEffectiveAndExpirationDates(status);
	}

	
}
