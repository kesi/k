package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class IdentityVerifierPage extends BasePage {

	@FindBy(xpath = "//app-ipas-identity-propensity-short-pannel//ejs-accordion//span/div/a")
	private WebElement txt_IdentityVerifierPanelTitle;

	@FindBy(xpath = "//app-ipas-identity-propensity-short-pannel//financial-clearance-status/img")
	private WebElement img_IdentityShortPanelModuleStatus;

	@FindBy(xpath="//app-ipas-identity-propensity-short-pannel//ejs-accordion//div[@class='e-toggle-icon']/span")
	private WebElement icon_IdentityExpandCollapse;

	@FindBy(xpath="//p[contains(text(),'Other Phone Numbers')]")
	private WebElement lbl_IdentityFullPanelPhone;

	@FindBy(xpath = "//ipas-identity-propensity-details//div[@class='title']")
	private WebElement txt_IdentityVerifierFullPanelTitle;

	@FindBy(xpath = "//ipas-identity-propensity-details//financial-clearance-status/img")
	private WebElement img_IdentityFullPanelModuleStatus;

	@FindBy(xpath="//app-ipas-identity-propensity-short-pannel//div[@class='last-run-info ng-star-inserted']/p")
	private WebElement txt_IdentityShortLastRunBy;

	@FindBy(xpath="//ipas-identity-propensity-details//div[@class='date ng-star-inserted']")
	private WebElement txt_IdentityFullPanelLastRunBy;

	@FindBy(xpath="//div[@class='section flex']/p")
	private WebElement lbl_IdentityFullPanelAddressSectionName;

	@FindBy(xpath="//h6[contains(text(),'Verification Response')]")
	private WebElement lbl_IdentityFullPanelVerificationResponse;

	@FindBy(xpath="//p[contains(text(),'Historical Addresses')]")
	private WebElement lbl_IdentityFullPanelHistoricalAddress;

	@FindBy(xpath="//p[contains(text(),'Other Phone Numbers')]")
	private WebElement lbl_IdentityFullPanelOtherPhones;

	@FindBy(xpath="//div[@class='patient-info']/ul/li")
	private List<WebElement> lbl_IdentityFullPanelResponse;

	@FindBy(xpath = "//app-ipas-identity-propensity-short-pannel//ejs-accordion//div[@class='no-data ng-star-inserted']")
	private WebElement txt_IdentityVerifierShortPanelMessage;

	@FindBy(xpath = "//ipas-identity-propensity-details//div[@class='no-data ng-star-inserted']")
	private WebElement txt_IdentityVerifierFullPanelMessage;

	@FindBy(xpath="(//div[@class='modal-body'])[2]//label")
	private List<WebElement> lbl_IdentityPanelRequestWindowFields;

	@FindBy(xpath="//a[contains(text(),'New Request')]")
	private WebElement btn_IdentityPanelNewRequest;

	@FindBy(xpath="//ejs-textbox[1]/span/input")
	private List<WebElement> lbl_IdentityVerifierNewRequestWindowFields;

	@FindBy(xpath="(//div[@class='modal-body'])[2]//div/p")
	private List<WebElement> lbl_IdentityVerifierNewRequestWindowMandatory;

	@FindBy(xpath="//ejs-datepicker/span/input[1]")
	private WebElement txt_IdentityPanelNewRequestDOB;

	@FindBy(xpath="//ejs-maskedtextbox[@formcontrolname='SSN']/span/input")
	private WebElement txt_IdentityPanelNewRequestSSN;

	@FindBy(xpath="(//button[contains(text(),'Cancel')])[2]")
	private WebElement btn_IdentityNewRequestWindowCancel;

	@FindBy(xpath="//div[contains(text(),'No Verification Data Found')]")
	private WebElement lbl_IdentityNoDataFound;

	@FindBy(xpath="//a[contains(text(),'New Request')]")
	private WebElement btn_IdentityHistory;

	@FindBy(xpath="(//button[@class='close'])[3]")
	private WebElement btn_IdentityNewRequestWindowCross;

	@FindBy(xpath="//span[contains(text(),'Patient visit does not have an identity verificati')]")
	private WebElement txt_IdentityShortManualMsg;

	@FindBy(xpath="//div[contains(text(),'Patient visit does not have an identity verificati')]")
	private WebElement txt_IdentityFullManualMsg;

	@FindBy(xpath="//button[contains(text(),'Send Request')]")
	private WebElement btn_IdentityNewRequestWindow;

	@FindBy(xpath="//div[@id='three']//app-ipas-document-management-pannel/div/ejs-accordion/div/div[2]/div/div/ul/li/div[1]")
	private List<WebElement> lbl_DigitalDocMangerPanel;


	@FindBy(xpath = "//div[@class='breadcrum-container noprint']/span[2]/a")
	private WebElement lnk_AccountNumber;

	@FindBy(xpath="//span[contains(text(),'No payment has created yet')]")
	private WebElement lbl_NoPayments;

	@FindBy(xpath="//ipas-payment-facilitator-pannel/ejs-accordion/div")
	private WebElement tbl_PaymentFacilitatorPanel;

	@FindBy(xpath="//ejs-accordion/div[1]/div[2]/div/div/ul/li/div[2]")
	private WebElement lbl_DataInAllDataPanel;

	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[2]")
	private List<WebElement> lbl_VisitSummaryData;	

	@FindBy(xpath="(//ipas-identity-propensity-details//div[2])[3]")
	private WebElement lbl_IdentityFullPanelLastRunBy;

	@FindBy(xpath="//app-ipas-identity-propensity-short-pannel//div/p")
	private WebElement lbl_IdentityShortPanelLastRunBy;

	@FindBy(xpath = "(//ipas-identity-propensity-details//div/p)[2]")
	private WebElement txt_IdentityVerifierFullPanelDataElements;

	@FindBy(xpath = "(//ipas-identity-propensity-details//div/financial-clearance-status/img)[2]")
	private WebElement txt_IdentityVerifierFullPanelDataElementsStatus;

	@FindBy(xpath = "//app-ipas-identity-propensity-short-pannel//div[@class='desc']")
	private WebElement txt_IdentityVerifierShortPanelDataElements;

	@FindBy(xpath = "(//app-ipas-identity-propensity-short-pannel//financial-clearance-status/img)[2]")
	private WebElement txt_IdentityVerifierShortPanelDataElementsStatus;

	@FindBy(xpath="(//ejs-textbox/span/input)[4]")
	private WebElement txt_IdentityPanelNewRequestLastName;	

	@FindBy(xpath="(//ejs-textbox/span/input)[5]")
	private WebElement txt_IdentityPanelNewRequestFirstName;

	@FindBy(xpath="(//ejs-textbox/span/input)[7]")
	private WebElement txt_IdentityPanelNewRequestStreetAddress;

	@FindBy(xpath="(//ejs-textbox/span/input)[9]")
	private WebElement txt_IdentityPanelNewRequestCity;

	@FindBy(xpath="(//ejs-textbox/span/input)[10]")
	private WebElement txt_IdentityPanelNewRequestState;

	@FindBy(xpath="(//ejs-textbox/span/input)[11]")
	private WebElement txt_IdentityPanelNewRequestZipCode;

	@FindBy(xpath="//a[contains(text(),'History')]")
	private WebElement btn_IdentityFullPanelHistory;

	@FindBy(xpath="//ejs-dialog//div/span/button[1]")
	private WebElement btn_HistoryCancel;

	@FindBy(xpath="//span[@class='e-ripple-container']")
	private WebElement btn_HistoryRecordSelect;

	@FindBy(xpath="//button[contains(text(),'Select')]")
	private WebElement btn_HistorySelect;

	@FindBy(xpath="//ipas-identity-propensity-details//div[@class='title']")
	private WebElement lbl_HistoricalMessage;

	@FindBy(xpath="//a[contains(text(),'Current Request')]")
	private WebElement btn_CurrentRequest;

	@FindBy(xpath="//tbody/tr/td/span[1]")
	private List<WebElement> lbl_IdentityHistoricalAddress;

	@FindBy(xpath="//tbody/tr/td/span[4]")
	private WebElement lbl_IdentityHistoricalAddressCity;
	@FindBy(xpath="//tbody/tr/td/span[6]")
	private WebElement lbl_IdentityHistoricalAddressState;

	@FindBy(xpath="//tbody/tr/td/span[7]")
	private WebElement lbl_IdentityHistoricalAddressZip;

	@FindBy(xpath = "//a[contains(text(),'Account Search')]")
	private WebElement lnk_AccounSearch;


	public IdentityVerifierPage() {
		PageFactory.initElements(driver, this);
	}


	public void verifyIdentityVerifier(String panel,String title){
		String actTitle="";
		try {
			webActions.waitForPageLoaded();		
			report.reportInfo("Expected short panel info: "+title);

			if(panel.contentEquals("Short Panel")){
				actTitle=webActions.getText(txt_IdentityVerifierPanelTitle, "title");
				report.reportInfo("Displayed Short Panel Title: "+actTitle);
			}
			else if(panel.contentEquals("Full Panel")){
				actTitle=webActions.getText(txt_IdentityVerifierFullPanelTitle, "title");
				report.reportInfo("Displayed Full Panel Title: "+actTitle);
			}

			if(actTitle.contentEquals(title)){
				report.reportPass("Verified successfully" +panel+  " title");
			}
			else{
				report.reportFail("Fail to verify postal" +panel+ " title and unmatched data is: "+actTitle);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyIdentityModuletStatus(String panel, String data){
		try {
			String moduleStatus = "";
			if("Short Panel".contentEquals(panel)){
				webActions.waitForVisibility(img_IdentityShortPanelModuleStatus, "ModuleStatus");
				moduleStatus=webActions.getAttributeValue(img_IdentityShortPanelModuleStatus, "src", "IdentityShortPanel");
			}			
			else if("Full Panel".contentEquals(panel)){
				webActions.waitForVisibility(img_IdentityFullPanelModuleStatus, "ModuleStatus");
				moduleStatus=webActions.getAttributeValue(img_IdentityFullPanelModuleStatus, "src", "IdentityFullPanel");
			}
			else if("FullPanelDataElements".contentEquals(panel)){
				webActions.waitForVisibility(txt_IdentityVerifierFullPanelDataElementsStatus, "ModuleStatus");
				moduleStatus=webActions.getAttributeValue(txt_IdentityVerifierFullPanelDataElementsStatus, "src", "IdentityFullPanelDataElements");
			}
			else if("ShortPanelDataElements".contentEquals(panel)){
				webActions.waitForVisibility(txt_IdentityVerifierShortPanelDataElementsStatus, "ModuleStatus");
				moduleStatus=webActions.getAttributeValue(txt_IdentityVerifierShortPanelDataElementsStatus, "src", "IdentityShortPanelDataElements");
			}
			if("Address not found".contentEquals(data)){
				if(moduleStatus.contains("error_sm")){
					report.reportPass("Verified Identity " +panel+ " module status when address not found");
				}
			}
			else if("AddressValid".contentEquals(data)){
				if(moduleStatus.contains("success_sm")){
					report.reportPass("Verified Identity " +panel+ " module status");
				}
			}
			else if("AddressReview".contentEquals(data)){
				if(moduleStatus.contains("alert_sm")){
					report.reportPass("Verified Identity " +panel+ " module status");
				}
			}
			else{
				report.reportFail("Fail to verify Identity Verifier " +panel+ "module status and actual displayed image is : " + moduleStatus);
			}		
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyExpandandCollapsIdentityPanel() throws Exception{
		StringBuilder unmatch=new StringBuilder();		
		webActions.waitForVisibility(img_IdentityShortPanelModuleStatus, "ModuleStatus");		
		String actualExpandStatus=webActions.getAttributeValue(icon_IdentityExpandCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons e-expand-icon".contentEquals(actualExpandStatus)){			
			report.reportPass("By default short Panel is displayed in Expand mode");
		}else{
			unmatch.append("Panle is not dispalyed in Expand mode by default");
			report.reportFail("Identity verifier Panel is not dispalyed in Expand mode by default");
		}
		webActions.waitAndClick(icon_IdentityExpandCollapse, "ExpandandCollapse");
		webActions.waitForPageLoaded();
		String actualCollapseStatus=webActions.getAttributeValue(icon_IdentityExpandCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons".contentEquals(actualCollapseStatus)){
			report.reportPass("Identity verifier Panel Successfully Collapsed");
		}
		else{
			unmatch.append("Identity verifier Panle is not Collapsed");
			report.reportFail("Identity verifier Panel is not Collapsed");
		}		
		if(unmatch.length()==0){
			report.reportPass("Identity verifier Panel Successfully Expanded and Collapsed");
		}else{
			report.reportFail("Failed to verify the Expand and Collapse of the Identity verifier Panel"+unmatch);
		}

	}

	public void clickOnIdentityPanel(){
		try {
			webActions.waitForVisibility(txt_IdentityVerifierPanelTitle, "Identity");
			webActions.click(txt_IdentityVerifierPanelTitle, "IdentityPanel");

			webActions.waitForVisibility(lbl_IdentityFullPanelAddressSectionName, "PanelLable");
			Thread.sleep(1000);

			report.reportInfo("Navigated to the Identity verifier Full Page");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyLastRunByInIdentityPanel(){
		String actCurrentDateTime = null; String expCurrentDateTime = null; String increasedCurrentDateTime = null;String fullPanelCurrentDateTime = null;
		try {			
			webActions.waitForVisibility(txt_IdentityVerifierPanelTitle, "PanelText");
			String actCurrentDate = webActions.waitAndGetText(txt_IdentityShortLastRunBy, "LastRunDateTime");
			actCurrentDateTime=actCurrentDate.replace(",", "");			
			report.reportInfo("Dsiplayed last run date from application: "+actCurrentDateTime);			
			String expCurrentDate = webActions.getIncreasedCurrentSystemDateTime(-1);			
			expCurrentDateTime="Last ran by Auto "+ expCurrentDate;			
			report.reportInfo("system current date time: "+expCurrentDateTime);
			if(actCurrentDateTime.contains(expCurrentDateTime))
			{
				report.reportPass("Verified last run by date and time");
			}else{
				report.reportFail("Failed to verify last run by date and time",true);
			}
			clickOnIdentityPanel();
			String fullPanelCurrentDate = webActions.waitAndGetText(txt_IdentityFullPanelLastRunBy, "LastRunDateTime");
			fullPanelCurrentDateTime=fullPanelCurrentDate.replace(",", "");			
			report.reportInfo("Dsiplayed last run date from application: "+actCurrentDateTime);

			if(fullPanelCurrentDateTime.contains(expCurrentDateTime))
			{
				report.reportPass("Verified last run by date and time in identity full panel");
			}else{
				report.reportFail("Failed to verify last run by date and time in identity full panel");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyVerificationResponse(DataTable testdata){
		try {
			ArrayList<String> actualData =new ArrayList<String>();
			ArrayList<String> expData=new ArrayList<>(testdata.asList());			
			webActions.waitForPageLoaded();
			actualData.add(webActions.getText(lbl_IdentityFullPanelAddressSectionName, "AddressSectionName"));
			actualData.add(webActions.getText(lbl_IdentityFullPanelVerificationResponse, "VerificationResponse"));
			actualData.add(webActions.getText(lbl_IdentityFullPanelHistoricalAddress, "HistoricalAddress"));
			actualData.add(webActions.getText(lbl_IdentityFullPanelOtherPhones, "OtherPhoneNumbers"));
			ArrayList<String> address=webActions.getDatafromWebTable(lbl_IdentityFullPanelResponse);
			actualData.addAll(address);
			report.reportInfo("Expected information :"+ expData);
			report.reportInfo("Actual information :"+ actualData);
			ArrayList<String>unmatchedInformation=webActions.getUmatchedInArrayComparision(actualData, expData);
			if(unmatchedInformation.size()==0){
				report.reportPass("Verified successfully identity verifier information");
			}
			else{
				throw new Exception("Fail to verify identity verifier information and unmatched data is: "+unmatchedInformation);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyIdentityVerifierMessage(String panel,String mesg){
		String actMsg="";
		try {
			webActions.waitForPageLoaded();		
			report.reportInfo("Expected short panel info: "+mesg);

			if(panel.contentEquals("Short Panel")){
				actMsg=webActions.getText(txt_IdentityVerifierShortPanelMessage, "msg");
				report.reportInfo("Displayed Short Panel message: "+actMsg);
			}
			else if(panel.contentEquals("Full Panel")){
				actMsg=webActions.getText(txt_IdentityVerifierFullPanelMessage, "msg");
				report.reportInfo("Displayed Full Panel message: "+actMsg);
			}
			else if(panel.contentEquals("FullPanelDataElements")){
				actMsg=webActions.getText(txt_IdentityVerifierFullPanelDataElements, "msg");
				report.reportInfo("Displayed Full Panel data elements information: "+actMsg);
			}
			else if(panel.contentEquals("ShortPanelDataElements")){
				actMsg=webActions.getText(txt_IdentityVerifierShortPanelDataElements, "msg");
				report.reportInfo("Displayed Full Panel data elements information: "+actMsg);
			}

			if(actMsg.contentEquals(mesg)){
				report.reportPass("Verified successfully" +panel+  " message");
			}
			else{
				report.reportFail("Fail to verify postal" +panel+ " message and unmatched data is: "+actMsg);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnIdentityNewRequestBtn(){
		try {
			webActions.waitForVisibility(btn_IdentityPanelNewRequest, "New");
			webActions.click(btn_IdentityPanelNewRequest, "NewRequestButton");
			webActions.waitForVisibilityOfAllElements(lbl_IdentityPanelRequestWindowFields, "IdentityNewrequestPage");
			report.reportInfo("Navigated to the Identity New Request Page");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyIdetifierFiedsInNewRequestWindow(String scenario, DataTable testData) {
		try {
			ArrayList<String> actualData = new ArrayList<>();
			ArrayList<String> expectedData = new ArrayList<>(testData.asList());
			if(scenario.contentEquals("fields")){
				report.reportInfo("Expected fields from identity verifier new request window "+expectedData);
				webActions.waitForPageLoaded();
				actualData=webActions.getDatafromWebTable(lbl_IdentityPanelRequestWindowFields);
				report.reportInfo("Displayed fields in new request window: "+actualData);
			}		
			else if (scenario.contentEquals("mandatory")){
				report.reportInfo("Expected mandatory fields in new request window "+expectedData);	

				int fieldsSize=lbl_IdentityVerifierNewRequestWindowFields.size();							
				for( int i=4;i<=fieldsSize;i++){
					String xpath1 = "(//ejs-textbox[1]/span/input[1])";
					String xpath2 = xpath1+"["+i+"]";
					WebElement field=driver.findElement(By.xpath(xpath2));					
					webActions.clickAction(field, "fields");
					Thread.sleep(1000);
					webActions.clearValue(field, "fields");
					webActions.waitForPageLoaded();
				}	

				actualData=webActions.getDatafromWebTable(lbl_IdentityVerifierNewRequestWindowMandatory);
				report.reportInfo("Displayed mandatory fields from new request window: "+actualData);
			}
			ArrayList<String>unmatchedFields=webActions.getUmatchedInArrayComparision(actualData, expectedData);
			if(unmatchedFields.size()==0){
				report.reportPass("Verified "+scenario+" from Identity new request window successfully");
			}
			else{
				report.reportFail("Fail to verify "+scenario+" from Identity new request window and unmatched "+scenario+" are: "+unmatchedFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void cancelAndCrossNavigation(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_IdentityNewRequestWindowCancel, "NewRequestCancelBtn");
			webActions.waitForVisibility(lbl_IdentityNoDataFound, "PanelInformation");
			webActions.assertDisplayed(btn_IdentityHistory, "HostoryButton");
			report.reportPass("History button is displayed");
			clickOnIdentityNewRequestBtn();
			webActions.click(btn_IdentityNewRequestWindowCross, "NewRequestCrossOprtion");
			webActions.waitForVisibility(lbl_IdentityNoDataFound, "PanelText");
			webActions.assertDisplayed(btn_IdentityHistory, "HostoryButton");
			report.reportPass("History button is displayed");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyIdentityMsgForManualRun(String panel,String message){
		String manualMessage="";
		try {
			webActions.waitForPageLoaded();

			if("Short".contentEquals(panel)){
				manualMessage=webActions.getText(txt_IdentityShortManualMsg, "ShortPanel");
			}
			else if("Full".contentEquals(panel)){
				manualMessage=webActions.getText(txt_IdentityFullManualMsg, "FullPanel");
			}
			if(message.contentEquals(manualMessage)){
				report.reportPass("Verified manual request message in" +panel+ "panel");
			}
			else{
				report.reportFail("Fail to verify manual request message in" +panel+ "panel");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnIdentityPanelManual(){
		try {
			webActions.waitForVisibility(txt_IdentityVerifierPanelTitle, "Identity");
			webActions.click(txt_IdentityVerifierPanelTitle, "IdentityPanel");
			try{
				webActions.waitForVisibility(txt_IdentityFullManualMsg, "PanelLable");
				Thread.sleep(1000);
			}
			catch(Exception e){
				webActions.waitForVisibility(lbl_IdentityFullPanelHistoricalAddress, "PanelLable");
			}
			report.reportInfo("Navigated to the Identity verifier Full Page");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnRequest(){
		try {
			webActions.waitForPageLoaded();			
			webActions.click(btn_IdentityNewRequestWindow, "SendRequest");
			report.reportInfo("Clicked on Send Request button");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void waitforPaymentFacilitatorPanel() throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(lbl_NoPayments, "No Payments Error Message");
		} catch (Exception e) {
			webActions.waitForVisibility(tbl_PaymentFacilitatorPanel, "Payment Facilitator Panel");
		}
	}
	public void verifyManualLastRunByInPostalPanel(){
		String actCurrentDateTime = null; String expCurrentDateTime = null; String increasedCurrentDateTime = null;String fullPanelCurrentDateTime = null;
		try {						
			String expCurrentDate = webActions.getCurrentSystemDateTime();
			String increasedTime=webActions.getIncreasedCurrentSystemDateTime(-1);
			expCurrentDateTime="Last ran by KesiReddy Yenugu "+ expCurrentDate;
			increasedCurrentDateTime="Last ran by KesiReddy Yenugu "+ increasedTime;
			report.reportInfo("system current date time: "+expCurrentDateTime);
			webActions.waitForVisibility(lbl_IdentityFullPanelLastRunBy, "LastRunDateTime");		
			String fullPanelCurrentDate = webActions.waitAndGetText(lbl_IdentityFullPanelLastRunBy, "LastRunDateTime");
			fullPanelCurrentDateTime=fullPanelCurrentDate.replace(",", "");			
			report.reportInfo("Dsiplayed last run date from application: "+fullPanelCurrentDateTime);

			if(fullPanelCurrentDateTime.contains(expCurrentDateTime)||fullPanelCurrentDateTime.contains(increasedCurrentDateTime))
			{
				report.reportPass("Verified last run by date and time in postal full panel");
			}else{
				report.reportFail("Failed to verify last run by date and time in postal full panel",true);
			}
			webActions.click(lnk_AccountNumber, "AccountNumber");
			webActions.waitForPageLoaded();			
			webActions.waitForVisibilityOfAllElements(lbl_DigitalDocMangerPanel, "DigitalDocs");			
			waitforPaymentFacilitatorPanel();
			report.reportInfo("Navigated to the Patient Visit Summary page");			
			webActions.waitForVisibilityOfAllElements(lbl_DataInAllDataPanel, "DataInAllData");
			webActions.waitForVisibilityOfAllElements(lbl_VisitSummaryData, "SummaryData");
			webActions.waitForVisibility(lbl_IdentityShortPanelLastRunBy, "LastRunDateTime");
			String actCurrentDate = webActions.waitAndGetText(lbl_IdentityShortPanelLastRunBy, "LastRunDateTime");
			actCurrentDateTime=actCurrentDate.replace(",", "");			
			report.reportInfo("Dsiplayed last run date from application: "+actCurrentDateTime);			

			if(actCurrentDateTime.contains(expCurrentDateTime)||actCurrentDateTime.contains(increasedCurrentDateTime))
			{
				report.reportPass("Verified last run by date and time in short panel");
			}else{
				report.reportFail("Failed to verify last run by date and time in short panel");
			}


		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void navigateToVisitMainPage(){
		try {
			webActions.click(lnk_AccountNumber, "AccountNumber");
			webActions.waitForPageLoaded();			
			webActions.waitForVisibilityOfAllElements(lbl_DigitalDocMangerPanel, "DigitalDocs");			
			waitforPaymentFacilitatorPanel();
			report.reportInfo("Navigated to the Patient Visit Summary page");			
			webActions.waitForVisibilityOfAllElements(lbl_DataInAllDataPanel, "DataInAllData");
			webActions.waitForVisibilityOfAllElements(lbl_VisitSummaryData, "SummaryData");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void enterAddressInIdentityWindow(DataTable testData){
		try {
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_IdentityPanelNewRequestLastName, "LastName");
			webActions.clearValue(txt_IdentityPanelNewRequestLastName, "LastName");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_IdentityPanelNewRequestLastName,webActions.getDatafromMap(testData,"LastName"), "LastName");			
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_IdentityPanelNewRequestFirstName, "FirstName");
			webActions.clearValue(txt_IdentityPanelNewRequestFirstName, "FirstName");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_IdentityPanelNewRequestFirstName,webActions.getDatafromMap(testData,"FirstName"), "FirstName");			
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_IdentityPanelNewRequestSSN, "SSN");
			webActions.clearValue(txt_IdentityPanelNewRequestSSN, "SSN");
			Thread.sleep(1000);
			webActions.clickAction(txt_IdentityPanelNewRequestSSN, "SSN");
			webActions.enterValuesfromKeyBoard(txt_IdentityPanelNewRequestSSN,webActions.getDatafromMap(testData,"SSN"), "SSN");			
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_IdentityPanelNewRequestStreetAddress, "Street");
			webActions.clearValue(txt_IdentityPanelNewRequestStreetAddress, "Street");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_IdentityPanelNewRequestStreetAddress,webActions.getDatafromMap(testData,"StreetAddress"), "Street");			
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_IdentityPanelNewRequestCity, "City");
			webActions.clearValue(txt_IdentityPanelNewRequestCity, "City");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_IdentityPanelNewRequestCity,webActions.getDatafromMap(testData,"City"), "City");
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_IdentityPanelNewRequestState, "State");
			webActions.clearValue(txt_IdentityPanelNewRequestState, "State");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_IdentityPanelNewRequestState,webActions.getDatafromMap(testData,"State"), "State");
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_IdentityPanelNewRequestZipCode, "ZipCode");
			webActions.clearValue(txt_IdentityPanelNewRequestZipCode, "ZipCode");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_IdentityPanelNewRequestZipCode,webActions.getDatafromMap(testData,"ZipCode"), "ZipCode");
			report.reportPass("Enter the data in Identity request window");

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyHistoricalIdentityTitle(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_IdentityFullPanelHistory, "History");
			Thread.sleep(2000);
			//webActions.waitForVisibility(btn_HistoryCancel, "Cancel");		
			webActions.click(btn_HistoryRecordSelect, "RecordRadio");
			webActions.waitForPageLoaded();
			webActions.click(btn_HistorySelect, "Select");
			webActions.waitForVisibility(lbl_HistoricalMessage, "HistoricalPostalMsg");
			Thread.sleep(1000);
			String actHistoricalMsg=webActions.getText(lbl_HistoricalMessage, "HistoricalPostalMsg");
			report.reportInfo("Displayed historical title: " + actHistoricalMsg);
			if("Historical Identity Verifier".contentEquals(actHistoricalMsg)){
				report.reportPass("Verified Historical confirmation message in postal full panel");
			}
			else{
				report.reportFail("Failed to verify historcial confirmation message and actual displayed msg : " + actHistoricalMsg,true );
			}	

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickOnCurrentRequest(){
		try {
			webActions.waitForPageLoaded();		
			webActions.clickAction(btn_CurrentRequest, "CurrentRequest");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_IdentityFullPanelVerificationResponse, "Verification");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyHistoricalAddress(DataTable testdata){
		try {

			ArrayList<String> actualData =new ArrayList<String>();
			ArrayList<String> actualData1 =new ArrayList<String>();
			ArrayList<String> actualData2 =new ArrayList<String>();
			ArrayList<String> expData=new ArrayList<>(testdata.asList());			
			webActions.waitForPageLoaded();
			actualData1=webActions.getDatafromWebTable(lbl_IdentityHistoricalAddress);		
			actualData2.add(webActions.getText(lbl_IdentityHistoricalAddressCity, "City"));
			actualData2.add(webActions.getText(lbl_IdentityHistoricalAddressState, "State"));
			actualData2.add(webActions.getText(lbl_IdentityHistoricalAddressZip, "Zip"));
			actualData.addAll(actualData1);
			actualData.addAll(actualData2);

			report.reportInfo("Expected information :"+ expData);
			report.reportInfo("Actual information :"+ actualData);
			ArrayList<String>unmatchedInformation=webActions.getUmatchedInArrayComparision(actualData, expData);
			if(unmatchedInformation.size()==0){
				report.reportPass("Verified successfully identity verifier historical address information");
			}
			else{
				throw new Exception("Fail to verify identity verifier historical address and unmatched data is: "+unmatchedInformation);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
