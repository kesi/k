package com.ipas.hf.web.pages.ipasPages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.web.pages.BasePage;

public class HomePage extends BasePage {


	@FindBy(xpath = "//a[contains(text(),'Account Search')]")
	private WebElement lnk_AccounSearch;

	@FindBy(xpath="//table[@class='e-table']//thead/tr")
	private WebElement lbl_Headers;

	@FindBy(linkText = "Service Tracker")
	private WebElement lnk_ServiceTrackerh;

	@FindBy(xpath = "//div[@class='dashboard-wrapper']/div/div/div")
	private WebElement lbl_DashboardWrapper;

	@FindBy(xpath="//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']")
	private WebElement lbl_Headers_ServiceTracker;

	@FindBy(linkText = "Maintenance")
	private WebElement lnk_Maintenance1;

	/*@FindBy(xpath="//ejs-dashboardlayout[@id='defaultLayout']/div[3]")
	private WebElement tbl_defaultLayout;*/

	@FindBy(xpath="//ejs-dashboardlayout[@id='defaultLayout']/div/ipas-maintenance-panel/ejs-accordion/div/div/div")
	private WebElement tbl_defaultLayout;
	
	@FindBy(xpath="//a[contains(text(),'Maintenance')]")
	private WebElement lnk_Maintenance;
	
	@FindBy(xpath="//div[@class='emptyinfo']")
	private WebElement lbl_NoDataMsg;
	
	@FindBy(xpath="//a[contains(text(),'Worklists')]")
	private WebElement lnk_WorkList;
	
	@FindBy(xpath="(//ejs-grid//tbody)[2]/tr")
	private WebElement lbl_AAGridData;
	
	@FindBy(xpath="(//ejs-grid//tbody)[2]/tr[1]/td[2]/div/a")
	private WebElement tr_GridData;

	public HomePage() {
		PageFactory.initElements(driver, this);
	}


	public void navigateToAccountSearch(){
		try {
			webActions.waitForVisibility(lbl_DashboardWrapper, "HomePage");
			webActions.waitForVisibility(lnk_AccounSearch,"AccountSearch");
			webActions.click(lnk_AccounSearch, "AccountSearch");
			webActions.waitForPageLoaded();
			try {
				webActions.waitForPageLoaded();
				//webActions.waitForVisibility(lbl_Headers, "Headers in Account Search");
				webActions.waitForVisibility(tr_GridData, "Grid Row", 50);
				webActions.waitForPageLoaded();
			} catch (Exception e) {
				webActions.waitForPageLoaded();
			}
			report.reportPass("Clicked on Account Search link and navigated to the Account Search Page Successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());	
		}
	}


	public void navigateToServiceTracker(){
		try {
			webActions.waitUntilisDisplayed(lbl_DashboardWrapper, "Dashboard Wrapper");
			webActions.waitAndClick(lnk_ServiceTrackerh, "Service Tracker");
			webActions.waitForPageLoaded();
			try {
				webActions.waitUntilisDisplayed(lbl_Headers_ServiceTracker, "Service Tracker Headers");
			} catch (Exception e) {
			}
			report.reportPass("Clicked on Service Tracker link and navigated to the Service Tracker Page Successfully");
		} catch (Exception e) {
			report.reportFail(e.toString());
		}
	}

	public void navigateToMaintenance(){
		try {
			webActions.waitForVisibility(lbl_DashboardWrapper, "HomePage");
			Thread.sleep(5000);
			webActions.click(lnk_Maintenance, "Maintenance");
			webActions.waitForPageLoaded();
			try {
				webActions.waitUntilisDisplayed(tbl_defaultLayout, "Default Layout");
			} catch (Exception e) {
			}
			report.reportPass("Clicked on Maintenance link and navigated to the Maintenance Page Successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());	
		}
	}
	public void navigateToWorList(){
		try {
			webActions.waitForVisibility(lbl_DashboardWrapper, "HomePage");			
			webActions.click(lnk_WorkList, "Worklist");
			webActions.waitForPageLoaded();
			try {
				Thread.sleep(5000);
				webActions.waitUntilisDisplayed(lbl_AAGridData, "Default grid");
				report.reportPass("Clicked on worklist link and navigated to the worklist Page Successfully");
			} catch (Exception e) {
			}
			
		} catch (Exception e) {
			report.reportFail(e.getMessage());	
		}
	}


	public void navigateToAccountSearchFromOtherPages(){
		try {			
			webActions.waitForVisibility(lnk_AccounSearch,"AccountSearch");
			webActions.click(lnk_AccounSearch, "AccountSearch");
			webActions.waitForPageLoaded();
			try {
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(lbl_Headers, "Headers in Account Search");
			} catch (Exception e) {
				webActions.waitForPageLoaded();
				//webActions.waitForVisibility(lbl_NoDataMsg,"SearchResults");
			}
			report.reportPass("Clicked on Account Search link and navigated to the Account Search Page Successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());	
		}
	}
	public void navigateToMaintenanceFromOtherPages(){
		try {			
			webActions.click(lnk_Maintenance, "Maintenance");
			webActions.waitForPageLoaded();
			try {
				webActions.waitUntilisDisplayed(tbl_defaultLayout, "Default Layout");
			} catch (Exception e) {
			}
			report.reportPass("Clicked on Maintenance link and navigated to the Maintenance Page Successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());	
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(lnk_AccounSearch);
	}

}
