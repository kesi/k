package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.ViewTenantsPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class ViewTenantsSteps {

	ViewTenantsPage viewTenant=new ViewTenantsPage();
	
	@Then("Verify the display of field names")
	public void verify_the_display_of_field_names(DataTable labelNames) {
		viewTenant.verifyFieldNamesa(labelNames);
	}

	@Then("Verify the default values and placeholders")
	public void verify_the_default_values_and_placeholders(DataTable testData) {
		viewTenant.verifyPlaceholdersandDefaultValues(testData);
	}
	
	@Then("Verify the Tenant results grid header names")
	public void verify_the_Tenant_results_grid_header_names(DataTable headerNames) {
		viewTenant.verifyHeaderNames(headerNames);
	}
	
	@Then("Verify the Action Icons for all tenant List")
	public void verify_the_Action_Icons_for_all_tenant_List(DataTable testData) {
		viewTenant.verifyActionIcons(testData);
	}
	
	@Then("Verify the search functionality with {string} and test data as {string}")
	public void verify_the_search_functionality_with_and_test_data_as(String colunmName, String testData) {
		viewTenant.serachDatainTenantsGrid(colunmName, testData);
	}
	
	@Then("Verify that {string} Displays as Hyperlink")
	public void verify_that_Displays_as_Hyperlink(String colunmName) {
		viewTenant.verifyTenantNameDisplaysasHyperlink(colunmName);
	}

}
