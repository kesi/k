package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.PatientVisitSummaryAllDataPanelPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class PatientVisitSummaryAllDataPanelSteps {
	PatientVisitSummaryAllDataPanelPage visitSummary=new PatientVisitSummaryAllDataPanelPage();	

	@Then("Get the value from response body as {string} and verify the displayed breadcrumb based on followed by Patient Visit number as {string}")
	public void get_the_value_from_response_body_as_and_verify_the_displayed_breadcrumb_based_on_followed_by_Patient_Visit_number_as(String visitId, String navigationName) {
		visitSummary.verifyPatientsummaryBreadcrumb(visitId,navigationName);
	}
	@Then("Get the value from response body and get value of {string} and click on visit number")
	public void get_the_value_from_response_body_and_get_value_of_and_click_on_visit_number(String visitId) {
		visitSummary.getVisitNumberFromResponseAndClickOnAccountNumber(visitId);	 
	}	
	@Then("Verify the patient visit summary information fileds")
	public void verify_the_patient_visit_summary_information_fileds(DataTable summaryfields) {
		visitSummary.verifyVisitSUmmaryFields(summaryfields);
	}	
	@Then("Verify the Patient visit summary information as {string}")
	public void verify_the_Patient_visit_summary_information_as(String panelName) {
		visitSummary.verifyVisitSummaryInfo(panelName);
	}
	@Then("Verify the display of sections in AllData Panel")
	public void verify_the_display_of_sections_in_AllData_Panel(DataTable patientInfoSections) {
		visitSummary.verifyPatinetInfoSectionInAllDataPanel(patientInfoSections);
	}
	@Then("Verify the display of label names from each section of All Data Panel")
	public void verify_the_display_of_label_names_from_each_section_of_All_Data_Panel(DataTable patientInfoSectionLabels) {
		visitSummary.verifySectionLabelsInAllDataPanel(patientInfoSectionLabels);
	}
	@Then("Verify the display of label data from each section of All Data Panel as {string}")
	public void verify_the_display_of_label_data_from_each_section_of_All_Data_Panel_as(String sectionName) {
		visitSummary.verifyAllDataPanelInfo(sectionName);
	}
	@Then("Verify expand and collapse of the All Data Panel")
	public void verify_expand_and_collapse_of_the_All_Data_Panel() throws Exception {
		visitSummary.verifyExpandandCollapsethePanel();
	}
	@Then("Verify the display of transaction history button at top right side of the page")
	public void verify_the_display_of_transaction_history_button_at_top_right_side_of_the_page() {
		visitSummary.verifyfields();
	}
	@Then("Click on Transaction History button")
	public void click_on_Transaction_History_button() {
		visitSummary.clickOnTransHistory();
	}
	@Then("Click on Transaction History button and Verify the window title as {string}")
	public void click_on_Transaction_History_button_and_Verify_the_window_title_as(String title) {
		visitSummary.verifyTransactionHistoryTitle(title);
	}
	@Then("Click on Transaction History button and Verify the column names in transaction history window")
	public void click_on_Transaction_History_button_and_Verify_the_column_names_in_transaction_history_window(DataTable tranHistoryColumns) {
		visitSummary.verifyColumnsInTransHistory(tranHistoryColumns);
	}
	@Then("Click on Transaction History button and click on cross option from window")
	public void click_on_Transaction_History_button_and_click_on_cross_option_from_window() {
		visitSummary.clickCrossInTransWindow();
	}

	@Then("Click on transcation history button and verify the visit {string}")
	public void click_on_transcation_history_button_and_verify_the_visit(String data) {
		visitSummary.verifyTransactionHistoryEventType(data);
	}

}