package com.ipas.hf.web.steps;

import java.io.IOException;
import java.util.ArrayList;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.azureutilities.CosmosDbDataValidation;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.ipasPages.AddPatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.ModuleStatusServiceTrackerPage;
import com.ipas.hf.web.pages.ipasPages.PatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.SignalRPage;
import com.ipas.hf.web.pages.ipasPages.SimpleSearchPage;
import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class AddPatientVisitSteps {

	AddPatientVisitPage addpatient          =new AddPatientVisitPage();
	SimpleSearchPage search                 =new SimpleSearchPage();
	PatientVisitPage visit                  =new PatientVisitPage();
	SignalRPage signalR                     =new SignalRPage();
	ModuleStatusServiceTrackerPage modStatus=new ModuleStatusServiceTrackerPage();
	Login login                             =new Login();
	RestActions rest                        =new RestActions();


	@Then("Navigate to module as {string} in Add Patient")
	public void Navigate_to_AddPatient_module(String module) throws Exception {
		if("AccountSearch".contentEquals(module))
		{
			search.accountsearchtab();
		}
		else if("ServiceTracker".contentEquals(module))
		{
			visit.serviceTrackerPageValidation();
		}
		addpatient.navigateToAddPatient();
	}

	@Then("Navigate to Account Search >> Add Patient")
	public void Navigate_to_AddPatient_AcctSearch() {
		search.accountsearchtab();
		addpatient.navigateToAddPatient();
	}

	@Then("Navigate to Service Tracker >> Add Patient")
	public void Navigate_to_AddPatient_ServiceTracker() throws Exception {
		visit.serviceTrackerPageValidation();
		addpatient.navigateToAddPatient();
	}

	@Then("Verify the display of BreadCrumb in Account Search")
	public void Verify_Account_Search_BreadCrumb() {
		addpatient.verifyAccountSearchBreadCrumb1();
	}

	@Then("Verify the display of BreadCrumb in Service Tracker")
	public void Verify_Service_Tracker_BreadCrumb() {
		addpatient.verifyServiceTrackerBreadCrumb();
	}

	@Then("Verify the fields in the Patient Information section")
	public void Verify_the_fields_in_Patient_Information_section(DataTable fieldNames) {
		addpatient.VerifyfieldsPatientVisitInfo(fieldNames);
	}

	@Then("Verify the Mandatory fields in Add Patient Visit")
	public void Verify_the_mandatory_fields_in_add_patient_visit(DataTable fieldNames) {
		addpatient.VerifyMandatoryfieldsPatientInfo(fieldNames);
	}

	@Then("Verify the Mandatory Validation in Add Patient Visit")
	public void Verify_the_mandatory_Validation_in_add_patient_visit() {
		addpatient.VerifyMandatoryValidationMsg();
	}

	@Then("Verify the fields in the Guarantor Information section")
	public void Verify_the_fields_in_Guarantor_Information_section(DataTable fieldNames) {
		addpatient.VerifyfieldsGuarantorInfo(fieldNames);
	}

	@Then("Verify the fields in the Insurance Information section")
	public void Verify_the_fields_in_Insurance_Information_section(DataTable fieldNames) {
		addpatient.VerifyfieldsInsuranceInfo(fieldNames);
	}

	@Then("Verify the validation messages when user enter less than minimum character as {string}")
	public void Verify_the_validation_messages_when_user_enter_less_than_minimum_character(String length,DataTable  validationMessages) {
		int len=Integer.parseInt(length);
		String testData=rest.randomString(len);
		addpatient.verifyValidationMessageMinimumAndMaximum(length,testData,validationMessages);
	}

	@Then("Verify the validation messages if user enter more than maximum characters as {string}")
	public void Verify_the_validation_messages_if_user_enter_more_than_maximum_characters(String length,DataTable  validationMessages) {
		int len=Integer.parseInt(length); 
		String testData=rest.randomString(len);
		addpatient.verifyValidationMessageMinimumAndMaximum(length,testData,validationMessages);
	}

	@Then("Verify the validation messages if numerics entered in Text fields as {string}")
	public void Verify_the_validation_messages_if_numericss_entered_into_text_fields(String length,DataTable  validationMessages) {
		int len=Integer.parseInt(length); 
		String testData=rest.randomNumber(len);
		addpatient.verifyValidationMessageNumerics(length,testData,validationMessages);
	}

	@Then("Verify the adding of new record in Add Patient as {string} and as {string} and verify the search results with columnName as {string}")
	public void Verify_the_adding_of_new_record_in_Add_Patient(String length,String length1,String columnName,DataTable columnNames) {
		int len=Integer.parseInt(length); 
		int len1=Integer.parseInt(length1); 
		String lastname=rest.randomString(len1);
		String firstname=rest.randomString(len);
		String patientName=firstname+" "+lastname;
		addpatient.verifyAddPatientAllFields(lastname,firstname);
		search.accountsearchtab();
		search.columnSelection(columnNames,true);
		search.searchValidation(patientName,columnName);
		String accountnumber=addpatient.verifyNavigationToAllDataPanel(patientName);		
		addpatient.notepadWrite("hello",accountnumber);

	}

	@Then("Verify the adding of new record in Add Patient as {string} and as {string}")
	public void Verify_the_adding_of_new_record_in_Add_Patient(String length,String length1) {
		int len=Integer.parseInt(length); 
		int len1=Integer.parseInt(length1); 
		String lastname=rest.randomString(len1);
		String firstname=rest.randomString(len);
		addpatient.verifyAddPatient(lastname,firstname);
	}

	@Then("Verify the manual visit card is displayed on service tracker board")
	public void Verify_the_manual_visit_card_in_service_tracker() throws Exception {
		String accountnumber=addpatient.notepadRead("hello");	
		visit.serviceTrackerPageValidation();
		modStatus.serviceTrackerSimpleSearch(accountnumber);
		signalR.VerifyVisitCardisDisplayed(accountnumber);
	}

	@Then("Verify the new manual visit card in payment facilitator")
	public void Verify_the_new_manual_visit_card_in_payment_facilitator() throws IOException {
		String accountnumber=addpatient.notepadRead("hello");
		addpatient.verifyVisitCardPaymentModule(accountnumber);
	}

	@Then("Verify the new manual visit card in digital documents")
	public void Verify_the_new_manual_visit_card_in_digital_documents(DataTable labels) throws Exception {
		String accountnumber=addpatient.notepadRead("hello");
		addpatient.verifyLabelNamesinDigitalDOcumentsMangerPage(labels,accountnumber);
	}

	@Then("Verify the default values or placeholders in add patient")
	public void Verify_the_default_values_or_placeholders_in_add_patient() {
		addpatient.verifyDefaultValues();
	}

	@Then("Verify the similar accounts section in add patient as {string} and as {string}")
	public void Verify_the_similar_accounts_section_in_add_patient(String length,String length1) {
		addpatient.verifySimilarAccounts(length,length1);
	}

	@Then("Verify the cancel button in add patient in module as {string}")
	public void Verify_the_cancel_button_in_add_patient(String module) {
		addpatient.verifyCancelButton(module);
	}

	@Then("Verify the placeholders in patient information section")
	public void Verify_the_placeholders_in_patient_information(DataTable placeholders) {
		addpatient.verifyPlaceholdersforPatientInfo(placeholders);
	}

	@Then("Verify the placeholders in Guarantor section")
	public void Verify_the_placeholders_in_guarantor(DataTable placeholders) {
		addpatient.verifyPlaceholdersforGuarantor(placeholders);
	}

	@Then("Verify the placeholders for rest of fields in Add patient")
	public void Verify_the_placeholders_for_rest_of_fields_in_Add_patient(DataTable placeholders) {
		addpatient.verifyPlaceholdersforRest(placeholders);
	}

	@Then("Verify navigation to all data panel from service tracker")
	public void Verify_navigation_to_all_data_panel_from_service_tracker() throws IOException {
		String accountnumber=addpatient.notepadRead("hello");
		addpatient.verifyNavigationToAllDataPanel(accountnumber);
	}

	@Then("Verify navigation to All Data Panel from account search")
	public void Verify_navigation_to_service_tracker_panel() throws IOException {
		String accountnumber=addpatient.notepadRead("hello");
		login.simpleSearch(accountnumber);
		addpatient.AllDataPanel(accountnumber);
	}

	@Then("Verify the validation messages if numerics entered as {string} are less than 10 digits")
	public void Verify_the_validation_messages_if_numerics_entered_are_less_than_10_digits(String length,DataTable  validationMessages) {		 
		addpatient.verifyValidationMessagePhoneNumbers(length,"333-333",validationMessages);
	}

	@Then("Verify the adding of new patient manually")
	public void Verify_the_adding_of_new_patient_manually(DataTable testData) {
		String lastname=rest.randomString(5);
		String firstname=rest.randomString(5);
		String patientName=firstname+" "+lastname;
		addpatient.notepadWrite("patientData",patientName);
		addpatient.addNewPatientManually(testData,lastname,firstname);
	}

	@Then("Verify the manual visit card in accountsearch with columnname as {string}")
	public void verify_the_manual_visit_card_in_accountsearch_with_columnname_as(String columnName,DataTable columnNames) throws IOException {
		String patientName=addpatient.notepadRead("patientData");
		search.accountsearchtab();
		search.columnSelection(columnNames,true);
		search.searchValidation(patientName.trim() , columnName);
		String accountnumber=addpatient.verifyNavigationToAllDataPanel(patientName.trim() );		
		addpatient.notepadWrite("hello",accountnumber);
	}

	@Then("Enter patient details and select the Relation To Patient as {string}")
	public void enter_patient_details_and_select_the_Relation_To_Patient_as(String relation, DataTable testData) {
		addpatient.verifyGuaratorDetails(relation, testData);
	}

	@Then("Verify the display of Similar accounts on selecting the patient from similar patients")
	public void verify_the_display_of_Similar_accounts_on_selecting_the_patient_from_similar_patients() {
		addpatient.verifySimilarAccountsForExistingPatient();
	}
	@Then("Add a new patient visit")
	public void add_a_new_patient_visit(DataTable testData) {
		ArrayList<String> patientData=new ArrayList<>();
		String lastname=rest.randomString(4);
		String firstname=rest.randomString(4);
		patientData.add(lastname);
		patientData.add(firstname);
		CosmosDbDataValidation.notepadWrite("hello", patientData);
		addpatient.addNewPatientManually(testData,lastname,firstname);
	}

}
