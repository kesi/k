package com.ipas.hf.web.pages.ipasPages;

import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

import org.openqa.selenium.support.ui.ExpectedCondition;
import java.util.ArrayList;
import java.util.List;

import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.web.pages.BasePage;

public class SimpleSearchPage extends BasePage{


	public SimpleSearchPage() {
		PageFactory.initElements(driver, this);
	}

	public String visitIdvalue;
	public String patientVisitID;
	public String patientAppointmentID;
	public String patientName;

	@FindBy(xpath = "//a[contains(text(),'Account Search')]")
	private WebElement lnk_accountSearch;

	@FindBy(xpath="//a[text()='Account Search']")
	private WebElement tb_search;

	@FindBy(xpath ="//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_searchBox;

	@FindBy(xpath="//ul[contains(@class,'p-autocomplete-items')]/li[1]")
	private WebElement drpdwn_search;

	@FindBy(xpath="//ul[contains(@id,'pr_id_')]")
	private WebElement drpdwn_searchItem;

	@FindBy(xpath="(//table[@class='e-table'])[2]//tr[1]//td[2]")
	private WebElement drpdwn_searchResults;

	@FindBy(xpath="//button[text()='Columns']")
	private WebElement btn_Columns;

	@FindBy(xpath="//table[@id='asgrid_content_table']")
	private WebElement grid_SearchContent;

	@FindBy(xpath = "//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_Search;

	@FindBy(xpath = "//div[@class='e-gridcontent']//tr[1]//td[2]//div[@class='boldtext ng-star-inserted']")
	private WebElement row_PatientName;

	@FindBy(xpath = "//li[@class='e-list-item e-level-1 e-checklist e-active']")
	private List<WebElement> columnName;

	@FindBy(xpath = "//tbody[@class='hscroll ng-star-inserted']/tr/td")
	private WebElement row_FirstPatient;

	@FindBy(xpath="//ul[@id='pr_id_1_list']/li[1]/span[1]/span")
	private WebElement icon_SearchResult;

	@FindBy(xpath="//tbody[@class='hscroll ng-star-inserted']/tr[1]/td[2]/div[1]")
	private WebElement lbl_PatientName;

	@FindBy(xpath="//ul[@id='pr_id_1_list']/li")
	private WebElement lbl_NoResultsarefound;

	@FindBy(xpath = "//div[@class='e-gridcontent e-lib e-droppable']//tr")
	private WebElement row_AllRecord;

	@FindBy(xpath="//div[@class='e-gridcontent e-lib e-droppable']//tr[1]/td")
	private WebElement row_First;

	@FindBy(xpath = "//div[@class='e-gridcontent e-lib e-droppable']//tr[1]//td[2]/div")
	private WebElement row_FirstRecord_2;

	@FindBy(xpath = "//span[@class='e-headertext'][contains(text(),'Patient')]")
	private WebElement lbl_Patient;

	@FindBy(xpath = "(//div[@class='e-content']//ul)[2]")
	private WebElement lst_ColumnBox;

	@FindBy(xpath = "//div[@id='panel']")
	private WebElement grid_Header;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody")
	private WebElement grid_Results;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody/tr/td")
	private WebElement lbl_GridRecords;
	Login logIn = new Login();


	public void accountsearchtab() {
		try {
			webActions.click(tb_search, "Account Search Tab");
			report.reportPass("Should Navigate to Account Search tab");
			webActions.waitForVisibility(txt_Search, "Search box");
			webActions.waitUntilisDisplayed(txt_searchBox,"Search Input Box");
			report.reportPass("Should Verify search Input Box");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_GridRecords,"Grid load");
			report.reportPass("Should wait until the Grid loads");
		} catch (Exception e) {
			report.reportFail("Failed to navigate to account search page: " + e);
		}
	}

	public void searchForLessThanThreeChar(String searchText) {
		try {
			webActions.waitForVisibility(tb_search,"Account Search Tab");
			webActions.waitForVisibility(txt_Search, "Search box");
			webActions.clearValue(txt_searchBox,"Search Text");
			report.reportPass("Clear Text :Validated clear option in Search field");
			webActions.sendKeys(txt_searchBox,searchText, "Search Text");
			report.reportPass("Entered Search Text in Search box");
			int searchTextLength=searchText.length();
			try {
				if(searchTextLength<3)
				{
					webActions.waitForElementToBeNotPresent(drpdwn_search,"Autocomplete Suggestions");
					report.reportPass("Should Not display Auto Complete Suggestions if search text less than 3 characters");
					webActions.clearValue(txt_searchBox,"Search Text");
					report.reportPass("Clear Text :Validated clear option in Search field");
				}
				else
				{
					report.reportInfo("Search text more than 2 characters");
				}
			} catch (Exception e1) {
				report.reportFail("Failed to find the length of search string due to: " + e1);
			}
		} catch (Exception e) {
			report.reportFail("Failed to navigate to account search page: " + e);
		}
	}

	public void checkColumns(DataTable columnNames){
		try{
			webActions.waitForVisibility(txt_searchBox,"Search Box",120);
			List<String> expColNames = columnNames.asList(String.class);
			report.reportInfo("Column Names to be selected are : "+expColNames);
			webActions.waitForVisibility(btn_Columns,"Columns Dropdown");
			webActions.click(btn_Columns,"Columns Dropdown");

		}catch(Exception e){

		}
	}

	public void columnSelection(DataTable columnNames,boolean select) {
		try{
			webActions.waitForVisibility(txt_searchBox,"Search Box",120);
			List<String> expColNameList = columnNames.asList(String.class);
			report.reportInfo("Column Names to be selected are : "+expColNameList);
			webActions.waitForVisibility(btn_Columns,"Columns Dropdown");
			webActions.click(btn_Columns,"Columns Dropdown");
			webActions.waitForVisibility(lst_ColumnBox,"Columns Dropdown");
			List<WebElement> options = lst_ColumnBox.findElements(By.tagName("li"));
			report.reportInfo("Total options in columns dropdown menu :"+options.size());
			for(int listcount = 0;listcount<expColNameList.size();listcount++){
				String expColName =expColNameList.get(listcount);
				options = lst_ColumnBox.findElements(By.tagName("li"));
				for(int i =0;i<options.size();i++){
					if(options.get(i).getText().equals(expColName)){
						String xpath1 = "(//span[text()='";
						String xpath2 = "'])[last()]";
						String xpath3 = xpath1+expColName+xpath2;
						String xpath4 = "//preceding::div[1]";
						String xpath5 = xpath3+xpath4;
						WebElement checkBox = driver.findElement(By.xpath(xpath5));
						WebElement checkBox1 = driver.findElement(By.xpath(xpath5));
						if(select==true)
						{
							if(checkBox1.getAttribute("aria-checked").equals("false"))
							{
								webActions.check(checkBox,expColName);
								report.reportPass("Should check the checkbox :" +expColName);
							}
							else
								report.reportInfo("Check box already checked "+expColName);	
							break;	
						}

						else if(select==false)
						{
							if(checkBox1.getAttribute("aria-checked").equals("true"))
							{
								webActions.check(checkBox,expColName);
								report.reportPass("Should uncheck the checkbox :" +expColName);
							}
							else
								report.reportInfo("Check box already unchecked "+expColName);	
							break;
						}
						webActions.click(btn_Columns,"Columns Dropdown");
					}
				}
			}
		}
		catch (Exception e) {
			report.reportFail(e.getMessage());
		}		
	}

	public ArrayList<String> getmatchedInArrayComparision(List<String> actData, List<String> expData) throws Exception
	{
		ArrayList<String> matchedArray = new ArrayList<String>();
		if(actData!=null && expData!=null &&actData.size()>0&&expData.size()>0 ){
			for(int data=0;data<actData.size();data++)
			{

				if(((actData.get(data)).contentEquals(expData.get(data))))
					matchedArray.add(actData.get(data));
			}
		}
		else{
			throw new Exception("Error in Array Sizes  matching");
		}
		return matchedArray;			
	}

	public void verifyResults(WebElement header,WebElement results,String fieldName,String searchedData)
	{
		try {
			Integer columnIndex = null;
			List<WebElement> rows_table = grid_Header.findElements(By.tagName("tr"));
			List<WebElement> columns=rows_table.get(0).findElements(By.tagName("th"));
			for(int cnum=0;cnum<columns.size();cnum++)
			{
				String columnName = (columns.get(cnum).getText());
				if(columnName.toUpperCase().contains(fieldName.toUpperCase())){
					columnIndex = cnum;
					break;
				}
			}
			List<WebElement> results_rows_table = grid_Results.findElements(By.tagName("tr"));
			int rowsCount = results_rows_table.size();
			for(int rnum=0;rnum<rowsCount;rnum++){
				List<WebElement> resultsColumns= results_rows_table.get(rnum).findElements(By.tagName("td"));
				List<WebElement> resultsData = (resultsColumns.get(columnIndex).findElements(By.tagName("div")));
				for(int i = 0;i<resultsData.size();i++){
					String text = resultsData.get(i).getText();
					if(text.contains(searchedData)){
						report.reportPass("Pass");
						break;
					}
				}
				if(resultsData.contains(searchedData)){
					report.reportPass("Pass");
				}
				else{
					report.reportPass("Fail");
					break;
				}
			}
		}
		catch (Exception e)
		{
			report.reportFail("Error to display search results matching the search criteria  " + e);
		}
	}

	public void searchValidation(String Identifier,String columnname)
	{
		try {
			webActions.waitForPageLoaded();
			webActions.waitForLoadingBarToAppear();
			report.reportInfo("Identifier is :"+Identifier);
			webActions.clearValue(txt_searchBox,"Search Text");
			webActions.sendKeys(txt_searchBox,Identifier, "Search Text");
			report.reportPass("Should enter the Search Attribute value "+Identifier+"in the Search box");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(drpdwn_searchItem,"Should wait until Drpdown Search Item list is displayed");
			List<WebElement> dropdownlist_values = drpdwn_searchItem.findElements(By.tagName("li"));
			for(int count=0;count<dropdownlist_values.size();count++)
			{
				String dropdownlist_values1=dropdownlist_values.get(count).getText();
				if(dropdownlist_values1.contains(Identifier))
				{
					webActions.click(drpdwn_search,"Element with Visit ID: "+Identifier);
					report.reportPass("Click on element with Visit ID: "+Identifier);
					webActions.waitForPageLoaded();
					webActions.waitForJSandJQueryToLoad();
					break;
				}

				else
				{
					report.reportFail("Failed to display matching record,Hence NO RESULTS FOUND VALIDATION MESSAGE");

				}
			}
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();

			ArrayList<String> dataFromGrid = webActions.getGridData(grid_Header, grid_Results,"Patient",columnname);

			ArrayList<String> returnUnmatched = webActions.isFullArrayMatchWithData(dataFromGrid,Identifier);
			if(returnUnmatched.size() == 0){
				report.reportPass("Successfully validated search results matching the search criteria :"+Identifier);
			}else{
				throw new Exception("Data verification failed, and unmatched data is: "+returnUnmatched);
			}
		}
		catch (Exception e)
		{
			report.reportFail("Error to display search results matching the search criteria  " + e.getMessage());
		}
	}


	public void maxLengthOfSearchInput(String length)
	{
		try {
			webActions.waitForVisibility(txt_Search, "Search box");
			if(webActions.getAttributeValue(txt_Search,"maxlength","search Input box max length").equals(length))
				report.reportPass("Displayed Maximum length of Input search input box as:  "+length);
			else
				report.reportFail("Fail to display the maximum length of the search input box :" +length);
		} catch (Exception e) {
			report.reportFail("Fail to display search input box :"+e);
		}
	}

	public void enterclearDatainSearch(String data){
		try {
			webActions.waitForVisibility(txt_Search, "Search box");
			webActions.sendKeys(txt_Search, data, "Search box");
			webActions.clearValue(txt_Search, "Search box");
			report.reportPass("Data entered and cleared in Search box successfully");
		} catch (Exception e) {
			report.reportFail("Fail to enter and clear data  in Search box");
		}
	}

	public void verifyHintText(String hintText){
		webActions.waitForVisibility(txt_Search, "Search box");
		String actHintText=webActions.getAttributeValue(txt_Search, "placeholder", "Search Box");
		if(hintText.contentEquals(actHintText)){
			report.reportPass("Hint text verified successfully and displayed as " + actHintText);
		}
		else{
			report.reportFail("Failed to verify Hint text in Search field: " + hintText);
		}
	}

	public void verifyNoResultsarefound(String data,String validationMessage){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txt_Search, "Search box");
			webActions.clearValue(txt_Search, "Search box");
			webActions.sendKeys(txt_Search, data, "Search box");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_NoResultsarefound, "No results are found message");
			String actValidationMessage=webActions.getText(lbl_NoResultsarefound, "No results are found message");
			report.reportInfo("Actual validation message displayed is :"+actValidationMessage);
			if(validationMessage.contentEquals(actValidationMessage)){
				report.reportPass("Should display validation message "+validationMessage+" when entered invalid data : "+data);
			}
			else{
				throw new Exception("Failed to verify the data :" +data  + validationMessage);
			}
		} catch (Exception e) {

			report.reportFail("Error while verifying data due to :"+e);
		}
	}

	public void verifyMaxNumOFAutoSuggestion(String Identifier) {
		try{
			int itemCount=0;
			webActions.waitForVisibility(txt_searchBox,"Simple Search");
			webActions.sendKeys(txt_searchBox,Identifier, "Simple Search");		
			report.reportPass("Entered search field value in to field");
			webActions.waitForVisibility(txt_searchBox,"Search Box",60);
			webActions.waitForVisibility(drpdwn_searchItem,"Should wait until Drpdown Search Item list is displayed");
			List<WebElement> dropdownlist_values = drpdwn_searchItem.findElements(By.tagName("li"));
			for(int count=0;count<dropdownlist_values.size();count++)
			{
				String dropdownlist_values1=dropdownlist_values.get(count).getText();
				report.reportInfo("dropdownlist_values1 is :"+(count+1)+ ": "+dropdownlist_values1);
				try {
					if(dropdownlist_values1.equals("No results are found"))
					{
						report.reportFail("Fail to display Auto Complete Suggestions as displayed No reslts found message");
						break;
					}
					else 
					{
						itemCount=itemCount+1;
					}	
				} catch (Exception e) {
					report.reportFail("Fail to display Auto Complete Suggestions due to :"+e);
				}

			}
			try {
				if(itemCount<=10)
				{
					report.reportPass("Should display Maximum Auto Complete Suggestions equal to or Below 10 Records");
				}

			} catch (Exception e) {
				report.reportFail("Fail to display Maximum Auto Complete Suggestions equal to or below 10 records due to :"+e);
			}
		}
		catch(Exception e){
			report.reportFail("Auto Complete Suggestions are not displayed properly :"+e.getMessage());
		}
	}

	public void verifySearchResultsRetained(String expectedValue){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txt_Search, "Search box");
			webActions.click(txt_Search, "Search box");
			String actValue=webActions.waitAndGetText(drpdwn_searchItem,"Actual Value");
			report.reportInfo("Actual validation message displayed is :"+actValue);
			if(expectedValue.contentEquals(actValue.trim())){
				report.reportPass("Successfully retained search results in search input box");
			}
			else{
				throw new Exception("Failed to retained search results in search input box");
			}
		} catch (Exception e) {

			report.reportFail("Error while verifying data due to :"+e);
		}
	}

	public void verifyGridResultsRetained(String Identifier,String columnname){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.waitUntilisDisplayed(grid_Results,"Grid Results");
			ArrayList<String> dataFromGrid = webActions.getGridData(grid_Header, grid_Results,"Patient",columnname);
			ArrayList<String> returnUnmatched = webActions.isFullArrayMatchWithData(dataFromGrid,Identifier);
			if(returnUnmatched.size() == 0){
				report.reportPass("Successfully validated search results matching the search criteria :"+Identifier);
			}else{
				throw new Exception("Data verification failed, and unmatched data is: "+returnUnmatched);
			}
		}
		catch (Exception e)
		{
			report.reportFail("Error to display search results matching the search criteria  " + e.getMessage());
		}
	}




	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_searchBox);
	}



}
