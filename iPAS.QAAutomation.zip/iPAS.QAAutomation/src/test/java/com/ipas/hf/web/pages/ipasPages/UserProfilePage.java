package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class UserProfilePage extends BasePage {
	UpdateVisitPage updateVisit = new UpdateVisitPage();
	Login logIn = new Login();
	HomePage hmPage = new HomePage();
	UserPermissionsPage usrPermission = new UserPermissionsPage();

	@FindBy(xpath="//button[contains(text(),'Edit')]")
	private WebElement btn_UsrPrfEdit;

	@FindBy(xpath = "//input[@id='username']")
	private WebElement txt_UserName;

	@FindBy(xpath ="//div[@class='modal-body']/div/div/label")
	private List<WebElement> lst_UPElements;

	@FindBy(xpath = "//img[@src='assets/images/cog.png']")
	private WebElement img_Settings;

	@FindBy(xpath ="//span[contains(text(),'User Profile')]")
	private WebElement img_UserProfile;

	@FindBy(xpath = "//ipas-app-navigations[1]//nav[1]//div[1]/a[@class='dropdown-item']/span")
	private List<WebElement> lst_Settings;

	@FindBy(xpath ="//form[1]/div[2]/div[1]/div[1]/button[1]")
	private WebElement btn_ChangePwd;

	@FindBy(xpath ="//form[1]/div[2]/div[1]/div[2]/button[1]")
	private WebElement btn_Edit;

	@FindBy(xpath ="//form[1]/div[2]/div[1]/div[2]/span[1]/button[1]")
	private WebElement btn_Cancel;

	@FindBy(xpath ="//form[1]/div[2]/div[1]/div[2]/span[1]/button[2]")
	private WebElement btn_Save;

	@FindBy(xpath ="//body/ejs-dialog[3]/div[1]/div[1]/div[1]/div[1]/div[1]/button[1]")
	private WebElement btn_UsrProfileClose;

	@FindBy(xpath ="//ejs-dialog[3]//form[1]/div[1]/div[1]/div[2]/ejs-textbox[1]/span[1]/input[1]")
	private WebElement txt_FirstName;

	@FindBy(xpath ="//ejs-dialog[3]//form[1]/div[1]/div[1]/div[3]/ejs-textbox[1]/span[1]/input[1]")
	private WebElement txt_LastName;

	@FindBy(xpath ="//form[1]//ejs-maskedtextbox[1]/span[1]/input[1]")
	private WebElement txt_UsrPhoneNumber;

	@FindBy(xpath ="//div[@class='modal-body']/div/div/div")
	private List<WebElement> lst_UsrPrflElementsData;

	@FindBy(xpath ="//form[1]/div[1]/div[1]/div[2]/div[1]")
	private WebElement txt_UsrPrflFirstName;

	@FindBy(xpath ="//form[1]/div[1]/div[1]/div[3]/div[1]")
	private WebElement txt_UsrPrflLastName;

	@FindBy(xpath ="//input[@placeholder='Enter email address']")
	private WebElement txt_UsrPrflEmail;

	@FindBy(xpath ="//form[1]/div[1]/div[2]/div[2]/div[1]")
	private WebElement txt_UsrPrflPhoneNumber;

	@FindBy(xpath ="//div[@class='modal-body']/div/div/div")
	private List<WebElement> lst_OperatorID;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs; 

	@FindBy(xpath = "//ejs-dialog[3]/div[1]/div[1]/div[1]/div[1]/div[1]/h4[1]")
	private WebElement txt_UserProfile; 

	@FindBy(xpath = "//form[1]/div[1]/div[1]/div[2]/div[1]/p[1]")
	private WebElement txt_FirstNameError; 

	@FindBy(xpath = "//form[1]/div[1]/div[1]/div[3]/div[1]/p[1]")
	private WebElement txt_LastNameError; 

	@FindBy(xpath ="//form[1]/div[1]/div[2]/div[2]/div[1]/p[1]")
	private WebElement txt_ErrorPhoneNumber;
	
	@FindBy(xpath ="//ipas-app-navigations[1]/div[2]/nav[1]/a[1]/img[1]")
	private WebElement txt_DashBoard;
	
	@FindBy(xpath ="//label[contains(text(),'Current Password')]")
	private WebElement lbl_CurrentPswd;
	
	@FindBy(xpath ="//h4/span")
	private WebElement lbl_CangePswdTitle;
	
	@FindBy(xpath ="(//label[contains(text(),'New Password')])[1]")
	private WebElement lbl_NewPswdInst;
	
	@FindBy(xpath ="(//label[contains(text(),'New Password')])[2]")
	private WebElement lbl_NewPswd;
	
	@FindBy(xpath ="//label[contains(text(),'Confirm Password')]")
	private WebElement lbl_ConfirmPswd;
	
	@FindBy(xpath ="(//button[@type='submit'])[1]")
	private WebElement btn_ChangePswd;
	
	@FindBy(xpath ="//input[@placeholder='Enter your current password']")
	private WebElement txt_CurrentPswd;
	
	@FindBy(xpath ="//input[@placeholder='Enter your new password']")
	private WebElement txt_newPswd;	

	@FindBy(xpath ="//input[@placeholder='Re-Enter your new password']")
	private WebElement txt_ConfirmnewPswd;
	
	@FindBy(xpath ="//div[@class='mandatory']/div")
	private List<WebElement> lbl_MandatoryFields;

	public UserProfilePage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyUserProfileElements(DataTable options) throws Exception{
		try{
			webActions.waitUntilEnabledAndClick(img_Settings, "Settings Icon");
			report.reportInfo("Clicked on Setting Image");
			webActions.waitUntilListisDisplayed(lst_Settings, "SettingsMenu");
			report.reportPass("Settings Menu is displayed");
			webActions.waitForPageLoaded();
			webActions.clickBYJS(img_UserProfile, "UserProfile");
			report.reportPass("Clicked on User Profile option");
			ArrayList<String> expectedOptions = new ArrayList<>(options.asList());
			report.reportInfo("Expected Elements are: "+expectedOptions);
			ArrayList<String> actualOptions = webActions.getDatafromWebTable(lst_UPElements);
			report.reportInfo("Actual Elements are :"+actualOptions);
			ArrayList<String>unmatchedOptionNames=webActions.getUmatchedInArrayComparision(actualOptions, expectedOptions);
			if(unmatchedOptionNames.size()==0){
				report.reportPass("Verified User Profile field names are successfully");
			}
			else{
				throw new Exception("Fail to read User Profile Field Names, unmatched fields are: "+unmatchedOptionNames);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyUserProfileButtons() throws Exception{
		try{
			String changePwdBtn = webActions.getText(btn_ChangePwd, "ChangedPwd");
			report.reportInfo("Change PWD button text is :"+changePwdBtn);
			String editBtn = webActions.getText(btn_Edit, "Edit");
			report.reportInfo("Edit button text is :"+editBtn);
			if(changePwdBtn.contentEquals("Change Password")&&editBtn.contentEquals("Edit")){
				report.reportPass("Change Password and Edit Buttons are displayed properly");
			}else{
				throw new Exception("Buttons are not displayed properly");
			}			
		}catch(Exception e){
			report.reportInfo(e.getMessage());
		}
	}

	public void verifyEditProfileElements(DataTable options) throws Exception{
		try{
			webActions.waitUntilEnabledAndClick(img_Settings, "Settings Icon");
			report.reportInfo("Clicked on Setting Image");
			webActions.waitUntilListisDisplayed(lst_Settings, "SettingsMenu");
			report.reportPass("Settings Menu is displayed");
			webActions.waitForPageLoaded();
			usrPermission.verifyEditUserProfileText();
			ArrayList<String> expectedOptions = new ArrayList<>(options.asList());
			report.reportInfo("Expected Elements are: "+expectedOptions);
			ArrayList<String> actualOptions = webActions.getDatafromWebTable(lst_UPElements);
			report.reportInfo("Actual Elements are :"+actualOptions);
			ArrayList<String>unmatchedOptionNames=webActions.getUmatchedInArrayComparision(actualOptions, expectedOptions);
			if(unmatchedOptionNames.size()==0){
				report.reportPass("Verified User Profile field names are successfully");
			}
			else{
				throw new Exception("Fail to read User Profile Field Names, unmatched fields are: "+unmatchedOptionNames);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyEditProfileButtons() throws Exception{
		try{
			String cancelBtn = webActions.getText(btn_Cancel, "Cancel");
			report.reportInfo("Cancel button text is :"+cancelBtn);
			String saveBtn = webActions.getText(btn_Save, "Save");
			report.reportInfo("Save button text is :"+saveBtn);
			if(cancelBtn.contentEquals("Change Password")&&saveBtn.contentEquals("Edit")){
				report.reportPass("Cancel and Save Buttons are displayed properly");
			}else{
				throw new Exception("Buttons are not displayed properly");
			}			
		}catch(Exception e){
			report.reportInfo(e.getMessage());
		}
	}

	public void verifyUserProfileXButton() throws Exception {
		try{
			webActions.waitForPageLoaded();
			if(webActions.isDisplayed(btn_UsrProfileClose, "X button")){
				report.reportPass("X button is displayed in User Profile Window");
			}else{
				throw new Exception("Unable to find Close button in User Profile Window");
			}		
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void closeUserProfileWindow() throws Exception {
		try{
			webActions.waitForPageLoaded();
			if(webActions.isDisplayed(btn_UsrProfileClose, "X button")){
				webActions.click(btn_UsrProfileClose, "Close Button");
				webActions.waitForPageLoaded();
			}else{
				throw new Exception("Unable to find Close button in User Profile Window");
			}		
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void editUserProfile(DataTable testData,String messageTitle,String messageContent) throws Exception{
		try{
			webActions.waitForJSandJQueryToLoad();
			webActions.click(txt_FirstName, "FirstName");
			webActions.clearValue(txt_FirstName, "FirstName");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_FirstName, getDatafromMap(testData,"First Name"), "First Name");
			webActions.click(txt_LastName, "LastName");
			webActions.clearValue(txt_LastName, "LastName");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_LastName, getDatafromMap(testData,"Last Name"), "Last Name");
			webActions.click(txt_UsrPhoneNumber, "PhoneNumber");
			webActions.clearValue(txt_UsrPhoneNumber, "PhoneNumber");
			webActions.waitForPageLoaded();
			webActions.sendKeysByJS(txt_UsrPhoneNumber, getDatafromMap(testData,"Phone Number"), "Phone Number");
			webActions.waitForPageLoaded();;
			webActions.click(btn_Save, "Save");
			webActions.waitForPageLoaded();
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actTitle=titleContent[0];
			String actContent=titleContent[1];
			report.reportInfo("Actual alert message after user is created: "+msg);
			if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent))){
				report.reportPass("Alert message is displayed successfully when try to create duplicate user:"+msg);
			}
			else{
				throw new Exception("Failed to verify the Alert message when try to create duplicate user: "+msg);
			}
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();//mandatory -- time taking to display the updated mobile number
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}

	public void clickUsrProfileSave() throws Exception{
		try{
			webActions.waitForPageLoaded();
			if(btn_Save.isEnabled()){
				webActions.click(btn_Save, "Save");
				webActions.waitForPageLoaded();
			}else{
				throw new Exception("Save button is not in Enabled Mode");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDataOfUserProfileFields(DataTable options) throws Exception{
		try{
			webActions.waitForJSandJQueryToLoad();
			ArrayList<String> expectedOptions = new ArrayList<>(options.asList());
			report.reportInfo("Expected Elements are: "+expectedOptions);
			ArrayList<String> actualOptions = new ArrayList<String>();
			actualOptions.add(webActions.getText(txt_UsrPrflFirstName, "FirstName"));
			actualOptions.add(webActions.getText(txt_UsrPrflLastName, "LastName"));
			actualOptions.add(webActions.getText(txt_UsrPrflEmail, "Email"));
			actualOptions.add(webActions.waitAndGetText(txt_UsrPrflPhoneNumber, "PhoneNumber"));
			report.reportInfo("Actual Elements are :"+actualOptions);
			ArrayList<String>unmatchedOptionNames=webActions.getUmatchedInArrayComparision(actualOptions, expectedOptions);
			if(unmatchedOptionNames.size()==0){
				report.reportPass("Verified User Profile field names are successfully");
			}
			else{
				throw new Exception("Fail to read User Profile Field Names, unmatched fields are: "+unmatchedOptionNames);
			}
			closeUserProfileWindow();
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void navigateToUserProfile() throws Exception{
		try{
			webActions.waitUntilEnabledAndClick(img_Settings, "Settings Icon");
			report.reportInfo("Clicked on Setting Image");
			webActions.waitUntilListisDisplayed(lst_Settings, "SettingsMenu");
			report.reportPass("Settings Menu is displayed");
			webActions.waitForClickAbilityAndClick(img_UserProfile, "UserProfile");
			report.reportInfo("Clicked on User Profile Option");
			String actText = webActions.getText(txt_UserProfile, "UserProfileText");
			if(actText.contentEquals("User Profile")){
				report.reportPass("User Text is displayed properly");
			}else{
				throw new Exception("unable to read User Profile");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyEmailAddressFieldMode() throws Exception{
		try{
			webActions.waitForPageLoaded();
			Thread.sleep(2000);
		String flag=txt_UsrPrflEmail.getAttribute("readonly");
			
			if(flag.contentEquals("true")){
				report.reportPass("Verified email address field successfully");
				
			}else{
				report.reportFail("fail to verify the email adress field");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	public void navigateToEditProfile() throws Exception{
		try{
			webActions.waitForPageLoaded();
			if(btn_Edit.isEnabled()){
				webActions.click(btn_Edit, "Edit");
			}else{
				throw new Exception("Edit button is not in enabled mode");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyMandatoryMessages(String fnMandatory, String snMandatory) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_FirstName, "FirstName");
			webActions.waitForPageLoaded();
			String errorFistName = webActions.waitAndGetText(txt_FirstNameError, "FirstNameError");
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_LastName, "LastName");
			webActions.waitForPageLoaded();
			String errorLastName = webActions.waitAndGetText(txt_LastNameError, "LastNameError");
			webActions.waitForPageLoaded();
			if(errorFistName.contentEquals(fnMandatory)&&errorLastName.contentEquals(snMandatory)){
				report.reportPass("Error Messages are displayed properly");
			}else{
				throw new Exception("Failed to read Error Messages");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyMinLengthmessages(String fnMandatory, String snMandatory) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_FirstName, "FirstName");
			webActions.waitForPageLoaded();
			webActions.enterValuesfromKeyBoard(txt_FirstName,"r", "FirstName");
			webActions.waitForPageLoaded();
			String errorFistName = webActions.waitAndGetText(txt_FirstNameError, "FirstNameError");
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_LastName, "LastName");
			webActions.waitForPageLoaded();
			webActions.enterValuesfromKeyBoard(txt_LastName,"r", "LastName");
			webActions.waitForPageLoaded();
			String errorLastName = webActions.waitAndGetText(txt_LastNameError, "LasttNameError");
			webActions.waitForPageLoaded();
			if(errorFistName.contentEquals(fnMandatory)&&errorLastName.contentEquals(snMandatory)){
				report.reportPass("Error Messages are displayed properly");
			}else{
				throw new Exception("Failed to read Error Messages");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyPhoneNumberValidationMsg(String errorMsg,String value) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_UsrPhoneNumber, "PhoneNumber");
			webActions.waitForPageLoaded();
			webActions.sendKeysByJS(txt_UsrPhoneNumber,value, "PhoneNumber");
			webActions.keyBoardEnter(txt_UsrPhoneNumber, "PhoneNumber");
			webActions.waitForPageLoaded();
			if(webActions.getText(txt_ErrorPhoneNumber, "PhoneNumber").contentEquals(errorMsg)){
				report.reportPass("Error msg is properly");
			}else{
				throw new Exception("Failed to read Mobile Number validation message");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyDashBoard() throws Exception{
		try{
			webActions.waitForPageLoaded();
			String actText = webActions.getAttributeValue(txt_DashBoard, "alt", "DashBoard");
			report.reportInfo("Actual DashBoard Text is :"+actText);
			if(actText.contentEquals("iPAS Logo")){
				report.reportPass("DahsBoard is displayed by default");
			}else{
				throw new Exception("DahsBoard is not displayed by default");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	
	public UserProfilePage openIpasApp() {
		try {
			String URL = TestBase.prop.ipasURL();
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to Open iPAS application");
		}
		return (UserProfilePage) base(UserProfilePage.class);
	}

	
	public void goToChangePswdWindow() throws Exception{
		try{
			webActions.waitUntilEnabledAndClick(img_Settings, "Settings Icon");
			report.reportInfo("Clicked on Setting Image");
			webActions.waitUntilListisDisplayed(lst_Settings, "SettingsMenu");
			report.reportPass("Settings Menu is displayed");
			webActions.waitForPageLoaded();
			webActions.clickBYJS(img_UserProfile, "UserProfile");
			report.reportPass("Clicked on User Profile option");
			webActions.waitForVisibility(btn_ChangePwd, "ChangePswdBtn");
			webActions.click(btn_ChangePwd, "ChangePswdBtn");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_CurrentPswd, "PasswdLabel");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyChangePswdElements(DataTable options) throws Exception{
		try{			
			ArrayList<String> expectedOptions = new ArrayList<>(options.asList());
			report.reportInfo("Expected Elements are: "+expectedOptions);
			ArrayList<String> actualOptions = new ArrayList<>();
			actualOptions.add(webActions.getText(lbl_CangePswdTitle, "windowTitle"));
			actualOptions.add(webActions.getText(lbl_NewPswdInst, "NewPswdInst"));
			actualOptions.add(webActions.getText(lbl_CurrentPswd, "currentPswd"));
			actualOptions.add(webActions.getText(lbl_NewPswd, "newPswd"));
			actualOptions.add(webActions.getText(lbl_ConfirmPswd, "confirmPswd"));
			
			report.reportInfo("Actual Elements are :"+actualOptions);
			ArrayList<String>unmatchedOptionNames=webActions.getUmatchedInArrayComparision(actualOptions, expectedOptions);
			if(unmatchedOptionNames.size()==0){
				report.reportPass("Verified change password elements successfully");
			}
			else{
				throw new Exception("Fail to verify elements and, unmatched fields are: "+unmatchedOptionNames);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	public void verifyChangePswdMode(){
		try {
			webActions.waitForPageLoaded();			
			boolean flag=btn_ChangePswd.isEnabled();
			
			if(flag){
				report.reportFail("Fail to verify change password button");
			}
			else{
				report.reportPass("Successfully verified change password button");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyChangePswdInstructions(DataTable options) throws Exception{
		try{			
			ArrayList<String> expectedOptions = new ArrayList<>(options.asList());
			report.reportInfo("Expected Elements are: "+expectedOptions);
			ArrayList<String> actualOptions = new ArrayList<>();
			
			for(int i=6;i<=12;i++){
				actualOptions.add(webActions.getText(driver.findElement(By.xpath("(//ul/li)["+i+"]")), "windowTitle"));
			}		
			report.reportInfo("Actual Elements are :"+actualOptions);
			ArrayList<String>unmatchedOptionNames=webActions.getUmatchedInArrayComparision(actualOptions, expectedOptions);
			if(unmatchedOptionNames.size()==0){
				report.reportPass("Verified change password instructions successfully");
			}
			else{
				throw new Exception("Fail to verify password instructions, unmatched fields are: "+unmatchedOptionNames);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	public void verifymandatoryValidations(DataTable options){
		try {
		webActions.waitForPageLoaded();
		webActions.click(txt_CurrentPswd, "currentPswd");
		webActions.pressTab();
		webActions.waitForPageLoaded();
		webActions.click(txt_newPswd, "NewPswd");
		webActions.pressTab();
		webActions.waitForPageLoaded();
		webActions.click(txt_ConfirmnewPswd, "ConfirmNewPswd");
		webActions.pressTab();
		webActions.waitForPageLoaded();
		ArrayList<String> expectedOptions = new ArrayList<>(options.asList());
		report.reportInfo("Expected Elements are: "+expectedOptions);
		ArrayList<String> actualOptions =webActions.getDatafromWebTable(lbl_MandatoryFields);
		report.reportInfo("Actual Elements are :"+actualOptions);
		ArrayList<String>unmatchedOptionNames=webActions.getUmatchedInArrayComparision(actualOptions, expectedOptions);
		if(unmatchedOptionNames.size()==0){
			report.reportPass("Verified mandatory validations successfully");
		}
		else{
			throw new Exception("Fail to verify validations, unmatched fields are: "+unmatchedOptionNames);
		}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyChangePaswdInstructions(String expMsg,String input){
		try {
			webActions.waitForPageLoaded();
			webActions.click(txt_CurrentPswd, "currentPswd");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_CurrentPswd, input, "currentPswd");
			webActions.waitForPageLoaded();
			webActions.click(txt_newPswd, "NewPswd");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_newPswd, input, "NewPswd");
			webActions.waitForPageLoaded();
			webActions.click(txt_ConfirmnewPswd, "ConfirmNewPswd");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_ConfirmnewPswd, input, "ConfirmNewPswd");
			webActions.waitForPageLoaded();
			ArrayList<String> actualOptions =webActions.getDatafromWebTable(lbl_MandatoryFields);
			report.reportInfo("Actual Elements are :"+actualOptions);
			ArrayList<String>unmatchedOptionNames=webActions.isFullArrayMatchWithData(actualOptions, expMsg);
			if(unmatchedOptionNames.size()==0){
				report.reportPass("Verified validation successfully");
			}
			else{
				throw new Exception("Fail to verify validation and unmatched fields are: "+unmatchedOptionNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_UserName);
	}

}
