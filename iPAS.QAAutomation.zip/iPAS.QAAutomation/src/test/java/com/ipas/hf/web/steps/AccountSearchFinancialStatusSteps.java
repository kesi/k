package com.ipas.hf.web.steps;

import java.io.IOException;
import java.util.ArrayList;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.ipasPages.AccountSearchFinancialStatusPage;
import com.ipas.hf.web.pages.ipasPages.AddPatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.EligibityPage;
import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class AccountSearchFinancialStatusSteps {

	AccountSearchFinancialStatusPage acctFinancialSts=new AccountSearchFinancialStatusPage();
	AddPatientVisitPage addPatient=new AddPatientVisitPage();
	RestActions rest=new RestActions();
	Login logIn=new Login();
	HomePage home=new HomePage();
	EligibityPage ele=new EligibityPage();

	@Then("Verify the display of financial status of the respective visit")
	public void verify_the_display_of_financial_status_of_the_respective_visit() {
		acctFinancialSts.verifyDefaultStatus();

	}	

	@Then("Click on allmodule window option and verify the title as {string}")
	public void click_on_allmodule_window_option_and_verify_the_title_as(String title) {
		acctFinancialSts.verifyAllModuleTitle(title);
	}
	@Then("Click on digital documents link from account search")
	public void click_on_digital_documents_link_from_account_search() {
		acctFinancialSts.clickOndigitaldocumentLink_AccountSearch();
	}

	@Then("Change the status of documents and forms")
	public void change_the_status_of_documents_and_forms() throws Exception {
		acctFinancialSts.verifyModuleStatusinDigitalDocumentsMangerPage();
	}

	@Then("Verify the financial clerance status in digital document manger page")
	public void verify_the_financial_clerance_status_in_digital_document_manger_page() {
		acctFinancialSts.verifyFinanceStatusInDigitalDocPage();
	}

	@Then("Verify the display of {string} status for all modules from All module window")
	public void verify_the_display_of_status_for_all_modules_from_All_module_window(String status) {
		acctFinancialSts.verifyAllModuleStatus(status);
	}	

	@Then("Go to the account search page from account search breadcrum")
	public void go_to_the_account_search_page_from_account_search_breadcrum() {
		acctFinancialSts.navigateAccountFromBreadcrum();
	}

	@Then("Verify the display of financial clearance status of {string} in Account search")
	public void verify_the_display_of_financial_clearance_status_of_in_Account_search(String status) {
		acctFinancialSts.verifyFinanceClearanceStatus(status);
	}
	@Then("Navigate to the service tracker page and change the status to review")
	public void navigate_to_the_service_tracker_page_and_change_the_status_to_review() {
		acctFinancialSts.changeServiceTrackerToReview();
	}

	@Then("Verify the financial clerance status of {string} in summary page")
	public void verify_the_financial_clerance_status_of_in_summary_page(String status) {
		acctFinancialSts.verifyFinanceStatusInSummaryPage(status);
	}

	@Then("Click on service tracker link from account search")
	public void click_on_service_tracker_link_from_account_search() {
		acctFinancialSts.clickOnServiceTrackerLink_NeedsAttention();
	}

	@Then("Change the service module status to clear")
	public void change_the_service_module_status_to_clear() {
		acctFinancialSts.changeServiceTrackerToClear();
	}

	@Then("Navigate to the payment facilitator page from all module window and change the status to pending")
	public void navigate_to_the_payment_facilitator_page_from_all_module_window_and_change_the_status_to_pending() {
		acctFinancialSts.changePaymentFacilitatorToPending();
	}
	@Then("Click on digital document manager panel Link")
	public void click_on_digital_document_manager_panel_Link() {
		acctFinancialSts.clickOnDigitalLink_VisitSummaryPage();
	}

	@Then("Verify the financial clearance status of {string} in Service Tracker window")
	public void verify_the_financial_clearance_status_of_in_Service_Tracker_window(String status) {
		acctFinancialSts.verifyFinanceStatusInServiceTrackerWindow(status);
	}

	@Then("Add new patient visit from Add patient page and search added patient in account search")
	public void add_new_patient_visit_from_Add_patient_page_and_search_added_patient_in_account_search() throws InterruptedException {
		int len=5; 
		int len1=4; 
		String firstName=rest.randomString(len);
		String lastName="V"+rest.randomString(len1);
		String patientName=firstName+" "+lastName;
		addPatient.navigateToAddPatient();
		addPatient.verifyAddPatient(lastName,firstName);
		Thread.sleep(3000);
		logIn.simpleSearch(patientName);
		addPatient.notepadWrite("hello", patientName);
		ArrayList<String> patient=new ArrayList<>();
		patient.add(firstName);
		patient.add(lastName);
		addPatient.notepadWrite("testData", patient);	
	}
	@Then("Read the created patient name from notepad and search from account search")
	public void read_the_created_patient_name_from_notepad_and_search_from_account_search() throws Exception {
		String patientName=addPatient.notepadRead("hello");
		logIn.simpleSearch(patientName);

	}

	@Then("Click on Account Number from link")
	public void click_on_Account_Number_from_link() throws Exception {
		acctFinancialSts.clickOnAccountLinkNumber();
	}	
	@Then("Go to the visit main page from account number breadcrumb")
	public void go_to_the_visit_main_page_from_account_number_breadcrumb() {
		acctFinancialSts.navigateViistMainPageFromBreadcrum();
	}

	@Then("Enter the valid postal address and verify the postal moduel status")
	public void enter_the_valid_postal_address_and_verify_the_postal_moduel_status(DataTable testData) {
		acctFinancialSts.enterPostalAddress(testData);
	}
	@Then("Click on Admit Notifier short panel")
	public void click_on_Admit_Notifier_short_panel() {
		acctFinancialSts.clickOnAdmitNotifierShortPanel();
	}
	@Then("Change the Admit Notifier status as {string}")
	public void change_the_Admit_Notifier_status_as(String status) {
		acctFinancialSts.changeAdmitNotifierStatus(status);
	}

	@Then("Navigate back to the Account search from other pages")
	public void navigate_back_to_the_Account_search_from_other_pages() {
		home.navigateToAccountSearchFromOtherPages();
	}

	@Then("Verify the financial clearance status as {string}")
	public void verify_the_financial_clearance_status_as(String status) {
		acctFinancialSts.verifyFinancialStatus(status);
	}

	@Then("Verify the financial status in visit main page as {string}")
	public void verify_the_financial_status_in_visit_main_page_as(String status) {
		acctFinancialSts.verifyFinanceStatusInSummaryPage(status);
	}

	@Then("Click on Account number link")
	public void click_on_Account_number_link() throws Exception {
		acctFinancialSts.clickOnAccountLinkNumber();
	}

	@Then("Run the eligibility manually and verify the financial status")
	public void run_the_eligibility_manually_and_verify_the_financial_status(DataTable testData) throws Exception {
		ele.runEligibility(testData);
	}
	@Then("Navigate to the service tracker page and update the status to review")
	public void navigate_to_the_service_tracker_page_and_update_the_status_to_review() {
		acctFinancialSts.changeServiceTrackerModuleStatusToReview();
	}
	@Then("Delete the cpt codes as {string}")
	public void delete_the_cpt_codes_as(String type) {
		acctFinancialSts.deleteMedicalNecessityCPTcodes(type);
	}

	@Then("Click on medical necessity check button")
	public void click_on_medical_necessity_check_button() {
		acctFinancialSts.clickOnMedicalCheck();
	}
	@Then("Go to the maintenance page")
	public void go_to_the_maintenance_page() {
		home.navigateToMaintenanceFromOtherPages();
	}

}
