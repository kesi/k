package com.ipas.hf.web.pages.ipasPages;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class AccountSearchFilteringPage extends BasePage {
	
	private JSONObject jsonObject;
	private static final String FILTERJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\AccountSearchFilters.json";
	private StepLogging log = StepLogging.getLoggingObject();
	
	@FindBy(xpath = "//button[@id='e-dropdown-btn_3']")
	private WebElement btn_Filter;

	@FindBy(xpath = "//button[text()='Columns']")
	private WebElement btn_Columns;

	@FindBy(xpath = "//div[@id='panel']")
	private WebElement grid_Header;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody")
	private WebElement grid_Results;

	@FindBy(xpath="//ejs-listview[@id='listview']/div[2]/ul/li")//ejs-listview[@id='listview']//span[@class='e-list-text']
	public List<WebElement> li_FilterNames;

	@FindBy(xpath="//ejs-listview[@id='listview']//li[(@class='e-list-item e-level-1 e-checklist')]")
	public List<WebElement> chk_Filter;

	@FindBy(xpath="//ejs-listview[@id='columnview']//span[contains(@class,'e-list-content e-checkbox e-checkbox-left')]")
	public List<WebElement> chk_Colunms;

	@FindBy(xpath="//ejs-dropdownlist[@id='Gender']")
	public WebElement dd_Gender;

	@FindBy(xpath="//ejs-dropdownlist[@id='Gender']/span/select/option")
	public WebElement dd_Gender1;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody/tr/td")
	private WebElement tbl_AllRecords;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr")
	private WebElement tbl_AccountSearch_Results;

	@FindBy(xpath = "//div[@class='e-gridcontent']//tr//td[2]/div[1]//div[2]//span")
	private List<WebElement> tbl_Gender;

	@FindBy(xpath = "//button[@class='btn btn-primary btn-md ml-10']")
	private WebElement btn_Apply;

	@FindBy(xpath = "//ejs-dropdownlist[@id='Gender']//input[@class='e-input']")
	private WebElement dd_Gender2;

	@FindBy(id ="PatientDateOfBirth_input")
	private WebElement date_DOB;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tr//td[2]/div[1]//div[2]")
	private List<WebElement> tbl_DOB;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody/tr/td[2]/div")
	private List<WebElement> tbl_Patient;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody/tr/td[3]")
	private List<WebElement> tbl_Visit;

	@FindBy(id = "SSN")
	private WebElement txt_SSN;

	@FindBy(id = "PhoneNumber")
	private WebElement txt_PhoneNumber;

	@FindBy(xpath = "//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_Search;

	@FindBy(xpath = "//input[@id='Email']")
	private WebElement txt_Email;

	@FindBy(xpath = "//ejs-dropdownlist[@id='Location']//input[@class='e-input']")
	private WebElement dd_Location;

	@FindBy(xpath = "//ejs-dropdownlist[@id='Location']/span/select/option")
	private WebElement li_Location;

	@FindBy(xpath = "//ejs-dropdownlist[@id='PatientType']//input[@class='e-input']")
	private WebElement dd_PatientType;

	@FindBy(xpath = "//ejs-dropdownlist[@id='PatientType']/span/select/option")
	private WebElement lis_PatientType;

	@FindBy(id = "MedicalClinicalService")
	private WebElement txt_HospitalService;

	@FindBy(id = "Diagnosis")
	private WebElement txt_Diagnosis;

	@FindBy(id = "Procedure")
	private WebElement txt_Procedure;

	@FindBy(id = "AdmittingProvider")
	private WebElement txt_AdmittingProvider;

	@FindBy(id = "ReferringProvider")
	private WebElement txt_ReferringProvider;

	@FindBy(xpath = "//ejs-dropdownlist[@id='VisitStatus']//input[@class='e-input']")
	private WebElement dd_VisitStatus;

	@FindBy(xpath = "//select[@id='VisitStatus_hidden']/option")
	private WebElement li_VisitStatus;

	@FindBy(xpath = "//ejs-dropdownlist[@id='FinancialClass']//input[@class='e-input']")
	private WebElement dd_FinancialClass;

	@FindBy(xpath = "//select[@id='FinancialClass_hidden']/option")
	private WebElement li_FinancialClass;

	@FindBy(xpath = "//ejs-dropdownlist[@id='PrimaryInsurance']//input[@class='e-input']")
	private WebElement dd_PrimaryInsurance;

	@FindBy(xpath = "//select[@id='PrimaryInsurance_hidden']/option")
	private WebElement li_PrimaryInsurance;

	@FindBy(xpath = "//ejs-dropdownlist[@id='SecondaryInsurance']//input[@class='e-input']")
	private WebElement dd_SecondaryInsurance;

	@FindBy(xpath = "//select[@id='SecondaryInsurance_hidden']/option")
	private WebElement li_SecondaryInsurance;

	@FindBy(xpath = "//ejs-dropdownlist[@id='TertiaryInsurance']//input[@class='e-input']")
	private WebElement dd_TertiaryInsurance;

	@FindBy(xpath = "//select[@id='TertiaryInsurance_hidden']/option")
	private WebElement li_TertiaryInsurance;

	@FindBy(xpath = "//ejs-dropdownlist[@id='EventType']//input[@class='e-input']")
	private WebElement dd_EventType;

	@FindBy(xpath = "//select[@id='EventType_hidden']/option")
	private WebElement li_EventType;

	@FindBy(xpath = "//ejs-dropdownlist[@id='Employee']//input[@class='e-input']")
	private WebElement dd_Employee;

	@FindBy(xpath = "//select[@id='Employee_hidden']/option")
	private WebElement li_Employee;

	@FindBy(linkText = "Service Tracker")
	private WebElement lnk_ServiceTracker;

	@FindBy(linkText = "Account Search")
	private WebElement lnk_AccountSearch;

	@FindBy(xpath = "//label[(text()='Service Department')]")
	private WebElement lbl_ServiceDepartment;

	@FindBy(xpath = "//div[@class='e-gridcontent']//tr[1]//td[2]/div/a")
	private WebElement lnk_AccountNumber;

	@FindBy(xpath = "//a[text()='All Data']")
	private WebElement lbl_AllData;

	@FindBy(xpath = "//ipas-breadcrumb/div/span[1]/a")
	private WebElement lnk_AccountSearch1;

	@FindBy(xpath="//table[@class='e-table']//thead/tr/th")
	private WebElement lbl_Headers;



	DefaultSearchPage defaultsearch;
	private RestActions rest = new RestActions();
	
	public AccountSearchFilteringPage() {
		PageFactory.initElements(driver, this);
		defaultsearch=new DefaultSearchPage();
	}

	public void verifyFilterNames(DataTable filterNames) {
		try {
			ArrayList<String> expFilterNames = new ArrayList<>(filterNames.asList());
			waitforAllRows();
			report.reportInfo("Expected Filter Names: "+expFilterNames);
			webActions.waitAndClick(btn_Filter, "Filter Button");
			ArrayList<String> actFilterNames=webActions.getDatafromWebTable(li_FilterNames);
			report.reportInfo("Displayed Filter Names in Application: "+actFilterNames);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actFilterNames, expFilterNames);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified Filter Names in Account Search page successfully");
			}
			else{
				throw new Exception("Fail to verify Filter Names in Account Search page and unmatched Filter Names are: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	/**
	 * To select any filter name 
	 * @param filterName
	 */
	public void selectFilterName(String filterName) throws Exception{
		try {
			webActions.waitForLoad();
			webActions.waitAndClick(btn_Filter, "Filter Button");
			webActions.selectCheckBoxfromList(chk_Filter,filterName,filterName);
			webActions.waitUntilEnabledAndClick(btn_Filter, "Filter Button");
			webActions.waitForLoad();
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			throw new Exception("Unable to select the "+filterName+" Filter Name: "+e);
		}
	} 

	public void selectColumn(String colunmnName){
		try {
			webActions.waitUntilEnabledAndClick(btn_Columns, "Columns Button");
			webActions.selectCheckBoxfromList(chk_Colunms,colunmnName,colunmnName);
			webActions.waitUntilEnabledAndClick(btn_Columns, "Columns Button");
		} catch (Exception e) {
		}
	}

	public String selectGender(String genderType) throws Exception{
		try {
			webActions.waitForClickAbility(dd_Gender2, "Gender");
			if(genderType.contentEquals("Female")){
				genderType="F";
			}
			else if(genderType.contentEquals("Male")){
				webActions.sendKeys(dd_Gender2, genderType, "Gender Dropdown");genderType="M";
			}else if(genderType.contentEquals("Other")){
				webActions.sendKeys(dd_Gender2, genderType, "");genderType="O";
			}else if(genderType.contentEquals("Unknown")){
				webActions.sendKeys(dd_Gender2, genderType, "");genderType="U";
			}
			webActions.click(btn_Apply, "Apply Button");
		} catch (Exception e) {
			throw e;
		}
		return genderType;
	}

	public void enterDateofBirth(String dateofBirth) throws Exception{
		try {
			webActions.waitForVisibility(date_DOB, "Date of Birth");
			webActions.sendKeys(date_DOB, dateofBirth, "Date of Birth");
			webActions.click(btn_Apply, "Apply Button");
		} catch (Exception e) {
			throw e;
		}
	}

	public void enterSSN(String SSN) throws Exception{
		try {
			webActions.waitForVisibility(txt_SSN, "SSN");
			webActions.click(txt_SSN, "SSN");
			//webActions.sendKeysByJS(txt_SSN, SSN, "SSN");
			webActions.enterValuesfromKeyBoard(txt_SSN, SSN, "SSN");
			webActions.click(txt_SSN, "SSN");
			webActions.keyBoardEnter(txt_SSN, "SSN");
			webActions.waitForPageLoaded();
			webActions.click(txt_Search, "Search");
			webActions.click(btn_Apply, "Apply Button");
			webActions.waitForPageLoaded();
			webActions.click(txt_Search, "Search");
			webActions.click(btn_Apply, "Apply Button");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			throw e;
		}
	}

	public void enterPhoneNumber(String phoneNumber) throws Exception{
		try {
			webActions.waitForVisibility(txt_PhoneNumber, "Phone Number");
			webActions.click(txt_PhoneNumber, "Phone Number");
			webActions.sendKeys(txt_PhoneNumber, phoneNumber, "Phone Number");
			webActions.click(btn_Apply, "Apply Button");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			throw e;
		}
	}

	public void enterEmail(String email) throws Exception{
		try {
			webActions.waitForVisibility(txt_Email, "Email");
			webActions.sendKeys(txt_Email, email, "Email");
			webActions.click(btn_Apply, "Apply Button");
		} catch (Exception e) {
			throw e;
		}
	}

	public void selectLocation(String location) throws Exception{
		try {
			webActions.waitForClickAbility(dd_Location, "Location");
			webActions.sendKeys(dd_Location, location, "Location");
			webActions.click(btn_Apply, "Apply Button");
		} catch (Exception e) {
			throw e;
		}
	}

	public void selectPatientType(String patientType) throws Exception{
		try {
			webActions.waitForClickAbility(dd_PatientType, "Patient Type");
			webActions.sendKeys(dd_PatientType, patientType, "Patient Type");
			webActions.click(btn_Apply, "Apply Button");
		} catch (Exception e) {
			throw e;
		}
	}

	public void selectVisitStatus(String visitStatus) throws Exception{
		try {
			webActions.waitForVisibility(dd_VisitStatus, "Visit Status");
			webActions.sendKeys(dd_VisitStatus, visitStatus, "Visit Status");
			webActions.click(btn_Apply, "Apply Button");
		} catch (Exception e) {
			throw e;
		}
	}

	public void enterHospitalService(String hospitalService) throws Exception{
		try {
			webActions.waitForVisibility(txt_HospitalService, "Hospital Service");
			webActions.sendKeys(txt_HospitalService, hospitalService, "Hospital Service");
			webActions.click(btn_Apply, "Apply Button");
		} catch (Exception e) {
			throw e;
		}
	}

	public void enterDiagnosis(String diagnosis) throws Exception{
		try {
			webActions.waitForVisibility(txt_Diagnosis, "Diagnosis");
			webActions.click(txt_Diagnosis, "Diagnosis");
			webActions.enterValuesfromKeyBoard(txt_Diagnosis, diagnosis, "Diagnosis");
			webActions.click(btn_Apply, "Apply Button");
		} catch (Exception e) {
			throw e;
		}
	}

	public void enterProcedure(String procedure) throws Exception{
		try {
			webActions.waitForVisibility(txt_Procedure, "Procedure");
			webActions.sendKeys(txt_Procedure, procedure, "Procedure");
			webActions.click(btn_Apply, "Apply Button");
		} catch (Exception e) {
			throw e;
		}
	}

	public void enterAdmittingProvider(String admittingProvider) throws Exception{
		try {
			webActions.waitForVisibility(txt_AdmittingProvider, "Admitting Provider");
			webActions.sendKeys(txt_AdmittingProvider, admittingProvider, "Admitting Provider");
			webActions.click(btn_Apply, "Apply Button");
		} catch (Exception e) {
			throw e;
		}
	}

	public void enterReferringProvider(String referringProvider) throws Exception{
		try {
			webActions.waitForVisibility(txt_ReferringProvider, "Referring Provider");
			webActions.sendKeys(txt_ReferringProvider, referringProvider, "ReferringProvider");
			webActions.click(btn_Apply, "Apply Button");
		} catch (Exception e) {
			throw e;
		}
	}

	public void selectFinancialClass(String financialClass) throws Exception{
		try {
			financialClass.toUpperCase();
			webActions.waitForVisibility(dd_FinancialClass, "Financial Class");
			webActions.sendKeys(dd_FinancialClass, financialClass, "Financial Class");
			webActions.click(btn_Apply, "Apply Button");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			throw e;
		}
	}

	public void selectPrimaryInsurance(String primaryInsurance) throws Exception{
		try {
			webActions.waitForVisibility(dd_PrimaryInsurance, "Primary Insurance");
			webActions.sendKeys(dd_PrimaryInsurance, primaryInsurance, "Primary Insurance");
			webActions.click(btn_Apply, "Apply Button");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			throw e;
		}
	}
	public void selectSecondaryInsurance(String secondaryInsurance) throws Exception{
		try {
			webActions.waitForVisibility(dd_SecondaryInsurance, "Secondary Insurance");
			webActions.sendKeys(dd_SecondaryInsurance, secondaryInsurance, "Secondary Insurance");
			webActions.click(btn_Apply, "Apply Button");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			throw e;
		}
	}

	public void selectTertiaryInsurance(String tertiaryInsurance) throws Exception{
		try {
			webActions.waitForVisibility(dd_TertiaryInsurance, "Tertiary Insurance");
			webActions.sendKeys(dd_TertiaryInsurance, tertiaryInsurance, "Tertiary Insurance");
			webActions.click(btn_Apply, "Apply Button");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			throw e;
		}
	}

	public void selectEventType(String eventType) throws Exception{
		try {
			webActions.waitForVisibility(dd_EventType, "Event Type");
			webActions.sendKeys(dd_EventType, eventType, "Event Type");
			webActions.click(btn_Apply, "Apply Button");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			throw e;
		}
	}

	public void selectEmployee(String employee) throws Exception{
		try {
			webActions.waitForLoad();
			webActions.waitForVisibility(dd_Employee, "Employee");
			webActions.sendKeys(dd_Employee, employee, "Employee");
			webActions.click(btn_Apply, "Apply Button");
			webActions.waitForLoad();
		} catch (Exception e) {
			throw e;
		}
	}


	public void verifytheFieldandDefaultValue(String filterName,String expectedValue){
		String actualDefaultValue="";
		try {
			waitforAllRows();
			selectFilterName(filterName);
			webActions.waitForLoad();
			switch (filterName) {
			case "Gender":
				webActions.waitForClickAbility(dd_Gender, filterName);
				webActions.assertDisplayed(dd_Gender, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				actualDefaultValue=webActions.getValue(dd_Gender1, filterName);
				break;
			case "Date of Birth":
				webActions.waitForVisibility(date_DOB, filterName);
				webActions.assertDisplayed(date_DOB, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				actualDefaultValue=webActions.getValue(date_DOB, filterName);
				break;
			case "SSN":
				webActions.waitForVisibility(txt_SSN, filterName);
				webActions.assertDisplayed(txt_SSN, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				webActions.click(txt_SSN, filterName);
				actualDefaultValue=webActions.getValue(txt_SSN, filterName);
				break;
			case "Phone Number":
				webActions.waitForVisibility(txt_PhoneNumber, filterName);
				webActions.assertDisplayed(txt_PhoneNumber, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				actualDefaultValue=webActions.getValue(txt_PhoneNumber, filterName);
				break;
			case "Email":
				webActions.waitForVisibility(txt_Email, filterName);
				webActions.assertDisplayed(txt_Email, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				actualDefaultValue=webActions.getValue(txt_Email, filterName);
				break;
			case "Location":
				webActions.waitForClickAbility(dd_Location, filterName);
				webActions.assertDisplayed(dd_Location, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				actualDefaultValue = webActions.getValue(li_Location, filterName);
				break;
			case "Patient Type":
				webActions.waitForClickAbility(dd_PatientType, filterName);
				webActions.assertDisplayed(dd_PatientType, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				actualDefaultValue = webActions.getValue(lis_PatientType, filterName);
				break;
			case "Hospital Service":
				webActions.waitForVisibility(txt_HospitalService, filterName);
				webActions.assertDisplayed(txt_HospitalService, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				actualDefaultValue=webActions.getValue(txt_HospitalService, filterName);
				break;
			case "Diagnosis":
				webActions.waitForVisibility(txt_Diagnosis, filterName);
				webActions.assertDisplayed(txt_Diagnosis, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				actualDefaultValue=webActions.getValue(txt_Diagnosis, filterName);
				break;
			case "Procedure":
				webActions.waitForVisibility(txt_Procedure, filterName);
				webActions.assertDisplayed(txt_Procedure, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				actualDefaultValue=webActions.getValue(txt_Procedure, filterName);
				break;
			case "Admitting Provider":
				webActions.waitForVisibility(txt_AdmittingProvider, filterName);
				webActions.assertDisplayed(txt_AdmittingProvider, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				actualDefaultValue=webActions.getText(txt_AdmittingProvider, filterName);
				break;
			case "Referring Provider":
				webActions.waitForVisibility(txt_ReferringProvider, filterName);
				webActions.assertDisplayed(txt_ReferringProvider, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				actualDefaultValue=webActions.getText(txt_ReferringProvider, filterName);
				break;
			case "Visit Status":
				webActions.waitForClickAbility(dd_VisitStatus, filterName);
				webActions.assertDisplayed(dd_VisitStatus, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				actualDefaultValue = webActions.getValue(li_VisitStatus, filterName);
				break;
			case "Financial Class":
				webActions.waitForClickAbility(dd_FinancialClass, filterName);
				webActions.assertDisplayed(dd_FinancialClass, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				actualDefaultValue = webActions.getValue(li_FinancialClass, filterName);
				break;
			case "Primary Insurance":
				webActions.waitForClickAbility(dd_PrimaryInsurance, filterName);
				webActions.assertDisplayed(dd_PrimaryInsurance, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				actualDefaultValue = webActions.getValue(li_PrimaryInsurance, filterName);
				break;
			case "Secondary Insurance":
				webActions.waitForClickAbility(dd_SecondaryInsurance, filterName);
				webActions.assertDisplayed(dd_SecondaryInsurance, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				actualDefaultValue = webActions.getValue(li_SecondaryInsurance, filterName);
				break;
			case "Tertiary Insurance":
				webActions.waitForClickAbility(dd_TertiaryInsurance, filterName);
				webActions.assertDisplayed(dd_TertiaryInsurance, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				actualDefaultValue = webActions.getValue(li_TertiaryInsurance, filterName);
				break;
			case "Event Type":
				webActions.waitForClickAbility(dd_EventType, filterName);
				webActions.assertDisplayed(dd_EventType, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				actualDefaultValue = webActions.getValue(li_EventType, filterName);
				break;
			case "Employee":
				webActions.waitForPageLoaded();
				webActions.waitForClickAbility(dd_Employee, filterName);
				webActions.assertDisplayed(dd_Employee, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				webActions.waitForPageLoaded();
				webActions.waitForJSandJQueryToLoad();
				actualDefaultValue = webActions.getValue(li_Employee, filterName);
				break;
			}
			report.reportInfo("Actual Default value in '"+filterName+"' field: " + actualDefaultValue);
			report.reportInfo("Expected Default value in '"+filterName+"' field: " + expectedValue);
			if(expectedValue.contentEquals(actualDefaultValue)){
				report.reportPass("Verified default value in '"+filterName+"' field successfully");
			}else{
				throw new Exception("Fail to verify the default value in '"+filterName+"' field and actual displayed value is: "+actualDefaultValue);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	public String enterOrSelectDatainFilter(String filterName,String testData) throws Exception{
		switch (filterName) {
		case "Gender":
			testData=selectGender(testData);
			break;
		case "Date of Birth":
			enterDateofBirth(testData);
			break;
		case "SSN":
			selectColumn(filterName);
			enterSSN(testData);
			//testData=testData.substring(7, 11);
			break;
		case "Phone Number":
			selectColumn(filterName);
			enterPhoneNumber(testData);
			testData=testData.replaceAll("[-()]","");
			break;
		case "Email":
			selectColumn(filterName);
			enterEmail(testData);
			break;
		case "Location":
			selectLocation(testData); 
			break;
		case "Patient Type":
			selectColumn(filterName);
			selectPatientType(testData); 
			break;
		case "Appointment Number":
			selectColumn(filterName);
			break;
		case "Hospital Service":
			selectColumn(filterName);
			enterHospitalService(testData);
			break;
		case "Diagnosis":
			selectColumn(filterName);
			enterDiagnosis(testData); 
			break;
		case "Procedure":
			selectColumn(filterName);
			enterProcedure(testData);
			break;
		case "Admitting Provider":
			selectColumn(filterName);
			enterAdmittingProvider(testData);
			break;
		case "Referring Provider":
			selectColumn(filterName);
			enterReferringProvider(testData);
			break;
		case "Visit Status":
			selectVisitStatus(testData);
			break;
		case "Financial Class":
			selectColumn(filterName);
			selectFinancialClass(testData);
			break;
		case "Primary Insurance":
			selectPrimaryInsurance(testData); 
			break;
		case "Secondary Insurance":
			selectSecondaryInsurance(testData); 
			break;
		case "Tertiary Insurance":
			selectTertiaryInsurance(testData); 
			break;
		case "Event Type":
			selectEventType(testData); 
			break;
		case "Employee":
			selectEmployee(testData); 
			webActions.waitForPageLoaded();
			break;
		}
		return testData;
	}

	public void verifyDatainAllColunms(String filterName,String testData,String columnName) throws Exception{
		try {
			webActions.waitForPageLoaded();
			waitforAllRows();
			selectFilterName(filterName);
			webActions.waitForPageLoaded();
			testData=enterOrSelectDatainFilter(filterName,testData);
			webActions.waitForPageLoaded();
			waitforAllRows();
			ArrayList<String>actData=webActions.getGridData(grid_Header,grid_Results,columnName,filterName);
			ArrayList<String> unmatchedData=webActions.isFullArrayMatchWithData(actData, testData);
			report.reportInfo("Expected data: "+testData);
			if(unmatchedData.size()==0){
				report.reportPass("All Data verified successfully and displayed data is: " + actData);
			}else{
				throw new Exception("Data verification failed, and unmatched data is: "+unmatchedData);
			}
		} catch (Exception e) {
			report.reportFail(e.toString());
		}
	}


	public void verifyAppliedFilterValues(String filterName,String testData,String pageName) throws Exception{
		try {
			StringBuilder errorCount= new StringBuilder();
			webActions.waitForPageLoaded();
			waitforAllRows();
			selectFilterName(filterName);
			selectColumn(filterName);
			enterEmail(testData);
			webActions.waitForPageLoaded();
			waitforAllRows();
			int actResultsCount=defaultsearch.getResultsCount();
			webActions.waitForPageLoaded();
			if ("Service Tracker".contentEquals(pageName)) {
				webActions.click(lnk_ServiceTracker, "Service Tracker");
				webActions.waitForVisibility(lbl_ServiceDepartment, "Service Department");
				webActions.waitForPageLoaded();
				String actualName = webActions.getText(lbl_ServiceDepartment, "Service Department");
				if ("Service Department".contentEquals(actualName)) {
					report.reportPass("User is navigated to Service Tracker page and verified field: " + actualName);
				} else {
					errorCount.append("User is not navigated to Service Tracker page");
				}
				webActions.click(lnk_AccountSearch, "Account Search");
			}
			else{
				webActions.waitForClickAbility(lnk_AccountNumber, "Account Number");
				webActions.click(lnk_AccountNumber, "Account Number");
				webActions.waitForClickAbility(lbl_AllData, "All Data");
				String actualName=webActions.getText(lbl_AllData, "All Data");
				if ("All Data".contentEquals(actualName)) {
					report.reportPass("User is navigated to All Data page and verified field: " + actualName);
				} else {
					errorCount.append("User is not navigated to All Data pag");
				}
				webActions.click(lnk_AccountSearch1, "Account Search");
			}
			webActions.waitForPageLoaded();
			int expResultsCount=defaultsearch.getResultsCount();
			if(actResultsCount==expResultsCount/*unmatchData.size()==0*/){
				report.reportPass("Search Results count is matched when user came back from "+pageName+" page");
			}
			else{
				errorCount.append("Search Results count is not matched when User came back from "+pageName+" page: ");
			}			
			try {
				webActions.waitForVisibility(txt_Email, filterName,15);
				webActions.assertDisplayed(txt_Email, filterName);
				report.reportInfo("Applied filter field is displayed successfully when User came back from "+pageName+" page");
			} catch (Exception e) {
				errorCount.append("Applied filter field is not displayed when User came back from "+pageName+" page");
			}
			if(errorCount.length()==0){
				report.reportPass("Verified Applied Filter Values successfully when user is come back from "+pageName+" page");
			}
			else{
				throw new Exception("Failed Applied Filter Values Verification and Error are: "+errorCount);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void applyFilterforMultipleFields(String filter1,String genderName,String filter2,String emailID) throws Exception{
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.waitForPageLoaded();
			waitforAllRows();
			selectFilterName(filter1);
			selectFilterName(filter2);
			webActions.waitForPageLoaded();
			selectColumn(filter2);
			webActions.waitForVisibility(txt_Email, "Email");
			webActions.sendKeys(txt_Email, emailID, "Email");
			genderName=selectGender(genderName);
			waitforAllRows();
			ArrayList<String>actGenger=webActions.getGridData(grid_Header,grid_Results,"Patient",filter1);
			ArrayList<String> unmatchedGenders=webActions.isFullArrayMatchWithData(actGenger, genderName);

			if(unmatchedGenders.size()==0){
				report.reportPass("All Gender names verified successfully and displayed data is: " + actGenger);
			}else{
				unmatch.append("Failed to verify the Genders, and unmatched data is: "+unmatchedGenders);
			}	
			ArrayList<String>actEmails=webActions.getGridData(grid_Header,grid_Results,"Patient",filter2);
			ArrayList<String> unmatchedEmails=webActions.isFullArrayMatchWithData(actEmails, emailID);
			if(unmatchedEmails.size()==0){
				report.reportPass("All emailID's verified successfully and displayed data is: " + actEmails);
			}else{
				unmatch.append("Failed to verify the emailID's, and unmatched data is: "+unmatchedEmails);
			}
			if(unmatch.length()==0){
				report.reportPass("Successfully verified the data when apply filters with Gender and Email");
			}
			else {
				throw new Exception("Data verification failed when apply filters with Gender and Email and unmatched data is: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}



	public void waitforAllRows(){
		try {
			webActions.waitForVisibility(tbl_AccountSearch_Results, "All Rows",8);
			//webActions.waitForVisibilityOfAllElements(tbl_AccountSearch_Results, "Account Search Table");
		} catch (Exception e) {
		}
	}

	public String addSpaceBetweenCapitalLetters(String text)
	{
		return text.replaceAll("(\\p{Ll})(\\p{Lu})","$1 $2");
	}

	public String removeSpaceBetweenCapitalLetters(String text)
	{
		return text.replaceAll("\\s(?=[A-Z])|(?<=\\s)\\s+", "");

	}
	
	@SuppressWarnings("unchecked")
	public void updateAccountSearchFilterJSON(String genderType) throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(FILTERJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject appointmentObject = (JSONObject) jsonObject.get("Appointment");
				try {
					String number = rest.getUniqueNumber();
					newNum = "A" + number;
					JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
					JSONObject tenantPatient = (JSONObject) msg.get(0);
					tenantPatient.put("TenantPatientId", newNum);
					tenantPatient = (JSONObject) msg.get(2);
					tenantPatient.put("TenantPatientId", newNum);
					String test = (String) tenantPatient.get("TenantPatientId");					
				} catch (Exception e) {
					log.error("Failed to update tenant patiend id", e);
					e.printStackTrace();
				}
				try {
					// update tenantPatientVisitId and visitDate
					/*JSONArray visit = (JSONArray) visitObject.get("TenantPatientVisitIdentifier");
					JSONObject patientVisit = (JSONObject) visit.get(0);
					patientVisit.put("TenantPatientVisitId", newNum);*/					
					visitObject.put("AccountNumber", newNum);
					visitObject.put("VisitNumber", newNum);
					Object tt = visitObject.get("VisitDate");
					String updatedDate = rest.updatedDateAppointment(tt);
					visitObject.put("VisitDate", updatedDate);

				} catch (Exception e) {
					log.error("Failed to update tenantPatientVisitId and visitDate", e);
					e.printStackTrace();
				}
				
				try {
					// update appointmentStartDate and appointmentEndDate
					Object appointment = appointmentObject.get("AppointmentStartDate");
					String updatedDates = rest.updatedDateAppointment(appointment);
					appointmentObject.put("AppointmentStartDate", updatedDates);
					appointmentObject.put("AppointmentEndDate", updatedDates);
					String appointmentId = rest.getUniqueAppointmentNumber();				
					appointmentObject.put("AppointmentId", appointmentId);
				} catch (Exception e) {
					log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
					e.printStackTrace();
				}
				
				try{
					JSONObject patientGender = (JSONObject)	patientObject.get("PatientGender");
					if ("Other".contentEquals(genderType)) {
						patientGender.put("GenderCode", "O");
						patientGender.put("GenderDescription", genderType);
					}else if("Unknown".contentEquals(genderType)){
						patientGender.put("GenderCode", "U");
						patientGender.put("GenderDescription", genderType);
					}
					else if("Male".contentEquals(genderType)){
						patientGender.put("GenderCode", "M");
						patientGender.put("GenderDescription", genderType);
					}
					else if("Female".contentEquals(genderType)){
						patientGender.put("GenderCode", "F");
						patientGender.put("GenderDescription", genderType);
					}
				}
				catch (Exception e){
					log.error("Failed to update patient Gender infomartion", e);
					e.printStackTrace();
				}
				
			FileWriter file = new FileWriter(FILTERJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}


	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(btn_Filter);
	}

}