package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.PatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.SignalRPage;
import com.ipas.hf.web.pages.ipasPages.SimpleSearchPage;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class SignalRSteps {
	
	Login logIn = new Login();
	//HomePage home = new HomePage();
	//SimpleSearchPage search=new SimpleSearchPage();
	SignalRPage signalR   =new SignalRPage();
	//RestActions rest      =new RestActions();
	PatientVisitPage visit=new PatientVisitPage();


	

	@Then("Get the Value from response body of service tracker and get value of {string}")
	public void get_the_Value_from_response_body_of_service_tracker_and_get_value_of(String visitId) {
		signalR.visitId=logIn.getVisitIdFromResponse(visitId);
		System.out.println("First Name of patient with Visit ID before json modification :" +signalR.visitId);
	}
	
	@Then("Select filters with JSON facility value as {string}  serviceDepartmeant as {string} and visitDate as {string}")
	public void select_filters_with_JSON_facility_and_serviceDepartment(String facility,String pocCode,String visitDate) throws Exception
	{
		signalR.facilityName=logIn.getVisitIdFromResponse(facility);
		signalR.pocCode=logIn.getVisitIdFromResponse(pocCode);
		signalR.Date=logIn.getVisitIdFromResponse(visitDate);
		String array[] = signalR.Date.split("T");
		signalR.visitDate=array[0];
		signalR.selectFilters(signalR.facilityName,signalR.pocCode,signalR.visitDate);
	}
	
	@Then("Select filters with facility value as {string}  serviceDepartmeant as {string} and visitDate as {string}")
	public void select_filters_with_facility_and_serviceDepartment(String facility,String pocCode,String visitDate) throws Exception
	{
		signalR.selectFilters(facility,pocCode,visitDate);
	}
	
	@Then("Validate the Patient visit card details with Patient Visit ID as {string} and {string}")
	public void Validate_the_Patient_visit_card_details_with_Patient_Visit_ID(String visitId,String fieldname) throws Exception{
		signalR.visitId=logIn.getVisitIdFromResponse(visitId);
		System.out.println("AccountNumber "+signalR.visitId);
		Thread.sleep(5000);
		signalR.verifyVisitCardResults(signalR.visitId,fieldname);
	}
	
	@Then("Select all columns from columns dropdown")
	public void Select_all_columns_from_columns_dropdown(DataTable columnNames)
    {
		signalR.columnSelectionServiceTracker(columnNames,true);
    }
	
	@Then("Compare the Modified Patient Details on service board after posting the json as {string} and {string}")
	public void Compare_the_Modified_Patient_Details_on_service_board_after_posting_the_json(String visitId,String fieldname) throws Exception{
		signalR.visitId=logIn.getVisitIdFromResponse(visitId);
		System.out.println("Account Number "+signalR.visitId);
		signalR.CompareVisitCard(signalR.visitId,fieldname);
	}
	
	@Then("Validate the patient visit card not displayed with visitID as {string}")
	public void Validate_the_patient_visit_card_not_displayed_with_visitID_as(String visitId) throws Exception{
		signalR.visitId=logIn.getVisitIdFromResponse(visitId);
		signalR.ValidateVisitCardisNotDisplayed(signalR.visitId);
	}
	
	@Then("Verify the display of Visit Card with AccountNum as {string} under Intake Status : Status as {string}")
	public void verify_the_display_of_Visit_Card_under_new_Intake_Status_VisitID_as_and_Status_as(String visitId,String expStatusName) throws Exception {
		signalR.pageRefresh();
		visit.serviceTrackerPageValidation();
		signalR.visitId=logIn.getVisitIdFromResponse(visitId);
		signalR.verifyCardCountUnderStatus(expStatusName, visitId);
	}
	
	@Then("Verify the visit card is displayed on service tracker board with account number as {string}")
	public void verify_the_visit_card_is_displayed_on_service_tracker_board(String accountnum) throws Exception{
		signalR.accountNum=logIn.getVisitIdFromResponse(accountnum);
		signalR.VerifyVisitCardDisplayed(signalR.accountNum);
	}
}