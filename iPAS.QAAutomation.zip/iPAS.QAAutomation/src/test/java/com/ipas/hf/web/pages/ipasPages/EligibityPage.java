package com.ipas.hf.web.pages.ipasPages;

import org.openqa.selenium.support.ui.ExpectedCondition;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.dbutilities.SqlQueries;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

import com.ipas.hf.web.pages.BasePage;

public class EligibityPage extends BasePage{

	private JSONObject jsonObject;
	private static final String ELIGIBILITY = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\Eligibility.json";
	private StepLogging log = StepLogging.getLoggingObject();

	@FindBy(linkText="Payer Maintenance Configuration")
	private WebElement lnk_PayerMintenace;

	@FindBy(xpath="//select[@name='payerCode']/../input")
	private WebElement dd_PayerConfigure;

	@FindBy(xpath="//a[(text()='Facility Config.')]")
	private WebElement btn_FacilityConfig;

	@FindBy(xpath="//ejs-textbox[@placeholder='Type Facility Name']/span/input")
	private WebElement txt_TypeFacilityName;

	@FindBy(xpath="//table[@class='e-table']/tbody/tr/td/div")
	private List<WebElement> li_FacilityNames;

	@FindBy(xpath="//table[@class='e-table']/tbody/tr[1]/td/div")
	private WebElement lbl_FacilityName;

	@FindBy(xpath="//ejs-switch[@formcontrolname='autoEligibility']")
	private WebElement switch_AutoEligibility;

	@FindBy(xpath="//ejs-switch[@formcontrolname='rte']")
	private WebElement switch_RTE;

	@FindBy(xpath="//ejs-switch[@formcontrolname='cascadesarch']")
	private WebElement switch_CascadeSearch;

	@FindBy(xpath="//button[(text()='Save')]")
	private WebElement btn_Save;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs; 

	@FindBy(xpath="//img[@alt='iPAS Logo']")
	private WebElement img_Home;

	@FindBy(linkText="Account Search")
	private WebElement lnk_AccountSearch;

	@FindBy(xpath="//tr[@class='e-columnheader']/th")
	private List<WebElement> tr_AccountSearch_Results;

	@FindBy(xpath="//ipas-eligibility-verification-panel//ejs-accordion/div/div[2]/div/div/div/div[3]//p[2]")
	private WebElement lbl_AutoRunStatus;

	@FindBy(xpath="//ipas-eligibility-verification-panel//ejs-accordion/div/div[2]/div/div/div/div[3]//p[2]")
	private WebElement lbl_NotRunStatus;

	@FindBy(linkText="Eligibility Verification")
	private WebElement lnk_Eligibility;

	@FindBy(xpath="//div[contains(text(),'Manual')]")
	private WebElement tab_Manual;

	@FindBy(xpath="//div[contains(text(),'Secondary - ')]")
	private WebElement tab_Secondary;

	@FindBy(xpath="//div[contains(text(),'Tertiary - ')]")
	private WebElement tab_Tertiary;

	String tab_Insurance="//div[contains(text(),'";
	String tab_Insurance1=" - ')]";

	@FindBy(xpath="//ejs-dropdownlist[@placeholder='Select Payer']/span/input")
	private WebElement dd_Payer;

	@FindBy(xpath="//ejs-dropdownlist[@id='searchSubject']/span/input")
	private WebElement dd_SearchSubject;

	@FindBy(xpath="//ejs-dropdownlist[@formcontrolname='searchCriteria']/span/input")
	private WebElement dd_SearchCriteria;

	@FindBy(xpath="//ejs-dropdownlist[@id='serviceCode']/span/input")
	private WebElement dd_ServiceCode;

	@FindBy(xpath="//ejs-textbox[@id='insuredId']/span/input")
	private WebElement txt_InsuredId;

	@FindBy(xpath="//a[contains(text(),'Run')]")
	private WebElement btn_RunManual;

	@FindBy(xpath="(//button[@type='button'])[2]")
	private WebElement btn_Run;

	@FindBy(xpath="//div[@id='content']/div[1]/div[2]")
	private WebElement lbl_EligibilityStatus_2;

	@FindBy(xpath="//span[contains(@class,'status')]")
	private WebElement lbl_EligibilityStatus;

	@FindBy(xpath="//div[contains(@class,'e-tab-wrap')]")
	private List<WebElement> tabs_AllInsurances;

	@FindBy(xpath="//button[(text()='Recheck Eligibility')]")
	private WebElement btn_RecheckEligibility;


	@FindBy(xpath="//ipas-eligibility-verification-panel//ejs-accordion/div/div[2]/div/div/div[2]//financial-clearance-status/img")
	private WebElement atr_FinancialClearanceStatus;

	@FindBy(xpath="//ipas-eligibility-verification-panel//ejs-accordion/div/div")
	private List<WebElement>lbl_AllInsurances;

	@FindBy(xpath="//div[contains(text(),'Secondary - ')]/../div[1]/img")
	private WebElement atr_SecondaryInsuranceFinClrStatus;

	String atr_InsuranceFinClrStatus="//div[contains(text(),'";
	String atr_InsuranceFinClrStatus1=" - ')]/../div[1]/img";

	@FindBy(xpath="//button[@data-toggle='dropdown']")
	private WebElement btn_OtherOptions;

	@FindBy(xpath="//a[contains(text(),'History')]")
	private WebElement btn_History;
	
	@FindBy(xpath="//a[contains(text(),'View Raw 271')]")
	private WebElement btn_ViewRaw271;
	
	@FindBy(xpath="//a[contains(text(),'Export')]")
	private WebElement btn_Export;
	
	@FindBy(xpath="//*[@id='sidebar']//print-preview-button-strip//div/cr-button[1]")
	private WebElement btn_ExportSave;
	
	@FindBy(xpath="//*[@id='sidebar']//print-preview-button-strip//div/cr-button[2]")
	private WebElement btn_ExportCancel;

	@FindBy(xpath="//tr[@role='row']/td[1]/div")
	private WebElement lbl_DateinHistory;

	@FindBy(xpath="//tr[@role='row']/td/div")
	private List<WebElement> lbl_HistoryData;

	@FindBy(xpath="//span[text()='×']")
	private WebElement btn_CloseXHistory;

	@FindBy(xpath="//input[@formcontrolname='subscriberMiddleInitial']")
	private WebElement txt_SubscriberMiddleName;

	@FindBy(xpath="//input[@placeholder='Group Number']")
	private WebElement txt_GroupNumber;

	@FindBy(xpath="//a[@class='panel-title ng-star-inserted']")
	private WebElement lbl_HistoricalEligibilityRunTitle;

	@FindBy(xpath="//a[contains(text(),'Most Recent')]")
	private WebElement btn_MostRecent;

	@FindBy(xpath="//p[@class='panel-title ng-star-inserted']")
	private WebElement lbl_EligibilityTitle;

	@FindBy(xpath="//button[contains(text(),'Associate')]")
	private WebElement btn_Associate;

	@FindBy(xpath="//span[contains(text(),'Secondary - ')]")
	private WebElement rd_SecondaryInsurance;

	@FindBy(xpath="//span[contains(text(),'Tertiary - ')]")
	private WebElement rd_TertiaryInsurance;

	@FindBy(xpath="//a[contains(text(),'Associate')]")
	private WebElement btn_Associate_Popup;

	String radio_Associate ="//span[contains(text(),'";
	String radio_Associate1 =" - ')]";

	@FindBy(xpath="//p[text()=' Eligibility Verification ']/img")
	private WebElement lbl_ModuleStatus;

	@FindBy(xpath="//a[(text()='Eligibility Verification')]/../financial-clearance-status/img")
	private WebElement atr_ModuleFinanceClearanceStatus;

	@FindBy(xpath="//a[@class='breadcrum ng-star-inserted']")
	private WebElement lnk_AccountSearch_breadcrum;

	@FindBy(xpath="//table[@id='asgrid_content_table']/tbody/tr/td[9]/div/div")
	private List<WebElement> li_AllModuleNameNeedsAttention;

	@FindBy(xpath="//ipas-eligibility-verification-panel//ejs-accordion/div/div[2]/div/div//div/financial-clearance-status")
	private List<WebElement> lbl_AllInsurancesFinClear;

	@FindBy(xpath="(//div[@class='insurance-content ng-star-inserted'])[2]/div/div[1]")
	private List<WebElement> lbl_MedicareFields;

	@FindBy(xpath="(//div[@class='insurance-content ng-star-inserted'])[2]/div/div[2]")
	private List<WebElement> lbl_MedicareValues;
	
	@FindBy(xpath="(//div[@class='insurance-content ng-star-inserted'])[2]/div/div[1]")
	private List<WebElement> lbl_NonMedicareFields;

	@FindBy(xpath="(//div[@class='insurance-content ng-star-inserted'])[2]/div/div[2]")
	private List<WebElement> lbl_NonMedicareValues;
	
	@FindBy(xpath="//div[@class='pay-section']/div/div[1]")
	private List<WebElement> lbl_PaySectionFields;
	
	@FindBy(xpath="//div[@class='pay-section']/div/div[2]")
	private List<WebElement> lbl_PaySectionValues;
	
	@FindBy(xpath="//span[@class='panel-title']")
	private List<WebElement> lbl_MedicareAllPanels;
	
	@FindBy(xpath="//span[(text()='Benefits, Part A')]/../../../..//child::ejs-accordion/div/div/div/div/div/div/div[1]")
	private List<WebElement> lbl_MedicarePanelNames_BenefitsPartA;
	
	@FindBy(xpath="//span[(text()='Benefits, Part A')]/../../../..//child::ejs-accordion/div/div/div/div/div[2]")
	private List<WebElement> lbl_MedicarePanelStatus_BenefitsPartA;

	@FindBy(xpath="//span[(text()='Benefits, Part B')]/../../../..//child::ejs-accordion/div/div/div/div/div/div/div[1]")
	private List<WebElement> lbl_MedicarePanelNames_BenefitsPartB;
	
	@FindBy(xpath="//span[(text()='Benefits, Part B')]/../../../..//child::ejs-accordion/div/div/div/div/div[2]")
	private List<WebElement> lbl_MedicarePanelStatus_BenefitsPartB;
	
	@FindBy(xpath="//span[(text()='Benefits')]/../../../..//child::ejs-accordion/div/div/div/div/div/div/div[1]")
	private List<WebElement> lbl_NonMedicarePanelNames_Benefits;
	
	@FindBy(xpath="//span[(text()='Benefits')]/../../../..//child::ejs-accordion/div/div/div/div/div[2]")
	private List<WebElement> lbl_NonMedicarePanelStatus_Benefits;
	
	@FindBy(xpath="//table[@id='asgrid_content_table']/tbody/tr[1]/td[10]/div/a")
	private WebElement lnk_NeedsAttention;

	@FindBy(xpath="//div[@class='modal-body row']/div/ul/li")
	private WebElement tbl_AllModules;
	
	@FindBy(xpath="//div[@id='detailContent']/p")
	private WebElement lbl_HeaderName;
	
	@FindBy(xpath="//a[@title='Eligibility']")
	private WebElement lnk_Eligibility_AllModules;
	
	@FindBy(xpath="//input[@id='patientVisitDate_input']")
	private WebElement txt_VisitDate;

	@FindBy(xpath="//div[contains(@class,'mandatory')]")
	private WebElement lbl_MandatoryMessage;
	
	@FindBy(xpath="//label[@for='patientVisitDate']")
	private WebElement lbl_VisitDate;

	
	
	private RestActions rest = new RestActions();
	PaymentFacilitatorPage payment=new PaymentFacilitatorPage();
	Login login=new Login();

	public EligibityPage() {
		PageFactory.initElements(driver, this);
	}


	public void clickPayerMintenace() throws Exception{
		webActions.waitAndClick(lnk_PayerMintenace, "Payer Mintenace");
		webActions.waitForPageLoaded();
		webActions.waitForJSandJQueryToLoad();
		webActions.waitForVisibility(dd_PayerConfigure, "Payer Configure");
	}

	public void navigateFacilityConfig() throws Exception{
		webActions.sendKeys(dd_PayerConfigure, "Eligibility", "Payer Configure");
		webActions.waitAndClick(btn_FacilityConfig, "Facility Config");
		try {
			webActions.waitForVisibilityOfAllElements(li_FacilityNames, "Facility Names");
		} catch (Exception e) {
		}
	}

	public void autoEligibilityTurnOnAndTrunOff(String facilityName,String runStatus) throws Exception{
		try {
			clickPayerMintenace();
			navigateFacilityConfig();
			webActions.click(txt_TypeFacilityName, "Type Facility Name");
			webActions.sendKeys(txt_TypeFacilityName, facilityName, "Type Facility Name");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(lbl_FacilityName, "Facility Config");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibility(switch_AutoEligibility, "Auto Eligibility");
			String actAutoEligibility=webActions.getAttributeValue(switch_AutoEligibility, "aria-checked", "Auto Eligibility");
			if("AutoRunYes".contentEquals(runStatus)){
				if(!actAutoEligibility.contentEquals("true")){
					webActions.click(switch_AutoEligibility, "Auto Eligibility");
				}
			}else if("AutoRunNo".contentEquals(runStatus)){
				if(actAutoEligibility.contentEquals("true")){
					webActions.click(switch_AutoEligibility, "Auto Eligibility");
					webActions.waitForPageLoaded();
					String actRTE=webActions.getAttributeValue(switch_RTE, "aria-checked", "RTE");
					if("false".contentEquals(actRTE)){
						webActions.click(switch_RTE, "RTE");
						webActions.waitForPageLoaded();
					}
				}
			}
			webActions.click(btn_Save, "Save");
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent=titleContent[1];
			if("Request processed successfully.".contentEquals(actContent)){
				report.reportPass("Successfully saved the settings: "+msg);
			}else{
				report.reportFail("Failed to save the settings", true);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage(), true);
		}
	}

	public void navigateAccountSearch() throws Exception{
		webActions.waitForPageLoaded();
		webActions.waitAndClick(img_Home, "Home");
		webActions.waitForPageLoaded();
		webActions.waitAndClick(lnk_AccountSearch, "Account Search");
		webActions.waitForPageLoaded();
		webActions.waitForJSandJQueryToLoad();
	}

	public void navigateAllDataPage(){
		try {
			String accountNumber=getDataFromJSONFile("AccountNumber");
			payment.searchAccountNuberinAccountSearchPage(accountNumber);
			webActions.waitForPageLoaded();
			try{
				webActions.waitForVisibilityOfAllElements(lbl_AllInsurances, "All Insurances");
			}catch (Exception e){
			}
		} catch (Exception e) {

		}
	}

	public void simpleSearchInAccountSearch(String accountNumber){
		try {
			payment.searchAccountNuberinAccountSearchPage(accountNumber);
			webActions.waitForPageLoaded();
			try{
				webActions.waitForVisibilityOfAllElements(lbl_AllInsurances, "All Insurances");
			}catch (Exception e){
			}
		} catch (Exception e) {

		}

	}

	public void verifyEligibilityRunStatusifAutoRunisOn(String expAutoStatus) throws Exception{
		try {
			webActions.waitForPageLoaded();
			navigateAllDataPage();
			webActions.waitForPageLoaded();
			expAutoStatus=expAutoStatus+payment.getCurrentDateandTime();
			String actStatus=webActions.getText(lbl_AutoRunStatus, "Auto Run Status");
			report.reportInfo("Actual text: "+actStatus);
			report.reportInfo("Expected text: "+expAutoStatus);
			if(actStatus.contains(expAutoStatus)){
				report.reportPass("Successfully verified the Eligibility run status when Auto run is Turn On");
			}else{
				report.reportFail("Failed to verify the Eligibility run status when Auto run is Turn On");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyEligibilityRunStatusifAutoRunisOff(String expAutoStatus) throws Exception{
		try {
			navigateAllDataPage();
			webActions.waitForPageLoaded();
			String actStatus=webActions.waitAndGetText(lbl_AutoRunStatus, "Auto Run Status");
			report.reportInfo("Actual text: "+actStatus);
			report.reportInfo("Expected text: "+expAutoStatus);
			if(actStatus.contains(expAutoStatus)){
				report.reportPass("Successfully verified the Eligibility run status when Auto run is Turn Off");
			}else{
				report.reportFail("Failed to verify the Eligibility run status when Auto run is Turn Off");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyInsuranceStatusinDataBase(int sequenceNumber){
		try {
			String dbStatus=SqlQueries.getInsuranceStatus(getPatientVisitId(), sequenceNumber);
			if(dbStatus.contains("1") || dbStatus.contains("2") || dbStatus.contains("3")){
				report.reportPass("Successfully verified status in data base and status is: "+dbStatus);
			}else{
				report.reportFail("Failed to verify the status in data base and status is: "+dbStatus);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}

	public void verifyInsuranceStatusinDataBase1(int sequenceNumber,String expStatus){
		try {
			String dbStatus=SqlQueries.getInsuranceStatus(getPatientVisitId(), sequenceNumber);
			if(dbStatus.contains(expStatus)){
				report.reportPass("Successfully verified status in data base and status is: "+dbStatus);
			}else{
				report.reportFail("Failed to verify the status in data base and status is: "+dbStatus);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyInsuranceStatusinDataBase(int sequenceNumber,String expStatus){
		try {
			String dbStatus=SqlQueries.getInsuranceStatus(getPatientVisitId(), sequenceNumber);
			if(dbStatus.contains(expStatus)){
				report.reportPass("Successfully verified status in data base and status is: "+dbStatus);
			}else{
				report.reportFail("Failed to verify the status in data base and status is: "+dbStatus);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String getDatabaseFinanceClearanceStatus(String dbStatus){
		if(dbStatus.contentEquals("1")){
			dbStatus="Needs Attention";
		}else if(dbStatus.contentEquals("2")){
			dbStatus="Review";
		}else if(dbStatus.contentEquals("3")){
			dbStatus="Clear";
		}
		return dbStatus;
	}





	public void runManualEligibilityProcessinManualTab(DataTable testData) throws Exception{
		try {
			StringBuilder unmatch=new StringBuilder();
			navigateAllDataPage();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_Eligibility, "Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(tabs_AllInsurances, "All Insurances");
			webActions.waitAndClick(tab_Manual, "Manual");
			webActions.waitForPageLoaded();
			webActions.sendKeys(dd_Payer, getTestData(testData, "Payer"), "Payer");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchSubject, getTestData(testData, "Search Subject"), "Search Subject");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchCriteria, getTestData(testData, "Search Criteria"), "Search Criteria");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(dd_ServiceCode, "Service Code");
			webActions.sendKeys(dd_ServiceCode, getTestData(testData, "Service Code"), "Service Code");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(txt_InsuredId, "Service Code");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_InsuredId, getTestData(testData, "InsuredId"), "InsuredId");
			webActions.waitForPageLoaded();
			webActions.click(btn_RunManual, "Run");
			try {
				String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
				String[] titleContent=msg.split("\\n");
				String actContent=titleContent[1];
				if("Request processed successfully.".contentEquals(actContent)){
					report.reportPass("Successfully verified the Manual Run Eligibility process: "+msg);
				}else{
					report.reportFail("Failed to verify the Manual Run Eligibility process",true);
					unmatch.append("Failed to verify the Manual Run Eligibility process");
				}
			} catch (Exception e) {

			}
			webActions.waitForPageLoaded();
			String actStatus=webActions.waitAndGetText(lbl_EligibilityStatus, "Eligibility Status");
			if(actStatus.contains(getTestData(testData, "Status"))){
				report.reportPass("Successfully verified the Manual Run Eligibility process and status is: "+actStatus);
			}else{
				report.reportFail("Failed to verify the Manual Run Eligibility process and status is: "+actStatus);
				unmatch.append("Failed to verify the Eligibility status: "+actStatus);
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}

	public void runManualEligibilityProcessForAllInsurance(DataTable testData) throws Exception{
		try {
			StringBuilder unmatch=new StringBuilder();
			navigateAllDataPage();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_Eligibility, "Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(tabs_AllInsurances, "All Insurances");
			String insuranceType=getTestData(testData, "Insurance Type");
			/*if("Primary".contentEquals(insuranceType)){

			}else if("Secondary".contentEquals(insuranceType)){
				webActions.waitAndClick(tab_Secondary, "Secondary");
			}else if("Tertiary".contentEquals(insuranceType)){
				webActions.waitAndClick(tab_Tertiary, "Tertiary");
			}else if("Manual".contentEquals(insuranceType)){
				webActions.waitAndClick(tab_Manual, "Manual");
			}*/
			driver.findElement(By.xpath(tab_Insurance+insuranceType+tab_Insurance1)).click();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			//webActions.sendKeys(dd_Payer, getTestData(testData, "Payer"), "Payer");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchSubject, getTestData(testData, "Search Subject"), "Search Subject");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchCriteria, getTestData(testData, "Search Criteria"), "Search Criteria");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(dd_ServiceCode, "Service Code");
			webActions.sendKeys(dd_ServiceCode, getTestData(testData, "Service Code"), "Service Code");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(txt_InsuredId, "InsuredId");
			webActions.clearValue(txt_InsuredId, "InsuredId");
			webActions.sendKeys(txt_InsuredId, getTestData(testData, "InsuredId"), "InsuredId");
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_Run, "Run");
			webActions.click(btn_Run, "Run");
			try {
				String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
				String[] titleContent=msg.split("\\n");
				String actContent=titleContent[1];
				if("Request processed successfully.".contentEquals(actContent)){
					report.reportPass("Successfully verified the alert message after Manual Run for the "+insuranceType+" Insurance: "+msg);
				}else{
					report.reportFail("Failed to verify the alert message after Manual Run for the "+insuranceType+" Insurance: "+msg);
				}
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			String actStatus=webActions.waitAndGetText(lbl_EligibilityStatus, "Eligibility Status");
			if(actStatus.contains(getTestData(testData, "Status"))){
				report.reportPass("Successfully verified the Status after Manual Run for the "+insuranceType+" Insurance: "+actStatus);
			}else{
				report.reportFail("Failed to verify the Status after Manual Run for the "+insuranceType+" Insurance:: "+actStatus,true);
				unmatch.append("Failed to verify the status after Manual Run for the "+insuranceType+" Insurance:: "+actStatus);
			}
			//String actFCStatus=webActions.getAttributeValue(atr_SecondaryInsuranceFinClrStatus, "src","Secondary Insurance Finance Clear Status");
			String actFCStatus=getInsuranceFinanceClearance(insuranceType);
			String expFCStatus=getExpectedModuleandFinanceClearanceStatus(getTestData(testData, "Finance Clearance Status"));
			if(actFCStatus.contains(expFCStatus)){
				report.reportPass("Successfully verified the Insurance Financial Clearance Status");
			}else{
				report.reportFail("Failed to verify the Insurance Financial Clearance status: "+actStatus,true);
				unmatch.append("Failed to verify the Insurance Financial Clearance status: "+actStatus);
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void recheckEligibility(DataTable testData) throws Exception{
		try {
			StringBuilder unmatch=new StringBuilder();
			navigateAllDataPage();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_Eligibility, "Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(tabs_AllInsurances, "All Insurances");
			webActions.waitAndClick(tab_Secondary, "Secondary");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_RecheckEligibility, "Recheck Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			//webActions.sendKeys(dd_Payer, getTestData(testData, "Payer"), "Payer");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchSubject, getTestData(testData, "Search Subject"), "Search Subject");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchCriteria, getTestData(testData, "Search Criteria"), "Search Criteria");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(dd_ServiceCode, "Service Code");
			webActions.sendKeys(dd_ServiceCode,getTestData(testData, "Service Code"), "Service Code");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(txt_InsuredId, "Service Code");
			webActions.clearValue(txt_InsuredId, "InsuredId");
			webActions.sendKeys(txt_InsuredId, getTestData(testData, "InsuredId"), "InsuredId");
			webActions.waitForPageLoaded();
			webActions.click(btn_Run, "Run");
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent=titleContent[1];
			if("Request processed successfully.".contentEquals(actContent)){
				report.reportPass("Successfully verified the alert message after Recheck Eligibility for the Secondary Insurance: "+msg);
			}else{
				report.reportFail("Failed to verify the alert message after Recheck Eligibility for the Secondary Insurance: "+msg,true);
				unmatch.append("Failed to verify the alert message after Recheck Eligibility for the Secondary Insurance: "+msg);
			}
			webActions.waitForPageLoaded();
			String actStatus=webActions.waitAndGetText(lbl_EligibilityStatus, "Eligibility Status");
			if(actStatus.contains(getTestData(testData, "Status"))){
				report.reportPass("Successfully verified the Eligibility Status after Recheck Eligibility for the Secondary Insurance: "+actStatus);
			}else{
				report.reportFail("Failed to verify the Eligibility Status after Recheck Eligibility for the Secondary Insurance: "+actStatus,true);
				unmatch.append("Failed to verify the Eligibility Status after Recheck Eligibility for the Secondary Insurance: "+actStatus);
			}
			String actFCStatus=getInsuranceFinanceClearance(getTestData(testData, "Insurance Type"));
			String expFCStatus=getExpectedModuleandFinanceClearanceStatus(getTestData(testData, "Finance Clearance Status"));
			if(actFCStatus.contains(expFCStatus)){
				report.reportPass("Successfully verified the Insurance Financial Clearance Status ");
			}else{
				report.reportFail("Failed to verify the Insurance Financial Clearance status: "+actStatus,true);
				unmatch.append("Failed to verify the Insurance Financial Clearance status: "+actStatus);
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyInsuranceStatus(String expStatus) throws Exception{
		try {
			navigateAllDataPage();
			webActions.waitForPageLoaded();
			String actStatus=webActions.getAttributeValue(atr_FinancialClearanceStatus, "src", "Financial Clearance Status");
			if(actStatus.contains(expStatus)){
				report.reportPass(" Successfully verified the Clear status for the first visit");
			}else{
				report.reportFail("Unable to verify Reuse eligibility process due to first visit not in the clear status");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyReuseEligibilityRunStatus(String expStatus) throws Exception{
		try {
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibilityOfAllElements(payment.tbl_AccountSearch_Results, "AccountSearch Results");
			} catch (Exception e) {
			}
			webActions.clearValue(payment.txt_Search, "Simple Search");
			webActions.waitForPageLoaded();
			navigateAllDataPage();
			webActions.waitForPageLoaded();
			expStatus=expStatus+payment.getCurrentDateandTime();
			String actStatus=webActions.getText(lbl_AutoRunStatus, "Auto Run Status");
			report.reportInfo("Actual text: "+actStatus);
			report.reportInfo("Expected text: "+expStatus);
			if(actStatus.contains(expStatus)){
				report.reportPass("Successfully verified the Reuse Eligibility status");
			}else{
				report.reportFail("Failed to verify the Reuse Eligibility status");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void cascadeSearchTurnOnAndTrunOff(String facilityName,String cascadeSearchStatus) throws Exception{
		try {
			clickPayerMintenace();
			navigateFacilityConfig();
			webActions.click(txt_TypeFacilityName, "Type Facility Name");
			webActions.sendKeys(txt_TypeFacilityName, facilityName, "Type Facility Name");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(lbl_FacilityName, "Facility Config");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();

			if("Yes".contentEquals(cascadeSearchStatus)){
				webActions.waitForVisibility(switch_AutoEligibility, "Auto Eligibility");
				String actAutoEligibility=webActions.getAttributeValue(switch_AutoEligibility, "aria-checked", "Auto Eligibility");
				if(actAutoEligibility.contentEquals("false")){
					webActions.click(switch_AutoEligibility, "Auto Eligibility");
					webActions.waitForPageLoaded();
				}
				webActions.waitForVisibility(switch_CascadeSearch, "Cascade Search");
				String actCascadeSearch=webActions.getAttributeValue(switch_CascadeSearch, "aria-checked", "Cascade Search");
				if ("false".contentEquals(actCascadeSearch)) {
					webActions.click(switch_CascadeSearch, "Cascade Search");
				}
			}else if("No".contentEquals(cascadeSearchStatus)){
				webActions.waitForVisibility(switch_AutoEligibility, "Auto Eligibility");
				String actAutoEligibility=webActions.getAttributeValue(switch_AutoEligibility, "aria-checked", "Auto Eligibility");
				if(actAutoEligibility.contentEquals("true")){
					webActions.click(switch_AutoEligibility, "Auto Eligibility");
					webActions.waitForPageLoaded();
				}
			}
			webActions.waitForPageLoaded();
			webActions.click(btn_Save, "Save");

			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent=titleContent[1];
			if("Request processed successfully.".contentEquals(actContent)){
				report.reportPass("Successfully saved the settings: "+msg);
			}else{
				report.reportFail("Failed to save the settings", true);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage(), true);
		}
	}

	public void verifyAutoCasCadeSearch(){
		try {
			webActions.waitForPageLoaded();
			navigateAllDataPage();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_Eligibility, "Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(tabs_AllInsurances, "All Insurances");
			webActions.waitAndClick(tab_Secondary, "Secondary");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_OtherOptions, "Other Options");
			webActions.waitAndClick(btn_History, "History");
			String actDate=webActions.waitAndGetText(lbl_DateinHistory, "History Date");
			String expDate=webActions.getSystemCurrentDate();
			ArrayList<String>eligibilityHistoryData=webActions.getDatafromWebTable(lbl_HistoryData);
			if(actDate.contains(expDate)){
				report.reportPass("Successfully verified the Cascade Search functionality: "+eligibilityHistoryData);
			}else{
				report.reportFail("Failed to veify the Cascade Search functionality");
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyManualCasCadeSearch(DataTable testData) throws Exception{
		try {
			StringBuilder unmatch=new StringBuilder();
			navigateAllDataPage();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_Eligibility, "Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(tabs_AllInsurances, "All Insurances");
			String insuranceType=getTestData(testData, "Insurance Type");
			if ("Manual".contentEquals(insuranceType)) {
				webActions.click(tab_Manual, "Manual");
			}else{
				driver.findElement(By.xpath(tab_Insurance + insuranceType + tab_Insurance1)).click();
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			if ("Manual".contentEquals(insuranceType)) {
				webActions.sendKeys(dd_Payer, getTestData(testData, "Payer"), "Payer");
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchSubject, getTestData(testData, "Search Subject"), "Search Subject");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchCriteria, getTestData(testData, "Search Criteria"), "Search Criteria");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(dd_ServiceCode, "Service Code");
			webActions.sendKeys(dd_ServiceCode, getTestData(testData, "Service Code"), "Service Code");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.clearValue(txt_SubscriberMiddleName, "Middle Name");
			webActions.sendKeys(txt_SubscriberMiddleName, getTestData(testData, "MiddleName"), "Middle Name");
			webActions.scrollBarHandle(txt_InsuredId, "InsuredId");
			webActions.clearValue(txt_InsuredId, "InsuredId");
			webActions.sendKeys(txt_InsuredId, getTestData(testData, "InsuredId"), "InsuredId");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_GroupNumber, getTestData(testData, "GroupNumber"), "Group Number");
			webActions.waitForPageLoaded();
			if("Manual".contentEquals(insuranceType)){
				webActions.scrollBarHandle(btn_RunManual, "Run");
				webActions.click(btn_RunManual, "Run");
			}else{
				webActions.scrollBarHandle(btn_Run, "Run");
				webActions.click(btn_Run, "Run");
			}
			try {
				String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
				String[] titleContent=msg.split("\\n");
				String actContent=titleContent[1];
				if("Request processed successfully.".contentEquals(actContent)){
					report.reportPass("Successfully verified the alert message when doing Cascade search: "+msg);
				}else{
					report.reportFail("Failed to verify the alert message when doing Cascade search: "+msg,true);
					unmatch.append("Failed to verify the alert message when doing Cascade search");
				}
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_OtherOptions, "Other Options");
			webActions.waitAndClick(btn_History, "History");
			String actDate=webActions.waitAndGetText(lbl_DateinHistory, "History Date");
			String expDate=webActions.getSystemCurrentDate();
			ArrayList<String>eligibilityHistoryData=webActions.getDatafromWebTable(lbl_HistoryData);
			if(actDate.contains(expDate)){
				report.reportPass("Successfully verified the Cascade Search functionality in "+insuranceType+" tab: "+eligibilityHistoryData);
			}else{
				report.reportFail("Failed to veify the Cascade Search functionality in "+insuranceType+" tab: "+eligibilityHistoryData);
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String getTestData(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}

	@SuppressWarnings("unchecked")
	public void updateEligibilityJSON1() throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(ELIGIBILITY);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			try {
				String number = rest.getUniqueNumber();
				newNum = "A" + number;
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(0);
				tenantPatient.put("TenantPatientId", newNum);

				tenantPatient = (JSONObject) msg.get(3);
				tenantPatient.put("TenantPatientId", newNum);

				String test = (String) tenantPatient.get("TenantPatientId");	
			} catch (Exception e) {
				log.error("Failed to update tenant patiend id", e);
				e.printStackTrace();
			}
			try {
				visitObject.put("AccountNumber", newNum);
				visitObject.put("VisitNumber", newNum);
				Object tt = visitObject.get("VisitDate");
				String updatedDate = rest.updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);

			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}

			FileWriter file = new FileWriter(ELIGIBILITY);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void updateEligibilityJSON(String type) throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(ELIGIBILITY);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			try {
				String number = rest.getUniqueNumber();
				newNum = "A" + number;
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(0);
				tenantPatient.put("TenantPatientId", newNum);

				tenantPatient = (JSONObject) msg.get(3);
				tenantPatient.put("TenantPatientId", newNum);

				String test = (String) tenantPatient.get("TenantPatientId");	
			} catch (Exception e) {
				log.error("Failed to update tenant patiend id", e);
				e.printStackTrace();
			}
			try {
				visitObject.put("AccountNumber", newNum);
				visitObject.put("VisitNumber", newNum);
				Object tt = visitObject.get("VisitDate");
				String updatedDate = rest.updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);

			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}

			try {
				JSONArray insuranceArray = (JSONArray) jsonObject.get("Insurance");
				JSONObject insurance = (JSONObject) insuranceArray.get(1);
				JSONObject insured = (JSONObject) insurance.get("insured");
				if(("Cascade".contentEquals(type))||("Retry".contentEquals(type))){
					insurance.put("insurancePlanId", "1456");
					insurance.put("insurancePlanName", "Aetna");
					
					insured.put("insuredid", "TC004001");
					
				}else if("Medicare".contentEquals(type)){
					insurance.put("insurancePlanId", "10109");
					insurance.put("insurancePlanName", "Medicare Part A");
					
					insured.put("insuredid", "TC001017");
				}
				else{
					insurance.put("insurancePlanId", "1456");
					insurance.put("insurancePlanName", "Aetna");
					
					insured.put("insuredid", "TC001010");
				}
			} catch (Exception e) {
				log.error("Failed to update insuredid and insurancePlanId and insurancePlanName", e);
				e.printStackTrace();
			}

			FileWriter file = new FileWriter(ELIGIBILITY);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void updateEligibilityJSONforReuse() throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(ELIGIBILITY);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");

			try {
				newNum = rest.getUniqueNumber();
				newNum = "A" + newNum;
				visitObject.put("AccountNumber", newNum);
				visitObject.put("VisitNumber", newNum);

			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}

			FileWriter file = new FileWriter(ELIGIBILITY);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}

	public String getDataFromJSONFile(String fieldName){
		String expectedResponseValue=null;
		try {
			FileReader reader = new FileReader(ELIGIBILITY);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");

			if(fieldName.contentEquals("AccountNumber")){
				/*JSONArray data = (JSONArray) visitObject.get("TenantPatientVisitIdentifier");
				JSONObject tenantPatient = (JSONObject) data.get(0);							
				expectedResponseValue= (String) tenantPatient.get("TenantPatientVisitId");*/
				expectedResponseValue = (String) visitObject.get("AccountNumber");	
			}
		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return expectedResponseValue;
	}
	
	@SuppressWarnings("unchecked")
	public void updatePatientResponsibilityEstimateinJSON(String estimateAmount) throws ParseException {
		try {
			FileReader reader = new FileReader(ELIGIBILITY);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");

			try {
				visitObject.put("PatientResponsibilityEstimate",estimateAmount);
			} catch (Exception e) {
				log.error("Failed to update PatientResponsibilityEstimate", e);
				e.printStackTrace();
			}

			FileWriter file = new FileWriter(ELIGIBILITY);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}

	public void navigateManualTab() throws Exception{
		try {
			navigateAllDataPage();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_Eligibility, "Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(tabs_AllInsurances, "All Insurances");
			webActions.waitAndClick(tab_Manual, "Manual");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
		}
	}


	public void recheckEligibilityinManualTab(DataTable testData) throws Exception{
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_RecheckEligibility, "Recheck Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_Payer, getTestData(testData, "Payer"), "Payer");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchSubject, getTestData(testData, "Search Subject"), "Search Subject");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchCriteria, getTestData(testData, "Search Criteria"), "Search Criteria");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(dd_ServiceCode, "Service Code");
			webActions.sendKeys(dd_ServiceCode,getTestData(testData, "Service Code"), "Service Code");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(txt_InsuredId, "Service Code");
			webActions.sendKeys(txt_InsuredId, getTestData(testData, "InsuredId"), "InsuredId");
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_RunManual, "Service Code");
			webActions.waitAndClick(btn_RunManual, "Run");
			webActions.waitForPageLoaded();
			try {
				String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
				String[] titleContent=msg.split("\\n");
				String actContent=titleContent[1];
				if("Request processed successfully.".contentEquals(actContent)){
					report.reportPass("Successfully verified the alert message after Recheck Eligibility for the Insurance: "+msg);
				}else{
					report.reportFail("Failed to verify the alert message after Recheck Eligibility for the Insurance: "+msg,true);
					unmatch.append("Failed to verify the alert message after Recheck Eligibility for the Insurance: "+msg);
				}
			} catch (Exception e) {

			}
			webActions.waitForPageLoaded();
			String actStatus=webActions.waitAndGetText(lbl_EligibilityStatus, "Eligibility Status");
			if(actStatus.contentEquals(getTestData(testData, "Status"))){
				report.reportPass("Successfully verified the Eligibility Status after Recheck Eligibility: "+actStatus);
			}else{
				report.reportFail("Failed to verify the Eligibility Status after Recheck Eligibility: "+actStatus,true);
				unmatch.append("Failed to verify the Eligibility Status after Recheck Eligibility: "+actStatus);
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void navigateHistoricalEligibilityRunandMostRecentRun (DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			webActions.waitAndClick(btn_OtherOptions, "Other Options");
			webActions.waitAndClick(btn_History, "History");
			String actDate=webActions.waitAndGetText(lbl_DateinHistory, "History Date");
			webActions.waitAndClick(lbl_DateinHistory, "Historical Response in History");
			String actHistoricalEligibilityRunTitle=webActions.waitAndGetText(lbl_HistoricalEligibilityRunTitle, "Historical Eligibility Run Title");
			if(expData.get(0).contentEquals(actHistoricalEligibilityRunTitle)){
				report.reportPass("Successfully navigated to Historical Eligibility: "+actHistoricalEligibilityRunTitle);
			}else{
				report.reportFail("Failed to navigate to Historical Eligibility: "+actHistoricalEligibilityRunTitle,true);
				unmatch.append("Failed to navigate to Historical Eligibility: "+actHistoricalEligibilityRunTitle);
			}
			webActions.waitAndClick(btn_OtherOptions, "Other Options");
			webActions.waitAndClick(btn_MostRecent, "MostRecent");

			String actEligibilityTitle=webActions.waitAndGetText(lbl_EligibilityTitle, "Eligibility Run Title");
			if(expData.get(1).contentEquals(actEligibilityTitle)){
				report.reportPass("Successfully navigated to Most Recent Eligibility: "+actEligibilityTitle);
			}else{
				report.reportFail("Failed to navigate to Most Recent Eligibility: "+actEligibilityTitle,true);
				unmatch.append("Failed to navigate to Most Recent Eligibility: "+actEligibilityTitle);
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void associateResponsetoInsurance(String insuranceType){
		try {
			webActions.waitAndClick(btn_Associate, "Associate");
			webActions.waitForClickAbility(btn_Associate_Popup, "Associate_Popup");
			driver.findElement(By.xpath(radio_Associate+insuranceType+radio_Associate1)).click();
			webActions.waitAndClick(btn_Associate_Popup, "Associate_Popup");
			try {
				String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
				String[] titleContent=msg.split("\\n");
				String actContent=titleContent[1];
				if("Request processed successfully.".contentEquals(actContent)){
					report.reportPass("Successfully verified the alert message after Associate Response to Insurance: "+msg);
				}else{
					report.reportFail("Failed to verify the alert message after Associate Response to Insurance: "+msg,true);
				}
			} catch (Exception e) {
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyCascadeSearch(String insuranceType){
		try {
			webActions.waitAndClick(btn_OtherOptions, "Other Options");
			webActions.waitAndClick(btn_History, "History");
			String actDate=webActions.waitAndGetText(lbl_DateinHistory, "History Date");
			String expDate=webActions.getSystemCurrentDate();
			ArrayList<String>eligibilityHistoryData=webActions.getDatafromWebTable(lbl_HistoryData);
			if(actDate.contains(expDate)){
				report.reportPass("Successfully verified the Cascade Search functionality in "+insuranceType+" tab: "+eligibilityHistoryData);
			}else{
				report.reportFail("Failed to veify the Cascade Search functionality in "+insuranceType+" tab");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void recheckEligibilityAfterManualRun(DataTable testData) throws Exception{
		try {
			StringBuilder unmatch=new StringBuilder();
			String insuranceType=getTestData(testData, "Insurance Type");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_RecheckEligibility, "Recheck Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			//webActions.sendKeys(dd_Payer, getTestData(testData, "Payer"), "Payer");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchSubject, getTestData(testData, "Search Subject"), "Search Subject");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchCriteria, getTestData(testData, "Search Criteria"), "Search Criteria");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(dd_ServiceCode, "Service Code");
			webActions.sendKeys(dd_ServiceCode,getTestData(testData, "Service Code"), "Service Code");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(txt_InsuredId, "Service Code");
			webActions.clearValue(txt_InsuredId, "InsuredId");
			webActions.sendKeys(txt_InsuredId, getTestData(testData, "InsuredId"), "InsuredId");
			webActions.waitForPageLoaded();
			webActions.click(btn_Run, "Run");
			try {
				String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
				String[] titleContent=msg.split("\\n");
				String actContent=titleContent[1];
				if("Request processed successfully.".contentEquals(actContent)){
					report.reportPass("Successfully verified the alert message after Recheck Eligibility for the "+insuranceType+" Insurance: "+msg);
				}else{
					report.reportFail("Failed to verify the alert message after Recheck Eligibility for the "+insuranceType+" Insurance: "+msg,true);
					unmatch.append("Failed to verify the alert message after Recheck Eligibility for the "+insuranceType+" Insurance: "+msg);
				}
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			String actStatus=webActions.waitAndGetText(lbl_EligibilityStatus, "Eligibility Status");
			if(actStatus.contains(getTestData(testData, "Status"))){
				report.reportPass("Successfully verified the Status after Recheck Eligibility for the "+insuranceType+" Insurance: "+actStatus);
			}else{
				report.reportFail("Failed to verify the Status after Recheck Eligibility for the "+insuranceType+" Insurance: "+actStatus,true);
				unmatch.append("Failed to verify the Status after Recheck Eligibility for the "+insuranceType+" Insurance: "+actStatus);
			}
			String actFCStatus=getInsuranceFinanceClearance(insuranceType);
			String expFCStatus=getExpectedModuleandFinanceClearanceStatus(getTestData(testData, "Finance Clearance Status"));
			if(actFCStatus.contains(expFCStatus)){
				report.reportPass("Successfully verified the Insurance Financial Clearance Status ");
			}else{
				report.reportFail("Failed to verify the Insurance Financial Clearance status: "+actStatus,true);
				unmatch.append("Failed to verify the Insurance Financial Clearance status: "+actStatus);
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyModuleStatus(String expStatus) {
		try {
			expStatus=getExpectedModuleandFinanceClearanceStatus(expStatus);
			String actStatus=getActualModuleStatus();
			if(actStatus.contains(expStatus)){
				report.reportPass("Successfully verified the Eligibility Module status");
			}else{
				report.reportFail("Failed to verify the Eligibility Module status: "+actStatus);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String getInsuranceFinanceClearance(String insuranceType){
		return driver.findElement(By.xpath(atr_InsuranceFinClrStatus+insuranceType+atr_InsuranceFinClrStatus1)).getAttribute("src");
	}

	public String getActualModuleStatus() throws Exception{
		webActions.waitForPageLoaded();
		webActions.waitForVisibility(lbl_ModuleStatus, "Module Status", 10);
		return webActions.getAttributeValue(lbl_ModuleStatus, "src","Module Status");
	}

	public String getExpectedModuleandFinanceClearanceStatus(String extStatus){
		if(extStatus.contentEquals("Needs Attention")){
			extStatus="error";
		}else if(extStatus.contentEquals("Review")){
			extStatus="alert";
		}else if(extStatus.contentEquals("Clear")){
			extStatus="success";
		}
		return extStatus;
	}

	public void manualRunEligibilityThreeInsurances(DataTable testData) throws Exception{
		try {
			StringBuilder unmatch=new StringBuilder();
			navigateAllDataPage();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_Eligibility, "Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(tabs_AllInsurances, "All Insurances");
			driver.findElement(By.xpath(tab_Insurance+"Primary"+tab_Insurance1)).click();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			//webActions.sendKeys(dd_Payer, getTestData(testData, "Payer"), "Payer");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchSubject, getTestData(testData, "Search Subject"), "Search Subject");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchCriteria, getTestData(testData, "Search Criteria"), "Search Criteria");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(dd_ServiceCode, "Service Code");
			webActions.sendKeys(dd_ServiceCode, getTestData(testData, "Service Code"), "Service Code");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(txt_InsuredId, "InsuredId");
			webActions.clearValue(txt_InsuredId, "InsuredId");
			webActions.sendKeys(txt_InsuredId, getTestData(testData, "PrimaryInsuredId"), "InsuredId");
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_Run, "Run");
			webActions.click(btn_Run, "Run");
			try {
				String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
				String[] titleContent=msg.split("\\n");
				String actContent=titleContent[1];
				if("Request processed successfully.".contentEquals(actContent)){
					report.reportPass("Successfully verified the alert message after Manual Run for the Primary Insurance: "+msg);
				}else{
					report.reportFail("Failed to verify the alert message after Manual Run for the Primary Insurance: "+msg);
				}
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();

			driver.findElement(By.xpath(tab_Insurance+"Secondary"+tab_Insurance1)).click();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			//webActions.sendKeys(dd_Payer, getTestData(testData, "Payer"), "Payer");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchSubject, getTestData(testData, "Search Subject"), "Search Subject");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchCriteria, getTestData(testData, "Search Criteria"), "Search Criteria");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(dd_ServiceCode, "Service Code");
			webActions.sendKeys(dd_ServiceCode, getTestData(testData, "Service Code"), "Service Code");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(txt_InsuredId, "InsuredId");
			webActions.clearValue(txt_InsuredId, "InsuredId");
			webActions.sendKeys(txt_InsuredId, getTestData(testData, "SecondaryInsuredId"), "InsuredId");
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_Run, "Run");
			webActions.click(btn_Run, "Run");
			try {
				String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
				String[] titleContent=msg.split("\\n");
				String actContent=titleContent[1];
				if("Request processed successfully.".contentEquals(actContent)){
					report.reportPass("Successfully verified the alert message after Manual Run for the Secondary Insurance: "+msg);
				}else{
					report.reportFail("Failed to verify the alert message after Manual Run for the Secondary Insurance: "+msg);
				}
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();

			driver.findElement(By.xpath(tab_Insurance+"Tertiary"+tab_Insurance1)).click();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			//webActions.sendKeys(dd_Payer, getTestData(testData, "Payer"), "Payer");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchSubject, getTestData(testData, "Search Subject"), "Search Subject");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchCriteria, getTestData(testData, "Search Criteria"), "Search Criteria");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(dd_ServiceCode, "Service Code");
			webActions.sendKeys(dd_ServiceCode, getTestData(testData, "Service Code"), "Service Code");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(txt_InsuredId, "InsuredId");
			webActions.clearValue(txt_InsuredId, "InsuredId");
			webActions.sendKeys(txt_InsuredId, getTestData(testData, "TertiaryInsuredId"), "InsuredId");
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_Run, "Run");
			webActions.click(btn_Run, "Run");
			try {
				String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
				String[] titleContent=msg.split("\\n");
				String actContent=titleContent[1];
				if("Request processed successfully.".contentEquals(actContent)){
					report.reportPass("Successfully verified the alert message after Manual Run for the Tertiary Insurance: "+msg);
				}else{
					report.reportFail("Failed to verify the alert message after Manual Run for the Tertiary Insurance: "+msg);
				}
			} catch (Exception e) {
			}
			webActions.waitAndGetText(lbl_EligibilityStatus, "Status");

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyEligibilityModuleStatusinPatientVistAllDataAndAccountSearch(String expStatus){
		try {
			StringBuilder unmatch=new StringBuilder();
			expStatus=getExpectedModuleandFinanceClearanceStatus(expStatus);
			navigatePatientVistAllDataPagefromEligibilityPage();

			String actStatusinPatientVistAllData=getModuleFinanceClearanceStatusinPatientVistAllData();
			if(actStatusinPatientVistAllData.contains(expStatus)){
				report.reportPass("Successfully verified the Eligibility Module status in Patient Visit All Data page");
			}else{
				unmatch.append("Failed to verify the Eligibility Module status in Patient Visit All Data page");
				report.reportFail("Failed to verify the Eligibility Module status in Patient Visit All Data page",true);
			}
			webActions.waitAndClick(lnk_AccountSearch_breadcrum, "Account Search");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			try {
				webActions.waitForVisibilityOfAllElements(li_AllModuleNameNeedsAttention, "Module Names");
			} catch (Exception e) {
			}
			List<WebElement> moduleName=li_AllModuleNameNeedsAttention;
			String actModuleStatusAccountSearch="";
			for (WebElement webElement : moduleName) {
				String actModuleName=webElement.getText().trim();
				if(actModuleName.contentEquals("Eligibility")){
					actModuleStatusAccountSearch=webElement.findElement(By.tagName("financial-clearance-status")).findElement(By.tagName("img")).getAttribute("src");
					break;
				}
			}
			if(actModuleStatusAccountSearch.contains(expStatus)){
				report.reportPass("Successfully verified the Eligibility Module status in Account Search page");
			}else{
				unmatch.append("Failed to verify the Eligibility Module status in Account Search page");
				report.reportFail("Failed to verify the Eligibility Module status in Account Search page",true);
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void navigatePatientVistAllDataPagefromEligibilityPage(){
		String accountNumber=getDataFromJSONFile("AccountNumber");
		driver.findElement(By.linkText(accountNumber)).click();
	}

	public String getModuleFinanceClearanceStatusinPatientVistAllData() throws Exception{
		webActions.waitForPageLoaded();
		try{
			webActions.waitForVisibilityOfAllElements(lbl_AllInsurancesFinClear, "All Insurances");
		}catch (Exception e){
		}
		webActions.waitForPageLoaded();
		webActions.waitForVisibility(atr_ModuleFinanceClearanceStatus, "Module Finance Clearance Status");
		return webActions.getAttributeValue(atr_ModuleFinanceClearanceStatus, "src", "Module Finance Clearance Status");
	}


	public void verifyMedicareFieldNamesInShortPanel(DataTable testData){
		try {
			ArrayList<String>expValues=new ArrayList<String>(testData.asList());
			webActions.waitForVisibilityOfAllElements(lbl_MedicareFields, "Medicare Fields");
			ArrayList<String>actFields=webActions.getDatafromWebTable(lbl_MedicareFields);
			report.reportInfo("Medicare Fields in short panel: "+actFields);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actFields, expValues);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Medicare Fields in short panel: "+actFields);
			}else{
				report.reportFail("Failed to verify the Medicare Fields in short panel: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyMedicareValuesInShortPanel(DataTable testData){
		try {
			ArrayList<String>expValues=new ArrayList<String>(testData.asList());
			ArrayList<String>actValues=webActions.getDatafromWebTable(lbl_MedicareValues);
			report.reportInfo("Medicare values in short panel: "+actValues);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actValues, expValues);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Medicare values in short panel: "+actValues);
			}else{
				report.reportFail("Failed to verify the Medicare values in short panel: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyNonMedicareFieldNamesInShortPanel(DataTable testData){
		try {
			ArrayList<String>expValues=new ArrayList<String>(testData.asList());
			webActions.waitForVisibilityOfAllElements(lbl_NonMedicareFields, "NonMedicare Fields");
			ArrayList<String>actFields=webActions.getDatafromWebTable(lbl_NonMedicareFields);
			report.reportInfo("Non-Medicare Fields in short panel: "+actFields);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actFields, expValues);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Non-Medicare Fields in short panel: "+actFields);
			}else{
				report.reportFail("Failed to verify the Non-Medicare Fields in short panel: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyNonMedicareValuesInShortPanel(DataTable testData){
		try {
			ArrayList<String>expValues=new ArrayList<String>(testData.asList());
			ArrayList<String>actValues=webActions.getDatafromWebTable(lbl_NonMedicareValues);
			report.reportInfo("Non-Medicare values in short panel: "+actValues);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actValues, expValues);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Non-Medicare values in short panel: "+actValues);
			}else{
				report.reportFail("Failed to verify the Non-Medicare values in short panel: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void clickEligibilityVerificationLinkAndNavigateInsuranceTab(String insuranceType){
		try {
			webActions.waitAndClick(lnk_Eligibility, "Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(tabs_AllInsurances, "All Insurances");
			driver.findElement(By.xpath(tab_Insurance+insuranceType+tab_Insurance1)).click();
			webActions.waitForPageLoaded();
		} catch (Exception e) {
		}
	}
	
	public void verifyPaymentTypeFields(String insuranceType,DataTable testData){
		try {
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			webActions.waitForVisibilityOfAllElements(lbl_PaySectionFields, "PaySection Fields");
			ArrayList<String> actData=webActions.getDatafromWebTable(lbl_PaySectionFields);
			report.reportInfo("Actual PaySection Fields for "+insuranceType+" plan: "+actData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the PaySection Fields for "+insuranceType+" plan");
			}else{
				report.reportFail("Failed to verify the PaySection Fields for "+insuranceType+" plan: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void verifyPaymentTypeValues(String insuranceType,DataTable testData){
		try {
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			webActions.waitForVisibilityOfAllElements(lbl_PaySectionValues, "PaySection Values");
			ArrayList<String> actData=webActions.getDatafromWebTable(lbl_PaySectionValues);
			report.reportInfo("Actual PaySection Values for "+insuranceType+" plan: "+actData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the PaySection values for "+insuranceType+" plan");
			}else{
				report.reportFail("Failed to verify the PaySection values for "+insuranceType+" plan: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void verifyMedicarePanelHeaderNames(String insuranceType,DataTable testData){
		try {
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			webActions.waitForVisibilityOfAllElements(lbl_MedicareAllPanels, "Medicare All Panels");
			waitForRetryRun(5);
			ArrayList<String>actData=webActions.getDatafromWebTable(lbl_MedicareAllPanels);
			report.reportInfo("Expected Panel Header Names for "+insuranceType+" plan: "+expData);
			report.reportInfo("Actual Panel Header Names for "+insuranceType+" plan: "+actData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Panel Header Names for "+insuranceType+" plan");
			}else{
				report.reportFail("Failed to verify the Panel Header Names for "+insuranceType+" plan: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyMedicareBenefitsPartAPanelNamesAndStatus(DataTable testData){
		try {
			StringBuilder verification=new StringBuilder();
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			webActions.waitForVisibilityOfAllElements(lbl_MedicarePanelNames_BenefitsPartA, "MedicarePanelNames_BenefitsPartA");
			ArrayList<String>actData=webActions.getDatafromWebTable(lbl_MedicarePanelNames_BenefitsPartA);
			report.reportInfo("Actual Medicare Benefits-PartA Panel Names: "+actData);
			report.reportInfo("Expected Medicare Benefits-PartA Panel Names: "+expData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Medicare Benefits-PartA Panel Names");
			}else{
				report.reportFail("Failed to verify the Medicare Benefits-PartA Panel Names: "+unmatch,true);
				verification.append("Failed to verify the Medicare Benefits-PartA Panel Names: "+unmatch);
			}
			ArrayList<String>actStatus=webActions.getDatafromWebTable(lbl_MedicarePanelStatus_BenefitsPartA);
			report.reportInfo("Actual Medicare Benefits-PartA Panel Status: "+actStatus);
			ArrayList<String>unmatchStatus=webActions.isFullArrayMatchWithData(actStatus, "ACTIVE");
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Status for all Medicare Benefits-PartA Panels");
			}else{
				report.reportFail("Failed to verify the Status for all Medicare Benefits-PartA Panels: "+unmatchStatus,true);
				verification.append("Failed to verify the Status for all Medicare Benefits-PartA Panels: "+unmatchStatus);
			}
			if(verification.length()!=0){
				report.reportFail(""+verification);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void verifyMedicareBenefitsPartBPanelNamesAndStatus(DataTable testData){
		try {
			StringBuilder verification=new StringBuilder();
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			webActions.waitForVisibilityOfAllElements(lbl_MedicarePanelNames_BenefitsPartB, "MedicarePanelNames_BenefitsPartB");
			ArrayList<String>actData=webActions.getDatafromWebTable(lbl_MedicarePanelNames_BenefitsPartB);
			report.reportInfo("Actual Medicare Benefits-PartB Panel Names: "+actData);
			report.reportInfo("Expected Medicare Benefits-PartB Panel Names: "+expData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Medicare Benefits-PartB Panel Names");
			}else{
				report.reportFail("Failed to verify the Medicare Benefits-PartB Panel Names: "+unmatch,true);
				verification.append("Failed to verify the Medicare Benefits-PartB Panel Names: "+unmatch);
			}
			
			ArrayList<String>actStatus=webActions.getDatafromWebTable(lbl_MedicarePanelStatus_BenefitsPartB);
			report.reportInfo("Actual Medicare Benefits-PartB Panel Status: "+actStatus);
			ArrayList<String>unmatchStatus=webActions.isFullArrayMatchWithData(actStatus, "ACTIVE");
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Status for all Medicare Benefits-PartB Panels");
			}else{
				report.reportFail("Failed to verify the Status for all Medicare Benefits-PartB Panels: "+unmatchStatus,true);
				verification.append("Failed to verify the Status for all Medicare Benefits-PartB Panels: "+unmatchStatus);
			}
			if(verification.length()!=0){
				report.reportFail(""+verification);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void verifyNonMedicareBenefitsPanelNamesAndStatus(DataTable testData){
		try {
			StringBuilder verification=new StringBuilder();
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			webActions.waitForVisibilityOfAllElements(lbl_NonMedicarePanelNames_Benefits, "NonMedicarePanelNames_Benefits");
			ArrayList<String>actData=webActions.getDatafromWebTable(lbl_NonMedicarePanelNames_Benefits);
			report.reportInfo("Actual Non-Medicare Benefits Panel Names: "+actData);
			report.reportInfo("Expected Non-Medicare Benefits Panel Names: "+expData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Non-Medicare Benefits Panel Names");
			}else{
				report.reportFail("Failed to verify the Non-Medicare Benefits Panel Names: "+unmatch,true);
				verification.append("Failed to verify the Non-Medicare Benefits Panel Names: "+unmatch);
			}
			
			ArrayList<String>actStatus=webActions.getDatafromWebTable(lbl_NonMedicarePanelStatus_Benefits);
			report.reportInfo("Actual Non-Medicare Benefits Panel Status: "+actStatus);
			ArrayList<String>unmatchStatus=webActions.isFullArrayMatchWithData(actStatus, "ACTIVE");
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Status for all Non-Medicare Benefits Panels");
			}else{
				report.reportFail("Failed to verify the Status for all Non-Medicare Benefits Panels: "+unmatchStatus,true);
				verification.append("Failed to verify the Status for all Non-Medicare Benefits Panels: "+unmatchStatus);
			}
			if(verification.length()!=0){
				report.reportFail(""+verification);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void navigateAccountSearchRetryRun() throws Exception{
		webActions.waitForPageLoaded();
		webActions.waitAndClick(img_Home, "Home");
		webActions.waitForPageLoaded();
		waitForRetryRun(120);
		webActions.waitAndClick(lnk_AccountSearch, "Account Search");
		webActions.waitForPageLoaded();
		webActions.waitForJSandJQueryToLoad();
		waitForRetryRun(120);
		webActions.waitAndClick(img_Home, "Home");
		waitForRetryRun(70);
		webActions.waitAndClick(lnk_AccountSearch, "Account Search");
	}
	
	public void verifyEligibilityRetryRunStatus(String expStatus) throws Exception{
		try {
			webActions.waitForPageLoaded();
			navigateAllDataPage();
			webActions.waitForPageLoaded();
			expStatus=expStatus+payment.getCurrentDateandTime();
			String actStatus=webActions.getText(lbl_AutoRunStatus, "Run Status");
			report.reportInfo("Actual text: "+actStatus);
			report.reportInfo("Expected text: "+expStatus);
			if(actStatus.contains(expStatus)){
				report.reportPass("Successfully verified the Eligibility Retry run status");
			}else{
				report.reportFail("Failed to verify the Eligibility Retry run status");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void verifyExportEligibility(){
		try {
			webActions.waitForPageLoaded();
			navigateAllDataPage();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_Eligibility, "Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(tabs_AllInsurances, "All Insurances");
			webActions.waitAndClick(tab_Secondary, "Secondary");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_OtherOptions, "Other Options");
			webActions.waitAndClick(btn_Export, "Export");
			webActions.waitForPageLoaded();
			//webActions.isDisplayed(btn_ExportCancel, "Cancel");
			report.reportPass("Successfully verified the the Export Eligibility functionality");
		} catch (Exception e) {
			report.reportFail("Failed to veify the Export Eligibility: "+e);
		}
	}

	//String accountNumber=getDataFromJSONFile("AccountNumber");
	
	public void navigateEligibilityVerificationLongPanelFromAllModulesPopup (){
		try {
			String accountNumber=getDataFromJSONFile("AccountNumber");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			login.simpleSearch(accountNumber);
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_NeedsAttention, "Needs Attention");
			webActions.waitForPageLoaded();
			webActions.waitAndGetText(lnk_Eligibility_AllModules, "Eligibility");
			//webActions.waitForVisibility(lnk_Eligibility_AllModules, "Eligibility");
			webActions.waitAndClick(lnk_Eligibility_AllModules, "Eligibility");
			webActions.waitForPageLoaded();
			String actName=webActions.waitAndGetText(lbl_HeaderName, "Header Name");
			if(actName.contentEquals("Eligibility Verification")){
				report.reportPass("Successfully navigated to Eligibility Verification long panel from All Modules popup in Account Search");
			}else{
				report.reportFail("Failed to navigate to Eligibility Verification long panel from All Modules popup in Account Search");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void verifyValidationMessagesInVisitDate(DataTable testData){
		try {
			ArrayList<String>expData=new ArrayList<String>(testData.asList());
			StringBuffer verify=new StringBuffer();
			webActions.waitForPageLoaded();
			navigateAllDataPage();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_Eligibility, "Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(tabs_AllInsurances, "All Insurances");
			webActions.waitAndGetText(btn_Run, "Run");
			webActions.waitForVisibility(txt_VisitDate, "Visit Date",10);
			String actVisitDate=webActions.getAttributeValue(txt_VisitDate, "value", "Visit Date");
			if(webActions.getSystemCurrentDate().contains(actVisitDate)){
				report.reportPass("Successfully verified the display of default visit date");
			}else{
				report.reportFail("Fail to verify the display of default visit date",true);
				verify.append("Fail to verify the display of default visit date");
			}
			waitForRetryRun(1);
			webActions.clearValue(txt_VisitDate, "Visit Date");
			webActions.click(lbl_VisitDate, "Visit Date");
			String actVisitDateisRequired=webActions.waitAndGetText(lbl_MandatoryMessage, "Mandatory Message");
			
			if(expData.get(0).contentEquals(actVisitDateisRequired)){
				report.reportPass("Successfully verified the Visit Date is required message");
			}else{
				report.reportFail("Fail to verify the Visit Date is required message",true);
				verify.append("Fail to verify the Visit Date is required message");
			}
			waitForRetryRun(1);
			webActions.clearValue(txt_VisitDate, "Visit Date");
			waitForRetryRun(1);
			webActions.sendKeys(txt_VisitDate, webActions.getPreviousDate(3), "Visit Date");
			webActions.click(lbl_VisitDate, "Visit Date");
			actVisitDateisRequired=webActions.waitAndGetText(lbl_MandatoryMessage, "Mandatory Message");
			if(expData.get(1).contentEquals(actVisitDateisRequired)){
				report.reportPass("Successfully verified the message if user enter Past date");
			}else{
				report.reportFail("Fail to verify the message if user enter Past date",true);
				verify.append("Fail to verify the message if user enter Past date");
			}
			
			webActions.clearValue(txt_VisitDate, "Visit Date");
			waitForRetryRun(1);
			webActions.sendKeys(txt_VisitDate, webActions.getNextDate(3), "Visit Date");
			webActions.click(lbl_VisitDate, "Visit Date");
			actVisitDateisRequired=webActions.waitAndGetText(lbl_MandatoryMessage, "Mandatory Message");
			if(expData.get(2).contentEquals(actVisitDateisRequired)){
				report.reportPass("Successfully verified the message if user enter Future date");
			}else{
				report.reportFail("Fail to verify the message if user enter Future date",true);
				verify.append("Fail to verify the message if user enter Future date");
			}
			
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
			
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void waitForRetryRun(int seconds){
		try {
			Thread.sleep(seconds*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public String getPatientVisitId(){
		String patientVisitId = rest.getStringValueFromResponse("$..patientVisitId");
		patientVisitId=replaceAll(patientVisitId);
		return patientVisitId;
	}
	public String replaceAll(String input){
		return input.replaceAll("[\\[\\]\"]", "");
	}

	public void runEligibility(DataTable testData) throws Exception{
		try {
			StringBuilder unmatch=new StringBuilder();			
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_Eligibility, "Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(tabs_AllInsurances, "All Insurances");
			webActions.waitForPageLoaded();
			Thread.sleep(2000);
			//webActions.clickAction(tab_SecondaryWitghoutInsuarnce, "Secondary");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_RecheckEligibility, "Recheck Eligibility");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();		
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchSubject, getTestData(testData, "Search Subject"), "Search Subject");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(dd_SearchCriteria, getTestData(testData, "Search Criteria"), "Search Criteria");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(dd_ServiceCode, "Service Code");
			webActions.sendKeys(dd_ServiceCode,getTestData(testData, "Service Code"), "Service Code");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.scrollBarHandle(txt_InsuredId, "Service Code");
			webActions.clearValue(txt_InsuredId, "InsuredId");
			webActions.sendKeys(txt_InsuredId, getTestData(testData, "InsuredId"), "InsuredId");
			webActions.waitForPageLoaded();
			webActions.click(btn_Run, "Run");
			String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent=titleContent[1];
			if("Request processed successfully.".contentEquals(actContent)){
				report.reportPass("Successfully verified the alert message after Recheck Eligibility for the Secondary Insurance: "+msg);
			}else{
				report.reportFail("Failed to verify the alert message after Recheck Eligibility for the Secondary Insurance: "+msg,true);
				unmatch.append("Failed to verify the alert message after Recheck Eligibility for the Secondary Insurance: "+msg);
			}
			webActions.waitForPageLoaded();
			String actStatus=webActions.waitAndGetText(lbl_EligibilityStatus, "Eligibility Status");
			if(actStatus.contains(getTestData(testData, "Status"))){
				report.reportPass("Successfully verified the Eligibility Status after Recheck Eligibility for the Secondary Insurance: "+actStatus);
			}else{
				report.reportFail("Failed to verify the Eligibility Status after Recheck Eligibility for the Secondary Insurance: "+actStatus,true);
				unmatch.append("Failed to verify the Eligibility Status after Recheck Eligibility for the Secondary Insurance: "+actStatus);
			}			
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}