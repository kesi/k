package com.ipas.hf.web.steps;



import com.ipas.hf.web.pages.ipasPages.DisplayEmployeeOnSTFullPagePage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class DisplayEmployeeOnSTFullPageSteps {
	DisplayEmployeeOnSTFullPagePage employeeOnSTFPage = new DisplayEmployeeOnSTFullPagePage();

	@Then("Verify the data in ST FullPage Status History")
	public void verify_the_data_in_ST_FullPage_Status_History(DataTable data) throws Exception {
		employeeOnSTFPage.verifyDataOnSTFullPageStatusHistory(data);
	}	

	@Then("Verify the display of Manual under MovedBy column in Status History")
	public void verify_the_display_of_Manual_under_MovedBy_column_in_Status_History() throws Exception {
		employeeOnSTFPage.verifyManualText();
	}

	@Then("Verify Status changed Date and Time")
	public void verify_Status_changed_Date_and_Time() throws Exception {
		employeeOnSTFPage.verifyCurrentDate();
	}


}
