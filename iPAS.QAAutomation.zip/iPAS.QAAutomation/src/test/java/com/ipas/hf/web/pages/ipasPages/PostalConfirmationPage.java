package com.ipas.hf.web.pages.ipasPages;

import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class PostalConfirmationPage extends BasePage {
	Login logIn=new Login();

	@FindBy(xpath = "//app-ipas-postal-short-pannel//ejs-accordion//span/div/a")
	private WebElement txt_PostalPanelTitle;

	@FindBy(xpath = "//div[contains(text(),'Address Not Found')]")
	private WebElement txt_AddressNotFoundInShortPanel;

	@FindBy(xpath = "//app-ipas-postal-short-pannel//financial-clearance-status/img")
	private WebElement img_PostalShortPanelModuleStatus;

	@FindBy(xpath="//app-ipas-postal-short-pannel//ejs-accordion//div[@class='e-toggle-icon']/span")
	private WebElement icon_PostalExpandCollapse; 

	@FindBy(xpath="//ipas-postal-details/div[@class='details-container']/div")
	private List<WebElement> lbl_PostalFullPanel; 

	@FindBy(xpath="//ipas-breadcrumb/div/span")
	private List<WebElement> lbl_iPASBreadcrumb;

	@FindBy(xpath="//app-ipas-postal-short-pannel//div[@class='last-run-info']/p")
	private WebElement txt_PostalShortLastRunBy;

	@FindBy(xpath="//ipas-postal-details//div[@class='date ng-star-inserted']")
	private WebElement txt_PostalFullPanelLastRunBy;

	@FindBy(xpath="//a[contains(text(),'History')]")
	private WebElement btn_PostalFullPanelHistory;

	@FindBy(xpath="//a[contains(text(),'New Request')]")
	private WebElement btn_PostalFullPanelNewRequest;

	@FindBy(xpath="//div[@class='section flex']/p")
	private WebElement lbl_PostalFullPanelSectionName;

	@FindBy(xpath = "//ipas-postal-details//div[@class='title']")
	private WebElement txt_PostalFullPanelTitle;

	@FindBy(xpath = "//ipas-postal-details//financial-clearance-status/img")
	private WebElement img_PostalFullPanelModuleStatus;

	@FindBy(xpath="(//div[@class='modal-content']/form)[3]/div")
	private List<WebElement> lbl_PostalFullPanelRequestWindow;

	@FindBy(xpath = "//span[contains(text(),'New Request')]")
	private WebElement txt_PostalNewRequestWindowTitle;

	@FindBy(xpath="(//div[@class='modal-body'])[2]//label")
	private List<WebElement> lbl_PostalFullPanelRequestWindowFields;

	@FindBy(xpath="//button[contains(text(),'Send Request')]")
	private WebElement btn_PostalNewRequestWindow;

	@FindBy(xpath="(//button[contains(text(),'Cancel')])[2]")
	private WebElement btn_PostalNewRequestWindowCancel;

	@FindBy(xpath="(//div[@class='modal-body'])[2]//ejs-textbox/span/input")
	private List<WebElement> lbl_PostalFullPanelRequestWindowFieldsInput;

	@FindBy(xpath="//p[contains(text(),'Street Address is required.')]")
	private WebElement lbl_PostalNewRequestWindowStreetMandatory;

	@FindBy(xpath="//p[contains(text(),'City is required.')]")
	private WebElement lbl_PostalNewRequestWindowCityMandatory;

	@FindBy(xpath="//p[contains(text(),'State is required.')]")
	private WebElement lbl_PostalNewRequestWindowStateMandatory;

	@FindBy(xpath="(//button[@class='close'])[3]")
	private WebElement btn_PostalNewRequestWindowCross;

	@FindBy(xpath="//app-ipas-postal-short-pannel//div[@class='panel-Area ng-star-inserted']/ul/li/div[1]")
	private WebElement lbl_PostalShrotZip;

	@FindBy(xpath="//app-ipas-postal-short-pannel//div[@class='panel-Area ng-star-inserted']/ul/li/div[2]")
	private WebElement lbl_PostalShrotZipCode;

	@FindBy(xpath="//div[contains(text(),'Data elements did not match')]")
	private WebElement lbl_PostalShrotDataElement;

	@FindBy(xpath="//div[@class='imgSpec']//financial-clearance-status/img")
	private WebElement lbl_PostalShrotDataElementStatus;

	@FindBy(xpath="//div/p[@class='description']")
	private WebElement lbl_PostalFullDataElement;

	@FindBy(xpath="//div[@class='icon']//financial-clearance-status/img")
	private WebElement lbl_PostalFullDataElementStatus;

	@FindBy(xpath="//h6[contains(text(),'Confirmation Response')]")
	private WebElement lbl_PostalFullDataElementResponseName;

	@FindBy(xpath="//li/p[@class='title']")
	private List<WebElement> lbl_PostalFullRenponseTitles;

	@FindBy(xpath="//li/p[2]")
	private List<WebElement> lbl_PostalFullRenponseValues;

	@FindBy(xpath="//app-ipas-postal-short-pannel//div[@class='desc']")
	private WebElement lbl_PostalShortPanelMessage;

	@FindBy(xpath="//a[contains(text(),'Automated Transaction Configuration')]")
	private WebElement lnl_AutomatedTransaction;

	@FindBy(xpath="(//ipas-maintenance-identity-propensity-configuration//tbody/tr[1])[2]/td[3]/div/ejs-switch")
	private WebElement btn_PostalToggleSwitchPRMH;

	@FindBy(xpath="//span[contains(text(),'Patient visit does not have postal confirmation re')]")
	private WebElement txt_PostalShortManualMsg;

	@FindBy(xpath="//div[contains(text(),'Patient visit does not have postal confirmation re')]")
	private WebElement txt_PostalFullManualMsg;


	@FindBy(xpath = "//a[contains(text(),'Account Search')]")
	private WebElement lnk_AccountSearch;

	@FindBy(xpath="//table[@class='e-table']//thead/tr")
	private WebElement lbl_Headers;

	@FindBy(xpath="//div[@class='emptyinfo']")
	private WebElement lbl_NoDataMsg;

	@FindBy(xpath="//ejs-dashboardlayout[@id='defaultLayout']/div/ipas-maintenance-panel/ejs-accordion/div/div/div")
	private WebElement tbl_defaultLayout;

	@FindBy(xpath="//a[contains(text(),'Maintenance')]")
	private WebElement lnk_Maintenance;

	@FindBy(xpath="((//div[@class='modal-body'])[2]//ejs-textbox[1]/span/input)[1]")
	private WebElement txt_PostalStreetAddress;

	@FindBy(xpath="((//div[@class='modal-body'])[2]//ejs-textbox[1]/span/input)[3]")
	private WebElement txt_PostalCity;

	@FindBy(xpath="((//div[@class='modal-body'])[2]//ejs-textbox[1]/span/input)[4]")
	private WebElement txt_PostalState;

	@FindBy(xpath="((//div[@class='modal-body'])[2]//ejs-textbox[1]/span/input)[5]")
	private WebElement txt_PostalZipCode;

	@FindBy(xpath="//ejs-dropdownlist/span")
	private WebElement ddl_PostalNewRequestdropdown;

	@FindBy(xpath = "//p[contains(text(),'Input Address Matched to a General Delivery Addres')]")
	private WebElement txt_FullPanelText;

	@FindBy(xpath = "//div[@class='breadcrum-container noprint']/span[2]/a")
	private WebElement lnk_AccountNumber;

	@FindBy(xpath="//span[contains(text(),'No payment has created yet')]")
	private WebElement lbl_NoPayments;

	@FindBy(xpath="//ipas-payment-facilitator-pannel/ejs-accordion/div")
	private WebElement tbl_PaymentFacilitatorPanel;

	@FindBy(xpath="//div[@id='three']//app-ipas-document-management-pannel/div/ejs-accordion/div/div[2]/div/div/ul/li/div[1]")
	private List<WebElement> lbl_DigitalDocMangerPanel;

	@FindBy(xpath="//ejs-accordion/div[1]/div[2]/div/div/ul/li/div[2]")
	private WebElement lbl_DataInAllDataPanel;

	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[2]")
	private List<WebElement> lbl_VisitSummaryData;	

	@FindBy(xpath="//span[contains(text(),'History')]")
	private WebElement lbl_HistoryWindowTitle;

	@FindBy(xpath="//thead/tr/th[2]/div/span")
	private WebElement lbl_HistoryDateTimeHeader;

	@FindBy(xpath="//thead/tr/th[3]/div/span")
	private WebElement lbl_HistoryEmployee;

	@FindBy(xpath="//thead/tr/th[4]/div/span")
	private WebElement lbl_HistoryType;

	@FindBy(xpath="(//button[contains(text(),'Cancel')])[2]")
	private WebElement btn_HistoryCancel;

	@FindBy(xpath="//button[contains(text(),'Select')]")
	private WebElement btn_HistorySelect;

	@FindBy(xpath="//span[@class='e-ripple-container']")
	private WebElement btn_HistoryRecordSelect;

	@FindBy(xpath="//ipas-postal-details//div[@class='title']")
	private WebElement lbl_HistoricalMessage;

	@FindBy(xpath="(//li/p[2])[4]")
	private WebElement lbl_PostalZipCode;

	@FindBy(xpath="//a[contains(text(),'Current Request')]")
	private WebElement btn_CurrentRequest;

	@FindBy(xpath="(//ipas-maintenance-identity-propensity-configuration//tbody/tr[1])[2]/td[2]/div/ejs-switch")
	private WebElement btn_IdentityToggleSwitchPRMH;

	@FindBy(xpath="(//ipas-maintenance-identity-propensity-configuration//tbody/tr[1])[2]/td[4]/div/ejs-switch")
	private WebElement btn_P2PToggleSwitchPRMH;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs; 

	public PostalConfirmationPage() {
		PageFactory.initElements(driver, this);
	}


	public void verifyPostalPanel(String panel,DataTable testdata){
		try {
			ArrayList<String> actualPanelText =new ArrayList<String>();
			ArrayList<String> expPanelTitle=new ArrayList<>(testdata.asList());		
			report.reportInfo("Expected short panel info: "+expPanelTitle);

			if(panel.contentEquals("Short Panel")){
				webActions.waitForVisibility(txt_AddressNotFoundInShortPanel, "PanelText");			    
				actualPanelText.add(webActions.getText(txt_PostalPanelTitle, "PanelTitle"));
				actualPanelText.add(webActions.getText(txt_AddressNotFoundInShortPanel, "AddressNotFound"));
				report.reportInfo("Displayed Short Panel Title: "+actualPanelText);
			}
			else if(panel.contentEquals("Full Panel")){
				webActions.waitForVisibility(txt_AddressNotFoundInShortPanel, "PanelText");			   
				actualPanelText.add(webActions.getText(txt_PostalFullPanelTitle, "PanelTitle"));
				actualPanelText.add(webActions.getText(txt_AddressNotFoundInShortPanel, "AddressNotFound"));
				report.reportInfo("Displayed Full Panel Title: "+actualPanelText);
			}
			ArrayList<String>unmatchedShortPanelInfo=webActions.getUmatchedInArrayComparision(actualPanelText, expPanelTitle);
			if(unmatchedShortPanelInfo.size()==0){
				report.reportPass("Verified successfully" +panel+  "information");
			}
			else{
				throw new Exception("Fail to verify postal" +panel+ "information and unmatched data is: "+unmatchedShortPanelInfo);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyPostalPanelModuletStatus(String panel, String data){
		try {
			String moduleStatus = "";
			if("Short Panel".contentEquals(panel)){
				webActions.waitForVisibility(img_PostalShortPanelModuleStatus, "ModuleStatus");
				moduleStatus=webActions.getAttributeValue(img_PostalShortPanelModuleStatus, "src", "PostalShortPanel");
			}			
			else if("Full Panel".contentEquals(panel)){
				webActions.waitForVisibility(img_PostalFullPanelModuleStatus, "ModuleStatus");
				moduleStatus=webActions.getAttributeValue(img_PostalFullPanelModuleStatus, "src", "PostalFullPanel");
			}
			if("Address not found".contentEquals(data)){
				if(moduleStatus.contains("error_sm")){
					report.reportPass("Verified Postal" +panel+ "module status when address not found");
				}
			}
			else if("GuarantorAddressValid".contentEquals(data)){
				if(moduleStatus.contains("success_sm")){
					report.reportPass("Verified Postal" +panel+ "module status");
				}
			}
			else if("AddressReview".contentEquals(data)){
				if(moduleStatus.contains("alert_sm")){
					report.reportPass("Verified Postal" +panel+ "module status");
				}
			}
			else{
				report.reportFail("Fail to verify postal" +panel+ "module status and actual displayed image is : " + moduleStatus);
			}		
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyExpandandCollapsPostalPanel() throws Exception{
		StringBuilder unmatch=new StringBuilder();		
		webActions.waitForVisibility(img_PostalShortPanelModuleStatus, "ModuleStatus");		
		String actualExpandStatus=webActions.getAttributeValue(icon_PostalExpandCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons e-expand-icon".contentEquals(actualExpandStatus)){			
			report.reportPass("By default short Panel is displayed in Expand mode");
		}else{
			unmatch.append("Panle is not dispalyed in Expand mode by default");
			report.reportFail("Postal Panel is not dispalyed in Expand mode by default");
		}
		webActions.waitAndClick(icon_PostalExpandCollapse, "ExpandandCollapse");
		webActions.waitForPageLoaded();
		String actualCollapseStatus=webActions.getAttributeValue(icon_PostalExpandCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons".contentEquals(actualCollapseStatus)){
			report.reportPass("Postal Panel Successfully Collapsed");
		}
		else{
			unmatch.append("Postal Panle is not Collapsed");
			report.reportFail("Postal Panel is not Collapsed");
		}		
		if(unmatch.length()==0){
			report.reportPass("Postal Panel Successfully Expanded and Collapsed");
		}else{
			report.reportFail("Failed to verify the Expand and Collapse of the Postal Confirmation Panel"+unmatch);
		}

	}

	public void clickOnPostal(){
		try {
			webActions.waitForVisibility(txt_PostalPanelTitle, "PostalPanel");
			webActions.click(txt_PostalPanelTitle, "PostalPanel");
			webActions.waitForVisibilityOfAllElements(lbl_PostalFullPanel, "PostalFullPage");
			Thread.sleep(1000);
			report.reportInfo("Navigated to teh Postal Full Page");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyDisplayedBreadcrumb(String visitId,String pageName,String menuName) throws Exception{	
		String accountNumber = logIn.getVisitIdFromResponse(visitId);
		ArrayList<String> expectedBreadcrumbTitles=new ArrayList<String>();
		expectedBreadcrumbTitles.add(pageName);
		expectedBreadcrumbTitles.add(accountNumber);
		expectedBreadcrumbTitles.add(menuName);
		report.reportInfo("Expected Breadcrumb Titles "+expectedBreadcrumbTitles);
		ArrayList<String> actualBreadcrumbTitles = new ArrayList<String>();

		if ("Account Search".contentEquals(pageName)) {			
			actualBreadcrumbTitles = webActions.getDatafromWebTable(lbl_iPASBreadcrumb);
		}
		report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumbTitles);
		ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles, expectedBreadcrumbTitles);
		if(unmatch.size()==0){
			report.reportPass("Page Breadcrumb Titles verified successfully, when user navigate from: "+pageName);
		}else{
			report.reportFail("Failed to verify the Page Breadcrumb Titles, when user navigate from: "+pageName+" : and unmatched data: "+unmatch);
		}
	}

	public void verifyLastRunByInPostalPanel(){
		String actCurrentDateTime = null; String expCurrentDateTime = null; String increasedCurrentDateTime = null;String fullPanelCurrentDateTime = null;
		try {			
			webActions.waitForVisibility(txt_AddressNotFoundInShortPanel, "PanelText");
			String actCurrentDate = webActions.waitAndGetText(txt_PostalShortLastRunBy, "LastRunDateTime");
			actCurrentDateTime=actCurrentDate.replace(",", "");			
			report.reportInfo("Dsiplayed last run date from application: "+actCurrentDateTime);			
			String expCurrentDate = webActions.getCurrentSystemDateTime();
			String increasedTime=webActions.getIncreasedCurrentSystemDateTime(-1);
			expCurrentDateTime="Last ran by Auto "+ expCurrentDate;
			increasedCurrentDateTime="Last ran by Auto "+ increasedTime;
			report.reportInfo("system current date time: "+expCurrentDateTime);
			if(actCurrentDateTime.contentEquals(expCurrentDateTime)||actCurrentDateTime.contentEquals(increasedCurrentDateTime))
			{
				report.reportPass("Verified last run by date and time");
			}else{
				report.reportFail("Failed to verify last run by date and time",true);
			}
			clickOnPostal();
			String fullPanelCurrentDate = webActions.waitAndGetText(txt_PostalFullPanelLastRunBy, "LastRunDateTime");
			fullPanelCurrentDateTime=fullPanelCurrentDate.replace(",", "");			
			report.reportInfo("Dsiplayed last run date from application: "+actCurrentDateTime);

			if(fullPanelCurrentDateTime.contentEquals(expCurrentDateTime)||fullPanelCurrentDateTime.contentEquals(increasedCurrentDateTime))
			{
				report.reportPass("Verified last run by date and time in postal full panel");
			}else{
				report.reportFail("Failed to verify last run by date and time in postal full panel");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyFieldsInPostalFullPanel(){
		try {
			webActions.waitForVisibility(txt_AddressNotFoundInShortPanel, "PanelText");
			webActions.assertDisplayed(btn_PostalFullPanelHistory, "HostoryButton");
			webActions.assertDisplayed(btn_PostalFullPanelNewRequest, "NewRequestButton");
			report.reportPass("Verified buttona sucessfully in panel");
			String sectionName=webActions.getText(lbl_PostalFullPanelSectionName, "FullPanelSectionName");
			if("Guarantor".contentEquals(sectionName)){
				report.reportPass("Verified section name in postal full panel");
			}
			else{
				report.reportFail("Failed to verify section name in postal full panel");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnPostalNewRequestBtn(){
		try {
			webActions.waitForVisibility(btn_PostalFullPanelNewRequest, "New");
			webActions.click(btn_PostalFullPanelNewRequest, "NewRequestButton");
			webActions.waitForVisibilityOfAllElements(lbl_PostalFullPanelRequestWindow, "PostalNewrequestPage");
			report.reportInfo("Navigated to the Postal New Request Page");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyfieldsAndSections(String scenario, DataTable testData) {
		try {
			ArrayList<String> actualData = new ArrayList<>();
			ArrayList<String> expectedData = new ArrayList<>(testData.asList());
			if(scenario.contentEquals("fields")){
				report.reportInfo("Expected fields from postal new request window "+expectedData);
				webActions.waitForPageLoaded();
				actualData=webActions.getDatafromWebTable(lbl_PostalFullPanelRequestWindowFields);
				report.reportInfo("Displayed fields in new request window: "+actualData);
			}		
			else if (scenario.contentEquals("mandatory")){
				report.reportInfo("Expected mandatory fields in new request window "+expectedData);							
				int fieldsSize=lbl_PostalFullPanelRequestWindowFieldsInput.size();							
				for( int i=1;i<=fieldsSize;i++){
					String xpath1 = "((//div[@class='modal-body'])[2]//ejs-textbox[1]/span/input)";
					String xpath2 = xpath1+"["+i+"]";
					WebElement field=driver.findElement(By.xpath(xpath2));					
					webActions.clickAction(field, "fields");
					webActions.clearValue(field, "fields");
					webActions.waitForPageLoaded();
				}
				webActions.waitForPageLoaded();
				actualData.add(webActions.getText(lbl_PostalNewRequestWindowStreetMandatory, "StreetAddress"));
				actualData.add(webActions.getText(lbl_PostalNewRequestWindowCityMandatory, "City"));
				actualData.add(webActions.getText(lbl_PostalNewRequestWindowStateMandatory, "State"));
				report.reportInfo("Displayed mandatory fields from new request window: "+actualData);
			}
			ArrayList<String>unmatchedFields=webActions.getUmatchedInArrayComparision(actualData, expectedData);
			if(unmatchedFields.size()==0){
				report.reportPass("Verified "+scenario+" from postal new request window successfully");
			}
			else{
				report.reportFail("Fail to verify "+scenario+" from postal new request window and unmatched "+scenario+" are: "+unmatchedFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void cancelAndCrossNavigation(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_PostalNewRequestWindowCancel, "NewRequestCancelBtn");
			webActions.waitForVisibility(txt_AddressNotFoundInShortPanel, "PanelText");
			webActions.assertDisplayed(btn_PostalFullPanelHistory, "HostoryButton");
			report.reportPass("History button is displayed");
			clickOnPostalNewRequestBtn();
			webActions.click(btn_PostalNewRequestWindowCross, "NewRequestCrossOprtion");
			webActions.waitForVisibility(txt_AddressNotFoundInShortPanel, "PanelText");
			webActions.assertDisplayed(btn_PostalFullPanelHistory, "HostoryButton");
			report.reportPass("History button is displayed");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDataElementsInShortAndFull(String panel,DataTable testdata){
		try {
			ArrayList<String> actualDataElements =new ArrayList<String>();
			ArrayList<String> expDataElements=new ArrayList<>(testdata.asList());		
			report.reportInfo("Expected short panel info: "+expDataElements);

			if(panel.contentEquals("Short Panel")){	
				webActions.waitForPageLoaded();
				actualDataElements.add(webActions.getText(lbl_PostalShrotZip, "ZipCodeText"));
				actualDataElements.add(webActions.getText(lbl_PostalShrotZipCode, "ZipCode"));
				actualDataElements.add(webActions.getText(lbl_PostalShrotDataElement, "DataElement"));
				report.reportInfo("Displayed Short Panel Elements: "+actualDataElements);
			}
			else if(panel.contentEquals("Full Panel")){
				webActions.waitForPageLoaded();
				actualDataElements.add(webActions.getText(lbl_PostalFullDataElement, "DataElements"));
				actualDataElements.add(webActions.getText(lbl_PostalFullDataElementResponseName, "ElementsResponse"));
				ArrayList<String> elementsTitle=webActions.getDatafromWebTable(lbl_PostalFullRenponseTitles);
				actualDataElements.addAll(elementsTitle);
				ArrayList<String> elementsValue=webActions.getDatafromWebTable(lbl_PostalFullRenponseValues);
				actualDataElements.addAll(elementsValue);
				report.reportInfo("Displayed Full Panel Elements: "+actualDataElements);
			}
			ArrayList<String>unmatchedShortPanelInfo=webActions.getUmatchedInArrayComparision(actualDataElements, expDataElements);
			if(unmatchedShortPanelInfo.size()==0){
				report.reportPass("Verified successfully" +panel+  "information");
			}
			else{
				throw new Exception("Fail to verify postal" +panel+ "information and unmatched data is: "+unmatchedShortPanelInfo);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyPostalDataElementsModuletStatus(String panel, String status){
		try {
			String moduleStatus = "";
			if("Short Panel".contentEquals(panel)){
				webActions.waitForVisibility(lbl_PostalShrotDataElementStatus, "ModuleStatus");
				moduleStatus=webActions.getAttributeValue(lbl_PostalShrotDataElementStatus, "src", "PostalShortPanel");
			}			
			else if("Full Panel".contentEquals(panel)){
				webActions.waitForVisibility(lbl_PostalFullDataElementStatus, "DataElementsStatus");
				moduleStatus=webActions.getAttributeValue(lbl_PostalFullDataElementStatus, "src", "DataElementsStatus");
			}		
			if("NeedsAttention".contentEquals(status)){
				if(moduleStatus.contains("error_sm")){
					report.reportPass("Verified Postal" +panel+ " module status when address not found");
				}
			}
			else if("Clear".contentEquals(status)){
				if(moduleStatus.contains("success_sm")){
					report.reportPass("Verified Postal" +panel+ " module status");
				}
			}
			else if("Review".contentEquals(status)){
				if(moduleStatus.contains("alert_sm")){
					report.reportPass("Verified Postal" +panel+ " module status");
				}
			}	
			else{
				report.reportFail("Fail to verify postal" +panel+ " data elementmodule status and actual displayed image is : " + moduleStatus);
			}		
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void postalSuccessMsg(String panel,String msg){
		try {
			String panelMsg = "";
			if("Short Panel".contentEquals(panel)){
				webActions.waitForVisibility(lbl_PostalShortPanelMessage, "Message");
				panelMsg=webActions.getText(lbl_PostalShortPanelMessage, "ShortPanel");
			}			
			else if("Full Panel".contentEquals(panel)){
				webActions.waitForVisibility(lbl_PostalFullDataElement, "DataElementsStatus");
				panelMsg=webActions.getText(lbl_PostalFullDataElement, "FullPanel");
			}	

			if(panelMsg.contentEquals(msg)){
				report.reportPass("Verified Postal" +panel+ " success message");
			}		

			else{
				report.reportFail("Fail to verify postal" +panel+ " success message and actual displayed message is : " + panelMsg);
			}		
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}	
	public void verifyMsgForManualRun(String panel,String message){
		String manualMessage="";
		try {
			webActions.waitForPageLoaded();

			if("Short".contentEquals(panel)){
				manualMessage=webActions.getText(txt_PostalShortManualMsg, "ShortPanel");
			}
			else if("Full".contentEquals(panel)){
				manualMessage=webActions.getText(txt_PostalFullManualMsg, "FullPanel");
			}
			if(message.contentEquals(manualMessage)){
				report.reportPass("Verified manual request message in" +panel+ "panel");
			}
			else{
				report.reportFail("Fail to verify manual request message in" +panel+ "panel");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void navigateAccountSearch(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lnk_AccountSearch, "AccountSearchLink");
			webActions.waitForPageLoaded();
			try {
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(lbl_Headers, "Headers in Account Search");
			} catch (Exception e) {
				webActions.waitForPageLoaded();
				//webActions.waitForVisibility(lbl_NoDataMsg,"SearchResults");
			}
			report.reportPass("Clicked on Account Search link and navigated to the Account Search Page Successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void navigateMaintenanceiPAS(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lnk_Maintenance, "Maintenance");
			webActions.waitForPageLoaded();
			try {
				webActions.waitUntilisDisplayed(tbl_defaultLayout, "Default Layout");
			} catch (Exception e) {
			}
			report.reportPass("Clicked on Maintenance link and navigated to the Maintenance Page Successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void enterZipCode(String type, String zipCode){
		try {
			if("Patient".contentEquals(type)){
				webActions.waitForPageLoaded();
				webActions.click(ddl_PostalNewRequestdropdown, "RequestType");			
				webActions.sendKeys(ddl_PostalNewRequestdropdown,type, "RequestType");
				webActions.pressTab();				
				webActions.waitForPageLoaded();		

			}
			webActions.waitForPageLoaded();
			webActions.clearValue(txt_PostalZipCode, "ZipCode");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_PostalZipCode, zipCode, "ZipCode");
			webActions.waitForPageLoaded();
			webActions.click(btn_PostalNewRequestWindow, "SendRequest");
			report.reportInfo("Clicked on Send Request button");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void enterAddressData(DataTable testData){
		try {
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_PostalStreetAddress, "StreetAddress");
			webActions.clearValue(txt_PostalStreetAddress, "StreetAddress");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_PostalStreetAddress,webActions.getDatafromMap(testData,"Street Address"), "StreetAddress");			
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_PostalCity, "City");
			webActions.clearValue(txt_PostalCity, "City");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_PostalCity,webActions.getDatafromMap(testData,"City"), "City");	
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_PostalState, "State");
			webActions.clearValue(txt_PostalState, "State");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_PostalState,webActions.getDatafromMap(testData,"State"), "State");
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_PostalZipCode, "ZipCode");
			webActions.clearValue(txt_PostalZipCode, "ZipCode");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_PostalZipCode,webActions.getDatafromMap(testData,"Zip Code"), "ZipCode");
			webActions.waitForPageLoaded();
			report.reportInfo("Entered data in request window successfully");
			webActions.waitForPageLoaded();
			webActions.click(btn_PostalNewRequestWindow, "SendRequest");
			report.reportInfo("Clicked on Send Request button");
			webActions.waitForPageLoaded();

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyManualLastRunByInPostalPanel(){
		String actCurrentDateTime = null; String expCurrentDateTime = null; String increasedCurrentDateTime = null;String fullPanelCurrentDateTime = null;
		try {			
			webActions.waitForVisibility(txt_FullPanelText, "PanelText");
			String expCurrentDate = webActions.getCurrentSystemDateTime();
			String increasedTime=webActions.getIncreasedCurrentSystemDateTime(-1);
			expCurrentDateTime="Last ran by Yenugu KesiReddy "+ expCurrentDate;
			increasedCurrentDateTime="Last ran by Yenugu KesiReddy "+ increasedTime;
			report.reportInfo("system current date time: "+expCurrentDateTime);	
			String fullPanelCurrentDate = webActions.waitAndGetText(txt_PostalFullPanelLastRunBy, "LastRunDateTime");
			fullPanelCurrentDateTime=fullPanelCurrentDate.replace(",", "");			
			report.reportInfo("Dsiplayed last run date from application: "+fullPanelCurrentDateTime);

			if(fullPanelCurrentDateTime.contentEquals(expCurrentDateTime)||fullPanelCurrentDateTime.contentEquals(increasedCurrentDateTime))
			{
				report.reportPass("Verified last run by date and time in postal full panel");
			}else{
				report.reportFail("Failed to verify last run by date and time in postal full panel",true);
			}
			webActions.click(lnk_AccountNumber, "AccountNumber");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_DigitalDocMangerPanel, "DigitalDocs");			
			waitforPaymentFacilitatorPanel();
			report.reportInfo("Navigated to the Patient Visit Summary page");			
			webActions.waitForVisibilityOfAllElements(lbl_DataInAllDataPanel, "DataInAllData");
			webActions.waitForVisibilityOfAllElements(lbl_VisitSummaryData, "SummaryData");

			String actCurrentDate = webActions.waitAndGetText(txt_PostalShortLastRunBy, "LastRunDateTime");
			actCurrentDateTime=actCurrentDate.replace(",", "");			
			report.reportInfo("Dsiplayed last run date from application: "+actCurrentDateTime);			

			if(actCurrentDateTime.contentEquals(expCurrentDateTime)||actCurrentDateTime.contentEquals(increasedCurrentDateTime))
			{
				report.reportPass("Verified last run by date and time in short panel");
			}else{
				report.reportFail("Failed to verify last run by date and time in short panel");
			}


		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void waitforPaymentFacilitatorPanel() throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(lbl_NoPayments, "No Payments Error Message");
		} catch (Exception e) {
			webActions.waitForVisibility(tbl_PaymentFacilitatorPanel, "Payment Facilitator Panel");
		}
	}
	public void verifyHistroyWindow(DataTable testData){
		try {
			ArrayList<String> actualheaders =new ArrayList<String>();
			ArrayList<String> expHeaders=new ArrayList<>(testData.asList());		
			report.reportInfo("Expected history window info: "+expHeaders);
			webActions.waitForPageLoaded();
			webActions.click(btn_PostalFullPanelHistory, "History");
			webActions.waitForVisibility(btn_HistoryCancel, "Cancel");
			boolean flag=btn_HistorySelect.isEnabled();
			if(flag){
				report.reportFail("Select button is displayed in enable mode by default");
			}
			else{
				report.reportPass("Verified Save button mode successfully");
			}
			actualheaders.add(webActions.getText(lbl_HistoryWindowTitle, "HistorryTitle"));
			actualheaders.add(webActions.getText(lbl_HistoryDateTimeHeader, "DateHeader"));
			actualheaders.add(webActions.getText(lbl_HistoryEmployee, "Employee"));
			actualheaders.add(webActions.getText(lbl_HistoryType, "Type"));			
			ArrayList<String>unmatchedShortPanelInfo=webActions.getUmatchedInArrayComparision(actualheaders, expHeaders);
			if(unmatchedShortPanelInfo.size()==0){
				report.reportPass("Verified successfully history window information");
			}
			else{
				throw new Exception("Fail to verify postal history window information and unmatched data is: "+unmatchedShortPanelInfo);
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyCancelInHistoryWindow(){
		try {
			webActions.waitForPageLoaded();		
			webActions.click(btn_PostalFullPanelHistory, "History");
			webActions.waitForVisibility(btn_HistoryCancel, "Cancel");
			Thread.sleep(1000);
			webActions.click(btn_HistoryCancel, "Cancel");
			webActions.waitForVisibility(btn_PostalFullPanelHistory, "History");
			webActions.assertDisplayed(btn_PostalFullPanelHistory, "HostoryButton");
			report.reportPass("History button is displayed");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyHistoricalPostalConfirmationData(String zipCode){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_PostalFullPanelHistory, "History");
			webActions.waitForVisibility(btn_HistoryCancel, "Cancel");
			Thread.sleep(2000);
			webActions.click(btn_HistoryRecordSelect, "RecordRadio");
			webActions.waitForPageLoaded();
			webActions.click(btn_HistorySelect, "Select");
			webActions.waitForVisibility(lbl_HistoricalMessage, "HistoricalPostalMsg");
			Thread.sleep(2000);
			String actHistoricalMsg=webActions.getText(lbl_HistoricalMessage, "HistoricalPostalMsg");
			if("Historical Postal Confirmation".contentEquals(actHistoricalMsg)){
				report.reportPass("Verified Historical confirmation message in postal full panel");
			}
			else{
				report.reportFail("Failed to verify historcial confirmation message and actual displayed msg : " + actHistoricalMsg,true );
			}			
			String displayedZipCode=webActions.getText(lbl_PostalZipCode, "ZipCode");
			if(displayedZipCode.contentEquals(zipCode)){
				report.reportPass("Verified Historical zip code successfully");
			}
			else{
				report.reportFail("Fail to verify historical zip code and displayed is : " + displayedZipCode);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyCurrentRequestData(String zipCode){
		try {
			webActions.waitForPageLoaded();
			Thread.sleep(2000);
			webActions.clickAction(btn_CurrentRequest, "CurrentRequest");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_PostalZipCode, "ZipCode");
			String displayedZipCode=webActions.getText(lbl_PostalZipCode, "ZipCode");
			if(displayedZipCode.contentEquals(zipCode)){
				report.reportPass("Verified current request zip code successfully");
			}
			else{
				report.reportFail("Fail to verify current request zip code and displayed is : " + displayedZipCode);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyAutoRunFlagOnAndOff(String runStatus, String module){
		try {
			webActions.click(lnl_AutomatedTransaction, "AutomatedTransactionLink");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_PostalToggleSwitchPRMH, "PostalToggleSwitch");
			webActions.waitForPageLoaded();
			if(module.contentEquals("Postal")){
				String actAutoRunStatus=webActions.getAttributeValue(btn_PostalToggleSwitchPRMH, "aria-checked", "Auto Run");
				if("Yes".contentEquals(runStatus)){
					if(!actAutoRunStatus.contentEquals("true")){
						webActions.waitForVisibility(btn_PostalToggleSwitchPRMH, "Auto Run");
						webActions.click(btn_PostalToggleSwitchPRMH, "Auto Run");
						webActions.waitForPageLoaded();
						report.reportPass("Auto Run flag is enabled successfully");
					}
					report.reportPass("Auto Run already in On");
				}

				else if("No".contentEquals(runStatus)){			
					if(!actAutoRunStatus.contentEquals("false")){
						webActions.waitForVisibility(btn_PostalToggleSwitchPRMH, "Auto Run");
						webActions.click(btn_PostalToggleSwitchPRMH, "Auto Run");
						webActions.waitForPageLoaded();
						report.reportPass("Auto Run flag is disabled successfully");
					}
					report.reportPass("Auto Run already in Off");
				}
			}
			else if(module.contentEquals("Identity")){
				String actAutoRunStatus=webActions.getAttributeValue(btn_IdentityToggleSwitchPRMH, "aria-checked", "Auto Run");
				if("Yes".contentEquals(runStatus)){
					if(!actAutoRunStatus.contentEquals("true")){
						webActions.waitForVisibility(btn_IdentityToggleSwitchPRMH, "Auto Run");
						webActions.click(btn_IdentityToggleSwitchPRMH, "Auto Run");
						webActions.waitForPageLoaded();
						report.reportPass("Auto Run flag is enabled successfully");
					}
					report.reportPass("Auto Run already in On");
				}

				else if("No".contentEquals(runStatus)){			
					if(!actAutoRunStatus.contentEquals("false")){
						webActions.waitForVisibility(btn_IdentityToggleSwitchPRMH, "Auto Run");
						webActions.click(btn_IdentityToggleSwitchPRMH, "Auto Run");
						webActions.waitForPageLoaded();
						report.reportPass("Auto Run flag is disabled successfully");
					}
					report.reportPass("Auto Run already in Off");
				}
			}
			else if(module.contentEquals("P2P")){
				String actAutoRunStatus=webActions.getAttributeValue(btn_P2PToggleSwitchPRMH, "aria-checked", "Auto Run");
				if("Yes".contentEquals(runStatus)){
					if(!actAutoRunStatus.contentEquals("true")){
						webActions.waitForVisibility(btn_P2PToggleSwitchPRMH, "Auto Run");
						webActions.click(btn_P2PToggleSwitchPRMH, "Auto Run");
						webActions.waitForPageLoaded();
						report.reportPass("Auto Run flag is enabled successfully");
					}
					report.reportPass("Auto Run already in On");
				}

				else if("No".contentEquals(runStatus)){			
					if(!actAutoRunStatus.contentEquals("false")){
						webActions.waitForVisibility(btn_P2PToggleSwitchPRMH, "Auto Run");
						webActions.click(btn_P2PToggleSwitchPRMH, "Auto Run");
						webActions.waitForPageLoaded();
						report.reportPass("Auto Run flag is disabled successfully");
					}
					report.reportPass("Auto Run already in Off");
				}
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
