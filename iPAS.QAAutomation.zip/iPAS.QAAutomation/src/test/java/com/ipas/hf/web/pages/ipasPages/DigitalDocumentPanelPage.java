package com.ipas.hf.web.pages.ipasPages;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class DigitalDocumentPanelPage extends BasePage {

	@FindBy(xpath = "//div[@class='e-list-item-header']/span[1]")
	private List<WebElement> lbl_DigitalDocumentPanelSectionNames;


	@FindBy(xpath = "//span[@class='e-list-content']/span")
	private List<WebElement> lbl_DigitalDocumentPanelDefaultStatus;

	@FindBy(xpath = "//span[2][@class='e-list-content']")
	private List<WebElement> lbl_DigitalDocumentPanelLabel1;

	@FindBy(xpath = "//span[3][@class='e-list-content']")
	private List<WebElement> lbl_DigitalDocumentPanelLabel2;

	@FindBy(xpath = "//div[@id='document-viewer-section']/span/h2")
	private WebElement lbl_DocumentViewerContent;

	@FindBy(xpath = "//div[@id='document-viewer-section']/div[3]/span")
	private WebElement lbl_DocumentViewerDefaultMsg;

	@FindBy(xpath = "//*[@id='document-list']//ul/li[2]/div/ejs-checkbox")
	private WebElement lbl_DocumentPhysicians;

	@FindBy(xpath = "//*[@id='form-list']//ul/li[3]/div/ejs-checkbox")
	private WebElement lbl_FormsGeneralPain;


	@FindBy(xpath = "//span[contains(text(),'Pre-Registration')]")
	private WebElement lbl_FormsPreReg;

	@FindBy(xpath = "//span[contains(text(),'Conditions of Admission')]")
	private WebElement lbl_FormsAdmission;
	
	@FindBy(xpath = "//span[contains(text(),'General Pain and Medical History')]")
	private WebElement lbl_FormsMedicalHistory;

	@FindBy(xpath = "//div[@id='document-viewer-section']/div[3]/button")
	private WebElement btn_DocumentViewerButtons;

	@FindBy(xpath = "//div[@id='document-viewer-section']/div/button[1]")
	private WebElement btn_FromsPrint;

	@FindBy(xpath = "//button[contains(text(),'Request Signature')]")
	private WebElement btn_RequestSignature;

	@FindBy(xpath = "//button[contains(text(),'Witness')]")
	private WebElement btn_Witness;

	@FindBy(xpath = "//button[contains(text(),'Change Status')]")
	private WebElement btn_ChangeStatus;

	@FindBy(xpath = "//div[@class='btn-block-area']/button[1]")
	private WebElement btn_Cancel;

	@FindBy(xpath = "//div[@class='btn-block-area']/button[2]")
	private WebElement btn_ChangeStatusPopUp;

	@FindBy(xpath = "//h4[contains(text(),'Change Status')]")
	private WebElement lbl_ChangeStatusTitle;

	@FindBy(xpath = "//label[contains(text(),'Status')]")
	private WebElement lbl_ChangeStatusDrp;

	@FindBy(xpath = "//select[@id='status']/option[1]")
	private WebElement txt_ChangeStatusDefaultValue;

	@FindBy(xpath = "//button[@class='close cross-icon']/span")
	private WebElement btn_ChangeStatusCross;

	@FindBy(xpath = "//div[@id='document-viewer-section']/div[1]/span/img")
	private WebElement lbl_FormStatus;

	@FindBy(id = "input_195")
	private WebElement txt_MRN;

	@FindBy(id = "input_11")
	private WebElement drp_Race;

	@FindBy(id = "input_13")
	private WebElement txt_EmployerName;

	@FindBy(id = "input_19")
	private WebElement drp_Relationship;

	@FindBy(id = "input_22")
	private WebElement drp_GuarantorRelationship;

	@FindBy(id = "input_25")
	private WebElement txt_GuarantorSocialSecurityNumber;

	@FindBy(xpath ="//button[@type='submit']")
	private WebElement btn_Submit;

	@FindBy(id = "input_41_full")
	private WebElement txt_PrimaryInsuPhNumber;

	@FindBy(id = "input_50_full")
	private WebElement txt_SecondaryInsuPhNumber;

	@FindBy(id = "input_141_full")
	private WebElement txt_TertiaryInsuPhNumber;
	
	@FindBy(id = "lite_mode_3")
	private WebElement txt_DateOfService;
	
	@FindBy(xpath="//div[@id='inputContainer']/input")
	private WebElement txt_Weight;
	
	@FindBy(xpath="//input[@id='heightFeet']")
	private WebElement txt_heightFeet;
	
	@FindBy(xpath="//input[@id='heightInches']")
	private WebElement txt_heightInches;
	
	@FindBy(id = "input_14")
	private WebElement txt_Age;

	public DigitalDocumentPanelPage() {
		PageFactory.initElements(driver, this);
	}
	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}

	public void verifyPanelSections(DataTable sectionNames){
		try {
			ArrayList<String> expectedSectionNames = new ArrayList<>(sectionNames.asList());
			report.reportInfo("Expected Section Names: "+expectedSectionNames);			
			ArrayList<String> actualColumnNames=webActions.getDatafromWebTable(lbl_DigitalDocumentPanelSectionNames);
			report.reportInfo("Displayed Column Names in Application: "+actualColumnNames);
			ArrayList<String>unmatchedSectionNames=webActions.getUmatchedInArrayComparision(actualColumnNames, expectedSectionNames);
			if(unmatchedSectionNames.size()==0){
				report.reportPass("Verified Section Names under document and forms successfully");
			}
			else{
				throw new Exception("Fail to verify section Names under documents and forms and unmatched section Names are: "+unmatchedSectionNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyDefaultStatusForDocsAndForms(DataTable testData){
		try {
			String expectedStatusNames = getDatafromMap(testData, "Status");
			report.reportInfo("Expected status Names: "+expectedStatusNames);			
			ArrayList<String> actualStatus=webActions.getDatafromWebTable(lbl_DigitalDocumentPanelDefaultStatus);
			report.reportInfo("Displayed Status in Application: "+actualStatus);
			ArrayList<String>unmatchedStatuses=webActions.isFullArrayMatchWithData(actualStatus, expectedStatusNames);
			if(unmatchedStatuses.size()==0){
				report.reportPass("Verified default status for document and forms successfully");
			}
			else{
				throw new Exception("Fail to verify default status for documents and forms and unmatched statuses are: "+unmatchedStatuses);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyLabelsOfDocsAndForms(DataTable testData){
		try {
			String expectedDocLabelNames = getDatafromMap(testData, "Label1");
			report.reportInfo("Expected Label1 Names: "+expectedDocLabelNames);			
			ArrayList<String> actualDocLabelNames=webActions.getDatafromWebTable(lbl_DigitalDocumentPanelLabel1);
			report.reportInfo("Displayed Labels in Application: "+actualDocLabelNames);
			ArrayList<String>unmatchedlabels=webActions.isFullArrayMatchWithData(actualDocLabelNames, expectedDocLabelNames);
			if(unmatchedlabels.size()==0){
				report.reportPass("Verified default labels names for documents and forms successfully");
			}
			else{
				report.reportFail("Fail to verify default label names for documents and forms and unmatched labels are: "+unmatchedlabels,true);
			}
			String expectedLabel2Names = getDatafromMap(testData, "Label2");
			report.reportInfo("Expected Label2 Names: "+expectedLabel2Names);			
			ArrayList<String> actualLabel2Names=webActions.getDatafromWebTable(lbl_DigitalDocumentPanelLabel2);
			report.reportInfo("Displayed Labels in Application: "+actualLabel2Names);
			ArrayList<String>unmatchedlables=webActions.isFullArrayMatchWithData(actualLabel2Names, expectedLabel2Names);
			if(unmatchedlables.size()==0){
				report.reportPass("Verified default labels names for documents and forms successfully");
			}
			else{
				report.reportFail("Fail to verify default label names for documents and forms and unmatched labels are: "+unmatchedlables);
			}			

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDefaultDisplayContent(String expContent) {
		try {
			webActions.waitForPageLoaded();
			String actualContent = webActions.getText(lbl_DocumentViewerContent, "Default Content");
			if (actualContent.contentEquals(expContent)){
				report.reportPass("Verified default content in document viewer successfully");
				report.reportInfo("Actual Message: "+actualContent);
				report.reportInfo("Expected Message: "+expContent);
			}
			else{
				report.reportFail("Actual  message doesn't match with Expected and Actual message is: "+actualContent);
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());

		}

	}
	public void verifyDocumentViewerMsg(String expMsg){
		try {
			webActions.waitForPageLoaded();
			webActions.clickAction(lbl_DocumentPhysicians, "documents");
			webActions.waitForPageLoaded();
			String actualMsg = webActions.getText(lbl_DocumentViewerDefaultMsg, "Default Msg");
			if (actualMsg.contentEquals(expMsg)){
				report.reportPass("Verified default message in document viewer successfully");
				report.reportInfo("Actual Message: "+actualMsg);
				report.reportInfo("Expected Message: "+expMsg);
			}
			else{
				report.reportFail("Actual  message doesn't match with Expected and Actual message is: "+actualMsg);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}		
	}

	public void verifyDocumentsButtons(){
		try {
			verifydisplayoFDocumentsButtons();
			verifyDcoumentsButtonsMode();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifydisplayoFDocumentsButtons(){
		try {
			webActions.waitForPageLoaded();
			webActions.clickAction(lbl_DocumentPhysicians, "documents");
			webActions.waitForPageLoaded();
			webActions.assertDisplayed(btn_RequestSignature, "Signature Button");
			report.reportPass("Request Signature button is displayed successfully");
			webActions.assertDisplayed(btn_Witness, "Witness Button");
			report.reportPass("Witness button is displayed successfully");
			webActions.assertDisplayed(btn_ChangeStatus, "Change Status");
			report.reportPass("Change Status button is displayed successfully");

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyDcoumentsButtonsMode(){
		try {			
			webActions.waitForPageLoaded();		
			boolean signature=btn_RequestSignature.isEnabled();
			if(signature==false){
				report.reportPass("Request Signature button is displayed in readonly mode");
			}
			else{
				report.reportFail("Request Signature button is not displayed in readonly mode",true);
			}
			boolean witness=btn_Witness.isEnabled();
			if(witness==false){
				report.reportPass("Witness button is displayed in readonly mode");
			}
			else{
				report.reportFail("Witness button is not displayed in readonly mode",true);
			}
			boolean changeStatus=btn_ChangeStatus.isEnabled();
			if(changeStatus){
				report.reportPass("Change Status button is displayed in enabled mode");
			}
			else{
				report.reportFail("Change Status button is not displayed in enabled mode");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}


	public void verifyFormsButtons(){
		try {
			webActions.waitForPageLoaded();
			webActions.clickAction(lbl_FormsGeneralPain, "Forms");			
			webActions.waitForPageLoaded();
			Thread.sleep(5000);
			webActions.assertDisplayed(btn_FromsPrint, "Print Button");
			report.reportPass("Print button is displayed successfully");
			webActions.assertDisplayed(btn_RequestSignature, "Signature Button");
			report.reportPass("Request Signature button is displayed successfully");
			webActions.assertDisplayed(btn_Witness, "Witness Button");
			report.reportPass("Witness button is displayed successfully");
			webActions.assertDisplayed(btn_ChangeStatus, "Change Status");
			report.reportPass("Change Status button is displayed successfully");
			webActions.waitForPageLoaded();	
			boolean print=btn_FromsPrint.isEnabled();
			if(print){
				report.reportPass("Print button is displayed in enabled mode");
			}
			else{
				report.reportFail("Print button is not displayed in enabled mode",true);
			}
			boolean signature=btn_RequestSignature.isEnabled();
			if(signature==false){
				report.reportPass("Request Signature button is displayed in readonly mode");
			}
			else{
				report.reportFail("Request Signature button is not displayed in readonly mode",true);
			}
			boolean witness=btn_Witness.isEnabled();
			if(witness==false){
				report.reportPass("Witness button is displayed in readonly mode");
			}
			else{
				report.reportFail("Witness button is not displayed in readonly mode",true);
			}
			boolean changeStatus=btn_ChangeStatus.isEnabled();
			if(changeStatus){
				report.reportPass("Change Status button is displayed in enabled mode");
			}
			else{
				report.reportFail("Change Status button is not displayed in enabled mode");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyChangeStatusButtons(){
		try {
			webActions.waitForPageLoaded();
			webActions.clickAction(lbl_DocumentPhysicians, "documents");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_ChangeStatus, "ChangeStatus");
			Thread.sleep(5000);
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.assertDisplayed(btn_Cancel, "Cancel Button");
			report.reportPass("Cancel button is displayed successfully");
			webActions.assertDisplayed(btn_ChangeStatusPopUp, "ChangeStatus Button");
			report.reportPass("Change Status button is displayed successfully");

			webActions.waitForPageLoaded();
			boolean changeBtn=btn_ChangeStatus.isEnabled();
			if(changeBtn==false){
				report.reportPass("Change status button is displayed in readonly mode");
			}
			else{
				report.reportFail("Change status button is not displayed in readonly mode",true);
			}			
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDefaultSelectedValueinChangeStatus(DataTable testData){
		try {
			List<String> expfields = testData.asList(String.class);
			List<String> actfields = new ArrayList<>(); 
			actfields.add(webActions.getText(lbl_ChangeStatusTitle, "Change Status window title"));
			actfields.add(webActions.getText(lbl_ChangeStatusDrp, "Status drop down title"));
			String pending=webActions.getText(txt_ChangeStatusDefaultValue, "Default selected value from drop down");
			actfields.add(pending.trim());

			report.reportInfo("Actual fields in change status window: "+actfields);
			report.reportInfo("Expected fields in change status window: "+expfields);
			ArrayList<String> unmatchedData=webActions.getUmatchedInArrayComparision(actfields,expfields);
			if(unmatchedData.size()==0){
				report.reportPass("Verified Default Values in change status window successfully");
			}
			else{
				throw new Exception("Fail to verify Default Values in change status window and unmatched data is: "+unmatchedData);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyChangeStatusWindowClose(){
		try {
			webActions.waitForPageLoaded();
			webActions.clickAction(lbl_DocumentPhysicians, "documents");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_ChangeStatus, "ChangeStatus");
			Thread.sleep(5000);
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.click(btn_Cancel, "CancelBtn");
			webActions.waitForPageLoaded();
			webActions.assertDisplayed(btn_Witness, "Witness Button");
			report.reportPass("Witness button is displayed successfully");
			webActions.waitAndClick(btn_ChangeStatus, "ChangeStatus");
			Thread.sleep(5000);
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.click(btn_ChangeStatusCross, "Cross Option");
			webActions.waitForPageLoaded();
			webActions.assertDisplayed(btn_Witness, "Witness Button");
			report.reportPass("Witness button is displayed successfully");
			webActions.waitForPageLoaded();
			boolean changeBtn=btn_ChangeStatus.isEnabled();
			if(changeBtn){
				report.reportPass("Change status button is displayed in enable mode");
			}
			else{
				report.reportFail("Change status button is not displayed in enable mode");
			}			
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	/*To verify the Pre-Registration form*/
	public void verifyPreRegistrationForm(){
		try {
			webActions.waitForPageLoaded();
			webActions.clickAction(lbl_FormsPreReg, "PreReg");			
			webActions.waitForPageLoaded();
			Thread.sleep(5000);
			driver.switchTo().frame(0);
			webActions.waitForPageLoaded();
			webActions.click(txt_MRN, "MRN");			
			webActions.sendKeys(txt_MRN,"1234","MRN");
			webActions.waitForPageLoaded();
			/*webActions.click(drp_Race,"Race");			
			webActions.selectByVisibleText(drp_Race, "White", "Status Dropdown");			
			webActions.waitForPageLoaded();
			webActions.click(txt_EmployerName,"EmployerName");		
			webActions.sendKeys(txt_EmployerName,"Pelitas","EmployerName");
			webActions.waitForPageLoaded();
			webActions.click(drp_Relationship,"StatusDrp");	
			webActions.selectByVisibleText(drp_Relationship, "Friend", "Status Dropdown");
			webActions.waitForPageLoaded();
			webActions.click(drp_GuarantorRelationship,"GuarantorStatusDrp");				
			webActions.selectByVisibleText(drp_GuarantorRelationship, "Friend", "Status Dropdown");
			webActions.waitForPageLoaded();
			webActions.click(txt_GuarantorSocialSecurityNumber, "SSN");			
			webActions.sendKeys(txt_GuarantorSocialSecurityNumber,"9","SSN");
			webActions.waitForPageLoaded();
			webActions.click(txt_PrimaryInsuPhNumber, "PrimaryInsuPhNumber");			
			webActions.sendKeys(txt_PrimaryInsuPhNumber,"99","PrimaryInsuPhNumber");
			webActions.waitForPageLoaded();*/
			webActions.click(txt_SecondaryInsuPhNumber, "SecondaryInsuPhNumber");			
			webActions.sendKeys(txt_SecondaryInsuPhNumber,"99","SecondaryInsuPhNumber");
			webActions.waitForPageLoaded();
			webActions.click(txt_TertiaryInsuPhNumber, "TertiaryInsuPhNumber");			
			webActions.sendKeys(txt_TertiaryInsuPhNumber,"99","TertiaryInsuPhNumber");
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_Submit, "Submit");
			Thread.sleep(5000);
			webActions.click(btn_Submit, "submit");
			webActions.waitForPageLoaded();
			Thread.sleep(15000);			
			driver.switchTo().parentFrame();
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();

			boolean witness=btn_Witness.isEnabled();
			if(witness){
				report.reportPass("Witness button is displayed in enabled mode");
			}
			else{
				report.reportFail("Witness button is not displayed in enabled mode",true);
			}
			boolean flag=verifyFormStatus();
			if(flag){
				report.reportPass("Form status is displayed as clear mode");
			}
			else{
				report.reportFail("Form status is not changed to clear mode");
			}	


		} catch (Exception e) {
			report.reportFail(e.getMessage());			
		}
	}	
	public void verifyAdmissionForm(){
		try {
			webActions.waitForPageLoaded();
			webActions.clickAction(lbl_FormsAdmission, "Admission");			
			webActions.waitForPageLoaded();
			Thread.sleep(5000);
			driver.switchTo().frame(0);
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_Submit, "Submit");
			Thread.sleep(5000);
			webActions.click(btn_Submit, "submit");
			webActions.waitForPageLoaded();
			Thread.sleep(15000);			
			driver.switchTo().parentFrame();
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();

			boolean witness=btn_Witness.isEnabled();
			if(witness){
				report.reportPass("Witness button is displayed in enabled mode");
			}
			else{
				report.reportFail("Witness button is not displayed in enabled mode",true);
			}
			boolean flag=verifyFormStatus();
			if(flag){
				report.reportPass("Form status is displayed as clear mode");
			}
			else{
				report.reportFail("Form status is not changed to clear mode");
			}	

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyGeneralPainAndMedicalHistory(){
		try {
			webActions.waitForPageLoaded();
			webActions.clickAction(lbl_FormsMedicalHistory, "MedicalHistory");			
			webActions.waitForPageLoaded();
			Thread.sleep(5000);
			driver.switchTo().frame(0);
			webActions.waitForPageLoaded();
			webActions.click(txt_DateOfService, "DateOfService");
			String currentDate=getSystemCurrentDate();
			System.out.println(currentDate);
			webActions.sendKeys(txt_DateOfService,currentDate,"DateOfService");
			webActions.waitForPageLoaded();
			webActions.clickAction(txt_Weight, "weight");
			webActions.sendKeys(txt_Weight,"65","weight");
			webActions.waitForPageLoaded();
			webActions.click(txt_heightFeet, "height");
			webActions.sendKeys(txt_heightFeet,"5","height");
			webActions.waitForPageLoaded();
			webActions.click(txt_heightInches, "Inches");
			webActions.sendKeys(txt_heightInches,"6","Inches");
			webActions.waitForPageLoaded();
			webActions.click(txt_Age, "Age");
			webActions.sendKeys(txt_Age,"45","Age");
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_Submit, "Submit");
			Thread.sleep(5000);
			webActions.click(btn_Submit, "submit");
			webActions.waitForPageLoaded();
			Thread.sleep(15000);			
			driver.switchTo().parentFrame();
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();

			boolean witness=btn_Witness.isEnabled();
			if(witness){
				report.reportPass("Witness button is displayed in enabled mode");
			}
			else{
				report.reportFail("Witness button is not displayed in enabled mode",true);
			}
			boolean flag=verifyFormStatus();
			if(flag){
				report.reportPass("Form status is displayed as clear mode");
			}
			else{
				report.reportFail("Form status is not changed to clear mode");
			}	

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public boolean verifyFormStatus(){
		boolean flag=false;
		try {
			String actFormStatus=webActions.getAttributeValue(lbl_FormStatus, "src", "DocumentViewerFormStatus");
			if(actFormStatus.contains("success")){
				report.reportPass("Form status is displayed as clear mode");
				flag=true;
			}
			else{
				report.reportFail("Form status is not displayed as clear mode and actual displayed image is : " + actFormStatus);
				flag=false;
			}		
		} catch (Exception e) {
			report.reportFail(e.getMessage());
			flag=false;
		}
		return flag;
	}
	public  String getSystemCurrentDate(){
		String sysDate=new SimpleDateFormat("MM-dd-yyyy").format(Calendar.getInstance().getTime());
		return sysDate;	
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}


}
