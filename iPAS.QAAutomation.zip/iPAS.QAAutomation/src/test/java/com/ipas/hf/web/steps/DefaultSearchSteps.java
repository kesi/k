package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.DefaultSearchPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class DefaultSearchSteps {

	DefaultSearchPage search=new DefaultSearchPage();
	
	@Then("Verify the following fields and buttons: Page title as {string} and Search Text field, Filters, Date of Service, Facility Drop down and Apply, Additional Filters, Columns, Tools")
	public void verify_the_following_fields_and_buttons_Page_title_as_and_Search_Text_field_Filters_Date_of_Service_Facility_Drop_down_and_Apply_Additional_Filters_Columns_Tools(String pageTitle) {
		search.verifyFields(pageTitle);
	}
	
	@Then("Verify the display of default values and hint text")
	public void verify_the_display_of_default_values_and_hint_text(DataTable testData) throws Exception {
		search.verifyDefaultValues(testData);
	}
	
	@Then("Verify the Grid Header Names")
	public void verify_the_Grid_Header_Names(DataTable headerNames) {
		search.verifyHeaderNames(headerNames);
	}
	
	@Then("Validate the Account Number Hyper Link and verify the page navigation after click as {string}")
	public void validate_the_Account_Number_Hyper_Link_and_verify_the_page_navigation_after_click_as(String pageTitle) {
		search.verifyAccountNumberHyperLink(pageTitle);
	}
	
	@Then("Verify display of all the dates in {string} with date is {string} in the Column as {string}")
	public void verify_display_of_all_the_dates_in_with_date_is_in_the_Column_as(String fieldName, String testData, String columnName) throws Exception   {
		search.verifytheDateofService(fieldName,testData,columnName);
	}
	
	@Then("Verify the display of Results count on the top of the results grid")
	public void verify_the_display_of_Results_count_on_the_top_of_the_results_grid() {
		search.verifyResultsCount();
	}
	
	@Then("Verify the display of visit types in the Visit Date field")
	public void verify_the_display_of_visit_types_in_the_Visit_Date_field(DataTable visitDateTypes) {
		search.verifyVisitDateTypes(visitDateTypes);
	}
	
	@Then("Verify the validation message as {string}")
	public void verify_the_validation_message_as(String validationMessage) {
		search.verifytheValidationMessageNoResults(validationMessage);
	}
	
	@Then("Verify the display of Default Search data with Date of Service is Today and Facility as {string}")
	public void verify_the_display_of_Default_Search_data_with_Date_of_Service_is_Today_and_Facility_as(String facilityName) throws Exception {
		search.verifyDefaultSearchData(facilityName);
	}

}
