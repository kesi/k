package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class ViewiPASUserPage extends BasePage {

	AddNewUserPage addNewUser=new AddNewUserPage();

	@FindBy(xpath="//span[contains(text(),'Users')]")
	private WebElement lbl_UserPanelName;

	@FindBy(xpath="//a[contains(text(),'User Accounts')]")
	private WebElement lnk_UserAccounts;

	@FindBy(xpath="//div[@class='breadcrum-container']/span")
	private List<WebElement> lbl_Breadcrumb;

	@FindBy(xpath="//table[@class='e-table e-sortfilter']/thead/tr/th/div/span[1]")
	private List<WebElement> lbl_UserGrid;   

	@FindBy(xpath="//tbody/tr/td")
	private List<WebElement> lbl_GridDate;

	@FindBy(xpath="//button[text()='Add New User']")
	private WebElement btn_AddNewUser; 

	@FindBy(xpath="//div[@class='grid']/span")
	private WebElement lbl_ResultsCount; 

	@FindBy(xpath="//span[contains(text(),'Inactive')]")
	private WebElement lbl_Inactive; 

	@FindBy(xpath="//label[contains(text(),'Search')]")
	private WebElement lbl_Search; 

	@FindBy(xpath="//thead/tr/th/div/span")
	private WebElement lbl_UserGrid1; 

	@FindBy(xpath = "//table[@class='e-table']/tbody/tr/td[1]")
	private List<WebElement> tbl_EmployeeName;

	@FindBy(xpath="//input[@placeholder='Type Employee Name']")
	private WebElement txt_SearchEmployee;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody//tr[1]//td/div")
	private WebElement lbl_EmployeeName; 

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody//tr[1]//td[3]/div/a")
	private WebElement lnk_FacilityName; 

	@FindBy(xpath = "//div[@id='facilityModel']/div/div/form/div")
	private List<WebElement> lbl_FacilityModelWindow; 

	@FindBy(xpath = "//div[@id='facilityModel']/div/div/form/div[1]/h5")
	private WebElement lbl_EmpNameInFacilityWindow;

	@FindBy(xpath = "//div[@id='facilityModel']/div/div/form/div[2]/div/ejs-treeview/ul/li/div[2]/div")
	private WebElement lbl_CollapseExpandIconOfFacilityWindow;

	@FindBy(xpath = "//div[@id='facilityModel']/div/div/form/div[2]/div/ejs-treeview/ul/li/ul/li/div/span")
	private WebElement lbl_DepartmentName;

	@FindBy(xpath = "//button[contains(text(),'OK')]")
	private WebElement btn_Ok;

	@FindBy(xpath = "//div[@id='facilityModel']/div/div/form/div[2]/div/ejs-treeview/ul/li/div[2]/span")
	private WebElement lbl_FacilityName;

	@FindBy(xpath = "//div[@id='facilityModel']/div/div/form/div[2]/div/ejs-treeview/ul/li/ul/li/ul/li/div/span")
	private WebElement lbl_SupervisorName;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody//tr[1]//td[8]/div/a/i")
	private WebElement btn_LockIcon;

	@FindBy(xpath = "//div[@class='modal-content modal-lg']/form/div")
	private List<WebElement> lbl_PopUpElements;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody//tr[1]//td[1]/div/div/a")
	private WebElement lbl_EmpName;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody//tr[1]//td[2]/div")
	private WebElement lbl_OperatorID;

	@FindBy(xpath = "//div[@class='modal-content modal-lg']/form/div[1]/h5")
	private WebElement lbl_PopUpHeader;

	@FindBy(xpath = "//div[@class='modal-content modal-lg']/form/div[2]")
	private WebElement lbl_PopUpPswdDesc;

	@FindBy(xpath = "//div[@class='modal-content modal-lg']/form/div[3]/button[1]")
	private WebElement btn_PopUpCancel;

	@FindBy(xpath = "//div[@class='modal-content modal-lg']/form/div[3]/button[2]")
	private WebElement btn_PopUpReset;

	@FindBy(xpath="//button[(text()='Submit')]")
	private WebElement btn_AddUserSubmit; 

	@FindBy(xpath="//span[contains(text(),'Add User')]")
	private WebElement lbl_AddUser;

	@FindBy(xpath="//table[@id='asgrid_content_table']//tbody//tr//td[1]/div/div/a")
	private List<WebElement> lbl_EmpNames;

	@FindBy(xpath="//ejs-checkbox[@label='Inactive']/label/span[1]")
	private WebElement chk_InactiveUser;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody//tr[1]//td[1]/div/div/a")
	private WebElement lbl_EmployeName; 




	public ViewiPASUserPage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyBreadcrumbinViewiPASUserPage(DataTable breadcrumb ){
		try {
			ArrayList<String> expectdBreadcrumb = new ArrayList<>(breadcrumb.asList());
			webActions.waitAndClick(lnk_UserAccounts, "User Accounts Link");			
			ArrayList<String> actualBreadcrumb=webActions.getDatafromWebTable(lbl_Breadcrumb);
			report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumb);
			report.reportInfo("Expected Breadcrumb Titles "+expectdBreadcrumb);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumb, expectdBreadcrumb);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Breadcrumb Titles in View iPAS User page");
			}else{
				throw new Exception("Fail to verify the Breadcrumb Titles in View iPAS User page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyFieldNamesandButtonNames(DataTable fieldNames ){
		try {
			ArrayList<String> expectdFieldNames = new ArrayList<>(fieldNames.asList());
			webActions.waitAndClick(lnk_UserAccounts, "User Accounts Link");				
			webActions.waitForVisibilityOfAllElements(lbl_UserGrid, "UsersGrid");		
			ArrayList<String> actualFieldNames=webActions.getDatafromWebTable(lbl_UserGrid);
			actualFieldNames.add(webActions.getText(btn_AddNewUser, "AddNewUser"));
			actualFieldNames.add(webActions.getText(lbl_Inactive, "Inactive"));
			actualFieldNames.add(webActions.getText(lbl_Search, "Search"));
			report.reportInfo("Actual Field Names: "+actualFieldNames);
			report.reportInfo("Expected Field Names: "+expectdFieldNames);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualFieldNames, expectdFieldNames);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Field names and Button names in View iPAS User page");
			}else{
				throw new Exception("Fail to verify the Field names and Button names in View iPAS User page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyResultsCount(){
		try {
			webActions.waitAndClick(lnk_UserAccounts, "User Accounts Link");
			webActions.waitForVisibilityOfAllElements(lbl_UserGrid, "UsersGrid");
			ArrayList<String> resultsCount=webActions.getDatafromWebTable(tbl_EmployeeName);
			int expResultsCount=resultsCount.size();
			int actResultsCount=getResultsCount();
			if(actResultsCount==expResultsCount){
				report.reportPass("Results count is verified successfully and  result count is: "+expResultsCount);
			}
			else{
				throw new Exception("Results count verification is failed and displyed results count is: "+actResultsCount);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public int getResultsCount(){
		return Integer.valueOf(webActions.getText(lbl_ResultsCount, "Results count").replaceAll("\\D", ""));
	}

	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}

	public void verifyUserData(String employeeName,DataTable testData){
		try{
			ArrayList<String> actUserData=new ArrayList<String>();
			ArrayList<String> expUserData=new ArrayList<String>();		
			webActions.waitForVisibility(lbl_EmployeeName, "Employee Name");
			for(int i=1;i<=6;i++){
				String xpath="//table[@id='asgrid_content_table']//tbody//tr[1]//td["+i+"]/div";
				actUserData.add(driver.findElement(By.xpath(xpath)).getText());			
			}
			expUserData.add(employeeName);
			expUserData.add(getDatafromMap(testData, "Operator ID"));
			expUserData.add(getDatafromMap(testData, "Facility"));
			expUserData.add(getDatafromMap(testData, "Role"));
			expUserData.add(getDatafromMap(testData, "Employee Role"));
			String phone=getDatafromMap(testData, "Phone Number");		
			phone=phone.substring(0, 3)+')'+phone.subSequence(4, 6)+phone.substring(5+1);		
			expUserData.add("("+phone);

			report.reportInfo("Actual user data: "+actUserData);
			report.reportInfo("Expected user data: "+expUserData);
			ArrayList<String>unmatchedData=webActions.getUmatchedInArrayComparision(actUserData, expUserData);	
			if(unmatchedData.size()==0){
				report.reportPass("Verified user data in view iPAS user page");
			}
			else{
				throw new Exception("Fail to verify user data in user grid and unmatched data is: "+unmatchedData);
			}
		}
		catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickOnFacilityLink(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lnk_FacilityName, "FacilityName");
			webActions.waitForVisibilityOfAllElements(lbl_FacilityModelWindow, "FacilityWindowElements");
			report.reportPass("Facility window is opened successfully");
		} catch (Exception e) {
			report.reportFail("Unable to open the Facility window on selecting facility link from view user grid");
		}
	}

	public void verifyEmployeeName(String employeeName){
		try {
			String actuEmpName=webActions.getText(lbl_EmpNameInFacilityWindow, "EmployeeName");
			String actEmp[]=actuEmpName.split(" ");
			String firstName=actEmp[0];
			String lastName=actEmp[1];
			String actualEmpName=lastName+" "+firstName;
			report.reportInfo("Actual employee name: " + actualEmpName);
			report.reportInfo("Expected employee name: " + employeeName);
			if(actualEmpName.contentEquals(employeeName)){
				report.reportPass("Verified employee name in facility window");
			}
			else{
				report.reportFail("Failed to verify the Employee name : " + actualEmpName);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyFacilityName(DataTable testData){
		try {
			String expFacilityName=getDatafromMap(testData, "Facility");
			String actFacilityName=webActions.getText(lbl_FacilityName, "FacilityName");
			report.reportInfo("Actual facility name: " + actFacilityName);
			report.reportInfo("Expected facility name: " + expFacilityName);
			if(actFacilityName.contentEquals(expFacilityName)){
				report.reportPass("Verified Facility name successfully");
			}
			else{
				report.reportFail("Failed to verify the facility name : " + actFacilityName, true);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyExpandAndCollapseOfFacilityWindow(){
		try {
			String defaultMode=webActions.getAttributeValue(lbl_CollapseExpandIconOfFacilityWindow, "class", "ExpandICon");
			report.reportInfo("Default display mode for facility icon : " + defaultMode);
			if(defaultMode.contentEquals("e-icons e-icon-expandable")){
				report.reportPass("Verified facility expand mode");
			}
			else{
				report.reportFail("Fail to verify default expand mode of facility : " + defaultMode, true);
			}		
			webActions.click(lbl_CollapseExpandIconOfFacilityWindow, "ExpandICon");
			webActions.waitForVisibility(lbl_DepartmentName, "Department");
			String collapseMode=webActions.getAttributeValue(lbl_CollapseExpandIconOfFacilityWindow, "class", "CollapseICon");
			report.reportInfo("After collapsing display mode for facility icon : " + collapseMode);
			if(collapseMode.contentEquals("e-icons interaction e-icon-collapsible")){
				report.reportPass("Verified facility collapse mode");
			}
			else{
				report.reportFail("Fail to verify collapse mode of facility : " + collapseMode, true);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDepartmentNameUnderFacility(DataTable testData){
		try {
			String expDptName=getDatafromMap(testData, "Administrative Department");
			String actDptName=webActions.getText(lbl_DepartmentName, "DepartmentName");
			report.reportInfo("Actual department name: " + actDptName);
			report.reportInfo("Expected department name: " + expDptName);
			if(actDptName.contentEquals(expDptName)){
				report.reportPass("Verified Lobby name successfully");
			}
			else{
				report.reportFail("Failed to verify the lobby name under facility : " + actDptName, true);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}		
	}
	public void verifySuperviosrUnderDepartmentName(DataTable testData){
		try {
			String expSupervisorName=getDatafromMap(testData, "Supervisor");
			String expSuperName1=expSupervisorName.substring(0, 6);
			String expSuperName2=expSupervisorName.substring(6);
			expSupervisorName=expSuperName1+" "+expSuperName2;
			String actSupervisorName=webActions.getText(lbl_SupervisorName, "SupervisorName");
			report.reportInfo("Actual supervisor name: " + actSupervisorName);
			report.reportInfo("Expected supervisor name: " + expSupervisorName);
			if(actSupervisorName.contentEquals(expSupervisorName)){
				report.reportPass("Verified Lobby name successfully");
			}
			else{
				report.reportFail("Failed to verify the lobby name under facility : " + actSupervisorName);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}		
	}
	public void clickOnOkBtnVerfiyEmpName(DataTable testData){
		try {
			webActions.waitForVisibility(btn_Ok, "OkBtn");
			webActions.click(btn_Ok, "OkButton");
			report.reportPass("Clicked on OK button from facility window");
			String expFacilityName=getDatafromMap(testData, "Facility");
			String actFacilityName=webActions.getText(lnk_FacilityName, "FacilityName");
			report.reportInfo("Actual facility name: " + actFacilityName);
			report.reportInfo("Expected facility name: " + expFacilityName);
			if(actFacilityName.contentEquals(expFacilityName)){
				report.reportPass("Verified Facility name successfully");
			}
			else{
				report.reportFail("Failed to verify the facility name : " + actFacilityName);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyPasswordRestPopUp(DataTable testData){
		try {
			ArrayList<String> actResetElements=new ArrayList<String>();
			ArrayList<String> expResetElements=new ArrayList<String>();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_UserAccounts, "User Accounts Link");
			webActions.waitForVisibilityOfAllElements(lbl_UserGrid, "UsersGrid");
			webActions.click(btn_LockIcon, "LockIcon");
			webActions.waitForVisibilityOfAllElements(lbl_PopUpElements, "ResetPopUpElements");
			expResetElements.add(getDatafromMap(testData, "PopUp Name"));
			expResetElements.add(getDatafromMap(testData, "Cancel"));
			expResetElements.add(getDatafromMap(testData, "Reset"));
			String empName=webActions.getText(lbl_EmpName, "EmployeeName");			
			String actEmp[]=empName.split(" ");
			String firstName=actEmp[0];
			String lastName=actEmp[1];
			String actualEmpName=lastName+" "+firstName;
			String operator=webActions.getText(lbl_OperatorID, "OperatorID");
			String passwordDescription="Do you want to reset"+" "+actualEmpName+" "+"("+operator+")"+" "+"password?";
			expResetElements.add(passwordDescription);
			actResetElements.add(webActions.getText(lbl_PopUpHeader, "PopupTitle"));			
			actResetElements.add(webActions.getText(btn_PopUpCancel, "PopUpCancel"));
			actResetElements.add(webActions.getText(btn_PopUpReset, "PopUpReset"));
			actResetElements.add(webActions.getText(lbl_PopUpPswdDesc, "PswdDesc"));
			report.reportInfo("Actual popup elements: "+ actResetElements);
			report.reportInfo("Expected popup elements: "+ expResetElements);
			ArrayList<String>unmatchedData=webActions.getUmatchedInArrayComparision(actResetElements, expResetElements);	
			if(unmatchedData.size()==0){
				report.reportPass("Verified Reset password popup elements");
			}
			else{
				throw new Exception("Fail to verify reset password elements and unmatched data is: "+unmatchedData);
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	/** To verify the cancel function from password reset popup**/
	public void clickOnCancelBtnVerfiyEmpName(){
		try {
			webActions.waitForVisibility(btn_PopUpCancel, "CancelBtn");
			webActions.click(btn_PopUpCancel, "CancelBtn");
			report.reportPass("Clicked on Cancel button from Reset password window");
			webActions.waitAndClick(btn_AddNewUser, "Add New User");
			webActions.waitUntilisDisplayed(btn_AddUserSubmit, "Submit Button");
			String actPage=webActions.getText(lbl_AddUser, "AddUSer");
			if(actPage.contentEquals("Add User")){
				report.reportPass("Verified cancel button function successfully");
			}
			else{
				report.reportFail("Failed to verify the cancel button function : " + actPage);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyUserNamesFromViewUserGrid(String userName){
		boolean flag=false;
		try {
			webActions.clearValue(txt_SearchEmployee, "UserName");
			Thread.sleep(2000);
			webActions.clickAction(chk_InactiveUser, "Inactivechkbox");
			Thread.sleep(3000);
			ArrayList<String> actUserNames=webActions.getDatafromWebTable(lbl_EmpNames);
			flag=isFullArrayContainsWithData(actUserNames,userName);
			if(flag){
				report.reportPass("Verified inactive user from users list of view user grid");
			}
			else{
				report.reportFail("Fail to verify the inactive users list from view user grid");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public boolean isFullArrayContainsWithData(ArrayList<String> actArrayData,String expData) throws Exception{
		boolean flag=false;
		{

			try {
				if (actArrayData.size()!=0) {
					for (int data = 0; data < actArrayData.size(); data++) {
						if (actArrayData.get(data).contentEquals(expData)) {
							report.reportInfo(expData);
							report.reportInfo(actArrayData.get(data));
							flag=true;
							break;
						}
					} 
				}else{
					throw new Exception("Actual data is zero");
				}
			} catch (Exception e) {
				report.reportFail(e.getMessage());
			}

		}
		return flag;
	}
	public void verifyResultCountOnNoResultsFound(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_UserAccounts, "User Accounts Link");
			webActions.waitForVisibilityOfAllElements(lbl_UserGrid, "UsersGrid");
			webActions.waitAndClick(txt_SearchEmployee, "Search Employee");		
			webActions.waitForPageLoaded();
			webActions.enterValuesfromKeyBoard(txt_SearchEmployee, "1407gakol","Search Employee");
			webActions.waitForPageLoaded();
			int actResultsCount=getResultsCount();
			int expResultCount=0;
			report.reportInfo("actResultsCount: " + actResultsCount);
			report.reportInfo("expResultCount: " + expResultCount);
			if(actResultsCount==expResultCount){
				report.reportPass("Results count is verified successfully and  result count is: "+expResultCount);
			}
			else{
				throw new Exception("Results count verification is failed and displyed results count is: "+actResultsCount);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	public void verifyUserDisplayBasedOnSearch(String userName){		
		try {
			String user[]=userName.split(" ");
			String lastName=user[0];
			String firstName=user[1];
			String expEmpName=lastName+" "+firstName;
			webActions.waitAndClick(txt_SearchEmployee, "Search Employee");
			webActions.clearValue(txt_SearchEmployee, "EmployeeName");
			webActions.refreshPage();
			Thread.sleep(5000);
			webActions.waitForPageLoaded();
			webActions.enterValuesfromKeyBoard(txt_SearchEmployee, firstName,"Search Employee");
			webActions.waitForPageLoaded();
			String actEmpName=webActions.getText(lbl_EmployeName, "EmployeeName");
			report.reportInfo("Actual employee name: " + actEmpName);
			report.reportInfo("Expected employee name: " + expEmpName);
			if(actEmpName.contentEquals(expEmpName)){
				report.reportPass("Verified Employee name successfully");
			}
			else{
				report.reportFail("Failed to verify the employee name : " + actEmpName);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
