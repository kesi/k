package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class CreateNewsPage extends BasePage {
	@FindBy(xpath = "//input[@id='username']")
	private WebElement txt_UserName;

	@FindBy(xpath = "//a[contains(text(),'Maintenance')]")
	private WebElement lnk_Maintenance;

	@FindBy(xpath = "//a[contains(text(),'News')]")
	private WebElement lnk_News;

	@FindBy(xpath = "//button[contains(text(),'Add News')]")
	private WebElement btn_AddNews;

	@FindBy(xpath = "//form//span[contains(text(),'Content')]")
	private WebElement txt_Content;

	@FindBy(xpath = "//input[@id='title']")
	private WebElement txtbox_NewsTitle;

	@FindBy(xpath = "//form[1]/div[3]/ejs-richtexteditor[1]/div[2]/div[1]/p[1]")
	private WebElement txt_NewsTextTextBox;

	@FindBy(xpath = "//div[contains(text(),'Title is required.')]")
	private WebElement txt_TitleRequired;

	@FindBy(xpath = "//ejs-multiselect[@id='dropdownFacility']/div/div")
	private WebElement drpdwn_ServiceFacility;

	@FindBy(xpath = "//form[1]/div[5]/div[1]/div[2]/ejs-multiselect[1]/div[1]/div[1]/span[5]")
	private WebElement drpdwn_Role;

	@FindBy(xpath = "//div[@class='e-multi-select-wrapper e-down-icon']/select[@class='e-multi-hidden']/option")
	private WebElement chkbox_SelectAllRole;

	@FindBy(xpath = "//ul[@id='dropdownFacility_options']/li")
	private WebElement drpdwn_Faciltiyvalue;

	@FindBy(xpath = "//div[@class='e-multi-select-wrapper e-down-icon']/span/input[@placeholder='Select Facility']")
	private WebElement txtbox_ServiceFacility;

	@FindBy(xpath = "//div[@class='e-multi-select-wrapper e-down-icon']/span/input[@placeholder='Select Role']")
	private WebElement txtbox_Role;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs; 

	@FindBy(xpath = "//input[@id='addnewstartdate_input']")
	private WebElement txtbox_StartDate;

	@FindBy(xpath = "//input[@id='addnewenddate_input']")
	private WebElement txtbox_EndDate;

	@FindBy(xpath = "//div[contains(text(),'Facilities are required.')]")
	private WebElement msg_FacilityRequired;

	@FindBy(xpath = "//div[contains(text(),'Roles are required.')]")
	private WebElement msg_RoleRequired;

	@FindBy(xpath = "//div[contains(text(),'Start Date is required.')]")
	private WebElement msg_StartDateRequired;

	@FindBy(xpath = "//button[contains(text(),'Save')]")
	private WebElement btn_OneSave;

	@FindBy(xpath = "//form[1]/div[7]/div[1]/button[1]")
	private WebElement btn_Cancel;

	@FindBy(xpath = "//form[1]/div[7]/div[1]/button[2]")
	private WebElement btn_Save;

	@FindBy(xpath = "//input[@placeholder='Type News Title']")
	private WebElement txtbox_SearchTextBox;

	@FindBy(xpath = "//table[1]/thead[1]/tr[1]/th/div/span")
	private List<WebElement> lst_newsGridHeaders;

	@FindBy(xpath = "//maintenance-newslist[1]/div[1]/div[2]/div[2]/span[1][contains(text(),'Results:')]")
	private WebElement txt_Results;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody/tr/td/div")
	private List<WebElement> tbl_AllNews; 

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody//tr[1]//td[1]//div")
	private WebElement lbl_NewsTitle; 

	@FindBy(xpath = "//div[contains(text(),'Create and edit news to be displayed on iPAS dashb')]")
	private WebElement msg_NewsPanel; 

	@FindBy(xpath = "//form[1]/div[5]/div[2]/ejs-checkbox[1]/label[1]/span[1]")
	private WebElement chkbox_NewsPanel; 

	String lst_TotalNewsCount = "//table[@id='asgrid_content_table']//tbody/tr/td/div/a";

	@FindBy(xpath = "//maintenance-newslist[1]/div[1]/div[2]/div[2]/span[1]")
	private WebElement txt_SrchRsltCount; 

	@FindBy(xpath="//ipas-maintenance-add-news[1]/div[1]/form[1]/div[2]/div[1]/div[1]")
	private List<WebElement> lbl_MaximumLengthValidationMessage;

	@FindBy(xpath="//table[@id='asgrid_content_table']//tbody/tr[1]/td/div")
	private List<WebElement> lst_NewsDataFromGrid;


	public CreateNewsPage() {
		PageFactory.initElements(driver, this);
	}

	public void clickNewsToNavigateNewsList() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.clickBYJS(lnk_News, "NewsLink");
			report.reportInfo("clicked on News Link to navigate to List News Page");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_AddNews, "AddNews");
			report.reportPass("AddNews button is displayed");
			webActions.click(btn_AddNews,  "AddNews");
			webActions.waitForPageLoaded();
			String actText = webActions.getText(txt_Content, "ContentText");
			if(actText.contentEquals("Content")){
				report.reportPass("Navigate to CreateNews Page and Content Text id displayed");
			}else{
				throw new Exception("Failed to read Content Text");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyTitleisrequired() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.click(txtbox_NewsTitle, "TitleTextBox");
			report.reportInfo("Clicked on Title Text Box");
			webActions.waitForPageLoaded();
			webActions.click(txt_NewsTextTextBox, "NewsTextBox");
			report.reportInfo("News Text Box");
			webActions.waitForPageLoaded();
			String actTitleMsg = webActions.getText(txt_TitleRequired, "TitleRequired");
			if(actTitleMsg.contentEquals("Title is required")){
				report.reportPass("Title Mandatory Message is displayed");
			}else{
				throw new Exception("Failed to read Title Mandatory message");
			}
		}catch(Exception e){
			report.reportInfo(e.getMessage());
		}
	}

	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}

	public String getRandomString(int length){
		String alphabet = "abcdefghijklmnopqrstuvwxyz";
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		for(int i = 0; i < length; i++) {
			int index = random.nextInt(alphabet.length());
			char randomChar = alphabet.charAt(index);
			sb.append(randomChar);
		}
		String randomString = sb.toString();
		return randomString;
	}

	public void createNews(DataTable testData,String messageTitle,String messageContent) throws Exception{
		String newsTitle = null;
		try{
			StringBuilder unmatch=new StringBuilder();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
			newsTitle=getRandomString(8);
			webActions.sendKeys(txtbox_NewsTitle, newsTitle, "News Title");
			report.reportInfo("Entered Text in Title Text Box");

			webActions.waitForPageLoaded();
			String newsTextData=getRandomString(10);		
			webActions.waitForPageLoaded();
			webActions.click(txt_NewsTextTextBox, "News Text");
			report.reportInfo("Clicked on News Text Box");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_NewsTextTextBox, newsTextData, "News Text");
			report.reportInfo("Entered Text in News Text Box");
			webActions.waitForPageLoaded();

			String facility=getDatafromMap(testData,"Facility");
			selectDropdown(drpdwn_ServiceFacility, facility, "Facility");

			String role=getDatafromMap(testData,"Role");
			selectDropdown(drpdwn_Role, role, "Role");

			webActions.waitForPageLoaded();
			webActions.sendKeys(txtbox_StartDate, getDatafromMap(testData,"Start Date"), "Start Date");
			webActions.waitForPageLoaded();
			webActions.pressTab();
			webActions.waitForPageLoaded();
			webActions.sendKeys(txtbox_EndDate, getDatafromMap(testData,"End Date"), "End Date");
			webActions.waitForPageLoaded();
			webActions.scrollDownPage();	
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_Save, "Save");
			Thread.sleep(5000);
			webActions.clickAction(btn_Save, "SaveButton");
			report.reportPass("Clicked on Save Button");
			//Thread.sleep(25000);
			String msg="";
			String actTitle="";
			String actContent="";
			try {
				webActions.waitForVisibility(txt_ToastMsgs, "Messages");
				msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
				String[] titleContent=msg.split("\\n");
				actTitle = titleContent[0];
				actContent = titleContent[1];
				report.reportInfo("Actual alert message after user is created: "+msg);
				if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent))){
					report.reportPass("Successfully displayed the alert message after user is created: "+msg);
				}
				else{
					unmatch.append("Alert message is not displayed/matched after user is created: "+msg);
				}
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			searchCreatedNews(newsTitle);
			
			ArrayList<String>expCreatedNewsData=new ArrayList<String>();
			//expCreatedNewsData.add(getDatafromMap(testData,"News Title"));
			expCreatedNewsData.add(newsTitle);
			expCreatedNewsData.add(getDatafromMap(testData,"Facility"));
			expCreatedNewsData.add(getDatafromMap(testData,"Role"));
			expCreatedNewsData.add(getDatafromMap(testData,"Start Date"));
			expCreatedNewsData.add(getDatafromMap(testData,"End Date"));
			report.reportInfo("Expected Test Data from feature file is :"+expCreatedNewsData.size()+".............."+expCreatedNewsData);
			
			ArrayList<String> actCreatedNewsData = readGridDataFromNewsListPage();
			report.reportInfo("Actual Test data from News list Page is :"+actCreatedNewsData.size()+"..............."+actCreatedNewsData);
			
			ArrayList<String> unmatchAmounts=webActions.getUmatchedInArrayComparision(actCreatedNewsData, expCreatedNewsData);
			if(unmatchAmounts.size()==0){
				report.reportPass("News Data is matched successfully "+actCreatedNewsData);
			}else{
				report.reportFail("Failed to read News Data: "+unmatchAmounts,true);
			}
		}catch(Exception e){
			report.reportFail(""+e);
		}
	}

	

	public void selectServiceFacility(String value) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.click(drpdwn_ServiceFacility, "Facility");
			report.reportInfo("Click on Service Facility DropDown");
			webActions.selectByValue(drpdwn_ServiceFacility, value, "FacilityDropddownValue");
			report.reportPass("Selected value from Facility DropDown");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void selectDropdown(WebElement element,String valuetoSelect,String elementName) throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(element, elementName);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			driver.findElement(By.xpath("//li[contains(.,'"+valuetoSelect+"')]")).click();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		} catch (Exception e) {
			throw e;
		}
	}

	public void verifyFacilityRequiredMsg(String expText) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txtbox_ServiceFacility, "FacilityTextBox");
			report.reportInfo("ServiceFacility Text Box is displayed");
			webActions.click(drpdwn_ServiceFacility, "Facility Text Box");
			webActions.waitForPageLoaded();
			webActions.click(drpdwn_ServiceFacility, "Facility Text Box");
			webActions.waitForPageLoaded();
			String actText = webActions.getText(msg_FacilityRequired, "FacilityRequired");
			report.reportInfo("Mandatory Msg of Facility is :"+actText);
			if(actText.contentEquals(expText)){
				report.reportPass("Mandatory msg for Facility is displayed properly");
			}else{
				throw new Exception("Failed to read Mandatory msg for Facility");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}


	public void verifyRoleRequiredMsg(String expText) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txtbox_Role, "RoleTextBox");
			report.reportInfo("Role Text Box is displayed");
			webActions.click(drpdwn_Role, "Role Text Box");
			webActions.waitForPageLoaded();
			webActions.click(drpdwn_Role, "Role Text Box");
			webActions.waitForPageLoaded();
			String actText = webActions.getText(msg_RoleRequired, "RoleRequired");
			report.reportInfo("Mandatory Msg of Role is :"+actText);
			if(actText.contentEquals(expText)){
				report.reportPass("Mandatory msg for Role is displayed properly");
			}else{
				throw new Exception("Failed to read Mandatory msg for Role");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyStartDateMandatoryMsg(String expText) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txtbox_StartDate, "Start Date");
			report.reportInfo("Start Date Text Box is displayed");
			webActions.click(txtbox_StartDate, "Start Date Text Box");
			webActions.waitForPageLoaded();
			webActions.click(txtbox_EndDate, "Start Date Text Box");
			webActions.waitForPageLoaded();
			String actText = webActions.getText(msg_StartDateRequired, "Start Date");
			report.reportInfo("Mandatory Msg of Start Date is :"+actText);
			if(actText.contentEquals(expText)){
				report.reportPass("Mandatory msg for Start Date is displayed properly");
			}else{
				throw new Exception("Failed to read Mandatory msg for Start Date");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyCancelSaveBtns() throws Exception{
		try{
			webActions.waitForPageLoaded();
			String saveText = webActions.getText(btn_Save, "SaveBtn");
			report.reportPass("Save button name is :"+saveText);
			String cancelText = webActions.getText(btn_Cancel, "CancelBtn");
			report.reportPass("Cancel button name is :"+cancelText);
			if(saveText.contentEquals("Save")&&cancelText.contentEquals("Cancel")){
				report.reportPass("Buttons are displayed");
			}else{
				throw new Exception("");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifySearchTextBox() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.clickBYJS(lnk_News, "NewsLink");
			report.reportInfo("clicked on News Link to navigate to List News Page");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			if(webActions.isDisplayed(txtbox_SearchTextBox, "Search TextBox")){
				report.reportPass("Search Text Box is displayed in News List Page");
			}else{
				throw new Exception("failed to find Search Text Box");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyNewsListGridHeaders(DataTable expGridHeaders) throws Exception{
		try{
			webActions.waitForPageLoaded();			
			ArrayList<String> expAllGridHeaders = new ArrayList<>(expGridHeaders.asList());
			report.reportInfo("Expected Tabs Names in Model Window : "+expAllGridHeaders);		
			ArrayList<String> actAllGridHeaders = webActions.getDatafromWebTable(lst_newsGridHeaders);
			report.reportInfo("List of Grid Headers are :"+actAllGridHeaders.size()+"              "+actAllGridHeaders);

			ArrayList<String> unmatchedGridHeaderNames=getUmatchedInArrayComparision(expAllGridHeaders,actAllGridHeaders);
			if(unmatchedGridHeaderNames.size()==0){
				report.reportPass("Verified Grid Header Names Successfully");
			}
			else{
				throw new Exception("Fail to verify Grid Header Names in News List and unmatched Headers are:"+unmatchedGridHeaderNames);
			}		
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public ArrayList<String> getUmatchedInArrayComparision(List<String> actData, List<String> expData) throws Exception
	{
		ArrayList<String> UnmatchedArray = new ArrayList<String>();
		if(actData!=null && expData!=null &&actData.size()>0&&expData.size()>0 && actData.size()==expData.size()){
			for(int data=0;data<actData.size();data++)
			{
				if(!((actData.get(data)).contentEquals(expData.get(data))))
					UnmatchedArray.add(actData.get(data));	
			}
		}
		else{
			throw new Exception("Arrya Sizes are not matched");
		}
		return UnmatchedArray;			
	}

	public void verifyResultsText() throws Exception{
		try{
			webActions.waitForPageLoaded();
			if(webActions.getText(txt_Results, "Results").contains("Results:")){
				report.reportPass("Results Text is displayed below Search Text Box");
			}else{
				throw new Exception("unable to find Results Text");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void searchCreatedNews(String newsTitle) throws Exception{
		String expNewsTitle = null;
		try{
			StringBuilder unmatch=new StringBuilder();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			try {
				webActions.waitForVisibilityOfAllElements(tbl_AllNews, "All News Grid");
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(txtbox_SearchTextBox, "Search News");
			webActions.click(txtbox_SearchTextBox, "Search Employee");
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
			webActions.enterValuesfromKeyBoard(txtbox_SearchTextBox, newsTitle,"Search Employee");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibility(lbl_NewsTitle, "News Title");
			String actNewsTitle=webActions.waitAndGetText(lbl_NewsTitle, "News Title");
			expNewsTitle=newsTitle;
			if(expNewsTitle.contentEquals(actNewsTitle)){
				report.reportPass("Newly created News is displayed successfully in the News list page: "+actNewsTitle);
			}else{
				unmatch.append("Incorrect News Title is displayed in the in the News list page after new News is created:"+actNewsTitle);
			}
			if(unmatch.length()==0){
				report.reportPass("Successfully verified the new News creation functionality");
			}else{
				throw new Exception("Fail to verify the new News creation functionality: "+unmatch);
			}
		}catch(Exception e){
			report.reportInfo(e.getMessage());
		}
	}

	public void verifyNewsDescriptiveText(String expNewsPanelText) throws Exception{
		try{
			webActions.waitForPageLoaded();
			String actNewsPanelText = webActions.getText(msg_NewsPanel, "NewsPanelText");
			report.reportInfo("Actual News Panel Text is :"+actNewsPanelText);
			if(actNewsPanelText.contentEquals(expNewsPanelText)){
				report.reportPass("News Panel Text is displayed properly");
			}else{
				throw new Exception("Failed to read News Panel Text");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void createNewsWithAllFieldsData(DataTable testData,String messageTitle,String messageContent) throws Exception{
		String newsTitle = null;
		try{
			StringBuilder unmatch=new StringBuilder();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForPageLoaded();
			newsTitle=getRandomString(8);
			webActions.sendKeys(txtbox_NewsTitle, newsTitle, "News Title");
			report.reportInfo("Entered Text in Title Text Box");

			webActions.waitForPageLoaded();
			String newsTextData=getRandomString(10);		
			webActions.waitForPageLoaded();
			webActions.click(txt_NewsTextTextBox, "News Text");
			report.reportInfo("Clicked on News Text Box");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_NewsTextTextBox, newsTextData, "News Text");
			report.reportInfo("Entered Text in News Text Box");
			webActions.waitForPageLoaded();

			String facility=getDatafromMap(testData,"Facility");
			selectDropdown(drpdwn_ServiceFacility, facility, "Facility");

			String role=getDatafromMap(testData,"Role");
			/*selectDropdown(drpdwn_Role, role, "Role"); */

			try{
				webActions.waitForPageLoaded();
				if(role.contentEquals("Select All")){
					/*selectDropdown(drpdwn_Role, "Client Administrator", "Role");
					webActions.waitForPageLoaded();
					selectDropdown(drpdwn_Role, "PELITAS Administrator", "Role");
					webActions.waitForPageLoaded();
					selectDropdown(drpdwn_Role, "Registrar", "Role");
					webActions.waitForPageLoaded();
					selectDropdown(drpdwn_Role, "Supervisor", "Role");
					webActions.waitForPageLoaded();*/
					//Thread.sleep(3000);
					webActions.click(chkbox_SelectAllRole, "Select All");
					webActions.waitForPageLoaded();
				}else {
					selectDropdown(drpdwn_Role, role, "Role");
					webActions.waitForPageLoaded();
				}

			}catch(Exception e){

			}
			webActions.waitForPageLoaded();
			webActions.clickBYJS(chkbox_NewsPanel, "Priority");
			report.reportPass("Priority check box is selected ");

			webActions.waitForPageLoaded();
			webActions.sendKeys(txtbox_StartDate, getDatafromMap(testData,"Start Date"), "Start Date");
			webActions.waitForPageLoaded();
			webActions.pressTab();
			webActions.waitForPageLoaded();

			webActions.waitForPageLoaded();
			webActions.sendKeys(txtbox_EndDate, getDatafromMap(testData,"End Date"), "End Date");
			webActions.waitForPageLoaded();
			webActions.pressTab();
			webActions.waitForPageLoaded();

			webActions.scrollDownPage();	
			webActions.waitForPageLoaded();
			webActions.scrollBarHandle(btn_Save, "Save");
			Thread.sleep(5000);
			webActions.clickAction(btn_Save, "SaveButton");
			report.reportPass("Clicked on Save Button");
			//Thread.sleep(25000);
			String msg="";
			String actTitle="";
			String actContent="";
			try {
				webActions.waitForVisibility(txt_ToastMsgs, "Messages");
				msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
				String[] titleContent=msg.split("\\n");
				actTitle = titleContent[0];
				actContent = titleContent[1];
				report.reportInfo("Actual alert message after user is created: "+msg);
				if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent))){
					report.reportPass("Successfully displayed the alert message after user is created: "+msg);
				}
				else{
					unmatch.append("Alert message is not displayed/matched after user is created: "+msg);
				}
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			searchCreatedNews(newsTitle);

		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyCancelButtonFunctionality() throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_Cancel, "Cancel");
			webActions.waitForPageLoaded();
			String addNewsButtonName=webActions.waitAndGetText(btn_AddNews, "Add News");
			if("Add News".contentEquals(addNewsButtonName)){
				report.reportInfo("User is navigated to News List page after click on Cancel button and verified Add News Button: "+addNewsButtonName);
				report.reportPass("Successfully verified the Cancel button functionality in the Add News page");	
			}else{
				throw new Exception("Fail to verify the Cancel button functionality, Users is not navigated to News List page");
			}
		} catch (Exception e) {	
			report.reportFail(e.getMessage());
		}
	}

	public void verifyNewsCountUnderNewsList() throws Exception{
		try{
			webActions.waitForPageLoaded();
			String expRsltCount=webActions.getText(txt_SrchRsltCount, "Resultscount");
			String[] splited = expRsltCount.split(":\\s");
			expRsltCount=splited[1];
			int expGridRsltCount=Integer.parseInt(expRsltCount);  
			report.reportInfo("Expected Results Count after Results Text is : "+expGridRsltCount);
			List<WebElement> actNewsRowsCount=driver.findElements(By.xpath(lst_TotalNewsCount));
			report.reportInfo("Actual Results Count in News List is : "+actNewsRowsCount.size());
			int actGridCount = actNewsRowsCount.size();

			if(expGridRsltCount==actGridCount){
				report.reportPass("Total News Count is displayed properly");
			}else{
				throw new Exception("Failed to read News Count in News List Page");
			}

		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void selectRole(String roleValue) throws Exception{
		try{
			String role =null;

		}catch(Exception e){

		}
	}



	public void validationMessageForNewsTitle(String data,DataTable validationMessage) throws Exception{
		try{
			ArrayList<String> expectdValidationMessages = new ArrayList<>(validationMessage.asList());
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txtbox_NewsTitle, "NewsTitle");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txtbox_NewsTitle, data, "NewsTitle");
			webActions.waitForPageLoaded();
			webActions.click(txt_NewsTextTextBox, "NewsText");
			webActions.waitForPageLoaded();
			ArrayList<String> actualValidationMessages = new  ArrayList<String>();
			List<WebElement> listMessage=lbl_MaximumLengthValidationMessage;
			for (WebElement element : listMessage) {
				String text=element.getText();
				actualValidationMessages.add(text.replace("\n", " "));
			}
			report.reportInfo("Actual Validation Messages: "+actualValidationMessages);
			report.reportInfo("Expected Validation Message: "+expectdValidationMessages);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualValidationMessages, expectdValidationMessages);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Validation Messages if enter greater than maximum length characters in News Details Page");
			}else{
				throw new Exception("Fail to verify the Validation Messages if enter greater than maximum length characters in News Details page: "+unmatch);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}


	public ArrayList<String> readGridDataFromNewsListPage() throws Exception{
		webActions.waitForPageLoaded();
		ArrayList<String> newsData = webActions.getDatafromWebTable(lst_NewsDataFromGrid);
		ArrayList<String> expdata = new ArrayList<String>();
		report.reportPass("expdata Data is :"+newsData.size());
		for(int i=0;i<newsData.size()-1;i++){
			expdata.add(newsData.get(i));
		}
		return expdata;
	}


	public CreateNewsPage openIpasApp() {
		try {
			String URL = TestBase.prop.ipasURL();
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to Open iPAS application");
		}
		return (CreateNewsPage) base(CreateNewsPage.class);
	}


	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_UserName);
	}

}
