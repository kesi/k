package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.PatientVisitSummaryAllDataPanelPage;
import com.ipas.hf.web.pages.ipasPages.WorkListPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class WorkListSteps {
	WorkListPage wPage=new WorkListPage();
	Login logIn=new Login();


	@Then("Verify the display of columns from {string} page")
	public void verify_the_display_of_columns_from_page(String page, DataTable columnNames) {
		wPage.verifyColumnNames(page, columnNames);
	}
	@Then("Click on account number filter icon and verify the window")
	public void click_on_account_number_filter_icon_and_verify_the_window() {
		wPage.verifyFiterWindow();
	}

	@Then("Click on selectAll and verify the filter mode as {string}")
	public void click_on_selectAll_and_verify_the_filter_mode_as(String type) {
		wPage.verifyfilterMode(type);
	}

	@Then("Click on SelectAll and verify the filter mode as {string}")
	public void click_on_SelectAll_and_verify_the_filter_mode_as(String type) {
		wPage.verifyfilterMode(type);
	}

	@Then("Enter invalid search data as {string} in search box and verify message as {string}")
	public void enter_invalid_search_data_as_in_search_box_and_verify_message_as(String testData, String msg) {
		wPage.verifySearchFilterMessage(testData,msg);
	}

	@Then("Select cross option and verify the filter mode")
	public void select_cross_option_and_verify_the_filter_mode() {
		wPage.clickOnCrossAndVerify();
	}

	@Then("Click on Clear button and verify")
	public void click_on_Clear_button_and_verify() {
		wPage.clickOnClearAndVerify();
	}

	@Then("Click on AccountNumber from {string} page")
	public void click_on_AccountNumber_from_page(String page) throws Exception {
		wPage.clickOnAccountLinkNumber(page);
	}

	@Then("Click on worklist link")
	public void click_on_worklist_link() {
		wPage.clickOnWorkListBreadCrumb();
	}

	@Then("Verify the results grid count")
	public void verify_the_results_grid_count() {
		wPage.verifyAccountsCount();
	}
	@Then("Perform search and verify the accounts count")
	public void perform_search_and_verify_the_accounts_count() {
		wPage.performSearchAndVerifyCount();
	}
	@Then("Verify the display of tabs")
	public void verify_the_display_of_tabs(DataTable names) {
		wPage.verifyTabs(names);
	}
	@Then("Click on eport to excel from tools option")
	public void click_on_eport_to_excel_from_tools_option() {
		wPage.clickOnExport();
	}
	@Then("Click on tab as {string}")
	public void click_on_tab_as(String tab) {
		wPage.clickOnTab(tab);
	}
	@Then("Click on select All and verify the accounts count")
	public void click_on_select_All_and_verify_the_accounts_count() {
		wPage.clickSelectAllAndVerifyCount();
	}
	@Then("Verify the display records status as {string}")
	public void verify_the_display_records_status_as(String status) {
		wPage.verifyChallengedRecords(status);
	}
	@Then("Verify the eligibility results grid count")
	public void verify_the_eligibility_results_grid_count() {
		wPage.verifyEligibilityAccountsCount();
	}

	@Then("Perform search and verify the eligibility accounts count")
	public void perform_search_and_verify_the_eligibility_accounts_count() {
		wPage.performSearchAndVerifyEligibilityCount();
	}

	@Then("Click on select All and verify the eligibility accounts count")
	public void click_on_select_All_and_verify_the_eligibility_accounts_count() {
		wPage.clickSelectAllAndEligibilityCount();
	}
	@Then("Click on eligibility account number filter")
	public void click_on_eligibility_account_number_filter() {
		wPage.clickOnEligibilityAccountFilter();
	}
	@Then("Get the value from response body and get value of {string} and verify accountnumber")
	public void get_the_value_from_response_body_and_get_value_of_and_verify_accountnumber(String accountNumber) {
		String acctNumber = logIn.getVisitIdFromResponse(accountNumber);		
		wPage.verifyEligibilityAccountNumber(acctNumber);

	}
	@Then("Navigate to WorkList Page from other page")
	public void navigate_to_WorkList_Page_from_other_page() {
		wPage.navigateToWorList();
	}
	@Then("Get the value from response body and get value of {string} and verify message as {string}")
	public void get_the_value_from_response_body_and_get_value_of_and_verify_message_as(String accountNumber, String msg) {
		String acctNumber = logIn.getVisitIdFromResponse(accountNumber);
		wPage.verifySearchFilterMessage(acctNumber,msg);
	}
	@Then("Click on eligibility link after primary insurance run")
	public void click_on_eligibility_link_after_primary_insurance_run() {
		wPage.clickOnEligibile();
	}
	@Then("Go the other tabs or pages and back to the eligibility and verify the results")
	public void go_the_other_tabs_or_pages_and_back_to_the_eligibility_and_verify_the_results() {
		String accountNumber = logIn.getVisitIdFromResponse("$..displayPatientAccountId");
		wPage.verifySearchFilter(accountNumber);
	}

}
