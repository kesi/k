package com.ipas.hf.web.pages.ipasPages;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class ServiceTrackerPage extends BasePage {
	private StepLogging log = StepLogging.getLoggingObject();
	private RestActions rest = new RestActions();

	@FindBy(linkText="Service Tracker")
	private WebElement lnk_ServiceTracker;

	@FindBy(xpath  = "//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_Search;

	@FindBy(xpath = "//button[@class='btn btn-primary btn-md']")
	private WebElement btn_Apply;

	@FindBy(xpath = "//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']")
	private WebElement li_IntakeStatus;

	@FindBy(xpath = "//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']")
	private List<WebElement> li_DefaultGridStatusNames;

	@FindBy(xpath = "//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']")
	private WebElement li_DefaultGridStatus1;

	@FindBy(xpath = "//input[@id='username']")
	private WebElement txt_UserName;

	@FindBy(xpath = "//a[@data-toggle='dropdown']//img")
	private WebElement lnk_Menu;

	@FindBy(xpath = "//*[contains(text(),' Logout')]")
	private WebElement lnk_Logout;

	@FindBy(xpath = "//label[contains(text(),'Search')]//following::input[1]")
	private WebElement txt_SimpleSearch;

	@FindBy(xpath = "//div[contains(text(),'In Service (0M)')]")
	private WebElement txt_Statusname;

	@FindBy(xpath = "//service-tracker-facility//ejs-dropdownlist/span/input")
	private WebElement ddl_Facility;

	@FindBy (xpath = "//service-tracker-lobby//ejs-dropdownlist/span/input")
	private WebElement ddl_Lobby;

	@FindBy(xpath = "//service-tracker-department//ejs-dropdownlist/span/input")
	private WebElement ddl_ServiceDepartment;

	@FindBy(xpath = "//ejs-datepicker[1]/span[1]/input[1]")
	private WebElement ddl_VisitDate;

	@FindBy(xpath = "//service-tracker-department//span[@class='e-input-group-icon e-ddl-icon e-search-icon']")
	private WebElement icon_ServiceDepartment;

	@FindBy(xpath="//service-tracker-department//span[@class='e-input-group-icon e-ddl-icon e-search-icon']")
	private WebElement ddl_Department;

	@FindBy(xpath = "//button[@target='#stcolumnview']")
	private WebElement btn_Columns;

	@FindBy(xpath = "//ul[contains(@class,'e-list-parent e-ul')]/li/div")
	private List<WebElement> li_TotalStatus;

	@FindBy(xpath = "//ul[contains(@class,'e-list-parent e-ul')]/li/div")
	private WebElement li_TotalColumnStatus;

	@FindBy(xpath = "//li[@class='e-list-item e-level-1 e-checklist e-active']")
	private List<WebElement> li_defaultcolumnNames;

	@FindBy(xpath = "//li[@class='e-list-item e-level-1 e-checklist e-active']")
	private List<WebElement> li_selectedColumnNames;

	@FindBy(xpath = "//li[@class='e-list-item e-level-1 e-checklist e-active'][7]//span[@class='e-frame e-icons e-check']")
	private WebElement lbl_columnActiveComplete;

	@FindBy(xpath = "//ul[@class='e-list-parent e-ul ']/li[7]")
	private WebElement lbl_columnInActiveComplete;

	@FindBy(xpath = "//ejs-datepicker[1]/span[1]/input[1]")
	private WebElement txt_DateOfService;

	@FindBy(xpath = "//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_SearchBox;

	@FindBy(xpath = "//div[contains(@id,'e-dropdown-btn_')]//ul/li/div/div")
	private List<WebElement> lst_ColumnBox;

	@FindBy(xpath = "//table/tbody/tr/td/div/div/div/div")
	private List<WebElement> li_VisitCardParts;
	
	public ServiceTrackerPage() {
		PageFactory.initElements(driver, this);
	}

	public void waitForVisitCardLoade(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(li_VisitCardParts, "VisitCard Parts");
		} catch (Exception e) {
		}
	}
	public void navigatetoServiceTrackerPage(String pageTitle) throws Exception {
		try{
			webActions.waitForVisibility(lnk_ServiceTracker, "Service Tracker");
			report.reportInfo("Service Tracker tab link is displayed");
			webActions.clickBYJS(lnk_ServiceTracker, "ServiceTracker");
			webActions.waitForPageLoaded();
			report.reportInfo("Clicked on Service Tracker Tab");
			waitForVisitCardLoade();
			report.reportInfo("Grid list is displayed on Service Tracker Board Page");
			report.reportInfo("Navigated to Service Tracker Page");
			String actPageTitle =webActions.getPageTitle();
			if(pageTitle.contentEquals(actPageTitle)){
				report.reportPass("Navigated to Service Tracker Page");	
			}else{
				throw new Exception("Not navigated to Service Tracker Page "+actPageTitle);
			}		
		}catch(Exception e){		
			//webActions.waitUntilisDisplayed(li_IntakeStatus, "Status Columns");
			report.reportFail(e.getMessage());
		}
	}

	public void verifyFieldsDisplay(String pageTitle) throws Exception {
		try{
			webActions.waitForVisibility(txt_Search, "Search Text Field");
			webActions.assertDisplayed(txt_Search, "Search Text Field");
			report.reportInfo("Verified the 'Search Text Field'");
			webActions.assertDisplayed(ddl_Facility, "Facility");
			report.reportInfo("Verified the 'Facility'");
			webActions.assertDisplayed(ddl_Lobby, "Lobby");
			report.reportInfo("Verified the 'Lobby'");
			webActions.assertDisplayed(ddl_ServiceDepartment, "Service Department");
			report.reportInfo("Verified the 'Service Department'");
			webActions.assertDisplayed(ddl_VisitDate, "Visit Date");
			report.reportInfo("Verified the 'Visit Date'");
			webActions.assertDisplayed(btn_Apply, "Apply");
			report.reportInfo("Verified the 'Apply'");
			webActions.assertDisplayed(btn_Columns, "Columns");
			report.reportInfo("Verified the 'Columns'");
			String actPageTitle=webActions.getPageTitle();
			if(pageTitle.contentEquals(actPageTitle)){ 
				report.reportPass("Verified all fields in Service Tracker successfully");	
			}else{
				throw new Exception("Fail to verify the default Fields in Service Tracker page and actual page title is: "+actPageTitle);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDefaultValues(DataTable testData) {
		try {
			List<String> expData = testData.asList(String.class);
			List<String> actData = new ArrayList<>(); 
			webActions.waitForClickAbility(ddl_Facility, "Facility");
			actData.add(webActions.getAttributeValue(txt_Search, "placeholder", "Search Box"));
			actData.add(webActions.getValue(ddl_Facility, ""));
			actData.add(webActions.getValue(ddl_Lobby, ""));
			actData.add(webActions.getValue(ddl_ServiceDepartment,""));
			//actData.add(webActions.getValue(ddl_VisitDate, ""));
			report.reportInfo("Actual Default Values in Servcie Tracker Page: "+actData);
			report.reportInfo("Expected Default Values in Servcie Tracker Page: "+expData);
			ArrayList<String> unmatchedData=getUmatchedInArrayComparision(actData,expData);
			if(unmatchedData.size()==0){
				report.reportPass("Verified Default Values in Service Tracker page successfully");
			}
			else{
				throw new Exception("Fail to verify Default Values in Service Tracker page and unmatched data is: "+unmatchedData);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void defaultGridStatusColumns(DataTable expDefaultGridStatusColumns){
		try{
			List<String> expDefaultStatus = expDefaultGridStatusColumns.asList(String.class);
			report.reportInfo("Expected Default Status Column names in Service Tracker Page : "+expDefaultStatus);
			webActions.waitUntilListisDisplayed(li_DefaultGridStatusNames, "Default Grid Header");
			List<String> actDefaultStatus=gridColumnNames(li_DefaultGridStatusNames);
			report.reportInfo("Actual Default Status Columns in Service Tracker Page : "+actDefaultStatus);
			ArrayList<String> unmatchedHeaderNames=getUmatchedInArrayComparision(actDefaultStatus,expDefaultStatus);
			if(unmatchedHeaderNames.size()==0){
				report.reportPass("Verified Default Grid Status Columns names Successfully");
			}
			else{
				throw new Exception("Failed to verify Default Status Column names and unmatched Default Status names are : "+unmatchedHeaderNames);
			}

		}catch(Exception e){
			report.reportFail("Unable to read default grid status columns names");
		}
	}

	public void totalColumnStatus(DataTable expStatus) throws Exception{
		try{
			webActions.waitUntilisDisplayed(li_IntakeStatus, "Status Columns");
			webActions.waitForVisibility(btn_Columns, "Columns");
			webActions.clickBYJS(btn_Columns, "Columns");
			report.reportPass("Clicked on Columns button");
			List<String> expTotalStatus = expStatus.asList(String.class);
			report.reportInfo("Expected total Status Names in Service Tracker Page : "+expTotalStatus);
			List<String> actTotalStatus=webActions.getDatafromWebTable(li_TotalStatus);
			report.reportInfo("Actual total Status Names in Service Tracker Page : "+actTotalStatus);
			ArrayList<String> unmatchedStatusNames=getUmatchedInArrayComparision(actTotalStatus,expTotalStatus);
			if(unmatchedStatusNames.size()==0){
				report.reportPass("Verified Total Status Names in Service Tracker page successfully");
			}
			else{
				throw new Exception("Fail to verify Total Status Names in Service Tracker Page and unmatched Names are: "+unmatchedStatusNames);
			}		
		}catch(Exception e){
			report.reportFail("Unabl to read count of Total Status :"+e.getMessage());
		}
	}

	public void verifySelectedColumnInGrid(String selectStatus) throws Exception{
		try{
			webActions.waitUntilisDisplayed(li_IntakeStatus, "Status Columns");
			webActions.waitForVisibility(btn_Columns,"Columns");
			webActions.waitForClickAbilityAndClick(btn_Columns, "Columns");
			report.reportPass("Clicked on Columns button");
			List<String> totalStatusColumns = webActions.getDatafromWebTable(li_TotalStatus);
			int allStatus = totalStatusColumns.size();
			report.reportPass("Status Columns list is :" +allStatus);
			webActions.selectCheckBoxfromList(li_TotalStatus, selectStatus, "status name");
			report.reportPass("Selected the required the status");
			webActions.waitForClickAbilityAndClick(btn_Columns, "Columns");
			report.reportPass("Clicked on Columns button");
			webActions.waitForLoadingBarToAppear();
			webActions.waitForVisibility(li_DefaultGridStatus1, "Grid Status Names");
			report.reportPass("Columns names list is displayed");
			List<String> gridColumns = gridColumnNames(li_DefaultGridStatusNames);
			int allGridColumns = gridColumns.size();
			report.reportPass("Present Columns List in Service Tracker Page :"+allGridColumns);
			for(int columnName =0; columnName<=allGridColumns;columnName++){
				if(gridColumns.get(columnName).contentEquals(selectStatus)){
					report.reportPass("Selected column name "+selectStatus+" is displayed in the grid");
					break;
				}else{
					report.reportFail("Selected column name is not displayed in the grid");
				}
			}
		}catch(Exception e){ 
			report.reportFail(e.getMessage());
		}
	}

	public void compareDefaultStatusInGridAndColumnsList(){
		try{
			webActions.waitUntilisDisplayed(li_IntakeStatus, "Status Columns");
			webActions.waitForVisibility(btn_Columns,"Columns");
			webActions.waitForClickAbilityAndClick(btn_Columns, "Columns");
			report.reportPass("Clicked on Columns button");	
			List<String> expDefaultStatus = selectedColumnList(li_defaultcolumnNames);
			report.reportInfo("Expected Default Status Column names in Service Tracker Page : "+expDefaultStatus);
			webActions.waitUntilListisDisplayed(li_DefaultGridStatusNames, "Default Grid Header");
			List<String> actDefaultStatus=gridColumnNames(li_DefaultGridStatusNames);
			report.reportInfo("Actual Default Status Columns in Service Tracker Page : "+actDefaultStatus);
			ArrayList<String> unmatchedHeaderNames=getUmatchedInArrayComparision(actDefaultStatus,expDefaultStatus);
			if(unmatchedHeaderNames.size()==0){
				report.reportPass("Verified Default Grid Status Columns names Successfully");
			}
			else{
				throw new Exception("Failed to verify Default Status Column names and unmatched Default Status names are : "+unmatchedHeaderNames);
			}

		}catch(Exception e){
			report.reportFail("Unable to read default grid status columns names");
		}
	}

	public void verifyAllSelectedColumnInGrid(DataTable expStatusList) throws Exception{
		try{
			webActions.waitUntilisDisplayed(li_IntakeStatus, "Status Columns");
			webActions.waitForVisibility(btn_Columns, "Columns Button");
			webActions.clickBYJS(btn_Columns, "Columns Button");

			ArrayList<String> expColumns = new ArrayList<>(expStatusList.asList());
			report.reportPass("Total columns to select are :"+expColumns.size());
			int exptotalstaus = expColumns.size();

			for(int statusToSelect =0; statusToSelect<exptotalstaus;statusToSelect++){
				webActions.waitUntilListisDisplayed(li_TotalStatus, "List");
				report.reportPass("List is displayed");
				webActions.selectCheckBoxfromList(li_TotalStatus, expColumns.get(statusToSelect), "status name "+expColumns.get(statusToSelect)+" is selected");
			}
			webActions.clickBYJS(btn_Columns, "Columns Button");
			webActions.clickBYJS(btn_Columns, "Columns Button");
			webActions.waitUntilListisDisplayed(li_selectedColumnNames, "List");
			List<String> expSelectedColumnsNames= selectedColumnList(li_selectedColumnNames);
			report.reportInfo("Total columns selected under Column list : "+expSelectedColumnsNames);		

			webActions.clickBYJS(btn_Columns, "Columns Button");
			report.reportPass("Clicked on Columns Button");
			webActions.waitUntilListisDisplayed(li_DefaultGridStatusNames, "list");
			report.reportPass("Grid columns names are displayed");

			List<String> actColumnStatus=gridColumnNames(li_DefaultGridStatusNames);	
			report.reportInfo("Actual Default Status Columns in Service Tracker Page : "+actColumnStatus);

			ArrayList<String> unmatchedHeaderNames=getUmatchedInArrayComparision(expSelectedColumnsNames,actColumnStatus);
			if(unmatchedHeaderNames.size()==0){
				report.reportPass("Selected Columns are displayed on the Service Tracker page grid  Successfully");
			}
			else{
				throw new Exception("Failed to verify display of selected columns on the Service Tracker Page : "+unmatchedHeaderNames);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void unselectedAndVerifyStatusInGrid(DataTable expStatusList){
		try{
			webActions.waitUntilisDisplayed(li_IntakeStatus, "Status Columns");
			webActions.waitForVisibility(btn_Columns, "Columns Button");
			webActions.clickBYJS(btn_Columns, "Columns Button");
			ArrayList<String> expColumns = new ArrayList<>(expStatusList.asList());
			report.reportPass("Total columns to select are :"+expColumns.size());
			int exptotalstaus = expColumns.size();
			for(int statusToSelect =0; statusToSelect<exptotalstaus;statusToSelect++){
				webActions.waitUntilListisDisplayed(li_TotalStatus, "List");
				report.reportInfo("List is displayed");
				webActions.selectCheckBoxfromList(li_TotalStatus, expColumns.get(statusToSelect), "status name "+expColumns.get(statusToSelect)+" is selected");
			}
			webActions.waitForClickAbility(lbl_columnInActiveComplete, "list");
			webActions.waitForLoadingBarToAppear();
			List<String> expSelectedColumnsNames= selectedColumnList(li_defaultcolumnNames);
			report.reportInfo("Expected active Status under Columns list : "+expSelectedColumnsNames);	
			webActions.waitForVisibility(btn_Columns, "Columns Button");
			webActions.clickBYJS(btn_Columns, "Columns Button");	
			List<String> actColumnStatus=gridColumnNames(li_DefaultGridStatusNames);	
			report.reportInfo("Actual Default Status Columns in Service Tracker Page : "+actColumnStatus);
			ArrayList<String> unmatchedHeaderNames=getUmatchedInArrayComparision(expSelectedColumnsNames,actColumnStatus);
			if(unmatchedHeaderNames.size()==0){
				report.reportPass("Verified Default Grid Status Columns names Successfully");
			}
			else{
				throw new Exception("Failed to verify Default Status Column names and unmatched Default Status names are : "+unmatchedHeaderNames);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyStatusNamesWithInitCap(){
		try{
			webActions.waitUntilisDisplayed(li_IntakeStatus, "Grid Column Names");
			List<String> actColumnStatus=gridColumnNames(li_DefaultGridStatusNames);	
			report.reportInfo("Actual Default Status Columns in Service Tracker Page : "+actColumnStatus);
			int exptotalstaus = actColumnStatus.size();
			for(int status =0; status<exptotalstaus;status++){
				String actualColumnsName = actColumnStatus.get(status);			
				if (Character.isUpperCase(actualColumnsName.charAt(0))){
					report.reportPass("Header name displayed in capital letter"+actualColumnsName);
				}
				else{
					report.reportFail("failed to read column name");
				}
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public ArrayList<String> gridStatusColumnscapital(List<WebElement> elements){
		ArrayList<String> data= new ArrayList<String>();
		List<WebElement> allElement = elements;
		for (WebElement we: allElement) { 
			String txt=we.getText();
			String[] splited = txt.split("\\s[(]");
			txt=splited[0];
			data.add(txt);
		}
		return data;
	}


	public ArrayList<String> gridColumnNames(List<WebElement> elements){
		ArrayList<String> data= new ArrayList<String>();
		List<WebElement> allElement = elements;
		for (WebElement we: allElement) { 		
			String txt=we.getText();
			String[] splited = txt.split("\\s[(-]");
			txt=splited[0];
			data.add(txt);
		}
		return data;
	}

	public ArrayList<String> selectedColumnList(List<WebElement> elements){
		ArrayList<String> data= new ArrayList<String>();
		List<WebElement> allElement = elements;
		for (WebElement we: allElement) { 
			String txt=we.getText();
			data.add(txt);
		}
		return data;
	}	

	public ArrayList<String> getUmatchedInArrayComparision(List<String> actData, List<String> expData) throws Exception
	{
		ArrayList<String> UnmatchedArray = new ArrayList<String>();
		if(actData!=null && expData!=null &&actData.size()>0&&expData.size()>0 && actData.size()==expData.size()){
			for(int data=0;data<actData.size();data++)
			{
				if(!((actData.get(data)).contentEquals(expData.get(data))))
					UnmatchedArray.add(actData.get(data));	
			}
		}
		else{
			throw new Exception("Arrya Sizes are not matched");
		}
		return UnmatchedArray;			
	}

	public void compareDateOfService() throws Exception{
		try{
			webActions.waitForPageLoaded();
			String actDateOfService = webActions.getValue(txt_DateOfService, "DateOfService");
			report.reportInfo("Date of Service from Service Tracker Page is :"+actDateOfService);
			String currentDateofService = webActions.getSystemCurrentDate();
			//SimpleDateFormat appDate = new SimpleDateFormat("MM/dd/yyyy");
			report.reportInfo("System Current Date is :"+currentDateofService);
			if(actDateOfService.contentEquals(currentDateofService)){
				report.reportPass("Date of Service is matched");
			}else{
				throw new Exception("Failed to compare Date of Service");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void selectAllStatus() {
		try{
			webActions.waitForVisibility(txt_SearchBox,"Search Box",120);
			webActions.waitForVisibility(btn_Columns,"Columns Dropdown");
			webActions.click(btn_Columns,"Columns Dropdown");
			webActions.waitForPageLoaded();
			webActions.waitUntilListisDisplayed(lst_ColumnBox,"Columns Dropdown");
			List<String> options = webActions.getDatafromWebTable(lst_ColumnBox);
			report.reportInfo("Total options in columns dropdown menu :"+options.size());
			for(int listcount = 0;listcount<options.size();listcount++){


			}
			webActions.click(btn_Columns,"Columns Dropdown");

		}
		catch (Exception e) {
			report.reportFail(e.getMessage());
		}		
	}





	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_UserName);
	}


}
