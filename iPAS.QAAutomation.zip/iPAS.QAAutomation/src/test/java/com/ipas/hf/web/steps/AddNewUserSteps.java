package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.AddNewUserPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class AddNewUserSteps {

	AddNewUserPage adduser = new AddNewUserPage();

	@Then("Verify the display of Users panel and label names")
	public void verify_the_display_of_Users_panel_and_label_names(DataTable label) {
		adduser.verifyLabelNames(label);
	}

	@Then("Verify the Expand Collapse of Users panel")
	public void verify_the_Expand_Collapse_of_Users_panel() {
		adduser.verifyExpandCollapseUsersPanel();
	}

	@Then("Verify the Breadcrumb for Add New User page")
	public void verify_the_Breadcrumb_for_Add_New_User_page(DataTable breadcrumb) {
		adduser.verifyBreadcrumbinAddNewUserPage(breadcrumb);
	}

	@Then("Verify the display of mandatory fields")
	public void verify_the_display_of_mandatory_fields(DataTable mandatoryFields) {
		adduser.verifyMandatoryFields(mandatoryFields);
	}

	@Then("Verify the display of field names and button names")
	public void verify_the_display_of_field_names_and_button_names(DataTable fieldNames) {
		adduser.verifyFieldNamesandButtonNames(fieldNames);
	}

	@Then("Verify the mandatory field validation messages")
	public void verify_the_mandatory_field_validation_messages(DataTable validationMessages) {
		adduser.verifytheMandatoryFieldValidationMessage(validationMessages);
	}

	@Then("Verify the validation messages if user enter less than minimum characters as {string}")
	public void verify_the_validation_messages_if_user_enter_less_than_minimum_characters_as(String testData,
			DataTable validationMessages) {
		adduser.verifyValidationMessageifEnterLessThanMinimumCharacters(testData, validationMessages);
	}

	@Then("Verify the validation messages if user enter greater than Maximum length characters as {string}")
	public void verify_the_validation_messages_if_user_enter_greater_than_Maximum_length_characters_as(String testData, DataTable validationMessages) {
		adduser.verifyValidationMessageifEnterGreaterThanMaximumLengthCharacters(testData,validationMessages);
	}

	@Then("Verify the validation messages as {string} if user enter invalid phone number as {string}")
	public void verify_the_validation_messages_as_if_user_enter_invalid_phone_number_as(String validationMessage,String phoneNumber) {
		adduser.verifyValidationMessageifEnterInvalidPhoneNumber(validationMessage, phoneNumber);
	}

	@Then("Verify the Placeholders for all fields")
	public void verify_the_Placeholders_for_all_fields(DataTable placeholders) {
		adduser.verifythePlaceholdersforallFields(placeholders);
	}

	@Then("Verify the Cancel button functionality")
	public void verify_the_Cancel_button_functionality() {
		adduser.verifyCancelButtonFunctionality();
	}

	@Then("Verify the validation message as {string} if user enter data as {string}")
	public void verify_the_validation_message_as_if_user_enter_data_as(String validationMessage, String testData) {
		adduser.verifyValidationMessageifNotEnteringAlphaCharacters(validationMessage,testData);
	}

	@Then("Verify the validation messages if user enter less than minimum length numeric values as {string}")
	public void verify_the_validation_messages_if_user_enter_less_than_minimum_length_numeric_values_as(String testData, DataTable validationMessages) {
		adduser.verifyValidationMessageifEnterLessThanMinimumNumericValues(testData,validationMessages);
	}

	@Then("Verify the New User creation with the following data and verify alert message as title {string} and content as {string}")
	public void verify_the_New_User_creation_with_the_following_data_and_verify_alert_message_as_title_and_content_as(String messageTitle,String messageContent,DataTable testData) {
		adduser.createNewUser(testData,messageTitle,messageContent);
	}

	@Then("Verify the alert error messages if user try to create duplicate user message as title {string} and content as {string}")
	public void verify_the_alert_error_messages_if_user_try_to_create_duplicate_user_message_as_title_and_content_as(String messageTitle,String messageContent,DataTable testData) {
		adduser.createDuplicateUser(testData,messageTitle,messageContent);
	}
	@Then("Verify the display of default radio button for first admin department")
	public void verify_the_display_of_default_radio_button_for_first_admin_department() {
		adduser.verifyDefaultRadio();
	}
	@Then("Verify the display of default radio button for newly added Admin department")
	public void verify_the_display_of_default_radio_button_for_newly_added_Admin_department() {
		adduser.verifyDefaultRadioForSecondDepartment();
	}
	@Then("Verify the display of toggle switch")
	public void verify_the_display_of_toggle_switch() {
		adduser.verifyToggleSwitch();
	}
	@Then("Verify the default display mode of toggle switch")
	public void verify_the_default_display_mode_of_toggle_switch() {
		adduser.verifyToggleSwitchMode();
	}
	@Then("Verify the accuracy and accountability toggle switch modes")
	public void verify_the_accuracy_and_accountability_toggle_switch_modes() {
		adduser.verifyToggleSwitchModes();
	}

}