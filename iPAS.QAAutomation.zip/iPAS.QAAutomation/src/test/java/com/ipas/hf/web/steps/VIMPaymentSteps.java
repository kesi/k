package com.ipas.hf.web.steps;

import org.json.simple.parser.ParseException;

import com.ipas.hf.web.pages.ipasPages.EligibityPage;
import com.ipas.hf.web.pages.ipasPages.VIMPaymentPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class VIMPaymentSteps {
	
	VIMPaymentPage vimpay=new VIMPaymentPage();
	EligibityPage eligibility=new EligibityPage();
	
	@Then("Verify payment panel if no pending payments")
	public void verify_payment_panel_if_no_pending_payments() {
		vimpay.verifyPaymentStatusandPaymentCountIfNoPayment();
	}

	@Then("Navigate to Payment Facilitator in iPAS")
	public void navigate_to_Payment_Facilitator_in_iPAS() {
	   vimpay.navigatePaymentFacilitator();
	}

	@Then("Save the Payment in iPAS")
	public void save_the_Payment_in_iPAS(DataTable testData) {
	   vimpay.savePaymentiPAS(testData);
	}

	@Then("Verify payment panel when having pending payments")
	public void verify_payment_panel_when_having_pending_payments() {
		vimpay.verifyPaymentStatusandPaymentCountIfHavingPayment();
	}
	
	@Then("Verify payment panel in VIM home page")
	public void verify_payment_panel_in_VIM_home_page(DataTable testData) {
		vimpay.verifyPaymentPanelInVIMHomePage(testData);
	}
	
	@Then("Make a Full Payment and verify the details")
	public void make_a_Full_Payment_and_verify_the_details(DataTable testData) {
		vimpay.makeaPayment(testData);
	}
	
	@Then("Verify the payment details in Payment Facilitator in iPAS")
	public void verify_the_payment_details_in_Payment_Facilitator_in_iPAS(DataTable testData) {
		vimpay.verifyPaymentDetailsInPaymentFacilitator(testData);
	}
	
	@Then("Navigate to Patient Visit All Data page")
	public void navigate_to_Patient_Visit_All_Data_page() {
	   vimpay.navigatePatientVisitAllDataPage();
	}
	
	@Then("Update Patient Responsibility Estimate in JSON {string}")
	public void update_Patient_Responsibility_Estimate_in_JSON(String estimateAmount) throws ParseException {
		eligibility.updatePatientResponsibilityEstimateinJSON(estimateAmount);
	}
	
	@Then("Make a Partial Payment and verify the details")
	public void make_a_Partial_Payment_and_verify_the_details(DataTable testData) {
	   vimpay.makeAPartialPayment(testData);
	}
	
	@Then("Make a Payment with Saved card")
	public void make_a_Payment_with_Saved_card(DataTable testData) {
	    vimpay.makeAPaymentWithSavedCard(testData);
	}

	@Then("Verify the payment details in Payment Facilitator iPAS for multiple payment transactions")
	public void verify_the_payment_details_in_Payment_Facilitator_iPAS_for_multiple_payment_transactions(DataTable testData) {
		vimpay.verifyPaymentDetailsInPaymentFacilitatorForMultipleTransactions(testData);
	}

	@Then("Verify the validation error messages")
	public void verify_the_validation_error_messages(DataTable testData) {
	   vimpay.verifyVIMPaymentValidationMessages(testData);
	}

	@Then("Download of Payment Receipt in VIM")
	public void download_of_Payment_Receipt_in_VIM(DataTable testData) {
	    vimpay.downloadPaymentReceipt(testData);
	}

}
