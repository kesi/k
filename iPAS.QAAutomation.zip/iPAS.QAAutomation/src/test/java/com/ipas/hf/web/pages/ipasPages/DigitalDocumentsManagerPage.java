package com.ipas.hf.web.pages.ipasPages;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class DigitalDocumentsManagerPage extends BasePage {

	private JSONObject jsonObject;
	private static final String DIGITALDOCSJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\DigitalDocuments.json";
	private StepLogging log = StepLogging.getLoggingObject();

	@FindBy(xpath = "//a[text()='All Data']")
	private WebElement lbl_AllData;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr/td")
	private WebElement tbl_AccountSearchData;

	@FindBy(xpath = "//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_Search;

	@FindBy(xpath = "//ejs-textbox[@id='search_text']//input")
	private WebElement txt_Search_ST;

	//ul[@id='searchcomp_options']/li
	@FindBy(xpath="//li[@id='p-highlighted-option']")
	private WebElement li_Search;

	@FindBy(xpath="//div[@class='e-gridcontent']//td[2]/div/a")
	private WebElement lnk_AccountNumber;

	@FindBy(xpath="//a[contains(text(),'Account Search')]")
	private WebElement lnk_AccountSearch_Home;

	@FindBy(xpath="//a[contains(@class,'breadcrum')]")
	private WebElement lbl_Breadcrum_Service;

	@FindBy(xpath="//span[contains(@class,'breadcrum-active')]")
	private WebElement lbl_Breadcrum_VisitNumber;

	@FindBy(xpath="//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']")
	private WebElement lbl_Headers;

	@FindBy(xpath="//table[@class='e-table']//thead/tr/th")
	private WebElement lbl_Headers_AS;


	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[2]")
	private List<WebElement> lbl_PatientVisitSummary;
	
	//div[@class='allData-control-section']/ejs-dashboardlayout/div
	@FindBy(xpath="//ejs-dashboardlayout[@id='defaultLayout']//div//child::ejs-accordion/div")
	private List<WebElement> tbl_AllData;
	
	@FindBy(xpath="//div[@hideauthorize='ViewAlerts']/ul/li/div/div")
	private List<WebElement> tr_ViewAlerts;

	@FindBy(xpath="//div[@id='three']//app-ipas-document-management-pannel//ejs-accordion/div/div[1]/div[1]/span/div/a")
	private WebElement lbl_DigitalDocMangerHeaderPanel;

	@FindBy(xpath="//div[@id='three']//app-ipas-document-management-pannel//ejs-accordion/div/div[2]/div/div/ul/li/div[1]")
	private WebElement lbl_DigitalDocMangerPanel1;

	@FindBy(xpath="//div[@id='three']//app-ipas-document-management-pannel//ejs-accordion/div/div[2]/div/div/ul/li/div[1]")
	private List<WebElement> lbl_DigitalDocMangerPanel;

	@FindBy(xpath="//app-ipas-document-management-pannel//ejs-accordion/div/div[1]/div[2]/span")
	private WebElement icon_ExpandCollapse;

	@FindBy(xpath="//div[@class='breadcrum-container noprint']/span")
	private List<WebElement> lbl_DigitalDocMangerPage;

	@FindBy(xpath="//div[(text()='No data available for Digital Documents Manager')]")
	private WebElement tbl_DetailDashboard;

	@FindBy(xpath="//div[@id='detail-document-table']/div/ejs-listview/div/div[2]/span")
	private WebElement tbl_DDMPage;

	@FindBy(xpath="//div[@id='detail-document-table']/div/ejs-listview/div/div[2]/span")
	private List<WebElement> lbl_DigitalDocumentsMangerPage1;

	@FindBy(xpath="//div[@id='detail-document-table']/div/ejs-listview/div/ul/li/div/span")
	private List<WebElement> lbl_DigitalDocumentsMangerPage2;

	@FindBy(linkText="Digital Document Manager")
	private WebElement lnk_DigitalDocuments;


	@FindBy(xpath="//app-ipas-service-tracker-panel/div/ejs-accordion/div/div[1]")
	private WebElement from_DDMPanel;

	@FindBy(xpath="//account-search-all-data-panel/ejs-accordion/div/div[1]")
	private WebElement to_ALLDataPanel;

	@FindBy(xpath="//div[@class='pasentDetails']")
	private WebElement div_PasentDetails;

	@FindBy(linkText="Transaction History")
	private WebElement lnk_TransactionHistory;

	@FindBy(xpath="//span[(text()='×')]")
	private WebElement icon_Close;

	@FindBy(xpath = "//a[text()='Digital Documents Manager']/../../../div/img")
	private WebElement img_FinancialClearanceStatus;

	@FindBy(xpath="//div[@id='three']//app-ipas-document-management-pannel//ejs-accordion/div/div[2]/div/div/ul/li/div[2]")
	private List<WebElement> lbl_DigitalDocumentsCount;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr")
	private List<WebElement> tbl_AccountSearch_Results;
	
	String form="//span[text()='";
	String form1="']";
	String discrepancy="']/../span[3]";
	
	@FindBy(xpath = "//span[@class='item-title']")
	private WebElement lbl_AllFormsAndDocuments;
	
	@FindBy(xpath = "//span[@class='item-title']")
	private List<WebElement> lbl_AllFormsAndDocs;
	
	/*@FindBy(id = "input_148")
	private WebElement txt_FirstName;*/
	
	@FindBy(xpath = "//input[contains(@name,'PatFirst')]")
	private WebElement txt_FirstName;
	
	@FindBy(xpath = "//button[@type='submit']")
	private WebElement btn_Submit;
	
	@FindBy(xpath = "//div[@class='details']")
	public List<WebElement> lbl_AllAlerts;
	
	@FindBy(xpath = "//p[text()='Your submission has been received.']")
	private WebElement lbl_SuccessMessage;
	
	@FindBy(xpath = "(//a[contains(text(),'Account Search')])[1]")
	private WebElement lnk_AccountSearch;		
			
	@FindBy(xpath = "//span[(text()='Pre-Registration')]/../span[3]")
	private WebElement btn_Discrepancy;	
	
	@FindBy(xpath = "//div[@class='header']/h5")
	private WebElement lbl_HeaderName;	
	
	@FindBy(xpath = "//div[@class='header']/h6")
	private WebElement lbl_HeaderDescription;
	
	@FindBy(xpath = "//div[@class='discrepancies']/span")
	public List<WebElement> tbl_Discrepancies;
	
	@FindBy(xpath = "//div[@class='name']/span")
	private WebElement lbl_FormName;
	
	@FindBy(xpath = "//img[@type='button']")
	private WebElement btn_CloseX;

	Login   logIn;
	private RestActions rest = new RestActions();
	public DigitalDocumentsManagerPage() {
		PageFactory.initElements(driver, this);
		logIn =new Login();
	}

	public void verifyDisplayedBreadcrumb(String responseValue,String menuName) throws Exception{
		String breadcrumb="";
		String breadcrumb_Visit="";
		try {
			String accountNumber = logIn.getVisitIdFromResponse(responseValue);
			if ("Account Search".contentEquals(menuName)) {
				searchAccountNuberinAccountSearchPage(accountNumber);
				breadcrumb = webActions.waitAndGetText(lbl_Breadcrum_Service, "");
				report.reportInfo("Breadcrumb is:  "+breadcrumb);
				breadcrumb_Visit = webActions.waitAndGetText(lbl_Breadcrum_VisitNumber, "");
				report.reportInfo("Level 2 Breadcrumb is:  "+breadcrumb_Visit);
			}else if("Service Tracker".contentEquals(menuName)){
				searchAccountNumberinServiceTracker(accountNumber);
				breadcrumb = webActions.waitAndGetText(lbl_Breadcrum_Service, "");
				report.reportInfo("Breadcrumb is:  "+breadcrumb);
				breadcrumb_Visit = webActions.waitAndGetText(lbl_Breadcrum_VisitNumber, "");
				report.reportInfo("Level 2 Breadcrumb is:  "+breadcrumb_Visit);
			}
			if((menuName.contentEquals(breadcrumb)) && (accountNumber.contentEquals(breadcrumb_Visit))){
				report.reportPass("Breadcrumb is displayed based on '"+menuName+"' followed by the display patient visit number: "+accountNumber+"");
			}
			else {
				report.reportFail("Filed to verify the displayed Breadcrumb based on '"+menuName+"' followed by the display patient visit number: "+accountNumber+"");
			}

		} catch (Exception e) {
			throw new Exception(e.toString());
		}

	}

	public void searchAccountNuberinAccountSearchPage(String accountNumber) throws Exception{
		try {
			webActions.waitForVisibilityOfAllElements(tbl_AccountSearch_Results, "Account Search Table");
			webActions.sendKeys(txt_Search, accountNumber, "");
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(li_Search, "Account Number List");
			webActions.waitForPageLoaded();
			webActions.click(li_Search, "Account Number List");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_Headers_AS,"Account Search Headers");
			driver.findElement(By.partialLinkText(accountNumber)).click();
			webActions.waitForVisibilityOfAllElements(tbl_AllData, "All Data Page");
			webActions.waitForPageLoaded();
			waitforAAARuleAlerts();
		} catch (Exception e) {
			throw new Exception(e);
		}
	}

	public void searchAccountNumberinServiceTracker(String AccountNumber) throws Exception{
		try {
			webActions.waitForVisibility(lbl_Headers, "Service Tracker Headers");
			webActions.waitForPageLoaded();
			webActions.enterValuesfromKeyBoard(txt_Search_ST, AccountNumber, "");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			driver.findElement(By.linkText(AccountNumber)).click();
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String navigateDigitalDocumentsManger(String pageName) throws Exception{
		String accountNumber=getDataFromJSONFile("AccountNumber");
		switch (pageName) {
		case "Account Search":
			searchAccountNuberinAccountSearchPage(accountNumber);
			break;
		case "Service Tracker":
			searchAccountNumberinServiceTracker(accountNumber);
			break;
		}
		return accountNumber;
	}
	public void verifyTheLabelNames(DataTable labelNames) throws Exception{
		ArrayList<String> expLabelNames = new ArrayList<>(labelNames.asList());
		searchAccountNuberinAccountSearchPage(getDataFromJSONFile("AccountNumber"));
		ArrayList<String> actualLableNames=new ArrayList<String>();
		webActions.waitForVisibility(lbl_DigitalDocMangerHeaderPanel, "DDMHeaderPanel");
		actualLableNames.add(webActions.waitAndGetText(lbl_DigitalDocMangerHeaderPanel, "DDMHeaderPanel"));
		webActions.waitForVisibility(lbl_DigitalDocMangerPanel1, "DDMHeader");
		actualLableNames.addAll(webActions.getDatafromWebTable(lbl_DigitalDocMangerPanel));
		report.reportInfo("Expected Label Names are: "+expLabelNames);
		report.reportInfo("Actual Label Names are: "+actualLableNames);
		ArrayList<String> unmatchData=webActions.getUmatchedInArrayComparision(actualLableNames, expLabelNames);
		if(unmatchData.size()==0){
			report.reportPass("Verified label names in the Digital Documents Manager panel successfully");
		}
		else{
			report.reportFail("Fail to verify label names in the Digital Documents Manager panel and unmatched Labels are: "+unmatchData);
		}
	}

	public void verifyPatientVisitSummaryInformation(String scenarioName) throws Exception{
		ArrayList<String> expData=getListDataFromJSONFile(scenarioName);
		searchAccountNuberinAccountSearchPage(expData.get(0));
		webActions.waitForVisibilityOfAllElements(lbl_PatientVisitSummary, "PatientVisitSummary");
		ArrayList<String> actData=webActions.getDatafromWebTable(lbl_PatientVisitSummary);
		report.reportInfo("Expected Patient Visit Summary Information: "+expData);
		report.reportInfo("Actual Patient Visit Summary Information: "+actData);
		ArrayList<String> unMatch=webActions.getUmatchedInArrayComparision(actData, expData);
		if(unMatch.size()==0){
			report.reportPass("Patient Visit Summary Information verified successfully: "+actData);
		}
		else{
			report.reportFail("Failed to verify the Patient Visit Summary Information, and unmatched data is: "+unMatch);
		}
	}

	public void verifyExpandandCollapsethePanel() throws Exception{
		StringBuilder unmatch=new StringBuilder();
		searchAccountNuberinAccountSearchPage(getDataFromJSONFile("AccountNumber"));
		webActions.waitForVisibility(icon_ExpandCollapse, "ExpandandCollapse");
		webActions.waitAndClick(icon_ExpandCollapse, "ExpandandCollapse");
		webActions.waitForPageLoaded();
		String actualCollapseStatus=webActions.getAttributeValue(icon_ExpandCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons".contentEquals(actualCollapseStatus)){
			report.reportPass("Digital Documents Manger Panel Successfully Collapsed");
		}
		else{
			unmatch.append("Panle is not Collapsed");
			report.reportFail("Panle is not Collapsed");
		}
		webActions.waitAndClick(icon_ExpandCollapse, "ExpandandCollapse");
		webActions.waitForPageLoaded();
		String actualEpandStatus=webActions.getAttributeValue(icon_ExpandCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons e-expand-icon".contentEquals(actualEpandStatus)){
			report.reportPass("Digital Documents Manger Panel Successfully Expanded");
		}else{
			unmatch.append("Panle is not Expanded");
			report.reportFail("Panle is not Expanded");
		}
		if(unmatch.length()==0){
			report.reportPass("Digital Documents Manger Panel Successfully Expanded and Collapsed");
		}else{
			report.reportFail("Failed to verify the Expand and Collapse the Digital Documents Manger Panel"+unmatch);
		}

	}

	public void verifyDisplayedBreadcrumbFollowedbyDigitalDocumentsManager(String menuName,String pageName) throws Exception{
		String accountNumber=getDataFromJSONFile("AccountNumber");
		ArrayList<String> expectedBreadcrumbTitles=new ArrayList<String>();
		expectedBreadcrumbTitles.add(pageName);
		expectedBreadcrumbTitles.add(accountNumber);
		expectedBreadcrumbTitles.add(menuName);
		report.reportInfo("Expected Breadcrumb Titles "+expectedBreadcrumbTitles);
		ArrayList<String> actualBreadcrumbTitles = new ArrayList<String>();

		if ("Account Search".contentEquals(pageName)) {
			searchAccountNuberinAccountSearchPage(accountNumber);
			webActions.waitAndClick(lbl_DigitalDocMangerHeaderPanel, "DDM Link");
			actualBreadcrumbTitles = webActions.getDatafromWebTable(lbl_DigitalDocMangerPage);
		}else if("Service Tracker".contentEquals(pageName)){
			searchAccountNumberinServiceTracker(accountNumber);
			webActions.waitAndClick(lbl_DigitalDocMangerHeaderPanel, "DDM Link");
			actualBreadcrumbTitles = webActions.getDatafromWebTable(lbl_DigitalDocMangerPage);
		}
		report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumbTitles);
		ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles, expectedBreadcrumbTitles);
		if(unmatch.size()==0){
			report.reportPass("Digital Documents Manager Breadcrumb Titles verified successfully, when user navigate from: "+pageName);
		}else{
			report.reportFail("Failed to verify the Digital Documents Manager Breadcrumb Titles, when user navigate from: "+pageName+" : and unmatched data: "+unmatch);
		}
	}

	public void verifytheErrorMessage(String errorMessage,String pageName) throws Exception{
		String actualErrorMessage="";
		navigateDigitalDocumentsManger(pageName);
		webActions.waitAndClick(lbl_DigitalDocMangerHeaderPanel, "DDM Link");
		webActions.waitForPageLoaded();
		webActions.waitUntilisDisplayed(tbl_DetailDashboard, "Label Error Message");
		actualErrorMessage=webActions.getText(tbl_DetailDashboard, "Label Error Message");
		report.reportInfo("Actual Error Message is: "+actualErrorMessage);
		report.reportInfo("Expected Error Message is: "+errorMessage);
		if(errorMessage.contentEquals(actualErrorMessage)){
			report.reportPass("Successfully verified the Error Message if documents count is zero when navigate from "+pageName+" page");
		}else{
			report.reportFail("Failed to verify the Error Message when navigate from "+pageName+" page");
		}
	}

	public void verifyLabelNamesinDigitalDocumentsMangerPage(DataTable labels) throws Exception{
		try {
			ArrayList<String> expLabelNames = new ArrayList<>(labels.asList());
			searchAccountNuberinAccountSearchPage(getDataFromJSONFile("AccountNumber"));
			ArrayList<String> actualLableNames=new ArrayList<String>();
			webActions.waitForVisibility(lbl_DigitalDocMangerHeaderPanel, "DDM Link");
			webActions.waitAndClick(lbl_DigitalDocMangerHeaderPanel, "DDM Link");
			waitforAAARuleAlerts();
			webActions.waitForVisibility(tbl_DDMPage, "DDMPage");
			actualLableNames.addAll(webActions.getDatafromWebTable(lbl_DigitalDocumentsMangerPage1));
			actualLableNames.addAll(webActions.getDatafromWebTable(lbl_DigitalDocumentsMangerPage2));
			report.reportInfo("Actual Label Names are: "+actualLableNames);
			report.reportInfo("Expected Label Names are: "+expLabelNames);
			ArrayList<String> unmatchData=webActions.getUmatchedInArrayComparision(actualLableNames, expLabelNames);
			if(unmatchData.size()==0){
				report.reportPass("Verified label names in the Digital Documents Manager panel successfully");
			}
			else{
				throw new Exception("Failed to verify the label names in the Digital Documents Manger page and unmatched Labels are: "+unmatchData);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyPatientVisitSummaryInformationinDDMPage(String scenarioName) {
		try {
			ArrayList<String> expData=getListDataFromJSONFile(scenarioName);
			clickDigitalDocumentsLinkinAccountSearch(expData.get(0));
			webActions.waitForVisibility(tbl_DDMPage, "DDMPage");
			ArrayList<String> actData=webActions.getDatafromWebTable(lbl_PatientVisitSummary);
			report.reportInfo("Expected Patient Visit Summary Information: "+expData);
			report.reportInfo("Actual Patient Visit Summary Information: "+actData);
			ArrayList<String> unMatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unMatch.size()==0){
				report.reportPass("Successfully verified Patient Visit Summary when click on Digital Documents link in Needs Attention: "+actData);
			}
			else{
				report.reportFail("Failed to verify Patient Visit Summary when click on Digital Documents link in Needs Attention and unmatched data is: "+unMatch,true);
			}
			ArrayList<String> actualBreadcrumbTitles = webActions.getDatafromWebTable(lbl_DigitalDocMangerPage);
			ArrayList<String> expBreadcrumbTitles= new ArrayList<String>();
			expBreadcrumbTitles.add("Account Search");
			expBreadcrumbTitles.add("Digital Documents Manager");
			ArrayList<String> unMatchBreadcrumb=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles, expBreadcrumbTitles);
			if(unMatchBreadcrumb.size()==0){
				report.reportPass("Successfully verified the BreadCrumb if navigate from Needs Attention: "+actualBreadcrumbTitles);
			}
			else{
				report.reportFail("Failed to verify the BreadCrumb if navigate from Needs Attention: "+unMatchBreadcrumb);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickDigitalDocumentsLinkinAccountSearch(String accountNumber) throws Exception {
		try {
			webActions.waitForVisibilityOfAllElements(tbl_AccountSearch_Results, "Account Search Table");
			webActions.sendKeys(txt_Search, accountNumber, "Simple Search");
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(li_Search, "Account Number List");
			webActions.click(li_Search, "Account Number List");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_Headers_AS,"Account Search Headers");
			webActions.waitAndClick(lnk_DigitalDocuments, "Digital Documents");
		} catch (Exception e) {
			throw new Exception(e);
		}
	}

	public void verifyDocumentsCountandFinancialClearanceStatus(DataTable testData) throws Exception{
		try {
			ArrayList<String> expectedData=new ArrayList<String>();
			expectedData.add(getExpectedFinancialClearanceStatus(testData));
			expectedData.add(getDatafromMap(testData,"Documents"));
			expectedData.add(getDatafromMap(testData,"Forms"));
			
			String visitStatus=getDatafromMap(testData,"Visit Status");
			String accountNumber;
			if("Discharged".contentEquals(visitStatus)){
				 accountNumber = logIn.getVisitIdFromResponse("$..displayPatientAccountId");
			}else{
				accountNumber=getDataFromJSONFile("AccountNumber");
			}
			searchAccountNuberinAccountSearchPage(accountNumber);
			ArrayList<String> actualData=new ArrayList<String>();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			actualData.add(getFinancialClearanceStatus());
			webActions.waitForVisibilityOfAllElements(lbl_DigitalDocumentsCount, "DigitalDocumentsCount");
			actualData.addAll(webActions.getDatafromWebTable(lbl_DigitalDocumentsCount));
			report.reportInfo("Expected Data"+expectedData);
			report.reportInfo("Actual Data: "+actualData);
			visitStatus=getVisitStatusMessage(visitStatus);
			ArrayList<String> unmatchData=webActions.getUmatchedInArrayComparision(actualData, expectedData);
			if(unmatchData.size()==0){
				report.reportPass("Successfully verified Digital Documents Count and Financial Clearance Status "+visitStatus+"");
			}
			else{
				report.reportFail("Fail to verify the Digital Documents Count and Financial Clearance Status "+visitStatus+": "+unmatchData);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public String getFinancialClearanceStatus(){
		String status=null;
		try {
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitForVisibility(img_FinancialClearanceStatus, "Financial Clearance Status");
			status= webActions.getAttributeValue(img_FinancialClearanceStatus, "src", "Digital Documents Manager");
		} catch (Exception e) {
		}
		return status;
	}
	public  String getExpectedFinancialClearanceStatus(DataTable testData){
		String expFCStatusPF=getDatafromMap(testData, "Financial Clearance Status");
		if(expFCStatusPF.contentEquals("Needs Attention")){
			expFCStatusPF="error";
		}else if(expFCStatusPF.contentEquals("Clear")){
			expFCStatusPF="success";
		}
		return expFCStatusPF;
	}
	
	public String getVisitStatusMessage(String visitStatus){
		 
		if("Visit Date is not empty".contentEquals(visitStatus)){
			visitStatus="if Visit Date is not empty";
		}else if("Visit Date is empty".contentEquals(visitStatus)){
			visitStatus="if Visit Date is empty";
		}else if("Cancelled".contentEquals(visitStatus)){
			visitStatus="if Visit status is Cancelled";
		}else if("Discharged".contentEquals(visitStatus)){
			visitStatus="if Visit status is Discharged";
		}else if("No Show".contentEquals(visitStatus)){
			visitStatus="if Visit status is No Show";
		}
		return visitStatus;
	}

	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}
	public void dragDrop() throws Exception{
		try {
			searchAccountNuberinAccountSearchPage(getDataFromJSONFile("AccountNumber"));
			webActions.waitForPageLoaded();
			Actions action = new Actions(driver);
			action.dragAndDrop(from_DDMPanel, to_ALLDataPanel).perform();
			/*Action dragAndDrop = action.clickAndHold(from_DDMPanel)
					.moveToElement(to_ALLDataPanel)
					.release(to_ALLDataPanel)
					.build();
					dragAndDrop.perform();*/
			action.release();
			webActions.waitForPageLoaded();

			report.reportPass("Successfully drag and drop");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void clickOnFormName(String formName){
		try {
			webActions.waitForClickAbility(lbl_AllFormsAndDocuments, "Forms And Documents");
			webActions.waitAndGetText(lbl_AllFormsAndDocuments, "Forms And Documents");
			//ArrayList<String> actData=webActions.getDatafromWebTable(lbl_AllFormsAndDocs);
			WebElement elementForme=driver.findElement(By.xpath(form+formName+form1));
			webActions.click(elementForme, "Form Name");
			webActions.waitForframeToBeAvailableAndSwitchToIt("myFrame");
			webActions.switchToiFrame("myFrame");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
		}
	}
	
	public void enterPreRegistrationForm(DataTable testData){
		try {
			String firstName=getDatafromMap(testData, "First Name");
			webActions.waitForVisibility(txt_FirstName, "First Name", 30);
			webActions.clearValue(txt_FirstName, "First Name");
			webActions.sendKeys(txt_FirstName, firstName, "First Name");
			report.reportPass("Successfully entered data in First Name");
			webActions.scrollBarHandle(btn_Submit, "Submit");
			webActions.click(btn_Submit, "Submit");
			String actMessage=webActions.waitAndGetText(lbl_SuccessMessage, "Success Messages");
			report.reportInfo("Success message after submit: "+actMessage);
			if("Your submission has been received.".contains(actMessage)){
				report.reportPass("Successfully updated data in Patient form");
			}else{
				report.reportFail("Fail to update data in Patient Form");
			}
			webActions.switchTodefaultContent();
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void navigateDigitalDocumentsManagerFullPage(){
		try {
			searchAccountNuberinAccountSearchPage(getDataFromJSONFile("AccountNumber"));
			webActions.waitForVisibility(lbl_DigitalDocMangerHeaderPanel, "DDM Link",15);
			webActions.waitAndClick(lbl_DigitalDocMangerHeaderPanel, "DDM Link");
			webActions.waitForClickAbility(lbl_AllFormsAndDocuments, "Forms And Documents");
			webActions.waitAndGetText(lbl_AllFormsAndDocuments, "Forms And Documents");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void openDiscrepancyWindow(String formName,DataTable testData){
		try {
			StringBuilder verify=new StringBuilder();
			ArrayList<String>expData=new ArrayList<>(testData.row(1));
			webActions.waitForPageLoaded();
			WebElement btn_Discrepancy=driver.findElement(By.xpath(form+formName+discrepancy));
			webActions.waitForVisibility(btn_Discrepancy, "Discrepancy button", 90);
			webActions.waitAndClick(btn_Discrepancy, "Discrepancy button");
			String actHeaderName=webActions.waitAndGetText(lbl_HeaderName, "Header Name");
			report.reportInfo("Actual HeaderName: "+actHeaderName);
			if("Discrepancies".contentEquals(actHeaderName)){
				report.reportPass("Successfully verified the Discrepancies window title");
			}else{
				report.reportFail("Failed to verify the Discrepancies window title",true);
				verify.append("Failed to verify the Discrepancies window title");
			}
			String actHeaderDescrption=webActions.waitAndGetText(lbl_HeaderDescription, "Header Description");
			report.reportInfo("Actual Header Descrptions: "+actHeaderDescrption);
			String actFormName=webActions.waitAndGetText(lbl_FormName, "Form Name");
			report.reportInfo("Actual Form Name is: "+actFormName);
			if(formName.contentEquals(actFormName)){
				report.reportPass("Successfully verified the Form name in Discrepancies window");
			}else{
				report.reportFail("Failed to verify the Form name in Discrepancies window",true);
				verify.append("Failed to verify the Form name in Discrepancies window");
			}
			ArrayList<String>actData=webActions.getDatafromWebTable(tbl_Discrepancies);
			report.reportInfo("Actual Discrepancies data: "+actData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Form Discrepancies data");
			}else{
				report.reportFail("Failed to verify the Form Discrepancies data",true);
				verify.append("Failed to verify the Form Discrepancies data");
			}
			webActions.waitForPageLoaded();
			webActions.click(btn_CloseX, "Close");
			String actText=webActions.waitAndGetText(btn_Discrepancy, "Discrepancy button");
			if(actText.contains("Discrepancy")){
				report.reportPass("Successfully closed the Discrepancies window");
			}else{
				report.reportFail("Fail to close the Discrepancies window",true);
				verify.append("Fail to close the Discrepancies window");
			}
			if(verify.length()!=0){
				report.reportFail(""+verify);
			}
			
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void waitforAAARuleAlerts() throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_AllAlerts, "All Alerts");
		} catch (Exception e) {
			webActions.waitForPageLoaded();
		}
	}




	@SuppressWarnings("unchecked")
	public void updateDigitalDocumentsJSON(String eventType) throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(DIGITALDOCSJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject appointmentObject = (JSONObject) jsonObject.get("Appointment");
			try {
				String number = rest.getUniqueNumber();
				newNum = "A" + number;
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(0);
				tenantPatient.put("TenantPatientId", newNum);
				tenantPatient = (JSONObject) msg.get(2);
				tenantPatient.put("TenantPatientId", newNum);
				String test = (String) tenantPatient.get("TenantPatientId");	
			} catch (Exception e) {
				log.error("Failed to update tenant patiend id", e);
				e.printStackTrace();
			}
			try {
				// update tenantPatientVisitId and visitDate
				/*JSONArray visit = (JSONArray) visitObject.get("TenantPatientVisitIdentifier");
				JSONObject patientVisit = (JSONObject) visit.get(0);
				patientVisit.put("TenantPatientVisitId", newNum);*/
				visitObject.put("AccountNumber", newNum);
				visitObject.put("VisitNumber", newNum);
				Object tt;
				tt = visitObject.get("VisitDate");
				String date = tt.toString();
				if(date.isEmpty()){
					tt = appointmentObject.get("AppointmentStartDate");
				}
				String updatedDate = rest.updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);

			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}

			try {
				// update appointmentStartDate and appointmentEndDate
				Object appointment = appointmentObject.get("AppointmentStartDate");
				String updatedDates = rest.updatedDateAppointment(appointment);
				appointmentObject.put("AppointmentStartDate", updatedDates);
				appointmentObject.put("AppointmentEndDate", updatedDates);
				String appointmentId = rest.getUniqueAppointmentNumber();				
				appointmentObject.put("AppointmentId", appointmentId);
			} catch (Exception e) {
				log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
				e.printStackTrace();
			}

			if ("S12".contentEquals(eventType)) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", eventType);
					eventObject.put("EventTypeDescription", "New appointment");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if ("S15".contentEquals(eventType)) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", eventType);
					eventObject.put("EventTypeDescription", "Appointment Cancellation");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if ("S26".equals(eventType)) {
				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", eventType);
					eventObject.put("EventTypeDescription", "Appointment No Show");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}
			else if ("A03".equals(eventType)) {

				try {
					// update eventTypeCode and eventTypeDescription
					JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
					JSONObject event = (JSONObject) tnasaction.get(0);
					JSONObject eventObject = (JSONObject) event.get("EventType");					
					eventObject.put("EventTypeCode", eventType);
					eventObject.put("EventTypeDescription", "Discharge/end visit");
				} catch (Exception e) {
					log.error("Failed to update eventTypeCode", e);
					e.printStackTrace();
				}
			}

			FileWriter file = new FileWriter(DIGITALDOCSJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void updateDigitalDocumentsJSONFile(String fieldName) throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(DIGITALDOCSJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject appointmentObject = (JSONObject) jsonObject.get("Appointment");
			try {
				String number = rest.getUniqueNumber();
				newNum = "A" + number;
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(0);
				tenantPatient.put("TenantPatientId", newNum);
				tenantPatient = (JSONObject) msg.get(2);
				tenantPatient.put("TenantPatientId", newNum);
				String test = (String) tenantPatient.get("TenantPatientId");	
			} catch (Exception e) {
				log.error("Failed to update tenant patiend id", e);
				e.printStackTrace();
			}
			try {
				// update tenantPatientVisitId and visitDate
				visitObject.put("AccountNumber", newNum);
				visitObject.put("VisitNumber", newNum);
				if ("VisitDate".contentEquals(fieldName)) {
					//Object tt = visitObject.get("VisitDate");
					//String updatedDate = rest.updatedDateAppointment(tt);
					visitObject.put("VisitDate", "");
				}

			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}

			try {
				// update appointmentStartDate and appointmentEndDate
				Object appointment = appointmentObject.get("AppointmentStartDate");
				String updatedDates = rest.updatedDateAppointment(appointment);
				appointmentObject.put("AppointmentStartDate", updatedDates);
				appointmentObject.put("AppointmentEndDate", updatedDates);
				String appointmentId = rest.getUniqueAppointmentNumber();				
				appointmentObject.put("AppointmentId", appointmentId);
			} catch (Exception e) {
				log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
				e.printStackTrace();
			}

			try {
				// update eventTypeCode and eventTypeDescription
				JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
				JSONObject event = (JSONObject) tnasaction.get(0);
				JSONObject eventObject = (JSONObject) event.get("EventType");					
				eventObject.put("EventTypeCode", "S12");
				eventObject.put("EventTypeDescription", "New appointment");
			} catch (Exception e) {
				log.error("Failed to update eventTypeCode", e);
				e.printStackTrace();
			}

			FileWriter file = new FileWriter(DIGITALDOCSJSONFILE);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}




	public String getDataFromJSONFile(String fieldName){
		String expectedResponseValue=null;
		try {
			FileReader reader = new FileReader(DIGITALDOCSJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");

			if(fieldName.contentEquals("AccountNumber")){
				/*JSONArray data = (JSONArray) visitObject.get("TenantPatientVisitIdentifier");
				JSONObject tenantPatient = (JSONObject) data.get(0);							
				expectedResponseValue= (String) tenantPatient.get("TenantPatientVisitId");*/
				expectedResponseValue = (String) visitObject.get("AccountNumber");	
			}

		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return expectedResponseValue;

	}

	public ArrayList<String> getListDataFromJSONFile(String scenarioName){
		ArrayList<String> jsondata=new ArrayList<String>();
		try {
			FileReader reader = new FileReader(DIGITALDOCSJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");

			SimpleDateFormat jsonDate = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat appDate = new SimpleDateFormat("MM/dd/yyyy");
			switch (scenarioName) {

			case "VisitInformation":
				/*JSONArray data = (JSONArray) visitObject.get("TenantPatientVisitIdentifier");
				JSONObject tenantPatient = (JSONObject) data.get(0);							
				jsondata.add((String) tenantPatient.get("TenantPatientVisitId"));*/

				jsondata.add((String) visitObject.get("AccountNumber"));	

				JSONObject patientGenderObject = (JSONObject) patientObject.get("PatientGender");

				jsondata.add((String) patientGenderObject.get("GenderDescription"));


				String dob=(String)patientObject.get("PatientDateOfBirth");
				Date expDate;
				expDate = jsonDate.parse(dob);
				jsondata.add(appDate.format(expDate));

				String inputdate=(String)visitObject.get("VisitDate");
				String[] result = inputdate.split("T");
				String splitedDate=result[0];
				expDate = jsonDate.parse(splitedDate);
				jsondata.add(appDate.format(expDate));

				String status=rest.getValueFromResponseandCompWithExpected("$..currentVisitStatusDescription");
				status=status.replaceAll("(\\p{Ll})(\\p{Lu})","$1 $2");
				jsondata.add(status);
				break;
			}
		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return jsondata;

	}



	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(tbl_AccountSearchData);
	}

}
