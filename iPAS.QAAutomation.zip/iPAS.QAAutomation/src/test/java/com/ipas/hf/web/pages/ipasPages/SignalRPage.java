package com.ipas.hf.web.pages.ipasPages;
import java.util.ArrayList;
import java.util.List;
import java.lang.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.io.*; 
import java.util.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.akiban.sql.parser.CurrentDatetimeOperatorNode;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;


import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;
import net.sourceforge.htmlunit.corejs.javascript.ast.ThrowStatement;
public class SignalRPage extends BasePage{
	
	private static final String NULL = null;




	public SignalRPage() {
		PageFactory.initElements(driver, this);
	}

	public String visitIdvalue;
	public RestActions rest = new RestActions();
	public String patientId;
	public String before_visitId;
	public String visitId;
	public String visitId1;
	public String expectedVisitId;
	public String accountNum;

	public String before_firstName;
	public String firstName;
	public String firstName1;
	public String lastName;
	public ArrayList<String> patientInfo;
	public ArrayList<String> list;

	@FindBy(xpath = "//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_SearchBox;
	
	@FindBy(xpath = "//div[@class='e-header-text']")
	private WebElement txt_header;
	
	@FindBy(xpath = "//button[contains(text(),'Columns')]")
	private WebElement btn_Columns;
	
	@FindBy(xpath = "//div[@class='e-kanban-header']")
	private WebElement grid_Header;
	
	@FindBy(xpath = "//div[@class='e-kanban-content e-lib e-draggable']")
	private WebElement grid_Results;
	
	@FindBy(xpath = "//div[contains(@id,'e-dropdown-btn_')]//ul")
	private WebElement lst_ColumnBox;
	
	@FindBy(xpath = "//service-tracker-facility//span//input")
	private WebElement drp_Facility;

	@FindBy(xpath = "//button[@class='btn btn-primary btn-md']")
	private WebElement btn_Apply;

	@FindBy(xpath = "//button[@class='btn btn-light w-md']")
	private WebElement btn_Tools;
	
	@FindBy(xpath ="//service-tracker-facility//span[@class='e-input-group-icon e-ddl-icon e-search-icon']")
	private WebElement arrow_Facility;
	
	@FindBy(xpath = "//service-tracker-department//span[@class='e-input-group-icon e-ddl-icon e-search-icon']")
	private WebElement arrow_ServDpt;
	
	@FindBy(xpath = "//service-tracker-department[1]/ejs-dropdownlist[1]/span[1]/span[1]")
	private WebElement arrow_ServDpt1;

	@FindBy(xpath ="//service-tracker-facility//span//input")
	private WebElement drpdownvalue_Facility;
	
	@FindBy(xpath ="//service-tracker-date//span//input")
	private WebElement ddl_DateOfService;
	
	@FindBy(xpath = "//service-tracker-department//span//input")
    private WebElement ddl_ServiceDepartment;
	
	 @FindBy(xpath = "//button[(text()='Apply')]")
	 private WebElement btn_Apply_Service;
	 
	 String li_GridColumns = "//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']";

	
	
	
	public String facility1="Bond Clinic";

	public String serviceDepartment1="imaging";
	public String serviceDepartment2="TestDepartment4";
	public String facilityID;
	public String serviceDept;
	public String visitDate;
	public String facilityName;
	public String Date;
	public String pocCode;


	
	
	public ArrayList<String> getPatientDataFromResponse(String patientId,String visitId,String data){
		String displayVisitId   = "";
		String displayPatientId = "";
		String patientinfo      = "";
		ArrayList<String> list =new ArrayList<>();

		try {
			String visitIdValue = rest.getStringValueFromResponse(visitId);
			String patientIdValue = rest.getStringValueFromResponse(patientId);
			String dataValue = rest.getStringValueFromResponse(data);

			
			displayVisitId = visitIdValue.replaceAll("\\W", "");
			displayPatientId= patientIdValue.replaceAll("\\W", "");
			patientinfo      =dataValue.replaceAll("\\W", "");
			list.add(displayVisitId);
			list.add(patientIdValue);
			list.add(dataValue);
			
			report.logPass("Validate Response Body Content Matches the Patient ID: " +displayPatientId+  "Visit ID :"+displayVisitId+
					"Patient Data :" +patientinfo);
		} catch (AssertionError e) {
			report.logHardFail("Validate Response Body Content Matches the Request Failed ", e);
		}
		return list;
	}
	
	public void selectFilters(String facility,String pocCode,String visitDate)
	{
		try {
			webActions.waitForPageLoaded();
			try {
				if(("BondClinic").contentEquals(facility))
				{
					webActions.waitForClickAbility(arrow_Facility, "Arrow");
					webActions.sendKeys(drp_Facility, "Bond Clinic", "Facility");
					webActions.sendKeysByJS(drp_Facility, "Bond Clinic", "Facility");
				    report.reportPass("Should select facility Name as :"+facility);
				} 
				
				else if(("Parkside Regional Clinic").contentEquals(facility))
				{
					webActions.waitForClickAbility(arrow_Facility, "Arrow");
					webActions.sendKeys(drp_Facility,facility, "Facility");
					webActions.sendKeysByJS(drp_Facility,facility, "Facility");
				    report.reportPass("Should select facility Name as :"+facility);
				}
				
				else if(("Parkside Regional Medical Hospital").contentEquals(facility))
				{
					webActions.waitForClickAbility(arrow_Facility, "Arrow");
					webActions.sendKeys(drp_Facility,facility, "Facility");
					webActions.sendKeysByJS(drp_Facility,facility, "Facility");
				    report.reportPass("Should select facility Name as :"+facility);
				}
			} catch (Exception e) {
				report.reportFail("Failed to select facility from facility dropdown  "+e,true);
			}
			try {
				if(("GIPC").contentEquals(pocCode)||("SDC").contentEquals(pocCode))
				   {
					   webActions.waitAndClick(arrow_ServDpt1, "serviceDepartment arrow"); 
					   webActions.isDisplayed(arrow_ServDpt1, "serviceDepartment arrow"); 
					   webActions.click(arrow_ServDpt1, "serviceDepartment arrow");
					   webActions.waitForPageLoaded();
					   webActions.sendKeys(ddl_ServiceDepartment,serviceDepartment1,"Service Department Dropdown Value");
					   report.reportPass("Should select Service Department value as "+serviceDepartment1+" for Point of care code :"+pocCode);
				   }
				   
				   else if(("CP").contentEquals(pocCode)||("NUCMD").contentEquals(pocCode))
				   {
					   
					   webActions.waitAndClick(arrow_ServDpt1, "serviceDepartment arrow"); 
					   webActions.isDisplayed(arrow_ServDpt1, "serviceDepartment arrow"); 
					   webActions.click(arrow_ServDpt1, "serviceDepartment arrow");
					   webActions.waitForPageLoaded();
					   webActions.sendKeys(ddl_ServiceDepartment,serviceDepartment2,"Service Department Dropdown Value");
					   report.reportPass("Should select Service Department value as "+serviceDepartment2+" for Point of care code :"+pocCode);
				   }	
			} catch (Exception e) {
				report.reportFail("Failed to select Service Department due to :  "+e,true);
			}
			
			   
			   try 
			   {
				   if((rest.getCurrentDate()).contentEquals(visitDate)||("Today").contentEquals(visitDate))
				   {
					   webActions.waitForPageLoaded();
					   webActions.sendKeys(ddl_DateOfService,rest.getCurrentDate(),"Date of Service : Today");
					   report.reportPass("Should display visit date as Current Date "+visitDate);   
				   }
				   
				   else if((webActions.getNextDate(1)).contentEquals(visitDate)||("Tomorrow").contentEquals(visitDate))
				   {
					   webActions.waitForPageLoaded();
					   webActions.clearValue(ddl_DateOfService,"Date of Service");
					   webActions.sendKeys(ddl_DateOfService,webActions.getNextDate(1),"Date of Service : Tomorrow");
					   report.reportPass("Should display visit date as : "+visitDate);   
				   }
			} catch (Exception e) {
				report.reportFail("Failed to display/post visit date  "+e);
			}
			   webActions.click(btn_Apply_Service, "Apply");
			   report.reportPass("Should click on Apply Button");
	
		} catch (Exception e1) {
			report.reportFail("Failed to display matched facility : "+e1);
		}
	}
	
	public ArrayList<String> verifyVisitCardResults(String visitId,String fieldname) throws Exception
	{
		webActions.waitForPageLoaded();
		Thread.sleep(5000);
		webActions.waitForPageLoaded();
		@SuppressWarnings("unused")
		String pointofcarelocation =NULL;
		String physicianFirstname=NULL;
		String physicianLastname=NULL;
		String patientvisitstatus=NULL;
		String patientserviceDepartment=NULL;
		String patientGender=NULL ; 
		String patientDOB= NULL;

		String xpath1="//a[text()=' ";
		String xpath2=" ']/../../..";
		String xpath3="/..";
		String xpath=xpath1+visitId+xpath2+xpath3;
		String xpath4=xpath1+visitId+xpath2;
		
		WebElement visitcard = driver.findElement(By.xpath(xpath));
		WebElement visitcardbody = driver.findElement(By.xpath(xpath4));

		list=new ArrayList<>();
		List<WebElement> visitcardDetails=visitcard.findElements(By.className("card-body"));
		List<WebElement> patientvisitcardbody=visitcardbody.findElements(By.tagName("span"));
		List<WebElement> patientvisitheader=visitcard.findElements(By.tagName("div"));
		String Patientcardbody[]            =visitcardDetails.get(0).getText().split(" ");
		String[] patientname                  =patientvisitheader.get(1).getText().split(" ");
		String patientFirstname               =patientname[0];
		String patientLastname                =patientname[1];

		String Gender ;
		String []serviceDepartment ;
		 if(patientvisitcardbody.size()==9)
			{
				Gender                             =patientvisitcardbody.get(0).getText();
				patientGender                      =Gender.substring(Gender.indexOf("(")+1,Gender.indexOf(")"));
				patientDOB                         =patientvisitcardbody.get(1).getText().trim();
				pointofcarelocation                =patientvisitcardbody.get(3).getText();
		        String physicianName[]             =patientvisitcardbody.get(4).getText().split(" ");
		        physicianFirstname                 =physicianName[2];
		        physicianLastname                  =physicianName[1];
		        patientvisitstatus                 =patientvisitcardbody.get(5).getText();
		        serviceDepartment                  =patientvisitcardbody.get(6).getText().split(" ");
		        patientserviceDepartment           =serviceDepartment[1];
			}
		
		else if(patientvisitcardbody.size()==8)
		{
			Gender                             =patientvisitcardbody.get(0).getText();
			patientGender                      =Gender.substring(Gender.indexOf("(")+1,Gender.indexOf(")"));
			patientDOB                         =patientvisitcardbody.get(1).getText();
			pointofcarelocation                =patientvisitcardbody.get(3).getText();
	        String physicianName[]             =patientvisitcardbody.get(4).getText().split(" ");
	        physicianFirstname                 =physicianName[2];
	        physicianLastname                  =physicianName[1];
	        patientvisitstatus                 =patientvisitcardbody.get(5).getText();
	        serviceDepartment                  =patientvisitcardbody.get(6).getText().split(" ");
	        patientserviceDepartment           =serviceDepartment[1];
		}
		
		else if(patientvisitcardbody.size()==7)
		{
			Gender                             =patientvisitcardbody.get(0).getText();
			patientGender                      =Gender.substring(Gender.indexOf("(")+1,Gender.indexOf(")"));
			patientDOB                         =patientvisitcardbody.get(1).getText();
			pointofcarelocation                =patientvisitcardbody.get(3).getText();
	        String physicianName[]             =patientvisitcardbody.get(4).getText().split(" ");
	        physicianFirstname                 =physicianName[2];
	        physicianLastname                  =physicianName[1];
	        patientvisitstatus                 =patientvisitcardbody.get(5).getText();
	        serviceDepartment                  =patientvisitcardbody.get(6).getText().split(" ");
	        patientserviceDepartment           =serviceDepartment[1];
		}
		
		if("PatientName".contentEquals(fieldname))
        {
        	list.add(patientFirstname);
        	list.add(patientLastname);
        }
        else if("PatientDateOfBirth".contentEquals(fieldname))

        {
        	list.add(patientDOB.trim());
        }
        else if("Gender".contentEquals(fieldname))
        {
        	list.add(patientGender);

        }
        else if("providerName".contentEquals(fieldname))
        {
        	list.add(physicianFirstname);
        	list.add(physicianLastname);
        }

        return list;
	  }
	
	public void verifySearchResults(WebElement header,WebElement results,String fieldName,String searchedData)
	{
	String functionName = "verifySearchResults";
	try {
	Integer columnIndex = null;
	List<WebElement> rows_table = grid_Header.findElements(By.tagName("tr"));
	List<WebElement> columns=rows_table.get(0).findElements(By.tagName("th"));
	for(int cnum=0;cnum<columns.size();cnum++)
	{
	String columnName = (columns.get(cnum).getText());
	if(columnName.toUpperCase().contains(fieldName.toUpperCase())){
	columnIndex = cnum;
	break;
	}
	}
	List<WebElement> results_rows_table = grid_Results.findElements(By.tagName("tr"));
	int rowsCount = results_rows_table.size();
	for(int rnum=0;rnum<rowsCount;rnum++){
	List<WebElement> resultsColumns= results_rows_table.get(rnum).findElements(By.tagName("td"));
	List<WebElement> resultsData = (resultsColumns.get(columnIndex).findElements(By.tagName("div")));
	for(int i = 0;i<resultsData.size();i++){
	String text = resultsData.get(i).getText();
	if(text.contains(searchedData)){
	report.reportPass("Pass");
	break;
	}
	}
	if(resultsData.contains(searchedData)){
		report.reportPass("Pass");
	}
	else{
		report.reportFail("Fail");
	break;
	}
	}
	}
	catch (Exception e)
	{
		report.reportFail("Error to display search results matching the search criteria  " + e);
	}
	}
	
	public void columnSelectionServiceTracker(DataTable columnNames,boolean select) {
		try{
			webActions.waitForVisibility(txt_SearchBox,"Search Box",120);
			List<String> expColNameList = columnNames.asList(String.class);
			report.reportInfo("Column Names to be selected are : "+expColNameList);
			webActions.waitForVisibility(btn_Columns,"Columns Dropdown");
			webActions.click(btn_Columns,"Columns Dropdown");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lst_ColumnBox,"Columns Dropdown");
			List<WebElement> options = lst_ColumnBox.findElements(By.tagName("li"));
			report.reportInfo("Total options in columns dropdown menu :"+options.size());
			for(int listcount = 0;listcount<expColNameList.size();listcount++){
				String expColName =expColNameList.get(listcount);
				options = lst_ColumnBox.findElements(By.tagName("li"));
				for(int i =0;i<options.size();i++){
					if(options.get(i).getText().equals(expColName)){
						String xpath1 = "(//span[text()='";
						String xpath2 = "'])[last()]";
						String xpath3 = xpath1+expColName+xpath2;
						String xpath4 = "//preceding::div[1]";
						String xpath5 = xpath3+xpath4;
						WebElement checkBox = driver.findElement(By.xpath(xpath5));
						WebElement checkBox1 = driver.findElement(By.xpath(xpath5));
						if(select==true)
						{
							if(checkBox1.getAttribute("aria-checked").equals("false"))
							{
								webActions.check(checkBox,expColName);
								report.reportPass("Should check the checkbox :" +expColName);
							}
							else
								report.reportInfo("Check box already checked "+expColName);	
							break;	
						}

						else if(select==false)
						{
							if(checkBox1.getAttribute("aria-checked").equals("true"))
							{
								webActions.check(checkBox,expColName);
								report.reportPass("Should uncheck the checkbox :" +expColName);
							}
							else
								report.reportInfo("Check box already unchecked "+expColName);	
							break;
						}
					}
				}
			}
			webActions.click(btn_Columns,"Columns Dropdown");

		}
		catch (Exception e) {
			report.reportFail(e.getMessage());
		}		
	}
	
	public ArrayList<String> getUmatchedInArrayComparision(List<String> actData, List<String> expData) throws Exception
	{
		ArrayList<String> UnmatchedArray = new ArrayList<String>();
		if(actData!=null && expData!=null &&actData.size()>0&&expData.size()>0 && actData.size()==expData.size()){
			for(int data=0;data<actData.size();data++)
			{
				if(!((actData.get(data)).contentEquals(expData.get(data))))
					UnmatchedArray.add(actData.get(data));	
			}
		}
		else{
			throw new Exception("Array Sizes are not matched");
		}
		return UnmatchedArray;			
	}
	
	public void CompareVisitCard(String visitId,String fieldname) throws Exception
	{
		ArrayList<String> ActualVal = new ArrayList<String>();
		ActualVal=rest.readJSON(fieldname);
		report.reportInfo("Updated JSON values :"+ActualVal);
		ArrayList<String> ExpectedVal = new ArrayList<String>();
		ExpectedVal=verifyVisitCardResults(visitId,fieldname);
		report.reportInfo("Updated Patient Visit Card Details :"+ExpectedVal);
		ArrayList<String> difference = getUmatchedInArrayComparision(ActualVal,ExpectedVal);
        if(difference.size()==0)
        {
              report.reportPass("JSON updation of Data on service tracker board successfull" ); 
        }
        else
            report.reportFail("JSON Data Modification/updation Failed :" +difference); 
	
	}
	
	public void ValidateVisitCardisNotDisplayed(String visitId) throws Exception
	{
		try {
			webActions.waitForPageLoaded();
			String xpath1="//a[text()=' ";
			String xpath2=" ']/../../../..";
			String xpath=xpath1+visitId+xpath2;
			WebElement visitcard = driver.findElement(By.xpath(xpath));
			webActions.waitForElementToBeNotPresent(visitcard,"Visit card with Account number"+visitId);
		}
		catch (Exception e1) {
            report.reportPass("Patient Visit Card should not be displayed on the board with visit id :"+visitId ); 
		}
	}
	
	public void VerifyVisitCardisDisplayed(String visitId)
	{
		try {
			webActions.waitForPageLoaded();
			String xpath1="//a[text()=' ";
			String xpath2=" ']/../../../..";
			String xpath=xpath1+visitId+xpath2;
			String xpath4="//div[@class='card-body']//a";
			WebElement visitcard = driver.findElement(By.xpath(xpath4));
			webActions.waitForVisibility(visitcard,"Visit card");
			String accountNumber =visitcard.getText().trim();
			webActions.waitForPageLoaded();
			if(visitId.contains(accountNumber))
			{
	            report.reportPass("Patient Visit Card should be displayed on the Service Tracker board with Account Number :"+visitId ); 
			}
			else
			{
	            report.reportFail("Patient Visit Card is not displayed on the Service Tracker board with visit id"); 
			}
		}
		catch (Exception e) {
            report.reportFail("Patient Visit Card is not displayed on the Service Tracker board with visit id :"+visitId +e); 
		}
	}
	
	public void VerifyVisitCardDisplayed(String visitId) throws Exception
	{
		try {
			webActions.waitForPageLoaded();
			String xpath1="//a[text()=' ";
			String xpath2=" ']/../../../..";
			String xpath=xpath1+visitId+xpath2;
			WebElement visitcard = driver.findElement(By.xpath(xpath));
			webActions.isDisplayed(visitcard,"Visit card with account number :"+visitId);
		}
		catch (Exception e1) {
            report.reportPass("Patient Visit Card is not displayed on the board with visit id :"+visitId ); 
		}
	}
	
	@SuppressWarnings("unused")
	public void verifyCardStatus(String expStatusName, String visitID) throws Exception{
		List<WebElement> gridHeaders = driver.findElements(By.xpath(li_GridColumns));
		report.reportPass("total columns displayed in the grid are :"+gridHeaders.size());		
		for(int gridc=0;gridc<gridHeaders.size();gridc++){
			String txt1=gridHeaders.get(gridc).getText();
			String[] splited = txt1.split("\\s[(]");
			txt1=splited[0];
			if(txt1.contentEquals(expStatusName)){	
				report.reportPass("status is displayed");
				String xpath1="//td[";
				String xpath2= "]//div[@class='card-body']";
				String xpath =xpath1+(gridc+1)+xpath2;
				List<WebElement> totalCards = driver.findElements(By.xpath(xpath));
				int cardinGrid = totalCards.size();
				report.reportPass("total cards count in :"+gridHeaders.get(gridc).getText()+" Status Column are :"+cardinGrid);		
				for(int j=0;j<cardinGrid;j++){
					String txt=totalCards.get(j).getText();
					String[] splited1 = txt.split("\\s");
					txt =splited1[0];	
					if(txt.contentEquals(visitID)){
						report.reportPass("visit id value is :"+txt+" is displayed under the status :"+txt1);
					}					
					break;
				}
			}
		}
	}
	
	public void verifyCardCountUnderStatus(String expStatusName, String visitID) throws Exception{
		webActions.waitForPageLoaded();
		List<WebElement> gridHeaders = driver.findElements(By.xpath(li_GridColumns));
		report.reportPass("total columns displayed in the grid are :"+gridHeaders.size());	
		for(int gridc=0;gridc<gridHeaders.size();gridc++){
			String txt1=gridHeaders.get(gridc).getText();
			String[] splited = txt1.split("\\s[(]");
			txt1=splited[0];
			try {
				if(txt1.contentEquals(expStatusName)){	
					report.reportPass("status is displayed");
					String xpath1="//td[";
					String xpath2= "]//div[@class='card-body']";
					String xpath =xpath1+(gridc+1)+xpath2;
					List<WebElement> totalCards = driver.findElements(By.xpath(xpath));
					int cardinGrid = totalCards.size();
					report.reportInfo("Cards displayed under the respective status column :"+cardinGrid );
					webActions.waitForPageLoaded();
					if(cardinGrid==1)
					{
					 report.reportPass("Card displayed successdully under the status column "+expStatusName);	
					}
					else
					{
						report.reportFail("Failed to display the card under the status column");
					}
				}	
			} catch (Exception e) {
				report.reportFail("Failed to display the card under the status due to :"+e);
			}
			
			
		}
	}
	
	public void pageRefresh()
	{
		webActions.refreshPage();
	}

	
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}