package com.ipas.hf.web.pages.ipasPages;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Sleeper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;


import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.ExtentSummary;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;
import io.cucumber.datatable.DataTable;

public class ViewFacilityConfigPage extends BasePage{
	
	private static final int WebElement = 0;
	private static final int Info = 0;
	RestActions rest=new RestActions();
	SimpleSearchPage search=new SimpleSearchPage();
	
	//xpaths
	
	@FindBy(xpath="//span[@class='panel-title' and text()='Accuracy & Accountability Advisor']")
	private WebElement lbl_AccuracyPanel;
	
	@FindBy(xpath="//span[@class='panel-title' and text()='Accuracy & Accountability Advisor']/../../..//a")
	private List<WebElement> lnk_AccuracyPanel;
	
	@FindBy(xpath="//div[contains(text(),'Configure Error Categories') or contains(text(),'Set up Accuracy and Accountability Advisor')]")
	private List<WebElement> txt_AccuracyPanelHelpText;
	
	@FindBy(xpath="//div[@class='breadcrum-container']/span")
	private List<WebElement> lbl_Breadcrumb;
	
	@FindBy(xpath="//button[text()='Add New Rule']")
	private WebElement btn_addNewRule;
	
	@FindBy(xpath="//button[text()='Apply']")
	private WebElement btn_apply;
	
	@FindBy(xpath="//a[text()='Rules Configuration']")
	private WebElement lnk_ruleConfig;
	
	@FindBy(xpath="//span[@class='breadcrum-active' and text()='Rule Configuration']")
	private WebElement brdcrum_ruleConfig;
	
	@FindBy(xpath="//ejs-dropdownlist[@id='ruleCategoryLookup']//input")
	private WebElement dd_ruleCategorySelectedValue;
	
	@FindBy(xpath="//ejs-dropdownlist[@id='facilityLookup']//input")
	private WebElement dd_FacilitySelectedValue;
	
	@FindBy(xpath="//ejs-dropdownlist[@id='ruleCategoryLookup']")
	private WebElement dd_ruleCategory;
	
	@FindBy(xpath="//label[text()='Rule Category Error']//following::label[1]/input[@type='checkbox']/../span[2]")
	private WebElement chkbx_inactive;
	
	@FindBy(xpath="//tr[@class='e-row' or @class='e-row e-altrow']")
	private List<WebElement> resultsgrid_rows;
	
	@FindBy(xpath="//div[@class='searchgrid']/span")
	private WebElement result_count;
	
	@FindBy(xpath="//span[@class='e-headertext']")
	private List<WebElement> headers_searchGrid;
	
	@FindBy(xpath="//div[@class='search-filter']//label")
	private List<WebElement> headers_searchFilter;
	
	@FindBy(xpath="//div[contains(text(),'Facility')]/../div[2]")
	private WebElement addnewRule_facility;
	
	 
	
	
	
	
	
	public ViewFacilityConfigPage() {
		PageFactory.initElements(driver, this);
	}
	
	//methods
	
	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}
	
	public void verifyPanelAndLinks(DataTable panelNames) {
		try {
			ArrayList<String> expLabels = new ArrayList<>(panelNames.asList());
			webActions.waitUntilisDisplayed(lbl_AccuracyPanel, "Accuracy and Accountability Panel");
			ArrayList<String> actLabels = new ArrayList<String>();
			actLabels.add(webActions.getText(lbl_AccuracyPanel, "Accuracy and Accountability Panel"));
			actLabels.addAll(webActions.getDatafromWebTable(lnk_AccuracyPanel));
			report.reportInfo("Expected Label Names Accuracy and Accountability Panel: "+expLabels);
			report.reportInfo("Displayed Lable Names in Accuracy and Accountability Panel: "+actLabels);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actLabels, expLabels);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Label Names in Accuracy and Accountability Panel successfully");
			}
			else{
				throw new Exception("Fail to verify Label Names in Accuracy and Accountability Panel and unmatched label Names are: "+unmatchedLabelNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyHelpText(DataTable label) {
		try {
			ArrayList<String> expLabels = new ArrayList<>(label.asList());
			report.reportInfo("Expected Helptext in Accuracy and Accountability: "+expLabels);
			webActions.waitUntilisDisplayed(lbl_AccuracyPanel, "Accuracy and Accountability Panel");
			ArrayList<String> actLabels = new ArrayList<String>();
			actLabels.addAll(webActions.getDatafromWebTable(txt_AccuracyPanelHelpText));
			report.reportInfo("Expected Help Text in  Accuracy and Accountability Panel: "+expLabels);
			report.reportInfo("Displayed Help Text in Accuracy and Accountability Panel: "+actLabels);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actLabels, expLabels);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Help Text in Accuracy and Accountability Panel successfully");
			}
			else{
				throw new Exception("Fail to verify Help Text in Accuracy and Accountability Panel and unmatched label Names are: "+unmatchedLabelNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyRulesConfigurationLink(DataTable label) {
		try {
			ArrayList<String> expLabels = new ArrayList<>(label.asList());
			report.reportInfo("Expected Helptext in Accuracy and Accountability: "+expLabels);
			webActions.waitUntilisDisplayed(lbl_AccuracyPanel, "Accuracy and Accountability Panel");
			ArrayList<String> actLabels = new ArrayList<String>();
			actLabels.addAll(webActions.getDatafromWebTable(txt_AccuracyPanelHelpText));
			report.reportInfo("Expected Help Text in  Accuracy and Accountability Panel: "+expLabels);
			report.reportInfo("Displayed Help Text in Accuracy and Accountability Panel: "+actLabels);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actLabels, expLabels);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified Help Text in Accuracy and Accountability Panel successfully");
			}
			else{
				throw new Exception("Fail to verify Help Text in Accuracy and Accountability Panel and unmatched label Names are: "+unmatchedLabelNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyBreadcrumbRulesConfiguration(DataTable breadcrumb ){
		try {
			ArrayList<String> expectdBreadcrumb = new ArrayList<>(breadcrumb.asList());
			webActions.waitForPageLoaded();
			ArrayList<String> actualBreadcrumb=webActions.getDatafromWebTable(lbl_Breadcrumb);
			report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumb);
			report.reportInfo("Expected Breadcrumb Titles "+expectdBreadcrumb);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumb, expectdBreadcrumb);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Breadcrumb Titles in Rules Configuration page");
			}else{
				throw new Exception("Fail to verify the Breadcrumb Titles in Rules Configuration page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyAddNewRule(){
		try {
			String expectedFacilityName=dd_FacilitySelectedValue.getAttribute("value").trim();
			webActions.waitForPageLoaded();
			webActions.click(btn_addNewRule, "Add New Rule Button");
			webActions.waitForPageLoaded();
			String actualFacilityName=addnewRule_facility.getText().trim();
			report.reportInfo("Expected facility name in search filter: "+expectedFacilityName);
			report.reportInfo("Actual facility name in Add New Rule: "+actualFacilityName);
			if(actualFacilityName.contentEquals(expectedFacilityName)){
				report.reportPass("Successfully displayed Add New Rule Button and the matching facility name in Add New Rule");
			}else{
				throw new Exception("Fail to display Add New Rule Button and the matching facility name in Add New Rule");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void clickRuleConfiguration(){
		try {
			webActions.waitForPageLoaded();
			if(webActions.isDisplayed(lnk_ruleConfig,"Rule Configuration link")){
				webActions.click(lnk_ruleConfig, "Rule Configuration link");
				report.reportPass("Successfully clicked on Rules Configuration link");
				webActions.waitForPageLoaded();
				webActions.isDisplayed(brdcrum_ruleConfig,"Rules Configuration"); 
			}else{
				throw new Exception("Fail to click on Rules Configuration link");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyDefaultValue(String value){
		try {
			webActions.waitForPageLoaded();
				String expectedSelectedValue=value;
				String actualSelectedValue=dd_ruleCategorySelectedValue.getAttribute("aria-label");
				report.reportInfo("Expected selected value :"+expectedSelectedValue);
				report.reportInfo("Actual selected value :"+actualSelectedValue);
				if(actualSelectedValue.contentEquals(expectedSelectedValue)){
				report.reportPass("Successfully displayed the default value All in Rules Category Dropdown");
			}else{
				throw new Exception("Fail to display the default value All in Rules Category Dropdown");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyInactiveCheckBox(String value){
		try {
			webActions.waitForPageLoaded();
				String expectedLabelValue=value;
				String actualLabelValue=chkbx_inactive.getText();
				if(actualLabelValue.contentEquals(expectedLabelValue)){
				report.reportPass("Successfully displayed the " +value+ " checkbox to right of rules category dropdown");
			}else{
				throw new Exception("Fail to display the checkbox to right of rules category dropdown");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyResultsDisplayed(){
		try {
			webActions.waitForPageLoaded();
				String expectedCount=String.valueOf(resultsgrid_rows.size());
				String []count=result_count.getText().split(":");
				String actualCount=count[1].trim();
				report.reportInfo("Expected count :"+expectedCount);
				report.reportInfo("Actual count :"+actualCount);
				if(actualCount.contentEquals(expectedCount.trim())){
				report.reportPass("Successfully displayed the results count in search results grid matching with the rows displayed");
			}else{
				throw new Exception("Fail to display the results count in search results grid matching with the rows");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyRuleListRulesConfiguration(DataTable rulelist ){
		try {
			ArrayList<String> expectdRuleList = new ArrayList<>(rulelist.asList());
			ArrayList<String> actualRuleList = new ArrayList<>();
			webActions.waitForPageLoaded();
			for(int i=0;i<headers_searchGrid.size();i++)
			{
				if(!headers_searchGrid.get(i).getText().isEmpty())
				{
					actualRuleList.add(headers_searchGrid.get(i).getText());
				}
			}
			report.reportInfo("Actual Rule list: "+actualRuleList);
			report.reportInfo("Expected Rule list "+expectdRuleList);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualRuleList, expectdRuleList);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the rules list in Rules Configuration page");
			}else{
				throw new Exception("Fail to verify the rules list in Rules Configuration page: "+unmatch);
			}
			
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifySearchHeaders(DataTable labels){
		try {
			ArrayList<String> expLabels = new ArrayList<>(labels.asList());
			webActions.waitForPageLoaded();
			ArrayList<String> actLabels = new ArrayList<String>();
			actLabels.addAll(webActions.getDatafromWebTable(headers_searchFilter));
			actLabels.add(webActions.getText(btn_apply, "Apply Button"));
			actLabels.add(webActions.getText(btn_addNewRule, "Add New Rule Button"));
			report.reportInfo("Expected filter names: "+expLabels);
			report.reportInfo("Displayed filter names in Rules configuration: "+actLabels);
			ArrayList<String>unmatchedLabelNames=webActions.getUmatchedInArrayComparision(actLabels, expLabels);
			if(unmatchedLabelNames.size()==0){
				report.reportPass("Verified filter names in Rules configuration successfully");
			}
			else{
				throw new Exception("Fail to verify filter names in Rules configuration and unmatched label Names are: "+unmatchedLabelNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}


	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
