package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.PostalConfirmationPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class PostalConfirmationSteps {
	PostalConfirmationPage postal=new PostalConfirmationPage();	

	@Then("Update Auto Run flag as {string} for {string} module")
	public void update_Auto_Run_flag_as_for_module(String runStatus, String module) {
		postal.verifyAutoRunFlagOnAndOff(runStatus, module);
	}

	@Then("Verify the display of Postal Confirmation {string}")
	public void verify_the_display_of_Postal_Confirmation(String panel, DataTable testdata) {
		postal.verifyPostalPanel(panel, testdata);
	}

	@Then("Verify the postal of {string} module status when {string}")
	public void verify_the_postal_of_module_status_when(String panel, String data) {
		postal.verifyPostalPanelModuletStatus(panel,data);
	}

	@Then("Verify expand and collapse of the Postal confirmation Panel")
	public void verify_expand_and_collapse_of_the_Postal_confirmation_Panel() throws Exception {
		postal.verifyExpandandCollapsPostalPanel();
	}

	@Then("Click on Postal link")
	public void click_on_Postal_link() {
		postal.clickOnPostal();
	}

	@Then("Then Get the value from response body as {string} and Verify the breadcrumb as {string} and as {string}")
	public void then_Get_the_value_from_response_body_as_and_Verify_the_breadcrumb_as_and_as(String visitId, String pageName, String menuName) throws Exception {
		postal.verifyDisplayedBreadcrumb(visitId, pageName, menuName);
	}

	@Then("Verify the display of last run by in both short and full panel")
	public void verify_the_display_of_last_run_by_in_both_short_and_full_panel() {
		postal.verifyLastRunByInPostalPanel();
	}	
	@Then("Verify the display of buttons and fields")
	public void verify_the_display_of_buttons_and_fields() {
		postal.verifyFieldsInPostalFullPanel();
	}

	@Then("Click on New Request button")
	public void click_on_New_Request_button() {
		postal.clickOnPostalNewRequestBtn();
	}
	@Then("Verify the display of {string} in postal new request window")
	public void verify_the_display_of_in_postal_new_request_window(String scenario,DataTable testData) {
		postal.verifyfieldsAndSections(scenario, testData);
	}
	@Then("Click on cancel and cross options and verify the navigation")
	public void click_on_cancel_and_cross_options_and_verify_the_navigation() {
		postal.cancelAndCrossNavigation();
	}
	@Then("Verify the display of {string} data elements")
	public void verify_the_display_of_data_elements(String panel,DataTable testdata) {
		postal.verifyDataElementsInShortAndFull(panel, testdata);
	}

	@Then("Verify the status of {string} Data elements and status as {string}")
	public void verify_the_status_of_Data_elements_and_status_as(String panel, String status) {
		postal.verifyPostalDataElementsModuletStatus(panel,status);
	}
	@Then("Verify the display of {string} message as {string}")
	public void verify_the_display_of_message_as(String panel, String message) {
		postal.postalSuccessMsg(panel, message);
	}
	@Then("Verify the display of message on the {string} panel as {string}")
	public void verify_the_display_of_message_on_the_panel_as(String panel, String message) {
		postal.verifyMsgForManualRun(panel, message);
	}
	@Then("Navigate to the Account Search page by link")
	public void navigate_to_the_Account_Search_page_by_link() {
		postal.navigateAccountSearch();
	}
	@Then("Navigate to Maintenance Page from ipas pages")
	public void navigate_to_Maintenance_Page_from_ipas_pages() {
		postal.navigateMaintenanceiPAS();
	}
	@Then("Enter Valid Zipcode in {string} request window as {string} and click on send request")
	public void enter_Valid_Zipcode_in_request_window_as_and_click_on_send_request(String type, String zipCode) {
		postal.enterZipCode(type, zipCode);
	}

	@Then("Enter the data in address fields and click on send request")
	public void enter_the_data_in_address_fields_and_click_on_send_request(DataTable testData) {
		postal.enterAddressData(testData);
	}
	@Then("Verify the last run by for manual request in full and short panels")
	public void verify_the_last_run_by_for_manual_request_in_full_and_short_panels() {
		postal.verifyManualLastRunByInPostalPanel();
	}
	@Then("Click on History button and verify the history window")
	public void click_on_History_button_and_verify_the_history_window(DataTable testData) {
		postal.verifyHistroyWindow(testData);   
	}	
	@Then("Verify the closing of History window on selecting cancel")
	public void verify_the_closing_of_History_window_on_selecting_cancel() {
		postal.verifyCancelInHistoryWindow();
	}
	@Then("Verify the display of Historical Postal Confirmation as {string} on selecting the history record")
	public void verify_the_display_of_Historical_Postal_Confirmation_as_on_selecting_the_history_record(String zipCode) {
		postal.verifyHistoricalPostalConfirmationData(zipCode);
	}
	@Then("Verify the display of current request data zipCode as {string} in full panel on selecting the current request button")
	public void verify_the_display_of_current_request_data_zipCode_as_in_full_panel_on_selecting_the_current_request_button(String zipCode) {
		postal.verifyCurrentRequestData(zipCode);
	}

}
