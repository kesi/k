package com.ipas.hf.web.steps;

import org.json.simple.parser.ParseException;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.UpdateVisitPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class UpdateVisitSteps {

	Login logIn = new Login();
	HomePage home = new HomePage();
	UpdateVisitPage updateVisit = new UpdateVisitPage();	
	RestActions rest = new RestActions();

	@Then("verify the Patient Visit Card as {string}")
	public void verify_the_Patient_Visit_Card_with(String visitID) throws Exception {
		updateVisit.simpleSearch(visitID);
		updateVisit.verifyPatientVisitCard(visitID);
	}

	@Then("Get value from response body and verify the Patient Visit Card as {string}")
	public void get_value_from_response_body_and_verify_the_Patient_Visit_Card_as(String visitID) throws Exception {
		updateVisit.compareVisitID(visitID);
	}

	@Then("verify the Patient Visit Card with VisitID: VisitID as {string}")
	public void verify_the_Patient_Visit_Card_with_VisitID_VisitID_as(String visitID) throws Exception {
		updateVisit.simpleSearch(visitID);
		updateVisit.verifyPatientVisitCard(visitID);
	}

	@Then("Click on Three Dots to open Model Window and verify the VisitID as {string}")
	public void click_on_Three_Dots_to_open_Model_Window_and_verify_the_VisitID(String responseValue) throws Exception {
		String visitID= logIn.getVisitIdFromResponse(responseValue);
		updateVisit.openModelWindow(visitID);
	}

	@Then("Verify the buttons in Model Window")
	public void verify_the_buttons_in_Model_Window() throws Exception {
		updateVisit.verifyModelWindowButtons();
	}

	@Then("Verify the Patient Name Detials on the Model Window as {string}")
	public void verify_the_Patient_Name_Detials_on_the_Model_Window_with_VisitID_VisitID_as(String responseValue) throws Exception {
		String visitID= logIn.getVisitIdFromResponse(responseValue);
		updateVisit.verifyPatientDetails(visitID);
	}

	@Then("Select Destination value from Destination Drop Down : Destiantion as {string}")
	public void destination_value_from_Destination_Drop_Down_Destiantion_as(String value) throws Exception {
		updateVisit.selectDestination(value);
	}

	@Then("Select Regitrar from Drop Down : Registrar as {string}")
	public void select_Regitrar_from_Drop_Down_Registrar_as(String value) throws Exception {
		updateVisit.selectRegistration(value);
	}

	@Then("Select Priority Check Box in Model Window")
	public void select_Priority_Check_Box_in_Model_Window() {
		updateVisit.selectPriority();
	}

	@Then("click on Submit button and close the Model Window")
	public void click_on_Submit_button_and_close_the_Model_Window() throws Exception {
		updateVisit.clickSubmit();
		updateVisit.getfilterMessages();
		updateVisit.closeModelWindow();
	}
	@Then("Verify the Destination, Registrar and Priority values")
	public void verify_the_Destination_Registrar_and_Priority_values() throws Exception {
		updateVisit.verifyDestinationRegistrarOnCard();
	}

	@Then("Select Intake Status from Drop Down : Intake Status as {string}")
	public void select_Intake_Status_from_Drop_Down_Intake_Status_as(String value) throws Exception {
		updateVisit.selectIntakeStatus(value);
	}

	@Then("Verify Tabs Names in Model Window")
	public void verify_Tabs_Names_in_Model_Window(DataTable data) {
		updateVisit.verifyTabsNamesInModelWindow(data);
	}

	@Then("Verify Visit Cards count against an Intake Status: Status as {string}")
	public void verify_Visit_Cards_count_against_an_Intake_Status_Status_as(String statusName) {
		updateVisit.verifyVisitCardsCount(statusName);
	}

	@Then("Verify the display of Visit Card under new Intake Status as {string} and {string}")
	public void verify_the_display_of_Visit_Card_under_new_Intake_Status_VisitID_as_and_Status_as(String expStatusName, String responseValue) throws Exception {
		String visitID = logIn.getVisitIdFromResponse(responseValue);
		updateVisit.verifyCardAgainstStatusColumn(expStatusName, visitID);
	}

	@Then("Verify the default value of Priority on the Visit Card")
	public void verify_the_default_value_of_Priority_on_the_Visit_Card() throws Exception {
		updateVisit.priorityNotDisplayedOnCard();
	}

	@Then("Verify the default values of Destination and Registrar on the Model Window")
	public void verify_the_default_values_of_Destination_and_Registrar_on_the_Model_Window() {
		updateVisit.defaultVaulesofDestinationRegistrar();
	}

	@Then("Verify the Unassigned for Destination and Registrar for newly created Visit Card")
	public void verify_the_Unassigned_for_Destination_and_Registrar_for_newly_created_Visit_Card() throws Exception {
		updateVisit.verifyDestinationRegistrarOnCard();
	}

	@Then("Get value from response body as {string} and search in Service Tracker Page")
	public void get_value_from_response_body_as_and_search_in_Service_Tracker_Page(String visitID) {
		updateVisit.simpleSearch(visitID);
	}

	@Then("Get the VisitID from JSON and search in Service Tracker Page as {string}")
	public void get_the_VisitID_from_JSON_and_search_in_Service_Tracker_Page(String responseValue) throws Exception {
		String visitID= logIn.getVisitIdFromResponse(responseValue);
		updateVisit.simpleSearch(visitID);
		updateVisit.verifyPatientVisitCard(visitID);
		Thread.sleep(5000);
	}

	@Then("Post data using event type as {string}")
	public void post_data_using_event_type_as(String eventType) throws ParseException {
		updateVisit.updatePatientVisitADTJsonFile(eventType);
	}

	@Then("Compare PointofCare on Visit Card and Modal Window as {string} for VisitID as {string}")
	public void compare_PointofCare_on_Visit_Card_and_Modal_Window_as_for_VisitID_as(String pocCode, String responseValue) throws Exception {
		String visitID= logIn.getVisitIdFromResponse(responseValue);
		updateVisit.getPOFCareOnCard(pocCode,visitID);
	}

	@Then("Verify the display of Present Status of the Visit Card on the Model Window")
	public void verify_the_display_of_Present_Status_of_the_Visit_Card_on_the_Model_Window() throws Exception {
		updateVisit.getStatusOnCard();
	}

	@Then("Verify the value of Priority on the Visit Card")
	public void verify_the_value_of_Priority_on_the_Visit_Card() throws Exception {
		updateVisit.priorityDisplayedOnCard();
	}

	@Then("Verify updated Destination, Registrar and Service Department on Visit Card")
	public void verify_updated_Destination_Registrar_and_Service_Department_on_Visit_Card(DataTable options) throws Exception {
		updateVisit.verifyDestinationRegistrarOnVisitCard(options);
	}

	@Then("Verify the color of Visit Number on Model Window")
	public void verify_the_color_of_Visit_Number_on_Model_Window() throws Exception {
		updateVisit.verifyVisitNumberColor();
	}

	@Then("Verify VisitTime on Page as {string}")
	public void verify_VisitTime_on_Page_as(String pageName) throws Exception {
		String visitDate= updateVisit.getVisitDatefromJSONresponseBasedOnObject();
		System.out.println("Visit Date is :"+visitDate);
		updateVisit.verifyVistTime(pageName,"5","30",visitDate);
	}

	@Then("Close the service tracker model window")
	public void close_the_service_tracker_model_window() throws Exception {
		updateVisit.closeModelWindow();
	}
	@Then("Click on service tracker panel link from visit main page")
	public void click_on_service_tracker_panel_link_from_visit_main_page() {
		updateVisit.clickOnServiceTracerPanelLnk();
	}

	@Then("Verify the wait time")
	public void verify_the_wait_time() {
		updateVisit.verifyDisplayWaitTime();
	}

	@Then("Verify wait time on the card")
	public void verify_wait_time_on_the_card() {
		updateVisit.waitTimeOnCard();
	}
	@Then("Go to the authorized users tab")
	public void go_to_the_authorized_users_tab() {
		updateVisit.authorizedUsersTab();
	}
	@Then("Verify the default display message as {string}")
	public void verify_the_default_display_message_as(String expMsg) {
		updateVisit.verifyAuthorizedUsersTabMsg(expMsg);
	}
	@Then("Add the Authorized users")
	public void add_the_Authorized_users(DataTable testData) {
		updateVisit.addAuthorizedUserInVim(testData);
	}

	@Then("Verify the authorized users")
	public void verify_the_authorized_users(DataTable testData) {
		updateVisit.verifyAuthorizedUsersInTab(testData);
	}


}