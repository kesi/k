package com.ipas.hf.api.steps;

import java.util.ArrayList;

import org.json.simple.parser.ParseException;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.azureutilities.CosmosDbDataValidation;
import com.ipas.hf.rest.RestActions;

import cucumber.api.java.en.Then;

public class CosmosDBSteps {	

	CosmosDbDataValidation comos=new CosmosDbDataValidation();
	RestActions rest=new RestActions();	



	@Then("Get the value of {string} from response body and connect to {string} cosmosDB and {string}")
	public void get_the_value_of_from_response_body_and_connect_to_cosmosDB_and(String dataBase, String containerId) {

		try {		  
			String id=comos.getPatientVisitIdFromResponse();
			comos.verifyAppointmentduration(dataBase, containerId, id);
		} catch (Exception e) {		
			e.printStackTrace();
		}
	}

	@Then("Update cosmos json file based on given event type {string}")
	public void update_cosmos_json_file_based_on_given_event_type(String type) {
		try {
			rest.cosmosSIUJsonFile(type);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Then("Read the patient information from current document {string} cosmosDB and {string} conatiner")
	public void read_the_patient_information_from_current_document_cosmosDB_and_conatiner(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		ArrayList<String> patientInfo=comos.readPatientInfoFromCosmos(dataBase, containerName, id);
		CosmosDbDataValidation.notepadWrite("hello", patientInfo);
	}

	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the patient information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_patient_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyPatientInformation(dataBase, containerName, id);
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the appointment duration information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_appointment_duration_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyAppointmentDuration(dataBase, containerName, id);
	}

	@Then("Read the contact information from current document {string} cosmosDB and {string} conatiner")
	public void read_the_contact_information_from_current_document_cosmosDB_and_conatiner(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		String patientContactInfo=comos.readPatientContactInfoFromCosmos(dataBase, containerName, id);
		CosmosDbDataValidation.notepadWrite("hello", patientContactInfo);
	}

	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the contact information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_contact_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyPatientContactInformation(dataBase, containerName, id);
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the visit provider information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_visit_provider_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyAdmittingVisitProviderInformation(dataBase, containerName, id);
	}

	@Then("Connect to {string} and {string} and the verify the generating of Insurance and Guarantor Ids from current document")
	public void connect_to_and_and_the_verify_the_generating_of_Insurance_and_Guarantor_Ids_from_current_document(String dataBase, String containerName) {
		ArrayList<String> insuGarid=new ArrayList<>();
		String insuranceId=comos.getInsuranceIdFromResponse();
		String guarantorId=comos.getGuarantorIdFromResponse();
		insuGarid.add(insuranceId.trim());
		insuGarid.add(guarantorId.trim());
		CosmosDbDataValidation.notepadWrite("hello", insuGarid);		
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyInsuranceGuarantorIds(dataBase, containerName, id);
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the insurance information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_insurance_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyInsuranceInformation(dataBase, containerName, id);
	}	
	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the facilityPayerMasterId from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_facilityPayerMasterId_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyFacilityPayerMasterId(dataBase, containerName, id);
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the guarantor information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_guarantor_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyGuarantorInformation(dataBase, containerName, id);
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the claimOccurance information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_claimOccurance_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyClaimOccuranceInformation(dataBase, containerName, id);
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the accident information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_accident_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyAccidentInformation(dataBase, containerName, id);
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the observation information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_observation_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyObservationInformation(dataBase, containerName, id);
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the drg information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_drg_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyDRGInformation(dataBase, containerName, id);	   
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the diagnosis information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_diagnosis_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyDiagnosisInformation(dataBase, containerName, id);
	}
	@Then("Read the all objects information from current document {string} cosmosDB and {string} conatiner")
	public void read_the_all_objects_information_from_current_document_cosmosDB_and_conatiner(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		ArrayList<String> allInfo=comos.readAllObjectsInformation(dataBase,containerName,id);
		CosmosDbDataValidation.notepadWrite("hello", allInfo);
	}	

	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the all objects information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_all_objects_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyVisitStatusAndDischargeDate(dataBase, containerName, id);
		comos.verifyAllObjectsInformation(dataBase, containerName, id);
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the general information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_general_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyJSONfields(dataBase, containerName, id);
	}

	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the visit status from current document as {string} and {string}")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_visit_status_from_current_document_as_and(String dataBase, String containerName, String status, String statusChange) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyVisitStatus(dataBase, containerName, id,status,statusChange);
	}

	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the expiring of visit status from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_expiring_of_visit_status_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyVisitStatusExpiry(dataBase, containerName, id);
	}
	@Then("Update SIU json file based on given event type {string}")
	public void update_SIU_json_file_based_on_given_event_type(String type) {
		try {
			rest.SIUJsonFile(type);
		} catch (ParseException e) {			
			e.printStackTrace();
		}
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner read the identifiers from current document")
	public void connect_to_cosmosDB_and_conatiner_read_the_identifiers_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.readPatientIdentifiersFromCosmos(dataBase, containerName, id);
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the added objects information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_added_objects_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyAllObjectsInformation(dataBase, containerName, id);
	}
	@Then("update cosmos ADT json file based on given event type {string}")
	public void update_cosmos_ADT_json_file_based_on_given_event_type(String type) {
		try {
			rest.cosmosADTJsonFile(type);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Then("update cosmos SIUADT json file based on given event type {string}")
	public void update_cosmos_SIUADT_json_file_based_on_given_event_type(String type) {
		try {		 
			rest.cosmosSIUADTJsonFile(type);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Then("Read the all objects information from ADT current document {string} cosmosDB and {string} conatiner")
	public void read_the_all_objects_information_from_ADT_current_document_cosmosDB_and_conatiner(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();	
		comos.verifyAllADTObjectsInformation(dataBase, containerName, id);

	}
	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the all ADT objects information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_all_ADT_objects_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyVisitStatusAndDischargeDate(dataBase, containerName, id);
		comos.verifyAllADTObjectsInformation(dataBase, containerName, id);
	}
	@Then("Update ADT json file based on given event type {string}")
	public void update_ADT_json_file_based_on_given_event_type(String type) {
		try {
			rest.objectsADTJsonFile(type);
		} catch (ParseException e) {			
			e.printStackTrace();
		}
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner read the ADT identifiers from current document")
	public void connect_to_cosmosDB_and_conatiner_read_the_ADT_identifiers_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.readADTPatientIdentifiersFromCosmos(dataBase, containerName, id);
	}
	@Then("Read the all objects information from ADT current document {string} cosmosDB and {string} conatiner store in list")
	public void read_the_all_objects_information_from_ADT_current_document_cosmosDB_and_conatiner_store_in_list(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		ArrayList<String> allInfo=comos.readAllObjectsADTInformation(dataBase,containerName,id);
		CosmosDbDataValidation.notepadWrite("hello", allInfo);
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the transaction array")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_transaction_array(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyTransactionArray(dataBase, containerName, id);

	}

	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the generating of procedureID")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_generating_of_procedureID(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		comos.verifyProcedureId(dataBase, containerName, id);
	}	

	@Then("Connect to {string} cosmosDB and {string} conatiner and the verify the estimate visit provider information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_the_verify_the_estimate_visit_provider_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		String providerName=comos.readVisitProviderInfoFromCosmos(dataBase, containerName, id);
		CosmosDbDataValidation.notepadWrite("hello", providerName);
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner and read the primary insurance plan name information from current document")
	public void connect_to_cosmosDB_and_conatiner_and_read_the_primary_insurance_plan_name_information_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		String insurancePlanName=comos.readInsurancePlanNameFromCosmos(dataBase, containerName, id);
		CosmosDbDataValidation.notepadWrite("hello", insurancePlanName);
	}
	@Then("Connect to {string} cosmosDB and {string} conatiner and read cpt code from current document")
	public void connect_to_cosmosDB_and_conatiner_and_read_cpt_code_from_current_document(String dataBase, String containerName) {
		String id=comos.getPatientVisitIdFromResponse();
		ArrayList<String> proceInfo=comos.readProcedureInfoFromCosmos(dataBase, containerName, id);
		CosmosDbDataValidation.notepadWrite("hello", proceInfo);
	}
}
