package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import cucumber.api.java.en.Then;

public class STFullPagePage extends BasePage {
	UpdateVisitPage updateVisit = new UpdateVisitPage();
	VPVServiceTrackerPanelPage vsrvcPanel = new VPVServiceTrackerPanelPage();
	String resetPassword="";
	private RestActions rest = new RestActions();
	Login logIn=new Login();
	PatientVisitSummaryAllDataPanelPage summaryPage=new PatientVisitSummaryAllDataPanelPage();

	@FindBy(xpath = "//input[@id='username']")
	private WebElement txt_UserName;

	String li_GridColumns = "//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']";

	@FindBy(xpath = "//label[contains(text(),'Search')]//following::input[1]")
	private WebElement txt_SimpleSearch;

	@FindBy(xpath="//form[@id='EditForm']//div[1]/div[@class='st modal-header']/button[@class='close']")
	private WebElement btn_MWindowClose;

	@FindBy (xpath= "//li[@id='p-highlighted-option']")
	private WebElement li_SimpleSeacrh;

	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@formcontrolname='serviceTrackerStatusId']/span/span")
	private WebElement drpdwn_IntakeStatus;

	@FindBy(xpath = "//form[1]//ejs-dropdownlist[@formcontrolname='serviceTrackerStatusId']/span//input")
	private WebElement drpvalue_IntakeStatus;

	@FindBy(xpath = "//app-ipas-service-tracker-panel[1]//div[1]/span[1]/div[1]/a[1]")
	private WebElement lnk_STPanel;

	@FindBy(partialLinkText = "Service Track")
	private WebElement lnk_STPanelLink;
	
	@FindBy(xpath = "//ipas-service-tracker-details[1]//span[1]/div[1]/span[1]")
	private WebElement lbl_STFullPage;

	String stfulData = "//ipas-service-tracker-details[1]//div[2]/div[1]/span[1]";

	@FindBy(xpath="//div[@class='allData-control-section']/ejs-dashboardlayout/div")
	private WebElement tbl_AllData;
	
	@FindBy(xpath = "//ipas-service-tracker-details[1]//div[2]/div[1]/span[1]")					
	private WebElement lbl_STFPData;

	@FindBy(xpath ="//a[contains(text(),'Account Search')]")
	private WebElement lnk_AccountSearch;

	@FindBy(xpath="//a[contains(text(),'Service Tracker')]")
	private WebElement lnk_ServiceTracker;

	@FindBy(xpath="//table[@class='e-table']//thead/tr")
	private WebElement lbl_Headers;

	@FindBy(xpath ="//div[@class='e-gridcontent']//tr[1]//td[2]/div/a")
	private WebElement lnk_AccountNumber;

	@FindBy(xpath="//div[@class='e-acrdn-header-content']")
	private WebElement lbl_AllPanels;

	@FindBy(xpath = "//a[contains(text(),'All Data')]")
	private WebElement lbl_AllDataPanelTitle;

	@FindBy(xpath="//div[@class='breadcrum-container']/span")
	private List<WebElement> lbl_AllDataFullPage;

	@FindBy(xpath="//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']")
	private WebElement lbl_Headers_ServiceTracker;

	@FindBy(xpath = "//input[@class='form-control e-control e-textbox e-lib e-input']")
	private WebElement txt_Search_ServiceTracker;

	@FindBy(xpath="//ipas-service-tracker-details[1]//span[2]/span[1]")
	private WebElement txt_StatusOnSTFPage;

	@FindBy(xpath = "//ipas-service-tracker-details[1]//span[2]/img[1]")
	private WebElement img_ThreeDots;

	@FindBy(xpath="//img[@src='assets/images/high_priority.png']")
	private WebElement img_STFPagePriority;

	@FindBy(xpath = "//ipas-service-tracker-details[1]//financial-clearance-status[1]/img[1]")
	private WebElement img_FinancialClearance;

	@FindBy(xpath="//div[@class='st modal-dialog modal-xl']//div[2]/span[1]")
	private WebElement lbl_VisitID;

	@FindBy(xpath="//ipas-service-tracker-details[1]//table[1]//div[2]//img[1]")
	private WebElement img_WheelChairOnSTFPage;

	@FindBy(xpath="//ipas-service-tracker-details[1]//table[1]/tr[1]/td[1]/div[1]/div[3]/div[1]/span[1]")
	private WebElement txt_TrackingHistory;

	@FindBy(xpath="//ejs-grid[1]/div[3]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/div/span")
	private WebElement txt_StatusInGrid;

	@FindBy(xpath ="//ipas-service-tracker-details[1]//div[2]/div[1]/span[2]/span[1]")
	private WebElement txt_STFPageStatus;

	@FindBy(xpath="//ipas-breadcrumb[1]/div[1]/span[1]/a[1]")
	private WebElement lnk_STrackerLink;

	@FindBy(xpath ="//div[@class='st modal-dialog modal-xl']//div[@class='st modal-header']/button")
	private WebElement btn_STFPageMWindowClose;

	@FindBy(xpath = "//div[@class='dashboard-wrapper']/div/div/div")
	private WebElement lbl_DashboardWrapper;

	@FindBy(xpath = "//a[contains(text(),'Account Search')]")
	private WebElement lnk_AccounSearch;

	@FindBy(xpath = "//span[contains(text(),'Results:')]")
	private WebElement txt_AcctSrch_Result;

	@FindBy(xpath = "//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_Search;
	
	@FindBy(xpath = "//div/div/div/div[2]/span[4]")
	private WebElement txt_ServiceDepartmentOnCard;

	@FindBy(xpath = "//div/div/div/div[2]/span[5]")
	private WebElement txt_RegistrarOnCard;

	@FindBy(xpath = "//div/div/div/div[2]/span[6]")
	private WebElement txt_Destination;

	@FindBy(xpath = "//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']")
	private List<WebElement> li_DefaultGridStatusNames;

	/*@FindBy(xpath="//ul[@id='searchcomp_options']/li")
    private WebElement li_Search;*/
	
	@FindBy(xpath="//li[@id='p-highlighted-option']")
    private WebElement li_Search;
	
	@FindBy(xpath="//div[@id='three']//app-ipas-document-management-pannel//ejs-accordion/div/div[2]/div/div/ul/li/div[1]")
	private List<WebElement> lbl_DigitalDocMangerPanel;
	
	@FindBy(xpath="//ejs-accordion/div[1]/div[2]/div/div/ul/li/div[2]")
	private WebElement lbl_DataInAllDataPanel;
	
	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[2]")
	private List<WebElement> lbl_VisitSummaryData;
	
	@FindBy(xpath="//ipas-payment-facilitator-pannel/ejs-accordion/div/div[2]/div")
	private WebElement lbl_NoPayments;
	
	@FindBy(xpath="//ipas-payment-facilitator-pannel/ejs-accordion/div")
	private WebElement tbl_PaymentFacilitatorPanel;
	
	public STFullPagePage() {
		PageFactory.initElements(driver, this);
	}

	public void navigateToSTFullPageFromSTPage(String visitID) throws Exception{
		try{Thread.sleep(5000);
			vsrvcPanel.clickVisitID(visitID);
			webActions.waitForPageLoaded();		
			webActions.waitForVisibilityOfAllElements(lbl_DigitalDocMangerPanel, "DigitalDocs");		
			report.reportInfo("Navigated to the Patient Visit Summary page");			
			webActions.waitForVisibilityOfAllElements(lbl_DataInAllDataPanel, "DataInAllData");
			webActions.waitForVisibilityOfAllElements(lbl_VisitSummaryData, "SummaryData");
			webActions.waitForVisibility(lnk_STPanel,"service tracker Panel",2);
			report.reportInfo("service tracker Panel displayed");
			webActions.waitForPageLoaded();
			webActions.clickBYJS(lnk_STPanel, "service tracker full page");			
			report.reportPass("Clicked on Service Tracker Panel to navigate to Service Tracker Full Page");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_STFullPage, "FullPage Header",30);			
			webActions.waitForVisibility(img_ThreeDots, "Three Dots",20);
			report.reportInfo("Three Dots is displayed on the Service Tracker FullPage");
			webActions.waitForVisibility(txt_TrackingHistory, "Tracking History",30);		
			String stfpText = webActions.getText(lbl_STFullPage, "FullPage Header");
			report.reportInfo("Actual Text Service Tracker FullPage Header is :"+stfpText);
			if(stfpText.contentEquals("Service Tracker")){
				report.reportPass("Successfully navigated to Service Tracker Full Page");
			}else{
				throw new Exception("Failed to navigate to Service Tracker Full Page");
			}		
		}catch(Exception e){
			webActions.waitUntilPresentAndDisplayed(lbl_STFullPage, "FullPage Header");
			webActions.waitUntilPresentAndDisplayed(img_ThreeDots, "Three Dots");
			webActions.waitForVisibility(txt_TrackingHistory, "Tracking History",10);
			report.reportFail(e.getMessage());
		}
	}

	public void verifyDbfrSDInSTFPage() throws Exception{
		try{
			webActions.waitForVisibility(lbl_STFPData, "STFP Data");
			report.reportInfo("Service Tracker Full Page Data is dispalyed");
			String data = webActions.getText(lbl_STFPData, "Data");
			report.reportInfo("Data is :"+data);
			String[] data1 = data.split(":");
			data=data1[0];
			if(data.contentEquals("D")){
				report.reportPass("D is displayed before Service Department Name in Service Tracker Full Page");
			}else{
				throw new Exception ("Failed to read D before Service Department Name in Service Tracker Full Page");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public ArrayList<String> readSrvcDepartmentDestinationRegistrarOnCard() throws Exception{
		ArrayList<String> data = new ArrayList<>();
		List<WebElement> patientDetails = driver.findElements(By.xpath("//div/div/div/div[2]/span"));
		report.reportPass("List of all Elements are :"+patientDetails.size()+" values are :"+patientDetails);
		for(int expData =1;expData<=patientDetails.size();expData++){
			if(expData==4){
				String xpath1 = "//div/div/div/div[2]/span[";
				String xpath2 ="]";
				String xpath3 =xpath1+expData+xpath2;
				WebElement valuesss = driver.findElement(By.xpath(xpath3));
				String txt = webActions.getText(valuesss, "elements");
				String[] text =txt.split(":\\s");
				txt = text[1];
				data.add(txt);
			}			
			else if(expData==5||expData==6){
				String xpath1 = "//div/div/div/div[2]/span[";
				String xpath2 ="]";
				String xpath3 =xpath1+expData+xpath2;
				WebElement valuesss = driver.findElement(By.xpath(xpath3));
				String txt = webActions.getText(valuesss, "elements");
				String[] text =txt.split(",");
				txt =text[1].trim();		
				data.add(txt);
			}
		}return data;
	}

	public ArrayList<String> readDataOnSTFPage() throws Exception{
		webActions.waitForVisibility(lbl_STFPData, "Data");
		String data = webActions.getText(lbl_STFPData, "Data");
		String[] data1 = data.split(":");
		data=data1[1];
		ArrayList<String> expectedListData=new ArrayList<String> (Arrays.asList(data.split("\\s*,\\s*")));
		report.reportPass("Data on Patient Visit Main page is  :"+expectedListData);		    	
		return  expectedListData;
	}

	public void compareDataonVisitCardAndSTFPage(ArrayList<String> actList, ArrayList<String> expList) {
		try{
			ArrayList<String> unmatched = webActions.getUmatchedInArrayComparision(actList,expList);
			if(unmatched.size()==0){
				report.reportPass("Service Department, Destination and Registrar values are dispayed successfully");
			}else{
				throw new Exception("Fail to verify Service Department, Destination and Registrar Names:"+unmatched);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifySTPageHighlighted() throws Exception{
		try{
			webActions.assertDisplayed(lnk_ServiceTracker, "Service Tracker");
			report.reportInfo("Service Tracker link is displayed");
			String actText=webActions.getAttributeValue(lnk_ServiceTracker, "class", "Service Tracker");
			if(actText.contentEquals("nav-link active")){
				report.reportPass("Service Tracker link is highlighted");
			}else{
				report.reportInfo("Failed to read Service Tracker highlighted");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyASPageHighlighted() throws Exception{
		try{
			webActions.assertDisplayed(lnk_AccountSearch, "Service Tracker");
			report.reportInfo("Account Search link is displayed");
			String actText=webActions.getAttributeValue(lnk_AccountSearch, "class", "Account Search");
			if(actText.contentEquals("nav-link active")){
				report.reportPass("AccountSearch link is highlighted");
			}else{
				report.reportInfo("Failed to read Account Search highlighted");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void clickOnAccountLinkNumber() throws Exception{
		try {	
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txt_AcctSrch_Result, "Results");
			report.reportInfo("Results text is displayed");
			String accountNumber=webActions.getText(lnk_AccountNumber, "Account Number");
			report.reportInfo("Account Number is: "+accountNumber);
			webActions.clickBYJS(lnk_AccountNumber, "Account Number");
			report.reportInfo("Navigated to the Patient Visit Summary page");
			webActions.waitUntilisDisplayed(lbl_AllPanels, "AllPanels");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	public void getVisitNumFrmResponseAndClickOnAccountNumber(String responseValue) throws Exception{
		try {
			String visitIdvalue = logIn.getVisitIdFromResponse(responseValue);
			srchAccountNumberinAccountSearchPage(visitIdvalue);
		} catch (Exception e) {

		}
	}

	public void srchAccountNumberinAccountSearchPage(String accountNumber) throws Exception{
        try {
            webActions.waitForVisibility(txt_AcctSrch_Result, "Account Search Headers");
            webActions.sendKeys(txt_Search, accountNumber, "VisitID");
            webActions.waitForPageLoaded();
            webActions.waitForJSandJQueryToLoad();
            webActions.waitForPageLoaded();
            webActions.waitForClickAbility(li_Search, "");
            webActions.waitForPageLoaded();
            webActions.waitForJSandJQueryToLoad();
            webActions.click(li_Search, "");
            webActions.waitForPageLoaded();
            webActions.waitForJSandJQueryToLoad();
            webActions.waitForPageLoaded();
            webActions.waitForVisibility(txt_AcctSrch_Result,"Account Search Headers");
            webActions.waitForPageLoaded();
            driver.findElement(By.partialLinkText(accountNumber)).click();
            webActions.waitForPageLoaded();
           // webActions.waitForJSandJQueryToLoad();
            webActions.waitForVisibility(tbl_AllData, "All Data Page",30);
            webActions.waitForPageLoaded();
        } catch (Exception e) {
            throw new Exception(e);
        }
    }
	
	
	
	public void simpleSearch(String value){
        try{
            webActions.waitUntilPresentAndDisplayed(txt_SimpleSearch, "Simple search");
            webActions.waitForVisibility(txt_AcctSrch_Result, "gridResults");
            webActions.sendKeys(txt_SimpleSearch, value, "Visit id");
            //webActions.keyBoardEnter(txt_SimpleSearch,"Simple search");
            webActions.waitForPageLoaded();
            webActions.waitForJSandJQueryToLoad();
            webActions.waitForPageLoaded();
            webActions.waitUntilisDisplayed(li_SimpleSeacrh, "Simple search");
            webActions.waitForPageLoaded();
            Thread.sleep(5000);
            webActions.waitForPageLoaded();
            webActions.click(li_SimpleSeacrh, "SimpleSearchAutoPopulate");
            webActions.waitForPageLoaded();
            webActions.waitForJSandJQueryToLoad();
            webActions.waitForPageLoaded();
            webActions.waitForVisibility(txt_AcctSrch_Result, "gridResults");
        }catch(Exception e){
        }
    }
	
	
	public void verifyDisplayedBreadcrumbFollowedbyAllData(String visitId,String pageName,String menuName) throws Exception{
		String accountNumber = updateVisit.getVisitIdFromResponse(visitId);
		ArrayList<String> expectedBreadcrumbTitles=new ArrayList<String>();
		expectedBreadcrumbTitles.add(pageName);
		expectedBreadcrumbTitles.add(accountNumber);
		expectedBreadcrumbTitles.add(menuName);
		report.reportInfo("Expected Breadcrumb Titles "+expectedBreadcrumbTitles);
		ArrayList<String> actualBreadcrumbTitles = new ArrayList<String>();

		if ("Account Search".contentEquals(pageName)) {
			srchAccountNumberinAccountSearchPage(accountNumber);;
			//summaryPage.clickOnAccountLinkNumber();
			webActions.waitAndClick(lbl_AllDataPanelTitle, "AllData");
			actualBreadcrumbTitles = webActions.getDatafromWebTable(lbl_AllDataFullPage);
		}else if("Service Tracker".contentEquals(pageName)){
			searchAccountNumberinServiceTracker(accountNumber);
			webActions.waitAndClick(lbl_AllDataPanelTitle, "AllData");
			actualBreadcrumbTitles = webActions.getDatafromWebTable(lbl_AllDataFullPage);
		}
		report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumbTitles);
		ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumbTitles, expectedBreadcrumbTitles);
		if(unmatch.size()==0){
			report.reportPass("AllData Page Breadcrumb Titles verified successfully, when user navigate from: "+pageName);
		}else{
			report.reportFail("Failed to verify the AllData Page Breadcrumb Titles, when user navigate from: "+pageName+" : and unmatched data: "+unmatch);
		}
	}

	public void searchAccountNumberinServiceTracker(String AccountNumber) throws Exception{
		try {
			webActions.waitForVisibility(lbl_Headers_ServiceTracker, "Service Tracker Headers",2);
			webActions.enterValuesfromKeyBoard(txt_Search_ServiceTracker, AccountNumber, "");
			Thread.sleep(2000);
			driver.findElement(By.linkText(AccountNumber)).click();
			report.reportInfo("Clicked on Account number");
		} catch (Exception e) {
			throw new Exception(e);
		}
	}

	public String getIntakeStatusFromModelWindow() throws Exception {
		String prsntStatus= null;
		try{
			webActions.waitForVisibility(drpdwn_IntakeStatus, "Intake Status Drop Down");
			report.reportPass("Intake Status drop down is displayed");
			webActions.waitForPageLoaded();
			prsntStatus= webActions.getAttributeValue(drpvalue_IntakeStatus, "aria-label", "dropdown");
			webActions.click(btn_MWindowClose, "X Buton");
			report.reportPass("Clicked on X button in Model Window");
			webActions.waitForPageLoaded();
		}catch(Exception e){
			report.reportFail(e.getMessage());
		} return prsntStatus;
	}

	public String getStatusOnSTFPage() throws Exception{
		String stfpStatus = null;
		try{
			stfpStatus =webActions.getText(txt_StatusOnSTFPage, "STFP Status");
			report.reportInfo("Status on Service Tracker Full Page is :"+stfpStatus);
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}return stfpStatus;
	}

	public void compareStatus() throws Exception{
		try{
			String visitID= updateVisit.getValuefromJSONresponseBasedOnObject();
			updateVisit.simpleSearch(visitID);
			updateVisit.openModelWindow(visitID);
			String actStatus = getIntakeStatusFromModelWindow();
			navigateToSTFullPageFromSTPage(visitID);
			String expStatus = getStatusOnSTFPage();
			if(actStatus.contentEquals(expStatus)){
				report.reportPass("Status is matched");
			}else{
				throw new Exception("Unable to Compare Status on Visit Card and Service Tracker Full Page");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyTitleModuleStatusonSTFPage() throws Exception{
		try{
			webActions.isDisplayed(lbl_STFullPage, "Service Tracker");
			report.reportPass("Service Tracker Lable is displayed");
			webActions.isDisplayed(img_FinancialClearance, "Module Status");
			report.reportPass("Module Status is displayed properly");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}


	public void priorityNotDisplayedOnSTFPage() throws Exception{
		try{
			webActions.isDisplayed(img_STFPagePriority, "Priority");
			report.reportFail("Priority is displayed on visit card");
		}catch(Exception e){
			report.reportPass("Priority icon is not displayed on the visit card");
		}
	}

	public void priorityDisplayedOnSTFPage() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(img_STFPagePriority, "Priority",25);
			if(webActions.isDisplayed(img_STFPagePriority, "Priority")){
				report.reportPass("Priority icon is displayed on the visit card");
			}else{
				throw new Exception("Failed to identify Priority on visit card");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}


	public void openModelWindowOnSTFPage() throws Exception {
		try{
			webActions.isDisplayed(img_ThreeDots, "Three Dots");
			report.reportInfo("Model window is displayed on Service Tracker Full Page");
			webActions.clickBYJS(img_ThreeDots, "Three Dots");
			report.reportPass("Clicked on Model Window");
			String visitid = webActions.getText(lbl_VisitID, "STFPage VisitID");
			webActions.waitForPageLoaded();
			Thread.sleep(2000);
			report.reportPass("Visit ID on STFPage is :"+visitid);
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void wheelChairNotDisplayedOnSTFPage() throws Exception{		
		try{
			webActions.waitForVisibility(img_WheelChairOnSTFPage, "WheelChair Icon",25);
			webActions.isDisplayed(img_WheelChairOnSTFPage, "WheelChair Icon");
			report.reportFail("Wheel Chair is displayed");
		}catch(Exception e){
			report.reportPass("Wheel Chair is not displayed");
		}		
	}

	public void verifyTrackingHistoryTextOnSTFullPage() throws Exception{
		try{
			webActions.waitForVisibility(txt_TrackingHistory, "THistory Text",25);
			String actText = webActions.getText(txt_TrackingHistory, "THistory Text");
			if(actText.trim().contains("Tracking History")){
				report.reportPass("Tracking History Text is displayed properly");
			}else{
				throw new Exception("Failed to read Tracking History Text");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void clickOnServiceTrackerBreadCrumb() throws Exception{
		try{
			webActions.clickBYJS(lnk_STrackerLink, "ServiceTracker");
			report.reportPass("Clicked on Service Tracker link to navigate to ServiceTracker Page");
			webActions.waitForPageLoaded();
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyStatusInGrid() throws Exception{
		try{
			String visitID= updateVisit.getValuefromJSONresponseBasedOnObject();
			updateVisit.simpleSearch(visitID);
			updateVisit.openModelWindow(visitID);
			String actStatus = getIntakeStatusFromModelWindow();
			navigateToSTFullPageFromSTPage(visitID);
			String expStatus = webActions.getText(txt_STFPageStatus, "Status InGrid");
			if(actStatus.contentEquals(expStatus)){
				report.reportPass("Status is matched");
			}else{
				throw new Exception("Unable to Compare Status on Visit Card and Service Tracker Full Page");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void closeModelWindowOnSTFPage() throws Exception{
		try{	
			webActions.waitForPageLoaded();
			webActions.assertDisplayed(btn_STFPageMWindowClose, "Close Button");
			report.reportInfo("Close button is displayed");
			webActions.waitForClickAbilityAndClick(btn_STFPageMWindowClose, "X Buton");
			report.reportPass("Clicked on X button in Model Window");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void navigateToAccountSearchPage(){
		try {
			webActions.waitForPageLoaded();	
			webActions.waitForVisibility(lnk_AccounSearch, "AccountSearch",15);
			webActions.click(lnk_AccounSearch, "AccountSearch");
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibility(txt_AcctSrch_Result, "Results");
			} catch (Exception e) {
				webActions.waitForVisibility(txt_AcctSrch_Result, "Results");
			}
			report.reportPass("Clicked on Account Search link and navigated to the Account Search Page Successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());	
		}
	}

	public STFullPagePage openIpasApp() {
		try {
			String URL = TestBase.prop.ipasURL();
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to Open iPAS application");
		}
		return (STFullPagePage) base(STFullPagePage.class);
	}

	public void navigateToSTFullPageFromPanel() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lnk_STPanel,"service tracker");
			report.reportInfo("service tracker Panel displayed");
			webActions.clickBYJS(lnk_STPanel, "service tracker Panel");
			report.reportPass("Service Tracker Panel is clicked");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_STFullPage, "FullPage Header",10);
			String stfpText = webActions.getText(lbl_STFullPage, "FullPage Header");
			if(stfpText.contentEquals("Service Tracker")){
				report.reportPass("Successfully navigated to Service Tracker Full Page");
			}else{
				throw new Exception("Failed to navigate to Service Tracker Full Page");
			}		
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void pageRefresh() throws Exception{
		try{
			webActions.refreshPage();
			webActions.waitForPageLoaded();
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyComma() throws Exception{
		try{
			webActions.waitForPageLoaded();
			String txtDestination= webActions.getText(txt_RegistrarOnCard, "Registrar");
			report.reportInfo("service department text is :"+txtDestination);
			String txtRegsistrar = webActions.getText(txt_RegistrarOnCard, "Registrar");
			report.reportInfo("registrar text is :"+txtRegsistrar);
			if(txtDestination.startsWith(",")&&txtRegsistrar.startsWith(",")){
				report.reportPass("Comma is displayed after Service Department name and Registrar Name");
			}else{
				throw new Exception("Comma is not displayed");
			}			
		}catch(Exception e){
			report.reportFail("Failed to read Comma after Service Department Name");
		}
	}
	public void waitforPaymentFacilitatorPanel() throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(lbl_NoPayments, "No Payments Error Message");
		} catch (Exception e) {
			webActions.waitForVisibility(tbl_PaymentFacilitatorPanel, "Payment Facilitator Panel");
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_UserName);
	}

}
