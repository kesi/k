package com.ipas.hf.web.steps;
import java.util.List;

import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.PatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.SimpleSearchPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;
import net.sourceforge.htmlunit.corejs.javascript.regexp.SubString;
public class PatientVisitCardSteps {
	
	Login logIn = new Login();
	HomePage home = new HomePage();
	SimpleSearchPage search=new SimpleSearchPage();
	PatientVisitPage visit=new PatientVisitPage();
	
//	@Then("Get the value from response body and get value of {string}")
//	public void get_the_value_from_response_body_and_get_value_of(String patientId) {
//		search.visitIdvalue = logIn.getVisitIdFromResponse(patientId);
//	}
	
	@Then("Validate the service tracker board")
	public void validate_service_tracker_board() throws Exception {
	
		visit.serviceTrackerPageValidation();
	}
	
//	@Then("Validate service tracker filters and default columns")
//	public void Validate_service_tracker_filters_and_default_columns(DataTable columnNames) throws Exception {
//    
//		visit.verifyDefaultFilters("iPAS");
//		visit.defaultColumnName1(columnNames);
//	}
	
	
	@Then("Validate the Patient visit card status count against each status column")
	public void Validate_the_Patient_visit_card_status_count_against_each_status_column(DataTable statusNames) throws Exception {
	    
		visit.verifystatusCardCount(statusNames);
	}
	
	
	
	
	
}
