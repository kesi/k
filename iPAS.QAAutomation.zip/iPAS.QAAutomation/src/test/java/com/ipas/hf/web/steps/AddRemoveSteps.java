package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.AddRemovePage;
import com.ipas.hf.web.pages.ipasPages.HomePage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class AddRemoveSteps {

	AddRemovePage columns=new AddRemovePage();
	HomePage homePage=new HomePage();
	boolean flag=false;

	@Then("Verify the display of Columns button on the top right side of Account serach page")
	public void verify_the_display_of_Columns_button_on_the_top_right_side_of_Account_serach_page() {
		columns.verifyfields();  
	}
	@Then("Click on Column button and verify the display of column names list")
	public void click_on_Column_button_and_verify_the_display_of_column_names_list(DataTable columnNames) {
		columns.verifyColumnNames(columnNames);
	}
	@Then("Click on Column button and verify title {string} from column list")
	public void click_on_Column_button_and_verify_title_from_column_list(String ColumnsTitle) {
		columns.verifyColumnListTitle(ColumnsTitle);
	}
	@Then("Click on columns button and verify the default selected fields as {string}")
	public void click_on_columns_button_and_verify_the_default_selected_fields(String fieldMode,DataTable columnNames) throws Exception {
		columns.columnSelection(fieldMode,columnNames);

	}
	@Then("Verify the default display search results grid header columns")
	public void verify_the_default_display_search_results_grid_header_columns(DataTable columnNames) {
		columns.verifyDefaultColumnNames(columnNames);
	}
	@Then("Select the field as {string}  and verify the display of search results grid column names")
	public void select_the_field_as_and_verify_the_display_of_search_results_grid_column_names(String fieldName,DataTable columnNames) {
		columns.verifyGridHeaderColumnNames(fieldName, columnNames);
	}
	@Then("Click on columns button and verify the default unSelected fields as {string}")
	public void ckick_on_columns_button_and_verify_the_default_unSelected_fields(String fieldMode,DataTable columnNames) throws Exception {
		columns.columnSelection(fieldMode,columnNames);
	}
	@Then("Unselect the colums fields from column list and verify the result grid header name as {string}")
	public void unselect_the_colums_fields_from_column_list_and_verify_the_result_grid_header_name_as(String headerName,DataTable columnNames) {
		columns.clickFieldsFromColumnList(headerName, columnNames);
	}
	@Then("Click on columns button and veify the follwing fields under patient column")
	public void click_on_columns_button_and_veify_the_follwing_fields_under_patient_column(DataTable fields) {
		columns.verifyColumnFieldsSelection(fields);
	}
	@Then("Click on column button and select the field as {string}")
	public void click_on_column_button_and_select_the_field_as(String colunmnName) {
		columns.selectColumn(colunmnName);
	}
	@Then("Get the value of {string} from reponse body and verify with result gird display value in Column as {string} and field value as {string}")
	public void get_the_value_of_from_reponse_body_and_verify_with_result_gird_display_value_in_Column_as_and_field_value_as(String responseValue, String columnName, String fieldName) throws Exception {
		columns.verifyDatainColumnBySelectingFieldFromColumns(responseValue, columnName, fieldName);
	}
	@Then("Get the value from response body and verify with result gird display value in Column as {string} and field value as {string}")
	public void get_the_value_from_response_body_and_verify_with_result_gird_display_value_in_Column_as_and_field_value_as(String columnName, String fieldName) throws Exception{
		columns.verifyDatainColumnBySelectingFieldFromColumn(columnName, fieldName);
	}
	@Then("Get the value from response body and verify with result gird display value in Column as {string} and field value as {string} and Mobile Number type code as {string}")
	public void get_the_value_from_response_body_and_verify_with_result_gird_display_value_in_Column_as_and_field_value_as_and_Mobile_Number_type_code_as(String columnName, String fieldName, String phoneType) throws Exception {
		columns.verifyPhoneNumberBySelectingFieldFromColumn(columnName, fieldName,phoneType);
	}
	@Then("Navigate to other page as {string} and back to Account search page")
	public void navigate_to_other_page_as_and_back_to_Account_search_page(String pageName) {
		columns.navigateAndBackToAccountSearch(pageName);
	}
	@Then("Navigate to the Account Search page")
	public void navigate_to_the_Account_Search_page() {
		homePage.navigateToAccountSearch();		
	}

	@Then("Verify the result Grid Header Names")
	public void verify_the_result_Grid_Header_Names(DataTable headerNames) {
		columns.verifyHeaderNames(headerNames);
	}
}	