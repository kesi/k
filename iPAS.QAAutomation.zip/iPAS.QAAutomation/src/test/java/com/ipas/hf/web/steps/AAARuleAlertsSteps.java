package com.ipas.hf.web.steps;



import org.json.simple.parser.ParseException;

import com.ipas.hf.web.pages.ipasPages.AAARuleAlertsPage;
import com.ipas.hf.web.pages.ipasPages.PaymentFacilitatorPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class AAARuleAlertsSteps {
	
	AAARuleAlertsPage aaaRuleAlert=new AAARuleAlertsPage();
	

	@Then("Update Patient Identifier in AAA Rule Alerts JSON")
	public void update_Patient_Identifier_in_AAA_Rule_Alerts_JSON() throws ParseException {
		aaaRuleAlert.updateAAARuleAlertJSON();
	}

	@Then("Update Patient data in JSON field name {string} and value as {string}")
	public void update_Patient_data_in_JSON_field_name_and_value_as(String fieldName, String fieldValue) throws ParseException {
		aaaRuleAlert.updatePatientData(fieldName, fieldValue);
	}
	
	@Then("Verify the list of Alerts in All Alerts section")
	public void verify_the_list_of_Alerts_in_All_Alerts_section(DataTable testData) {
		aaaRuleAlert.verifyAllRuleAlerts(testData);
	}
	
	@Then("Verify the list of Alerts in All Alerts section if receive same visit account with updated patient data")
	public void verify_the_list_of_Alerts_in_All_Alerts_section_if_receive_same_visit_account_with_updated_patient_data(DataTable testData) {
		aaaRuleAlert.verifyAllRuleAlertsforUpdatedVisitAccount(testData);
	}
	
	@Then("Click on alert name {string}")
	public void click_on_alert_name(String alertName) {
		aaaRuleAlert.clickOnChallengeButton(alertName);
	}
	
	@Then("Click on Challenge button for {string} Rule alert")
	public void click_on_Challenge_button_for_Rule_alert(String alertName) {
		aaaRuleAlert.clickOnChallengeButton(alertName);
	}

	
	@Then("Verify mandatory field validation message {string} and Cancel button functionality")
	public void verify_mandatory_field_validation_message_and_Cancel_button_functionality(String errorMessage) {
		aaaRuleAlert.verifyValidationsOnChallengeAlertWindow(errorMessage);
	}
	
	@Then("Verify the Challenge Alert functionality")
	public void verify_the_Challenge_Alert_functionality(DataTable testData) {
		aaaRuleAlert.challengeAlert(testData);
	}
	
	@Then("Click on rule alert name link {string}")
	public void click_on_rule_alert_name_link(String expAlertName) {
		aaaRuleAlert.clickOnRuleAlertLink(expAlertName);
	}

	@Then("Verify the rule alert information data")
	public void verify_the_rule_alert_information_data(DataTable testData) {
		aaaRuleAlert.verifyRuleAlertInformationData(testData);
	}
	
	@Then("Logout from the Application")
	public void logout_from_the_Application() {
		aaaRuleAlert.logout();
	}
	
	@Then("Verify Review Challenge button")
	public void verify_Review_Challenge_button() {
		aaaRuleAlert.verifyReviewChallengeButton();
	}
	
	@Then("Click on Review Challenge button for {string} rule alert")
	public void click_on_Review_Challenge_button_for_rule_alert(String expAlertName) {
		aaaRuleAlert.clickOnReviewChallenge(expAlertName);
	}
	
	@Then("Verify the Challenge data and mandatory field validation {string} and close the window")
	public void verify_the_Challenge_data_and_mandatory_field_validation_and_close_the_window(String expError, DataTable testData) {
		aaaRuleAlert.verifyChallengeDataMandatoryFieldValidationAndCloseWindow(expError, testData);
	}
	
	@Then("Verify the {string} functionality on Review Challenge Alert")
	public void verify_the_functionality_on_Review_Challenge_Alert(String reviewType,DataTable testData) {
		aaaRuleAlert.reviewChallenge(reviewType,testData);
	}

	@Then("Verify the Alert status as {string} for Employee after challenge was {string}")
	public void verify_the_Alert_status_as_for_Employee_after_challenge_was(String expStatus, String reviewType) {
		aaaRuleAlert.verifyAlertStausAfterReviewChallenge(expStatus, reviewType);
	}
	
	@Then("Verify the list of Alerts in Worklists")
	public void verify_the_list_of_Alerts_in_Worklists(DataTable testData) {
		aaaRuleAlert.verifyRuleAlertsinWorklists(testData);
	}
	
	@Then("Verify the Challenged alerts")
	public void verify_the_Challenged_alerts(DataTable testData) {
		aaaRuleAlert.verifyChallengedAlert(testData);
	}
	
	@Then("Verify the Challenged alert in Accuracy & Accountability")
	public void verify_the_Challenged_alert_in_Accuracy_Accountability() {
		aaaRuleAlert.verifyChallengedAlertinAccuracyAccountabilityTab();
	}
	
	@Then("Verify Rejected Rule Alert in Accuracy & Accountability Tab")
	public void verify_Rejected_Rule_Alert_in_Accuracy_Accountability_Tab() {
		aaaRuleAlert.verifyRejectedRuleAlertsinAccuracyAccountabilityTab();
	}

	@Then("Verify Rejected Rule Alert in Challenged Tab {string}")
	public void verify_Rejected_Rule_Alert_in_Challenged_Tab(String expMessage) {
		aaaRuleAlert.verifyRejectedRuleAlertinChallengedTab(expMessage);
	}

	@Then("Update EmployeeID for {string} and EmployeeId is {string} in AAA Rule Alerts JSON")
	public void update_EmployeeID_for_and_EmployeeId_is_in_AAA_Rule_Alerts_JSON(String employeeName, String employeeId) throws Exception {
		aaaRuleAlert.updateEmployeeId(employeeName,employeeId);
	}
	
	@Then("Verify the {string} functionality on Review Challenge Alert when having multiple challenges")
	public void verify_the_functionality_on_Review_Challenge_Alert_when_having_multiple_challenges(String reviewType,DataTable testData) {
		aaaRuleAlert.reviewChallengeForMultipleUsers(reviewType,testData);
	}
	
	@Then("Verify the {string} functionality on Second Review Challenge Alert when having multiple challenges")
	public void verify_the_functionality_on_Second_Review_Challenge_Alert_when_having_multiple_challenges(String reviewType,DataTable testData) {
		aaaRuleAlert.reviewSecondChallengeForMultipleUsers(reviewType, testData);
	}

	@Then("Verify the display of Rule Data Elements in Red on All Pages")
	public void verify_the_display_of_Rule_Data_Elements_in_Red_on_All_Pages() {
		aaaRuleAlert.verifyAllDataElementsInRed();
	}
	
	@Then("Verify the Challenge Alert functionality for Supervisor")
	public void verify_the_Challenge_Alert_functionality_for_Supervisor(DataTable testData) {
		aaaRuleAlert.challengeAlertforSupervisor(testData);
	}
	
	@Then("Click Review Challenge button")
	public void click_Review_Challenge_button() {
		aaaRuleAlert.clickReviewChallengeButton();
	}

	@Then("Verify the Rule Alerts in Worklists page for Supervisor {string} and {string}")
	public void verify_the_Rule_Alerts_in_Worklists_page_for_Supervisor_and(String supervisor, String employee) {
		aaaRuleAlert.verifyWorkListForSupervisor(supervisor, employee);
	}
	
	@Then("Update Guarantor Address {string} in AAA Rule Alerts JSON")
	public void update_Guarantor_Address_in_AAA_Rule_Alerts_JSON(String address) throws ParseException {
		aaaRuleAlert.updateGuarantorData(address);
	}
	@Then("Verify AAA Rule Alerts when receive same visit account with updated patient data")
	public void verify_AAA_Rule_Alerts_when_receive_same_visit_account_with_updated_patient_data(DataTable testData) {
	    aaaRuleAlert.verifyAllRuleAlertsWhenPatientVisitDataUpdated(testData);
	}
	
	@Then("Verify AAA Rule Alerts when receive new patient visit")
	public void verify_AAA_Rule_Alerts_when_receive_new_patient_visit(DataTable testData) {
		aaaRuleAlert.verifyRuleAlertForNewPatientVisit(testData);
	}

}
