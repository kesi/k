package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.AddNotesPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class AddNotesSteps {
	AddNotesPage addNotesPage = new AddNotesPage();

	@Then("Verify Notes button is displayed in More options window")
	public void verify_Notes_button_is_displayed_in_More_options_window() throws Exception {
		addNotesPage.verifyNotesTab();
	}

	@Then("Verify Notes, Operator and Notes Date Columns names in Notes PopUp")
	public void verify_Notes_Operator_and_Notes_Date_Columns_names_in_Notes_PopUp(DataTable expColumnNames) throws Exception {
		addNotesPage.verifyColumnsNamesInNotesWindow(expColumnNames);
	}

	@Then("Verify Add Note button on Notes PopUp Window is in disabled mode")
	public void verify_Add_Note_button_on_Notes_PopUp_Window_is_in_disabled_mode() throws Exception {
		addNotesPage.verifyAddNotesButtonInDisabledMode();
	}

	@Then("Verify Close button in Notes PopUp Window")
	public void verify_Close_button_in_Notes_PopUp_Window() throws Exception {
		addNotesPage.verifyCloseButtonInNotesWindow();
	}

	@Then("Verify the display of help text in Notes Window as {string}")
	public void verify_the_display_of_help_text_in_Notes_Window_as(String actText) throws Exception {
		addNotesPage.verifyMaxLengthMessageInNotesWindow(actText);
	}

	@Then("Create Notes with Data as {string}")
	public void create_Notes_with_Data_as(String data) throws Exception {
		addNotesPage.createNotes(data);
	}

	@Then("Verify the display of Help Text in Notes Window as {string}")
	public void verify_the_display_of_Help_Text_in_Notes_Window_as(String data) throws Exception {
		addNotesPage.verifyMaxLengthMsg(data);
	}

	@Then("Verify the display of Min length help text in Notes Window as {string}")
	public void verify_the_display_of_Min_length_help_text_in_Notes_Window_as(String data) throws Exception {
		addNotesPage.verifyMinxLengthMsg(data);
	}
	
	
	@Then("Verify the Data in Notes Window Grid")
	public void verify_the_Data_in_Notes_Window_Grid(DataTable data) throws Exception {
		addNotesPage.verifyCreatedNotesData(data);
	}

	@Then("Verify Add Note button on Notes PopUp Window is in enabled mode")
	public void verify_Add_Note_button_on_Notes_PopUp_Window_is_in_enabled_mode() throws Exception {
		addNotesPage.verifyAddNotesButtonInEnabledMode();
	}


	@Then("Verify the display of success message as {string} and confirmation as {string} after creating notes as {string}")
	public void verify_the_display_of_success_message_as_and_confirmation_as_after_creating_notes_as(String successMsgText, String conMsg, String notesData) throws Exception {
		addNotesPage.verifySuccessMsgAfterCreatingNotes(successMsgText,conMsg,notesData);
	}
	
	@Then("Verify user can enter all special characters")
	public void verify_use_can_enter_all_special_characters() throws Exception {
		addNotesPage.enterSpecialCharacters();
	}
	
	@Then("Close Notes Window by clicking on Close button")
	public void close_Notes_Window_by_clicking_on_Close_button() throws Exception {
		addNotesPage.closeNotesWindow();
	}
}
