package com.ipas.hf.web.steps;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.ipasPages.AddNewUserPage;
import com.ipas.hf.web.pages.ipasPages.EditUserPage;
import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class EditUserSteps{

	EditUserPage edituser = new EditUserPage();
	RestActions rest=new RestActions();


	@Then("Verify the Breadcrumb for Edit User page")
	public void verify_the_Breadcrumb_for_Edit_User_page(DataTable breadcrumb) {
		edituser.verifyBreadcrumbinEditUserPage(breadcrumb);
	}
	
	@Then("Verify the Heading for Edit User page")
	public void verify_the_Heading_for_Edit_User_page() {
		edituser.verifyEditUserHeading();
	}
	
	@Then("Verify the Sections for Edit User page")
	public void verify_the_Sections_for_Edit_User_page(DataTable sections) {
		edituser.verifytheSections(sections);
	}
	
	@Then("Verify the placeholders for Edit User page")
	public void verify_the_placeholders_for_Edit_User_page(DataTable placeholders) {
		edituser.verifythePlaceholdersforallFields(placeholders);
	}
	
	@Then("Verify the Cancel button functionality of Edit User")
	public void verify_the_Cancel_button_functionality_of_Edit_User() {
		edituser.verifyCancelButtonFunctionalityEditUser();
	}
	
	@Then("Verify the Operator ID and email fields are disabled")
	public void verify_the_OperatorID_and_email_fields_are_disabled() {
		edituser.verifytheFieldsDisabledEditUser();
	}
	
	@Then("Verify the mandatory fields displayed in edit user page")
	public void verify_the_mandatory_fields_displayed_in_edit_user(DataTable mandatoryFields) {
		edituser.verifyMandatoryFields(mandatoryFields);
	}
	
	@Then("Verify the Changes will be saved when user clicks the Submit button")
	public void Verify_the_Changes_will_be_saved_when_user_clicks_the_Submit_button() {
		edituser.verifyChangesSaved();
	}
	
	@Then("Verify the Changes will not be saved until user clicks the Submit button")
	public void Verify_the_Changes_will_not_be_saved_until_user_clicks_the_Submit_button() {
		edituser.verifyChangesNotSaved();
	}
	
	@Then("Verify the messages when user enter less than minimum character as {string}")
	public void Verify_the_messages_when_user_enter_less_than_minimum_character(String length,DataTable  validationMessages) {
		int len=Integer.parseInt(length);
		String testData=rest.randomString(len);
		edituser.verifyValidationMessageMinimumAndMaximum(length,testData,validationMessages);
	}
	
	@Then("Verify the messages if numerics entered in Text fields as {string}")
	public void Verify_the_validation_messages_if_numericss_entered_into_text_fields(String length,DataTable  validationMessages) {
		int len=Integer.parseInt(length); 
		String testData=rest.randomNumber(len);
		edituser.verifyMessageNumericsValidation(length,testData,validationMessages);
	}
	
}
