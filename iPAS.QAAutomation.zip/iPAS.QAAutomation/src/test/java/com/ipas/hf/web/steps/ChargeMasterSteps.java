package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.ChargeMasterPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class ChargeMasterSteps {
	ChargeMasterPage cmpage=new ChargeMasterPage();	

	@Then("Verify the display of panel information")
	public void verify_the_display_of_panel_information(DataTable testData) {
		cmpage.verifyPanelInfo(testData);
	}

	@Then("Verify the Breadcrumb for Add New line page")
	public void verify_the_Breadcrumb_for_Add_New_line_page(DataTable breadcrumb) {
		cmpage.verifyBreadCrumbAddNewLinePage(breadcrumb);
	}

	@Then("Verify the mandatory validations and Cancel  Button")
	public void verify_the_mandatory_validations_and_Cancel_Button(DataTable validationMessages) {
		cmpage.verifytheMandatoryFieldValidationsAndCancelButton(validationMessages);
	}
	@Then("Navigate to Add New Line Page")
	public void navigate_to_Add_New_Line_Page() {
		cmpage.goToAddChargeCodePage();
	}
	@Then("Verify the Addede charge code")
	public void verify_the_Addede_charge_code(DataTable testData) {
		cmpage.addChargeCode(testData);
	}

	@Then("Go to the Add New line page and add previously added charge code and verify message as {string}")
	public void go_to_the_Add_New_line_page_and_add_previously_added_charge_code_and_verify_message_as(String expmsg) {
		cmpage.verifyDuplicateChargeCode(expmsg);
	}
	@Then("Click on charge code and verify the charge code mode")
	public void click_on_charge_code_and_verify_the_charge_code_mode() {
		cmpage.verifyChargeCodeMode();
	}

	@Then("Update the department and charge amount and verify from grid")
	public void update_the_department_and_charge_amount_and_verify_from_grid(DataTable testData) {
		cmpage.editAndVerifyUpdatedDataFromGrid(testData);
	}
	@Then("Verify the price history")
	public void verify_the_price_history(DataTable testData) {
		cmpage.verifyPriceHistory(testData);
	}

}
