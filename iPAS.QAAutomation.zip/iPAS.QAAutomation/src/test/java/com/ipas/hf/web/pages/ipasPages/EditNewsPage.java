package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;
import com.jayway.jsonpath.internal.function.text.Concatenate;

import io.cucumber.datatable.DataTable;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.BasePage;

public class EditNewsPage  extends BasePage{
	
	@FindBy(linkText="News")
	private WebElement lnk_News;
	
	@FindBy(xpath="//td[@class='e-rowcell e-templatecell']/div/a[@class='titleLink boldtext']")
	private WebElement lst_titlelist;
	
	@FindBy(xpath="//span[text()='News List']")
	private WebElement txt_Newslist;
	
	@FindBy(xpath="//input[@aria-placeholder='Type News Title']")
	private WebElement txt_NewsSearch;
	
	@FindBy(xpath="//a[@class='titleLink boldtext']")
	private WebElement txt_NewsTitle;
	
	@FindBy(xpath="//input[@id='title']")
	private WebElement txt_EditNewsTitle;
	
	
	@FindBy(xpath="//span[text()='Edit News']")
	private WebElement txt_EditNews;
	
	@FindBy(xpath="//div[@class='headtitle']/span")
	private List<WebElement> lst_titleNames;
	
	@FindBy(xpath="//div[contains(text(),'Title is required.')]")
	private List<WebElement> lst_validationmsg;
	
	@FindBy(xpath="//div[@class='breadcrum-container']/span")
	private List<WebElement> lbl_Breadcrumb;
	
	@FindBy(xpath="//div[@class='headtitle']/span[contains(text(),'Content')]//following::label[1]")
	private WebElement txt_ContentNewTitle;
	
	@FindBy(xpath="//div[@class='headtitle']/span[contains(text(),'Content')]//following::label[2]")
	private WebElement txt_ContentNewText;
	
	@FindBy(xpath="//div[@class='headtitle']/span[contains(text(),'Settings')]/..//following::label[@for]")
	private List<WebElement> lst_Settings;
	
	@FindBy(xpath="//span[@class='mandatory' and text()='*']/..//label")
	private List<WebElement> lst_MandatoryFeilds;
	
	@FindBy(xpath="//div[@id='newsText_rte-edit-view']/p")
	private WebElement txtarea_NewsText;
	
	@FindBy(xpath="//button[text()='Save']")
	private WebElement button_Save;
	
	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;
	
	
	RestActions rest=new RestActions();
	
	
	
	
	public EditNewsPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void navigateToNewsList(){
		try {
			webActions.isDisplayed(lnk_News, "News Link in Maintainance Page");
			report.reportPass("Should display News Link in Maintainance Page");
			webActions.click(lnk_News, "News Link");
			report.reportPass("Should click on the News Link in Maintainance Page");
			webActions.isDisplayed(txt_Newslist, "News List Page");
			report.reportPass("Should Naviagte to News List Page");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyHyperlink(){
		try {
			webActions.isDisplayed(lnk_News, "News Link in Maintainance Page");
			report.reportPass("Should display News Link in Maintainance Page");
			webActions.click(lnk_News, "News Link");
			report.reportPass("Should click on the News Link in Maintainance Page");
			webActions.isDisplayed(txt_Newslist, "News List Page");
			report.reportPass("Should Naviagte to News List Page");
			webActions.waitForPageLoaded();
			if(lst_titlelist.isDisplayed())
			{
				report.reportPass("Should display Titles in Newslist as Hyperlinks");
				webActions.waitForPageLoaded();
			}
			else
			{
				report.reportFail("Failed to display Titles in Newslist as Hyperlinks");
			}
			
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	
	public void navigateToEditNews(){
		try {
			String actualTitle=webActions.getText(driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div/a")), "FirstNews");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_NewsSearch, actualTitle,"NewsTitle: "+actualTitle);
			report.reportPass("Should Enter News title in News list search box");
			webActions.waitForPageLoaded();
			if(txt_NewsTitle.isDisplayed())
			{
				report.reportPass("Should display Title entered in News Search box");
				String expectedTitle=txt_NewsTitle.getText();
				if(expectedTitle.contentEquals(actualTitle))
				{
					report.reportPass("News title search successfull");
					webActions.click(txt_NewsTitle, "News Title :"+actualTitle);
					webActions.waitForPageLoaded();
					Thread.sleep(2000);
					webActions.isDisplayed(txt_EditNews,"Edit News Page");
					report.reportPass("Should display Edit News Page");
				}
				else
				{
					report.reportFail("Failed to display news title searched");
				}
			}
			else
			{
				report.reportFail("Failed to display Titles in news list page");
			}
			
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyEditNewsTitles(DataTable TitleNames) {
		try {
			ArrayList<String> expTitleNames = new ArrayList<>(TitleNames.asList());
			report.reportInfo("Expected Title Names: "+expTitleNames);
			ArrayList<String> actTitleNames=webActions.getDatafromWebTable(lst_titleNames);
			report.reportInfo("Displayed Actual Title Names as  "+actTitleNames);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actTitleNames, expTitleNames);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified Title Names in Edit News Successfully");
			}
			else{
				throw new Exception("Fail to verify Title Names in Edit News and unmatched Title Names are: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyBreadcrumbinEditNewsPage(DataTable breadcrumb ){
		try {
			ArrayList<String> expectdBreadcrumb = new ArrayList<>(breadcrumb.asList());
			ArrayList<String> actualBreadcrumb=webActions.getDatafromWebTable(lbl_Breadcrumb);
			report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumb);
			report.reportInfo("Expected Breadcrumb Titles "+expectdBreadcrumb);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumb, expectdBreadcrumb);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Breadcrumb Titles in Edit News page");
			}else{
				throw new Exception("Fail to verify the Breadcrumb Titles in Edit News page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyContentSection(){
		try {
			String content1="News Title";
			String content2="News Text";
			if(txt_ContentNewTitle.getText().contentEquals(content1)&&txt_ContentNewText.getText().contentEquals(content2)){
				report.reportPass("Successfully verified the Content sections as :"+content1+"and "+content2+" in Edit News");
			}else{
				throw new Exception("Fail to verify the Content Sections in Edit News page: ");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifySettingsSections(DataTable Sections) {
		try {
			ArrayList<String> expSectionNames = new ArrayList<>(Sections.asList());
			report.reportInfo("Expected Settings Names: "+expSectionNames);
			ArrayList<String> actSectionNames=webActions.getDatafromWebTable(lst_Settings);
			report.reportInfo("Displayed Actual Settings Names as  "+actSectionNames);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actSectionNames, expSectionNames);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified Sections under settings in Edit News Successfully");
			}
			else{
				throw new Exception("Fail to verify Sections under settings in Edit News and unmatched Names are: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyMandatoryfieldsEditNews(DataTable fields) {
		try {
			ArrayList<String> expMandatoryfields = new ArrayList<>(fields.asList());
			report.reportInfo("Expected Settings Names: "+expMandatoryfields);
			ArrayList<String> actMandatoryfields=webActions.getDatafromWebTable(lst_MandatoryFeilds);
			report.reportInfo("Displayed Actual Settings Names as  "+actMandatoryfields);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actMandatoryfields,expMandatoryfields);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified Mandatory fields in Edit News Successfully");
			}
			else{
				throw new Exception("Fail to verify Mandatory fields in Edit News and unmatched Names are: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifySaveFunctionality() {
		try {
		String messageTitle ="Success!";
		String messageContent="Data updated successfully.";	
		String editText=rest.randomString(10);
		webActions.waitForPageLoaded();
		webActions.waitForPageLoaded();
		webActions.click(txtarea_NewsText, "News Text");
		webActions.clearValue(txtarea_NewsText, "News Text");
		webActions.sendKeys(txtarea_NewsText, editText, "Enter value in NewsText field :"+editText);
		report.reportPass("Should enter value in NewsText field :"+editText);
		webActions.click(button_Save,"Save Button");
		report.reportPass("Should click on Save Button");
		 String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
         String[] titleContent=msg.split("\\n");
         String actTitle=titleContent[0];
         String actContent=titleContent[1];
         report.reportInfo("Actual alert message after user created: "+msg);
         if((messageTitle.contentEquals(actTitle)) && (messageContent.contentEquals(actContent)))
         	{
	            report.reportPass("Successfully Edit News is updated and alert message is matched: "+msg);
         	}
        webActions.waitForPageLoaded();
        navigateToEditNews();
  		webActions.waitForPageLoaded();
  		String ActualEditedText=webActions.getText(txtarea_NewsText,"Edit News");
  		report.reportInfo("Actual Text :"+ActualEditedText);
  		if(editText.contentEquals(ActualEditedText))
  		{
	            report.reportPass("Edit News updation successfull");
  		}
  		else
  		{
  			report.reportFail("Failed to update edit news");
  		}
 		
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	
	public void verifyValidationsNewsTitle(DataTable ValidationMsg) {
		try {
			webActions.waitForPageLoaded();
			webActions.click(txt_EditNewsTitle, "EditNewsTitle");
			webActions.clearValue(txt_EditNewsTitle, "EditNewsTitle");
			Thread.sleep(1000);
			webActions.click(txt_EditNewsTitle, "EditNewsTitle");
			webActions.waitForPageLoaded();
			webActions.pressTab();
			webActions.waitForPageLoaded();
			ArrayList<String> expValidationMsg = new ArrayList<>(ValidationMsg.asList());
			report.reportInfo("Expected Validation message: "+expValidationMsg);
			ArrayList<String> actValidationMsg=webActions.getDatafromWebTable(lst_validationmsg);
					report.reportInfo("Displayed Actual Validation message: "+actValidationMsg);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actValidationMsg, expValidationMsg);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified Validation message in Edit News Successfully");
			}
			else{
				throw new Exception("Fail to verify Validation message: in Edit News and unmatched are: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}	
	
}
