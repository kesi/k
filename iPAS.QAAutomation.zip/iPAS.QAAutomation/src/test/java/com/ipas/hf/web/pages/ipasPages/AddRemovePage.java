package com.ipas.hf.web.pages.ipasPages;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class AddRemovePage extends BasePage {
	private JSONObject jsonObject;
	private static final String SIUJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\SIUEventBasedData.json";
	private static final String ADTJSONFILE = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\ADTEventBasedData.json";

	@FindBy(xpath = "//button[text()='Columns']")
	private WebElement btn_Columns;

	
	@FindBy(xpath="//ejs-listview[@id='columnview']//div[@class='e-content']/ul/li/span")
	public List<WebElement> chk_Columns;

	@FindBy(xpath="//ejs-listview[@id='columnview']/div/div[2]/span")
	public WebElement txt_columnTitle;

	@FindBy(xpath="//ejs-listview/div[2]/ul/li[2]/div/span")
	public  WebElement txt_fieldName;

	@FindBy(xpath="//table[@class='e-table']/thead/tr/th[@class='e-headercell e-leftalign']")
	public  WebElement txt_gridHeader;

	@FindBy(xpath="//th[@class='e-headercell e-leftalign']/div/span|//th[@class='e-headercell e-templatecell e-leftalign']/div/span")
	public  List<WebElement> lbl_headercolumnNames;

	@FindBy(xpath="//input[@placeholder='Type Account ID/Patient Name']")
	public  WebElement txt_searchBox;	

	@FindBy(xpath = "//div[@id='e-dropdown-btn_4-popup']//ul")
	private WebElement lst_ColumnBox;

	@FindBy(xpath="//li[@class='e-list-item e-level-1 e-checklist e-active e-listviewcheckbox-disabled']")
	public  List<WebElement> lbl_selectedFieldNames;


	@FindBy(xpath = "//div[@id='panel']")
	private WebElement grid_Header;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody")
	private WebElement grid_Results;

	@FindBy(xpath="//a[contains(text(),'Service Tracker')]")
	private WebElement link_ServiceTracker;

	@FindBy(xpath="//a[contains(text(),'Account Search')]")
	private WebElement link_AccountSearch;

	@FindBy(xpath = "//div[@class='e-gridcontent']//tr[1]//td[2]/div/a")
	private WebElement lnk_AccountNumber;

	@FindBy(xpath="//div[@class='top-bredcrum']/ipas-breadcrumb/div/span[1]/a")
	private WebElement link_AccountSearchFromPageSummary;

	@FindBy(xpath="//table[@id='asgrid_content_table']//tbody/tr/td")
	private WebElement lbl_Headers;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody/tr/td")
	private WebElement lbl_GridRecords;

	@FindBy(xpath="//div[@class='imgSpec ng-star-inserted']/a")
	private WebElement lbl_AllData;

	@FindBy(xpath="//div[contains(text(),'M:')]")
	private WebElement lbl_Mobile;

	@FindBy(xpath="//div[contains(text(),'H:')]")
	private WebElement lbl_Home;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody/tr/td")
	private WebElement tbl_AllRecord;

	@FindBy(xpath="//ejs-accordion/div[1]/div[2]/div/div/ul/li/div[2]")
	private WebElement lbl_DataInAllDataPanel;

	public AddRemovePage() {
		PageFactory.initElements(driver, this);
	}

	private RestActions rest = new RestActions();
	public void verifyfields(){
		try {
			webActions.waitForVisibility(btn_Columns, "Columns");
			webActions.assertDisplayed(btn_Columns, "Columns");			
			report.reportPass("Column button is displayed on account search page");
		} catch (Exception e) {
			report.reportFail("Column button is not displayed on account search page");
		}
	}
	public void verifyColumnNames(DataTable columnNames) {
		try {
			ArrayList<String> expectedColumnNames = new ArrayList<>(columnNames.asList());
			report.reportInfo("Expected Column Names: "+expectedColumnNames);
			webActions.waitUntilEnabledAndClick(btn_Columns, "Columns Button");
			webActions.waitForPageLoaded();
			ArrayList<String> actualColumnNames=webActions.getDatafromWebTable(chk_Columns);
			report.reportInfo("Displayed Column Names in Application: "+actualColumnNames);
			ArrayList<String>unmatchedColumnNames=webActions.getUmatchedInArrayComparision(actualColumnNames, expectedColumnNames);
			if(unmatchedColumnNames.size()==0){
				report.reportPass("Verified Column Names in column list of Account Search page successfully");
			}
			else{
				throw new Exception("Fail to verify column Names in column list of Account Search page and unmatched column Names are: "+unmatchedColumnNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyColumnListTitle(String title) {
		try {
			webActions.waitUntilEnabledAndClick(btn_Columns, "Columns Button");
			String ActualTitle = webActions.getText(txt_columnTitle, "Columns Title");
			if (ActualTitle.contentEquals(title)){
				report.reportPass("Verified Columns title successfully");
				report.reportInfo("Actual Columns title: "+ActualTitle);
			}
			else{
				throw new Exception("Actual Columns title did not match with Expected and Actual title is: "+ActualTitle);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());

		}

	}

	public void columnSelection(String fieldMode,DataTable columnNames) { 
		try{
			webActions.waitForVisibility(txt_searchBox,"Search Box",120);
			List<String> expColNames = columnNames.asList(String.class);
			report.reportInfo("Column Names to be selected are : "+expColNames);
			webActions.waitForVisibility(btn_Columns,"Columns Dropdown");
			webActions.click(btn_Columns,"Columns Dropdown");
			webActions.waitForVisibility(lst_ColumnBox,"Columns Dropdown");			
			List<WebElement> options = lst_ColumnBox.findElements(By.tagName("li"));			
			for(int x = 0;x<expColNames.size();x++){		
				String value =expColNames.get(x);

				for(int i =0;i<options.size();i++){
					if(options.get(i).getText().equalsIgnoreCase(value)){
						String test = options.get(i).getText();						
						String xpath1 = "//span[text()='";
						String xpath2 = "']//preceding::div[1]";
						String xpath3 = xpath1+value+xpath2;
						List<WebElement> checkBox = driver.findElements(By.xpath(xpath3));				

						if(fieldMode.contentEquals("checked")){
							String valueChecked=checkBox.get(0).getAttribute("aria-checked");						
							if(valueChecked.equals("true")){							
								report.reportPass("Verified the default selected fields from column list successfully: "+value);							
							}
							else{
								String valueChecked1=checkBox.get(1).getAttribute("aria-checked");
								if(valueChecked1.equals("true")){							
									report.reportPass("Verified the default selected fields from column list successfully: "+value);
								}
							}											
						}
						else if(fieldMode.contentEquals("unChecked")){
							String valueChecked1=checkBox.get(0).getAttribute("aria-checked");
							if(valueChecked1.equals("false")){
								report.reportPass("Verified the default un-selected fields from column list successfully: "+value);

							}
							else{
								report.reportFail("unchecked fields are not mateched: "+value);
							}

						}
					}

				}
			}

		}
		catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	public void verifyDefaultColumnNames(DataTable columnNames) {
		try {
			ArrayList<String> expectedColumnNames = new ArrayList<>(columnNames.asList());
			report.reportInfo("Expected grid header default column names: "+expectedColumnNames);
			webActions.waitForVisibility(txt_gridHeader, "DefaultColumnNames");
			ArrayList<String> actualColumnNames=webActions.getDatafromWebTable(lbl_headercolumnNames);
			report.reportInfo("Default displayed Column Names in Application: "+actualColumnNames);
			ArrayList<String>unmatchedColumnNames=webActions.getUmatchedInArrayComparision(actualColumnNames, expectedColumnNames);
			if(unmatchedColumnNames.size()==0){
				report.reportPass("Verified Column Names in grid header of serach result grid successfully");
			}
			else{
				throw new Exception("Fail to verify column Names in grid header of serach result grid and unmatched column Names are: "+unmatchedColumnNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void selectColumn(String colunmnName){
		try {
			System.out.println("colunmnName: "+ colunmnName);
			webActions.waitUntilEnabledAndClick(btn_Columns, "Columns Button");
			webActions.waitForPageLoaded();
			Thread.sleep(5000);
			webActions.selectCheckBoxfromList(chk_Columns,colunmnName,"Columns");
			webActions.waitForPageLoaded();
			webActions.waitUntilEnabledAndClick(btn_Columns, "Columns Button");
			report.reportPass("Selected the field from column list successfully: "+colunmnName);
		} catch (Exception e) {
			report.reportFail("Failed to select the field from column list");
		}
	}

	public void verifyGridHeaderColumnNames(String fieldName,DataTable columnNames) {
		try {
			ArrayList<String> expectedColumnNames = new ArrayList<>(columnNames.asList());
			report.reportInfo("Expected grid header default column names: "+expectedColumnNames);
			webActions.waitForPageLoaded();
			selectColumn(fieldName);
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_headercolumnNames, "DefaultColumnNames");
			ArrayList<String> actualColumnNames=webActions.getDatafromWebTable(lbl_headercolumnNames);
			report.reportInfo("Header column names dsiplayed in search result grid: "+actualColumnNames);
			ArrayList<String>unmatchedColumnNames=webActions.getUmatchedInArrayComparision(actualColumnNames, expectedColumnNames);
			if(unmatchedColumnNames.size()==0){
				report.reportPass("Verified Column Names in grid header of serach result grid successfully");
			}
			else{
				throw new Exception("Failed to verify column Names in grid header of serach result grid and unmatched column Names are: "+unmatchedColumnNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	/**To verify the read only fields in columns list*/
	public boolean verifyColumnFieldsSelection(DataTable columnNames) {
		boolean flag=false;
		try {
			ArrayList<String> expectedColumnNames = new ArrayList<>(columnNames.asList());
			report.reportInfo("Expected grid header default column names: "+expectedColumnNames);
			webActions.waitUntilEnabledAndClick(btn_Columns, "Columns Button");
			webActions.waitForVisibility(lst_ColumnBox, "ColumnNames");
			ArrayList<String> actualColumnNames=webActions.getDatafromWebTable(lbl_selectedFieldNames);
			report.reportInfo("Default displayed Column Names in Application: "+actualColumnNames);
			ArrayList<String>unmatchedColumnNames=webActions.getUmatchedInArrayComparision(actualColumnNames, expectedColumnNames);
			if(unmatchedColumnNames.size()==0){	
				report.reportPass("Verified Column fields from column list successfully");
				flag=true;
			}
			else{
				flag=false;
				throw new Exception("Fail to verify column fields from column list and unmatched column fields are: "+unmatchedColumnNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
		return flag;
	}	
	/** To select/Un select multiple columns from column list*/
	public void clickFieldsFromColumnList(String headerName, DataTable columnNames){
		try {
			webActions.waitUntilEnabledAndClick(btn_Columns, "Columns Button");
			List<String> fields= columnNames.asList(String.class);
			int fieldsClick=fields.size();
			for (int fieldsToSelect = 0; fieldsToSelect < fieldsClick; fieldsToSelect++) {
				webActions.selectCheckBoxfromList(chk_Columns,fields.get(fieldsToSelect),fields.get(fieldsToSelect));
			}					
			webActions.waitUntilEnabledAndClick(btn_Columns, "Columns Button");
			webActions.waitForVisibility(txt_gridHeader, "DefaultColumnNames");
			ArrayList<String> actualColumnNames=webActions.getDatafromWebTable(lbl_headercolumnNames);
			report.reportInfo("Header column names dsiplayed in search result grid: "+actualColumnNames);
			ArrayList<String>unmatchedColumnNames=webActions.isFullArrayMatchWithData(actualColumnNames, headerName);
			if(unmatchedColumnNames.size()==0){
				report.reportPass("Verified Column Names in grid header of serach result grid successfully");
			}
			else{
				throw new Exception("Fail to verify column Names in grid header of serach result grid and unmatched column Names are: "+unmatchedColumnNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}


	public void verifyDatainColumnBySelectingFieldFromColumns(String responseValue,String columnName,String fieldName) throws Exception{
		String expectedValue="";
		ArrayList<String>actData2=new ArrayList<String>();
		try {
			expectedValue=rest.getValueFromResponseandCompWithExpected(responseValue);
			if((expectedValue.contains("CheckedIn"))){
				expectedValue=expectedValue.replaceAll("(\\p{Ll})(\\p{Lu})","$1 $2");	
			}
			webActions.waitForPageLoaded();			
			ArrayList<String>actData=webActions.getGridData(grid_Header,grid_Results,columnName,fieldName);
			String actData1=actData.get(0);
			actData2.add(actData1.replaceAll("//W", " "));
			ArrayList<String> unmatchedData=webActions.isFullArrayMatchWithData(actData2, expectedValue);
			report.reportInfo("Expected Data is: "+expectedValue);
			report.reportInfo("Actual Data is: "+actData2);
			if(unmatchedData.size()==0){
				report.reportPass("Data verified successfully and displayed data is: " + actData2);
			}else{
				throw new Exception("Data verification failed, and unmatched data is: "+unmatchedData);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public String getValuefromJSONresponseBasedOnObject(String fieldName){
		String expectedResponseValue=null;
		try {
			// read the json file

			FileReader reader = new FileReader(ADTJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject appointObject = (JSONObject) jsonObject.get("appointment");

			if(fieldName.contentEquals("Patient Type")){						
				JSONObject patientTypeObject=(JSONObject) visitObject.get("PatientType");
				expectedResponseValue = (String) patientTypeObject.get("PatientTypeDescription");						
			}
			else if(fieldName.contentEquals("Appointment Number")){						
				expectedResponseValue = (String)  appointObject.get("AppointmentId");				
			}
			else if(fieldName.contentEquals("Patient Name")){						
				expectedResponseValue = (String)  patientObject.get("PatientFirstName");				
			}
			else if(fieldName.contentEquals("SSN")){
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(1);							
				String ssn= (String) tenantPatient.get("TenantPatientId");
				String ssnMask=ssn.substring(6, 11);
				expectedResponseValue="***-**"+ssnMask;
			}
			else if(fieldName.contentEquals("Email")){
				expectedResponseValue= (String)patientObject.get("PatientEmailAddress");
			}
			else if(fieldName.contentEquals("Hospital Service")){
				expectedResponseValue=(String) visitObject.get("VisitService");													

			}
			else if(fieldName.contentEquals("Diagnosis")){							
				JSONArray diag = (JSONArray) jsonObject.get("Diagnosis");							
				JSONObject diagnosis=(JSONObject) diag.get(0);
				JSONObject diagnosisDescription=(JSONObject)diagnosis.get("DiagnosisDescription");
				expectedResponseValue=(String) diagnosisDescription.get("DiagnosisCode");							
			}
			else if(fieldName.contentEquals("Procedure")){
				JSONArray proce = (JSONArray) jsonObject.get("Procedure");
				JSONObject procedure=(JSONObject)proce.get(0);
				JSONObject procedureNameObject=(JSONObject) procedure.get("ProcedureName");
				expectedResponseValue=(String) procedureNameObject.get("ProcedureCode");							
			}
			else if(fieldName.contentEquals("Admitting Provider")){
				JSONArray visitProvider=(JSONArray)visitObject.get("VisitProvider");
				JSONObject visitProviderName = (JSONObject)visitProvider.get(3);
				expectedResponseValue=(String)visitProviderName.get("ProviderLastName");							
			}
			else if(fieldName.contentEquals("Referring Provider")){
				JSONArray visitProvider=(JSONArray)visitObject.get("VisitProvider");
				JSONObject visitProviderName = (JSONObject)visitProvider.get(1);
				expectedResponseValue=(String)visitProviderName.get("ProviderLastName");							
			}
			else if(fieldName.contentEquals("Financial Class")){
				JSONObject FinancialClass=(JSONObject)visitObject.get("FinancialClass");
				expectedResponseValue=(String) FinancialClass.get("FinancialClassDescription");
			}
			else if((fieldName.contentEquals("Primary Insurance"))||(fieldName.contentEquals("Secondary Insurance"))||(fieldName.contentEquals("Tertiary Insurance"))){
				JSONArray insu=(JSONArray) jsonObject.get("Insurance");
				JSONObject insurance = null;
				if(fieldName.contentEquals("Primary Insurance")){
					insurance = (JSONObject)insu.get(0);
				}
				else if(fieldName.contentEquals("Secondary Insurance")){
					insurance = (JSONObject)insu.get(1);
				}
				else{
					insurance = (JSONObject)insu.get(2);
				}
				String insurancePlanId=(String) insurance.get("InsurancePlanId");
				String insurancePlanName=(String) insurance.get("InsurancePlanName");
				expectedResponseValue=insurancePlanId+" "+insurancePlanName;
			}
			else if (fieldName.contentEquals("Phone Number")){
				JSONArray phn = (JSONArray) patientObject.get("PatientPhoneNumber");
				JSONObject patientPhone = (JSONObject) phn.get(0);							
				expectedResponseValue= (String) patientPhone.get("PhoneNumber");

			}
		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return expectedResponseValue;

	}
	/** To verify the data with JSON response**/
	public void verifyDatainColumnBySelectingFieldFromColumn(String columnName,String fieldName) throws Exception{
		String expectedValue="";
		ArrayList<String> unmatchedData;
		try{
			expectedValue=getValuefromJSONresponseBasedOnObject(fieldName);	
			webActions.waitForPageLoaded();			
			ArrayList<String>actData=webActions.getGridData(grid_Header,grid_Results,columnName,fieldName);				
			if((fieldName.contentEquals("Admitting Provider"))||(fieldName.contentEquals("Referring Provider"))){				
				unmatchedData=isFullArrayMatchWithContainsData(actData, expectedValue);
			}else{
				unmatchedData=webActions.isFullArrayMatchWithData(actData, expectedValue);
			}
			report.reportInfo("Expected Data is: "+expectedValue);
			if(unmatchedData.size()==0){
				report.reportPass("Data verified successfully and displayed data is: " + actData);
			}else{
				throw new Exception("Data verification failed, and unmatched data is: "+unmatchedData);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public ArrayList<String> isFullArrayMatchWithContainsData(ArrayList<String> actArrayData,String expData)
	{
		ArrayList<String> unmatchdata = new ArrayList<String>();
		for(int data=0;data<actArrayData.size();data++)
		{
			if(!actArrayData.get(data).contains(expData))
			{
				unmatchdata.add(actArrayData.get(data));
			}
		}
		return unmatchdata;
	}

	/** To verify the phone number from with JSON response**/
	public void verifyPhoneNumberBySelectingFieldFromColumn(String columnName,String fieldName, String phoneType) throws Exception{

		try{
			String expectedValue=getPhoneNumberfromJSONresponse(fieldName,phoneType);				
			webActions.waitForPageLoaded();						
			String actData=getPhoneNumberFromApp(phoneType);
			report.reportInfo("Actual Data is: "+actData);
			report.reportInfo("Expected Data is: "+expectedValue);
			if(actData.contains(expectedValue)){
				report.reportPass("Data verified successfully and displayed data is: " + actData);
			}else{
				throw new Exception("Data verification failed, and unmatched data is: "+actData);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public String getPhoneNumberfromJSONresponse(String fieldName, String type){
		String expectedResponseValue=null;
		try {
			// read the json file

			FileReader reader = new FileReader(ADTJSONFILE);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");

			if (fieldName.contentEquals("Phone Number")){
				JSONArray phn = (JSONArray) patientObject.get("PatientPhoneNumber");
				JSONObject patientPhone=null;
				if(type.contentEquals("M")){
					patientPhone = (JSONObject) phn.get(0);
				}
				else{
					patientPhone = (JSONObject) phn.get(1);
				}
				String expectedResponseValue1= (String) patientPhone.get("PhoneNumber");
				expectedResponseValue=expectedResponseValue1.replaceAll("\\p{P}","");
			}
		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return expectedResponseValue;

	}

	public String getPhoneNumberFromApp(String type){
		String Number="";
		String txt="";
		try {
			if(type.contentEquals("M")){
				txt=webActions.getText(lbl_Mobile, "Mobile");
			}
			else{
				txt=webActions.getText(lbl_Home, "Home");
			}
			String [] txt1=txt.split(":");
			String mobile=txt1[1];
			Number=mobile.replaceAll("\\p{P}","");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
		return Number;		
	}

	public void navigateAndBackToAccountSearch(String pageName){
		try {
			if(pageName.contentEquals("ServiceTracker"))
			{
				webActions.waitForClickAbility(lnk_AccountNumber, "Account Number");
				webActions.waitForClickAbility(link_ServiceTracker, "Service Tracker");			
				webActions.click(link_ServiceTracker, "Service Tracker");
				report.reportInfo("Navigated to the service tracker page");			
				webActions.waitForClickAbilityAndClick(link_AccountSearch, "Account Search");
				webActions.waitForPageLoaded();
				webActions.waitUntilisDisplayed(lbl_Headers, "Headers");	
				report.reportInfo("Back to the Account search page");			
			}
			else if(pageName.contentEquals("PatientVisitSummary")){
				webActions.waitForClickAbility(lnk_AccountNumber, "Account Number");
				String accountNumber=webActions.getText(lnk_AccountNumber, "Account Number");
				report.reportInfo("Account Number is: "+accountNumber);
				webActions.click(lnk_AccountNumber, "Account Number");
				report.reportInfo("Navigated to the Patient Visit Summary page");
				webActions.waitUntilisDisplayed(lbl_DataInAllDataPanel, "AllData");
				//webActions.waitForClickAbility(link_AccountSearchFromPageSummary, "Account Number");
				webActions.click(link_AccountSearchFromPageSummary, "Account Number");
				webActions.waitForPageLoaded();
				webActions.waitUntilisDisplayed(lbl_Headers, "gridheader");				
				report.reportInfo("Back to the Account search page");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}
	public void verifyHeaderNames(DataTable headerNames){
		try {
			List<String> expHeaders = headerNames.asList(String.class);
			report.reportInfo("Expected Header Names in Default Search: "+expHeaders);
			webActions.waitForVisibility(tbl_AllRecord,"All Records");
			List<String> actHeaders=webActions.getDatafromWebTable(lbl_headercolumnNames);
			report.reportInfo("Actual Header Names in Default Search: "+actHeaders);
			ArrayList<String> unmatchedHeaderNames=webActions.getUmatchedInArrayComparision(actHeaders,expHeaders);
			if(unmatchedHeaderNames.size()==0){
				report.reportPass("Verified Header Names in Default Search page successfully");
			}
			else{
				throw new Exception("Fail to verify Header Names in Default Search page and unmatched Names are: "+unmatchedHeaderNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}


}