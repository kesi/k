package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class UserPermissionsPage extends BasePage {
	UpdateVisitPage updateVisit = new UpdateVisitPage();
	Login logIn = new Login();
	HomePage hmPage = new HomePage();

	String resetPassword="";

	@FindBy(xpath = "//input[@id='username']")
	private WebElement txt_UserName;

	@FindBy(xpath = "//input[@id='password']")
	private WebElement txt_Password;

	@FindBy(xpath = "//img[@src='assets/images/cog.png']")
	private WebElement img_Settings;

	@FindBy(xpath = "//ipas-app-navigations[1]//nav[1]//div[1]/a[@class='dropdown-item']/span")
	private List<WebElement> lst_Settings;

	@FindBy(xpath = "//ul/li/a[@class='nav-link']")
	private List<WebElement> lst_MainModules;

	@FindBy(xpath ="//span[contains(text(),'User Profile')]")
	private WebElement img_UserProfile;

	@FindBy(xpath="//button[contains(text(),'Edit')]")
	private WebElement btn_UsrPrfEdit;

	@FindBy(xpath="//ejs-dialog[3]//h4")
	private WebElement txt_EditPrflText;

	@FindBy(xpath ="//form[1]//ejs-maskedtextbox[1]/span[1]/input[1]")
	private WebElement txt_UsrMobileNumber;

	@FindBy(xpath = "//button[contains(text(),'Save')]")
	private WebElement btn_SaveInEditUsrPrf;

	@FindBy(xpath ="//body/ejs-dialog[3]/div[1]/div[1]/div[1]/div[1]/div[1]/button[1]")
	private WebElement btn_UsrPrflClose;

	@FindBy(xpath = "//form[1]/div[2]/div[1]/div[1]/button[1]")
	private WebElement btn_ChangePassword;

	@FindBy(xpath ="//h4/span[contains(text(),'Change Password')]")
	private WebElement txt_ChangePassword;

	@FindBy(xpath ="//div/div/div//span[@class='panel-title']")
	private List<WebElement> txt_MaintenanceModules;

	@FindBy(xpath ="//div/div//ul/li/div/a")
	private List<WebElement> txt_SubMenuOptions;

	@FindBy(linkText = "Maintenance")
	private WebElement lnk_Maintenance;

	@FindBy(xpath="//ipas-payment-facilitator-pannel/ejs-accordion/div")
	private WebElement tbl_PaymentFacilitatorPanel;

	@FindBy(linkText="Payment Facilitator")
	private WebElement lnk_PaymentFacilitator;

	@FindBy(xpath="//span[contains(text(),'Results')]")
	private WebElement lbl_Headers_AS;

	@FindBy(xpath = "//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_Search;

	@FindBy(xpath="//ul[contains(@class,'p-autocomplete-items')]/li[1]")
	private WebElement li_Search;

	@FindBy(xpath="//table[@class='e-kanban-table e-header-table']//div[@class='e-header-text']")
	private WebElement lbl_Headers;

	@FindBy(xpath = "//input[@id='textbox_3']")
	private WebElement txt_Search_ST;

	@FindBy(xpath="//a[text()='Account Search']")
	private WebElement tb_search;

	@FindBy(xpath ="//input[@role='searchbox']")
	private WebElement txt_searchBox;

	@FindBy(xpath ="//a[text()='Service Tracker']")
	private WebElement tab_serviceTracker;

	@FindBy(xpath="//div[@class='Servicetrackerfilters']")
	private WebElement grid_filters;

	@FindBy(xpath = "//div[@class='content-wrapper']")
	private WebElement grid_serviceTrackerBoard;

	public UserPermissionsPage() {
		PageFactory.initElements(driver, this);
	}

	public void verifySettingsOptions(DataTable options) {
		try {
			ArrayList<String> expectedOptions = new ArrayList<>(options.asList());
			report.reportInfo("Expected Settings option Names: "+expectedOptions);
			webActions.waitUntilEnabledAndClick(img_Settings, "Settings Icon");
			report.reportInfo("Image Settings Icon is displayed");
			webActions.waitUntilisDisplayed(img_Settings, "SettingsMenu");
			report.reportInfo("Settings Options drop down is displayed");
			ArrayList<String> actualOptions=webActions.getDatafromWebTable(lst_Settings);
			report.reportInfo("Actual Displayed Settings options Names in Application: "+actualOptions);
			ArrayList<String>unmatchedOptionNames=webActions.getUmatchedInArrayComparision(actualOptions, expectedOptions);
			if(unmatchedOptionNames.size()==0){
				report.reportPass("Verified Settings options in Dash Board page successfully");
			}
			else{
				throw new Exception("Fail to verify list of options in Settings in Dash Board and unmatched options are: "+unmatchedOptionNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}


	public void verifyAccessibleModules(DataTable options) throws Exception{
		try{
			ArrayList<String> expectedOptions = new ArrayList<>(options.asList());
			report.reportInfo("Expected option Names: "+expectedOptions);
			ArrayList<String> actualOptions=webActions.getDatafromWebTable(lst_MainModules);
			report.reportInfo("Displayed Module Names in Application: "+actualOptions);
			ArrayList<String>unmatchedOptionNames=webActions.getUmatchedInArrayComparision(actualOptions, expectedOptions);
			if(unmatchedOptionNames.size()==0){
				report.reportPass("Verified Module Names are successfully");
			}
			else{
				throw new Exception("Fail to read Module Names and unmatched modules are: "+unmatchedOptionNames);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyEditProfile() throws Exception{
		try{
			webActions.waitUntilEnabledAndClick(img_Settings, "Settings Icon");
			report.reportInfo("Clicked on Setting Image");
			webActions.waitUntilisDisplayed(img_UserProfile, "SettingsMenu");
			report.reportInfo("Settings Menu is displayed");
			verifyEditUserProfileText();
			closeUserProfile();
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyEditUserProfileText() throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.waitForClickAbilityAndClick(img_UserProfile, "User Profile");
			report.reportInfo("Clicked on User Prfoile");
			webActions.waitForClickAbilityAndClick(btn_UsrPrfEdit, "EditProfile");
			report.reportInfo("Clicked on Edit in User Prfoile");
			webActions.waitForPageLoaded();
			String actEditProfile=webActions.getText(txt_EditPrflText, "EditProfile");
			report.reportInfo("User Profile text is :"+actEditProfile);
			if(actEditProfile.contentEquals("Edit User Profile")){
				report.reportPass("Edit User Profile text is displayed properly");
			}else{
				throw new Exception("Unable to read User Profile text");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void editUserMobile() throws Exception{
		try{
			webActions.waitForPageLoaded();
			String mobileNumber = webActions.getAttributeValue(txt_UsrMobileNumber,"value","Mobile Number");
			report.reportPass("Mobile Number is :"+mobileNumber);
			webActions.clearValue(txt_UsrMobileNumber, "Mobile Numb");
			webActions.wait(2);
			if(btn_SaveInEditUsrPrf.isEnabled()){
				webActions.click(btn_SaveInEditUsrPrf, "Save button");
			}else{
				throw new Exception("Save button is not in enabled mode");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void closeUserProfile() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_UsrPrflClose, "Cross Button");
			webActions.clickBYJS(btn_UsrPrflClose, "Cross Button");
			report.reportPass("Clicked on Cross button in Edit User");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyResetPassword() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitUntilEnabledAndClick(img_Settings, "Settings Icon");
			report.reportInfo("Clicked on Setting Image");
			webActions.waitUntilisDisplayed(img_UserProfile, "SettingsMenu");
			report.reportInfo("Settings Menu is displayed");
			webActions.waitForClickAbilityAndClick(img_UserProfile, "User Profile");
			report.reportInfo("Clicked on User Prfoile");
			webActions.click(btn_ChangePassword,"Change Password");
			report.reportPass("Clicked on Change Password");
			String actText = webActions.getText(txt_ChangePassword, "Change Password Text");
			report.reportInfo("Actual Text is :"+actText);
			if(actText.contentEquals("Change Password")){
				report.reportPass("Change Password text is displayed properly");
			}else{
				throw new Exception("Unable to read Change Password text");
			}		
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}


	public void verifyMaintenanceModules(DataTable options) throws Exception{
		try{			
			ArrayList<String> expectedOptions = new ArrayList<>(options.asList());
			report.reportInfo("Expected option Names: "+expectedOptions);
			ArrayList<String> actualOptions=webActions.getDatafromWebTable(txt_MaintenanceModules);
			report.reportInfo("Displayed Module Names in Application: "+actualOptions);
			ArrayList<String>unmatchedOptionNames=webActions.getUmatchedInArrayComparision(actualOptions, expectedOptions);
			if(unmatchedOptionNames.size()==0){
				report.reportPass("Verified Module Names are successfully");
			}
			else{
				throw new Exception("Fail to read Module Names and unmatched modules are: "+unmatchedOptionNames);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifySubMenuOptionsOfMaintenanceModules(DataTable options) throws Exception{
		try{			
			ArrayList<String> expectedOptions = new ArrayList<>(options.asList());
			report.reportInfo("Expected option Names: "+expectedOptions);
			ArrayList<String> actualOptions=webActions.getDatafromWebTable(txt_SubMenuOptions);
			report.reportInfo("Displayed Module Names in Application: "+actualOptions);
			ArrayList<String>unmatchedOptionNames=webActions.getUmatchedInArrayComparision(actualOptions, expectedOptions);
			if(unmatchedOptionNames.size()==0){
				report.reportPass("Verified Module Names are successfully");
			}
			else{
				throw new Exception("Fail to read Module Names and unmatched modules are: "+unmatchedOptionNames);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void navigatetoPaymentFacilitatorPage(String pageName, String visitID) {
		try {
			navigatePatientVisitMainPage(pageName,visitID);
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(tbl_PaymentFacilitatorPanel, "Payment Facilitator Panel");
			webActions.waitAndClick(lnk_PaymentFacilitator, "Payment Facilitator");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void accountsearchtab() {
		try {
			webActions.click(tb_search, "Account Search Tab");
			report.reportPass("Should Navigate to Account Search tab");
			webActions.waitUntilisDisplayed(txt_searchBox,"Search Input Box");
			report.reportPass("Should Verify search Input Box");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_Headers_AS,"Grid load");
			report.reportPass("Should wait until the Grid loads");
		} catch (Exception e) {
			report.reportFail("Failed to navigate to account search page: " + e);
		}
	}

	public void serviceTrackerPageValidation() throws Exception
	{
		webActions.click(tab_serviceTracker,"tab_serviceTracker");
		webActions.waitForVisibility(grid_filters,"Filters of Service Page");
		report.reportPass("Should load Service Tracker Board with Filters");
		webActions.waitUntilisDisplayed(grid_filters,"Filters of Service Page");
		webActions.waitUntilisDisplayed(grid_serviceTrackerBoard, "Service Tracker Board");
		webActions.isDisplayed(grid_serviceTrackerBoard, "Service Tracker Board");
		report.reportPass("Should display Service Tracker Board with Default Status Headers");
	}


	public String navigatePatientVisitMainPage(String pageName, String visitID){
		String accountNumber="";
		try {
			accountNumber = logIn.getVisitIdFromResponse(visitID);
			switch (pageName) {
			case "Account Search":
				searchAccountNuberinAccountSearchPage(accountNumber);
				break;
			case "Service Tracker":
				searchAccountNumberinServiceTracker(accountNumber);
				break;
			}
		} catch (Exception e) {
			report.reportFail("Failed to navigate Patient Visi tMain Page from "+pageName+" page");
		}
		return accountNumber;
	}

	public void searchAccountNuberinAccountSearchPage(String accountNumber) throws Exception{
		try {
			webActions.waitForVisibility(lbl_Headers_AS, "Account Search Headers");
			webActions.sendKeys(txt_Search, accountNumber, "");
			webActions.waitForClickAbility(li_Search, "");
			webActions.click(li_Search, "");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_Headers_AS,"Account Search Headers");
			driver.findElement(By.partialLinkText(accountNumber)).click();
			webActions.waitForVisibility(tbl_PaymentFacilitatorPanel, "Payment Facilitator Panel");
		} catch (Exception e) {
			throw new Exception(e);
		}
	}

	public void searchAccountNumberinServiceTracker(String AccountNumber) throws Exception{
		try {
			webActions.waitForVisibility(lbl_Headers, "Service Tracker Headers");
			webActions.enterValuesfromKeyBoard(txt_Search_ST, AccountNumber, "");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			driver.findElement(By.linkText(AccountNumber)).click();
			webActions.waitForVisibility(tbl_PaymentFacilitatorPanel, "PaymentFacilitatorPanel");
		} catch (Exception e) {
			throw new Exception(e);
		}
	}

	public UserPermissionsPage openIpasApp() {
		try {
			String URL = TestBase.prop.ipasURL();
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to Open iPAS application");
		}
		return (UserPermissionsPage) base(UserPermissionsPage.class);
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_UserName);
	}

}
