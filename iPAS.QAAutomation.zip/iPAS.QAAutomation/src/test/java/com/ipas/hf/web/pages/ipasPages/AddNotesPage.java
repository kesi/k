package com.ipas.hf.web.pages.ipasPages;


import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class AddNotesPage extends BasePage {

	String resetPassword="";

	@FindBy(xpath = "//input[@id='username']")
	private WebElement txt_UserName;

	@FindBy(xpath = "//div[@class='st modal-dialog modal-xl']//a[contains(text(),'Notes')]")
	private WebElement btn_NotesOnModalWindow;

	@FindBy(xpath = "//span[contains(text(),'Notes')]")
	private WebElement txt_NotesOnNotesWindow;

	@FindBy(xpath = "//div[@class='note-list']//tr[@class='e-columnheader']/th/div/span")
	private List<WebElement> txt_HeaderColumnNames;

	@FindBy(xpath = "//button[contains(text(),'Add Note')]")
	private WebElement btn_AddNotesInNotesWindow;

	@FindBy(xpath = "//ejs-dialog[1]/div[1]/button[1]/span[@class='e-btn-icon e-icon-dlg-close e-icons']")
	private WebElement btn_CloseButtonInNotesWindow;

	@FindBy(xpath = "//ejs-dialog[1]/div[2]/div[1]/div[2]/div[1]/div[1]/p[1]")
	private WebElement msg_MAxLengthMsg;

	@FindBy(xpath = "//ejs-textbox[1]/span[1]/textarea[1]")
	private WebElement txtBox_NotesTextBox;

	@FindBy(xpath = "//div[@class='e-gridcontent']//table/tbody/tr[1]/td")
	private List<WebElement> txt_NotesGridData;

	@FindBy(xpath = "//div[@class='e-gridcontent']//table/tbody/tr[1]/td[3]")
	private WebElement txt_NotesGridDateData;

	@FindBy(xpath = "//div[@class='e-gridcontent']//table/tbody/tr[1]/td[2]")
	private WebElement txt_NotesGridUserName;

	@FindBy(xpath = "//div[@class='e-gridcontent']//table/tbody/tr[1]/td[1]")
	private WebElement txt_NotesGridNotesData;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_FilterMsgs; 

	@FindBy(xpath = "//div[@class='e-gridcontent']//table/tbody/tr")
	private List<WebElement> txt_NotesGridCount;
		
	@FindBy(xpath = "//ejs-dialog[1]/div[1]/button[1]/span[1]")
	private WebElement btn_CloseBtnOnNotesWindow;
	
	public AddNotesPage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyNotesTab() throws Exception{
		try{
			webActions.waitForPageLoaded();
			if(btn_NotesOnModalWindow.isDisplayed()){
				report.reportPass("Notes Button is displayed");
				webActions.waitForClickAbilityAndClick(btn_NotesOnModalWindow, "Notes");
				report.reportInfo("Clicked on Notes button");
				webActions.waitForPageLoaded();
				if(txt_NotesOnNotesWindow.isDisplayed()){
					report.reportPass("Notes text is displayed on Notes Window");
				}else{
					throw new Exception("Failed to read Notes Text on Notes Window");
				}				
			}else{
				throw new Exception("Notes button is not displayed");
			}

		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyColumnsNamesInNotesWindow(DataTable expTabs) throws Exception{
		try{
			webActions.waitForPageLoaded();
			ArrayList<String> expTabsCount = new ArrayList<>(expTabs.asList());
			report.reportInfo("Expected Column Names in Notes Window : "+expTabsCount);		
			ArrayList<String> actTabsCount= webActions.getDatafromWebTable(txt_HeaderColumnNames);
			report.reportPass("Actual Column Names in Notes window are :"+actTabsCount.size());
			ArrayList<String> unmatchedTabNames=getUmatchedInArrayComparision(expTabsCount,actTabsCount);
			if(unmatchedTabNames.size()==0){
				report.reportPass("Verified Column Names Successfully");
			}
			else{
				throw new Exception("Fail to verify Tab Names in Model Window and unmatched Types are:"+unmatchedTabNames);
			}

		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyAddNotesButtonInDisabledMode() throws Exception{
		try{
			if(!btn_AddNotesInNotesWindow.isEnabled()){
				report.reportPass("Add Note button is in disabled mode");
			}else{
				throw new Exception("Add Note button is in enabled mode");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyAddNotesButtonInEnabledMode() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.sendKeys(txtBox_NotesTextBox, "Test", "TextBox");
			report.reportPass("Text is entered successfully in Text Box");
			webActions.waitForPageLoaded();
			if(btn_AddNotesInNotesWindow.isEnabled()){
				report.reportPass("Add Note button is in disabled mode");
			}else{
				throw new Exception("Add Note button is in enabled mode");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public ArrayList<String> getUmatchedInArrayComparision(List<String> actData, List<String> expData) throws Exception
	{
		ArrayList<String> UnmatchedArray = new ArrayList<String>();
		if(actData!=null && expData!=null &&actData.size()>0&&expData.size()>0 && actData.size()==expData.size()){
			for(int data=0;data<actData.size();data++)
			{
				if(!((actData.get(data)).contentEquals(expData.get(data))))
					UnmatchedArray.add(actData.get(data));	
			}
		}
		else{
			throw new Exception("Arrya Sizes are not matched");
		}
		return UnmatchedArray;			
	}

	public void verifyCloseButtonInNotesWindow() throws Exception{
		try{
			webActions.waitForPageLoaded();
			if(btn_CloseButtonInNotesWindow.isDisplayed()){
				report.reportPass("close button is displayed on Notes PopUp Window");
			}else{
				throw new Exception("Failed to find close button in Notes PopUp Window");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyMaxLengthMessageInNotesWindow(String expMessageLength) throws Exception{
		String actMessageLength = null;
		try{
			webActions.waitForPageLoaded();
			actMessageLength = webActions.getText(msg_MAxLengthMsg, "MaxLength");
			report.reportInfo("Actual Text is :"+actMessageLength);
			if(actMessageLength.contentEquals(expMessageLength)){
				report.reportPass("Max length message is displayed properly");
			}else{
				throw new Exception("Failed to read Max Length message");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void createNotes(String value) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txtBox_NotesTextBox, "NotesTextBox");
			report.reportInfo("Notes Text Box is displayed");
			webActions.sendKeys(txtBox_NotesTextBox, value, "Msg");
			report.reportPass("Text is entered successfully");
			webActions.click(btn_AddNotesInNotesWindow, "Submit");
			report.reportPass("Clicked on Submit button");
			webActions.waitForPageLoaded();
			Thread.sleep(2000);
			webActions.waitUntilListisDisplayed(txt_NotesGridData, "Notes Grid");
			report.reportPass("List is displayed successfully");

		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyCreatedNotesData(DataTable data) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitUntilListisDisplayed(txt_NotesGridData, "GridData");
			report.reportPass("Grid Data is displayed properly");
			ArrayList<String> expNotesGridData = new ArrayList<>(data.asList());
			expNotesGridData.add(webActions.getSystemCurrentDate());
			report.reportInfo("Expected Notes Grid Data is : "+expNotesGridData);

			ArrayList<String> actGridData = new ArrayList<String>();
			actGridData.add(webActions.waitAndGetText(txt_NotesGridNotesData, "NotesData"));
			actGridData.add(webActions.waitAndGetText(txt_NotesGridUserName, "NotesUserName"));
			actGridData.add(getDateValueFromNotesGrid());
			report.reportInfo("Data from Application is :"+actGridData);

			ArrayList<String> unmatchedNotesGridData = webActions.getUmatchedInArrayComparision(actGridData, expNotesGridData);
			if(unmatchedNotesGridData.size()==0){
				report.reportPass("Verified Notes Grid Data successfully");
			}
			else{
				throw new Exception("Fail to verify Notes Grid data and unmatched data is: "+unmatchedNotesGridData);
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public String getDateValueFromNotesGrid() throws Exception{
		String actDateValue = null; String dateValueFromGrid =null;
		try{
			webActions.waitForPageLoaded();
			actDateValue = webActions.waitAndGetText(txt_NotesGridDateData, "DateValue");
			report.reportInfo("Date value is :"+actDateValue);
			dateValueFromGrid = actDateValue.substring(0,11);
			report.reportInfo("Expected Data is after split is : "+dateValueFromGrid);			
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
		return dateValueFromGrid;
	}

	public void verifyMaxLengthMsg(String data) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txtBox_NotesTextBox, "TextBox");
			report.reportPass("Notes Text Bos is displayed ");
			String textToEnter = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ "
					+ "ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			webActions.sendKeys(txtBox_NotesTextBox, textToEnter, "NotesTextBox");
			report.reportPass("Data is entered in Notes Text Box successfully");
			webActions.waitForPageLoaded();
			String maxTextMsg = webActions.getText(msg_MAxLengthMsg, "MaxLength");
			if(maxTextMsg.contentEquals(data)){
				report.reportPass("Max Length Message is displayed properly in Notes Tab");
			}else{
				throw new Exception("Failed to red Max Lenth Message is Notes Tab");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}

	public void verifyMinxLengthMsg(String data) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txtBox_NotesTextBox, "TextBox");
			report.reportPass("Notes Text Bos is displayed ");
			webActions.waitForPageLoaded();
			String minTextMsg = webActions.getText(msg_MAxLengthMsg, "MaxLength");
			if(minTextMsg.contentEquals(data)){
				report.reportPass("Max Length Message is displayed properly in Notes Tab");
			}else{
				throw new Exception("Failed to red Max Lenth Message is Notes Tab");
			}
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	
	
	public void verifySuccessMsgAfterCreatingNotes(String successMsgText, String conMsg, String notesData) throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.sendKeys(txtBox_NotesTextBox, notesData, "TextBox");
			report.reportPass("Notes entered successfully");
			webActions.waitForClickAbilityAndClick(btn_AddNotesInNotesWindow, "AddNotesBtn");
			report.reportPass("Clicked on Add Notes button");			
			//webActions.waitForVisibility(txt_FilterMsgs, "messages",1);
			//report.reportInfo("Filter message is displayed successfully as"+txt_FilterMsgs);		
			String msg=webActions.waitAndGetText(txt_FilterMsgs, "FilterMsgs");
			String[] titleContent=msg.split("\\n");
			String actTitle=titleContent[0];
			String actContent=titleContent[1];
			webActions.waitUntilListisDisplayed(txt_HeaderColumnNames, "GridColumns");
			report.reportPass("Grid Columns Names are displayed successfully");
			webActions.waitForPageLoaded();
			if((successMsgText.contentEquals(actTitle)) && (conMsg.contentEquals(actContent))){
				report.reportPass("Both title and content displayed properly");
			}
			else{
				throw new Exception("Both title and content are not displayed properly actual Title: "+actTitle+ "and actual content: "+actContent);
			}
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void enterSpecialCharacters() throws Exception{
		try{
			webActions.waitForPageLoaded();
			String value = "'`~!@#$%^&*()_-+={[}]<,>.?/;";
					
			webActions.waitForVisibility(txtBox_NotesTextBox, "NotesTextBox");
			report.reportPass("Notes Text Box is displayed");
			webActions.sendKeys(txtBox_NotesTextBox, value, "TextBox");
			report.reportPass("User can enter all special characters");
			
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}
	
	public void closeNotesWindow() throws Exception{
		try{
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(btn_CloseBtnOnNotesWindow, "CloseBtn",4);
			webActions.clickBYJS(btn_CloseBtnOnNotesWindow, "CloseBtn");
			Thread.sleep(3000);
			report.reportPass("Clicked on Closed button in Notes Window");
		}catch(Exception e){
			report.reportFail(e.getMessage());
		}
	}



	public AddNotesPage openIpasApp() {
		try {
			String URL = TestBase.prop.ipasURL();
			webActions.loadURL(URL);
			report.reportPass("Application opened successfully");
		} catch (Exception e) {
			report.reportHardFail(e, "Failed to Open iPAS application");
		}
		return (AddNotesPage) base(AddNotesPage.class);
	}


	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_UserName);
	}

}
