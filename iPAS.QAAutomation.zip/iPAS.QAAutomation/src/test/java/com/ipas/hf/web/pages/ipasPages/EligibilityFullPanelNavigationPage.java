package com.ipas.hf.web.pages.ipasPages;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class EligibilityFullPanelNavigationPage extends BasePage{
	
	AddPatientVisitPage addpatient=new AddPatientVisitPage();
	
	//Path
	@FindBy(xpath="//div[@class='header d-flex ng-star-inserted']/a[text()='Eligibility Verification']")
	private WebElement pnl_EligibilityVerification;
	
	@FindBy(xpath="//div[@class='breadcrum-container']/span")
	private List<WebElement> lbl_Breadcrumb;
	
	@FindBy(xpath = "//div[@id='parentEligibility']/p")
	private  List<WebElement> lst_pagetitle;
	
	@FindBy(xpath = "//div[@class='e-tab-text']//div[@class='ng-star-inserted']")
	private  List<WebElement> lst_tabs;
	
	@FindBy(xpath="//div[@id='allDataPasentDetails']")
	private WebElement lbl_PatientDetails;
	
	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[1]")
	private List<WebElement> lbl_patientInfoFields;
	
	@FindBy(xpath="//div[@class='e-indicator e-ignore']")
	private String tab_indicator;
	
	@FindBy(xpath="//div[@class='ng-star-inserted' and contains(text(),'PRIMARY')]")
	private WebElement tab_primary;
	
	private StepLogging log = StepLogging.getLoggingObject();
	
	public EligibilityFullPanelNavigationPage() {
		PageFactory.initElements(driver, this);
	}

	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}

	RestActions rest=new RestActions();
	HomePage homePage=new HomePage();
	
	//Methods
	public void verifyEligibilityVerificationPanel(){
		try {
			webActions.waitForPageLoaded();
			if(pnl_EligibilityVerification.isDisplayed()){
				report.reportPass("Successfully displayed the Eligibility Verification Panel");
			}
		else{
				throw new Exception("Fail to  display the Eligibility Verification Panel");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void clickEligibilityVerificationPanel(){
		try {
			webActions.waitForPageLoaded();
			if(pnl_EligibilityVerification.isDisplayed()){
				webActions.click(pnl_EligibilityVerification,"Click on Eligibility Verification Panel");
				report.reportPass("Successfully Clicked on the Eligibility Verification Panel");
				webActions.waitForPageLoaded();
			}
		else{
				throw new Exception("Fail to click the Eligibility Verification Panel");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyBreadcrumbinEligibilityVerificationPanel(DataTable breadcrumb ){
		try {
			ArrayList<String> expectdBreadcrumb = new ArrayList<>(breadcrumb.asList());
			webActions.waitForPageLoaded();
			ArrayList<String> actualBreadcrumb=webActions.getDatafromWebTable(lbl_Breadcrumb);
			report.reportInfo("Actual Breadcrumb Titles: "+actualBreadcrumb);
			report.reportInfo("Expected Breadcrumb Titles "+expectdBreadcrumb);
			ArrayList<String> unmatch=webActions.getUmatchedInArrayComparision(actualBreadcrumb, expectdBreadcrumb);
			if(unmatch.size()==0){
				report.reportPass("Successfully verified the Breadcrumb Titles in Edit Eligibility page");
			}else{
				throw new Exception("Fail to verify the Breadcrumb Titles in Edit Eligibility page: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyPageTitle(DataTable pagetitle){
		try {
			ArrayList<String> expLabelNames = new ArrayList<>(pagetitle.asList());
			report.reportInfo("Expected Page Title : "+expLabelNames);
			ArrayList<String> actLabelNames=webActions.getDatafromWebTable(lst_pagetitle);
			report.reportInfo("Displayed Page Title: "+actLabelNames);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actLabelNames, expLabelNames);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified Page Title as Eligilibity Verification Successfully");
			}
			else{
				throw new Exception("Fail to verify Page Title as Eligilibity Verification and unmatched Names are: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void verifyTabsAcross(DataTable tabs){
		try {
			ArrayList<String> expTabNames = new ArrayList<>(tabs.asList());
			report.reportInfo("Expected Tabs present across the page : "+expTabNames);
			ArrayList<String> actTabNames=webActions.getDatafromWebTable(lst_tabs);
			report.reportInfo("Displayed Tabs across the page: "+actTabNames);
			ArrayList<String>unmatchedFilterNames=webActions.getUmatchedInArrayComparision(actTabNames, expTabNames);
			if(unmatchedFilterNames.size()==0){
				report.reportPass("Verified Tabs across the Eligilibity Verification Successfully");
			}
			else{
				throw new Exception("Fail to verify Tabs across the Eligilibity Verification and unmatched Names are: "+unmatchedFilterNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
		public void verifyPatientInfoFields(DataTable fields){
			try {
				ArrayList<String> expectedPatientInfoFields = new ArrayList<>(fields.asList());
				report.reportInfo("Expected Patient Info Fields: "+expectedPatientInfoFields);
				webActions.waitUntilisDisplayed(lbl_PatientDetails, "Patient Info Details Panel");
				ArrayList<String> actualPatientInfoFields=webActions.getDatafromWebTable(lbl_patientInfoFields);
				report.reportInfo("Displayed Patient Info Fields in Application: "+actualPatientInfoFields);
				ArrayList<String>unmatchedPatientInfoFields=webActions.getUmatchedInArrayComparision(actualPatientInfoFields, expectedPatientInfoFields);
				if(unmatchedPatientInfoFields.size()==0){
					report.reportPass("Verified Patient Info fields in Eligibility Verification page");
				}
				else{
					throw new Exception("Fail to verify Patient Info fields in Eligibility Verification page and unmatched fields are: "+unmatchedPatientInfoFields);
				}
			} catch (Exception e) {
				report.reportFail(e.getMessage());
			}
		}
		
		public void verifyTabSelectedasIndicatorTab(){
			try {
				String expectedColor="#2854BD";
				webActions.waitForPageLoaded();
				webActions.click(tab_primary, "Primary");
				report.reportPass("Should click on Primary Tab Successfully");
				webActions.waitForPageLoaded();
				String actualColor = driver.findElement(By.xpath(tab_indicator)).getCssValue("color");
				if(expectedColor.contentEquals(actualColor))
				{
					report.reportPass("Selected Primary tab is Indicated in Blue Color");
				}
				else
				{
					throw new Exception("Fail to display indicator tab in blue color");
				}

			} catch (Exception e) {
				report.reportFail(e.getMessage());
			}
		}
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}