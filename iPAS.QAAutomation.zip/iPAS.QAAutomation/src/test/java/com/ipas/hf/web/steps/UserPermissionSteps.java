package com.ipas.hf.web.steps;

import java.util.Properties;

import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.utilities.ConfigProperties;
import com.ipas.hf.web.pages.ipasPages.AddPatientVisitPage;
import com.ipas.hf.web.pages.ipasPages.HomePage;
import com.ipas.hf.web.pages.ipasPages.Login;
import com.ipas.hf.web.pages.ipasPages.UserPermissionsPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

public class UserPermissionSteps {
	private ConfigProperties configProp = TestBase.prop;
	UserPermissionsPage userPermission = new UserPermissionsPage();
	AddPatientVisitPage addpatient = new AddPatientVisitPage();
	Login logIn = new Login();
	HomePage home = new HomePage();

	@Then("Click on Setting and verify the list of options")
	public void click_on_Setting_and_verify_the_list_of_options(DataTable options) {
		userPermission.verifySettingsOptions(options);
	}

	@Then("Verify the modules Names displayed for the logged in user")
	public void verify_the_modules_Names_displayed_for_the_logged_in_user(DataTable options) throws Exception {
		userPermission.verifyAccessibleModules(options);
	}
	
	@Then("Verify View Profile, Edit Profile")
	public void verify_View_Profile_Edit_Profile() throws Exception {
		userPermission.verifyEditProfile();
	}
	
	@Then("Verify View Profile, ResetPassword")
	public void verify_View_PRofile_ResetPassword() throws Exception {
		userPermission.verifyResetPassword();
	}
	
	@Then("Verify the modules Names displayed in Maintenance Module")
	public void verify_the_modules_Names_displayed_in_Maintenance_Module(DataTable options) throws Exception {
		userPermission.verifyMaintenanceModules(options);
	}

	@Then("Verify SubMenu options in Maintenance Module")
	public void verify_SubMenu_options_in_Maintenance_Module(DataTable options) throws Exception {
		userPermission.verifySubMenuOptionsOfMaintenanceModules(options);
	}
	
	@Then("Navigate to Payment FacilitatorPage from {string} page and visitid as {string}")
	public void navigate_to_Payment_FacilitatorPage_from_page_and_visitid_as(String pageName, String visitID) {
		userPermission.navigatetoPaymentFacilitatorPage(pageName,visitID);
	}
	
	@Then("Navigate to {string} module in Add Patient")
	public void Navigate_to_AddPatient_module(String module) throws Exception {
		if("AccountSearch".contentEquals(module))
		{
			userPermission.accountsearchtab();
		}
		else if("ServiceTracker".contentEquals(module))
		{
			userPermission.serviceTrackerPageValidation();
		}
		addpatient.navigateToAddPatient();
	}
}
