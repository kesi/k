package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.AddMedicalNecessityCustomResponsePage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class AddMedicalNecessityCustomResponseSteps {

	AddMedicalNecessityCustomResponsePage addResponce=new AddMedicalNecessityCustomResponsePage();
	
	@Then("Navigate to Add Custom Response page")
	public void navigate_to_Add_Custom_Response_page() {
		addResponce.navigateToAddCustomResponsePage();
	}
	
	@Then("Verify the Field Names in Add Custom Response page")
	public void verify_the_Field_Names_in_Add_Custom_Response_page(DataTable fieldNames) {
		addResponce.verifyTheFieldNames(fieldNames);
	}

	@Then("verify Breadcrumb in Add Custom Response page")
	public void verify_Breadcrumb_in_Add_Custom_Response_page(DataTable breadcrumb) {
		addResponce.verifyBreadcrumb(breadcrumb);
	}
	
	@Then("Verify mandatory field validation messages in Add Custom Response page")
	public void verify_mandatory_field_validation_messages_in_Add_Custom_Response_page(DataTable errorMessages) {
		addResponce.verifyMandatoryFieldValidationMessages(errorMessages);
	}
	
	@Then("Verify the Cancel button functionality in Add Custom Response page")
	public void verify_the_Cancel_button_functionality_in_Add_Custom_Response_page() {
		addResponce.verifyCancelButtonFunctionality();
	}
	
	@Then("Verify the Unsaved Changes Discard popup title as {string} and message as {string}")
	public void verify_the_Unsaved_Changes_Discard_popup_title_as_and_message_as(String alertTitle, String alertMessage) {
		addResponce.verifyTheUnsavedChangesDiscardPopup(alertTitle, alertMessage);
	}


	@Then("Add Custom Response Code")
	public void add_Custom_Response_Code(DataTable testData) {
	    addResponce.AddCustomResponse(testData);
	}
	
	@Then("Add Custom Response Code with all payers")
	public void add_Custom_Response_Code_with_all_payers(DataTable testData) {
		addResponce.AddCustomResponseWithAllPayers(testData);
	}
}
