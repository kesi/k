package com.ipas.hf.web.steps;

import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.ipasPages.EditNewsPage;
import com.ipas.hf.web.pages.ipasPages.SearchPayerPage;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.ipasPages.EditNewsPage;
import com.ipas.hf.web.pages.ipasPages.EditUserPage;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class SearchPayerSteps {

	SearchPayerPage searchpayer = new SearchPayerPage();
	RestActions rest=new RestActions();

	@Then("Navigate to configure payer codes")
	public void Verify_the_navigation_bar() throws InterruptedException {
		searchpayer.navigateToconfigurePayerCodes();
	}

	@Then("verify the search Criteria section")
	public void Verify_the_search_Criteria_section() {
		searchpayer.verifySearchCriteria();
	}

	@Then("verify the search field")
	public void Verify_the_search_field() {
		searchpayer.verifySearchfield();
	}

	@Then("verify the Connection field")
	public void Verify_the_Connection_field() {
		searchpayer.verifyConnectionfield();
	}

	@Then("verify the Apply or search button")
	public void Verify_the_apply_button() {
		searchpayer.verifyApplybutton();
	}

	@Then("verify if  search criteria yields no results")
	public void Verify_if_search_criteria_yields_no_results() {
		searchpayer.verifyNoResultsFound();
	}
}