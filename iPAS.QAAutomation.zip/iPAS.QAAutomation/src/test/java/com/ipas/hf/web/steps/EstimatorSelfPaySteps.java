package com.ipas.hf.web.steps;


import org.json.simple.parser.ParseException;

import com.ipas.hf.web.pages.ipasPages.EstimatorSelfPayPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class EstimatorSelfPaySteps {

	EstimatorSelfPayPage esp=new EstimatorSelfPayPage();


	
	@Then("Update Estimator Self Pay JSON file {string}")
	public void update_Estimator_Self_Pay_JSON_file(String estimateAmount) throws Throwable {
		esp.updateEstimatorSelfPayJSON(estimateAmount);
	}

	@Then("Navigate to the Estimator page")
	public void navigate_to_the_Estimator_page() {
		esp.navigateEstimatorFullpage();
	}

	@Then("Verify Estimator page for Self Pay")
	public void verify_Estimator_page_for_Self_Pay() {
		esp.verifyEstimatePageforSelfPay();
	}

	@Then("Edit the CPTCode")
	public void edit_the_CPTCode() {
		esp.editCPTCode();
	}

	@Then("Delete the CPTCode")
	public void delete_the_CPTCode() {
		esp.deleteCPTCode();
	}

	@Then("Add CPT Codes to Estimate")
	public void add_CPT_Codes_to_Estimate(DataTable testData) {
		esp.addCPTCode(testData);
	}

	@Then("Verify the Multi Procedure Discounting functionality for Self Pay")
	public void verify_the_Multi_Procedure_Discounting_functionality_for_Self_Pay(DataTable testData) {
		esp.verifyMultiProcedureDiscounting(testData);
	}

	@Then("Save the Estimate")
	public void save_the_Estimate() {
		esp.saveEstimate();
	}

	@Then("Confirm the Estimate")
	public void confirm_the_Estimate() {
		esp.confirmEstimate();
	}

	@Then("Click on Send To Payment Facilitator")
	public void click_on_Send_To_Payment_Facilitator() {
		esp.sendToPayementFacilitatorAndVerifyPaymentDetails();
	}
	
	@Then("Veirfy the Estimate Amount in Payment Facilitator")
	public void veirfy_the_Estimate_Amount_in_Payment_Facilitator() {
		esp.VerifyEstimateAmountinPaymentFacilitator();
	}

	@Then("Veirfy the Send Payment Facilitator Button")
	public void veirfy_the_Send_Payment_Facilitator_Button() {
	    esp.verifysendToPayementFacilitatorButton();
	}

	@Then("Navigate to Payment Facilitator page")
	public void navigate_to_Payment_Facilitator_page() {
		esp.navigatePaymentFacilitatorPage();
	}
	
	@Then("Navigate to Estimate From PaymentFacilitator")
	public void navigate_to_Estimate_From_PaymentFacilitator() {
	   esp.navigateToEstimateFromPaymentFacilitator();
	}
	
	@Then("Click on New Estimate")
	public void click_on_New_Estimate() {
		esp.clickNewEstimate();
	}

	@Then("Verify the View Estimate History")
	public void verify_the_View_Estimate_History(DataTable testData) {
		esp.verifyEstimateHistory(testData);
	}
	
	@Then("Switch to Estimate History and Verify the results")
	public void switch_to_Estimate_History_and_Verify_the_results(DataTable testData) {
		esp.switchToEstimateHistory(testData);
	}
	
	@Then("Verify the display of message if no note added")
	public void verify_the_display_of_message_if_no_note_added() {
		esp.verifyNoRecordsAddNoteWindow();
	}

	@Then("Verify the Add and View Note functionality")
	public void verify_the_Add_and_View_Note_functionality(DataTable testData) {
	    esp.addAndViewNotesforEstimate(testData);
	}
	
	@Then("Verify the Estimator Work Sheet for the Confirmed Status")
	public void verify_the_Estimator_Work_Sheet_for_the_Confirmed_Status() {
		esp.verifytheEstimatorWorkSheetforConfirmedStatus();
	}
	
	@Then("Verify the page navigation to Eligibility from Estimator and Navigate to Estimate from Needs Attention")
	public void verify_the_page_navigation_to_Eligibility_from_Estimator_and_Navigate_to_Estimate_from_Needs_Attention() {
	    esp.navigateToEstimateFromNeedsAttention();
	}
	
	@Then("Save Estimate with discount")
	public void save_Estimate_with_discount(DataTable testData) {
	   esp.calculateDiscountAmount(testData);
	}

	@Then("Update Estimate with discount")
	public void update_Estimate_with_discount(DataTable testData) {
		esp.calculateDiscountAmount(testData);
	}



}