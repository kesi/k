package com.ipas.hf.web.pages.ipasPages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.BasePage;

public class PatientVisitCardFinancialStatusPage extends BasePage {
	
	@FindBy(xpath = "//div[@class='card-body']/div/div/financial-clearance-status/img")
	private WebElement lbl_VisitCardFinancialStatus;
	
	@FindBy(xpath = "//div[@class='card-footer mod-status-container']/span/financial-clearance-status/img")
	private WebElement lbl_DigitalDocumentFinancialStatus;
	
	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[2]")
	private WebElement lbl_VisitSummaryData;
	@FindBy(xpath = "//button[@class='imgButton']/img")
	private WebElement lbl_VisitCard3Dots; 
	
	@FindBy(xpath = "//div[@class='st modal-content']/div")
	private WebElement lbl_ServiceTrackerPageStatus;

	@FindBy(xpath = "//div[@class='page-css']/span/img")	
	private WebElement lbl_ServiceTrackerPageStatusImg;
	
	@FindBy(xpath = "//ejs-checkbox/label/span[@class='e-icons e-frame']")
	private WebElement lbl_ServiceTrackerPageStatusPriorityChkBox; 

	@FindBy(xpath = "//ejs-checkbox/label/span[@class='e-icons e-frame e-check']")
	private WebElement lbl_ServiceTrackerPageStatusPriorityUnChkBox;

	@FindBy(xpath = "//button[contains(text(),'Submit')]")
	private WebElement lbl_ServiceTrackerPageStatusSubmitbtn;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;
	
	@FindBy(xpath = "//div[@class='st modal-header']/button")
	private WebElement btn_ServiceTrackerPopCross;
	

	public PatientVisitCardFinancialStatusPage() {
		PageFactory.initElements(driver, this);
	}
	
	/**To verify the visit card financial status from service tracker board**/
	public void verifyVisitCardFinancialStatus(){
		try {
			String actdefaultVisitCardStatus=webActions.getAttributeValue(lbl_VisitCardFinancialStatus, "src", "VisitCardFinancial");
			if(actdefaultVisitCardStatus.contains("error")){
				report.reportPass("Visit Card financial status is displayed as pending mode");
			}
			else{				
				report.reportFail("Visit card financial status is not displayed as pending mode and actual displayed image is : " + actdefaultVisitCardStatus, true);
			}
			String actdigitalStatus=webActions.getAttributeValue(lbl_DigitalDocumentFinancialStatus, "src", "DigitalDocumentFinancial");
			if(actdigitalStatus.contains("error_sm")){
				report.reportPass("Digital document financial status is displayed as pending mode");
			}
			else{				
				report.reportFail("Digital document financial status is not displayed as pending mode and actual displayed image is : " + actdigitalStatus);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}	
	
	public void changeServiceTrackerToReviewFromVisitCard(){
		try {
			webActions.waitForPageLoaded();	
			webActions.clickAction(lbl_VisitCard3Dots, "ServicetRacker");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_ServiceTrackerPageStatus, "ServiceStatusPage");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.clickAction(lbl_ServiceTrackerPageStatusImg, "StatusImg");
			webActions.waitForPageLoaded();
			Thread.sleep(10000);
			//webActions.waitForVisibility(lbl_ServiceTrackerPageStatusImgPriority, "HighPriorityWindow");
			webActions.click(lbl_ServiceTrackerPageStatusPriorityChkBox, "HighPriorityChkBox");
			webActions.waitForPageLoaded();
			webActions.clickAction(lbl_ServiceTrackerPageStatusSubmitbtn, "SubmitBtn");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txt_ToastMsgs, "toastmessages");
			webActions.waitForVisibility(btn_ServiceTrackerPopCross, "crossOption");
			webActions.waitForPageLoaded();
			report.reportPass("Service tracker module status saved successfully");

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	/**To verify the visit card financial status from service tracker board**/
	public void verifyVisitCardFinanceClearanceStatus(){
		try {
			String actdefaultVisitCardStatus=webActions.getAttributeValue(lbl_VisitCardFinancialStatus, "src", "VisitCardFinancial");			
			
			if(actdefaultVisitCardStatus.contains("error")){
				report.reportPass("Visit Card financial status is displayed as pending mode");
			}				
		
			else if(actdefaultVisitCardStatus.contains("success")){
				report.reportPass("Visit Card financial status is displayed as clear mode");
			}
			else if(actdefaultVisitCardStatus.contains("alert")){
				report.reportPass("Visit Card financial status is displayed as Pending review mode");
			}
			else{				
				report.reportFail("Visit card financial status is not displayed as expected mode and actual displayed image is : " + actdefaultVisitCardStatus, true);
			}
		}catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
