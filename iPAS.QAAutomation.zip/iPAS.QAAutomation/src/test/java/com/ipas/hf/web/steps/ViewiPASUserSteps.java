package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.AddNewUserPage;
import com.ipas.hf.web.pages.ipasPages.ViewiPASUserPage;

import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;

public class ViewiPASUserSteps {

	ViewiPASUserPage viewUser=new ViewiPASUserPage();
	AddNewUserPage addNewUser=new AddNewUserPage();

	@Then("Verify the Breadcrumb for ViewiPAS user")
	public void verify_the_Breadcrumb_for_ViewiPAS_user(DataTable breadcrumb) {
		viewUser.verifyBreadcrumbinViewiPASUserPage(breadcrumb);
	}

	@Then("Verify the display of user grid header names and fields and buttons")
	public void verify_the_display_of_user_grid_header_names_and_fields_and_buttons(DataTable fieldNames) {
		viewUser.verifyFieldNamesandButtonNames(fieldNames);
	}

	@Then("Verify the display of result count in view iPAS user page")
	public void verify_the_display_of_result_count_in_view_iPAS_user_page() {
		viewUser.verifyResultsCount();
	}

	@Then("Create new user and verify the assigned facility from view user grid and verify alert message as title {string} and content as {string}")
	public void create_new_user_and_verify_the_assigned_facility_from_view_user_grid_and_verify_alert_message_as_title_and_content_as(String messageTitle, String messageContent, DataTable testData) {
		String employeeName=addNewUser.createNewUser(testData, messageTitle, messageContent);
		viewUser.verifyUserData(employeeName, testData);
	}

	@Then("Create new user and open the facility window from view user grid and verify alert message as title {string} and content as {string}")
	public void create_new_user_and_open_the_facility_window_from_view_user_grid_and_verify_alert_message_as_title_and_content_as(String messageTitle, String messageContent, DataTable testData) {
		String employeeName=addNewUser.createNewUser(testData, messageTitle, messageContent);
		viewUser.clickOnFacilityLink();
		viewUser.verifyEmployeeName(employeeName);
		viewUser.verifyFacilityName(testData);
		//viewUser.verifyExpandAndCollapseOfFacilityWindow();
		viewUser.verifyDepartmentNameUnderFacility(testData);
		//viewUser.verifySuperviosrUnderDepartmentName(testData);
		viewUser.clickOnOkBtnVerfiyEmpName(testData);
	}
	@Then("Click on password icon and verify the details of pop-up")
	public void click_on_password_icon_and_verify_the_details_of_pop_up(DataTable dataTable) {
		viewUser.verifyPasswordRestPopUp(dataTable);
		viewUser.clickOnCancelBtnVerfiyEmpName();
	}
	@Then("Create new inactive user and verify the users from view user grid and verify alert message as title {string} and content as {string}")
	public void create_new_inactive_user_and_verify_the_users_from_view_user_grid_and_verify_alert_message_as_title_and_content_as(String messageTitle, String messageContent, DataTable testData) {
		String userName=addNewUser.createNewUser(testData, messageTitle, messageContent);
		viewUser.verifyUserNamesFromViewUserGrid(userName);
	}
	@Then("Create new user and verify the result grid based on search criteria in view user grid and verify alert message as title {string} and content as {string}")
	public void create_new_user_and_verify_the_result_grid_based_on_search_criteria_in_view_user_grid_and_verify_alert_message_as_title_and_content_as(String messageTitle, String messageContent,DataTable testData) {
		String userName=addNewUser.createNewUser(testData, messageTitle, messageContent);
		viewUser.verifyUserDisplayBasedOnSearch(userName);
	}

	@Then("Enter invalid data in Employee Name search field and verify the dispay of result count")
	public void enter_invalid_data_in_Employee_Name_search_field_and_verify_the_dispay_of_result_count() {
		viewUser.verifyResultCountOnNoResultsFound();
	}


}
