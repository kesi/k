package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.BasePage;


import io.cucumber.datatable.DataTable;

public class MedicalNecessityPage extends BasePage{

	@FindBy(xpath="//ipas-medical-necessity-check-info-panel//ul/li/div")
	private List<WebElement> txt_MedicalShortPanel;

	@FindBy(xpath="//ipas-medical-necessity-check-info-panel//img")
	private WebElement lbl_img_MedicalShortPanelModuleStatus;

	@FindBy(xpath="(//ipas-medical-necessity-add-check-config//img)[1]")
	private WebElement lbl_img_MedicalFullPanelModuleStatus;

	@FindBy(xpath="//ipas-medical-necessity-check-info-panel//span[contains(text(),'Review')]")
	private WebElement lbl_MedicalShortPanelModuleStatus;

	@FindBy(xpath="//ipas-medical-necessity-add-check-config//span[contains(text(),'Review')]")
	private WebElement lbl_MedicalLongPanelModuleStatus;

	@FindBy(xpath="//h2[contains(text(),'No Document/Form available for display')]")
	private WebElement lbl_MedicalLongPanelABNSection;

	@FindBy(xpath="//a[contains(text(),'Medical Necessity')]")
	private WebElement lbl_MedicalShortPanelLink;

	@FindBy(xpath="//ipas-medical-necessity-check-info-panel//div[@class='last-run-info ng-star-inserted']/p")
	private WebElement txt_MedicalShortLastRunBy;

	@FindBy(xpath="//ipas-medical-necessity-mn-check-info-detail-container//div[@class='last-run-info']/p")
	private WebElement txt_MedicalFullPanelLastRunBy;

	@FindBy(xpath="//ipas-medical-necessity-check-info-panel//ejs-accordion//div[@class='e-toggle-icon']/span")
	private WebElement icon_MedicalExpandCollapse; 

	@FindBy(xpath="//ipas-medical-necessity-check-info-panel//span[contains(text(),'Not Run')]")
	private WebElement lbl_MedicalShortPanelNotRunModuleStatus;

	@FindBy(xpath="//ipas-medical-necessity-add-check-config//span[contains(text(),'Not Run')]")
	private WebElement lbl_MedicalLongPanelNotRunModuleStatus;

	@FindBy(xpath="//td[contains(text(),'No records to display')]")
	private WebElement lbl_MedicalLongPanelDesc;

	@FindBy(xpath="//ipas-medical-necessity-add-check-config/div[1]")
	private WebElement lbl_MedicalLongPanel;

	@FindBy(xpath="//ipas-medical-necessity-add-check-config//div[@class='title ml-2']/span")
	private WebElement lbl_MedicalFullPanelTitle;

	@FindBy(xpath="//ipas-medical-necessity-add-check-config//div[@class='subtitle']")
	private WebElement lbl_MedicalFullPanelSubTitle;

	@FindBy(xpath="//ipas-medical-necessity-add-check-config//div[@class='icd-grid-header d-flex grid-item']/div[")
	private WebElement lbl_MedicalFullPanelICDHeaders;

	@FindBy(xpath="//ipas-medical-necessity-add-check-config//div[@class='cpt-grid-row grid-item']/div")
	private WebElement lbl_MedicalFullPanelCPTHeaders;

	@FindBy(xpath="//a[contains(text(),'New Medical Necessity Check')]")
	private WebElement Btn_MedicalFullPanelNewMedicalNecessityCheck;

	@FindBy(xpath="//ipas-medical-necessity-add-check-config//input")
	private WebElement Txt_MedicalFullPanelICDCode;

	@FindBy(xpath="(//ipas-medical-necessity-add-check-config//div[@class='mr-2'])[1]")
	private WebElement Txt_MedicalFullPanelICPTCode1;

	@FindBy(xpath="(//ipas-medical-necessity-add-check-config//div[@class='mr-2'])[4]")
	private WebElement Txt_MedicalFullPanelICPTCode2;

	@FindBy(xpath="//ipas-medical-necessity-add-check-config//a")
	private List<WebElement> lbl_MedicalFullPanelLinks;

	@FindBy(xpath="//ipas-medical-necessity-check-info-panel//span[contains(text(),'Fail')]")
	private WebElement lbl_MedicalShortPanelFailModuleStatus;

	@FindBy(xpath="//ipas-medical-necessity-add-check-config//span[contains(text(),'Fail')]")
	private WebElement lbl_MedicalLongPanelFailModuleStatus;

	@FindBy(xpath="//ipas-medical-necessity-add-check-config//span/img")
	private WebElement img_MedicalICDTrash;

	@FindBy(xpath="(//ipas-medical-necessity-add-check-config//div/img)[2]")
	private WebElement img_MedicalCPTTrash;

	@FindBy(xpath="//p[contains(text(),'ICD code is required.')]")
	private WebElement msg_MedicalICD;

	@FindBy(xpath="//span[contains(text(),'Not configured yet')]")
	private WebElement msg_MedicalCPT;

	@FindBy(xpath="//a[contains(text(),'Run')]")
	private WebElement Btn_MedicalFullPanelRun;

	@FindBy(xpath="//a[contains(text(),'Cancel')]")
	private WebElement Btn_MedicalFullPanelCancel;

	@FindBy(xpath="//ipas-medical-necessity-check-info-panel//span[contains(text(),'Pass')]")
	private WebElement lbl_MedicalShortPanelClearModuleStatus;

	@FindBy(xpath="//ipas-medical-necessity-add-check-config//span[contains(text(),'Pass')]")
	private WebElement lbl_MedicalLongPanelClearModuleStatus;

	@FindBy(xpath="//ipas-medical-necessity-mn-check-info-detail-container//div[@class='subtitle mb-2']")
	private WebElement lbl_MedicalNecessityResults;

	@FindBy(xpath="//tr[1]/th")
	private WebElement lbl_MedicalNecessityResultsHeaders;

	@FindBy(xpath="(//ipas-medical-necessity-add-check-config//a)[2]")
	private WebElement lnk_MedicalNecessityAddNewICD;

	@FindBy(xpath="(//ipas-medical-necessity-add-check-config//a)[3]")
	private WebElement lnk_MedicalNecessityAddNewCPT;

	@FindBy(xpath="//a[contains(text(),'Create ABN')]")
	private WebElement Btn_MedicalFullPanelABN;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs; 

	@FindBy(linkText="Payer Maintenance Configuration")
	private WebElement lnk_PayerMintenace;

	@FindBy(xpath="//select[@name='payerCode']/../input")
	private WebElement dd_PayerConfigure;

	@FindBy(xpath="//ejs-textbox[@id='search_text']//input")
	private WebElement txt_Search;

	@FindBy(xpath="//ejs-dropdownlist[@id='ddlelement']//input")
	private WebElement dd_Facility;

	@FindBy(linkText="Apply")
	private WebElement btn_Apply;

	@FindBy(xpath="//div[@class='e-gridcontent']//tbody/tr/td[1]/span[1]")
	private List<WebElement> tr_Rows;

	@FindBy(xpath="//ejs-switch[@role='switch']")
	private WebElement chk_AutoRun;

	@FindBy(xpath="//a[contains(text(),'Save')]")
	private WebElement btn_Save_MedNec;

	@FindBy(xpath="//ipas-medical-necessity-cpt-icd-footer//button[1]")
	private WebElement btn_ICD_Cancel;

	@FindBy(xpath="//ipas-medical-necessity-cpt-icd-footer//button[2]")
	private WebElement btn_ICD_Select;

	@FindBy(xpath="//h5[contains(text(),'icd')]")
	private WebElement lbl_ICDWindowTitle;

	@FindBy(xpath="//ipas-medical-necessity-cpt-icd-grid//tr/th[1]")
	private WebElement lbl_ICDHeaders;

	@FindBy(xpath="//ipas-medical-necessity-cpt-icd-grid//tr/th[2]")
	private WebElement lbl_ICDHeaders1;

	@FindBy(xpath="(//ipas-medical-necessity-cpt-icd-grid//tr[1]/td[1])[2]")
	private WebElement txt_ICDWindowMsg;

	@FindBy(xpath="//input[@placeholder='Type Code or Key Word']")
	private WebElement txt_ICDWindowSearch;

	@FindBy(xpath="//h5[contains(text(),'CPT')]")
	private WebElement lbl_CPTWindowTitle;

	@FindBy(xpath="//ipas-add-cpt-dialog//div[@class='cpt-grid-row grid-item']/div")
	private List<WebElement> lbl_CPTWindowHeaders;

	@FindBy(xpath="//div[contains(text(),'No facility charge master records are found matchi')]")
	private WebElement lbl_CPTWindowMsg;

	@FindBy(xpath="//ipas-add-cpt-dialog//button[1]")
	private WebElement btn_CPT_Cancel;

	@FindBy(xpath="//ipas-add-cpt-dialog//button[2]")
	private WebElement btn_CPT_Add;

	@FindBy(xpath="(//ipas-medical-necessity-cpt-icd-grid//tbody/tr)[2]/td[1]")
	private WebElement lbl_ICDSearchResultsRow;

	@FindBy(xpath="//ipas-add-cpt-dialog//div[@class='grid-items']/div[1]")
	private WebElement lbl_CPTSearchResultsRow;

	@FindBy(xpath="(//ipas-medical-necessity-add-check-config//span)[5]")
	private WebElement lbl_CPTCodeMsg;

	@FindBy(xpath="(//ipas-breadcrumb//span/a)[2]")
	private WebElement lbl_AccountNumber;


	public MedicalNecessityPage() {
		PageFactory.initElements(driver, this);
	}


	public void verifyMedicalPanel(String panel,DataTable testdata){
		try {
			ArrayList<String> actualPanelText =new ArrayList<String>();
			ArrayList<String> expPanelTitle=new ArrayList<>(testdata.asList());		
			report.reportInfo("Expected short panel info: "+expPanelTitle);

			if(panel.contentEquals("Short Panel")){
				webActions.waitForVisibilityOfAllElements(txt_MedicalShortPanel, "PanelText");			    
				actualPanelText.addAll(webActions.getDatafromWebTable(txt_MedicalShortPanel));
				report.reportInfo("Displayed Short Panel text: "+actualPanelText);
			}
			else if(panel.contentEquals("Full Panel")){

			}
			ArrayList<String>unmatchedShortPanelInfo=webActions.getUmatchedInArrayComparision(actualPanelText, expPanelTitle);
			if(unmatchedShortPanelInfo.size()==0){
				report.reportPass("Verified successfully" +panel+  "information");
			}
			else{
				throw new Exception("Fail to verify medical" +panel+ "information and unmatched data is: "+unmatchedShortPanelInfo);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyMedicalPanelModuletStatus(String panel, String data){
		try {
			String moduleStatus = "";
			if("Short Panel".contentEquals(panel)){
				webActions.waitForVisibility(lbl_img_MedicalShortPanelModuleStatus, "ModuleStatus");
				moduleStatus=webActions.getAttributeValue(lbl_img_MedicalShortPanelModuleStatus, "src", "MedicalShortPanel");
			}			
			else if("Full Panel".contentEquals(panel)){
				webActions.waitForVisibility(lbl_img_MedicalFullPanelModuleStatus, "ModuleStatus");
				moduleStatus=webActions.getAttributeValue(lbl_img_MedicalFullPanelModuleStatus, "src", "MedicalShortPanel");
			}

			if("Fail".contentEquals(data)){
				if(moduleStatus.contains("error_sm")){
					report.reportPass("Verified Medical" +panel+ "module status when fail");
				}
			}
			else if("Clear".contentEquals(data)||"Not Run".contentEquals(data)){
				if(moduleStatus.contains("success_sm")){
					report.reportPass("Verified Medical" +panel+ "module status");
				}
			}
			else if("Review".contentEquals(data)){
				if(moduleStatus.contains("alert_sm")){
					report.reportPass("Verified Medical" +panel+ "module status");
				}
			}
			else{
				report.reportFail("Fail to verify postal" +panel+ "module status and actual displayed image is : " + moduleStatus);
			}		
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifymoduleStatus(String status){
		ArrayList<String> actualText=new ArrayList<String>();	
		try {
			if("Review".contentEquals(status)){
				actualText.add(webActions.getText(lbl_MedicalShortPanelModuleStatus, "StatusName"));
				clickOnMedicalShortPanel();
				actualText.add(webActions.getText(lbl_MedicalLongPanelModuleStatus, "StatusName"));
			}
			else if("Not Run".contentEquals(status)){
				actualText.add(webActions.getText(lbl_MedicalShortPanelNotRunModuleStatus, "StatusName"));
				clickOnMedicalShortPanel();
				actualText.add(webActions.getText(lbl_MedicalLongPanelNotRunModuleStatus, "StatusName"));
			}
			else if("Fail".contentEquals(status)){
				actualText.add(webActions.getText(lbl_MedicalShortPanelFailModuleStatus, "StatusName"));
				clickOnMedicalShortPanel();
				actualText.add(webActions.getText(lbl_MedicalLongPanelFailModuleStatus, "StatusName"));
			}
			else if("Pass".contentEquals(status)){
				actualText.add(webActions.getText(lbl_MedicalShortPanelClearModuleStatus, "StatusName"));
				clickOnMedicalShortPanel();
				actualText.add(webActions.getText(lbl_MedicalLongPanelClearModuleStatus, "StatusName"));
			}
			ArrayList<String>unmatchedInfo=webActions.isFullArrayMatchWithData(actualText, status);
			if(unmatchedInfo.size()==0){
				report.reportPass("Verified medical necessity module status successfully");
			}
			else{
				throw new Exception("Fail to verify medical module status and unmatched data is: "+unmatchedInfo);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnMedicalShortPanel(){
		try {
			webActions.click(lbl_MedicalShortPanelLink, "SHortPanelLink");
			webActions.waitForPageLoaded();			
			//webActions.waitForVisibility(lbl_MedicalLongPanel, "LongPanel");			
			Thread.sleep(5000);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyLastRunByInMedicalPanel(){
		String actCurrentDateTime = null; String expCurrentDateTime = null; String increasedCurrentDateTime = null;String fullPanelCurrentDateTime = null;
		try {
			webActions.waitForPageLoaded();
			String actCurrentDate = webActions.waitAndGetText(txt_MedicalShortLastRunBy, "LastRunDateTime");
			actCurrentDateTime=actCurrentDate.replace(",", "");			
			report.reportInfo("Dsiplayed last run date from application: "+actCurrentDateTime);			
			String expCurrentDate = webActions.getCurrentSystemDateTime();
			String increasedTime=webActions.getIncreasedCurrentSystemDateTime(3);
			expCurrentDateTime="Last ran by Auto "+ expCurrentDate;
			increasedCurrentDateTime="Last ran by Auto "+ increasedTime;
			report.reportInfo("system current date time: "+expCurrentDateTime);
			if(actCurrentDateTime.contentEquals(expCurrentDateTime)||actCurrentDateTime.contentEquals(increasedCurrentDateTime))
			{
				report.reportPass("Verified last run by date and time");
			}else{
				report.reportFail("Failed to verify last run by date and time",true);
			}
			clickOnMedicalShortPanel();
			String fullPanelCurrentDate = webActions.waitAndGetText(txt_MedicalFullPanelLastRunBy, "LastRunDateTime");
			fullPanelCurrentDateTime=fullPanelCurrentDate.replace(",", "");			
			report.reportInfo("Dsiplayed last run date from application: "+actCurrentDateTime);

			if(fullPanelCurrentDateTime.contentEquals(expCurrentDateTime)||fullPanelCurrentDateTime.contentEquals(increasedCurrentDateTime))
			{
				report.reportPass("Verified last run by date and time in Medical full panel");
			}else{
				report.reportFail("Failed to verify last run by date and time in Medical full panel");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyExpandandCollapsPostalPanel() throws Exception{
		StringBuilder unmatch=new StringBuilder();		
		webActions.waitForVisibility(lbl_MedicalShortPanelModuleStatus, "ModuleStatus");		
		String actualExpandStatus=webActions.getAttributeValue(icon_MedicalExpandCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons e-expand-icon".contentEquals(actualExpandStatus)){			
			report.reportPass("By default short Panel is displayed in Expand mode");
		}else{
			unmatch.append("Panle is not dispalyed in Expand mode by default");
			report.reportFail("Medical Necessity Panel is not dispalyed in Expand mode by default");
		}
		webActions.waitAndClick(icon_MedicalExpandCollapse, "ExpandandCollapse");
		webActions.waitForPageLoaded();
		String actualCollapseStatus=webActions.getAttributeValue(icon_MedicalExpandCollapse, "class", "ExpandandCollapse");
		if("e-tgl-collapse-icon e-icons".contentEquals(actualCollapseStatus)){
			report.reportPass("Postal Panel Successfully Collapsed");
		}
		else{
			unmatch.append("Medical Necessity Panle is not Collapsed");
			report.reportFail("Medical Necessity Panel is not Collapsed");
		}		
		if(unmatch.length()==0){
			report.reportPass("Medical Necessity Panel Successfully Expanded and Collapsed");
		}else{
			report.reportFail("Failed to verify the Expand and Collapse of the Medical Necessity Panel"+unmatch);
		}
		webActions.waitAndClick(icon_MedicalExpandCollapse, "ExpandandCollapse");
		webActions.waitForPageLoaded();
	}

	public void verifyMedicalFullPanelFields(DataTable testdata){

		try {
			webActions.waitForPageLoaded();
			ArrayList<String> expPanelFields=new ArrayList<>(testdata.asList());
			ArrayList<String> actPanelFields=new ArrayList<>();
			actPanelFields.add(webActions.getText(lbl_MedicalFullPanelTitle, "Title").trim());
			actPanelFields.add(webActions.getText(lbl_MedicalFullPanelSubTitle, "SubTitle").trim());
			for (int i = 1; i <=3; i++) {
				String xpath1="//ipas-medical-necessity-add-check-config//div[@class='icd-grid-header d-flex grid-item']/div";
				String xpath2 = xpath1+"["+i+"]";
				WebElement field=driver.findElement(By.xpath(xpath2));	
				if(i==1||i==2){
					actPanelFields.add(webActions.getText(field, "ICDHeaders"));					
				}
				else{
					continue;
				}
			}
			for (int i = 1; i <=5; i++) {
				String xpath1="//ipas-medical-necessity-add-check-config//div[@class='cpt-grid-row grid-item']/div";
				String xpath2 = xpath1+"["+i+"]";
				WebElement field=driver.findElement(By.xpath(xpath2));	
				if(i==1||i==2||i==3||i==4){
					actPanelFields.add(webActions.getText(field, "CPTHeaders"));					
				}
				else{
					continue;
				}
			}
			actPanelFields.add(webActions.getText(Btn_MedicalFullPanelNewMedicalNecessityCheck, "Button"));
			ArrayList<String>unmatchedInfo=webActions.getUmatchedInArrayComparision(actPanelFields, expPanelFields);
			if(unmatchedInfo.size()==0){
				report.reportPass("Verified medical necessity full panel fields successfully");
			}
			else{
				throw new Exception("Fail to verify medicalfull panel fields and unmatched data is: "+unmatchedInfo);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyICDCodeMode(String mode){
		try {
			String actMode=webActions.getAttributeValue(Txt_MedicalFullPanelICDCode, "class", "ICDCode");
			if("disabled".contentEquals(mode)){				
				if(actMode.contentEquals("e-input form-control code ng-untouched ng-pristine")){
					report.reportPass("ICD code mode verified successfully");
				}
				else{
					report.reportFail("Fail to verify ICD code mode and displayed mode is: " +actMode);
				}
			}
			else if("enabled".contentEquals(mode)){
				boolean flag=Txt_MedicalFullPanelICDCode.isEnabled();
				if(flag){
					report.reportPass("ICD code mode verified successfully");
				}
				/*if(actMode.contentEquals("e-input form-control code ng-untouched ng-pristine ng-valid")){
					report.reportPass("ICD code mode verified successfully");
				}*/
				else{
					report.reportFail("Fail to verify ICD code mode and displayed mode is: " +flag);
				}
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}
	public void verifyICDAndCPTCodes(){
		try {
			ArrayList<String> expCodes=webActions.notepadReadToList("hello");
			ArrayList<String> actCodes=new ArrayList<>();
			actCodes.add(webActions.getText(Txt_MedicalFullPanelICDCode, "ICDCode"));
			actCodes.add(webActions.getText(Txt_MedicalFullPanelICPTCode1, "CPTCode"));
			actCodes.add(webActions.getText(Txt_MedicalFullPanelICPTCode2, "CPTCode"));
			report.reportInfo("actual codes: "+actCodes);
			report.reportInfo("expected codes: "+expCodes);
			ArrayList<String>unmatchedInfo=webActions.getUmatchedInArrayComparision(actCodes, expCodes);
			if(unmatchedInfo.size()==0){
				report.reportPass("Verified medical necessity ICD/CPT codes successfully");
			}
			else{
				throw new Exception("Fail to verify medical necessity ICD/CPT codes and unmatched data is: "+unmatchedInfo);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyMedicalFullPanelLinksAndButtons(DataTable testdata){

		try {
			webActions.waitForPageLoaded();
			clickOnMedicalCheck();			
			ArrayList<String> expPanelFields=new ArrayList<>(testdata.asList());
			ArrayList<String> actPanelFields=new ArrayList<>();
			actPanelFields.addAll(webActions.getDatafromWebTable(lbl_MedicalFullPanelLinks));
			ArrayList<String>unmatchedInfo=webActions.getUmatchedInArrayComparision(actPanelFields, expPanelFields);
			if(unmatchedInfo.size()==0){
				report.reportPass("Verified medical necessity full panel fields successfully");
			}
			else{
				throw new Exception("Fail to verify medicalfull panel fields and unmatched data is: "+unmatchedInfo);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickOnMedicalCheck(){
		try {
			webActions.click(Btn_MedicalFullPanelNewMedicalNecessityCheck, "Button");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_MedicalFullPanelLinks, "fields");
			Thread.sleep(1000);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyICDandCPTmessages(DataTable testdata){

		try {
			webActions.waitForPageLoaded();
			clickOnMedicalCheck();			
			ArrayList<String> expPanelFields=new ArrayList<>(testdata.asList());
			ArrayList<String> actPanelFields=new ArrayList<>();
			webActions.click(img_MedicalICDTrash, "ICDDeletion");
			webActions.waitForPageLoaded();
			webActions.click(img_MedicalCPTTrash, "CPTDeletion");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(msg_MedicalICD, "ICD");
			webActions.waitForVisibility(msg_MedicalCPT, "CPT");

			actPanelFields.add(webActions.getText(msg_MedicalICD, "ICDMSG"));
			actPanelFields.add(webActions.getText(msg_MedicalCPT, "CPTMSG"));			

			ArrayList<String>unmatchedInfo=webActions.getUmatchedInArrayComparision(actPanelFields, expPanelFields);
			if(unmatchedInfo.size()==0){
				report.reportPass("Verified medical necessity ICD and CPT msgs successfully");
			}
			else{
				throw new Exception("Fail to verify medical necessity ICD and CPT msgs and unmatched data is: "+unmatchedInfo);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyRunBtnMode(String mode){
		try {
			String actMode=webActions.getAttributeValue(Btn_MedicalFullPanelRun, "class", "RunBtn");
			if("disabled".contentEquals(mode)){				
				if(actMode.contentEquals("btn disabled btn--gray btn--blue")){
					report.reportPass("Run button mode verified successfully");
				}
				else{
					report.reportFail("Fail to verify Run button mode and displayed mode is: " +actMode);
				}
			}
			else if("enabled".contentEquals(mode)){
				if(actMode.contentEquals("btn btn--blue")){
					report.reportPass("Run button mode verified successfully");
				}
				else{
					report.reportFail("Fail to verify run button mode and displayed mode is: " +actMode);
				}
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	public void verifyNavigation(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(Btn_MedicalFullPanelCancel, "CancelBtn");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(Btn_MedicalFullPanelNewMedicalNecessityCheck, "NecessitycheckBtn");
			boolean flag=Btn_MedicalFullPanelNewMedicalNecessityCheck.isDisplayed();
			if(flag){
				report.reportPass("Verified navigation successfully");
			}
			else{
				report.reportFail("Fail to verify navigation on selecting the cancel button");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}
	public void verifyMedicalNecessityResults(String type,DataTable testdata){

		try {
			webActions.waitForPageLoaded();
			ArrayList<String> expPanelFields=new ArrayList<>(testdata.asList());
			ArrayList<String> actPanelFields=new ArrayList<>();

			if("Headers".contentEquals(type)){
				actPanelFields.add(webActions.getText(lbl_MedicalNecessityResults, "Title").trim());
				for (int i =1;i<=7;i++) {
					String xpath1="//tr[1]/th";
					String xpath2 = xpath1+"["+i+"]";
					WebElement field=driver.findElement(By.xpath(xpath2));	
					if(i==2||i==3||i==4||i==5||i==6||i==7){
						actPanelFields.add(webActions.getText(field, "ResultsHeaders"));					
					}
					else{
						continue;
					}
				}
			}
			else if("Results".contentEquals(type)){
				for (int i =1;i<=6;i++) {
					String xpath1="(//tr[1]/td";
					String xpath2 = xpath1+"["+i+"])[2]";
					WebElement field=driver.findElement(By.xpath(xpath2));	
					if(i==2||i==3||i==4||i==5||i==6){
						actPanelFields.add(webActions.getText(field, "Results"));					
					}
					else{
						continue;
					}
				}
			}

			ArrayList<String>unmatchedInfo=webActions.getUmatchedInArrayComparision(actPanelFields, expPanelFields);
			if(unmatchedInfo.size()==0){
				report.reportPass("Verified medical necessity results headers successfully");
			}
			else{
				throw new Exception("Fail to verify medical necessity results headers and unmatched data is: "+unmatchedInfo);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyFieldsForNotRun(DataTable testdata){
		try {
			ArrayList<String> expPanelFields=new ArrayList<>(testdata.asList());
			ArrayList<String> actPanelFields=new ArrayList<>();
			webActions.waitForVisibility(msg_MedicalICD, "ICD");
			actPanelFields.add(webActions.getText(msg_MedicalICD, "ICDMSG"));
			actPanelFields.add(webActions.getText(lbl_MedicalLongPanelDesc, "Results"));
			actPanelFields.add(webActions.getText(lnk_MedicalNecessityAddNewICD, "ICDLink"));
			actPanelFields.add(webActions.getText(lnk_MedicalNecessityAddNewCPT, "CPTLink"));

			ArrayList<String>unmatchedInfo=webActions.getUmatchedInArrayComparision(actPanelFields, expPanelFields);
			if(unmatchedInfo.size()==0){
				report.reportPass("Verified medical necessity fields successfully");
			}
			else{
				throw new Exception("Fail to verify medical necessity fields and unmatched data is: "+unmatchedInfo);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyCreateABNBtnMode(String mode){
		try {
			String actMode=webActions.getAttributeValue(Btn_MedicalFullPanelABN, "class", "RunBtn");
			if("disabled".contentEquals(mode)){				
				if(actMode.contentEquals("btn disabled btn--gray btn--flat-blue")){
					report.reportPass("ABN button mode verified successfully");
				}
				else{
					report.reportFail("Fail to verify ABN button mode and displayed mode is: " +actMode);
				}
			}
			else if("enabled".contentEquals(mode)){
				if(actMode.contentEquals("btn btn--blue")){
					report.reportPass("ABN button mode verified successfully");
				}
				else{
					report.reportFail("Fail to verify ABN button mode and displayed mode is: " +actMode);
				}
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}
	public void clickPayerMintenace() throws Exception{
		webActions.waitAndClick(lnk_PayerMintenace, "Payer Mintenace");
		webActions.waitForPageLoaded();
		webActions.waitForJSandJQueryToLoad();
		webActions.waitForVisibility(dd_PayerConfigure, "Payer Configure");
	}
	public void navigateFacilityConfig(String moduleName,String plan_Name_Code,String facility) throws Exception{
		webActions.sendKeys(dd_PayerConfigure, moduleName, "Payer Configure");
		webActions.waitForPageLoaded();
		webActions.sendKeys(txt_Search, plan_Name_Code, "Search");
		webActions.waitForPageLoaded();
		webActions.sendKeys(dd_Facility, facility, "Facility");
		webActions.waitForPageLoaded();
		webActions.waitAndClick(btn_Apply, "Apply");
		try {
			webActions.waitForVisibilityOfAllElements(tr_Rows, "Facility Names");
		} catch (Exception e) {
		}
	}

	public void medNecAutoRunTurnOnAndTrunOff(String moduleName,String plan_Name_Code,String facility,String runStatus) throws Exception{
		try {
			clickPayerMintenace();
			navigateFacilityConfig(moduleName,plan_Name_Code,facility);
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			for (WebElement webElement : tr_Rows) {
				String txt=webElement.getText();
				if(plan_Name_Code.contentEquals(txt)){
					webElement.click();
					webActions.waitForPageLoaded();
					break;
				}
			}

			String actAutoRunStatus=webActions.getAttributeValue(chk_AutoRun, "aria-checked", "Auto Run");
			if("AutoRunYes".contentEquals(runStatus)){
				if(!actAutoRunStatus.contentEquals("true")){
					webActions.waitForVisibility(chk_AutoRun, "Auto Run");
					webActions.click(chk_AutoRun, "Auto Run");

					webActions.click(btn_Save_MedNec, "Save");
					String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
					String[] titleContent=msg.split("\\n");
					String actContent=titleContent[1];
					if("Updated successfully.".contentEquals(actContent)){
						report.reportPass("Successfully saved the settings: "+msg);
					}else{
						report.reportFail("Failed to save the settings", true);
					}
				}
				report.reportPass("Auto Run already in On");
			}else if("AutoRunNo".contentEquals(runStatus)){
				if(actAutoRunStatus.contentEquals("true")){
					webActions.waitForVisibility(chk_AutoRun, "Auto Run");
					webActions.click(chk_AutoRun, "Auto Run");

					webActions.click(btn_Save_MedNec, "Save");
					String msg=webActions.waitAndGetText(txt_ToastMsgs, "Messages");
					String[] titleContent=msg.split("\\n");
					String actContent=titleContent[1];
					if("Updated successfully.".contentEquals(actContent)){
						report.reportPass("Successfully saved the settings: "+msg);
					}else{
						report.reportFail("Failed to save the settings", true);
					}
				}
				report.reportPass("Auto Run already in Off");
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage(), true);
		}
	}
	public void verifyICDWindowFields(DataTable testdata){
		try {
			ArrayList<String> expPanelFields=new ArrayList<>(testdata.asList());
			ArrayList<String> actPanelFields=new ArrayList<>();
			webActions.waitForVisibility(msg_MedicalICD, "ICD");
			webActions.click(Txt_MedicalFullPanelICDCode, "ICDCode");
			webActions.waitForVisibility(btn_ICD_Cancel, "ICDCancel");
			Thread.sleep(2000);			
			actPanelFields.add(webActions.getText(lbl_ICDWindowTitle, "ICDCode"));
			actPanelFields.add(webActions.getText(lbl_ICDHeaders, "ICdHeader"));
			actPanelFields.add(webActions.getText(lbl_ICDHeaders1, "ICdHeader"));
			actPanelFields.add(webActions.getText(txt_ICDWindowMsg, "MSG"));

			ArrayList<String>unmatchedInfo=webActions.getUmatchedInArrayComparision(actPanelFields, expPanelFields);
			if(unmatchedInfo.size()==0){
				report.reportPass("Verified medical necessity fields successfully");
			}
			else{
				throw new Exception("Fail to verify medical necessity fields and unmatched data is: "+unmatchedInfo);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyICDValidationMsg(String input){
		try {
			webActions.sendKeys(txt_ICDWindowSearch, "dsfcg", "SearchBox");
			webActions.waitForVisibility(txt_ICDWindowMsg, "ICDMsg");
			String msg=webActions.getText(txt_ICDWindowMsg, "MSG");			
			if(msg.contentEquals(input)){
				report.reportPass("ICD msg verified successfully");
			}
			else{
				report.reportFail("Fail to verify ICD msg and displayed msg is: " +msg);
			}			
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyICDNavigation(){
		try {
			webActions.click(btn_ICD_Cancel, "ICDCancel");
			webActions.waitForVisibility(msg_MedicalICD, "msg");
			String msg=webActions.getText(msg_MedicalICD, "msg");
			if(msg.contentEquals("ICD code is required.")){
				report.reportPass("verified navigation successfully");
			}
			else{
				report.reportFail("Fail to verify ICD window navigation and displayed msg is: " +msg);
			}	
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyCPTWindowFields(DataTable testdata){
		try {
			ArrayList<String> expPanelFields=new ArrayList<>(testdata.asList());
			ArrayList<String> actPanelFields=new ArrayList<>();
			webActions.waitForVisibility(lnk_MedicalNecessityAddNewCPT, "CPTLink");
			webActions.click(lnk_MedicalNecessityAddNewCPT, "CPTLink");
			webActions.waitForVisibility(btn_CPT_Cancel, "CPTCancel");
			Thread.sleep(2000);			
			actPanelFields.add(webActions.getText(lbl_CPTWindowTitle, "CPTtitle"));
			actPanelFields.addAll(webActions.getDatafromWebTable(lbl_CPTWindowHeaders));
			actPanelFields.add(webActions.getText(lbl_CPTWindowMsg, "CPTMsg"));		  

			ArrayList<String>unmatchedInfo=webActions.getUmatchedInArrayComparision(actPanelFields, expPanelFields);
			if(unmatchedInfo.size()==0){
				report.reportPass("Verified medical necessity CPT window fields successfully");
			}
			else{
				throw new Exception("Fail to verify medical necessity CPT window fields and unmatched data is: "+unmatchedInfo);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyCPTValidationMsg(String input){
		try {
			webActions.sendKeys(txt_ICDWindowSearch, "0000", "SearchBox");
			webActions.waitForVisibility(lbl_CPTWindowMsg, "CPTMsg");
			String msg=webActions.getText(lbl_CPTWindowMsg, "MSG");			
			if(msg.contentEquals(input)){
				report.reportPass("CPT msg verified successfully");
			}
			else{
				report.reportFail("Fail to verify CPT msg and displayed msg is: " +msg);
			}			
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyCPTNavigation(){
		try {
			webActions.click(btn_CPT_Cancel, "CPTCancel");
			webActions.waitForVisibility(lnk_MedicalNecessityAddNewCPT, "CPTLInk");
			String msg=webActions.getText(lnk_MedicalNecessityAddNewCPT, "CPTLink");
			if(msg.contentEquals("Add New CPT")){
				report.reportPass("verified navigation successfully");
			}
			else{
				report.reportFail("Fail to verify CPT window navigation and displayed msg is: " +msg);
			}	
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void selectICDCode(String code){
		try {
			webActions.waitForPageLoaded();			
			webActions.click(Txt_MedicalFullPanelICDCode, "ICDCode");
			webActions.waitForVisibility(btn_ICD_Cancel, "ICDCancel");
			Thread.sleep(1000);
			webActions.sendKeys(txt_ICDWindowSearch, code, "SearchBox");
			webActions.waitForVisibility(lbl_ICDSearchResultsRow, "ICDROw");
			Thread.sleep(3000);
			webActions.waitAndClick(lbl_ICDSearchResultsRow, "ICDROw");
			webActions.waitForClickAbilityAndClick(btn_ICD_Select, "Select");
			webActions.waitForPageLoaded();	
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void selectCPTCode(String code){
		try {
			webActions.waitForVisibility(lnk_MedicalNecessityAddNewCPT, "CPTLink");
			webActions.click(lnk_MedicalNecessityAddNewCPT, "CPTLink");
			webActions.waitForVisibility(btn_CPT_Cancel, "CPTCancel");
			Thread.sleep(2000);
			webActions.sendKeys(txt_ICDWindowSearch, code, "SearchBox");
			webActions.waitForVisibility(lbl_CPTSearchResultsRow, "CPTROw");
			Thread.sleep(2000);
			webActions.click(lbl_CPTSearchResultsRow, "CPTROw");
			webActions.waitForClickAbilityAndClick(btn_CPT_Add, "Add");
			webActions.waitForPageLoaded();
			Thread.sleep(2000);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyCPTMsg(String expMsg){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_CPTCodeMsg, "CPTMsg");
			String cptMsg=webActions.getText(lbl_CPTCodeMsg, "CPTMsg");
			if(cptMsg.contentEquals(expMsg)){
				report.reportPass("verified cpt code message successfully");
			}
			else{
				report.reportFail("Fail to verify CPT code message and displayed msg is: " +cptMsg);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void clickOnRunBtn(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(Btn_MedicalFullPanelRun, "RunBtn");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(Btn_MedicalFullPanelNewMedicalNecessityCheck, "NecessityCheck");
			webActions.waitForPageLoaded();
			Thread.sleep(2000);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyCPTcodes(DataTable testdata){
		try {
			ArrayList<String> expCodes=new ArrayList<>(testdata.asList());
			ArrayList<String> actCodes=new ArrayList<>();
			actCodes.add(webActions.getText(Txt_MedicalFullPanelICPTCode1, "CPTCode"));
			actCodes.add(webActions.getText(Txt_MedicalFullPanelICPTCode2, "CPTCode"));
			report.reportInfo("actual codes: "+actCodes);
			report.reportInfo("expected codes: "+expCodes);

			ArrayList<String>unmatchedInfo=webActions.getUmatchedInArrayComparision(actCodes, expCodes);
			if(unmatchedInfo.size()==0){
				report.reportPass("Verified medical necessity CPT codes successfully");
			}
			else{
				throw new Exception("Fail to verify medical necessity CPT codes and unmatched codes are: "+unmatchedInfo);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void verifyLastRunByInMedicalPanel_Manual(){
		String actCurrentDateTime = null; String expCurrentDateTime = null; String increasedCurrentDateTime = null;String fullPanelCurrentDateTime = null;
		try {
			webActions.waitForPageLoaded();
			String expCurrentDate = webActions.getCurrentSystemDateTime();
			String increasedTime=webActions.getIncreasedCurrentSystemDateTime(1);
			expCurrentDateTime="Last ran by Kesireddy Yenugu "+ expCurrentDate;
			increasedCurrentDateTime="Last ran by Kesireddy Yenugu "+ increasedTime;
			report.reportInfo("system current date time: "+expCurrentDateTime);
			String fullPanelCurrentDate = webActions.waitAndGetText(txt_MedicalFullPanelLastRunBy, "LastRunDateTime");
			fullPanelCurrentDateTime=fullPanelCurrentDate.replace(",", "");			
			report.reportInfo("Dsiplayed last run date from application: "+fullPanelCurrentDateTime);

			if(fullPanelCurrentDateTime.contentEquals(expCurrentDateTime)||fullPanelCurrentDateTime.contentEquals(increasedCurrentDateTime))
			{
				report.reportPass("Verified last run by date and time in Medical full panel");
			}else{
				report.reportFail("Failed to verify last run by date and time in Medical full panel",true);
			}

			clickonAccountNumber();

			String actCurrentDate = webActions.waitAndGetText(txt_MedicalShortLastRunBy, "LastRunDateTime");
			actCurrentDateTime=actCurrentDate.replace(",", "");			
			report.reportInfo("Dsiplayed last run date from application: "+actCurrentDateTime);			

			if(actCurrentDateTime.contentEquals(expCurrentDateTime)||actCurrentDateTime.contentEquals(increasedCurrentDateTime))
			{
				report.reportPass("Verified last run by date and time in short panel");
			}else{
				report.reportFail("Failed to verify last run by date and time in short panel");
			}			

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public void clickonAccountNumber(){
		try {
			webActions.click(lbl_AccountNumber, "AccountNumber");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(txt_MedicalShortLastRunBy, "lastRun");
			Thread.sleep(2000);

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
