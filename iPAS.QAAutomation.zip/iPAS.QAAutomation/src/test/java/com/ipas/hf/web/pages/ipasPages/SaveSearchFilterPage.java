package com.ipas.hf.web.pages.ipasPages;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;


import com.google.common.collect.Ordering;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;


public class SaveSearchFilterPage extends BasePage{

	AccountSearchFilteringPage accountFilter=new AccountSearchFilteringPage();

	@FindBy(xpath = "//div[@class='Searchfilters']/div/div/div/div/div[2]")
	private WebElement btn_ToolIcon;

	@FindBy(xpath = "//a[contains(text(),'Account Search')]")
	private WebElement lnk_AccounSearch;

	@FindBy(xpath="//div[@class='Searchfilters']/div/div/div/div/div[2]/div/div[@class='tools']/a")
	private List<WebElement> li_ToolOptions;

	@FindBy(xpath = "//div[@class='Searchfilters']/div/div/div/div/div[2]/div/div[@class='tools']/label")
	private WebElement txt_ToolsMenu;

	@FindBy(xpath = "//h5[@id='savefilterModalLabel']")
	private WebElement txt_SaveFilterWindowMenu; 

	@FindBy(xpath = "//div[@class='modal-body']/div/label")
	private WebElement lbl_FilterName;

	@FindBy(xpath = "//div[@class='modal-body']/div/div[@class='col-md-10']/label")
	private WebElement lbl_Overwrite; 

	@FindBy(xpath = "//div[@class='modal-footer']/button[@type='submit']")
	private WebElement btn_Save; 

	@FindBy(xpath = "//div[contains(text(),'Filter name is required.')]")
	private WebElement txt_FilterErrorMsg; 

	@FindBy(xpath = "//div[contains(text(),'It allows maximum 25 characters')]")
	private WebElement txt_FilterMaxErrorMsg;

	@FindBy(xpath = "//div[@class='mt-10']")
	private WebElement lbl_Overwritedrp;

	@FindBy(xpath = "//div[@class='mt-10']//span[@class='e-input-group e-control-wrapper e-disabled e-ddl e-lib e-keyboard e-valid-input']/input")
	private WebElement lbl_OverwriteDefaultMode;

	@FindBy(xpath = "//div[@class='mt-10']//span[@class='e-input-group e-control-wrapper e-ddl e-lib e-keyboard e-valid-input']/input")
	private WebElement lbl_OverwriteMode;

	@FindBy(xpath = "//table[@id='asgrid_content_table']//tbody/tr/td")
	private WebElement lbl_GridRecords;

	@FindBy(xpath = "//input[@id='Name']")
	private WebElement txt_FilterName;

	@FindBy(xpath = "//input[@id='Name']//following::input[1]")
	private WebElement btn_Filtertoggle; 

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_FilterMsgs; 

	@FindBy(xpath = "//button[@id='e-dropdown-btn_3']")
	private WebElement btn_Filter;

	@FindBy(xpath="//ejs-listview[@id='listview']//li[(@class='e-list-item e-level-1 e-checklist')]")
	public List<WebElement> chk_Filter;

	@FindBy(xpath="//ejs-listview[@id='listview']//li[@class='e-list-item e-level-1 e-checklist e-active']")
	public List<WebElement> unchk_Filter;

	@FindBy(xpath="//table[@id='asgrid_content_table']//tbody/tr/td") 
	private WebElement lbl_Headers;

	@FindBy(xpath="//ejs-dropdownlist[@id='VisitDate']/span/input[@class='e-input']")
	private WebElement drp_FilterSelectedValue;

	@FindBy(xpath="//ejs-dropdownlist[@id='VisitDate']/span[@class='e-input-group e-control-wrapper e-ddl e-lib e-keyboard e-valid-input']")
	private WebElement drp_Filteroption;

	@FindBy(xpath = "//div[@id='panel']")
	private WebElement grid_Header;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody")
	private WebElement grid_Results;

	@FindBy(xpath="//ejs-dropdownlist[@id='Gender']")
	public WebElement dd_Gender;

	@FindBy(xpath="//ejs-dropdownlist[@id='Gender']//input[@class='e-input']")
	public WebElement dd_Gender1;	

	@FindBy(xpath = "//div[@class='pl-10 ng-star-inserted']/button[@class='btn btn-primary btn-md']")
	private WebElement btn_Apply;

	@FindBy(xpath = "//div[@class='pl-10 ng-star-inserted']/button[@class='btn btn-primary btn-md ml-10']")
	private WebElement btn_ApplyAfterFilterSelection;

	@FindBy(xpath = "//div[@id='savefilter']/div/div/form/div/a/span")
	private WebElement btn_saveFilterCross;

	@FindBy(xpath = "//ejs-dropdownlist[@class='form-control fa-blue e-control e-dropdownlist e-lib']/span/input")
	private WebElement drp_overwriteDropdown;

	@FindBy(xpath = "//h5[@id='filter-settingsModalLabel']")
	private WebElement txt_FilterSettingsWindowMenu;

	@FindBy(xpath = "//div[@class='modal-footer']/button[@type='button']")
	private WebElement btn_FilterSave;

	@FindBy(xpath = "//div[@class='modal-body']/label")
	private WebElement lbl_FilterSettingsName; 

	@FindBy(xpath = "//div[@id='filter-settings']/div/div/div/a/span")
	private WebElement btn_FilterSettingsCross;

	@FindBy(xpath="//div[@class='card']/ul/li")
	public List<WebElement> li_FilterSettings; 

	@FindBy(xpath="//div[@class='card']/ul/li/a/i")
	public List<WebElement> icon_FilterSettingsDelte;
	
	@FindBy(xpath = "//div[@class='dashboard-wrapper']/div/div/div")
	private WebElement lbl_DashboardWrapper;

	public SaveSearchFilterPage() {
		PageFactory.initElements(driver, this); 
	}	

	public void verifyfields(){
		try {		
			webActions.waitForVisibility(btn_ToolIcon, "ToolIcon");
			webActions.assertDisplayed(btn_ToolIcon, "ToolIcon");			
			report.reportPass("Tools icon is displayed to the right of the search Columns button");
		} catch (Exception e) {
			report.reportFail("Tools icon is not displayed to the right of the search Columns button");
		}
	}

	public void verifyToolsOptions(DataTable options) {
		try {
			ArrayList<String> expectedOptions = new ArrayList<>(options.asList());
			report.reportInfo("Expected option Names: "+expectedOptions);
			webActions.waitUntilEnabledAndClick(btn_ToolIcon, "Tools Icon");
			webActions.waitUntilisDisplayed(txt_ToolsMenu, "ToolsMenu");
			ArrayList<String> actualOptions=webActions.getDatafromWebTable(li_ToolOptions);
			report.reportInfo("Displayed tools options Names in Application: "+actualOptions);
			ArrayList<String>unmatchedOptionNames=webActions.getUmatchedInArrayComparision(actualOptions, expectedOptions);
			if(unmatchedOptionNames.size()==0){
				report.reportPass("Verified tool options in tool icon list of Account Search page successfully");
			}
			else{
				throw new Exception("Fail to verify list of options in column tools menu of Account Search page and unmatched options are: "+unmatchedOptionNames);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyToolsMenuTitle(String title) {
		try {
			webActions.waitUntilEnabledAndClick(btn_ToolIcon, "Tools Icon");
			String ActualTitle = webActions.getText(txt_ToolsMenu, "Tools Title");
			if (ActualTitle.contentEquals(title)){
				report.reportPass("Verified Tools title successfully");
				report.reportInfo("Actual Tools mneu title: "+ActualTitle);
				report.reportInfo("Expected Tools menu title: "+title);
			}
			else{
				throw new Exception("Actual Tools menu title did not match with Expected and Actual title is: "+ActualTitle);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());

		}

	}
	public void clickOnRequiredOptionFromToolsMenu(String optionToSelect) throws Exception{
		try {

			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.waitUntilEnabledAndClick(btn_ToolIcon, "Tools Icon");
			List<WebElement> allOptions = li_ToolOptions;
			for (WebElement option : allOptions) {
				String optionvalue=option.getText().trim();				
				if (optionToSelect.contentEquals(optionvalue)) {
					option.click();					
					report.reportInfo("Option selected from tools menu: "+optionvalue);
					break;
				}					
			}		

		} catch (Exception e) {
			report.reportFail("Unable to select the option from tools menu");
			throw e;
		}

	}

	public void verifySaveFilterModelWindowTitle(String windowTitle) {
		try {
			webActions.waitForVisibility(txt_SaveFilterWindowMenu, "Save Filter Window Title");
			String ActualTitle = webActions.getText(txt_SaveFilterWindowMenu, "Save Filter Window Title");
			if (ActualTitle.contentEquals(windowTitle)){
				report.reportPass("Verified Save Filter Model Window title successfully");
				report.reportInfo("Actual Save Filter Model Window title: "+ActualTitle);
				report.reportInfo("Expected Save Filter Model Window title: "+windowTitle);
			}
			else{
				throw new Exception("Actual Save Filter Model Window title did not match with Expected and Actual title is: "+ActualTitle);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());

		}

	}

	public void verifyFieldsInSaveFilterWindow(DataTable testData){
		try {
			List<String> expfields = testData.asList(String.class);
			List<String> actfields = new ArrayList<>(); 
			actfields.add(webActions.getText(lbl_FilterName, "FilterName"));
			actfields.add(webActions.getText(lbl_Overwrite, "Overwrite"));

			report.reportInfo("Actual fields in Save filter window: "+actfields);
			report.reportInfo("Expected fields in Save filter window: "+expfields);
			ArrayList<String> unmatchedData=webActions.getUmatchedInArrayComparision(actfields,expfields);
			if(unmatchedData.size()==0){
				report.reportPass("Verified Default Values in Default Search page successfully");
			}
			else{
				throw new Exception("Fail to verify Default Values in Default Search page and unmatched data is: "+unmatchedData);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifySaveButton(){
		try {		
			webActions.waitForVisibility(btn_Save, "SaveButton");
			webActions.assertDisplayed(btn_Save, "SaveButton");			
			report.reportPass("Save button is displayed on the Save Filter model window");
		} catch (Exception e) {
			report.reportFail("Save button is is not displayed on the Save Filter model window");
		}
	}

	public void verifyFilterErrorMsg(String expmessage) {
		try {
			webActions.waitForVisibility(btn_Save, "SaveButton");
			webActions.clickAction(btn_Save, "SaveButton");
			String ActualErrorMsg = webActions.getText(txt_FilterErrorMsg, "Error Message");
			if (ActualErrorMsg.contentEquals(expmessage)){
				report.reportPass("Verified Filter Error message successfully");
				report.reportInfo("Actual Filter Error Message: "+ActualErrorMsg);
				report.reportInfo("Expected Filter Error Message: "+expmessage);
			}
			else{
				throw new Exception("Actual error message doesn't match with Expected and Actual error message is: "+ActualErrorMsg);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());

		}

	}

	public void verifyOverWriteExistingMode(String expValue){
		try {
			webActions.waitForVisibility(lbl_Overwritedrp, "Overwrite");
			String actValue=null;
			if(expValue.contentEquals("true")){
				actValue=webActions.getAttributeValue(lbl_OverwriteDefaultMode, "aria-disabled", "Overwrite");
			}
			else if(expValue.contentEquals("false")){
				webActions.waitForClickAbility(lbl_OverwriteMode, "Overwrite");
				actValue=webActions.getAttributeValue(lbl_OverwriteMode, "aria-disabled", "Overwrite");
			}			
			if(actValue.contentEquals(expValue)){
				report.reportPass("OverwriteExisting filter drop down displayed as expected mode");

			}
			else{
				throw new Exception("OverwriteExisting filter drop down is not displayed as per expected mode: "+actValue);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	/**To click on filter toggle in save filter model window*/
	public void clickOnToggle(){
		try {
			webActions.waitForVisibility(txt_FilterName, "FilterName");
			webActions.sendKeys(txt_FilterName, "ABC", "FilterName");
			webActions.waitForPageLoaded();
			webActions.clickAction(btn_Filtertoggle, "FilterToggle");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}


	}
	/** To enter the filter name in filter name filed*/
	public String enterDataInFilterNameField(){
		String filterName=null;
		try {
			String num=getUniqueNumber();
			filterName="Vishnu"+num;
			webActions.waitForVisibility(txt_FilterName, "FilterName");
			webActions.sendKeys(txt_FilterName, filterName, "FilterName");
			report.reportInfo("Entered filter name in FilterName field");
			webActions.waitForVisibility(btn_Save, "SaveButton");
			webActions.click(btn_Save, "SaveButton");
			report.reportInfo("Clicked on Save button");
			webActions.waitForVisibility(txt_FilterMsgs, "toastmsg");
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
		return filterName;

	}
	/**To verify the filter messages*/
	public void getfilterMessages(String title,String content){
		try {
		//webActions.waitForPageLoaded();
		//webActions.waitForVisibility(txt_FilterMsgs, "messages");
		String msg=webActions.waitAndGetText(txt_FilterMsgs, "FilterMsgs");
		String[] titleContent=msg.split("\\n");
		String actTitle=titleContent[0];
		String actContent=titleContent[1];
		if((title.contentEquals(actTitle)) && (content.contentEquals(actContent))){
			report.reportPass("Both title and content displayed properly");
		}
		else{
			throw new Exception("Both title and content are not displayed properly actual Title: " +actTitle+ " and actual content: "+ actContent);
		}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}


	}

	/** To generate unique number*/
	public String getUniqueNumber() {
		String uniqueNumber = "";
		try {
			Date dNow = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("DDYYHHssMs");
			String s = ft.format(dNow);
			uniqueNumber = s.substring(0, Math.min(s.length(), 10));

		} catch (Exception e) {

		}
		return uniqueNumber;
	}

	/**
	 * To select any filter name 
	 * @param filterName
	 */
	public void selectFilterName(String filterName){
		try {			
			webActions.waitUntilEnabledAndClick(btn_Filter, "Filter Button");
			webActions.selectCheckBoxfromList(chk_Filter,filterName,"Filter");
			report.reportInfo("Selected Filter from list: "+filterName);
			webActions.waitUntilEnabledAndClick(btn_Filter, "Filter Button");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	} 
	/** To create the filter with existing filter name
	 * **/
	public void verifySaveFilterUnique(){
		try {
			String filterName=enterDataInFilterNameField();	
			report.reportInfo("First time filter is created successfully: "+filterName);	
			webActions.waitForPageLoaded();
			unSelectFilterName("Gender");
			clickOnRequiredOptionFromToolsMenu("Save Filter As");			
			webActions.waitForVisibility(txt_FilterName, "FilterName");
			webActions.sendKeys(txt_FilterName, filterName, "FilterName");
			report.reportInfo("Second time enter existing filter name in filter name field: "+filterName);
			webActions.waitForVisibility(btn_Save, "SaveButton");
			webActions.clickAction(btn_Save, "SaveButton");
			report.reportInfo("Clicked on Save button");

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	/** To enter the filter name as more than 25 characters in filter name filed*/
	public void enterFilterNameMoreThan25(){

		try {
			String num=getUniqueNumber();
			String filterName="Vishnu Vardhan Reddy"+num;
			webActions.waitForVisibility(txt_FilterName, "FilterName");
			webActions.sendKeys(txt_FilterName, filterName, "FilterName");
			report.reportInfo("Entered filter name in FilterName field");
			webActions.waitForVisibility(btn_Save, "SaveButton");
			webActions.click(btn_Save, "SaveButton");
			report.reportInfo("Clicked on Save button");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}


	}
	/** To verify the filter error message*/
	public void verifyFilterMaxErrorMsg(String expmessage){
		try {

			String ActualErrorMsg = webActions.getText(txt_FilterMaxErrorMsg, "Error Message");
			if (ActualErrorMsg.contentEquals(expmessage)){
				report.reportPass("Verified Filter Max Error message successfully");
				report.reportInfo("Actual Filter Max Error Message: "+ActualErrorMsg);
				report.reportInfo("Expected Filter Max Error Message: "+expmessage);
			}
			else{
				throw new Exception("Actual error message doesn't match with Expected and Actual error message is: "+ActualErrorMsg);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());

		}		

	}

	/** To enter the filter name with special characters in filter name filed*/
	public String enterFilterNameWithSpecialChar(){
		String filterName=null;
		try {
			String num=getUniqueNumber();
			filterName="V s_:;.u,#&*[{("+num;
			webActions.waitForVisibility(txt_FilterName, "FilterName");
			webActions.sendKeys(txt_FilterName, filterName, "FilterName");
			report.reportInfo("Entered filter name in FilterName field");
			webActions.waitForVisibility(btn_Save, "SaveButton");
			webActions.click(btn_Save, "SaveButton");
			report.reportInfo("Clicked on Save button");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
		return filterName;

	}

	/** To Verify the created filter name in filter drop down
	 * **/
	public void verifyFilterinFilterDropDown(){
		try {
			String expfilterName=enterDataInFilterNameField();		
			report.reportInfo("Filter is created successfully: "+expfilterName);			
			webActions.waitForVisibility(lbl_Headers, "Headers");
			Thread.sleep(3000);			
			webActions.clickAction(drp_Filteroption, "Filters");
			Thread.sleep(3000);
			webActions.sendKeys(drp_FilterSelectedValue, expfilterName, "Filters");			
			String selectedFilter=webActions.getAttributeValue(drp_FilterSelectedValue, "aria-label", "Filters");						
			if(selectedFilter.contentEquals(expfilterName)){
				report.reportPass("Created filter is displayed in filter drop down");
			}
			else{
				throw new Exception("Created filter name is not displayed in filter drop down: "+expfilterName);
			}


		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void selectFilterAndEnterData(String filterName,String filterData){
		try {
			webActions.waitForLoad();
			webActions.waitForVisibility(lbl_GridRecords, "gridRecords");
			selectFilterName(filterName);
			enterOrSelectDatainFilter(filterName,filterData);
			webActions.waitForLoad();
			report.reportPass("Filter is selected successfully" + filterName + "and enter data in filter as: "+ filterData);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}

	}

	/** To create new filter and select the same filter from filter drop down
	 * **/
	public void createAndSelectFilterFromFilterDropDown(String filterName){
		try {
			String expfilterName=enterDataInFilterNameField();	

			report.reportInfo("Filter is created successfully: "+expfilterName);		
			unSelectFilterName(filterName);			
			Thread.sleep(3000);
			webActions.clickAction(drp_Filteroption, "Filters");
			Thread.sleep(3000);
			webActions.sendKeys(drp_FilterSelectedValue, expfilterName, "Filters");	
			webActions.waitForLoad();

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	/** To verify the selected filter value and results grid verification based on filter selection**/
	public void verifyDatainResultsGrid(String filterName,String filterData,String columnName) throws Exception{
		try {
			webActions.waitForVisibility(dd_Gender, "GenderFilter");
			//verifyFilterValue(filterName, filterData);					
			webActions.click(btn_ApplyAfterFilterSelection, "Apply Button");
			webActions.waitForVisibility(lbl_Headers, "Headers");
			if(filterData.contentEquals("Male")){
				filterData="M";
			}			
			ArrayList<String>actData=webActions.getGridData(grid_Header,grid_Results,columnName,filterName);
			ArrayList<String> unmatchedData=webActions.isFullArrayMatchWithData(actData, filterData);
			report.reportInfo("Expected data: "+filterData);
			if(unmatchedData.size()==0){
				report.reportPass("All Data verified successfully and displayed data is: " + actData);
			}else{
				throw new Exception("Data verification failed, and unmatched data is: "+unmatchedData);
			}
		} catch (Exception e) {
			report.reportFail(e.toString());
		}
	}
	/** To verify the selected value from filter**/
	public void verifyFilterValue(String filterName,String filterData){
		String actualValue=null;
		try {			
			switch (filterName) {
			case "Gender":
				webActions.waitForClickAbility(dd_Gender, filterName);
				webActions.assertDisplayed(dd_Gender, filterName);
				report.reportInfo("Verified the '"+filterName+"' Field");
				actualValue=webActions.getValue(dd_Gender1, filterName);				
				break;
			}
			report.reportInfo("Actual  value in '"+filterName+"' field: " + actualValue);
			report.reportInfo("Expected  value in '"+filterName+"' field: " + filterData);
			if(filterData.contentEquals(actualValue)){
				report.reportPass("Verified  value in '"+filterName+"' field successfully");
			}else{
				throw new Exception("Fail to verify the value in '"+filterName+"' field and actual displayed value is: "+actualValue);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}	

	public void enterOrSelectDatainFilter(String filterName,String testData) throws Exception{

		switch (filterName) {
		case "Gender":
			selectGender(testData);
			break;		
		}		
	}

	public void selectGender(String genderType) throws Exception{
		try {
			webActions.waitForClickAbility(dd_Gender1, "Gender");			
			webActions.sendKeys(dd_Gender1, genderType, "Gender Dropdown");

		} catch (Exception e) {
			throw e;
		}

	}
	/**
	 * To Un select any filter name 
	 * @param filterName
	 */
	public void unSelectFilterName(String filterName){
		try {			
			webActions.waitUntilEnabledAndClick(btn_Filter, "Filter Button");
			webActions.selectCheckBoxfromList(unchk_Filter,filterName,"Filter");
			report.reportInfo("Un-selected Filter from list: "+filterName);
			webActions.waitForPageLoaded();
			webActions.waitUntilEnabledAndClick(btn_Filter, "Filter Button");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	} 

	public void verifyFilterNameMode(){
		try {		
			boolean txt=txt_FilterName.isEnabled();
			String filterNameMode=Boolean.toString(txt);
			report.reportInfo("filterNameMode: "+filterNameMode);
			if(filterNameMode.contentEquals("false")){
				report.reportPass("FilterName field is disabled on selecting the toggle");
			}
			else{
				throw new Exception("FilterName field not is disabled on selecting the toggle");
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void closeSaveFilterWindow(){

		try {
			webActions.click(btn_saveFilterCross, "CrossOptionInSaveFilter");
			webActions.waitUntilEnabledAndClick(btn_ToolIcon, "ToolsIcon");
			report.reportPass("Save filter model window is closed on selecting the cross option from it");

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	/** To Verify the overwrite of existing filter
	 * **/
	public void verifyOvwriteFilterinOverwriteExisting(String filterName,String genderType,String optionToSelect){
		try {
			webActions.waitForLoad();
			String expfilterName=enterDataInFilterNameField();		
			report.reportInfo("Filter is created successfully: "+expfilterName);			
			webActions.waitForVisibility(lbl_GridRecords, "Gridrecords");			
			selectGender(genderType);
			report.reportInfo("Value selected for Gender filter: "+genderType);
			Thread.sleep(3000);
			clickOnRequiredOptionFromToolsMenu(optionToSelect);			
			clickOnToggle();			
			//webActions.sendKeys(drp_overwriteDropdown, expfilterName, "Filters");
			webActions.clickAction(btn_Save, "SaveButton");
			webActions.waitForVisibility(txt_FilterMsgs, "toastmesg");
			webActions.waitForPageLoaded();
			unSelectFilterName(filterName);
			webActions.waitForPageLoaded();
			//webActions.refreshPage();
			webActions.waitForPageLoaded();
			//navigateToAccountSearch();
			webActions.waitForPageLoaded();
			webActions.sendKeys(drp_FilterSelectedValue, expfilterName, "Filters");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(dd_Gender1, "Gender");
			webActions.waitForPageLoaded();
			String filterValue=webActions.getValue(dd_Gender1, "Gender");
			report.reportInfo("Value changed for existing filter: "+filterValue);
			if(filterValue.contentEquals(genderType)){
				report.reportPass("Filter Value is overwritten successfully for existing filter");
			}
			else{
				throw new Exception("Filter value is not overwrite for existing filter: "+filterValue);
			}			

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public void verifyFilterSettingsModelWindowTitle(String title) {
		try {
			webActions.waitForVisibility(txt_FilterSettingsWindowMenu, "Filter Settings Window Title");
			String ActualTitle = webActions.getText(txt_FilterSettingsWindowMenu, "Filter Settings Window Title");
			if (ActualTitle.contentEquals(title)){
				report.reportPass("Verified Filter Settings Model Window title successfully");
				report.reportInfo("Actual Filter Settings Model Window title: "+ActualTitle);
				report.reportInfo("Expected Filter Settings Model Window title: "+title);
			}
			else{
				throw new Exception("Actual Filter Settings Model Window title did not match with Expected and Actual title is: "+ActualTitle);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());

		}

	}

	public void verifyFilterSettingsModelWindowFields(String field) {
		try {
			webActions.waitForVisibility(txt_FilterSettingsWindowMenu, "Filter Settings Window fields");
			String ActualFields = webActions.getText(lbl_FilterSettingsName, "Filter Settings Window fields");
			if (ActualFields.contentEquals(field)){
				report.reportPass("Verified Filter Settings Model Window fields successfully");
				report.reportInfo("Actual Filter Settings Model Window fields: "+ActualFields);
				report.reportInfo("Expected Filter Settings Model Window fields: "+field);
			}
			else{
				throw new Exception("Actual Filter Settings Model Window fileds did not match with Expected and Actual filed is: "+ActualFields);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());

		}

	}

	public void verifyFilterSettingsSaveButton(){
		try {		
			webActions.waitForVisibility(btn_FilterSave, "SaveButton");
			webActions.assertDisplayed(btn_FilterSave, "SaveButton");			
			report.reportPass("Save button is displayed on the Filter settings model window");
		} catch (Exception e) {
			report.reportFail("Save button is is not displayed on the filter settings model window");
		}
	}

	public void closeFilterSettingsWindow(){

		try {
			webActions.click(btn_FilterSettingsCross, "CrossOptionInFilterSettings");
			webActions.waitUntilEnabledAndClick(btn_ToolIcon, "ToolsIcon");
			report.reportPass("Filter Setting model window is closed on selecting the cross option from it");

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	/** To create new filter and delete the same filter from filter settings * **/
	public void createAndDeleteFilterFromFilterSettings(String optionToSelect, String title,String content) throws Exception{

		try {
			String expfilterName=enterDataInFilterNameField();
			report.reportInfo("Filter is created successfully: "+expfilterName);
			Thread.sleep(10000);
			clickOnRequiredOptionFromToolsMenu(optionToSelect);
			webActions.waitUntilisDisplayed(lbl_FilterSettingsName, "FilterSettingsModelWindow");	
			List<WebElement> allOptions = li_FilterSettings;			
			for (int i = 1; i <allOptions.size(); i++) {
				String filterName=allOptions.get(i).getText();					
				if(filterName.contentEquals(expfilterName)){					
					int j=i+1;
					String filterDelete="//div[@class='card']/ul["+j+"]/li/a/i";					
					driver.findElement(By.xpath(filterDelete)).click();
					report.reportInfo("Filter is deleted Successfully : "+filterName);
					webActions.click(btn_FilterSave, "Savebutton");
					break;
				}
			}			
			getfilterMessages(title, content);			
			clickOnRequiredOptionFromToolsMenu(optionToSelect);
			webActions.waitUntilisDisplayed(lbl_FilterSettingsName, "FilterSettingsModelWindow");	
			List<WebElement> filterOptions = li_FilterSettings;
			for (WebElement webElement : filterOptions) {
				String filterNameAfeterDelete=webElement.getText();								
				if(filterNameAfeterDelete.contentEquals(expfilterName)){
					report.reportFail("Filter Name is not deleted Successfully: "+filterNameAfeterDelete);
					break;
				}				
			}
			report.reportPass("Filter Name is deleted Successfully: "+expfilterName);
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}		
	}

	/**To verify the saved filter default sort order from filter settings model**/
	public void verifyFilterSortOrder(){
		try {
			ArrayList<String> filtersList=new ArrayList<String>();
			webActions.waitUntilisDisplayed(lbl_FilterSettingsName, "FilterSettingsModelWindow");	
			List<WebElement> filterOptions = li_FilterSettings;
			for (WebElement webElement : filterOptions) {
				filtersList.add(webElement.getText());
			}			
			boolean sorted = Ordering.natural().isOrdered(filtersList);
			String flag=Boolean.toString(sorted);			
			if(flag.contentEquals("true")){
				report.reportPass("Saved filter are sorted by default in ascending order from filter settings: "+filtersList);
			}
			else{
				throw new Exception("Saved filter are not sorted by default in ascending order from filter settings: "+filtersList);
			}

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	/** To create a filter with already deleted filter from filter settings * **/
	public void createFilterWithDeletedFilterName(String option1,String option2,String title,String content) throws Exception{

		try {
			String expfilterName=enterDataInFilterNameField();
			report.reportInfo("Filter is created successfully: "+expfilterName);
			Thread.sleep(10000);
			clickOnRequiredOptionFromToolsMenu(option2);
			webActions.waitUntilisDisplayed(lbl_FilterSettingsName, "FilterSettingsModelWindow");	
			List<WebElement> allOptions = li_FilterSettings;			
			for (int i = 1; i <allOptions.size(); i++) {
				String filterName=allOptions.get(i).getText();					
				if(filterName.contentEquals(expfilterName)){					
					int j=i+1;
					String filterDelete="//div[@class='card']/ul["+j+"]/li/a/i";					
					driver.findElement(By.xpath(filterDelete)).click();
					report.reportInfo("Filter is deleted Successfully : "+filterName);
					webActions.click(btn_FilterSave, "Savebutton");
					webActions.waitForVisibility(txt_FilterMsgs, "toastmsg");
					break;
				}
			}
			unSelectFilterName("Gender");
			Thread.sleep(10000);
			selectFilterName("Gender");
			clickOnRequiredOptionFromToolsMenu(option1);
			webActions.waitForVisibility(txt_FilterName, "FilterName");
			webActions.sendKeys(txt_FilterName, expfilterName, "FilterName");
			report.reportInfo("Entered filter name in FilterName field");
			webActions.waitForVisibility(btn_Save, "SaveButton");
			webActions.click(btn_Save, "SaveButton");
			report.reportInfo("Clicked on Save button");
			getfilterMessages(title, content);

		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}		
	}

	public void navigateToAccountSearch(){
		try {
			webActions.waitForPageLoaded();		
			webActions.click(lnk_AccounSearch, "AccountSearch");
			webActions.waitForPageLoaded();
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_Headers, "Headers in Account Search");		
			
			report.reportPass("Clicked on Account Search link and navigated to the Account Search Page Successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());	
		}
	}
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}