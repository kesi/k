package com.ipas.hf.web.steps;

import com.ipas.hf.web.pages.ipasPages.DisplaySearchPage;
import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;


public class DisplaySearchSteps {

	DisplaySearchPage displaySearch=new DisplaySearchPage();

	@Then("Verify the VisitDate and LastEventDate by adding OffsetTime in the {string} page")
	public void verify_the_VisitDate_and_LastEventDate_by_adding_OffsetTime_in_the_page(String pageName) {
		displaySearch.verifyVisitDateAndLastEventDate(pageName);
	}
	@Then("Get the value of {string} from json and verify with discharge date population")
	public void get_the_value_of_from_json_and_verify_with_discharge_date_population(String input) {
		displaySearch.verifytDischargeDate(input);
	}
	
	@Then("Add new patient and verify the Visit Date and Last Event data the {string} page")
	public void add_new_patient_and_verify_the_Visit_Date_and_Last_Event_data_the_page(String pageName, DataTable testData) {
		displaySearch.verifyVisitDateAndLastEventDateManuallyAddedPatient(pageName,testData);
	}
	
	@Then("Verify Patient DBO as {string} in Account Search page and Guarantor DOB as {string} in All Data page")
	public void verify_Patient_DBO_as_in_Account_Search_page_and_Guarantor_DOB_as_in_All_Data_page(String patientDOB, String guarantorDOB) {
		displaySearch.verifyPatientDOBandGuarantorDBO( patientDOB,guarantorDOB);
	}


}
