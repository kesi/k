package com.ipas.hf.web.pages.ipasPages;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ipas.hf.actions.WebActions;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class DisplaySearchPage extends BasePage {

	@FindBy(xpath="//table[@id='asgrid_content_table']/tbody/tr/td[3]/div/div[1]")
	private WebElement lbl_VisitDate;

	@FindBy(xpath="//table[@id='asgrid_content_table']/tbody/tr/td[8]/div[1]")
	private WebElement lbl_EventType;

	@FindBy(xpath="//table[@id='asgrid_content_table']/tbody/tr/td[8]/div[2]")
	private WebElement lbl_EmployeeName;

	@FindBy(xpath="//table[@id='asgrid_content_table']/tbody/tr/td[8]/div[3]")
	private WebElement lbl_LastEventDate;

	@FindBy(xpath="//div[@class='pasentDetails']/ul/li[4]/div[2]")
	private WebElement lbl_DateOfService;

	@FindBy(xpath="//p[contains(text(),'Patient Information')]/../ul[4]/li[1]/div[2]")
	private WebElement lbl_EventType_AllData;

	@FindBy(xpath="//p[contains(text(),'Patient Information')]/../ul[4]/li[2]/div[2]")
	private WebElement lbl_EmployeeName_AllData;

	@FindBy(xpath="//p[contains(text(),'Patient Information')]/../ul[4]/li[3]/div[2]")
	private WebElement lbl_EventDateandTimeStamp;	

	@FindBy(xpath="//p[contains(text(),'Patient Information')]/../ul[2]/li[1]/div[2]")
	private WebElement lbl_DischagrdeDate;

	@FindBy(xpath="//table[1]/tr[1]/td[1]/ejs-accordion[2]/div/div[2]/div/div/table[4]/tr[2]/td[1]/span")
	private WebElement lbl_DischagrdeDateFullPage;

	@FindBy(xpath="//div[@id='acrdn_panel_7']/div/div/ul/li/div[2]")
	private List<WebElement> lbl_SectionDataInAllDataPanel;

	@FindBy(xpath="//ejs-accordion/div[1]/div[2]/div/div/ul/li/div[2]")
	private WebElement lbl_DataInAllDataPanel;

	@FindBy(xpath = "//a[contains(text(),'All Data')]")
	private WebElement lbl_AllDataPanelTitle;

	@FindBy(xpath="//div[@id='fullPageAllData-control-section']")
	private WebElement lbl_AllPanelsData;

	@FindBy(xpath="//div[@class='pasentDetails']/ul/li/div[2]")
	private List<WebElement> lbl_VisitSummaryData;	

	@FindBy(xpath="//a[contains(text(),'Account Search')]")
	private WebElement lnk_AccountSearch_Home;

	@FindBy(xpath = "//input[@placeholder='Type Account ID/Patient Name']")
	private WebElement txt_Search;

	@FindBy(xpath="//li[@id='p-highlighted-option']")
	private WebElement li_Search;

	@FindBy(xpath="//table[@class='e-table']//thead/tr/th")
	private WebElement lbl_Headers_AS;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr/td[2]/div/a")
	private WebElement lbl_AccountNumber_AccountSearch;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr/td[2]/div/div[2]")
	private WebElement lbl_PatientDateofBirth_AccountSearch;

	@FindBy(xpath="//div[@class='pasentDetails']/ul/li[3]/div[2]")
	private WebElement lbl_PatientDateofBirth_AllData;

	@FindBy(xpath="//ejs-accordion[3]/div/div[2]/div/div/table[1]/tr[2]/td[1]/span")
	private WebElement lbl_GuarantorDateofBirth;


	private RestActions rest = new RestActions();
	Login logIn = new Login();
	AddPatientVisitPage addPatient=new AddPatientVisitPage();

	public DisplaySearchPage() {
		PageFactory.initElements(driver, this);
	}

	public String getVisitandDischargeDateFromJSON(){
		String expVisitDate=null;
		try {
			expVisitDate=rest.getStringValueFromResponse("$..visitDate");
			expVisitDate = expVisitDate.replaceAll("\"","");
			expVisitDate = expVisitDate.replaceAll("\\[|\\]", ""); 
			expVisitDate=webActions.getVisitandDischargeDate(expVisitDate, 5, 30);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return expVisitDate;
	}

	public String getEventDateandTimeStampFromJSON(){
		String expEventDateTime=null;
		try {
			expEventDateTime=rest.getStringValueFromResponse("$..eventDateTime");
			expEventDateTime = expEventDateTime.replaceAll("\"","");
			expEventDateTime = expEventDateTime.replaceAll("\\[|\\]", ""); 
			expEventDateTime=webActions.getEventDateandTimeStamp(expEventDateTime, 5, 30);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return expEventDateTime;
	}

	public void verifyVisitDateAndLastEventDate(String pageName){
		try {
			StringBuilder unmatch=new StringBuilder();
			String expVisitDate=getVisitandDischargeDateFromJSON();
			report.reportInfo("Expected Visit Date after adding OffsetTime value: "+expVisitDate);
			String actVistDate=null;
			if ("Account Search".contentEquals(pageName)) {
				actVistDate = webActions.waitAndGetText(lbl_VisitDate, "Visit Date");
			}
			else{
				String accountNumber=logIn.getVisitIdFromResponse("$..displayPatientAccountId");
				driver.findElement(By.partialLinkText(accountNumber)).click();
				webActions.waitForVisibility(lbl_EventDateandTimeStamp, "EventDateandTimeStamp");
				webActions.waitForPageLoaded();
				actVistDate = webActions.waitAndGetText(lbl_DateOfService, "Date Of Service");
			}
			report.reportInfo("Actual Visit Date in "+pageName+" page: "+actVistDate);
			if(actVistDate.contentEquals(expVisitDate)){
				report.reportPass("Successfully verified the Visit Date after adding OffsetTime value in the "+pageName+" page");
			}else{
				unmatch.append("Failed to verify the Visit Date after adding OffsetTime value in the "+pageName+" page");
				report.reportFail("Failed to verify the Visit Date after adding OffsetTime value in the "+pageName+" page", true);
			}

			String expEventDateTime=getEventDateandTimeStampFromJSON();
			report.reportInfo("Expected Event Date and Time after adding OffsetTime value: "+expEventDateTime);
			String actEventDateTime = null;
			if ("Account Search".contentEquals(pageName)) {
				actEventDateTime = webActions.waitAndGetText(lbl_LastEventDate, "Last Event Date");
			}
			else{
				actEventDateTime = webActions.waitAndGetText(lbl_EventDateandTimeStamp, "Event Date and Time Stamp");
			}
			report.reportInfo("Actual Event Date and Time in "+pageName+ "page: "+actEventDateTime);

			if(actEventDateTime.contentEquals(expEventDateTime)){
				report.reportPass("Successfully verified the Event Date and Time after adding OffsetTime value in the "+pageName+" page");
			}else{
				unmatch.append("Failed to verify the Event Date and Time after adding OffsetTime value in the "+pageName+" page");
				report.reportFail("Failed to verify the Event Date and Time after adding OffsetTime value in the "+pageName+" page", true);
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}

	}	

	public void verifytDischargeDate(String input){
		try {
			StringBuilder unmatch=new StringBuilder();
			String visitDischargeDate=getValueFromResponse(input);
			report.reportInfo(visitDischargeDate);
			String expectedDischargeDate=webActions.getVisitandDischargeDate(visitDischargeDate, 5, 30);					
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_DataInAllDataPanel, "DataInAllData");				
			String actualDate=webActions.waitAndGetText(lbl_DischagrdeDate, "DischargeDate");

			report.reportInfo("VisitDischargeDate from expected format : " + expectedDischargeDate);
			report.reportInfo("Discharged date from All Data Panel : " + actualDate);
			if(actualDate.contentEquals(expectedDischargeDate)){
				report.reportPass("Discharge date is populated as visitDischargeDate");
			}
			else{
				unmatch.append("Failed to verify the Discharge from All Data Panel and actual discharge date is : " + actualDate );
				report.reportFail("Discharge date is not populated as visitDischargeDate and actual displayed date is : " + actualDate,true);
			}
			clickOnAllDataLink();
			String actualDischargeDate=webActions.waitAndGetText(lbl_DischagrdeDateFullPage, "DischargeDate_FullPage");
			report.reportInfo("Discharged date from Visit Full page : " + actualDischargeDate);
			if(actualDischargeDate.contentEquals(expectedDischargeDate)){
				report.reportPass("Discharge date is populated as visitDischargeDate in Full Page");
			}
			else{
				unmatch.append("Failed to verify the Discharge from full page and actual discharge date is : " + actualDischargeDate );
				report.reportFail("Discharge date is not populated as visitDischargeDate and actual displayed date is : " + actualDischargeDate );
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	public String getValueFromResponse(String inputValue){
		String value = "";
		try {
			value = rest.getStringValueFromResponse(inputValue);
			value = value.replaceAll("\"","");
			value = value.replaceAll("\\[|\\]", "");			
			report.logPass("Validate Response Body Content Matches the Expected Value: " + inputValue
					+ " Actual value : " + value);
		} catch (AssertionError e) {
			report.logHardFail("Validate Response Body Content Matches the Request Failed ", e);
		}
		return value;
	}

	public void clickOnAllDataLink(){
		try {
			webActions.click(lbl_AllDataPanelTitle, "AllData");
			webActions.waitUntilisDisplayed(lbl_AllPanelsData, "AllPanels");
			webActions.waitForPageLoaded();
			webActions.waitForVisibilityOfAllElements(lbl_VisitSummaryData, "VisitSummary");
			report.reportInfo("Clicked on All Data link");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}

	public String addNewPatientandSearchPatientNameinAccountSearchPage(String pageName){
		String accountNumber="";
		try {
			addPatient.navigateToAddPatient();
			String lastName=rest.randomString(6);
			String firstName=rest.randomString(6);
			addPatient.verifyAddPatient(lastName, firstName);
			String patientName=firstName+" "+lastName;
			accountNumber=searchPatientNameinAccountSearchPage(patientName);
		} catch (Exception e) {
		}
		return accountNumber;
	}



	public String searchPatientNameinAccountSearchPage(String patientName) throws Exception{
		String accountNumber=null;
		try {
			webActions.waitForPageLoaded();
			webActions.waitAndClick(lnk_AccountSearch_Home, "Account Search");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.sendKeys(txt_Search, patientName, "Simple Search");
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(li_Search, "Patient Name list");
			//webActions.waitUntilisDisplayed(li_Search, "Patient Name list");
			webActions.waitForPageLoaded();
			webActions.click(li_Search, "Patient Name list");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_Headers_AS,"Account Search Headers");
			webActions.waitForPageLoaded();
			accountNumber=webActions.waitAndGetText(lbl_AccountNumber_AccountSearch, "Account Number");
		} catch (Exception e) {
			throw new Exception(e);
		}
		return accountNumber;
	}

	public void verifyVisitDateAndLastEventDateManuallyAddedPatient(String pageName,DataTable testData){
		try {
			List<String> expData = testData.asList(String.class);
			StringBuilder unmatch=new StringBuilder();
			String accountNumber=addNewPatientandSearchPatientNameinAccountSearchPage(pageName);
			String expVisitDate=getExpectedVisitDateforManuallyAddedPatient();
			report.reportInfo("Expected Visit Date: "+expVisitDate);

			String actVistDate=null;
			if ("Account Search".contentEquals(pageName)) {
				actVistDate = webActions.waitAndGetText(lbl_VisitDate, "Visit Date");
			}
			else{
				driver.findElement(By.partialLinkText(accountNumber)).click();
				webActions.waitForVisibility(lbl_EventDateandTimeStamp, "EventDateandTimeStamp");
				webActions.waitForPageLoaded();
				actVistDate = webActions.waitAndGetText(lbl_DateOfService, "Date Of Service");
			}
			report.reportInfo("Actual Visit Date in "+pageName+" page: "+actVistDate);
			if(actVistDate.contains(expVisitDate)){
				report.reportPass("Successfully verified the Visit Date in the "+pageName+" page");
			}else{
				unmatch.append("Failed to verify the Visit Date in the "+pageName+" page");
				report.reportFail("Failed to verify the Visit Date in the "+pageName+" page", true);
			}

			String actEventType = null;
			String expEventType=expData.get(0);
			if ("Account Search".contentEquals(pageName)) {
				actEventType = webActions.waitAndGetText(lbl_EventType, "Event Type");
			}
			else{
				actEventType = webActions.waitAndGetText(lbl_EventType_AllData, "Event Type");
			}
			report.reportInfo("Actual Event Type in "+pageName+ "page: "+actEventType);

			if(actEventType.contains(expEventType)){
				report.reportPass("Successfully verified the Event Type in the "+pageName+" page");
			}else{
				unmatch.append("Failed to verify the Event Type in the "+pageName+" page");
				report.reportFail("Failed to verify the Event Type in the "+pageName+" page", true);
			}

			String actEmployeeName = null;
			String expEmployeeName=expData.get(1);
			if ("Account Search".contentEquals(pageName)) {
				actEmployeeName = webActions.waitAndGetText(lbl_EmployeeName, "Employee Name");
			}
			else{
				actEmployeeName = webActions.waitAndGetText(lbl_EmployeeName_AllData, "Employee Name");
			}
			report.reportInfo("Actual Employee Name in "+pageName+ "page: "+actEmployeeName);
			report.reportInfo("Expected Employee Name in "+pageName+ "page: "+expEmployeeName);
			if(actEmployeeName.contains(expEmployeeName)){
				report.reportPass("Successfully verified the Employee Name in the "+pageName+" page");
			}else{
				unmatch.append("Failed to verify the Employee Name in the "+pageName+" page");
				report.reportFail("Failed to verify the Employee Name in the "+pageName+" page", true);
			}

			report.reportInfo("Expected Event Date and Time  value: "+expVisitDate);
			String actEventDateTime=null;
			if ("Account Search".contentEquals(pageName)) {
				actEventDateTime = webActions.waitAndGetText(lbl_LastEventDate, "Last Event Date");
			}
			else{
				actEventDateTime = webActions.waitAndGetText(lbl_EventDateandTimeStamp, "Event Date and Time Stamp");
			}
			report.reportInfo("Actual Event Date and Time in "+pageName+ "page: "+actEventDateTime);

			if(actEventDateTime.contains(expVisitDate)){
				report.reportPass("Successfully verified the Event Date and Time in the "+pageName+" page");
			}else{
				unmatch.append("Failed to verify the Event Date and Time in the "+pageName+" page");
				report.reportFail("Failed to verify the Event Date and Time in the "+pageName+" page", true);
			}

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String getExpectedVisitDateforManuallyAddedPatient() throws Exception{
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyy hh:");  
		Date date = new Date();  
		String expDate=formatter.format(date); 
		return expDate;
	}

	public void verifyPatientDOBandGuarantorDBO(String patientDOB,String guarantorDOB){
		try {
			StringBuilder unmatch=new StringBuilder();
			String patientName=addPatient.notepadRead("patientData");
			report.reportInfo("Added new Patient Name is: "+patientName);
			String accountNumber=searchPatientNameinAccountSearchPage(patientName);
			String actPatientDOB=webActions.waitAndGetText(lbl_PatientDateofBirth_AccountSearch, "Patient DOB");
			report.reportInfo("Actual Patient DOB is in Account Search page: "+actPatientDOB);
			report.reportInfo("Expected Patient DOB is: "+patientDOB);
			if(actPatientDOB.contains(patientDOB)){
				report.reportPass("Successfully verified the Patient Date of Birth in the Account Search page");
			}
			else{
				unmatch.append("Failed to verify the Patient Date of Birth in the Account Search page");
				report.reportFail("Failed to verify the Patient Date of Birth in the Account Search page", true);
			}
			driver.findElement(By.partialLinkText(accountNumber)).click();
			webActions.waitForPageLoaded();
			String actPatientDOB_PatientVisit=webActions.waitAndGetText(lbl_PatientDateofBirth_AllData, "Patient DOB");
			report.reportInfo("Actual Patient DOB is in Patient Visit page: "+actPatientDOB_PatientVisit);
			if(actPatientDOB_PatientVisit.contains(patientDOB)){
				report.reportPass("Successfully verified the Patient Date of Birth in the Patient Visit page");
			}
			else{
				unmatch.append("Failed to verify the Patient Date of Birth in the Patient Visit page");
				report.reportFail("Failed to verify the Patient Date of Birth in the Patient Visit page", true);
			}
			clickOnAllDataLink();
			webActions.waitForPageLoaded();
			String actGuarantorDOB=webActions.waitAndGetText(lbl_GuarantorDateofBirth, "Guarantor Date of Birth");
			report.reportInfo("Actual Guarantor DOB in All Data page: "+actGuarantorDOB);
			report.reportInfo("Expected Guarantor DOB in All Data page: "+guarantorDOB);
			if(actGuarantorDOB.contains(guarantorDOB)){
				report.reportPass("Successfully verified the Guarantor Date of Birth in the All Data page");
			}else{
				unmatch.append("Failed to verify the Guarantor Date of Birth in the All Data page");
				report.reportFail("Failed to verify the Guarantor Date of Birth in the All Data page", true);
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(lbl_LastEventDate);
	}

}
