package com.ipas.hf.web.pages.ipasPages;


import java.awt.AWTException;
import java.awt.HeadlessException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.time.DateUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.akiban.sql.parser.DDLStatementNode;
import com.ipas.hf.actions.WebActions;
import com.ipas.hf.azureutilities.TodoDaoFactory;
import com.ipas.hf.reporting.StepLogging;
import com.ipas.hf.rest.RestActions;
import com.ipas.hf.testbase.TestBase;
import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class AAARuleAlertsPage extends BasePage {

	private JSONObject jsonObject;
	private static final String AAAALERTS = ".\\src\\main\\resources\\IPASTestData\\Body\\POSITIVE\\AAARuleAlerts.json";
	private StepLogging log = StepLogging.getLoggingObject();

	@FindBy(xpath = "//a[@class='breadcrum']")
	private WebElement lnk_AccountSearch;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr/td")
	private WebElement tbl_AccountSearchData;

	@FindBy(xpath = "//input[@placeholder='Type Account ID/Patient Name']")
	public WebElement txt_Search;

	@FindBy(xpath = "//ejs-textbox[@id='search_text']//input")
	private WebElement txt_Search_ST;

	@FindBy(xpath="//li[@id='p-highlighted-option']")
	private WebElement li_Search;

	@FindBy(xpath="//div[@class='e-gridcontent']//td[2]/div/a")
	private WebElement lnk_AccountNumber;

	@FindBy(xpath="//span[@class='breadcrum-active ng-star-inserted']")
	private WebElement lbl_AccountNumber;

	@FindBy(xpath="//table[@class='e-table']//thead/tr/th")
	private WebElement lbl_Headers_AS;

	@FindBy(xpath="//ipas-payment-facilitator-pannel/ejs-accordion/div")
	private WebElement tbl_PaymentFacilitatorPanel;

	@FindBy(xpath = "//ejs-dashboardlayout[@id='defaultLayout']//child::ejs-accordion")
	private List<WebElement> lbl_AllPanels;

	@FindBy(xpath = "//table[@id='asgrid_content_table']/tbody/tr")
	public List<WebElement> tbl_AccountSearch_Results;

	@FindBy(xpath = "//div[@class='details']")
	public List<WebElement> lbl_AllAlerts;

	@FindBy(xpath="//div[contains(@class,'pasentNameContainer')]//span[2]")
	private WebElement lbl_PatientLastName;

	@FindBy(xpath="//div[contains(@class,'active')]//button[@hideauthorize='ChallengeAlert']")
	private WebElement btn_Challenge;

	@FindBy(xpath="//span[@class='modal-title']")
	private WebElement lbl_ModelTitle;

	@FindBy(xpath="//textarea[@formcontrolname='challengeReasonComment']")
	private WebElement txt_ChallengeReasonComment;

	@FindBy(xpath="//div[@class='error ng-star-inserted']")
	private WebElement lbl_ErrorMessage;

	@FindBy(xpath="//button[@class='btn btn-primary'][contains(text(),'Challenge')]/../button[1]")
	private WebElement btn_Cancel;

	@FindBy(xpath="//div[@class='challengeAlertDialog modal-header']/span[2]/button")
	private WebElement btn_CloseX;

	@FindBy(xpath="//button[@class='btn btn-primary'][contains(text(),'Challenge')]")
	private WebElement btn_Challenge_Popup;

	@FindBy(xpath="//ejs-dropdownlist[@formcontrolname='challengeReasonId']/span")
	private WebElement dd_ChallengeReason;

	@FindBy(xpath="//button[@class='btn btn-primary'][contains(text(),'Challenge')]/../button[2]")
	private WebElement btn_Save;

	@FindBy(xpath="//div[@class='carousel-item active ng-star-inserted']/div[2]//label")
	private WebElement lbl_AlertWasChallenge;

	@FindBy(xpath = "//div[@class='e-toast-message']")
	private WebElement txt_ToastMsgs;

	@FindBy(xpath="//div[@class='carousel-item active ng-star-inserted']/div[3]/div")
	private List<WebElement> lbl_AlertData;

	@FindBy(xpath = "//div[@class='carousel-item active ng-star-inserted']/div[4]/span")
	private WebElement lbl_ErrorData;

	@FindBy(xpath = "//div[@class='carousel-item active ng-star-inserted']/div[4]/div/span")
	private WebElement lbl_ElementName;

	@FindBy(xpath = "//img[@alt='settings']")
	private WebElement img_Settings;

	@FindBy(xpath = "//span[text()='Logout']")
	private WebElement btn_Logout;

	@FindBy(xpath = "//button[@hideauthorize='ReviewAlertChallenge']")
	private WebElement btn_ReviewChallenge;

	@FindBy(xpath="//tr[@class='white-color ng-star-inserted']/td")
	private List<WebElement> li_ReviewChallengeData;

	@FindBy(xpath = "//tr[@class='white-color ng-star-inserted']/td[2]/div")
	private WebElement lbl_OperatorID;

	@FindBy(xpath = "//span[(text()='Review Challenge')]")
	private WebElement lbl_WindowTitle_ReviewChallenge;

	@FindBy(xpath = "//textarea[@formcontrolname='challengeResponseComment']")
	private WebElement txt_ReviewComments;

	@FindBy(xpath = "//div[@id='challengeReviewDialogId']/div/div/div[1]//button")
	private WebElement btn_CloseX_ReviewChallenge;

	@FindBy(xpath = "//tr[@class='e-columnheader']/th[1]/div//ejs-checkbox")
	private WebElement  chk_SelectAll;

	@FindBy(xpath = "//div/table/tbody/tr[1]/td[1]/ejs-checkbox/label")
	private WebElement  chk_FirstRow;

	@FindBy(xpath = "//ejs-dropdownlist[@formcontrolname='challengeResponseId']/span/input")
	private WebElement  dd_ChallengeResponse;

	@FindBy(xpath = "//button[contains(text(),'Reject')]")
	private WebElement btn_Reject;

	@FindBy(xpath = "//button[contains(text(),'Accept')]")
	private WebElement btn_Accept;

	String button="//button[contains(text(),'";
	String button1="')]";

	@FindBy(xpath="//span[(text()='Account No')]/../../div[3]")//th[2]/div[3]
	public WebElement btn_AccountNumberFilter;

	@FindBy(xpath = "(//ejs-grid//tbody)[2]/tr/td[7]/div/div")
	private List<WebElement> tr_RuleTitle;
	
	@FindBy(xpath = "(//ejs-grid//tbody)[2]/tr/td[6]/div/div")
	private List<WebElement> tr_RuleTitle_Challenge;

	@FindBy(xpath="//input[@placeholder='Search']")
	public WebElement txt_AccountSearchBox;

	@FindBy(xpath="//button[contains(text(),'Filter')]")
	public WebElement btn_Filter;

	@FindBy(xpath="//div[contains(text(),'Challenge')]")
	private WebElement btn_Challenge_Worklist;

	@FindBy(xpath = "(//ejs-grid//tbody)[2]/tr/td[9]")
	private List<WebElement> tr_Challenged;	
	
	@FindBy(xpath = "(//ejs-grid//tbody)[2]/tr/td[10]")
	private List<WebElement> tr_Challenged_AATab;	

	@FindBy(xpath="//a[contains(text(),'Worklists')]")
	private WebElement lnk_WorkList;

	@FindBy(xpath="//div[contains(text(),'Account Error')]")
	private WebElement btn_AccuracyAccountability;

	@FindBy(xpath="//span[contains(text(),'No Matches Found')]")
	public WebElement lbl_NoMatchMsg;

	@FindBy(xpath = "//div[@class='details']")
	public WebElement lbl_AllRuleAlerts;

	@FindBy(xpath="//div[contains(@class,'pasentNameContainer')]//span[1]")
	private WebElement lbl_PatientFirstName;

	@FindBy(xpath="//span[contains(text(),'Guarantor Information')]/../../../div[2]/div/div/div[1]/span/span[1]")
	private WebElement lbl_GuarantorFirstName;

	@FindBy(xpath="//span[contains(text(),'Guarantor Information')]/../../../div[2]/div/div/div[1]/span/span[2]")
	private WebElement lbl_GuarantorLastName;

	@FindBy(xpath="//span[contains(text(),'Guarantor Information')]/../../../div[2]/div/div/table[3]/tr[2]/td[3]/span")
	private WebElement lbl_GuarantorAddress;

	@FindBy(xpath="//span[contains(text(),'Patient Contact Information')]/../../../div[2]/div/div/div[1]/span/span[1]")
	private WebElement lbl_EmergencyContactFName;

	@FindBy(xpath="//span[contains(text(),'Patient Contact Information')]/../../../div[2]/div/div/div[1]/span/span[2]")
	private WebElement lbl_EmergencyContactLName;

	@FindBy(xpath="//span[contains(text(),'Patient Contact Information')]/../../../div[2]/div/div/table[1]/tr[2]/td[1]/ng-contaner/span")
	private WebElement lbl_EmergencyContactAddress;

	@FindBy(xpath="(//td[contains(text(),'Relationship')])[4]")
	private WebElement lbl_EmergencyContactRelationship;
			
	@FindBy(xpath="//span[contains(text(),'Insurance Information')]/../../../div[2]/div/div/table[4]/tr[2]/td[1]/span/span[1]")
	private WebElement lbl_InsuredFirstName;

	@FindBy(xpath="//a[contains(text(),'All Data')]")
	private WebElement lnk_AllData;
	
	@FindBy(xpath = "(//ejs-grid//tbody)[2]/tr/td[11]/div/div")
	private List<WebElement> tr_EmployeeName;

	private RestActions rest = new RestActions();
	WorkListPage work=new WorkListPage();

	public AAARuleAlertsPage() {
		PageFactory.initElements(driver, this);
	}


	public void searchAccountNuberinAccountSearchPage() throws Exception{
		try {
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_Search, getAccountNumber(), "Simple Search");
			webActions.waitForPageLoaded();
			webActions.waitForClickAbility(li_Search, "Account Numnber list");
			webActions.waitForPageLoaded();
			webActions.click(li_Search, "Account Numnber list");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_Headers_AS,"Account Search Headers");
			driver.findElement(By.partialLinkText(getAccountNumber())).click();
			waitforAllPanels();
			waitforAllAlerts();
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void waitforAllAlerts(){
		try {
			webActions.waitForVisibilityOfAllElements(lbl_AllAlerts, "All Alerts");
		} catch (Exception e) {
		}
	}


	public void waitforAllPanels(){
		try {
			webActions.waitForVisibilityOfAllElements(lbl_AllPanels, "All Panels");
		} catch (Exception e) {
		}
	}

	public void verifyAllRuleAlerts(DataTable testData){
		try {
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			StringBuffer unmatch=new StringBuffer();
			searchAccountNuberinAccountSearchPage();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			ArrayList<String> actData=webActions.getDatafromWebTable(lbl_AllAlerts);
			Collections.sort(actData);
			report.reportInfo("Actual Rule Alerts: "+actData);
			/*report.reportInfo("Actual Rule Alerts count: "+actData.size());*/
			
			/*Collections.sort(expData);
			report.reportInfo("Expected Rule Alerts: "+expData);
			report.reportInfo("Expected Rule Alerts count: "+expData.size());*/
			
			/*if(actData.size()==expData.size()){
				report.reportPass("All Rule Alerts are displayed successfully");
			}else{
				unmatch.append("Failed to display the All Rule Alerts");
				report.reportFail("Failed to display the All Rule Alerts",true);
			}*/
			
			if (actData.contains(expData.get(0))) {
				report.reportPass("Successfully verified the AAA Rule");
			}else{
				report.reportFail("Failed to verify the AAA Rule",true);
				unmatch.append("Failed to verify the AAA Rule");
			}

			String actPatientStatus=webActions.getAttributeValue(lbl_PatientLastName, "style", "Patient Last Name");
			if(actPatientStatus.contains("red")){
				report.reportPass("Successfully verified the Rule Alert for Patient Last Name field ");
			}else{
				unmatch.append("Failed to verify the Rule Alert for Patient Last Name field");
				report.reportFail("Failed to verify the Rule Alert for Patient Last Name field",true);
			}

			/*ArrayList<String>unmatchedAlerts=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatchedAlerts.size()==0){
				report.reportPass("Successfully verified the description for all rule alerts");
			}else{
				unmatch.append("Failed to verify the description for rule alerts");
				report.reportFail("Failed to verify the description for rule alerts: "+unmatchedAlerts,true);
			}*/
			if(unmatch.length()!=0){
				report.reportFail("Fail to verify all rule alerts: "+unmatch);
			}
			
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyAllRuleAlertsforUpdatedVisitAccount(DataTable testData){
		try {
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			StringBuffer unmatch=new StringBuffer();
			searchAccountNuberinAccountSearchPage();
			ArrayList<String> actData=webActions.getDatafromWebTable(lbl_AllAlerts);
			Collections.sort(actData);
			report.reportInfo("Actual Rule Alerts: "+actData);
			/*report.reportInfo("Actual Rule Alerts count: "+actData.size());
			
			Collections.sort(expData);
			report.reportInfo("Expected Rule Alerts: "+expData);
			report.reportInfo("Expected Rule Alerts count: "+expData.size());
			if(actData.size()==expData.size()){
				report.reportPass("All Rule Alerts are displayed successfully when receive same visit account with updated patient data");
			}else{
				unmatch.append("Failed to display the All Rule Alerts when receive same visit account with updated patient data");
				report.reportFail("Failed to display the All Rule Alerts when receive same visit account with updated patient data",true);
			}*/
			
			if (!actData.contains(expData.get(0))) {
				report.reportPass("Successfully verified the AAA Rule");
			}else{
				report.reportFail("Failed to verify the AAA Rule",true);
				unmatch.append("Failed to verify the AAA Rule");
			}

			String actPatientStatus = null;
			try {
				actPatientStatus = webActions.getAttributeValue(lbl_PatientLastName, "style", "Patient Last Name");
			} catch (Exception e) {
				actPatientStatus="";
			}
			if(actPatientStatus.contains("")){
				report.reportPass("Successfully verified the Rule Alert for Patient Last Name field for the updated visit account");
			}else{
				unmatch.append("Failed to verify the Rule Alert for Patient Last Name field for the updated visit account");
				report.reportFail("Failed to verify the Rule Alert for Patient Last Name field for the updated visit account",true);
			}

			/*ArrayList<String>unmatchedAlerts=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatchedAlerts.size()==0){
				report.reportPass("Successfully verified the description for all rule alerts when receive same visit account with updated patient data");
			}else{
				unmatch.append("Failed to verify the description for rule alerts when receive same visit account with updated patient data");
				report.reportFail("Failed to verify the description for rule alerts when receive same visit account with updated patient data: "+unmatchedAlerts,true);
			}*/
			
			if(unmatch.length()!=0){
				report.reportFail("Fail to verify all rule alerts when receive same visit account with updated patient data: "+unmatch);
			}
			
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void clickOnChallengeButton(String expAlertName){
		try {
			searchAccountNuberinAccountSearchPage();
			try {
				webActions.waitForVisibility(lbl_AllRuleAlerts, "AllRuleAlerts", 10);
			} catch (Exception e) {
			}
			List<WebElement> alertNames=driver.findElements(By.xpath("//div[@class='details']"));
			for (WebElement alertText : alertNames) {
				String actName=alertText.getText();
				if(actName.contains(expAlertName)){
					alertText.click();
					webActions.waitForPageLoaded();
					break;
				}
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.waitAndClick(btn_Challenge, "Challenge");
			webActions.waitAndGetText(lbl_ModelTitle, "Model Title");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void clickOnRuleAlertLink(String expAlertName){
		try {
			searchAccountNuberinAccountSearchPage();
			try {
				webActions.waitForVisibility(lbl_AllRuleAlerts, "AllRuleAlerts", 10);
			} catch (Exception e) {
			}
			List<WebElement> alertNames=driver.findElements(By.xpath("//div[@class='details']"));
			for (WebElement alertText : alertNames) {
				String actName=alertText.getText();
				if(actName.contains(expAlertName)){
					alertText.click();
					webActions.waitForPageLoaded();
					break;
				}
			}
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyRuleAlertInformationData(DataTable testData){
		try {
			ArrayList<String>expData=new ArrayList<String>(testData.asList());
			ArrayList<String>actData=new ArrayList<String>();
			webActions.waitForPageLoaded();
			webActions.waitAndGetText(lbl_ErrorData, "ErrorData");
			actData.addAll(webActions.getDatafromWebTable(lbl_AlertData));
			actData.add(webActions.getText(lbl_ErrorData, "Error Data"));
			actData.add(webActions.getText(lbl_ElementName, "Element Name"));
			report.reportInfo("Actual Rule Alert Information data: "+actData);
			report.reportInfo("Expected Rule Alert Information data: "+actData);
			ArrayList<String>unmatch=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatch.size()==0){
				report.reportPass("Rule Alert Information Data verified successfully");
			}else{
				report.reportFail("Rule Alert Information Data verification failed and unmatched data is: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyValidationsOnChallengeAlertWindow(String errorMessage){
		try {
			StringBuilder unmatch=new StringBuilder();
			webActions.click(txt_ChallengeReasonComment, "Challenge Reason");
			webActions.click(lbl_ModelTitle, "Model Title");
			String actError=webActions.waitAndGetText(lbl_ErrorMessage, "Error Message");
			if(actError.contentEquals(errorMessage)){
				report.reportPass("Successfully verified mandatory field validation error message");
			}else{
				report.reportFail("Failed to verify the mandatory field validation error message", true);
				unmatch.append("Failed to verify the mandatory field validation error message");
			}
			webActions.click(btn_Cancel, "Cancel");
			webActions.waitForPageLoaded();
			try {
				webActions.click(btn_Challenge, "Challenge");
				report.reportPass("Successfully verified the Cancel button functionality");
			} catch (Exception e) {
				report.reportFail("Failed to verify the Cancel button functionality", true);
				unmatch.append("Failed to verify the Cancel button functionality");
			}

			try {
				webActions.click(btn_CloseX, "Close");
				report.reportPass("Successfully verified the Close button functionality");
			} catch (Exception e) {
				report.reportFail("Failed to verify the Close button functionality", true);
				unmatch.append("Failed to verify the Close button functionality");
			}

			if(unmatch.length()==0){
				report.reportPass("Successfully verified mandatory field validation error message and cancel button functionality");
			}
			else{
				report.reportFail("Failed to verify the mandatory field validation error message and cancel button functionality: "+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void challengeAlert(DataTable testData){
		try {
			StringBuffer unmatch=new StringBuffer();
			webActions.waitForPageLoaded();
			webActions.sendKeys(dd_ChallengeReason, getDatafromMap(testData, "Challenge Reason"), "Challenge Reason");
			webActions.click(lbl_ModelTitle, "Model Title");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_ChallengeReasonComment,getDatafromMap(testData, "Challenge Comment"), "Challenge Comment");
			webActions.click(btn_Save, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			if(actContent.contains(getDatafromMap(testData,"Alert Message"))){
				report.reportPass("Successfully verified the Challenged the Alert message");
			}else{
				report.reportFail("Failed verify the Challenge the Alert message",true);
				unmatch.append("Failed verify the Challenge the Alert message");
			}
			webActions.waitForPageLoaded();
			String actText=webActions.waitAndGetText(lbl_AlertWasChallenge, "AlertWasChallenge");
			if(getDatafromMap(testData, "Message").contentEquals(actText)){
				report.reportPass("Successfully verified the label name after challenge the alert");
			}else{
				report.reportFail("Failed to verify the label name after challenge the alert",true);
				unmatch.append("Failed to verify the label name after challenge the alert");
			}
			if(unmatch.length()==0){
				report.reportPass("Successfully challenge the alert");
			}else{
				report.reportFail("Failed to challenge the alert: "+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyReviewChallengeButton(){
		try {
			webActions.waitForPageLoaded();
			String actButtonName=webActions.waitAndGetText(btn_ReviewChallenge,"Review Challege");
			if(actButtonName.contains("Review Challenge")){
				report.reportPass("Successfully verified Review Challenge button: "+actButtonName);
			}else{
				report.reportFail("Failed to verify the Review Challenge button: "+actButtonName);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void clickOnReviewChallenge(String expAlertName){
		try {
			searchAccountNuberinAccountSearchPage();
			try {
				webActions.waitForVisibility(lbl_AllRuleAlerts, "AllRuleAlerts", 10);
			} catch (Exception e) {
			}
			List<WebElement> alertNames=driver.findElements(By.xpath("//div[@class='details']"));
			for (WebElement alertText : alertNames) {
				String actName=alertText.getText();
				if(actName.contains(expAlertName)){
					alertText.click();
					webActions.waitForPageLoaded();
					break;
				}
			}
			webActions.waitForPageLoaded();
			webActions.waitAndGetText(btn_ReviewChallenge,"Review Challege");
			webActions.waitForClickAbilityAndClick(btn_ReviewChallenge, "ReviewChallenge");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyChallengeDataMandatoryFieldValidationAndCloseWindow(String expError,DataTable testData){
		try {
			StringBuilder unmatch=new StringBuilder();
			ArrayList<String> expData=new ArrayList<String>(testData.row(1));
			expData.add(webActions.getSystemCurrentDate());
			webActions.waitForPageLoaded();
			report.reportInfo("Expected Challenge Data is: "+expData);
			ArrayList<String> actData =new ArrayList<String>();
			List<WebElement> allElement = li_ReviewChallengeData;
			for (WebElement we: allElement) { 
				String txt=we.getText();
				txt=txt.replace("\n", " ").replace("\r", " ");
				if(!txt.isEmpty()){
					actData.add(txt);
				}
			}
			report.reportInfo("Actual Challenge Data is: "+actData);
			ArrayList<String> unmatchData=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatchData.size()==0){
				report.reportPass("Successfully verified the challenge data");
			}else{
				report.reportFail("Failed to verify the challenge data: "+unmatchData,true);
				unmatch.append("Failed to verify the challenge data: "+unmatchData);
			}
			webActions.click(txt_ReviewComments, "Review Comments");
			webActions.click(lbl_WindowTitle_ReviewChallenge, "Review Challenge");
			String actError=webActions.waitAndGetText(lbl_ErrorMessage, "Error Message");
			if(actError.contentEquals(expError)){
				report.reportPass("Successfully verified the mandatory field validation message");
			}else{
				report.reportFail("Failed to verify the mandatory field validation message: "+actError,true);
				unmatch.append("Failed to verify the mandatory field validation message: "+actError);
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void reviewChallenge(String reviewType,DataTable testData){
		try {
			StringBuffer unmatch=new StringBuffer();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(chk_SelectAll, "Select All");
			webActions.waitForPageLoaded();
			webActions.sendKeys(dd_ChallengeResponse, getDatafromMap(testData, "Challenge Response"), "ChallengeResponse");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_ReviewComments, getDatafromMap(testData, "Review Comments"), "ReviewComments");
			webActions.waitForPageLoaded();
			driver.findElement(By.xpath(button+reviewType+button1)).click();
			//webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			if(actContent.contains(getDatafromMap(testData,"Alert Message"))){
				report.reportPass("Successfully verified the Review Challenge Alert message when "+reviewType+" challenge");
			}else{
				report.reportFail("Failed verify the Review Challenge Alert message when "+reviewType+" challenge: "+actContent,true);
				unmatch.append("Failed verify the Review Challenge Alert message when "+reviewType+" challenge");
			}
			webActions.waitForPageLoaded();
			boolean buttonDisplayed = false;
			try {
				buttonDisplayed=webActions.isDisplayed(btn_ReviewChallenge, "ReviewChallenge");
			} catch (Exception e) {
			}
			if(buttonDisplayed==false){
				report.reportPass("Successfully verified Review Challenge button is not displayed after "+reviewType+" the challenge");
			}else{
				report.reportFail("Failed to verify Review Challenge button is displaying even after "+reviewType+" the challenge",true);
				unmatch.append("Failed to verify Review Challenge button is displaying even after "+reviewType+" the challenge");
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyAlertStausAfterReviewChallenge(String expStatus,String reviewType){
		try {
			webActions.waitForPageLoaded();
			String actText=webActions.waitAndGetText(lbl_AlertWasChallenge, "AlertWasChallenge");
			if(expStatus.contentEquals(actText)){
				report.reportPass("Successfully verified the alert status for employee when challenge was "+reviewType+"");
			}else{
				report.reportFail("Failed to verify the alert status for employee when challenge was "+reviewType+"");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void logout(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitForClickAbilityAndClick(img_Settings, "Settings");
			webActions.click(btn_Logout, "Logout");
			report.reportPass("Successfully logout the application");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void filterWithAccountNumber(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_AccountNumberFilter, "AccountNumberFilter");
			webActions.sendKeys(txt_AccountSearchBox, getAccountNumber(), "Search");
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			webActions.click(btn_Filter, "Filter");
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public ArrayList<String> getRuleTitle(){
		ArrayList<String>actData = new ArrayList<String>();
		try {
			webActions.waitForPageLoaded();
			actData=webActions.getDatafromWebTable(tr_RuleTitle);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
		return actData;
	}
	
	public ArrayList<String> getRuleTitle_ChanllengeTab(){
		ArrayList<String>actData = new ArrayList<String>();
		try {
			webActions.waitForPageLoaded();
			actData=webActions.getDatafromWebTable(tr_RuleTitle_Challenge);
		} catch (Exception e) {
			report.reportFail(""+e);
		}
		return actData;
	}

	public void verifyRuleAlertsinWorklists(DataTable testData){
		try {
			ArrayList<String>expData=new ArrayList<String>(testData.asList());
			Collections.sort(expData);
			StringBuffer unmatch=new StringBuffer();
			filterWithAccountNumber();
			/*int actCount=work.getResultsCount();
			report.reportInfo("AAA Rule Alerts Count is: "+actCount);
			if(expData.size()==actCount){
				report.reportPass("Successfully verified the AAA Rule Alerts count");
			}else{
				report.reportFail("Failed to verify AAA Rule Alerts count: "+actCount,true);
				unmatch.append("Failed to verify AAA Rule Alerts count "+actCount);
			}*/
			ArrayList<String>actData=getRuleTitle();
			Collections.sort(actData);  
			report.reportInfo("Actual AAA Rule Title is: "+actData);
			report.reportInfo("Expected AAA Rule Title is: "+expData);
			if (actData.contains(expData.get(0))) {
				report.reportPass("Successfully verified the AAA Rule Title in Worklists");
			}else{
				report.reportFail("Failed to verify the AAA Rule Titles Worklists: ",true);
				unmatch.append("Failed to verify the AAA Rule Titles Worklists");
			}
			/*ArrayList<String>unmatchData=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatchData.size()==0){
				report.reportPass("Successfully verified the AAA Rule Titles");
			}else{
				report.reportFail("Failed to verify the AAA Rule Titles: "+unmatchData,true);
				unmatch.append("Failed to verify the AAA Rule Titles: "+unmatchData);
			}*/
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyChallengedAlert(DataTable testData){
		try {
			ArrayList<String>expData=new ArrayList<String>(testData.asList());
			webActions.waitForPageLoaded();
			webActions.click(lnk_WorkList, "Worklist");
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibilityOfAllElements(tr_Challenged_AATab, "Alerts");
			} catch (Exception e) {
			}
			webActions.waitAndClick(btn_Challenge_Worklist, "Challenge");
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibilityOfAllElements(tr_Challenged, "Alerts");
			} catch (Exception e) {
			}
			filterWithAccountNumber();
			ArrayList<String>actData=getRuleTitle_ChanllengeTab();
			report.reportInfo("Actual Challenged Rule Title is: "+actData);
			report.reportInfo("Expected Challenged Rule Title is: "+expData);
			ArrayList<String>unmatchData=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatchData.size()==0){
				report.reportPass("Successfully verified the Challenged Rule Titles");
			}else{
				report.reportFail("Failed to verify the Challenged Rule Titles: "+unmatchData);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyChallengedAlertinAccuracyAccountabilityTab(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(btn_AccuracyAccountability, "Accuracy & Accountability");
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibilityOfAllElements(tr_Challenged_AATab, "Alerts");
			} catch (Exception e) {
			}
			webActions.waitForPageLoaded();
			filterWithAccountNumber();
			ArrayList<String>actData=webActions.getDatafromWebTable(tr_Challenged_AATab);
			int statusCount=actData.size();
			int IterateCount=0;
			for (String actText: actData) {
				if(actText.contentEquals("Challenged")){
					report.reportPass("Successfully verified the Challenged alert in Accuracy & Accountability");
					break;
				}
				IterateCount++;
				if(statusCount==IterateCount){
					report.reportFail("Failed to verify the Challenged alert in Accuracy & Accountability");
				}
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyRejectedRuleAlertsinAccuracyAccountabilityTab(){
		try {
			navigateWorkLists();
			webActions.waitForPageLoaded();
			filterWithAccountNumber();
			ArrayList<String>actData=webActions.getDatafromWebTable(tr_Challenged_AATab);
			int statusCount=actData.size();
			int IterateCount=0;
			for (String actText: actData) {
				if(actText.contentEquals("Rejected")){
					report.reportPass("Successfully verified the Rejected alert in Accuracy & Accountability");
					break;
				}
				IterateCount++;
				if(statusCount==IterateCount){
					report.reportFail("Failed to verify the Rejected alert in Accuracy & Accountability");
				}
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyRejectedRuleAlertinChallengedTab(String expMessage){
		try {
			webActions.waitAndClick(btn_Challenge_Worklist, "Challenge");
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibilityOfAllElements(tr_Challenged_AATab, "Alerts");
			} catch (Exception e) {
			}
			webActions.waitAndClick(btn_AccountNumberFilter, "AccountNumberFilter");
			webActions.sendKeys(txt_AccountSearchBox, getAccountNumber(), "Search");
			webActions.waitForVisibility(lbl_NoMatchMsg, "Message");
			String actMsg=webActions.getText(lbl_NoMatchMsg, "Message");
			if(actMsg.contentEquals(expMessage)){
				report.reportPass("Verified validation message successfully");
			}else{
				report.reportFail("Fail to Verify validation message");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void reviewChallengeForMultipleUsers(String reviewType,DataTable testData){
		try {
			StringBuffer unmatch=new StringBuffer();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(chk_FirstRow, "First Row");
			webActions.sendKeys(dd_ChallengeResponse, getDatafromMap(testData, "Challenge Response"), "ChallengeResponse");
			webActions.sendKeys(txt_ReviewComments, getDatafromMap(testData, "Review Comments"), "ReviewComments");
			driver.findElement(By.xpath(button+reviewType+button1)).click();
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			if(actContent.contains(getDatafromMap(testData,"Alert Message"))){
				report.reportPass("Successfully verified the Review Challenge Alert message when "+reviewType+" challenge");
			}else{
				report.reportFail("Failed verify the Review Challenge Alert message when "+reviewType+" challenge: "+actContent,true);
				unmatch.append("Failed verify the Review Challenge Alert message when "+reviewType+" challenge");
			}
			webActions.waitForPageLoaded();
			String actChallengeCount=webActions.waitAndGetText(btn_ReviewChallenge, "ReviewChallenge");
			if(actChallengeCount.contains("1")){
				report.reportPass("Successfully verified challenge count after "+reviewType+" one challenge when having multiple challenges");
			}else{
				report.reportPass("Fail to verify the challenge count after "+reviewType+" one challenge when having multiple challenges");
				unmatch.append("Fail to verify the challenge count after "+reviewType+" one challenge when having multiple challenges");
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void reviewSecondChallengeForMultipleUsers(String reviewType,DataTable testData){
		try {
			StringBuffer unmatch=new StringBuffer();
			webActions.waitForPageLoaded();
			webActions.waitAndClick(btn_ReviewChallenge, "ReviewChallenge");
			webActions.waitAndClick(chk_FirstRow, "First Row");
			webActions.sendKeys(dd_ChallengeResponse, getDatafromMap(testData, "Challenge Response"), "ChallengeResponse");
			webActions.sendKeys(txt_ReviewComments, getDatafromMap(testData, "Review Comments"), "ReviewComments");
			driver.findElement(By.xpath(button+reviewType+button1)).click();
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			if(actContent.contains(getDatafromMap(testData,"Alert Message"))){
				report.reportPass("Successfully verified the Review Challenge Alert message when "+reviewType+" challenge");
			}else{
				report.reportFail("Failed verify the Review Challenge Alert message when "+reviewType+" challenge: "+actContent,true);
				unmatch.append("Failed verify the Review Challenge Alert message when "+reviewType+" challenge");
			}
			webActions.waitForPageLoaded();
			boolean buttonDisplayed = false;
			try {
				buttonDisplayed=webActions.isDisplayed(btn_ReviewChallenge, "ReviewChallenge");
			} catch (Exception e) {
			}
			if(buttonDisplayed==false){
				report.reportPass("Successfully verified Review Challenge button is not displayed after "+reviewType+" the challenge");
			}else{
				report.reportFail("Failed to verify Review Challenge button is displaying even after "+reviewType+" the challenge",true);
				unmatch.append("Failed to verify Review Challenge button is displaying even after "+reviewType+" the challenge");
			}
			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyAllDataElementsInRed(){
		try {
			StringBuffer unmatch=new StringBuffer();
			searchAccountNuberinAccountSearchPage();
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibility(lbl_AllRuleAlerts, "AllRuleAlerts", 10);
			} catch (Exception e) {
			}
			unmatch.append(verifyDataElementsInRed(lbl_PatientFirstName,"PatientFirstName"));
			unmatch.append(verifyDataElementsInRed(lbl_PatientLastName,"PatientLastName"));

			webActions.waitAndClick(lnk_AllData, "All Data");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_GuarantorFirstName, "GuarantorFirstName", 15);
			
			unmatch.append(verifyDataElementsInRed(lbl_GuarantorFirstName,"GuarantorFirstName"));
			unmatch.append(verifyDataElementsInRed(lbl_GuarantorLastName,"GuarantorLastName"));
			unmatch.append(verifyDataElementsInRed(lbl_GuarantorAddress,"GuarantorAddress"));
			unmatch.append(verifyDataElementsInRed(lbl_EmergencyContactRelationship,"EmergencyContactRelationship"));

			if(unmatch.length()!=0){
				report.reportFail(""+unmatch);
			}

		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String verifyDataElementsInRed(WebElement element, String elementName){
		String expField="red";
		String unmatch="";
		String patientFirstName=webActions.getAttributeValue(element, "style", elementName);
		if(patientFirstName.contains(expField)){
			report.reportPass("Successfully displayed "+elementName+" in Red");
		}else{
			report.reportFail("Fail to display the "+elementName+" in Red",true);
			//unmatch.append("Fail to display the "+elementName+" in Red");
			unmatch="Fail to display the "+elementName+" in Red";
		}
		return unmatch;
	}

	public void navigateWorkLists(){
		try {
			webActions.waitForPageLoaded();
			webActions.click(lnk_WorkList, "Worklist");
			webActions.waitForPageLoaded();
			try {
				webActions.waitForVisibilityOfAllElements(tr_Challenged, "Alerts");
			} catch (Exception e) {
			}
		} catch (Exception e) {
		}
	}
	
	public void clickReviewChallengeButton(){
		try {
			webActions.waitForPageLoaded();
			webActions.waitAndGetText(btn_ReviewChallenge,"Review Challege");
			webActions.waitForClickAbilityAndClick(btn_ReviewChallenge, "ReviewChallenge");
		} catch (Exception e) {
		}
	}
	
	public void challengeAlertforSupervisor(DataTable testData){
		try {
			webActions.waitForPageLoaded();
			webActions.sendKeys(dd_ChallengeReason, getDatafromMap(testData, "Challenge Reason"), "Challenge Reason");
			webActions.click(lbl_ModelTitle, "Model Title");
			webActions.waitForPageLoaded();
			webActions.sendKeys(txt_ChallengeReasonComment,getDatafromMap(testData, "Challenge Comment"), "Challenge Comment");
			webActions.click(btn_Save, "Save");
			webActions.waitForVisibility(txt_ToastMsgs, "Messages");
			String msg = webActions.waitAndGetText(txt_ToastMsgs, "Messages");
			String[] titleContent=msg.split("\\n");
			String actContent = titleContent[1];
			report.reportInfo("Actual alert message: "+actContent);
			if(actContent.contains(getDatafromMap(testData,"Alert Message"))){
				report.reportPass("Successfully verified the Challenged the Alert message");
			}else{
				report.reportFail("Failed verify the Challenge the Alert message");
			}
			webActions.waitForPageLoaded();
			
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void verifyWorkListForSupervisor(String supervisor,String employee){
		try {
			navigateWorkLists();
			webActions.waitForPageLoaded();
			filterWithAccountNumber();
			webActions.waitForPageLoaded();
			ArrayList<String> actData=getEmployeeNameforSupervisorUser();
			//ArrayList<String> actData=webActions.getDatafromWebTable(tr_EmployeeName);
			ArrayList<String> unmatchdata=new ArrayList<>();
			
			for (int data = 0; data < actData.size(); data++) {
				if ((actData.get(data).contains(supervisor)||(actData.get(data).contains(employee)))) {
					/*unmatchdata.add("unmatched data in row no: " + data + " and data is: " + actData.get(data));
					log.info(" unmatched data in row no: " + data + " and actual data is : " + actData.get(data)
					+ " is not matched with expected data: " + supervisor +" or "+employee);*/
					report.reportPass("Worklist for Supervisor user: "+data+" : "+actData.get(data));
				}else{
					unmatchdata.add("Unmatched data in row no: " + data + " and data is: " + actData.get(data));
					report.reportFail("Worklist for Supervisor user: "+data+" : "+actData.get(data));
				}
			} 
			if(unmatchdata.size()==0){
				report.reportPass("Successfully verified the worklist for Supervisor user: "+actData);
			}
			else{
				report.reportFail("Fail to verify the worklist for Supervisor user: "+unmatchdata);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
		
	}
	public ArrayList<String> getEmployeeNameforSupervisorUser(){
		ArrayList<String> actEmployee=new ArrayList<String>();
		List<WebElement>row=tr_EmployeeName;
		/*for (int i = 0; i <8; i++) {
			actEmployee.add(row.get(i).getText());
			//actEmployee.add(txt);
		}*/
		for (WebElement webElement : row) {
			actEmployee.add(webElement.getText());
		}
		return actEmployee;
	}


	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}
	
	public void verifyAllRuleAlertsWhenPatientVisitDataUpdated(DataTable testData){
		try {
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			searchAccountNuberinAccountSearchPage();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			ArrayList<String> actData=webActions.getDatafromWebTable(lbl_AllAlerts);
			Collections.sort(actData);
			report.reportInfo("Actual Rule Alerts when patient visit data is updated: "+actData);
			if (!actData.contains(expData.get(0))) {
				report.reportPass("Successfully verified the AAA Rule when patient visit data is updated");
			}else{
				report.reportFail("Failed to verify the AAA Rule when patient visit data is updated");
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public void verifyRuleAlertForNewPatientVisit(DataTable testData){
		try {
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			StringBuffer unmatch=new StringBuffer();
			searchAccountNuberinAccountSearchPage();
			webActions.waitForPageLoaded();
			webActions.waitForJSandJQueryToLoad();
			ArrayList<String> actData=webActions.getDatafromWebTable(lbl_AllAlerts);
			Collections.sort(actData);
			report.reportInfo("Actual Rule Alerts: "+actData);
			
			if (actData.contains(expData.get(0))) {
				report.reportPass("Successfully verified the AAA Rule");
			}else{
				report.reportFail("Failed to verify the AAA Rule",true);
				unmatch.append("Failed to verify the AAA Rule");
			}
			
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public String getAccountNumber(){
		String expectedResponseValue=null;
		try {
			FileReader reader = new FileReader(AAAALERTS);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			expectedResponseValue = (String) visitObject.get("AccountNumber");	
		} catch (Exception e) {
			report.reportHardFail(e.getMessage());
		}
		return expectedResponseValue;

	}

	@SuppressWarnings("unchecked")
	public void updateAAARuleAlertJSON() throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(AAAALERTS);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			JSONObject visitObject = (JSONObject) jsonObject.get("Visit");
			JSONObject appointmentObject = (JSONObject) jsonObject.get("Appointment");
			try {
				String number = rest.getUniqueNumber();
				newNum = "A" + number;
				JSONArray msg = (JSONArray) patientObject.get("TenantPatientIdentifier");
				JSONObject tenantPatient = (JSONObject) msg.get(0);
				tenantPatient.put("TenantPatientId", newNum);

				tenantPatient = (JSONObject) msg.get(3);
				tenantPatient.put("TenantPatientId", newNum);

				String test = (String) tenantPatient.get("TenantPatientId");	
			} catch (Exception e) {
				log.error("Failed to update tenant patiend id", e);
				e.printStackTrace();
			}
			try {
				visitObject.put("AccountNumber", newNum);
				visitObject.put("VisitNumber", newNum);
				Object tt = visitObject.get("VisitDate");
				String updatedDate = rest.updatedDateAppointment(tt);
				visitObject.put("VisitDate", updatedDate);

			} catch (Exception e) {
				log.error("Failed to update tenantPatientVisitId and visitDate", e);
				e.printStackTrace();
			}

			try {
				// update appointmentStartDate and appointmentEndDate
				Object appointment = appointmentObject.get("AppointmentStartDate");
				String updatedDates = rest.updatedDateAppointment(appointment);
				appointmentObject.put("AppointmentStartDate", updatedDates);
				appointmentObject.put("AppointmentEndDate", updatedDates);
				String appointmentId = rest.getUniqueAppointmentNumber();				
				appointmentObject.put("AppointmentId", appointmentId);
			} catch (Exception e) {
				log.error("Failed to update appointmentStartDate and appointmentEndDate", e);
				e.printStackTrace();
			}
			FileWriter file = new FileWriter(AAAALERTS);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void updatePatientData(String fieldName,String fieldValue) throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(AAAALERTS);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			JSONObject patientObject = (JSONObject) jsonObject.get("Patient");
			if("PatientLastName".contentEquals(fieldName)){
				patientObject.put(fieldName, fieldValue);
				System.out.println("Data is: "+fieldName+"  Name is: " +fieldValue);
			}

			JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
			JSONObject event = (JSONObject) tnasaction.get(0);
			event.put("EmployeeId", "1571");
			
			try {
				JSONArray guarantor = (JSONArray) jsonObject.get("Guarantor");
				JSONObject guarant= (JSONObject) guarantor.get(0);
				JSONArray guarantorAddressObject = (JSONArray) guarant.get("GuarantorAddress");
				JSONObject addressObject= (JSONObject) guarantorAddressObject.get(0);
				addressObject.put("StreetAddress1", "1045 CLOVE GLEN");
			} catch (Exception e) {
				report.reportFail(""+e,true);
			}



			FileWriter file = new FileWriter(AAAALERTS);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void updateEmployeeId(String employeeName, String employeeId) throws ParseException {
		try {
			FileReader reader = new FileReader(AAAALERTS);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON

			JSONArray tnasaction = (JSONArray) jsonObject.get("Transaction");
			JSONObject event = (JSONObject) tnasaction.get(0);
			/*if(employeeName.contentEquals("reddykesi@gmail.com")){
				event.put("EmployeeId", employeeId);
			}
			if(employeeName.contentEquals("kyenugu@xtglobal.com")){
				event.put("EmployeeId", employeeId);
			}*/
			event.put("EmployeeId", employeeId);

			FileWriter file = new FileWriter(AAAALERTS);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
	public void updateGuarantorData(String address) throws ParseException {
		String newNum = "";
		try {
			FileReader reader = new FileReader(AAAALERTS);
			JSONParser jsonParser = new JSONParser();
			jsonObject = (JSONObject) jsonParser.parse(reader);
			// Read specific object in JSON
			try {
				JSONArray guarantor = (JSONArray) jsonObject.get("Guarantor");
				JSONObject guarant= (JSONObject) guarantor.get(0);
				JSONArray guarantorAddressObject = (JSONArray) guarant.get("GuarantorAddress");
				JSONObject addressObject= (JSONObject) guarantorAddressObject.get(0);
				addressObject.put("StreetAddress1", address);
			} catch (Exception e) {
				e.printStackTrace();
			}

			FileWriter file = new FileWriter(AAAALERTS);
			// File Writer creates a file in write mode at the given location
			file.write(jsonObject.toString());
			file.flush();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
	}


	public String getCurrentDate() {
		String currentDate = "";
		try {
			Date date = new Date();
			date = DateUtils.addDays(date, -1);
			currentDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
		} catch (Exception e) {

		}
		return currentDate;

	}

	public String updatedDateAppointment(Object object) {
		String updatedDate = "";
		try {
			String date = object.toString();
			String currentDate = getCurrentDate();
			String array[] = date.split("T");
			updatedDate = currentDate + "T" + array[1];
			log.info("Updated appointment date");
		} catch (Exception e) {
			log.error("Failed to update appointment date", e);
		}

		return updatedDate;

	}



	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(tbl_AccountSearchData);
	}

}
