package com.ipas.hf.web.pages.ipasPages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class AlertPage extends BasePage {
	
	PatientVisitSummaryAllDataPanelPage summary=new PatientVisitSummaryAllDataPanelPage();
	
	@FindBy(xpath="//div[@id='notificationBell']/div")
	private WebElement img_Bell;
	
	@FindBy(xpath="//h4[contains(text(),'Notifications')]")
	private WebElement lbl_Notifications;
	
	@FindBy(xpath="//ejs-sidebar//div[@class='e-card-header-title']")
	private List<WebElement> lbl_NotificationsList;	
	
	@FindBy(xpath="//div[@id='notificationBell']/span")
	private WebElement lbl_AlertsCount;
	
	@FindBy(xpath="//a[contains(text(),'All Data')]")
	private WebElement lbl_AllDataPanel;
	
	@FindBy(xpath = "//a[contains(text(),'Account Search')]")
	private WebElement lnk_AccounSearch;
	
	@FindBy(xpath="//table[@class='e-table']//thead/tr")
	private WebElement lbl_Headers;
	
	@FindBy(xpath="//div[@class='emptyinfo']")
	private WebElement lbl_NoDataMsg;
	
	public AlertPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void verifyNotificationsWindow(){
		try {
			clickOnBellIcon();
			String windowTitle=webActions.getText(lbl_Notifications, "Notifications");
			if("Notifications".contentEquals(windowTitle)){
				report.reportPass("Verified window title successfully");
			}
			else{
				report.reportFail("Fail to verify window title and actual displayed is: " + windowTitle);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	
	public ArrayList<String> getNotificationsList(List<WebElement> elements, String elementName){
		ArrayList<String> data= new ArrayList<String>();
		List<WebElement> allElement = elements;
		for (WebElement we: allElement) { 
			String txt=we.getText().trim();						
			data.add(txt);			
		}
		return data;
	}
	public int getAlertsCount(){	
		String count=webActions.getText(lbl_AlertsCount, "Alertscount");		
		return Integer.parseInt(count);
	}
	
	public void clickOnBellIcon(){
		try {
			webActions.waitForPageLoaded();			
			webActions.click(img_Bell, "BellIcon");
			webActions.waitForPageLoaded();
			webActions.waitForVisibility(lbl_Notifications, "Notifications");
			Thread.sleep(15000);			
			
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}
	public void verifyAlertsCount(){
		try {
			clickOnBellIcon();
			ArrayList<String> resultsCount=getNotificationsList(lbl_NotificationsList,"TotalAlerts");
			int expResultsCount=resultsCount.size();
			int actResultsCount=getAlertsCount();
			if(actResultsCount==expResultsCount){
				report.reportPass("Alerts count is verified successfully and  result count is: "+expResultsCount);
			}
			else{
				throw new Exception("Alerts count verification is failed and expected count is:" +expResultsCount+ "but displyed alerts count is: "+actResultsCount);
			}
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
	public void clickAccountSearchLinkAndBellIcon(){
		try {
			webActions.waitForVisibility(lnk_AccounSearch,"AccountSearch");
			webActions.click(lnk_AccounSearch, "AccountSearch");
			webActions.waitForPageLoaded();
			try {
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(lbl_Headers, "Headers in Account Search");
			} catch (Exception e) {
				webActions.waitForPageLoaded();
				webActions.waitForVisibility(lbl_NoDataMsg,"SearchResults");
			}
			clickOnBellIcon();
			report.reportPass("Clicked on Account Search link and navigated to the Account Search Page Successfully");
		} catch (Exception e) {
			report.reportFail(e.getMessage());
		}
	}
	
public void verifyNavigation(String moduleName){
	try {
		List<WebElement> alertNames=driver.findElements(By.xpath("//ejs-sidebar//div[@class='e-card-header-title']"));	
		for(int i=1;i<=alertNames.size();i++){			
			String xpath="(//ejs-sidebar//div[@class='e-card-header-title'])["+i+"]";
			String text=driver.findElement(By.xpath(xpath)).getText();
			if(text.contentEquals(moduleName)){
				String content=driver.findElement(By.xpath("(//ejs-sidebar//div[@class='e-card-text'])["+i+"]")).getText();
				driver.findElement(By.xpath(xpath)).click();
				Thread.sleep(5000);
				if(content.contains("Account has")){
					String actPanelTitle=webActions.getText(lbl_AllDataPanel, "PanelTitle");
					if(actPanelTitle.contentEquals("All Data")){
						report.reportPass("Verified alert visit main page navigation");
					}
					else{
						report.reportFail("Fail to verify alert visit main page navigation");
					}
				}
				else {
					if(moduleName.contentEquals("Eligibility")){
						String actPage=driver.findElement(By.xpath("//div[@id='detailContent']/p")).getText();
						if(actPage.contentEquals("Eligibility Verification")){
							report.reportPass("Verified eligibility alert page navigation");
						}
						else{
							report.reportFail("Fail to verify eligibility alert page navigation");
						}
					}
					else if(moduleName.contentEquals("Medical Necessity Check")){
						String actPage=driver.findElement(By.xpath("//ipas-medical-necessity-add-check-config//div[@class='title ml-2']/span")).getText();
						if(actPage.contentEquals("Medical Necessity")){
							report.reportPass("Verified medical necessity alert page navigation");
						}
						else{
							report.reportFail("Fail to verify medical necessity alert page navigation");
						}
					}
					else if(moduleName.contentEquals("Postal Confirmation")){
						String actPage=driver.findElement(By.xpath("//ipas-postal-details//div[@class='title']")).getText();
						if(actPage.contentEquals("Postal Confirmation")){
							report.reportPass("Verified postal alert page navigation");
						}
						else{
							report.reportFail("Fail to verify postal alert page navigation");
						}
					}
					else if(moduleName.contentEquals("Identity Verifier")){
						String actPage=driver.findElement(By.xpath("//ipas-identity-propensity-details//div[@class='title']")).getText();
						if(actPage.contentEquals("Identity Verifier")){
							report.reportPass("Verified identity alert page navigation");
						}
						else{
							report.reportFail("Fail to verify identity alert page navigation");
						}
					}
					
				}
								
				break;
			}
		}
		
	
	} catch (Exception e) {
		report.reportFail(e.getMessage());
	}
}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}

}
