package com.ipas.hf.web.pages.ipasPages;


import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.ipas.hf.web.pages.BasePage;

import io.cucumber.datatable.DataTable;

public class ViewTenantsPage extends BasePage {

	@FindBy(linkText="Organization Maintenance")
	private WebElement lnk_OrganizationMaintenance;

	@FindBy(xpath="//div[@class='e-gridcontent']/div/table/tbody/tr")
	private List<WebElement> tbl_Tenants;

	@FindBy(xpath="//tr[@class='e-columnheader']/th/div/span")
	private List<WebElement> th_TenantsGrid;

	@FindBy(xpath="//div[@class='breadcrum-container']")
	private List<WebElement> lbl_Breadcrum_All;

	@FindBy(xpath="//div[@class='filter-section row']//div/child::label")
	private List<WebElement> lbl_TextFeildNames;

	@FindBy(xpath="//div[@class='filter-section row']//child::div/button")
	private List<WebElement> lbl_ButtonNames;

	@FindBy(xpath="//ejs-textbox[@id='search_text']/span/input")
	private WebElement txt_Search;

	@FindBy(xpath="//ejs-dropdownlist[@id='organizationId']/span/input")
	private WebElement dd_Organization;

	@FindBy(xpath="//div[@id='panel']//child::th")
	private List<WebElement> lbl_HeaderNames;

	@FindBy(xpath="//div[@class='e-gridcontent']//table/tbody/tr[1]/td[6]/div/a/img")
	private List<WebElement> atr_Actions;

	@FindBy(xpath="//div[@class='e-gridcontent']//table/tbody")
	public WebElement grid_Results;

	@FindBy(xpath="//div[@id='panel']")
	public WebElement grid_Header;

	@FindBy(xpath="//button[(text()='Apply')]")
	private WebElement btn_Apply;
	
	@FindBy(xpath="//div[@class='e-gridcontent']//table/tbody/tr[1]/td/a")
	private WebElement lbl_TenantName;
	
	@FindBy(xpath="//div[@class='wrapper']/div[1]/div[1]")
	private WebElement lbl_TenantName_FacilitiesPage;
	
	@FindBy(xpath="//div[@class='e-gridcontent']//table/tbody/tr[1]/td[4]/div/a")
	private WebElement lbl_CRMID;

	public ViewTenantsPage() {
		PageFactory.initElements(driver, this);
	}

	public void verifyFieldNamesa(DataTable labelNames){
		try {
			ArrayList<String> expLabel=new ArrayList<String>(labelNames.asList());
			navigateToTenantListPage();
			ArrayList<String> actLabel = new ArrayList<>();
			actLabel.addAll(webActions.getDatafromWebTable(lbl_TextFeildNames));
			actLabel.addAll(webActions.getDatafromWebTable(lbl_ButtonNames));
			report.reportInfo("Actual Label names: "+actLabel);
			report.reportInfo("Expected Label names: "+expLabel);
			ArrayList<String> unmatchData=webActions.getUmatchedInArrayComparision(actLabel, expLabel);
			if(unmatchData.size()==0){
				report.reportPass("Successfully verified the field names");
			}else{
				report.reportFail("Failed to verify the field names: "+unmatchData, true);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyPlaceholdersandDefaultValues(DataTable testData){
		try {
			ArrayList<String> expData=new ArrayList<String>(testData.asList());
			ArrayList<String> actData = new ArrayList<>();
			actData.add(webActions.getAttributeValue(txt_Search, "placeholder", "Search"));
			actData.add(webActions.getAttributeValue(dd_Organization, "aria-label", "Organization"));
			report.reportInfo("Actual Data: "+actData);
			report.reportInfo("Expected Data: "+expData);
			ArrayList<String> unmatchData=webActions.getUmatchedInArrayComparision(actData, expData);
			if(unmatchData.size()==0){
				report.reportPass("Successfully verified Placeholders and Default Values");
			}else{
				report.reportFail("Failed to verify Placeholders and Default Values: "+unmatchData, true);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyHeaderNames(DataTable testData){
		try {
			ArrayList<String> expHeaders=new ArrayList<String>(testData.asList());
			ArrayList<String> actHeaders=webActions.getDatafromWebTable(lbl_HeaderNames);
			report.reportInfo("Actual Header names: "+actHeaders);
			report.reportInfo("Expected Header names: "+expHeaders);
			ArrayList<String> unmatchHeaders=webActions.getUmatchedInArrayComparision(actHeaders, expHeaders);
			if(unmatchHeaders.size()==0){
				report.reportPass("Successfully verified the Header names");
			}else{
				report.reportFail("Failed to verify the Header names: "+unmatchHeaders, true);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void verifyActionIcons(DataTable testData){
		try {
			navigateToTenantListPage();
			ArrayList<String> expActions=new ArrayList<>(testData.asList());
			ArrayList<String> actActions=webActions.getListofAttributeValuesfromWebPage(atr_Actions, "src");
			report.reportInfo("Actual Data: "+actActions);
			report.reportInfo("Expected Data: "+expActions);
			ArrayList<String> unmatchData=webActions.getUmatchedInArrayComparision(actActions, expActions);
			if(unmatchData.size()==0){
				report.reportPass("Successfully verified Action icons and Default Values");
			}else{
				report.reportFail("Failed to verify Action icons: "+unmatchData, true);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void serachDatainTenantsGrid(String colunmName,String testData){
		try {
			navigateToTenantListPage();
			webActions.waitForPageLoaded();
			enterTestData(colunmName,testData);
			ArrayList<String> actData=webActions.getDataFromResultsGrid(grid_Header,grid_Results,colunmName,getTagName(colunmName));
			report.reportInfo("Actual Data: "+actData);
			report.reportInfo("Expected Data: "+testData);
			ArrayList<String>unMatchData=webActions.isFullArrayMatchWithData(actData,testData);
			if(unMatchData.size()==0){
				report.reportPass("Successfully verified the data");
			}else{
				report.reportFail("Failed to verify the data: "+unMatchData);
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
	}

	public void enterTestData(String colunmName,String testData){
		try {
			if("Tenant Name".contentEquals(colunmName)){
				webActions.click(txt_Search, "txt_Search");
				webActions.sendKeys(txt_Search, testData, "Search");
			}else if("Organization Name".contentEquals(colunmName)){
				webActions.sendKeys(dd_Organization, testData, "Search");
				webActions.click(btn_Apply, "Apply");
			}
			webActions.waitForPageLoaded();
		} catch (Exception e) {
			report.reportFail("Failed to enter the test data");
		}
	}
	public String getTagName(String columnName){
		String tagName="";
		if("Tenant Name".contentEquals(columnName)){
			tagName="a";
		}
		else {
			tagName="div";
		}
		return tagName;
	}

	public void navigateToTenantListPage(){
		try {
			webActions.waitAndClick(lnk_OrganizationMaintenance, "Organization Maintenance Link");
			webActions.waitForVisibilityOfAllElements(th_TenantsGrid, "Tenants Grid");
		} catch (Exception e) {
		}
	}
	
	public void verifyTenantNameDisplaysasHyperlink(String colunmName){
		try {
			navigateToTenantListPage();
			if ("Tenant Name".contentEquals(colunmName)) {
				String tenantNameInTenantPage = webActions.waitAndGetText(lbl_TenantName, "Tenant Name");
				webActions.click(lbl_TenantName, "Tenant Name");
				webActions.waitForPageLoaded();
				String tenantNameInFacilitiesPage = webActions.waitAndGetText(lbl_TenantName_FacilitiesPage,
						"Tenant Name in Facilities Page");
				if (tenantNameInTenantPage.contentEquals(tenantNameInFacilitiesPage)) {
					report.reportPass("Successfully verified "+colunmName+" as Hyperlink");
				} else {
					report.reportFail("Failed to verify "+colunmName+" as Hyperlink");
				} 
			}else if("CRM ID".contentEquals(colunmName)){
				webActions.click(lbl_CRMID, "CRM ID");
				webActions.waitForPageLoaded();
				webActions.switchToOtherOpenedWindow();
				String actPageTitle=webActions.getPageTitle();
				if("HubSpot Login".contentEquals(actPageTitle)){
					report.reportPass("Successfully verified "+colunmName+" as Hyperlink");
				}else{
					report.reportFail("Failed to verify "+colunmName+" as Hyperlink");
				}
			}
		} catch (Exception e) {
			report.reportFail(""+e);
		}
		
	}


	public String getDatafromMap(DataTable testData,String keyName){
		return (String) testData.asMaps(String.class, String.class).get(0).get(keyName);	
	}


	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txt_Search);
	}

}
